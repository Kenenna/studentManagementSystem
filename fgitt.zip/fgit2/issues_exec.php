<?php
session_start();
include("auth.php");
include("db.php");
if($_POST['id'])
{
$id=mysql_escape_String($_POST['id']);
$firstname=mysql_escape_String($_POST['firstname']);
$pfirstname=mysql_escape_String($_POST['pfirstname']);
$sfirstname=mysql_escape_String($_POST['sfirstname']);
$sql = "update scores set firstname='$firstname', pfirstname='$pfirstname', sfirstname='$sfirstname' where score_id='$id' AND school='".$_SESSION["school"]."'";
mysql_query($sql);
}
?>