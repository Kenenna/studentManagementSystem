<?php
	session_start();
	include("auth.php"); 
	include('db.php');
	include ("connection.php");
$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Update Attendance</title>
 <link rel="stylesheet" href="css/style.css" />
 
 <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
	<script src="table/js/jquery.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js" type="text/javascript"></script>

<link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
<script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
<style>
nav li ul li{
    z-index: 1000;
    float: left;
}
</style>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>

  <script>
$(document).ready(function() {
    $('#example').DataTable( {
        scrollY:        '50vh',
        scrollCollapse: true,
        paging:         false
    } );
} );
    </script>
 <script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>
  <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
</head>

<body>
<?php
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");
}
else{header("location: logout.php");}
?>

				
<?php
include "connection.php";
$user=$_SESSION['username'];
$result3 = mysqli_query($db, "SELECT * FROM users2 where username='$user' AND school='".$_SESSION["school"]."'");
while($rowtid = mysqli_fetch_assoc($result3))
{
$tname[] = $rowtid['teacher'];
}

$tna = current($tname);
if($_POST['good']=="good"){ //check in delstudentatt.php file
$classd = $_POST['classe'];
}else{
$classd = $_POST['class'];	
}
$arms = $_POST['arms'];
$year = $_POST['year'];
$term = $_POST['term'];
$role = $_SESSION['role'];
echo '<br><br><br>';

if($classd=='Primary 1'){
		$class = 'Year 1';
	}
	elseif($classd=='Primary 2'){
		$class = 'Year 2';
	}
	elseif($classd=='Primary 3'){
		$class = 'Year 3';
	}
	elseif($classd=='Primary 4'){
		$class = 'Year 4';
	}
	elseif($classd=='Primary 5'){
		$class = 'Year 5';
	}	
	elseif($classd=='Primary 6'){
		$class = 'Year 6';
	}
	elseif($classd=='JS1'){
		$class = 'Year 7';
	}
	elseif($classd=='JS2'){
		$class = 'Year 8';
	}
	elseif($classd=='JS3'){
		$class = 'Year 9';
	}
	elseif($classd=='SS1'){
		$class = 'Year 10';
	}
	elseif($classd=='SS2'){
		$class = 'Year 11';
	}	
	elseif($classd=='SS3'){
		$class = 'Year 12';
	}		
	else{
		$class = $classd;
	}	
	
	if($class=="Year 1"){
	if($ctype=="Js"){
	$cl = "JS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 1";
}else{
	$cl = "Year 1";
}
}
elseif($class=="Year 2"){
	if($ctype=="Js"){
	$cl = "JS2";
}elseif($ctype=="Primary"){
	$cl = "Primary 2";
}else{
	$cl = "Year 2";
}
}
elseif($class=="Year 3"){
	if($ctype=="Js"){
	$cl = "JS3";
}elseif($ctype=="Primary"){
	$cl = "Primary 3";
}else{
	$cl = "Year 3";
}
}
elseif($class=="Year 4"){
	if($ctype=="Js"){
	$cl = "SS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 4";
}else{
	$cl = "Year 4";
}
}
elseif($class=="Year 5"){
	if($ctype=="Js"){
	$cl = "SS2";
}elseif($ctype=="Primary"){
	$cl = "Primary 5";
}else{
	$cl = "Year 5";
}
}
elseif($class=="Year 6"){
	if($ctype=="Js"){
	$cl = "SS3";
}elseif($ctype=="Primary"){
	$cl = "Primary 6";
}else{
	$cl = "Year 6";
}
}
elseif($class=="Year 7"){
	if($ctype=="Js"){
	$cl = "JS1";
}else{
	$cl = "Year 7";
}
}
else if($class=="Year 8"){
	if($ctype=="Js"){
	$cl = "JS2";
}else{
	$cl = "Year 8";
}
}else if($class=="Year 9"){
	if($ctype=="Js"){
	$cl = "JS3";
}else{
	$cl = "Year 9";
}
}else if($class=="Year 10"){
	if($ctype=="Js"){
	$cl = "SS1";
}else{
	$cl = "Year 10";
}
}else if($class=="Year 11"){
	if($ctype=="Js"){
	$cl = "SS2";
}else{
	$cl = "Year 11";
}
}else if($class=="Year 12"){
	if($ctype=="Js"){
	$cl = "SS3";
}else{
	$cl = "Year 12";
}
}else{
	$cl = "NOT APPLICABLE";
}
	

$resulttnam = mysqli_query($db, "SELECT formt FROM attend where class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."' LIMIT 1");
while($rowtnam = mysqli_fetch_assoc($resulttnam))
{
$tnamee = $rowtnam['formt'];
}

if($role=='admin' OR $role=='principal'){
	$formt = $tnamee;
}else{
$resulttnamm = mysqli_query($db, "SELECT DISTINCT(formt) FROM attend where class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while($rowtnamm = mysqli_fetch_assoc($resulttnamm))
{
$tnamee2[] = $rowtnamm['formt'];
}
if(count($tnamee2)>=1){
$formt = $tnamee;
}
}
echo '<div class="row-fluid" style="width:100%;">';
echo '<div class="span12">';
echo '<div class="container" style="width:100%;">';
echo '<center>';
if($_SESSION['role']=='admin' OR $_SESSION['role']=='principal'){
echo '<br><br><br><br>';
}else{
echo '<input type="submit" style="background-color: green; color: white; float: right;" id="changehref" class="button" value="Take Attendance" />';
echo '<div style="clear: both;"></div>';
echo '<br>';
}
echo '<span style="color: red; font-size: 18px; text-decoration: underline;">Attendance for '.ucfirst($formt).'\'s '.$cl.' '.$arms.' Class in '.$term.', '.$year.'/'.($year+1).' Session</span><br>';
echo '<span style="color: red; font-size: 16px; text-decoration: underline;">Deleting a student\'s attendance for a given day, deletes that student\'s attendance for MORNING AND AFTERNOON of that day.</span><br>';

$result = mysqli_query($db, "SELECT * FROM attend where class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."' ORDER BY student_name ASC");
echo '<table id="example" class="table table-striped table-bordered" style="width:100%; text-align: center;">';
echo '<thead><tr>';
echo '<th style="text-align:center;">Student Name</th>';
echo '<th style="text-align:center;">Present</th>';
echo '<th style="display: none;">Class</th>';
echo '<th style="display: none;">Arm</th>';
echo '<th style="display: none;">Year</th>';
echo '<th style="display: none;">Term</th>';
echo '<th>Date</th>';
echo '<th>Edit</th>';
echo '<th>Delete</th>';
echo '</tr><thead><tbody>';
while ($row = mysqli_fetch_assoc($result)) {
echo '<tr>';
echo '<td style="text-align:center;"><input style="display: none;" type="text" id="student_name" name="student_name" value="'.$row['student_name'].'" />'.$row['student_name'].'</td>';
echo '<td style="text-align:center;"><input style="display: none;" type="text" id="attend" name="attend" value="'.$row['attend'].'" />'.$row['attend'].'</td>';
echo '<td style="display: none;"><input readonly="readonly" type="text" id="class" name="class" value="'.$row['class'].'" /></td>';
echo '<td style="display: none;"><input readonly="readonly" type="text" id="arms" name="arms" value="'.$row['arms'].'" /></td>';
echo '<td style="display: none;"><input readonly="readonly" type="text" id="year" name="year" value="'.$row['year'].'" /></td>';
echo '<td style="display: none;"><input readonly="readonly" type="text" id="term" name="term" value="'.$row['term'].'" /></td>';
echo '<td style="text-align:center;"><input style="display: none;" type="text" id="datename" name="datename" value="'.strtoupper(date("D jS \of F Y", strtotime($row["datename"]))).'" />'.strtoupper(date("D jS \of F Y", strtotime($row["datename"]))).'</td>';
echo '<td><a href="updatestudentsatt.php?id='.$row['id'].'"><img src="table/edit-icon.png" alt="no image" height="30" width="30" /></a></td>';
echo '<td><a onClick="javascript:confirmationDelete($(this));return false;" href="delstudentatt.php?id='.$row['id'].'"><img src="table/deletee.png" alt="no image" height="30" width="30" /></a></td>';
echo '</tr>';
}
echo '</tbody></table>';
echo '</center>';
?>
<br>
</div></div></div>
<?php
include("footer.php");
?>
</body>
</html>