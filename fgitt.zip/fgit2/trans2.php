<?php
include("auth.php"); //include auth.php file on all secure pages
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Transcript</title>
<script type="text/javascript" src="js/jquery-2.1.4.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script>
$(document).ready(function(){
	$( "input[type=text]" ).css( "display", "none" );
	$("input[type=submit], .pbutton").hover(
	function(){$(this).css("background-color", "red");},
	function(){$(this).css("background-color", "grey");}
	);
	$("input[type=submit], .pbutton").hover(
	function(){$(this).css("color", "white");},
	function(){$(this).css("color", "red");}
	);
	$( "input[type=submit]" ).css("color", "white");
	$( "tr:even" ).css( "background-color", "grey" );
	$( "tr:odd" ).css( "background-color", "red" );
	$( "tr:even" ).css( "color", "white" );
	$( "td:empty" ).text( "-" );
});
</script>

<script>
function printDiv(eleId){
    var PW = window.open('', '_blank', 'Print content');
 
    //IF YOU HAVE DIV STYLE IN CSS, REMOVE BELOW COMMENT AND ADD CSS ADDRESS
    //PW.document.write('<link rel="stylesheet" type="text/css" href="CSS-FILE-ADDRESS"/>');
 
    PW.document.write(document.getElementById(eleId).innerHTML);
    PW.document.close();
    PW.focus();
    PW.print();
    PW.close();
}
</script>


</head>
<body>
<?php
$class_name = $_POST['class_name'];
$year = $_POST['year'];
include "connection.php";
$user1 = $_SESSION['username'];
$resultreguser = mysqli_query($db, "SELECT * FROM users2 WHERE username='$user1'");
while($resultreguser2 = mysqli_fetch_assoc($resultreguser)){ 
$st_name[] = $resultreguser2['teacher'];
}
$student_name2 = current($st_name);
$student_name = $_POST['student_name'];
$resultreg = mysqli_query($db, "SELECT * FROM regstu WHERE caa='$class_name' AND yoa='$year' AND student_name='$student_name2'");
$resultreg22 = mysqli_query($db, "SELECT * FROM regstu WHERE caa='$class_name' AND yoa='$year' AND student_name='$student_name'");
$regcount = mysqli_num_rows($resultreg);
$regcount22 = mysqli_num_rows($resultreg22);



if($_SESSION['role'] == 'admin'){
if($regcount22 != 1){
	echo $regcount;
	echo "<div style='color:red; width:100%; text-align: center;'>YOUR YEAR OF ADMISSION OR CLASS AT ADMISSION IS INCORRECT</div>";
	echo '<meta content="2;index.php" http-equiv="refresh" />';
	}
else{
    while($resultreg2 = mysqli_fetch_assoc($resultreg22)){ 			
$stu_name[] = $resultreg2['student_name'];
$sex[] = $resultreg2['sex'];
$caa[] = $resultreg2['caa'];
$yoa[] = $resultreg2['yoa'];
$admno[] = $resultreg2['admno'];
$reason[] = $resultreg2['reason'];
$dob[] = $resultreg2['dob'];
}
$stu_name2 = current($stu_name);
$sex2 = current($sex);	
$caa2 = current($caa);
$yoa2 = current($yoa);
$admno2 = current($admno);
$reason2 = current($reason);
$dob2 = current($dob);

$year1 = $_POST['year'];
$year2 = $year1 + 1;
$year3 = $year1 + 2;
$year4 = $year1 + 3;
$year5 = $year1 + 4;
$year6 = $year1 + 5;
include "connection.php";
$resultgrad = mysqli_query($db, "SELECT * FROM studentsbyclass WHERE student_name='$stu_name2' AND (year='$year1' OR year='$year2' OR year='$year3' OR year='$year4' OR year='$year5' OR year='$year6') AND (term='First Term' OR term='Second Term' OR term='Third Term')");
while($rowgrad = mysqli_fetch_assoc($resultgrad))
							{ 			
$yeargrad[] = $rowgrad['year'];
}
$yeargrad2 = $yeargrad;
$maxgrad = max($yeargrad2);

$resultclass = mysqli_query($db, "SELECT * FROM studentsbyclass WHERE student_name='$stu_name2' AND year='$maxgrad' AND (term='First Term' OR term='Second Term' OR term='Third Term')");
while($rowclass = mysqli_fetch_assoc($resultclass))
							{ 			
$classgrad[] = $rowclass['class'];
}
$classgrad2 = current($classgrad);
?>
<!--<button onclick="printDiv('printMe');">Print Transcript</button>-->

<div id="printMe">
<table style="width: 100%;">
<tbody style="width: 100%;">
<tr style="width: 100%;">
<td style="width: 6%;"><img src="images/6.png" align="left" height="70" width="90" /></td>
<td style="text-align: left; width: 78%;" colspan="2">
<span style="font-size: 12pt;">CORONA SCHOOLS TRUST</span><br><span style="font-size: 10pt;">CORONA SECONDARY SCHOOL</span><br>
<span style="font-size: 9pt;">Yenagoa Road, Agbara Estate, Ogun State, Nigeria</span><br>
<span style="font-size: 8pt;">Email: info@coronaschools.org</span></span><br>
<span style="font-size: 8pt;"><span>Website: www.coronaschools.org</span></span><br>
</td>
<td style="width: 6%;">
<?php
include "connection.php";	
$student_name = $_POST['student_name'];
$resultpic = mysqli_query($db, "SELECT * FROM img WHERE student_name='$student_name'");
						while($rowpic = mysqli_fetch_assoc($resultpic))
							{
$rpic[] = $rowpic['img'];							
echo '<img style="float:right;" src="'.$rowpic['img'].'" height="80" width="100"/>';
}
$rpic2 = current($rpic);
?>
</td>
</tr>
<tr style="width: 100%;">
<td colspan="2" style="font-size: 11px; width: 50%;">NAME: <?php echo strtoupper($stu_name2); ?></td>
<td colspan="2" style="text-align: right; font-size: 10px; width: 50%;">YEAR OF ENTRY: <?php echo strtoupper($yoa2); ?> &nbsp;&nbsp;/&nbsp;&nbsp; YEAR OF LEAVING: <?php echo $maxgrad ?></td>
</tr>
<tr style="width: 100%;">
<td colspan="2" style="font-size: 10px; width: 50%;">SEX: <?php echo strtoupper($sex2); ?></td>
<td colspan="2" style="text-align: right; font-size: 10px; width: 50%;">REASON FOR LEAVING: <?php echo strtoupper($reason2); ?></td>
</tr>
<tr style="width: 100%;">
<td colspan="2" style="font-size: 10px; width: 50%;">CLASS: <?php echo strtoupper($caa2); ?> - <?php echo strtoupper($classgrad2); ?></td>
<td colspan="2" style="text-align: right; font-size: 10px; width: 50%;">ADMISSION NO: <?php echo $admno2; ?><br>DATE OF BIRTH: <?php echo $dob2; ?></td>
</tr>
</tbody>
</table>
<table style="height: auto; width: 100%; text-align: center;">
<tr><td><span style="font-size: 12pt;">TRANSCRIPT</span></td></tr>
</table>


<table id="tb1" style="font-size: 11px; width: 100%; text-align: center;" border="1">
<tbody>
<tr style="height: 2px;">
<td rowspan="3">SUBJECT</td>
<?php
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y7 = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y7 = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y7 = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y7 = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y7 = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y7 = 'Year 12';
		}
		else{
			$y7 = 'NOT APPLICABLE';
		}
	?>
<td  colspan="6"><?php echo $y7; ?></td>
<?php } ?>

<?php
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y8 = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y8 = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y8 = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y8 = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y8 = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y8 = 'NOT APPLICABLE';
		}
		else{
			$y8 = 'NOT APPLICABLE';
		}
	?>
<td colspan="6"><?php echo $y8; ?></td>
	<?php } ?>
	
	
<?php
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y9 = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y9 = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y9 = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y9 = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y9 = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y9 = 'NOT APPLICABLE';
		}
		else{
			$y9 = 'NOT APPLICABLE';
		}
	?>
<td colspan="6"><?php echo $y9; ?></td>
	<?php } ?>
	
<?php
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y10 = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y10 = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y10 = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y10 = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y10 = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y10 = 'NOT APPLICABLE';
		}
		else{
			$y10 = 'NOT APPLICABLE';
		}
	?>
<td colspan="6"><?php echo $y10; ?></td>
	<?php } ?>
	
<?php
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y11 = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y11 = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y11 = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y11 = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y11 = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y11 = 'NOT APPLICABLE';
		}
		else{
			$y11 = 'NOT APPLICABLE';
		}
	?>
<td colspan="6"><?php echo $y11; ?></td>
	<?php } ?>
	
<?php
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y12 = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y12 = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y12 = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y12 = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y12 = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y12 = 'NOT APPLICABLE';
		}
		else{
			$y12 = 'NA';
		}
	?>
<td colspan="6"><?php echo $y12; ?></td>
	<?php } ?>
</tr>
<tr style="height: 13px;">
<td colspan="2">1st Term</td>
<td colspan="2">2nd Term</td>
<td colspan="2">3rd Term</td>

<td  colspan="2">1st Term</td>
<td  colspan="2">2nd Term</td>
<td colspan="2">3rd Term</td>

<td  colspan="2">1st Term</td>
<td  colspan="2">2nd Term</td>
<td colspan="2">3rd Term</td>

<td  colspan="2">1st Term</td>
<td  colspan="2">2nd Term</td>
<td colspan="2">3rd Term</td>

<td  colspan="2">1st Term</td>
<td  colspan="2">2nd Term</td>
<td colspan="2">3rd Term</td>

<td  colspan="2">1st Term</td>
<td  colspan="2">2nd Term</td>
<td colspan="2">3rd Term</td>
</tr>
<tr style="height: 13px;">
<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>

<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>

<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>

<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>

<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>

<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>
</tr>


<tr style="height: 13px;">
<td>ENGLISH</td>
<?php
include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
//YEAR 7 DATA FOR ENGLISH
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='English'");
				while($row = mysqli_fetch_assoc($result))
							{
						$term111[] = $row['term'];						
						$score111[] = $row['score'];						
						}
$fscore111 = $score111;
$fterm111 = $term111;
$c = array_combine($fterm111, $fscore111);
$eng7 = $c;
ksort($eng7);
$ffengsc71 = $eng7['First Term'];
$ssengsc72 = $eng7['Second Term'];
$ttengsc73 = $eng7['Third Term'];
if($ffengsc71 >= 70){$gradeeng71 = "A"; }
else if(($ffengsc71 >= 60) AND ($ffengsc71 <= 69)){$gradeeng71 = "C";}
else if(($ffengsc71 >= 50) AND ($ffengsc71 <= 59)){$gradeeng71 = "P";}
else if(($ffengsc71 <= 49)){$gradeeng71 = "F";}
else {$gradeeng71 = "NA";}	
if($ssengsc72 >= 70){$gradeeng72 = "A"; }
else if(($ssengsc72 >= 60) AND ($ssengsc72 <= 69)){$gradeeng72 = "C";}
else if(($ssengsc72 >= 50) AND ($ssengsc72 <= 59)){$gradeeng72 = "P";}
else if(($ssengsc72 <= 49)){$gradeeng72 = "F";}
else {$gradeeng72 = "NA";}	
if($ttengsc73 >= 70){$gradeeng73 = "A"; }
else if(($ttengsc73 >= 60) AND ($ttengsc73 <= 69)){$gradeeng73 = "C";}
else if(($ttengsc73 >= 50) AND ($ttengsc73 <= 59)){$gradeeng73 = "P";}
else if(($ttengsc73 <= 49)){$gradeeng73 = "F";}
else {$gradeeng73 = "NA";}	
}

// YEAR 8 DATA FOR ENGLISH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeeng81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeeng81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeeng81 = "P";}
								else if(($row["score"] <= 49)){$gradeeng81 = "F";}
								else {$gradeeng81 = "NA";}
						$fengscore81[] = $row['score'];	
						}
$ffengsc81 = current($fengscore81);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeeng82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeeng82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeeng82 = "P";}
								else if(($row["score"] <= 49)){$gradeeng82 = "F";}
								else {$gradeeng82 = "NA";}
						$sengscore82[] = $row['score'];	
						}
$ssengsc82 = current($sengscore82);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeeng83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeeng83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeeng83 = "P";}
								else if(($row["score"] <= 49)){$gradeeng83 = "F";}
								else {$gradeeng83 = "NA";}
						$tengscore83[] = $row['score'];	
						}
$ttengsc83 = current($tengscore83);	
}
// YEAR 9 DATA FOR ENGLISH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeeng91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeeng91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeeng91 = "P";}
								else if(($row["score"] <= 49)){$gradeeng91 = "F";}
								else {$gradeeng91 = "NA";}
						$fengscore91[] = $row['score'];	
						}
$ffengsc91 = current($fengscore91);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeeng92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeeng92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeeng92 = "P";}
								else if(($row["score"] <= 49)){$gradeeng92 = "F";}
								else {$gradeeng92 = "NA";}
						$sengscore92[] = $row['score'];	
						}
$ssengsc92 = current($sengscore92);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeeng93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeeng93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeeng93 = "P";}
								else if(($row["score"] <= 49)){$gradeeng93 = "F";}
								else {$gradeeng93 = "NA";}
						$tengscore93[] = $row['score'];	
						}
$ttengsc93 = current($tengscore93);	
}	

// YEAR 10 DATA FOR ENGLISH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeeng101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeng101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeng101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeng101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeng101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeng101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeng101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeng101 = "E8";}
								else if(($row["score"] <= 39)){$gradeeng101 = "F9";}
								else {$gradeeng101 = "NA";}
						$fengscore101[] = $row['score'];						
						}
$ffengsc101 = current($fengscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeeng102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeng102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeng102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeng102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeng102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeng102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeng102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeng102 = "E8";}
								else if(($row["score"] <= 39)){$gradeeng102 = "F9";}
								else {$gradeeng102 = "NA";}
						$sengscore102[] = $row['score'];						
						}
$ssengsc102 = current($sengscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$gradeeng103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeng103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeng103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeng103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeng103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeng103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeng103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeng103 = "E8";}
								else if(($row["score"] <= 39)){$gradeeng103 = "F9";}
								else {$gradeeng103 = "NA";}
						$tengscore103[] = $row['score'];						
						}
$ttengsc103 = current($tengscore103);
}

// YEAR 11 DATA FOR ENGLISH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeeng111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeng111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeng111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeng111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeng111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeng111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeng111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeng111 = "E8";}
								else if(($row["score"] <= 39)){$gradeeng111 = "F9";}
								else {$gradeeng111 = "NA";}
						$fengscore111[] = $row['score'];						
						}
$ffengsc111 = current($fengscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$gradeeng112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeng112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeng112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeng112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeng112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeng112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeng112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeng112 = "E8";}
								else if(($row["score"] <= 39)){$gradeeng112 = "F9";}
								else {$gradeeng112 = "NA";}
						$sengscore112[] = $row['score'];						
						}
$ssengsc112 = current($sengscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradeeng113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeng113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeng113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeng113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeng113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeng113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeng113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeng113 = "E8";}
								else if(($row["score"] <= 39)){$gradeeng113 = "F9";}
								else {$gradeeng113 = "NA";}
						$tengscore113[] = $row['score'];						
						}
$ttengsc113 = current($tengscore113);		
}

// YEAR 12 DATA FOR ENGLISH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeeng121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeng121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeng121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeng121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeng121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeng121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeng121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeng121 = "E8";}
								else if(($row["score"] <= 39)){$gradeeng121 = "F9";}
								else {$gradeeng121 = "NA";}
						$fengscore121[] = $row['score'];						
						}
$ffengsc121 = current($fengscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeeng122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeng122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeng122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeng122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeng122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeng122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeng122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeng122 = "E8";}
								else if(($row["score"] <= 39)){$gradeeng122 = "F9";}
								else {$gradeeng122 = "NA";}
						$sengscore122[] = $row['score'];						
						}
$ssengsc122 = current($sengscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeeng123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeng123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeng123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeng123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeng123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeng123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeng123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeng123 = "E8";}
								else if(($row["score"] <= 39)){$gradeeng123 = "F9";}
								else {$gradeeng123 = "NA";}
						$tengscore123[] = $row['score'];						
						}
$ttengsc123 = current($tengscore123);
}					
?>
<td><?php echo $ffengsc71;  ?></td>
<td><?php if($ffengsc71 != ""){echo $gradeeng71;}else{echo "-";} ?></td>
<td><?php echo $ssengsc72;  ?></td>
<td><?php if($ssengsc72 != ""){echo $gradeeng72;}else{echo "-";} ?></td>
<td><?php echo $ttengsc73;  ?></td>
<td><?php if($ttengsc73 != ""){echo $gradeeng73;}else{echo "-";} ?></td>
<td><?php echo $ffengsc81;  ?></td>
<td><?php if($ffengsc81 != ""){echo $gradeeng81;}else{echo "-";} ?></td>
<td><?php echo $ssengsc82;  ?></td>
<td><?php if($ssengsc82 != ""){echo $gradeeng82;}else{echo "-";} ?></td>
<td><?php echo $ttengsc83;  ?></td>
<td><?php if($ttengsc83 != ""){echo $gradeeng83;}else{echo "-";} ?></td>
<td><?php echo $ffengsc91;  ?></td>
<td><?php if($ffengsc91 != ""){echo $gradeeng91;}else{echo "-";} ?></td>
<td><?php echo $ssengsc92;  ?></td>
<td><?php if($ssengsc92 != ""){echo $gradeeng92;}else{echo "-";} ?></td>
<td><?php echo $ttengsc93;  ?></td>
<td><?php if($ttengsc93 != ""){echo $gradeeng93;}else{echo "-";} ?></td>
<td><?php echo $ffengsc101;  ?></td>
<td><?php if($ffengsc101 != ""){echo $gradeeng101;}else{echo "-";} ?></td>
<td><?php echo $ssengsc102;  ?></td>
<td><?php if($ssengsc102 != ""){echo $gradeeng102;}else{echo "-";} ?></td>
<td><?php echo $ttengsc103;  ?></td>
<td><?php if($ttengsc103 != ""){echo $gradeeng103;}else{echo "-";} ?></td>
<td><?php echo $ffengsc111;  ?></td>
<td><?php if($ffengsc111 != ""){echo $gradeeng111;}else{echo "-";} ?></td>
<td><?php echo $ssengsc112;  ?></td>
<td><?php if($ssengsc112 != ""){echo $gradeeng112;}else{echo "-";} ?></td>
<td><?php echo $ttengsc113;  ?></td>
<td><?php if($ttengsc113 != ""){echo $gradeeng113;}else{echo "-";} ?></td>
<td><?php echo $ffengsc121;  ?></td>
<td><?php if($ffengsc121 != ""){echo $gradeeng121;}else{echo "-";} ?></td>
<td><?php echo $ssengsc122;  ?></td>
<td><?php if($ssengsc122 != ""){echo $gradeeng122;}else{echo "-";} ?></td>
<td><?php echo $ttengsc123;  ?></td>
<td><?php if($ttengsc123 != ""){echo $gradeeng123;}else{echo "-";} ?></td>
</tr>


<tr style="height: 13px;">
<td>MATHEMATICS</td>
<?php
include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
//YEAR 7 DATA FOR MATH
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademat71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademat71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademat71 = "P";}
								else if(($row["score"] <= 49)){$grademat71 = "F";}
								else {$grademat71 = "NA";}
						$fmatscore71[] = $row['score'];	
						}
$ffmatsc71 = current($fmatscore71);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademat72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademat72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademat72 = "P";}
								else if(($row["score"] <= 49)){$grademat72 = "F";}
								else {$grademat72 = "NA";}
						$smatscore72[] = $row['score'];	
						}
$ssmatsc72 = current($smatscore72);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademat73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademat73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademat73 = "P";}
								else if(($row["score"] <= 49)){$grademat73 = "F";}
								else {$grademat73 = "NA";}
						$tmatscore73[] = $row['score'];	
						}
$ttmatsc73 = current($tmatscore73);
}
// YEAR 8 DATA FOR MATHS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademat81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademat81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademat81 = "P";}
								else if(($row["score"] <= 49)){$grademat81 = "F";}
								else {$grademat81 = "NA";}
						$fmatscore81[] = $row['score'];	
						}
$ffmatsc81 = current($fmatscore81);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademat82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademat82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademat82 = "P";}
								else if(($row["score"] <= 49)){$grademat82 = "F";}
								else {$grademat82 = "NA";}
						$smatscore82[] = $row['score'];	
						}
$ssmatsc82 = current($smatscore82);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademat83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademat83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademat83 = "P";}
								else if(($row["score"] <= 49)){$grademat83 = "F";}
								else {$grademat83 = "NA";}
						$tmatscore83[] = $row['score'];	
						}
$ttmatsc83 = current($tmatscore83);
}
// YEAR 9 DATA FOR MATHS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademat91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademat91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademat91 = "P";}
								else if(($row["score"] <= 49)){$grademat91 = "F";}
								else {$grademat91 = "NA";}
						$fmatscore91[] = $row['score'];	
						}
$ffmatsc91 = current($fmatscore91);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademat92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademat92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademat92 = "P";}
								else if(($row["score"] <= 49)){$grademat92 = "F";}
								else {$grademat92 = "NA";}
						$smatscore92[] = $row['score'];	
						}
$ssmatsc92 = current($smatscore92);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademat93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademat93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademat93 = "P";}
								else if(($row["score"] <= 49)){$grademat93 = "F";}
								else {$grademat93 = "NA";}
						$tmatscore93[] = $row['score'];	
						}
$ttmatsc93 = current($tmatscore93);
}	

// YEAR 10 DATA FOR MATHS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$grademat101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademat101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademat101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademat101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademat101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademat101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademat101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademat101 = "E8";}
								else if(($row["score"] <= 39)){$grademat101 = "F9";}
								else {$grademat101 = "NA";}
						$fmatscore101[] = $row['score'];						
						}
$ffmatsc101 = current($fmatscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$grademat102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademat102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademat102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademat102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademat102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademat102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademat102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademat102 = "E8";}
								else if(($row["score"] <= 39)){$grademat102 = "F9";}
								else {$grademat102 = "NA";}
						$smatscore102[] = $row['score'];						
						}
$ssmatsc102 = current($smatscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$grademat103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademat103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademat103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademat103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademat103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademat103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademat103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademat103 = "E8";}
								else if(($row["score"] <= 39)){$grademat103 = "F9";}
								else {$grademat103 = "NA";}
						$tmatscore103[] = $row['score'];						
						}
$ttmatsc103 = current($tmatscore103);
}

// YEAR 11 DATA FOR MATHS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$grademat111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademat111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademat111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademat111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademat111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademat111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademat111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademat111 = "E8";}
								else if(($row["score"] <= 39)){$grademat111 = "F9";}
								else {$grademat111 = "NA";}
						$fmatscore111[] = $row['score'];						
						}
$ffmatsc111 = current($fmatscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$grademat112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademat112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademat112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademat112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademat112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademat112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademat112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademat112 = "E8";}
								else if(($row["score"] <= 39)){$grademat112 = "F9";}
								else {$grademat112 = "NA";}
						$smatscore112[] = $row['score'];						
						}
$ssmatsc112 = current($smatscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grademat113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademat113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademat113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademat113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademat113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademat113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademat113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademat113 = "E8";}
								else if(($row["score"] <= 39)){$grademat113 = "F9";}
								else {$grademat113 = "NA";}
						$tmatscore113[] = $row['score'];						
						}
$ttmatsc113 = current($tmatscore113);		
}

// YEAR 12 DATA FOR MATHS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$grademat121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademat121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademat121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademat121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademat121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademat121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademat121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademat121 = "E8";}
								else if(($row["score"] <= 39)){$grademat121 = "F9";}
								else {$grademat121 = "NA";}
						$fmatscore121[] = $row['score'];						
						}
$ffmatsc121 = current($fmatscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$grademat122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademat122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademat122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademat122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademat122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademat122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademat122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademat122 = "E8";}
								else if(($row["score"] <= 39)){$grademat122 = "F9";}
								else {$grademat122 = "NA";}
						$smatscore122[] = $row['score'];						
						}
$ssmatsc122 = current($smatscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$grademat123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademat123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademat123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademat123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademat123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademat123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademat123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademat123 = "E8";}
								else if(($row["score"] <= 39)){$grademat123 = "F9";}
								else {$grademat123 = "NA";}
						$tmatscore123[] = $row['score'];						
						}
$ttmatsc123 = current($tmatscore123);
}					
?>
<td><?php echo $ffmatsc71;  ?></td>
<td><?php if($ffmatsc71 != ""){echo $grademat71;}else{echo "-";} ?></td>
<td><?php echo $ssmatsc72;  ?></td>
<td><?php if($ssmatsc72 != ""){echo $grademat72;}else{echo "-";} ?></td>
<td><?php echo $ttmatsc73;  ?></td>
<td><?php if($ttmatsc73 != ""){echo $grademat73;}else{echo "-";} ?></td>
<td><?php echo $ffmatsc81;  ?></td>
<td><?php if($ffmatsc81 != ""){echo $grademat81;}else{echo "-";} ?></td>
<td><?php echo $ssmatsc82;  ?></td>
<td><?php if($ssmatsc82 != ""){echo $grademat82;}else{echo "-";} ?></td>
<td><?php echo $ttmatsc83;  ?></td>
<td><?php if($ttmatsc83 != ""){echo $grademat83;}else{echo "-";} ?></td>
<td><?php echo $ffmatsc91;  ?></td>
<td><?php if($ffmatsc91 != ""){echo $grademat91;}else{echo "-";} ?></td>
<td><?php echo $ssmatsc92;  ?></td>
<td><?php if($ssmatsc92 != ""){echo $grademat92;}else{echo "-";} ?></td>
<td><?php echo $ttmatsc93;  ?></td>
<td><?php if($ttmatsc93 != ""){echo $grademat93;}else{echo "-";} ?></td>
<td><?php echo $ffmatsc101;  ?></td>
<td><?php if($ffmatsc101 != ""){echo $grademat101;}else{echo "-";} ?></td>
<td><?php echo $ssmatsc102;  ?></td>
<td><?php if($ssmatsc102 != ""){echo $grademat102;}else{echo "-";} ?></td>
<td><?php echo $ttmatsc103;  ?></td>
<td><?php if($ttmatsc103 != ""){echo $grademat103;}else{echo "-";} ?></td>
<td><?php echo $ffmatsc111;  ?></td>
<td><?php if($ffmatsc111 != ""){echo $grademat111;}else{echo "-";} ?></td>
<td><?php echo $ssmatsc112;  ?></td>
<td><?php if($ssmatsc112 != ""){echo $grademat112;}else{echo "-";} ?></td>
<td><?php echo $ttmatsc113;  ?></td>
<td><?php if($ttmatsc113 != ""){echo $grademat113;}else{echo "-";} ?></td>
<td><?php echo $ffmatsc121;  ?></td>
<td><?php if($ffmatsc121 != ""){echo $grademat121;}else{echo "-";} ?></td>
<td><?php echo $ssmatsc122;  ?></td>
<td><?php if($ssmatsc122 != ""){echo $grademat122;}else{echo "-";} ?></td>
<td><?php echo $ttmatsc123;  ?></td>
<td><?php if($ttmatsc123 != ""){echo $grademat123;}else{echo "-";} ?></td>
</tr>


<tr style="height: 13px;">
<td>AGRIC SC.</td>
<?php
include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
//YEAR 7 DATA FOR AGRIC
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeagr71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeagr71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeagr71 = "P";}
								else if(($row["score"] <= 49)){$gradeagr71 = "F";}
								else {$gradeagr71 = "NA";}
						$fagrscore71[] = $row['score'];	
						}
$ffagrsc71 = current($fagrscore71);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeagr72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeagr72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeagr72 = "P";}
								else if(($row["score"] <= 49)){$gradeagr72 = "F";}
								else {$gradeagr72 = "NA";}
						$sagrscore72[] = $row['score'];	
						}
$ssagrsc72 = current($sagrscore72);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeagr73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeagr73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeagr73 = "P";}
								else if(($row["score"] <= 49)){$gradeagr73 = "F";}
								else {$gradeagr73 = "NA";}
						$tagrscore73[] = $row['score'];	
						}
$ttagrsc73 = current($tagrscore73);	
}
// YEAR 8 DATA FOR AGRIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeagr81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeagr81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeagr81 = "P";}
								else if(($row["score"] <= 49)){$gradeagr81 = "F";}
								else {$gradeagr81 = "NA";}
						$fagrscore81[] = $row['score'];	
						}
$ffagrsc81 = current($fagrscore81);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeagr82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeagr82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeagr82 = "P";}
								else if(($row["score"] <= 49)){$gradeagr82 = "F";}
								else {$gradeagr82 = "NA";}
						$sagrscore82[] = $row['score'];	
						}
$ssagrsc82 = current($sagrscore82);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeagr83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeagr83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeagr83 = "P";}
								else if(($row["score"] <= 49)){$gradeagr83 = "F";}
								else {$gradeagr83 = "NA";}
						$tagrscore83[] = $row['score'];	
						}
$ttagrsc83 = current($tagrscore83);	
}
// YEAR 9 DATA FOR AGR
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeagr91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeagr91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeagr91 = "P";}
								else if(($row["score"] <= 49)){$gradeagr91 = "F";}
								else {$gradeagr91 = "NA";}
						$fagrscore91[] = $row['score'];	
						}
$ffagrsc91 = current($fagrscore91);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeagr92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeagr92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeagr92 = "P";}
								else if(($row["score"] <= 49)){$gradeagr92 = "F";}
								else {$gradeagr92 = "NA";}
						$sagrscore92[] = $row['score'];	
						}
$ssagrsc92 = current($sagrscore92);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeagr93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeagr93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeagr93 = "P";}
								else if(($row["score"] <= 49)){$gradeagr93 = "F";}
								else {$gradeagr93 = "NA";}
						$tagrscore93[] = $row['score'];	
						}
$ttagrsc93 = current($tagrscore93);	
}	

// YEAR 10 DATA FOR AGRIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeagr101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeagr101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeagr101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeagr101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeagr101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeagr101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeagr101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeagr101 = "E8";}
								else if(($row["score"] <= 39)){$gradeagr101 = "F9";}
								else {$gradeagr101 = "NA";}
						$fagrscore101[] = $row['score'];						
						}
$ffagrsc101 = current($fagrscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeagr102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeagr102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeagr102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeagr102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeagr102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeagr102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeagr102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeagr102 = "E8";}
								else if(($row["score"] <= 39)){$gradeagr102 = "F9";}
								else {$gradeagr102 = "NA";}
						$sagrscore102[] = $row['score'];						
						}
$ssagrsc102 = current($sagrscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradeagr103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeagr103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeagr103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeagr103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeagr103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeagr103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeagr103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeagr103 = "E8";}
								else if(($row["score"] <= 39)){$gradeagr103 = "F9";}
								else {$gradeagr103 = "NA";}
						$tagrscore103[] = $row['score'];						
						}
$ttagrsc103 = current($tagrscore103);
}

// YEAR 11 DATA FOR AGRIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeagr111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeagr111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeagr111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeagr111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeagr111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeagr111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeagr111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeagr111 = "E8";}
								else if(($row["score"] <= 39)){$gradeagr101 = "F9";}
								else {$gradeagr111 = "NA";}
						$fagrscore111[] = $row['score'];						
						}
$ffagrsc111 = current($fagrscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$gradeagr112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeagr112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeagr112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeagr112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeagr112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeagr112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeagr112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeagr112 = "E8";}
								else if(($row["score"] <= 39)){$gradeagr112 = "F9";}
								else {$gradeagr112 = "NA";}
						$sagrscore112[] = $row['score'];						
						}
$ssagrsc112 = current($sagrscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradeagr113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeagr113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeagr113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeagr113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeagr113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeagr113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeagr113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeagr113 = "E8";}
								else if(($row["score"] <= 39)){$gradeagr113 = "F9";}
								else {$gradeagr113 = "NA";}
						$tagrscore113[] = $row['score'];						
						}
$ttagrsc113 = current($tagrscore113);		
}

// YEAR 12 DATA FOR AGRIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeagr121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeagr121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeagr121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeagr121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeagr121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeagr121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeagr121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeagr121 = "E8";}
								else if(($row["score"] <= 39)){$gradeagr121 = "F9";}
								else {$gradeagr121 = "NA";}
						$fagrscore121[] = $row['score'];						
						}
$ffagrsc121 = current($fagrscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradeagr122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeagr122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeagr122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeagr122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeagr122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeagr122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeagr122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeagr122 = "E8";}
								else if(($row["score"] <= 39)){$gradeagr122 = "F9";}
								else {$gradeagr122 = "NA";}
						$sagrscore122[] = $row['score'];						
						}
$ssagrsc122 = current($sagrscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeagr123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeagr123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeagr123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeagr123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeagr123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeagr123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeagr123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeagr123 = "E8";}
								else if(($row["score"] <= 39)){$gradeagr123 = "F9";}
								else {$gradeagr123 = "NA";}
						$tagrscore123[] = $row['score'];						
						}
$ttagrsc123 = current($tagrscore123);
}					
?>
<td><?php echo $ffagrsc71;  ?></td>
<td><?php if($ffagrsc71 != ""){echo $gradeagr71;}else{echo "-";} ?></td>
<td><?php echo $ssagrsc72;  ?></td>
<td><?php if($ssagrsc72 != ""){echo $gradeagr72;}else{echo "-";} ?></td>
<td><?php echo $ttagrsc73;  ?></td>
<td><?php if($ttagrsc73 != ""){echo $gradeagr73;}else{echo "-";} ?></td>
<td><?php echo $ffagrsc81;  ?></td>
<td><?php if($ffagrsc81 != ""){echo $gradeagr81;}else{echo "-";} ?></td>
<td><?php echo $ssagrsc82;  ?></td>
<td><?php if($ssagrsc82 != ""){echo $gradeagr82;}else{echo "-";} ?></td>
<td><?php echo $ttagrsc83;  ?></td>
<td><?php if($ttagrsc83 != ""){echo $gradeagr83;}else{echo "-";} ?></td>
<td><?php echo $ffagrsc91;  ?></td>
<td><?php if($ffagrsc91 != ""){echo $gradeagr91;}else{echo "-";} ?></td>
<td><?php echo $ssagrsc92;  ?></td>
<td><?php if($ssagrsc92 != ""){echo $gradeagr92;}else{echo "-";} ?></td>
<td><?php echo $ttagrsc93;  ?></td>
<td><?php if($ttagrsc93 != ""){echo $gradeagr93;}else{echo "-";} ?></td>
<td><?php echo $ffagrsc101;  ?></td>
<td><?php if($ffagrsc101 != ""){echo $gradeagr101;}else{echo "-";} ?></td>
<td><?php echo $ssagrsc102;  ?></td>
<td><?php if($ssagrsc102 != ""){echo $gradeagr102;}else{echo "-";} ?></td>
<td><?php echo $ttagrsc103;  ?></td>
<td><?php if($ttagrsc103 != ""){echo $gradeagr103;}else{echo "-";} ?></td>
<td><?php echo $ffagrsc111;  ?></td>
<td><?php if($ffagrsc111 != ""){echo $gradeagr111;}else{echo "-";} ?></td>
<td><?php echo $ssagrsc112;  ?></td>
<td><?php if($ssagrsc112 != ""){echo $gradeagr112;}else{echo "-";} ?></td>
<td><?php echo $ttagrsc113;  ?></td>
<td><?php if($ttagrsc113 != ""){echo $gradeagr113;}else{echo "-";} ?></td>
<td><?php echo $ffagrsc121;  ?></td>
<td><?php if($ffagrsc121 != ""){echo $gradeagr121;}else{echo "-";} ?></td>
<td><?php echo $ssagrsc122;  ?></td>
<td><?php if($ssagrsc122 != ""){echo $gradeagr122;}else{echo "-";} ?></td>
<td><?php echo $ttagrsc123;  ?></td>
<td><?php if($ttagrsc123 != ""){echo $gradeagr123;}else{echo "-";} ?></td>
</tr>


<tr style="height: 13px;">
<td>BASIC SC.</td>
<?php
include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
//YEAR 7 DATA FOR BASIC SC
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='Basic Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebas71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebas71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebas71 = "P";}
								else if(($row["score"] <= 49)){$gradebas71 = "F";}
								else {$gradebas71 = "NA";}
						$fbasscore71[] = $row['score'];	
						}
$ffbassc71 = current($fbasscore71);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='Basic Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebas72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebas72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebas72 = "P";}
								else if(($row["score"] <= 49)){$gradebas72 = "F";}
								else {$gradebas72 = "NA";}
						$sbasscore72[] = $row['score'];	
						}
$ssbassc72 = current($sbasscore72);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='Basic Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebas73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebas73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebas73 = "P";}
								else if(($row["score"] <= 49)){$gradebas73 = "F";}
								else {$gradebas73 = "NA";}
						$tbasscore73[] = $row['score'];	
						}
$ttbassc73 = current($tbasscore73);	
}
// YEAR 8 DATA FOR BASIC SC.
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Basic Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebas81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebas81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebas81 = "P";}
								else if(($row["score"] <= 49)){$gradebas81 = "F";}
								else {$gradebas81 = "NA";}
						$fbasscore81[] = $row['score'];	
						}
$ffbassc81 = current($fbasscore81);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Basic Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebas82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebas82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebas82 = "P";}
								else if(($row["score"] <= 49)){$gradebas82 = "F";}
								else {$gradebas82 = "NA";}
						$sbasscore82[] = $row['score'];	
						}
$ssbassc82 = current($sbasscore82);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Basic Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebas83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebas83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebas83 = "P";}
								else if(($row["score"] <= 49)){$gradebas83 = "F";}
								else {$gradebas83 = "NA";}
						$tbasscore83[] = $row['score'];	
						}
$ttbassc83 = current($tbasscore83);	
}
// YEAR 9 DATA FOR BASIC SCIENCE
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Basic Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebas91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebas91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebas91 = "P";}
								else if(($row["score"] <= 49)){$gradebas91 = "F";}
								else {$gradebas91 = "NA";}
						$fbasscore91[] = $row['score'];	
						}
$ffbassc91 = current($fbasscore91);		

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Basic Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebas92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebas92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebas92 = "P";}
								else if(($row["score"] <= 49)){$gradebas92 = "F";}
								else {$gradebas92 = "NA";}
						$sbasscore92[] = $row['score'];	
						}
$ssbassc92 = current($sbasscore92);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Basic Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebas93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebas93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebas93 = "P";}
								else if(($row["score"] <= 49)){$gradebas93 = "F";}
								else {$gradebas93 = "NA";}
						$tbasscore93[] = $row['score'];	
						}
$ttbassc93 = current($tbasscore93);		
}	
?>
<td><?php echo $ffbassc71;  ?></td>
<td><?php if($ffbassc71 != ""){echo $gradebas71;}else{echo "-";} ?></td>
<td><?php echo $ssbassc72;  ?></td>
<td><?php if($ssbassc72 != ""){echo $gradebas72;}else{echo "-";} ?></td>
<td><?php echo $ttbassc73;  ?></td>
<td><?php if($ttbassc73 != ""){echo $gradebas73;}else{echo "-";} ?></td>
<td><?php echo $ffbassc81;  ?></td>
<td><?php if($ffbassc81 != ""){echo $gradebas81;}else{echo "-";} ?></td>
<td><?php echo $ssbassc82;  ?></td>
<td><?php if($ssbassc82 != ""){echo $gradebas82;}else{echo "-";} ?></td>
<td><?php echo $ttbassc83;  ?></td>
<td><?php if($ttbassc83 != ""){echo $gradebas83;}else{echo "-";} ?></td>
<td><?php echo $ffbassc91;  ?></td>
<td><?php if($ffbassc91 != ""){echo $gradebas91;}else{echo "-";} ?></td>
<td><?php echo $ssbassc92;  ?></td>
<td><?php if($ssbassc92 != ""){echo $gradebas92;}else{echo "-";} ?></td>
<td><?php echo $ttbassc93;  ?></td>
<td><?php if($ttbassc93 != ""){echo $gradebas93;}else{echo "-";} ?></td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
</tr>


<tr style="height: 13px;">
<td>BIOLOGY</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<?php
// YEAR 10 DATA FIRST TERM FOR BIOLOGY
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Biology'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradebio101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradebio101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradebio101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradebio101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradebio101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradebio101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradebio101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradebio101 = "E8";}
								else if(($row["score"] <= 39)){$gradebio101 = "F9";}
								else {$gradebio101 = "NA";}
						$bioscore101[] = $row['score'];	
						}
$ffbiosc101 = current($bioscore101);						
?>
<td><?php echo $ffbiosc101;  ?></td>
<td><?php if($ffbiosc101 != ""){echo $gradebio101;}else{echo "-";} ?></td>
<?php } ?>


<?php
// YEAR 10 DATA SECOND TERM FOR BIOLOGY
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Biology'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradebio102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradebio102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradebio102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradebio102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradebio102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradebio102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradebio102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradebio102 = "E8";}
								else if(($row["score"] <= 39)){$gradebio102 = "F9";}
								else {$gradebio102 = "NA";}
						$bioscore102[] = $row['score'];	
						}
$ssbiosc102 = current($bioscore102);						
?>
<td><?php echo $ssbiosc102;  ?></td>
<td><?php if($ssbiosc102 != ""){echo $gradebio102;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 10 DATA THIRD TERM FOR BIOLOGY
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Biology'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradebio103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradebio103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradebio103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradebio103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradebio103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradebio103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradebio103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradebio103 = "E8";}
								else if(($row["score"] <= 39)){$gradebio103 = "F9";}
								else {$gradebio103 = "NA";}
						$bioscore103[] = $row['score'];	
						}
$ttbiosc103 = current($bioscore103);						
?>
<td><?php echo $ttbiosc103;  ?></td>
<td><?php if($ttbiosc103 != ""){echo $gradebio103;}else{echo "-";} ?></td>
<?php } ?>





<?php
// YEAR 11 DATA FIRST TERM FOR BIOLOGY
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Biology'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradebio111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradebio111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradebio111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradebio111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradebio111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradebio111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradebio111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradebio111 = "E8";}
								else if(($row["score"] <= 39)){$gradebio111 = "F9";}
								else {$gradebio111 = "NA";}
						$bioscore111[] = $row['score'];	
						}
$ffbiosc111 = current($bioscore111);						
?>
<td><?php echo $ffbiosc111;  ?></td>
<td><?php if($ffbiosc111 != ""){echo $gradebio111;}else{echo "-";} ?></td>
<?php } ?>


<?php
// YEAR 11 DATA SECOND TERM FOR BIOLOGY
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Biology'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradebio112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradebio112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradebio112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradebio112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradebio112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradebio112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradebio112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradebio112 = "E8";}
								else if(($row["score"] <= 39)){$gradebio112 = "F9";}
								else {$gradebio112 = "NA";}
						$bioscore112[] = $row['score'];	
						}
$ssbiosc112 = current($bioscore112);						
?>
<td><?php echo $ssbiosc112;  ?></td>
<td><?php if($ssbiosc112 != ""){echo $gradebio112;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 11 DATA THIRD TERM FOR BIOLOGY
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NOT APPLICABLE';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Biology'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradebio113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradebio113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradebio113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradebio113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradebio113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradebio113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradebio113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradebio113 = "E8";}
								else if(($row["score"] <= 39)){$gradebio113 = "F9";}
								else {$gradebio113 = "NA";}
						$bioscore113[] = $row['score'];	
						}
$ttbiosc113 = current($bioscore113);						
?>
<td><?php echo $ttbiosc113;  ?></td>
<td><?php if($ttbiosc113 != ""){echo $gradebio113;}else{echo "-";} ?></td>
<?php } ?>




<?php
// YEAR 12 DATA FIRST TERM FOR BIOLOGY
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Biology'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradebio121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradebio121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradebio121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradebio121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradebio121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradebio121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradebio121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradebio121 = "E8";}
								else if(($row["score"] <= 39)){$gradebio121 = "F9";}
								else {$gradebio121 = "NA";}
						$bioscore121[] = $row['score'];	
						}
$ffbiosc121 = current($bioscore121);						
?>
<td><?php echo $ffbiosc121;  ?></td>
<td><?php if($ffbiosc121 != ""){echo $gradebio121;}else{echo "-";} ?></td>
<?php } ?>


<?php
// YEAR 12 DATA SECOND TERM FOR BIOLOGY
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Biology'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradebio122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradebio122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradebio122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradebio122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradebio122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradebio122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradebio122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradebio122 = "E8";}
								else if(($row["score"] <= 39)){$gradebio122 = "F9";}
								else {$gradebio122 = "NA";}
						$bioscore122[] = $row['score'];	
						}
$ssbiosc122 = current($bioscore122);						
?>
<td><?php echo $ssbiosc122;  ?></td>
<td><?php if($ssbiosc122 != ""){echo $gradebio122;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 12 DATA THIRD TERM FOR BIOLOGY
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Biology'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradebio123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradebio123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradebio123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradebio123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradebio123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradebio123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradebio123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradebio123 = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else if($y == 'NOT APPLICABLE'){$grade = "NA";}
								else {$gradebio123 = "NA";}
						$bioscore123[] = $row['score'];	
						}
$ttbiosc123 = current($bioscore123);				
?>
<td><?php echo $ttbiosc123;  ?></td>
<td><?php if($ttbiosc123 != ""){echo $gradebio123;}else{echo "-";} ?></td>
<?php } ?>
</tr>



<tr style="height: 13px;">
<td>BIZ. STUDIES</td>
<?php
//YEAR 7 DATA FIRST TERM FOR BIZ STUDIES
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='Business Studies'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebus71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebus71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebus71 = "P";}
								else if(($row["score"] <= 49)){$gradebus71 = "F";}
								else {$gradebus71 = "NA";}
						$fbusscore71[] = $row['score'];	
						}
$ffbussc71 = current($fbusscore71);					
?>
<td><?php echo $ffbussc71;  ?></td>
<td><?php if($ffbussc71 != ""){echo $gradebus71;}else{echo "-";} ?></td>
<?php } ?>
<?php
//YEAR 7 DATA SECOND TERM FOR BIZ
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='Business Studies'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebus72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebus72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebus72 = "P";}
								else if(($row["score"] <= 49)){$gradebus72 = "F";}
								else {$gradebus72 = "NA";}
						$sbusscore72[] = $row['score'];	
						}
$ssbussc72 = current($sbusscore72);					
?>
<td><?php echo $ssbussc72;  ?></td>
<td><?php if($ssbussc72 != ""){echo $gradebus72;}else{echo "-";} ?></td>
<?php } ?>
<?php
//YEAR 7 DATA THIRD TERM FOR BIZ
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='Business Studies'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebus73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebus73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebus73 = "P";}
								else if(($row["score"] <= 49)){$gradebus73 = "F";}
								else {$gradebus73 = "NA";}
						$tbusscore73[] = $row['score'];	
						}
$ttbussc73 = current($tbusscore73);			
?>
<td><?php echo $ttbussc73;  ?></td>
<td><?php if($ttbussc73 != ""){echo $gradebus73;}else{echo "-";} ?></td>
<?php } ?>
<?php
// YEAR 8 DATA FIRST TERM FOR BIZ
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Business Studies'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebus81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebus81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebus81 = "P";}
								else if(($row["score"] <= 49)){$gradebus81 = "F";}
								else {$gradebus81 = "NA";}
						$fbusscore81[] = $row['score'];	
						}
$ffbussc81 = current($fbusscore81);				
?>
<td><?php echo $ffbussc81;  ?></td>
<td><?php if($ffbussc81 != ""){echo $gradebus81;}else{echo "-";} ?></td>
<?php } ?>
<?php
// YEAR 8 DATA SECOND TERM FOR BIZ
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Business Studies'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebus82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebus82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebus82 = "P";}
								else if(($row["score"] <= 49)){$gradebus82 = "F";}
								else {$gradebus82 = "NA";}
						$sbusscore82[] = $row['score'];	
						}
$ssbussc82 = current($sbusscore82);						
?>
<td><?php echo $ssbussc82;  ?></td>
<td><?php if($ssbussc82 != ""){echo $gradebus82;}else{echo "-";} ?></td>
<?php } ?>
<?php
// YEAR 8 DATA THIRD TERM FOR BIZ
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Business Studies'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebus83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebus83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebus83 = "P";}
								else if(($row["score"] <= 49)){$gradebus83 = "F";}
								else {$gradebus83 = "NA";}
						$tbusscore83[] = $row['score'];	
						}
$ttbussc83 = current($tbusscore83);						
?>
<td><?php echo $ttbussc83;  ?></td>
<td><?php if($ttbussc83 != ""){echo $gradebus83;}else{echo "-";} ?></td>
<?php } ?>
<?php
// YEAR 9 DATA FIRST TERM FOR BIZ
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Business Studies'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebus91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebus91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebus91 = "P";}
								else if(($row["score"] <= 49)){$gradebus91 = "F";}
								else {$gradebus91 = "NA";}
						$fbusscore91[] = $row['score'];	
						}
$ffbussc91 = current($fbusscore91);						
?>
<td><?php echo $ffbussc91;  ?></td>
<td><?php if($ffbussc91 != ""){echo $gradebus91;}else{echo "-";} ?></td>
<?php } ?>
<?php
// YEAR 9 DATA SECOND TERM FOR BIZ
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Business Studies'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebus92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebus92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebus92 = "P";}
								else if(($row["score"] <= 49)){$gradebus92 = "F";}
								else {$gradebus92 = "NA";}
						$sbusscore92[] = $row['score'];	
						}
$ssbussc92 = current($sbusscore92);				
?>
<td><?php echo $ssbussc92;  ?></td>
<td><?php if($ssbussc92 != ""){echo $gradebus92;}else{echo "-";} ?></td>
<?php } ?>
<?php
// YEAR 9 DATA THIRD TERM FOR BIZ
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Business Studies'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebus93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebus93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebus93 = "P";}
								else if(($row["score"] <= 49)){$gradebus93 = "F";}
								else {$gradebus93 = "NA";}
						$tbusscore93[] = $row['score'];	
						}
$ttbussc93 = current($tbusscore93);		
?>
<td><?php echo $ttbussc93;  ?></td>
<td><?php if($ttbussc93 != ""){echo $gradebus93;}else{echo "-";} ?></td>
<?php } ?>

<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
</tr>


<tr style="height: 13px;">
<td>CATERING</td>
<?php
include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
//YEAR 7 DATA FOR CATERING
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecat71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecat71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecat71 = "P";}
								else if(($row["score"] <= 49)){$gradecat71 = "F";}
								else {$gradecat71 = "NA";}
						$fcatscore71[] = $row['score'];						
						}
$ffcatsc71 = current($fcatscore71);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecat72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecat72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecat72 = "P";}
								else if(($row["score"] <= 49)){$gradecat72 = "F";}
								else {$gradecat72 = "NA";}
						$scatscore72[] = $row['score'];						
						}
$sscatsc72 = current($scatscore72);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecat73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecat73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradect73 = "P";}
								else if(($row["score"] <= 49)){$gradecat73 = "F";}
								else {$gradecat73 = "NA";}
						$tcatscore73[] = $row['score'];						
}
$ttcatsc73 = current($tcatscore73);
}
// YEAR 8 DATA FOR CATERING
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecat81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecat81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecat81 = "P";}
								else if(($row["score"] <= 49)){$gradecat81 = "F";}
								else {$gradecat81 = "NA";}
						$fcatscore81[] = $row['score'];						
						}
$ffcatsc81 = current($fcatscore81);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecat82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecat82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecat82 = "P";}
								else if(($row["score"] <= 49)){$gradecat82 = "F";}
								else {$gradecat82 = "NA";}
						$scatscore82[] = $row['score'];						
						}
$sscatsc82 = current($scatscore82);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecat83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecat83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecat83 = "P";}
								else if(($row["score"] <= 49)){$gradecat83 = "F";}
								else {$gradecat83 = "NA";}
						$tcatscore83[] = $row['score'];						
}
$ttcatsc83 = current($tcatscore83);				
}

// YEAR 9 DATA FOR CATERING
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecat91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecat91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecat91 = "P";}
								else if(($row["score"] <= 49)){$gradecat91 = "F";}
								else {$gradecat91 = "NA";}
						$fcatscore91[] = $row['score'];						
						}
$ffcatsc91 = current($fcatscore91);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecat92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecat92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecat92 = "P";}
								else if(($row["score"] <= 49)){$gradecat92 = "F";}
								else {$gradecat92 = "NA";}
						$scatscore92[] = $row['score'];						
						}
$sscatsc92 = current($scatscore92);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecat93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecat93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecat93 = "P";}
								else if(($row["score"] <= 49)){$gradecat93 = "F";}
								else {$gradecat93 = "NA";}
						$tcatscore93[] = $row['score'];						
}
$ttcatsc93 = current($tcatscore93);				
}	

// YEAR 10 DATA FOR CATERING
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradecat101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecat101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecat101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecat101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecat101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecat101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecat101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecat101 = "E8";}
								else if(($row["score"] <= 39)){$gradecat101 = "F9";}
								else {$gradecat101 = "NA";}
						$fcatscore101[] = $row['score'];						
						}
$ffcatsc101 = current($fcatscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecat102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecat102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecat102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecat102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecat102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecat102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecat102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecat102 = "E8";}
								else if(($row["score"] <= 39)){$gradecat102 = "F9";}
								else {$gradecat102 = "NA";}
						$scatscore102[] = $row['score'];						
						}
$sscatsc102 = current($scatscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecat103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecat103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecat103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecat103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecat103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecat103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecat103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecat103 = "E8";}
								else if(($row["score"] <= 39)){$gradecat103 = "F9";}
								else {$gradecat103 = "NA";}
						$tcatscore103[] = $row['score'];						
}
$ttcatsc103 = current($tcatscore103);				
}

// YEAR 11 DATA FOR CATERING
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradecat111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecat111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecat111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecat111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecat111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecat111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecat111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecat111 = "E8";}
								else if(($row["score"] <= 39)){$gradecat111 = "F9";}
								else {$gradecat111 = "NA";}
						$fcatscore111[] = $row['score'];						
						}
$ffcatsc111 = current($fcatscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecat112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecat112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecat112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecat112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecat112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecat112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecat112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecat112 = "E8";}
								else if(($row["score"] <= 39)){$gradecat112 = "F9";}
								else {$gradecat112 = "NA";}
						$scatscore112[] = $row['score'];						
						}
$sscatsc112 = current($scatscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecat113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecat113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecat113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecat113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecat113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecat113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecat113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecat113 = "E8";}
								else if(($row["score"] <= 39)){$gradecat113 = "F9";}
								else {$gradecat113 = "NA";}
						$tcatscore113[] = $row['score'];						
}
$ttcatsc113 = current($tcatscore113);				
}

// YEAR 12 DATA FOR CATERING
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradecat121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecat121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecat121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecat121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecat121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecat121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecat121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecat121 = "E8";}
								else if(($row["score"] <= 39)){$gradecat121 = "F9";}
								else {$gradecat121 = "NA";}
						$fcatscore121[] = $row['score'];						
						}
$ffcatsc121 = current($fcatscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecat122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecat122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecat122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecat122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecat122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecat122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecat122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecat122 = "E8";}
								else if(($row["score"] <= 39)){$gradecat122 = "F9";}
								else {$gradecat122 = "NA";}
						$scatscore122[] = $row['score'];						
						}
$sscatsc122 = current($scatscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecat123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecat123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecat123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecat123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecat123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecat123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecat123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecat123 = "E8";}
								else if(($row["score"] <= 39)){$gradecat123 = "F9";}
								else {$gradecat123 = "NA";}
						$tcatscore123[] = $row['score'];						
}
$ttcatsc123 = current($tcatscore123);				
}					
?>
<td><?php echo $ffcatsc71;  ?></td>
<td><?php if($ffcatsc71 != ""){echo $gradecat71;}else{echo "-";} ?></td>
<td><?php echo $sscatsc72;  ?></td>
<td><?php if($sscatsc72 != ""){echo $gradecat72;}else{echo "-";} ?></td>
<td><?php echo $ttcatsc73;  ?></td>
<td><?php if($ttcatsc73 != ""){echo $gradecat73;}else{echo "-";} ?></td>
<td><?php echo $ffcatsc81;  ?></td>
<td><?php if($ffcatsc81 != ""){echo $gradecat81;}else{echo "-";} ?></td>
<td><?php echo $sscatsc82;  ?></td>
<td><?php if($sscatsc82 != ""){echo $gradecat82;}else{echo "-";} ?></td>
<td><?php echo $ttcatsc83;  ?></td>
<td><?php if($ttcatsc83 != ""){echo $gradecat83;}else{echo "-";} ?></td>
<td><?php echo $ffcatsc91;  ?></td>
<td><?php if($ffcatsc91 != ""){echo $gradecat91;}else{echo "-";} ?></td>
<td><?php echo $sscatsc92;  ?></td>
<td><?php if($sscatsc92 != ""){echo $gradecat92;}else{echo "-";} ?></td>
<td><?php echo $ttcatsc93;  ?></td>
<td><?php if($ttcatsc93 != ""){echo $gradecat93;}else{echo "-";} ?></td>
<td><?php echo $ffcatsc101;  ?></td>
<td><?php if($ffcatsc101 != ""){echo $gradecat101;}else{echo "-";} ?></td>
<td><?php echo $sscatsc102;  ?></td>
<td><?php if($sscatsc102 != ""){echo $gradecat102;}else{echo "-";} ?></td>
<td><?php echo $ttcatsc103;  ?></td>
<td><?php if($ttcatsc103 != ""){echo $gradecat103;}else{echo "-";} ?></td>
<td><?php echo $ffcatsc111;  ?></td>
<td><?php if($ffcatsc111 != ""){echo $gradecat111;}else{echo "-";} ?></td>
<td><?php echo $sscatsc112;  ?></td>
<td><?php if($sscatsc112 != ""){echo $gradecat112;}else{echo "-";} ?></td>
<td><?php echo $ttcatsc113;  ?></td>
<td><?php if($ttcatsc113 != ""){echo $gradecat113;}else{echo "-";} ?></td>
<td><?php echo $ffcatsc121;  ?></td>
<td><?php if($ffcatsc121 != ""){echo $gradecat121;}else{echo "-";} ?></td>
<td><?php echo $sscatsc122;  ?></td>
<td><?php if($sscatsc122 != ""){echo $gradecat122;}else{echo "-";} ?></td>
<td><?php echo $ttcatsc123;  ?></td>
<td><?php if($ttcatsc123 != ""){echo $gradecat123;}else{echo "-";} ?></td>
</tr>







<tr style="height: 13px;">
<td>CHEMISTRY</td>
<?php
include "connection.php";
// YEAR 10 DATA FOR CHEM
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Chemistry'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeche101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeche101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeche101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeche101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeche101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeche101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeche101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeche101 = "E8";}
								else if(($row["score"] <= 39)){$gradeche101 = "F9";}
								else {$gradeche101 = "NA";}
						$fchescore101[] = $row['score'];						
						}
$ffchescore101 = current($fchescore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Chemistry'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradeche102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeche102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeche102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeche102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeche102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeche102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeche102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeche102 = "E8";}
								else if(($row["score"] <= 39)){$gradeche101 = "F9";}
								else {$gradeche102 = "NA";}
						$schescore102[] = $row['score'];						
						}
$sschescore102 = current($schescore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Chemistry'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeche103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeche103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeche103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeche103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeche103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeche103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeche103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeche103 = "E8";}
								else if(($row["score"] <= 39)){$gradeche103 = "F9";}
								else {$gradeche103 = "NA";}
						$tchescore103[] = $row['score'];						
}
$ttchescore103 = current($tchescore103);				
}

// YEAR 11 DATA FOR CHEMISTRY
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Chemistry'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeche111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeche111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeche111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeche111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeche111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeche111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeche111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeche111 = "E8";}
								else if(($row["score"] <= 39)){$gradeche111 = "F9";}
								else {$gradeche111 = "NA";}
						$fchescore111[] = $row['score'];						
						}
$ffchescore111 = current($fchescore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Chemistry'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeche112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeche112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeche112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeche112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeche112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeche112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeche112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeche112 = "E8";}
								else if(($row["score"] <= 39)){$gradeche112 = "F9";}
								else {$gradeche112 = "NA";}
						$schescore112[] = $row['score'];						
						}
$sschescore112 = current($schescore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Chemistry'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeche113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeche113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeche113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeche113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeche113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeche113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeche113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeche113 = "E8";}
								else if(($row["score"] <= 39)){$gradeche113 = "F9";}
								else {$gradeche113 = "NA";}
						$tchescore113[] = $row['score'];						
}
$ttchescore113 = current($tchescore113);				
}

// YEAR 12 DATA FOR CHEMISTRY
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Chemistry'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradecat121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeche121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeche121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeche121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeche121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeche121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeche121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeche121 = "E8";}
								else if(($row["score"] <= 39)){$gradeche121 = "F9";}
								else {$gradeche121 = "NA";}
						$fchescore121[] = $row['score'];						
						}
$ffchescore121 = current($fchescore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Chemistry'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeche122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeche122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeche122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeche122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeche122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeche122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeche122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeche122 = "E8";}
								else if(($row["score"] <= 39)){$gradeche122 = "F9";}
								else {$gradeche122 = "NA";}
						$schescore122[] = $row['score'];						
						}
$sschescore122 = current($schescore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Chemistry'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeche123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeche123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeche123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeche123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeche123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeche123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeche123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeche123 = "E8";}
								else if(($row["score"] <= 39)){$gradeche123 = "F9";}
								else {$gradeche123 = "NA";}
						$tchescore123[] = $row['score'];						
}
$ttchescore123 = current($tchescore123);				
}					
?>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td><?php echo $ffchescore101;  ?></td>
<td><?php if($ffchescore101 != ""){echo $gradeche101;}else{echo "-";} ?></td>
<td><?php echo $sschescore102;  ?></td>
<td><?php if($sschescore102 != ""){echo $gradeche102;}else{echo "-";} ?></td>
<td><?php echo $ttchescore103;  ?></td>
<td><?php if($ttchescore103 != ""){echo $gradeche103;}else{echo "-";} ?></td>
<td><?php echo $ffchescore111;  ?></td>
<td><?php if($ffchescore111 != ""){echo $gradeche111;}else{echo "-";} ?></td>
<td><?php echo $sschescore112;  ?></td>
<td><?php if($sschescore112 != ""){echo $gradeche112;}else{echo "-";} ?></td>
<td><?php echo $ttchescore113;  ?></td>
<td><?php if($ttchescore113 != ""){echo $gradeche113;}else{echo "-";} ?></td>
<td><?php echo $ffchescore121;  ?></td>
<td><?php if($ffchescore121 != ""){echo $gradeche121;}else{echo "-";} ?></td>
<td><?php echo $sschescore122;  ?></td>
<td><?php if($sschescore122 != ""){echo $gradeche122;}else{echo "-";} ?></td>
<td><?php echo $ttchescore123;  ?></td>
<td><?php if($ttchescore123 != ""){echo $gradeche123;}else{echo "-";} ?></td>
</tr>



<tr style="height: 13px;">
<td>CIVIC EDU</td>
<?php
include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
//YEAR 7 DATA FOR CIVIC EDU
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeciv71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeciv71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeciv71 = "P";}
								else if(($row["score"] <= 49)){$gradeciv71 = "F";}
								else {$gradeciv71 = "NA";}
						$fcivscore71[] = $row['score'];						
						}
$ffcivscore71 = current($fcivscore71);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeciv72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeciv72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeciv72 = "P";}
								else if(($row["score"] <= 49)){$gradeciv72 = "F";}
								else {$gradeciv72 = "NA";}
						$scivscore72[] = $row['score'];						
						}
$sscivscore72 = current($scivscore72);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeciv73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeciv73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeciv73 = "P";}
								else if(($row["score"] <= 49)){$gradeciv73 = "F";}
								else {$gradeciv73 = "NA";}
						$tcivscore73[] = $row['score'];						
}
$ttcivscore73 = current($tcivscore73);
}
// YEAR 8 DATA FOR CIVIC EDU
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeciv81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeciv81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeciv81 = "P";}
								else if(($row["score"] <= 49)){$gradeciv81 = "F";}
								else {$gradeciv81 = "NA";}
						$fcivscore81[] = $row['score'];						
						}
$ffcivscore81 = current($fcivscore81);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeciv82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeciv82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeciv82 = "P";}
								else if(($row["score"] <= 49)){$gradeciv82 = "F";}
								else {$gradeciv82 = "NA";}
						$scivscore82[] = $row['score'];						
						}
$sscivscore82 = current($scivscore82);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeciv83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeciv83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeciv83 = "P";}
								else if(($row["score"] <= 49)){$gradeciv83 = "F";}
								else {$gradeciv83 = "NA";}
						$tcivscore83[] = $row['score'];						
}
$ttcivscore83 = current($tcivscore83);				
}

// YEAR 9 DATA FOR CIVIC EDU
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeciv91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeciv91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeciv91 = "P";}
								else if(($row["score"] <= 49)){$gradeciv91 = "F";}
								else {$gradeciv91 = "NA";}
						$fcivscore91[] = $row['score'];						
						}
$ffcivscore91 = current($fcivscore91);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeciv92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeciv92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeciv92 = "P";}
								else if(($row["score"] <= 49)){$gradeciv92 = "F";}
								else {$gradeciv92 = "NA";}
						$scivscore92[] = $row['score'];						
						}
$sscivscore92 = current($scivscore92);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeciv93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeciv93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeciv93 = "P";}
								else if(($row["score"] <= 49)){$gradeciv93 = "F";}
								else {$gradeciv93 = "NA";}
						$tcivscore93[] = $row['score'];						
}
$ttcivscore93 = current($tcivscore93);				
}	

// YEAR 10 DATA FOR CIVIC EDU
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeciv101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeciv101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeciv101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeciv101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeciv101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeciv101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeciv101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeciv101 = "E8";}
								else if(($row["score"] <= 39)){$gradeciv101 = "F9";}
								else {$gradeciv101 = "NA";}
						$fcivscore101[] = $row['score'];						
						}
$ffcivscore101 = current($fcivscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeciv102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeciv102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeciv102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeciv102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeciv102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeciv102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeciv102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeciv102 = "E8";}
								else if(($row["score"] <= 39)){$gradecat102 = "F9";}
								else {$gradeciv102 = "NA";}
						$scivscore102[] = $row['score'];						
						}
$sscivscore102 = current($scivscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeciv103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeciv103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeciv103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeciv103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeciv103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeciv103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeciv103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeciv103 = "E8";}
								else if(($row["score"] <= 39)){$gradecat102 = "F9";}
								else {$gradeciv103 = "NA";}
						$tcivscore103[] = $row['score'];						
}
$ttcivscore103 = current($tcivscore103);				
}

// YEAR 11 DATA FOR CIVIC EDU
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeciv111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeciv111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeciv111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeciv111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeciv111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeciv111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeciv111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeciv111 = "E8";}
								else if(($row["score"] <= 39)){$gradeciv111 = "F9";}
								else {$gradeciv111 = "NA";}
						$fcivscore111[] = $row['score'];						
						}
$ffcivscore111 = current($fcivscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$gradecat112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeciv112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeciv112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeciv112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeciv112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeciv112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeciv112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeciv112 = "E8";}
								else if(($row["score"] <= 39)){$gradeciv112 = "F9";}
								else {$gradeciv112 = "NA";}
						$scivscore112[] = $row['score'];						
						}
$sscivscore112 = current($scivscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$gradecat111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeciv113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeciv113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeciv113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeciv113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeciv113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeciv113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeciv113 = "E8";}
								else if(($row["score"] <= 39)){$gradeciv113 = "F9";}
								else {$gradeciv113 = "NA";}
						$tcivscore113[] = $row['score'];						
}
$ttcivscore113 = current($tcivscore113);				
}

// YEAR 12 DATA FOR CIVIC EDU
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeciv121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeciv121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeciv121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeciv121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeciv121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeciv121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeciv121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeciv121 = "E8";}
								else if(($row["score"] <= 39)){$gradeciv121 = "F9";}
								else {$gradeciv121 = "NA";}
						$fcivscore121[] = $row['score'];						
						}
$ffcivscore121 = current($fcivscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecat122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeciv122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeciv122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeciv122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeciv122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeciv122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeciv122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeciv122 = "E8";}
								else if(($row["score"] <= 39)){$gradeciv122 = "F9";}
								else {$gradeciv122 = "NA";}
						$scivscore122[] = $row['score'];						
						}
$sscivscore122 = current($scivscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecat123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeciv123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeciv123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeciv123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeciv123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeciv123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeciv123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeciv123 = "E8";}
								else if(($row["score"] <= 39)){$gradeciv123 = "F9";}
								else {$gradeciv123 = "NA";}
						$tcivscore123[] = $row['score'];						
}
$ttcivscore123 = current($tcivscore123);				
}					
?>
<td><?php echo $ffcivscore71;  ?></td>
<td><?php if($ffcivscore71 != ""){echo $gradeciv71;}else{echo "-";} ?></td>
<td><?php echo $sscivscore72;  ?></td>
<td><?php if($sscivscore72 != ""){echo $gradeciv72;}else{echo "-";} ?></td>
<td><?php echo $ttcivscore73;  ?></td>
<td><?php if($ttcivscore73 != ""){echo $gradeciv73;}else{echo "-";} ?></td>
<td><?php echo $ffcivscore81;  ?></td>
<td><?php if($ffcivscore81 != ""){echo $gradeciv81;}else{echo "-";} ?></td>
<td><?php echo $sscivscore82;  ?></td>
<td><?php if($sscivscore82 != ""){echo $gradeciv82;}else{echo "-";} ?></td>
<td><?php echo $ttcivscore83;  ?></td>
<td><?php if($ttcivscore83 != ""){echo $gradeciv83;}else{echo "-";} ?></td>
<td><?php echo $ffcivscore91;  ?></td>
<td><?php if($ffcivscore91 != ""){echo $gradeciv91;}else{echo "-";} ?></td>
<td><?php echo $sscivscore92;  ?></td>
<td><?php if($sscivscore92 != ""){echo $gradeciv92;}else{echo "-";} ?></td>
<td><?php echo $ttcivscore93;  ?></td>
<td><?php if($ttcivscore93 != ""){echo $gradeciv93;}else{echo "-";} ?></td>
<td><?php echo $ffcivscore101;  ?></td>
<td><?php if($ffcivscore101 != ""){echo $gradeciv101;}else{echo "-";} ?></td>
<td><?php echo $sscivscore102;  ?></td>
<td><?php if($sscivscore102 != ""){echo $gradeciv102;}else{echo "-";} ?></td>
<td><?php echo $ttcivscore103;  ?></td>
<td><?php if($ttcivscore103 != ""){echo $gradeciv103;}else{echo "-";} ?></td>
<td><?php echo $ffcivscore111;  ?></td>
<td><?php if($ffcivscore111 != ""){echo $gradeciv111;}else{echo "-";} ?></td>
<td><?php echo $sscivscore112;  ?></td>
<td><?php if($sscivscore112 != ""){echo $gradeciv112;}else{echo "-";} ?></td>
<td><?php echo $ttcivscore113;  ?></td>
<td><?php if($ttcivscore113 != ""){echo $gradeciv113;}else{echo "-";} ?></td>
<td><?php echo $ffcivscore121;  ?></td>
<td><?php if($ffcivscore121 != ""){echo $gradeciv121;}else{echo "-";} ?></td>
<td><?php echo $sscivscore122;  ?></td>
<td><?php if($sscivscore122 != ""){echo $gradeciv122;}else{echo "-";} ?></td>
<td><?php echo $ttcivscore123;  ?></td>
<td><?php if($ttcivscore123 != ""){echo $gradeciv123;}else{echo "-";} ?></td>
</tr>





<tr style="height: 13px;">
<td>CRK</td>
<?php
include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
//YEAR 7 DATA FOR CRK
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecrk71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecrk71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecrk71 = "P";}
								else if(($row["score"] <= 49)){$gradecrk71 = "F";}
								else {$gradecrk71 = "NA";}
						$fcrkscore71[] = $row['score'];						
						}
$ffcrkscore71 = current($fcrkscore71);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecrk72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecrk72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecrk72 = "P";}
								else if(($row["score"] <= 49)){$gradecrk72 = "F";}
								else {$gradecrk72 = "NA";}
						$scrkscore72[] = $row['score'];						
						}
$sscrkscore72 = current($scrkscore72);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecrk73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecrk73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecrk73 = "P";}
								else if(($row["score"] <= 49)){$gradecrk73 = "F";}
								else {$gradecrk73 = "NA";}
						$tcrkscore73[] = $row['score'];						
}
$ttcrkscore73 = current($tcrkscore73);
}
// YEAR 8 DATA FOR CRK
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecrk81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecrk81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecrk81 = "P";}
								else if(($row["score"] <= 49)){$gradecrk81 = "F";}
								else {$gradecrk81 = "NA";}
						$fcrkscore81[] = $row['score'];						
						}
$ffcrkscore81 = current($fcrkscore81);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecrk82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecrk82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecrk82 = "P";}
								else if(($row["score"] <= 49)){$gradecrk82 = "F";}
								else {$gradecrk82 = "NA";}
						$scrkscore82[] = $row['score'];						
						}
$sscrkscore82 = current($scrkscore82);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecrk83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecrk83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecrk83 = "P";}
								else if(($row["score"] <= 49)){$gradecrk83 = "F";}
								else {$gradecrk83 = "NA";}
						$tcrkscore83[] = $row['score'];						
}
$ttcrkscore83 = current($tcrkscore83);				
}

// YEAR 9 DATA FOR CRK
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecrk91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecrk91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecrk91 = "P";}
								else if(($row["score"] <= 49)){$gradecrk91 = "F";}
								else {$gradecrk91 = "NA";}
						$fcrkscore91[] = $row['score'];						
						}
$ffcrkscore91 = current($fcrkscore91);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecrk92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecrk92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecrk92 = "P";}
								else if(($row["score"] <= 49)){$gradecrk92 = "F";}
								else {$gradecrk92 = "NA";}
						$scrkscore92[] = $row['score'];						
						}
$sscrkscore92 = current($scrkscore92);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecrk93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecrk93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecrk93 = "P";}
								else if(($row["score"] <= 49)){$gradecrk93 = "F";}
								else {$gradecrk93 = "NA";}
						$tcrkscore93[] = $row['score'];						
}
$ttcrkscore93 = current($tcrkscore93);				
}	

// YEAR 10 DATA FOR CRK
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradecrk101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecrk101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecrk101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecrk101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecrk101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecrk101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecrk101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecrk101 = "E8";}
								else if(($row["score"] <= 39)){$gradecrk101 = "F9";}
								else {$gradecrk101 = "NA";}
						$fcrkscore101[] = $row['score'];						
						}
$ffcrkscore101 = current($fcrkscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecrk102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecrk102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecrk102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecrk102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecrk102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecrk102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecrk102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecrk102 = "E8";}
								else if(($row["score"] <= 39)){$gradecrk102 = "F9";}
								else {$gradecrk102 = "NA";}
						$scrkscore102[] = $row['score'];						
						}
$sscrkscore102 = current($scrkscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecrk103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecrk103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecrk103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecrk103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecrk103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecrk103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecrk103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecrk103 = "E8";}
								else if(($row["score"] <= 39)){$gradecrk103 = "F9";}
								else {$gradecrk103 = "NA";}
						$tcrkscore103[] = $row['score'];						
}
$ttcrkscore103 = current($tcrkscore103);				
}

// YEAR 11 DATA FOR CRK
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradecrk111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecrk111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecrk111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecrk111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecrk111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecrk111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecrk111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecrk111 = "E8";}
								else if(($row["score"] <= 39)){$gradecrk111 = "F9";}
								else {$gradecrk111 = "NA";}
						$fcrkscore111[] = $row['score'];						
						}
$ffcrkscore111 = current($fcrkscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecrk112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecrk112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecrk112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecrk112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecrk112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecrk112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecrk112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecrk112 = "E8";}
								else if(($row["score"] <= 39)){$gradecrk112 = "F9";}
								else {$gradecrk112 = "NA";}
						$scrkscore112[] = $row['score'];						
						}
$sscrkscore112 = current($scrkscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$gradecrk113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecrk113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecrk113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecrk113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecrk113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecrk113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecrk113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecrk113 = "E8";}
								else if(($row["score"] <= 39)){$gradecrk113 = "F9";}
								else {$gradecrk113 = "NA";}
						$tcrkscore113[] = $row['score'];						
}
$ttcrkscore113 = current($tcrkscore113);				
}

// YEAR 12 DATA FOR CRK
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradecrk121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecrk121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecrk121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecrk121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecrk121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecrk121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecrk121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecrk121 = "E8";}
								else if(($row["score"] <= 39)){$gradecrk121 = "F9";}
								else {$gradecrk121 = "NA";}
						$fcrkscore121[] = $row['score'];						
						}
$ffcrkscore121 = current($fcrkscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecrk122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecrk122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecrk122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecrk122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecrk122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecrk122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecrk122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecrk122 = "E8";}
								else if(($row["score"] <= 39)){$gradecrk122 = "F9";}
								else {$gradecrk122 = "NA";}
						$scrkscore122[] = $row['score'];						
						}
$sscrkscore122 = current($scrkscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecrk123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecrk123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecrk123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecrk123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecrk123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecrk123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecrk123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecrk123 = "E8";}
								else if(($row["score"] <= 39)){$gradecrk123 = "F9";}
								else {$gradecrk123 = "NA";}
						$tcrkscore123[] = $row['score'];						
}
$ttcrkscore123 = current($tcrkscore123);				
}					
?>
<td><?php echo $ffcrkscore71;  ?></td>
<td><?php if($ffcrkscore71 != ""){echo $gradecrk71;}else{echo "-";} ?></td>
<td><?php echo $sscrkscore72;  ?></td>
<td><?php if($sscrkscore72 != ""){echo $gradecrk72;}else{echo "-";} ?></td>
<td><?php echo $ttcrkscore73;  ?></td>
<td><?php if($ttcrkscore73 != ""){echo $gradecrk73;}else{echo "-";} ?></td>
<td><?php echo $ffcrkscore81;  ?></td>
<td><?php if($ffcrkscore81 != ""){echo $gradecrk81;}else{echo "-";} ?></td>
<td><?php echo $sscrkscore82;  ?></td>
<td><?php if($sscrkscore82 != ""){echo $gradecrk82;}else{echo "-";} ?></td>
<td><?php echo $ttcrkscore83;  ?></td>
<td><?php if($ttcrkscore83 != ""){echo $gradecrk83;}else{echo "-";} ?></td>
<td><?php echo $ffcrkscore91;  ?></td>
<td><?php if($ffcrkscore91 != ""){echo $gradecrk91;}else{echo "-";} ?></td>
<td><?php echo $sscrkscore92;  ?></td>
<td><?php if($sscrkscore92 != ""){echo $gradecrk92;}else{echo "-";} ?></td>
<td><?php echo $ttcrkscore93;  ?></td>
<td><?php if($ttcrkscore93 != ""){echo $gradecrk93;}else{echo "-";} ?></td>
<td><?php echo $ffcrkscore101;  ?></td>
<td><?php if($ffcrkscore101 != ""){echo $gradecrk101;}else{echo "-";} ?></td>
<td><?php echo $sscrkscore102;  ?></td>
<td><?php if($sscrkscore102 != ""){echo $gradecrk102;}else{echo "-";} ?></td>
<td><?php echo $ttcrkscore103;  ?></td>
<td><?php if($ttcrkscore103 != ""){echo $gradecrk103;}else{echo "-";} ?></td>
<td><?php echo $ffcrkscore111;  ?></td>
<td><?php if($ffcrkscore111 != ""){echo $gradecrk111;}else{echo "-";} ?></td>
<td><?php echo $sscrkscore112;  ?></td>
<td><?php if($sscrkscore112 != ""){echo $gradecrk112;}else{echo "-";} ?></td>
<td><?php echo $ttcrkscore113;  ?></td>
<td><?php if($ttcrkscore113 != ""){echo $gradecrk113;}else{echo "-";} ?></td>
<td><?php echo $ffcrkscore121;  ?></td>
<td><?php if($ffcrkscore121 != ""){echo $gradecrk121;}else{echo "-";} ?></td>
<td><?php echo $sscrkscore122;  ?></td>
<td><?php if($sscrkscore122 != ""){echo $gradecrk122;}else{echo "-";} ?></td>
<td><?php echo $ttcrkscore123;  ?></td>
<td><?php if($ttcrkscore123 != ""){echo $gradecrk123;}else{echo "-";} ?></td>
</tr>




<tr style="height: 13px;">
<td>ECONOMICS</td>
<?php
include "connection.php";
// YEAR 10 DATA FOR ECONOMICS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Economics'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeeco101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeco101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeco101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeco101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeco101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeco101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeco101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeco101 = "E8";}
								else if(($row["score"] <= 39)){$gradeeco101 = "F9";}
								else {$gradeeco101 = "NA";}
						$fecoscore101[] = $row['score'];						
						}
$ffecoscore101 = current($fecoscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Economics'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$gradeeco102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeco102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeco102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeco102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeco102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeco102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeco102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeco102 = "E8";}
								else if(($row["score"] <= 39)){$gradeeco102 = "F9";}
								else {$gradeeco102 = "NA";}
						$secoscore102[] = $row['score'];						
						}
$ssecoscore102 = current($secoscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Economics'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$gradeeco103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeco103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeco103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeco103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeco103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeco103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeco103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeco103 = "E8";}
								else if(($row["score"] <= 39)){$gradeeco103 = "F9";}
								else {$gradeeco103 = "NA";}
						$tecoscore103[] = $row['score'];						
}
$ttecoscore103 = current($tecoscore103);				
}

// YEAR 11 DATA FOR ECONOMICS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Economics'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeeco111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeco111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeco111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeco111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeco111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeco111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeco111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeco111 = "E8";}
								else if(($row["score"] <= 39)){$gradeeco111 = "F9";}
								else {$gradeeco111 = "NA";}
						$fecoscore111[] = $row['score'];						
						}
$ffecoscore111 = current($fecoscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Economics'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeeco112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeco112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeco112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeco112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeco112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeco112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeco112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeco112 = "E8";}
								else if(($row["score"] <= 39)){$gradeeco112 = "F9";}
								else {$gradeeco112 = "NA";}
						$secoscore112[] = $row['score'];					
						}
$ssecoscore112 = current($secoscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Economics'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$gradeeco113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeco113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeco113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeco113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeco113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeco113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeco113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeco113 = "E8";}
								else if(($row["score"] <= 39)){$gradeeco113 = "F9";}
								else {$gradeeco113 = "NA";}
						$tecoscore113[] = $row['score'];				
}
$ttecoscore113 = current($tecoscore113);				
}

// YEAR 12 DATA FOR ECONOMICS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Economics'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeeco121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeco121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeco121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeco121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeco121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeco121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeco121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeco121 = "E8";}
								else if(($row["score"] <= 39)){$gradeeco121 = "F9";}
								else {$gradeeco121 = "NA";}
						$fecoscore121[] = $row['score'];						
						}
$ffecoscore121 = current($fecoscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Economics'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeeco122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeco122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeco122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeco122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeco122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeco122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeco122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeco122 = "E8";}
								else if(($row["score"] <= 39)){$gradeeco122 = "F9";}
								else {$gradeeco122 = "NA";}
						$secoscore122[] = $row['score'];						
						}
$ssecoscore122 = current($secoscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Economics'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeeco123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeco123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeco123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeco123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeco123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeco123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeco123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeco123 = "E8";}
								else if(($row["score"] <= 39)){$gradeeco123 = "F9";}
								else {$gradeeco123 = "NA";}
						$tecoscore123[] = $row['score'];						
						}
$ttecoscore123 = current($tecoscore123);			
}					
?>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td><?php echo $ffecoscore101;  ?></td>
<td><?php if($ffecoscore101 != ""){echo $gradeeco101;}else{echo "-";} ?></td>
<td><?php echo $ssecoscore102;  ?></td>
<td><?php if($ssecoscore102 != ""){echo $gradeeco102;}else{echo "-";} ?></td>
<td><?php echo $ttecoscore103;  ?></td>
<td><?php if($ttecoscore103 != ""){echo $gradeeco103;}else{echo "-";} ?></td>
<td><?php echo $ffecoscore111;  ?></td>
<td><?php if($ffecoscore111 != ""){echo $gradeeco111;}else{echo "-";} ?></td>
<td><?php echo $ssecoscore112;  ?></td>
<td><?php if($ssecoscore112 != ""){echo $gradeeco112;}else{echo "-";} ?></td>
<td><?php echo $ttecoscore113;  ?></td>
<td><?php if($ttecoscore113 != ""){echo $gradeeco113;}else{echo "-";} ?></td>
<td><?php echo $ffecoscore121;  ?></td>
<td><?php if($ffecoscore121 != ""){echo $gradeeco121;}else{echo "-";} ?></td>
<td><?php echo $ssecoscore122;  ?></td>
<td><?php if($ssecoscore122 != ""){echo $gradeeco122;}else{echo "-";} ?></td>
<td><?php echo $ttecoscore123;  ?></td>
<td><?php if($ttecoscore123 != ""){echo $gradeeco123;}else{echo "-";} ?></td>
</tr>






<tr style="height: 13px;">
<td>FOOD & NUT.</td>
<?php
include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
//YEAR 7 DATA FOR FN
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefoo71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefoo71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefoo71 = "P";}
								else if(($row["score"] <= 49)){$gradefoo71 = "F";}
								else {$gradefoo71 = "NA";}
						$ffooscore71[] = $row['score'];						
						}
$fffooscore71 = current($ffooscore71);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefoo72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefoo72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefoo72 = "P";}
								else if(($row["score"] <= 49)){$gradefoo72 = "F";}
								else {$gradefoo72 = "NA";}
						$sfooscore72[] = $row['score'];						
						}
$ssfooscore72 = current($sfooscore72);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefoo73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefoo73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefoo73 = "P";}
								else if(($row["score"] <= 49)){$gradefoo73 = "F";}
								else {$gradefoo73 = "NA";}
						$tfooscore73[] = $row['score'];						
						}
$ttfooscore73 = current($tfooscore73);
}
// YEAR 8 DATA FOR F&N
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefoo81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefoo81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefoo81 = "P";}
								else if(($row["score"] <= 49)){$gradefoo81 = "F";}
								else {$gradefoo81 = "NA";}
						$ffooscore81[] = $row['score'];						
						}
$fffooscore81 = current($ffooscore81);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefoo82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefoo82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefoo82 = "P";}
								else if(($row["score"] <= 49)){$gradefoo82 = "F";}
								else {$gradefoo82 = "NA";}
						$sfooscore82[] = $row['score'];						
						}
$ssfooscore82 = current($sfooscore82);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefoo83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefoo83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefoo83 = "P";}
								else if(($row["score"] <= 49)){$gradefoo83 = "F";}
								else {$gradefoo83 = "NA";}
						$tfooscore83[] = $row['score'];						
						}
$ttfooscore83 = current($tfooscore83);
}
// YEAR 9 DATA FOR F&N
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefoo91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefoo91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefoo91 = "P";}
								else if(($row["score"] <= 49)){$gradefoo91 = "F";}
								else {$gradefoo91 = "NA";}
						$ffooscore91[] = $row['score'];						
						}
$fffooscore91 = current($ffooscore91);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefoo92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefoo92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefoo92 = "P";}
								else if(($row["score"] <= 49)){$gradefoo92 = "F";}
								else {$gradefoo92 = "NA";}
						$sfooscore92[] = $row['score'];						
						}
$ssfooscore92 = current($sfooscore92);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefoo93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefoo93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefoo93 = "P";}
								else if(($row["score"] <= 49)){$gradefoo93 = "F";}
								else {$gradefoo93 = "NA";}
						$tfooscore93[] = $row['score'];						
						}
$ttfooscore93 = current($tfooscore93);				
}	

// YEAR 10 DATA FOR F&N
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradefoo101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefoo101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefoo101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefoo101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefoo101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefoo101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefoo101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefoo101 = "E8";}
								else if(($row["score"] <= 39)){$gradefoo101 = "F9";}
								else {$gradefoo101 = "NA";}
						$ffooscore101[] = $row['score'];						
						}
$fffooscore101 = current($ffooscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradefoo102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefoo102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefoo102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefoo102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefoo102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefoo102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefoo102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefoo102 = "E8";}
								else if(($row["score"] <= 39)){$gradefoo102 = "F9";}
								else {$gradefoo102 = "NA";}
						$sfooscore102[] = $row['score'];						
						}
$ssfooscore102 = current($sfooscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradefoo103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefoo103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefoo103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefoo103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefoo103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefoo103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefoo103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefoo103 = "E8";}
								else if(($row["score"] <= 39)){$gradefoo103 = "F9";}
								else {$gradefoo103 = "NA";}
						$tfooscore103[] = $row['score'];						
						}
$ttfooscore103 = current($tfooscore103);		
}

// YEAR 11 DATA FOR CRK
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradefoo111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefoo111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefoo111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefoo111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefoo111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefoo111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefoo111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefoo111 = "E8";}
								else if(($row["score"] <= 39)){$gradefoo111 = "F9";}
								else {$gradefoo111 = "NA";}
						$ffooscore111[] = $row['score'];						
						}
$fffooscore111 = current($ffooscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradefoo112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefoo112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefoo112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefoo112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefoo112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefoo112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefoo112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefoo112 = "E8";}
								else if(($row["score"] <= 39)){$gradefoo112 = "F9";}
								else {$gradefoo112 = "NA";}
						$sfooscore112[] = $row['score'];						
						}
$ssfooscore112 = current($sfooscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradefoo113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefoo113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefoo113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefoo113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefoo113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefoo113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefoo113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefoo113 = "E8";}
								else if(($row["score"] <= 39)){$gradefoo113 = "F9";}
								else {$gradefoo113 = "NA";}
						$tfooscore113[] = $row['score'];						
						}
$ttfooscore113 = current($tfooscore113);				
}

// YEAR 12 DATA FOR FN
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradefoo121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefoo121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefoo121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefoo121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefoo121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefoo121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefoo121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefoo121 = "E8";}
								else if(($row["score"] <= 39)){$gradefoo121 = "F9";}
								else {$gradefoo121 = "NA";}
						$ffooscore121[] = $row['score'];						
						}
$fffooscore121 = current($ffooscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradefoo122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefoo122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefoo122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefoo122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefoo122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefoo122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefoo122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefoo122 = "E8";}
								else if(($row["score"] <= 39)){$gradefoo122 = "F9";}
								else {$gradefoo122 = "NA";}
						$sfooscore122[] = $row['score'];						
						}
$ssfooscore122 = current($sfooscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradefoo123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefoo123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefoo123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefoo123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefoo123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefoo123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefoo123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefoo123 = "E8";}
								else if(($row["score"] <= 39)){$gradefoo123 = "F9";}
								else {$gradefoo123 = "NA";}
						$tfooscore123[] = $row['score'];						
						}
$ttfooscore123 = current($tfooscore123);			
}					
?>
<td><?php echo $fffooscore71;  ?></td>
<td><?php if($fffooscore71 != ""){echo $gradefoo71;}else{echo "-";} ?></td>
<td><?php echo $ssfooscore72;  ?></td>
<td><?php if($ssfooscore72 != ""){echo $gradefoo72;}else{echo "-";} ?></td>
<td><?php echo $ttfooscore73;  ?></td>
<td><?php if($ttfooscore73 != ""){echo $gradefoo73;}else{echo "-";} ?></td>
<td><?php echo $fffooscore81;  ?></td>
<td><?php if($fffooscore81 != ""){echo $gradefoo81;}else{echo "-";} ?></td>
<td><?php echo $ssfooscore82;  ?></td>
<td><?php if($ssfooscore82 != ""){echo $gradefoo82;}else{echo "-";} ?></td>
<td><?php echo $ttfooscore83;  ?></td>
<td><?php if($ttfooscore83 != ""){echo $gradefoo83;}else{echo "-";} ?></td>
<td><?php echo $fffooscore91;  ?></td>
<td><?php if($fffooscore91 != ""){echo $gradefoo91;}else{echo "-";} ?></td>
<td><?php echo $ssfooscore92;  ?></td>
<td><?php if($ssfooscore92 != ""){echo $gradefoo92;}else{echo "-";} ?></td>
<td><?php echo $ttfooscore93;  ?></td>
<td><?php if($ttfooscore93 != ""){echo $gradefoo93;}else{echo "-";} ?></td>
<td><?php echo $fffooscore101;  ?></td>
<td><?php if($fffooscore101 != ""){echo $gradefoo101;}else{echo "-";} ?></td>
<td><?php echo $ssfooscore102;  ?></td>
<td><?php if($ssfooscore102 != ""){echo $gradefoo102;}else{echo "-";} ?></td>
<td><?php echo $ttfooscore103;  ?></td>
<td><?php if($ttfooscore103 != ""){echo $gradefoo103;}else{echo "-";} ?></td>
<td><?php echo $fffooscore111;  ?></td>
<td><?php if($fffooscore111 != ""){echo $gradefoo111;}else{echo "-";} ?></td>
<td><?php echo $ssfooscore112;  ?></td>
<td><?php if($ssfooscore112 != ""){echo $gradefoo112;}else{echo "-";} ?></td>
<td><?php echo $ttfooscore113;  ?></td>
<td><?php if($ttfooscore113 != ""){echo $gradefoo113;}else{echo "-";} ?></td>
<td><?php echo $fffooscore121;  ?></td>
<td><?php if($fffooscore121 != ""){echo $gradefoo121;}else{echo "-";} ?></td>
<td><?php echo $ssfooscore122;  ?></td>
<td><?php if($ssfooscore122 != ""){echo $gradefoo122;}else{echo "-";} ?></td>
<td><?php echo $ttfooscore123;  ?></td>
<td><?php if($ttfooscore123 != ""){echo $gradefoo123;}else{echo "-";} ?></td>
</tr>




<tr style="height: 13px;">
<td>FRENCH.</td>
<?php
include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
//YEAR 7 DATA FOR FRENCH
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefre71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefre71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefre71 = "P";}
								else if(($row["score"] <= 49)){$gradefre71 = "F";}
								else {$gradefre71 = "NA";}
						$ffrescore71[] = $row['score'];						
						}
$fffrescore71 = current($ffrescore71);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefre72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefre72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefre72 = "P";}
								else if(($row["score"] <= 49)){$gradefre72 = "F";}
								else {$gradefre72 = "NA";}
						$sfrescore72[] = $row['score'];						
						}
$ssfrescore72 = current($sfrescore72);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefre73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefre73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefre73 = "P";}
								else if(($row["score"] <= 49)){$gradefre73 = "F";}
								else {$gradefre73 = "NA";}
						$tfrescore73[] = $row['score'];						
						}
$ttfrescore73 = current($tfrescore73);
}
// YEAR 8 DATA FOR FRENCH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefre81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefre81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefre81 = "P";}
								else if(($row["score"] <= 49)){$gradefre81 = "F";}
								else {$gradefre81 = "NA";}
						$ffrescore81[] = $row['score'];						
						}
$fffrescore81 = current($ffrescore81);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefre82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefre82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefre82 = "P";}
								else if(($row["score"] <= 49)){$gradefre82 = "F";}
								else {$gradefre82 = "NA";}
						$sfrescore82[] = $row['score'];						
						}
$ssfrescore82 = current($sfrescore82);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefre83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefre83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefre83 = "P";}
								else if(($row["score"] <= 49)){$gradefre83 = "F";}
								else {$gradefre83 = "NA";}
						$tfrescore83[] = $row['score'];						
						}
$ttfrescore83 = current($tfrescore83);
}

// YEAR 9 DATA FOR FRENCH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefre91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefre91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefre91 = "P";}
								else if(($row["score"] <= 49)){$gradefre91 = "F";}
								else {$gradefre91 = "NA";}
						$ffrescore91[] = $row['score'];						
						}
$fffrescore91 = current($ffrescore91);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefre92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefre92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefre92 = "P";}
								else if(($row["score"] <= 49)){$gradefre92 = "F";}
								else {$gradefoo92 = "NA";}
						$sfrescore92[] = $row['score'];						
						}
$ssfrescore92 = current($sfrescore92);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefre93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefre93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefre93 = "P";}
								else if(($row["score"] <= 49)){$gradefre93 = "F";}
								else {$gradefre93 = "NA";}
						$tfrescore93[] = $row['score'];						
						}
$ttfrescore93 = current($tfrescore93);				
}	

// YEAR 10 DATA FOR FRENCH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradefre101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefre101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefre101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefre101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefre101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefre101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefre101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefre101 = "E8";}
								else if(($row["score"] <= 39)){$gradefre101 = "F9";}
								else {$gradefre101 = "NA";}
						$ffrescore101[] = $row['score'];						
						}
$fffrescore101 = current($ffrescore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradefre102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefre102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefre102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefre102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefre102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefre102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefre102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefre102 = "E8";}
								else if(($row["score"] <= 39)){$gradefre102 = "F9";}
								else {$gradefre102 = "NA";}
						$sfrescore102[] = $row['score'];						
						}
$ssfrescore102 = current($sfrescore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradefre103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefre103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefre103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefre103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefre103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefre103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefre103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefre103 = "E8";}
								else if(($row["score"] <= 39)){$gradefre103 = "F9";}
								else {$gradefre103 = "NA";}
						$tfrescore103[] = $row['score'];						
						}
$ttfrescore103 = current($tfrescore103);		
}

// YEAR 11 DATA FOR FRENCH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradefre111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefre111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefre111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefre111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefre111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefre111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefre111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefre111 = "E8";}
								else if(($row["score"] <= 39)){$gradefre111 = "F9";}
								else {$gradefre111 = "NA";}
						$ffrescore111[] = $row['score'];						
						}
$fffrescore111 = current($ffrescore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradefre112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefre112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefre112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefre112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefre112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefre112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefre112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefre112 = "E8";}
								else if(($row["score"] <= 39)){$gradefre112 = "F9";}
								else {$gradefre112 = "NA";}
						$sfrescore112[] = $row['score'];						
						}
$ssfrescore112 = current($sfrescore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradefre113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefre113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefre113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefre113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefre113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefre113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefre113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefre113 = "E8";}
								else if(($row["score"] <= 39)){$gradefre113 = "F9";}
								else {$gradefre113 = "NA";}
						$tfrescore113[] = $row['score'];						
						}
$ttfrescore113 = current($tfrescore113);				
}

// YEAR 12 DATA FOR FRENCH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradefre121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefre121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefre121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefre121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefre121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefre121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefre121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefre121 = "E8";}
								else if(($row["score"] <= 39)){$gradefre121 = "F9";}
								else {$gradefre121 = "NA";}
						$ffrescore121[] = $row['score'];						
						}
$fffrescore121 = current($ffrescore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradefre122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefre122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefre122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefre122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefre122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefre122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefre122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefre122 = "E8";}
								else if(($row["score"] <= 39)){$gradefre122 = "F9";}
								else {$gradefre122 = "NA";}
						$sfrescore122[] = $row['score'];						
						}
$ssfrescore122 = current($sfrescore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradefre123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefre123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefre123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefre123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefre123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefre123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefre123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefre123 = "E8";}
								else if(($row["score"] <= 39)){$gradefre123 = "F9";}
								else {$gradefre123 = "NA";}
						$tfrescore123[] = $row['score'];						
						}
$ttfrescore123 = current($tfrescore123);			
}					
?>
<td><?php echo $fffrescore71;  ?></td>
<td><?php if($fffrescore71 != ""){echo $gradefre71;}else{echo "-";} ?></td>
<td><?php echo $ssfrescore72;  ?></td>
<td><?php if($ssfrescore72 != ""){echo $gradefre72;}else{echo "-";} ?></td>
<td><?php echo $ttfrescore73;  ?></td>
<td><?php if($ttfrescore73 != ""){echo $gradefre73;}else{echo "-";} ?></td>
<td><?php echo $fffrescore81;  ?></td>
<td><?php if($fffrescore81 != ""){echo $gradefre81;}else{echo "-";} ?></td>
<td><?php echo $ssfrescore82;  ?></td>
<td><?php if($ssfrescore82 != ""){echo $gradefre82;}else{echo "-";} ?></td>
<td><?php echo $ttfrescore83;  ?></td>
<td><?php if($ttfrescore83 != ""){echo $gradefre83;}else{echo "-";} ?></td>
<td><?php echo $fffrescore91;  ?></td>
<td><?php if($fffrescore91 != ""){echo $gradefre91;}else{echo "-";} ?></td>
<td><?php echo $ssfrescore92;  ?></td>
<td><?php if($ssfrescore92 != ""){echo $gradefre92;}else{echo "-";} ?></td>
<td><?php echo $ttfrescore93;  ?></td>
<td><?php if($ttfrescore93 != ""){echo $gradefre93;}else{echo "-";} ?></td>
<td><?php echo $fffrescore101;  ?></td>
<td><?php if($fffrescore101 != ""){echo $gradefre101;}else{echo "-";} ?></td>
<td><?php echo $ssfrescore102;  ?></td>
<td><?php if($ssfrescore102 != ""){echo $gradefre102;}else{echo "-";} ?></td>
<td><?php echo $ttfrescore103;  ?></td>
<td><?php if($ttfrescore103 != ""){echo $gradefre103;}else{echo "-";} ?></td>
<td><?php echo $fffrescore111;  ?></td>
<td><?php if($fffrescore111 != ""){echo $gradefre111;}else{echo "-";} ?></td>
<td><?php echo $ssfrescore112;  ?></td>
<td><?php if($ssfrescore112 != ""){echo $gradefre112;}else{echo "-";} ?></td>
<td><?php echo $ttfrescore113;  ?></td>
<td><?php if($ttfrescore113 != ""){echo $gradefre113;}else{echo "-";} ?></td>
<td><?php echo $fffrescore121;  ?></td>
<td><?php if($fffrescore121 != ""){echo $gradefre121;}else{echo "-";} ?></td>
<td><?php echo $ssfrescore122;  ?></td>
<td><?php if($ssfrescore122 != ""){echo $gradefre122;}else{echo "-";} ?></td>
<td><?php echo $ttfrescore123;  ?></td>
<td><?php if($ttfrescore123 != ""){echo $gradefre123;}else{echo "-";} ?></td>
</tr>




<tr style="height: 13px;">
<td>GOVERNMENT.</td>
<?php
include "connection.php";	
// YEAR 10 DATA FOR GOVT
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Government'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradegov101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradegov101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradegov101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradegov101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradegov101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradegov101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradegov101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradegov101 = "E8";}
								else if(($row["score"] <= 39)){$gradegov101 = "F9";}
								else {$gradegov101 = "NA";}
						$fgovscore101[] = $row['score'];						
						}
$ffgovscore101 = current($fgovscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Government'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradegov102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradegov102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradegov102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradegov102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradegov102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradegov102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradegov102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradegov102 = "E8";}
								else if(($row["score"] <= 39)){$gradegov102 = "F9";}
								else {$gradegov102 = "NA";}
						$sgovscore102[] = $row['score'];						
						}
$ssgovscore102 = current($sgovscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Government'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradegov103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradegov103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradegov103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradegov103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradegov103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradegov103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradegov103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradegov103 = "E8";}
								else if(($row["score"] <= 39)){$gradegov103 = "F9";}
								else {$gradegov103 = "NA";}
						$tgovscore103[] = $row['score'];						
						}
$ttgovscore103 = current($tgovscore103);		
}

// YEAR 11 DATA FOR GOVT
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Government'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradegov111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradegov111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradegov111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradegov111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradegov111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradegov111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradegov111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradegov111 = "E8";}
								else if(($row["score"] <= 39)){$gradegov111 = "F9";}
								else {$gradegov111 = "NA";}
						$fgovscore111[] = $row['score'];						
						}
$ffgovscore111 = current($fgovscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Government'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradegov112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradegov112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradegov112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradegov112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradegov112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradegov112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradegov112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradegov112 = "E8";}
								else if(($row["score"] <= 39)){$gradegov112 = "F9";}
								else {$gradegov112 = "NA";}
						$sgovscore112[] = $row['score'];						
						}
$ssgovscore112 = current($sgovscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Government'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradegov113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradegov113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradegov113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradegov113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradegov113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradegov113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradegov113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradegov113 = "E8";}
								else if(($row["score"] <= 39)){$gradegov113 = "F9";}
								else {$gradegov113 = "NA";}
						$tgovscore113[] = $row['score'];						
						}
$ttgovscore113 = current($tgovscore113);				
}

// YEAR 12 DATA FOR GOVT
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Government'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradegov121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradegov121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradegov121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradegov121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradegov121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradegov121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradegov121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradegov121 = "E8";}
								else if(($row["score"] <= 39)){$gradegov121 = "F9";}
								else {$gradegov121 = "NA";}
						$fgovscore121[] = $row['score'];						
						}
$ffgovscore121 = current($fgovscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Government'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradegov122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradegov122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradegov122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradegov122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradegov122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradegov122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradegov122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradegov122 = "E8";}
								else if(($row["score"] <= 39)){$gradegov122 = "F9";}
								else {$gradegov122 = "NA";}
						$sgovscore122[] = $row['score'];						
						}
$ssgovscore122 = current($sgovscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Government'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradegov123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradegov123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradegov123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradegov123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradegov123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradegov123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradegov123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradegov123 = "E8";}
								else if(($row["score"] <= 39)){$gradegov123 = "F9";}
								else {$gradegov123 = "NA";}
						$tgovscore123[] = $row['score'];						
						}
$ttgovscore123 = current($tgovscore123);			
}					
?>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td><?php echo $ffgovscore101;  ?></td>
<td><?php if($ffgovscore101 != ""){echo $gradegov101;}else{echo "-";} ?></td>
<td><?php echo $ssgovscore102;  ?></td>
<td><?php if($ssgovscore102 != ""){echo $gradegov102;}else{echo "-";} ?></td>
<td><?php echo $ttgovscore103;  ?></td>
<td><?php if($ttgovscore103 != ""){echo $gradegov103;}else{echo "-";} ?></td>
<td><?php echo $ffgovscore111;  ?></td>
<td><?php if($ffgovscore111 != ""){echo $gradegov111;}else{echo "-";} ?></td>
<td><?php echo $ssgovscore112;  ?></td>
<td><?php if($ssgovscore112 != ""){echo $gradegov112;}else{echo "-";} ?></td>
<td><?php echo $ttgovscore113;  ?></td>
<td><?php if($ttgovscore113 != ""){echo $gradegov113;}else{echo "-";} ?></td>
<td><?php echo $ffgovscore121;  ?></td>
<td><?php if($ffgovscore121 != ""){echo $gradegov121;}else{echo "-";} ?></td>
<td><?php echo $ssgovscore122;  ?></td>
<td><?php if($ssgovscore122 != ""){echo $gradegov122;}else{echo "-";} ?></td>
<td><?php echo $ttgovscore123;  ?></td>
<td><?php if($ttgovscore123 != ""){echo $gradegov123;}else{echo "-";} ?></td>
</tr>


<tr style="height: 13px;">
<td>ICT</td>
<?php
include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
//YEAR 7 DATA FOR ICT
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeict71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeict71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeict71 = "P";}
								else if(($row["score"] <= 49)){$gradeict71 = "F";}
								else {$gradeict71 = "NA";}
						$fictscore71[] = $row['score'];						
						}
$ffictscore71 = current($fictscore71);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeict72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeict72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeict72 = "P";}
								else if(($row["score"] <= 49)){$gradeict72 = "F";}
								else {$gradeict72 = "NA";}
						$sictscore72[] = $row['score'];						
						}
$ssictscore72 = current($sictscore72);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeict73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeict73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeict73 = "P";}
								else if(($row["score"] <= 49)){$gradeict73 = "F";}
								else {$gradeict73 = "NA";}
						$tictscore73[] = $row['score'];						
						}
$ttictscore73 = current($tictscore73);
}
// YEAR 8 DATA FOR ICT
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeict81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeict81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeict81 = "P";}
								else if(($row["score"] <= 49)){$gradeict81 = "F";}
								else {$gradeict81 = "NA";}
						$fictscore81[] = $row['score'];						
						}
$ffictscore81 = current($fictscore81);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeict82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeict82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeict82 = "P";}
								else if(($row["score"] <= 49)){$gradeict82 = "F";}
								else {$gradeict82 = "NA";}
						$sictscore82[] = $row['score'];						
						}
$ssictscore82 = current($sictscore82);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeict83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeict83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeict83 = "P";}
								else if(($row["score"] <= 49)){$gradeict83 = "F";}
								else {$gradeict83 = "NA";}
						$tictscore83[] = $row['score'];						
						}
$ttictscore83 = current($tictscore83);
}
// YEAR 9 DATA FOR ICT
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeict91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeict91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeict91 = "P";}
								else if(($row["score"] <= 49)){$gradeict91 = "F";}
								else {$gradeict91 = "NA";}
						$fictscore91[] = $row['score'];						
						}
$ffictscore91 = current($fictscore91);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeict92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeict92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeict92 = "P";}
								else if(($row["score"] <= 49)){$gradeict92 = "F";}
								else {$gradeict92 = "NA";}
						$sictscore92[] = $row['score'];						
						}
$ssictscore92 = current($sictscore92);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeict93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeict93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeict93 = "P";}
								else if(($row["score"] <= 49)){$gradeict93 = "F";}
								else {$gradeict93 = "NA";}
						$tictscore93[] = $row['score'];						
						}
$ttictscore93 = current($tictscore93);	
}	

// YEAR 10 DATA FOR ICT
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeict101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeict101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeict101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeict101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeict101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeict101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeict101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeict101 = "E8";}
								else if(($row["score"] <= 39)){$gradeict101 = "F9";}
								else {$gradeict101 = "NA";}
						$fictscore101[] = $row['score'];						
						}
$ffictscore101 = current($fictscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeict102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeict102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeict102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeict102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeict102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeict102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeict102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeict102 = "E8";}
								else if(($row["score"] <= 39)){$gradeict102 = "F9";}
								else {$gradeict102 = "NA";}
						$sictscore102[] = $row['score'];						
						}
$ssictscore102 = current($sictscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeict103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeict103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeict103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeict103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeict103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeict103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeict103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeict103 = "E8";}
								else if(($row["score"] <= 39)){$gradeict103 = "F9";}
								else {$gradeict103 = "NA";}
						$tictscore103[] = $row['score'];						
						}
$ttictscore103 = current($tictscore103);	
}

// YEAR 11 DATA FOR ICT
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeict111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeict111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeict111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeict111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeict111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeict111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeict111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeict111 = "E8";}
								else if(($row["score"] <= 39)){$gradeict111 = "F9";}
								else {$gradeict111 = "NA";}
						$fictscore111[] = $row['score'];						
						}
$ffictscore111 = current($fictscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$gradeict112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeict112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeict112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeict112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeict112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeict112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeict112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeict112 = "E8";}
								else if(($row["score"] <= 39)){$gradeict112 = "F9";}
								else {$gradeict112 = "NA";}
						$sictscore112[] = $row['score'];						
						}
$ssictscore112 = current($sictscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeict113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeict113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeict113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeict113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeict113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeict113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeict113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeict113 = "E8";}
								else if(($row["score"] <= 39)){$gradeict113 = "F9";}
								else {$gradeict113 = "NA";}
						$tictscore113[] = $row['score'];						
						}
$ttictscore113 = current($tictscore113);				
}

// YEAR 12 DATA FOR ICT
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeict121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeict121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeict121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeict121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeict121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeict121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeict121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeict121 = "E8";}
								else if(($row["score"] <= 39)){$gradeict121 = "F9";}
								else {$gradeict121 = "NA";}
						$fictscore121[] = $row['score'];						
						}
$ffictscore121 = current($fictscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeict122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeict122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeict122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeict122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeict122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeict122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeict122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeict122 = "E8";}
								else if(($row["score"] <= 39)){$gradeict122 = "F9";}
								else {$gradeict122 = "NA";}
						$sictscore122[] = $row['score'];						
						}
$ssictscore122 = current($sictscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeict123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeict123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeict123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeict123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeict123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeict123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeict123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeict123 = "E8";}
								else if(($row["score"] <= 39)){$gradeict123 = "F9";}
								else {$gradeict123 = "NA";}
						$tictscore123[] = $row['score'];						
						}
$ttictscore123 = current($tictscore123);		
}					
?>
<td><?php echo $ffictscore71;  ?></td>
<td><?php if($ffictscore71 != ""){echo $gradeict71;}else{echo "-";} ?></td>
<td><?php echo $ssictscore72;  ?></td>
<td><?php if($ssictscore72 != ""){echo $gradeict72;}else{echo "-";} ?></td>
<td><?php echo $ttictscore73;  ?></td>
<td><?php if($ttictscore73 != ""){echo $gradeict73;}else{echo "-";} ?></td>
<td><?php echo $ffictscore81;  ?></td>
<td><?php if($ffictscore81 != ""){echo $gradeict81;}else{echo "-";} ?></td>
<td><?php echo $ssictscore82;  ?></td>
<td><?php if($ssictscore82 != ""){echo $gradeict82;}else{echo "-";} ?></td>
<td><?php echo $ttictscore83;  ?></td>
<td><?php if($ttictscore83 != ""){echo $gradeict83;}else{echo "-";} ?></td>
<td><?php echo $ffictscore91;  ?></td>
<td><?php if($ffictscore91 != ""){echo $gradeict91;}else{echo "-";} ?></td>
<td><?php echo $ssictscore92;  ?></td>
<td><?php if($ssictscore92 != ""){echo $gradeict92;}else{echo "-";} ?></td>
<td><?php echo $ttictscore93;  ?></td>
<td><?php if($ttictscore93 != ""){echo $gradeict93;}else{echo "-";} ?></td>
<td><?php echo $ffictscore101;  ?></td>
<td><?php if($ffictscore101 != ""){echo $gradeict101;}else{echo "-";} ?></td>
<td><?php echo $ssictscore102;  ?></td>
<td><?php if($ssictscore102 != ""){echo $gradeict102;}else{echo "-";} ?></td>
<td><?php echo $ttictscore103;  ?></td>
<td><?php if($ttictscore103 != ""){echo $gradeict103;}else{echo "-";} ?></td>
<td><?php echo $ffictscore111;  ?></td>
<td><?php if($ffictscore111 != ""){echo $gradeict111;}else{echo "-";} ?></td>
<td><?php echo $ssictscore112;  ?></td>
<td><?php if($ssictscore112 != ""){echo $gradeict112;}else{echo "-";} ?></td>
<td><?php echo $ttictscore113;  ?></td>
<td><?php if($ttictscore113 != ""){echo $gradeict113;}else{echo "-";} ?></td>
<td><?php echo $ffictscore121;  ?></td>
<td><?php if($ffictscore121 != ""){echo $gradeict121;}else{echo "-";} ?></td>
<td><?php echo $ssictscore122;  ?></td>
<td><?php if($ssictscore122 != ""){echo $gradeict122;}else{echo "-";} ?></td>
<td><?php echo $ttictscore123;  ?></td>
<td><?php if($ttictscore123 != ""){echo $gradeict123;}else{echo "-";} ?></td>
</tr>




<tr style="height: 13px;">
<td>IGBO</td>
<?php
include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
//YEAR 7 DATA FOR IGBO
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeigb71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeigb71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeigb71 = "P";}
								else if(($row["score"] <= 49)){$gradeigb71 = "F";}
								else {$gradeigb71 = "NA";}
						$figbscore71[] = $row['score'];						
						}
$ffigbscore71 = current($figbscore71);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeigb72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeigb72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeigb72 = "P";}
								else if(($row["score"] <= 49)){$gradeigb72 = "F";}
								else {$gradeigb72 = "NA";}
						$sigbscore72[] = $row['score'];						
						}
$ssigbscore72 = current($sigbscore72);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeigb73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeigb73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeigb73 = "P";}
								else if(($row["score"] <= 49)){$gradeigb73 = "F";}
								else {$gradeigb73 = "NA";}
						$tigbscore73[] = $row['score'];						
						}
$ttigbscore73 = current($tigbscore73);
}
// YEAR 8 DATA FOR IGBO
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeigb81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeigb81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeigb81 = "P";}
								else if(($row["score"] <= 49)){$gradeigb81 = "F";}
								else {$gradeigb81 = "NA";}
						$figbscore81[] = $row['score'];						
						}
$ffigbscore81 = current($figbscore81);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeigb82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeigb82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeigb82 = "P";}
								else if(($row["score"] <= 49)){$gradeigb82 = "F";}
								else {$gradeigb82 = "NA";}
						$sigbscore82[] = $row['score'];						
						}
$ssigbscore82 = current($sigbscore82);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeigb83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeigb83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeigb83 = "P";}
								else if(($row["score"] <= 49)){$gradeigb83 = "F";}
								else {$gradeigb83 = "NA";}
						$tigbscore83[] = $row['score'];						
						}
$ttigbscore83 = current($tigbscore83);
}
// YEAR 9 DATA FOR IGBO
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeigb91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeigb91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeigb91 = "P";}
								else if(($row["score"] <= 49)){$gradeigb91 = "F";}
								else {$gradeigb91 = "NA";}
						$figbscore91[] = $row['score'];						
						}
$ffigbscore91 = current($figbscore91);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeigb92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeigb92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeigb92 = "P";}
								else if(($row["score"] <= 49)){$gradeigb92 = "F";}
								else {$gradeigb92 = "NA";}
						$sigbscore92[] = $row['score'];						
						}
$ssigbscore92 = current($sigbscore92);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeigb93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeigb93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeigb93 = "P";}
								else if(($row["score"] <= 49)){$gradeigb93 = "F";}
								else {$gradeigb93 = "NA";}
						$tigbscore93[] = $row['score'];						
						}
$ttigbscore93 = current($tigbscore93);
}	

// YEAR 10 DATA FOR IGBO
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeigb101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeigb101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeigb101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeigb101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeigb101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeigb101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeigb101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeigb101 = "E8";}
								else if(($row["score"] <= 39)){$gradeigb101 = "F9";}
								else {$gradeigb101 = "NA";}
						$figbscore101[] = $row['score'];						
						}
$ffigbscore101 = current($figbscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeigb102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeigb102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeigb102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeigb102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeigb102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeigb102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeigb102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeigb102 = "E8";}
								else if(($row["score"] <= 39)){$gradeigb102 = "F9";}
								else {$gradeigb102 = "NA";}
						$sigbscore102[] = $row['score'];						
						}
$ssigbscore102 = current($sigbscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeigb103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeigb103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeigb103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeigb103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeigb103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeigb103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeigb103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeigb103 = "E8";}
								else if(($row["score"] <= 39)){$gradeigb103 = "F9";}
								else {$gradeigb103 = "NA";}
						$tigbscore103[] = $row['score'];						
						}
$ttigbscore103 = current($tigbscore103);	
}

// YEAR 11 DATA FOR IGBO
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeigb111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeigb111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeigb111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeigb111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeigb111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeigb111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeigb111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeigb111 = "E8";}
								else if(($row["score"] <= 39)){$gradeigb111 = "F9";}
								else {$gradeigb111 = "NA";}
						$figbscore111[] = $row['score'];						
						}
$ffigbscore111 = current($figbscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$gradeigb112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeigb112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeigb112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeigb112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeigb112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeigb112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeigb112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeigb112 = "E8";}
								else if(($row["score"] <= 39)){$gradeigb112 = "F9";}
								else {$gradeigb112 = "NA";}
						$sigbscore112[] = $row['score'];						
						}
$ssigbscore112 = current($sigbscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeigb113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeigb113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeigb113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeigb113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeigb113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeigb113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeigb113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeigb113 = "E8";}
								else if(($row["score"] <= 39)){$gradeigb113 = "F9";}
								else {$gradeigb113 = "NA";}
						$tigbscore113[] = $row['score'];						
						}
$ttigbscore113 = current($tigbscore113);				
}

// YEAR 12 DATA FOR IGBO
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeigb121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeigb121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeigb121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeigb121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeigb121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeigb121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeigb121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeigb121 = "E8";}
								else if(($row["score"] <= 39)){$gradeigb121 = "F9";}
								else {$gradeigb121 = "NA";}
						$figbscore121[] = $row['score'];						
						}
$ffigbscore121 = current($figbscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeigb122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeigb122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeigb122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeigb122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeigb122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeigb122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeigb122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeigb122 = "E8";}
								else if(($row["score"] <= 39)){$gradeigb122 = "F9";}
								else {$gradeigb122 = "NA";}
						$sigbscore122[] = $row['score'];						
						}
$ssigbscore122 = current($sigbscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeigb123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeigb123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeigb123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeigb123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeigb123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeigb123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeigb123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeigb123 = "E8";}
								else if(($row["score"] <= 39)){$gradeigb123 = "F9";}
								else {$gradeigb123 = "NA";}
						$tigbscore123[] = $row['score'];						
						}
$ttigbscore123 = current($tigbscore123);
}					
?>
<td><?php echo $ffigbscore71;  ?></td>
<td><?php if($ffigbscore71 != ""){echo $gradeigb71;}else{echo "-";} ?></td>
<td><?php echo $ssigbscore72;  ?></td>
<td><?php if($ssigbscore72 != ""){echo $gradeigb72;}else{echo "-";} ?></td>
<td><?php echo $ttigbscore73;  ?></td>
<td><?php if($ttigbscore73 != ""){echo $gradeigb73;}else{echo "-";} ?></td>
<td><?php echo $ffigbscore81;  ?></td>
<td><?php if($ffigbscore81 != ""){echo $gradeigb81;}else{echo "-";} ?></td>
<td><?php echo $ssigbscore82;  ?></td>
<td><?php if($ssigbscore82 != ""){echo $gradeigb82;}else{echo "-";} ?></td>
<td><?php echo $ttigbscore83;  ?></td>
<td><?php if($ttigbscore83 != ""){echo $gradeigb83;}else{echo "-";} ?></td>
<td><?php echo $ffigbscore91;  ?></td>
<td><?php if($ffigbscore91 != ""){echo $gradeigb91;}else{echo "-";} ?></td>
<td><?php echo $ssigbscore92;  ?></td>
<td><?php if($ssigbscore92 != ""){echo $gradeigb92;}else{echo "-";} ?></td>
<td><?php echo $ttigbscore93;  ?></td>
<td><?php if($ttigbscore93 != ""){echo $gradeigb93;}else{echo "-";} ?></td>
<td><?php echo $ffigbscore101;  ?></td>
<td><?php if($ffigbscore101 != ""){echo $gradeigb101;}else{echo "-";} ?></td>
<td><?php echo $ssigbscore102;  ?></td>
<td><?php if($ssigbscore102 != ""){echo $gradeigb102;}else{echo "-";} ?></td>
<td><?php echo $ttigbscore103;  ?></td>
<td><?php if($ttigbscore103 != ""){echo $gradeigb103;}else{echo "-";} ?></td>
<td><?php echo $ffigbscore111;  ?></td>
<td><?php if($ffigbscore111 != ""){echo $gradeigb111;}else{echo "-";} ?></td>
<td><?php echo $ssigbscore112;  ?></td>
<td><?php if($ssigbscore112 != ""){echo $gradeigb112;}else{echo "-";} ?></td>
<td><?php echo $ttigbscore113;  ?></td>
<td><?php if($ttigbscore113 != ""){echo $gradeigb113;}else{echo "-";} ?></td>
<td><?php echo $ffigbscore121;  ?></td>
<td><?php if($ffigbscore121 != ""){echo $gradeigb121;}else{echo "-";} ?></td>
<td><?php echo $ssigbscore122;  ?></td>
<td><?php if($ssigbscore122 != ""){echo $gradeigb122;}else{echo "-";} ?></td>
<td><?php echo $ttigbscore123;  ?></td>
<td><?php if($ttigbscore123 != ""){echo $gradeigb123;}else{echo "-";} ?></td>
</tr>




<tr style="height: 13px;">
<td>LIT IN ENGLISH</td>
<?php
include "connection.php";	
// YEAR 10 DATA FOR LIT
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Lit in English'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradelit101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradelit101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradelit101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradelit101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradelit101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradelit101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradelit101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradelit101 = "E8";}
								else if(($row["score"] <= 39)){$gradelit101 = "F9";}
								else {$gradelit101 = "NA";}
						$flitscore101[] = $row['score'];						
						}
$fflitscore101 = current($flitscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Lit in English'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradelit102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradelit102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradelit102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradelit102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradelit102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradelit102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradelit102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradelit102 = "E8";}
								else if(($row["score"] <= 39)){$gradelit102 = "F9";}
								else {$gradelit102 = "NA";}
						$slitscore102[] = $row['score'];						
						}
$sslitscore102 = current($slitscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Lit in English'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradelit103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradelit103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradelit103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradelit103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradelit103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradelit103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradelit103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradelit103 = "E8";}
								else if(($row["score"] <= 39)){$gradelit103 = "F9";}
								else {$gradelit103 = "NA";}
						$tlitscore103[] = $row['score'];						
						}
$ttlitscore103 = current($tlitscore103);		
}

// YEAR 11 DATA FOR LIT
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Lit in English'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradelit111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradelit111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradelit111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradelit111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradelit111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradelit111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradelit111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradelit111 = "E8";}
								else if(($row["score"] <= 39)){$gradelit111 = "F9";}
								else {$gradelit111 = "NA";}
						$flitscore111[] = $row['score'];						
						}
$fflitscore111 = current($flitscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Lit in English'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradelit112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradelit112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradelit112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradelit112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradelit112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradelit112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradelit112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradelit112 = "E8";}
								else if(($row["score"] <= 39)){$gradelit112 = "F9";}
								else {$gradelit112 = "NA";}
						$slitscore112[] = $row['score'];						
						}
$sslitscore112 = current($slitscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Lit in English'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradelit113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradelit113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradelit113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradelit113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradelit113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradelit113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradelit113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradelit113 = "E8";}
								else if(($row["score"] <= 39)){$gradelit113 = "F9";}
								else {$gradelit113 = "NA";}
						$tlitscore113[] = $row['score'];						
						}
$ttlitscore113 = current($tlitscore113);				
}

// YEAR 12 DATA FOR LIT
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Lit in English'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradelit121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradelit121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradelit121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradelit121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradelit121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradelit121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradelit121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradelit121 = "E8";}
								else if(($row["score"] <= 39)){$gradelit121 = "F9";}
								else {$gradelit121 = "NA";}
						$flitscore121[] = $row['score'];						
						}
$fflitscore121 = current($flitscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Lit in English'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradelit122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradelit122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradelit122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradelit122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradelit122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradelit122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradelit122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradelit122 = "E8";}
								else if(($row["score"] <= 39)){$gradelit122 = "F9";}
								else {$gradelit122 = "NA";}
						$slitscore122[] = $row['score'];						
						}
$sslitscore122 = current($slitscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Lit in English'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradelit123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradelit123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradelit123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradelit123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradelit123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradelit123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradelit123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradelit123 = "E8";}
								else if(($row["score"] <= 39)){$gradelit123 = "F9";}
								else {$gradelit123 = "NA";}
						$tlitscore123[] = $row['score'];						
						}
$ttlitscore123 = current($tlitscore123);			
}					
?>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td><?php echo $fflitscore101;  ?></td>
<td><?php if($fflitscore101 != ""){echo $gradelit101;}else{echo "-";} ?></td>
<td><?php echo $sslitscore102;  ?></td>
<td><?php if($sslitscore102 != ""){echo $gradelit102;}else{echo "-";} ?></td>
<td><?php echo $ttlitscore103;  ?></td>
<td><?php if($ttlitscore103 != ""){echo $gradelit103;}else{echo "-";} ?></td>
<td><?php echo $fflitscore111;  ?></td>
<td><?php if($fflitscore111 != ""){echo $gradelit111;}else{echo "-";} ?></td>
<td><?php echo $sslitscore112;  ?></td>
<td><?php if($sslitscore112 != ""){echo $gradelit112;}else{echo "-";} ?></td>
<td><?php echo $ttlitscore113;  ?></td>
<td><?php if($ttlitscore113 != ""){echo $gradelit113;}else{echo "-";} ?></td>
<td><?php echo $fflitscore121;  ?></td>
<td><?php if($fflitscore121 != ""){echo $gradelit121;}else{echo "-";} ?></td>
<td><?php echo $sslitscore122;  ?></td>
<td><?php if($sslitscore122 != ""){echo $gradelit122;}else{echo "-";} ?></td>
<td><?php echo $ttlitscore123;  ?></td>
<td><?php if($ttlitscore123 != ""){echo $gradelit123;}else{echo "-";} ?></td>
</tr>


<tr style="height: 13px;">
<td>MARKETING</td>
<?php
include "connection.php";
// YEAR 10 DATA FOR MARKETING
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Marketing'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$grademar101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademar101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademar101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademar101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademar101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademar101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademar101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademar101 = "E8";}
								else if(($row["score"] <= 39)){$grademar101 = "F9";}
								else {$grademar101 = "NA";}
						$fmarscore101[] = $row['score'];						
						}
$ffmarscore101 = current($fmarscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Marketing'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$grademar102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademar102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademar102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademar102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademar102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademar102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademar102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademar102 = "E8";}
								else if(($row["score"] <= 39)){$grademar102 = "F9";}
								else {$grademar102 = "NA";}
						$smarscore102[] = $row['score'];						
						}
$ssmarscore102 = current($smarscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Marketing'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$grademar103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademar103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademar103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademar103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademar103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademar103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademar103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademar103 = "E8";}
								else if(($row["score"] <= 39)){$grademar103 = "F9";}
								else {$grademar103 = "NA";}
						$tmarscore103[] = $row['score'];						
						}
$ttmarscore103 = current($tmarscore103);	
}

// YEAR 11 DATA FOR MARKETING
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Marketing'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$grademar111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademar111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademar111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademar111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademar111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademar111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademar111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademar111 = "E8";}
								else if(($row["score"] <= 39)){$grademar111 = "F9";}
								else {$grademar111 = "NA";}
						$fmarscore111[] = $row['score'];						
						}
$ffmarscore111 = current($fmarscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Marketing'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$grademar112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademar112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademar112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademar112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademar112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademar112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademar112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademar112 = "E8";}
								else if(($row["score"] <= 39)){$grademar112 = "F9";}
								else {$grademar112 = "NA";}
						$smarscore112[] = $row['score'];						
						}
$ssmarscore112 = current($smarscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Marketing'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$grademar113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademar113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademar113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademar113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademar113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademar113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademar113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademar113 = "E8";}
								else if(($row["score"] <= 39)){$grademar113 = "F9";}
								else {$grademar113 = "NA";}
						$tmarscore113[] = $row['score'];						
						}
$ttmarscore113 = current($tmarscore113);			
}

// YEAR 12 DATA FOR MUSIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Marketing'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$grademar121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademar121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademar121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademar121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademar121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademar121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademar121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademar121 = "E8";}
								else if(($row["score"] <= 39)){$grademar121 = "F9";}
								else {$grademar121 = "NA";}
						$fmarscore121[] = $row['score'];						
						}
$ffmarscore121 = current($fmarscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Marketing'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$grademar122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademar122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademar122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademar122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademar122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademar122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademar122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademar122 = "E8";}
								else if(($row["score"] <= 39)){$grademar122 = "F9";}
								else {$grademar122 = "NA";}
						$smarscore122[] = $row['score'];						
						}
$ssmarscore122 = current($smarscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Marketing'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$grademar123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademar123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademar123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademar123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademar123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademar123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademar123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademar123 = "E8";}
								else if(($row["score"] <= 39)){$grademar123 = "F9";}
								else {$grademar123 = "NA";}
						$tmarscore123[] = $row['score'];						
						}
$ttmarscore123 = current($tmarscore123);
}					
?>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td><?php echo $ffmarscore101;  ?></td>
<td><?php if($ffmarscore101 != ""){echo $grademar101;}else{echo "-";} ?></td>
<td><?php echo $ssmarscore102;  ?></td>
<td><?php if($ssmarscore102 != ""){echo $grademar102;}else{echo "-";} ?></td>
<td><?php echo $ttmarscore103;  ?></td>
<td><?php if($ttmarscore103 != ""){echo $grademar103;}else{echo "-";} ?></td>
<td><?php echo $ffmarscore111;  ?></td>
<td><?php if($ffmarscore111 != ""){echo $grademar111;}else{echo "-";} ?></td>
<td><?php echo $ssmarscore112;  ?></td>
<td><?php if($ssmarscore112 != ""){echo $grademar112;}else{echo "-";} ?></td>
<td><?php echo $ttmarscore113;  ?></td>
<td><?php if($ttmarscore113 != ""){echo $grademar113;}else{echo "-";} ?></td>
<td><?php echo $ffmarscore121;  ?></td>
<td><?php if($ffmarscore121 != ""){echo $grademar121;}else{echo "-";} ?></td>
<td><?php echo $ssmarscore122;  ?></td>
<td><?php if($ssmarscore122 != ""){echo $grademar122;}else{echo "-";} ?></td>
<td><?php echo $ttmarscore123;  ?></td>
<td><?php if($ttmarscore123 != ""){echo $grademar123;}else{echo "-";} ?></td>
</tr>




<tr style="height: 13px;">
<td>MUSIC</td>
<?php
include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
//YEAR 7 DATA FOR MUSIC
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='Music'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademus71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademus71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademus71 = "P";}
								else if(($row["score"] <= 49)){$grademus71 = "F";}
								else {$grademus71 = "NA";}
						$fmusscore71[] = $row['score'];						
						}
$ffmusscore71 = current($fmusscore71);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='Music'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademus72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademus72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademus72 = "P";}
								else if(($row["score"] <= 49)){$grademus72 = "F";}
								else {$grademus72 = "NA";}
						$smusscore72[] = $row['score'];						
						}
$ssmusscore72 = current($smusscore72);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='Music'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademus73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademus73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademus73 = "P";}
								else if(($row["score"] <= 49)){$grademus73 = "F";}
								else {$grademus73 = "NA";}
						$tmusscore73[] = $row['score'];						
						}
$ttmusscore73 = current($tmusscore73);
}
// YEAR 8 DATA FOR MUSIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Music'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademus81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademus81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademus81 = "P";}
								else if(($row["score"] <= 49)){$grademus81 = "F";}
								else {$grademus81 = "NA";}
						$fmusscore81[] = $row['score'];						
						}
$ffmusscore81 = current($fmusscore81);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Music'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademus82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademus82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademus82 = "P";}
								else if(($row["score"] <= 49)){$grademus82 = "F";}
								else {$grademus82 = "NA";}
						$smusscore82[] = $row['score'];						
						}
$ssmusscore82 = current($smusscore82);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Music'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademus83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademus83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademus83 = "P";}
								else if(($row["score"] <= 49)){$grademus83 = "F";}
								else {$grademus83 = "NA";}
						$tmusscore83[] = $row['score'];						
						}
$ttmusscore83 = current($tmusscore83);
}
// YEAR 9 DATA FOR MUSIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Music'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademus91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademus91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademus91 = "P";}
								else if(($row["score"] <= 49)){$grademus91 = "F";}
								else {$grademus91 = "NA";}
						$fmusscore91[] = $row['score'];						
						}
$ffmusscore91 = current($fmusscore91);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Music'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademus92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademus92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademus92 = "P";}
								else if(($row["score"] <= 49)){$grademus92 = "F";}
								else {$grademus92 = "NA";}
						$smusscore92[] = $row['score'];						
						}
$ssmusscore92 = current($smusscore92);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Music'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademus93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademus93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademus93 = "P";}
								else if(($row["score"] <= 49)){$grademus93 = "F";}
								else {$grademus93 = "NA";}
						$tmusscore93[] = $row['score'];						
						}
$ttmusscore93 = current($tmusscore93);
}	

// YEAR 10 DATA FOR MUSIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Music'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$grademus101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademus101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademus101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademus101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademus101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademus101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademus101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademus101 = "E8";}
								else if(($row["score"] <= 39)){$grademus101 = "F9";}
								else {$grademus101 = "NA";}
						$fmusscore101[] = $row['score'];						
						}
$ffmusscore101 = current($fmusscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Music'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$grademus102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademus102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademus102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademus102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademus102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademus102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademus102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademus102 = "E8";}
								else if(($row["score"] <= 39)){$grademus102 = "F9";}
								else {$grademus102 = "NA";}
						$smusscore102[] = $row['score'];						
						}
$ssmusscore102 = current($smusscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Music'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$grademus103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademus103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademus103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademus103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademus103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademus103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademus103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademus103 = "E8";}
								else if(($row["score"] <= 39)){$grademus103 = "F9";}
								else {$grademus103 = "NA";}
						$tmusscore103[] = $row['score'];						
						}
$ttmusscore103 = current($tmusscore103);	
}

// YEAR 11 DATA FOR MUSIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Music'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$grademus111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademus111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademus111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademus111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademus111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademus111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademus111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademus111 = "E8";}
								else if(($row["score"] <= 39)){$grademus111 = "F9";}
								else {$grademus111 = "NA";}
						$fmusscore111[] = $row['score'];						
						}
$ffmusscore111 = current($fmusscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Music'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$grademus112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademus112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademus112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademus112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademus112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademus112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademus112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademus112 = "E8";}
								else if(($row["score"] <= 39)){$grademus112 = "F9";}
								else {$grademus112 = "NA";}
						$smusscore112[] = $row['score'];						
						}
$ssmusscore112 = current($smusscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Music'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$grademus113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademus113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademus113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademus113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademus113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademus113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademus113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademus113 = "E8";}
								else if(($row["score"] <= 39)){$grademus113 = "F9";}
								else {$grademus113 = "NA";}
						$tmusscore113[] = $row['score'];						
						}
$ttmusscore113 = current($tmusscore113);			
}

// YEAR 12 DATA FOR MUSIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Music'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$grademus121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademus121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademus121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademus121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademus121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademus121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademus121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademus121 = "E8";}
								else if(($row["score"] <= 39)){$grademus121 = "F9";}
								else {$grademus121 = "NA";}
						$fmusscore121[] = $row['score'];						
						}
$ffmusscore121 = current($fmusscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Music'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$grademus122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademus122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademus122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademus122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademus122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademus122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademus122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademus122 = "E8";}
								else if(($row["score"] <= 39)){$grademus122 = "F9";}
								else {$grademus122 = "NA";}
						$smusscore122[] = $row['score'];						
						}
$ssmusscore122 = current($smusscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Music'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$grademus123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademus123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademus123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademus123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademus123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademus123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademus123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademus123 = "E8";}
								else if(($row["score"] <= 39)){$grademus123 = "F9";}
								else {$grademus123 = "NA";}
						$tmusscore123[] = $row['score'];						
						}
$ttmusscore123 = current($tmusscore123);
}					
?>
<td><?php echo $ffmusscore71;  ?></td>
<td><?php if($ffmusscore71 != ""){echo $grademus71;}else{echo "-";} ?></td>
<td><?php echo $ssmusscore72;  ?></td>
<td><?php if($ssmusscore72 != ""){echo $grademus72;}else{echo "-";} ?></td>
<td><?php echo $ttmusscore73;  ?></td>
<td><?php if($ttmusscore73 != ""){echo $grademus73;}else{echo "-";} ?></td>
<td><?php echo $ffmusscore81;  ?></td>
<td><?php if($ffmusscore81 != ""){echo $grademus81;}else{echo "-";} ?></td>
<td><?php echo $ssmusscore82;  ?></td>
<td><?php if($ssmusscore82 != ""){echo $grademus82;}else{echo "-";} ?></td>
<td><?php echo $ttmusscore83;  ?></td>
<td><?php if($ttmusscore83 != ""){echo $grademus83;}else{echo "-";} ?></td>
<td><?php echo $ffmusscore91;  ?></td>
<td><?php if($ffmusscore91 != ""){echo $grademus91;}else{echo "-";} ?></td>
<td><?php echo $ssmusscore92;  ?></td>
<td><?php if($ssmusscore92 != ""){echo $grademus92;}else{echo "-";} ?></td>
<td><?php echo $ttmusscore93;  ?></td>
<td><?php if($ttmusscore93 != ""){echo $grademus93;}else{echo "-";} ?></td>
<td><?php echo $ffmusscore101;  ?></td>
<td><?php if($ffmusscore101 != ""){echo $grademus101;}else{echo "-";} ?></td>
<td><?php echo $ssmusscore102;  ?></td>
<td><?php if($ssmusscore102 != ""){echo $grademus102;}else{echo "-";} ?></td>
<td><?php echo $ttmusscore103;  ?></td>
<td><?php if($ttmusscore103 != ""){echo $grademus103;}else{echo "-";} ?></td>
<td><?php echo $ffmusscore111;  ?></td>
<td><?php if($ffmusscore111 != ""){echo $grademus111;}else{echo "-";} ?></td>
<td><?php echo $ssmusscore112;  ?></td>
<td><?php if($ssmusscore112 != ""){echo $grademus112;}else{echo "-";} ?></td>
<td><?php echo $ttmusscore113;  ?></td>
<td><?php if($ttmusscore113 != ""){echo $grademus113;}else{echo "-";} ?></td>
<td><?php echo $ffmusscore121;  ?></td>
<td><?php if($ffmusscore121 != ""){echo $grademus121;}else{echo "-";} ?></td>
<td><?php echo $ssmusscore122;  ?></td>
<td><?php if($ssmusscore122 != ""){echo $grademus122;}else{echo "-";} ?></td>
<td><?php echo $ttmusscore123;  ?></td>
<td><?php if($ttmusscore123 != ""){echo $grademus123;}else{echo "-";} ?></td>
</tr>





<tr style="height: 13px;">
<td>PHE</td>
<?php
include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
//YEAR 7 DATA FOR PHE
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='PHE'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradephe71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradephe71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradephe71 = "P";}
								else if(($row["score"] <= 49)){$gradephe71 = "F";}
								else {$gradephe71 = "NA";}
						$fphescore71[] = $row['score'];						
						}
$ffphescore71 = current($fphescore71);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='PHE'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradephe72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradephe72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradephe72 = "P";}
								else if(($row["score"] <= 49)){$gradephe72 = "F";}
								else {$gradephe72 = "NA";}
						$sphescore72[] = $row['score'];						
						}
$ssphescore72 = current($sphescore72);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='PHE'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradephe73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradephe73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradephe73 = "P";}
								else if(($row["score"] <= 49)){$gradephe73 = "F";}
								else {$gradephe73 = "NA";}
						$tphescore73[] = $row['score'];						
						}
$ttphescore73 = current($tphescore73);
}
// YEAR 8 DATA FOR PHE
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='PHE'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradephe81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradephe81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradephe81 = "P";}
								else if(($row["score"] <= 49)){$gradephe81 = "F";}
								else {$gradephe81 = "NA";}
						$fphescore81[] = $row['score'];						
						}
$ffphescore81 = current($fphescore81);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='PHE'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradephe82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradephe82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradephe82 = "P";}
								else if(($row["score"] <= 49)){$gradephe82 = "F";}
								else {$gradephe82 = "NA";}
						$sphescore82[] = $row['score'];						
						}
$ssphescore82 = current($sphescore82);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='PHE'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradephe83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradephe83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradephe83 = "P";}
								else if(($row["score"] <= 49)){$gradephe83 = "F";}
								else {$gradephe83 = "NA";}
						$tphescore83[] = $row['score'];						
						}
$ttphescore83 = current($tphescore83);
}
// YEAR 9 DATA FOR PHE
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='PHE'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradephe91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradephe91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradephe91 = "P";}
								else if(($row["score"] <= 49)){$gradephe91 = "F";}
								else {$gradephe91 = "NA";}
						$fphescore91[] = $row['score'];						
						}
$ffphescore91 = current($fphescore91);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='PHE'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradephe92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradephe92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradephe92 = "P";}
								else if(($row["score"] <= 49)){$gradephe92 = "F";}
								else {$gradephe92 = "NA";}
						$sphescore92[] = $row['score'];						
						}
$ssphescore92 = current($sphescore92);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='PHE'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradephe93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradephe93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradephe93 = "P";}
								else if(($row["score"] <= 49)){$gradephe93 = "F";}
								else {$gradephe93 = "NA";}
						$tphescore93[] = $row['score'];						
						}
$ttphescore93 = current($tphescore93);
}	

// YEAR 10 DATA FOR PHE
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='PHE'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradephe101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradephe101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradephe101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradephe101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradephe101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradephe101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradephe101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradephe101 = "E8";}
								else if(($row["score"] <= 39)){$gradephe101 = "F9";}
								else {$gradephe101 = "NA";}
						$fphescore101[] = $row['score'];						
						}
$ffphescore101 = current($fphescore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='PHE'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradephe102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradephe102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradephe102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradephe102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradephe102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradephe102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradephe102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradephe102 = "E8";}
								else if(($row["score"] <= 39)){$gradephe102 = "F9";}
								else {$gradephe102 = "NA";}
						$sphescore102[] = $row['score'];						
						}
$ssphescore102 = current($sphescore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='PHE'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradephe103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradephe103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradephe103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradephe103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradephe103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradephe103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradephe103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradephe103 = "E8";}
								else if(($row["score"] <= 39)){$gradephe103 = "F9";}
								else {$gradephe103 = "NA";}
						$tphescore103[] = $row['score'];						
						}
$ttphescore103 = current($tphescore103);
}

// YEAR 11 DATA FOR PHE
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='PHE'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradephe111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradephe111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradephe111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradephe111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradephe111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradephe111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradephe111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradephe111 = "E8";}
								else if(($row["score"] <= 39)){$gradephe111 = "F9";}
								else {$gradephe111 = "NA";}
						$fphescore111[] = $row['score'];						
						}
$ffphescore111 = current($fphescore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='PHE'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradephe112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradephe112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradephe112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradephe112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradephe112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradephe112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradephe112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradephe112 = "E8";}
								else if(($row["score"] <= 39)){$gradephe112 = "F9";}
								else {$gradephe112 = "NA";}
						$sphescore112[] = $row['score'];						
						}
$ssphescore112 = current($sphescore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='PHE'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$gradephe113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradephe113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradephe113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradephe113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradephe113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradephe113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradephe113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradephe113 = "E8";}
								else if(($row["score"] <= 39)){$gradephe113 = "F9";}
								else {$gradephe113 = "NA";}
						$tphescore113[] = $row['score'];						
						}
$ttphescore113 = current($tphescore113);			
}

// YEAR 12 DATA FOR PHE
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='PHE'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradephe121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradephe121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradephe121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradephe121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradephe121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradephe121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradephe121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradephe121 = "E8";}
								else if(($row["score"] <= 39)){$gradephe121 = "F9";}
								else {$gradephe121 = "NA";}
						$fphescore121[] = $row['score'];						
						}
$ffphescore121 = current($fphescore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='PHE'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradephe122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradephe122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradephe122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradephe122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradephe122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradephe122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradephe122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradephe122 = "E8";}
								else if(($row["score"] <= 39)){$gradephe122 = "F9";}
								else {$gradephe122 = "NA";}
						$sphescore122[] = $row['score'];						
						}
$ssphescore122 = current($sphescore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='PHE'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradephe123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradephe123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradephe123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradephe123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradephe123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradephe123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradephe123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradephe123 = "E8";}
								else if(($row["score"] <= 39)){$gradephe123 = "F9";}
								else {$gradephe123 = "NA";}
						$tphescore123[] = $row['score'];						
						}
$ttphescore123 = current($tphescore123);
}					
?>
<td><?php echo $ffphescore71;  ?></td>
<td><?php if($ffphescore71 != ""){echo $gradephe71;}else{echo "-";} ?></td>
<td><?php echo $ssphescore72;  ?></td>
<td><?php if($ssphescore72 != ""){echo $gradephe72;}else{echo "-";} ?></td>
<td><?php echo $ttphescore73;  ?></td>
<td><?php if($ttphescore73 != ""){echo $gradephe73;}else{echo "-";} ?></td>
<td><?php echo $ffphescore81;  ?></td>
<td><?php if($ffphescore81 != ""){echo $gradephe81;}else{echo "-";} ?></td>
<td><?php echo $ssphescore82;  ?></td>
<td><?php if($ssphescore82 != ""){echo $gradephe82;}else{echo "-";} ?></td>
<td><?php echo $ttphescore83;  ?></td>
<td><?php if($ttphescore83 != ""){echo $gradephe83;}else{echo "-";} ?></td>
<td><?php echo $ffphescore91;  ?></td>
<td><?php if($ffphescore91 != ""){echo $gradephe91;}else{echo "-";} ?></td>
<td><?php echo $ssphescore92;  ?></td>
<td><?php if($ssphescore92 != ""){echo $gradephe92;}else{echo "-";} ?></td>
<td><?php echo $ttphescore93;  ?></td>
<td><?php if($ttphescore93 != ""){echo $gradephe93;}else{echo "-";} ?></td>
<td><?php echo $ffphescore101;  ?></td>
<td><?php if($ffphescore101 != ""){echo $gradephe101;}else{echo "-";} ?></td>
<td><?php echo $ssphescore102;  ?></td>
<td><?php if($ssphescore102 != ""){echo $gradephe102;}else{echo "-";} ?></td>
<td><?php echo $ttphescore103;  ?></td>
<td><?php if($ttphescore103 != ""){echo $gradephe103;}else{echo "-";} ?></td>
<td><?php echo $ffphescore111;  ?></td>
<td><?php if($ffphescore111 != ""){echo $gradephe111;}else{echo "-";} ?></td>
<td><?php echo $ssphescore112;  ?></td>
<td><?php if($ssphescore112 != ""){echo $gradephe112;}else{echo "-";} ?></td>
<td><?php echo $ttphescore113;  ?></td>
<td><?php if($ttphescore113 != ""){echo $gradephe113;}else{echo "-";} ?></td>
<td><?php echo $ffphescore121;  ?></td>
<td><?php if($ffphescore121 != ""){echo $gradephe121;}else{echo "-";} ?></td>
<td><?php echo $ssphescore122;  ?></td>
<td><?php if($ssphescore122 != ""){echo $gradephe122;}else{echo "-";} ?></td>
<td><?php echo $ttphescore123;  ?></td>
<td><?php if($ttphescore123 != ""){echo $gradephe123;}else{echo "-";} ?></td>
</tr>



<tr style="height: 13px;">
<td>PHYSICS</td>
<?php
include "connection.php";	
// YEAR 10 DATA FOR PHYSICS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Physics'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradephy101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradephy101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradephy101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradephy101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradephy101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradephy101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradephy101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradephy101 = "E8";}
								else if(($row["score"] <= 39)){$gradephy101 = "F9";}
								else {$gradephy101 = "NA";}
						$fphyscore101[] = $row['score'];						
						}
$ffphyscore101 = current($fphyscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Physics'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradephy102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradephy102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradephy102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradephy102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradephy102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradephy102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradephy102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradephy102 = "E8";}
								else if(($row["score"] <= 39)){$gradephy102 = "F9";}
								else {$gradephy102 = "NA";}
						$sphyscore102[] = $row['score'];						
						}
$ssphyscore102 = current($sphyscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Physics'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradephy103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradephy103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradephy103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradephy103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradephy103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradephy103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradephy103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradephy103 = "E8";}
								else if(($row["score"] <= 39)){$gradephy103 = "F9";}
								else {$gradephy103 = "NA";}
						$tphyscore103[] = $row['score'];						
						}
$ttphyscore103 = current($tphyscore103);		
}

// YEAR 11 DATA FOR PHYSICS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Physics'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradephy111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradephy111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradephy111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradephy111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradephy111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradephy111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradephy111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradephy111 = "E8";}
								else if(($row["score"] <= 39)){$gradephy111 = "F9";}
								else {$gradephy111 = "NA";}
						$fphyscore111[] = $row['score'];						
						}
$ffphyscore111 = current($fphyscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Physics'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradephy112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradephy112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradephy112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradephy112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradephy112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradephy112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradephy112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradephy112 = "E8";}
								else if(($row["score"] <= 39)){$gradephy112 = "F9";}
								else {$gradephy112 = "NA";}
						$sphyscore112[] = $row['score'];						
						}
$ssphyscore112 = current($sphyscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Physics'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradephy113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradephy113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradephy113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradephy113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradephy113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradephy113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradephy113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradephy113 = "E8";}
								else if(($row["score"] <= 39)){$gradephy113 = "F9";}
								else {$gradephy113 = "NA";}
						$tphyscore113[] = $row['score'];						
						}
$ttphyscore113 = current($tphyscore113);				
}

// YEAR 12 DATA FOR PHYSICS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Physics'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradephy121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradephy121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradephy121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradephy121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradephy121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradephy121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradephy121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradephy121 = "E8";}
								else if(($row["score"] <= 39)){$gradephy121 = "F9";}
								else {$gradephy121 = "NA";}
						$fphyscore121[] = $row['score'];						
						}
$ffphyscore121 = current($fphyscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Physics'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradephy122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradephy122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradephy122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradephy122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradephy122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradephy122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradephy122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradephy122 = "E8";}
								else if(($row["score"] <= 39)){$gradephy122 = "F9";}
								else {$gradephy122 = "NA";}
						$sphyscore122[] = $row['score'];						
						}
$ssphyscore122 = current($sphyscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Physics'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradephy123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradephy123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradephy123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradephy123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradephy123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradephy123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradephy123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradephy123 = "E8";}
								else if(($row["score"] <= 39)){$gradephy123 = "F9";}
								else {$gradephy123 = "NA";}
						$tphyscore123[] = $row['score'];						
						}
$ttphyscore123 = current($tphyscore123);		
}					
?>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td><?php echo $ffphyscore101;  ?></td>
<td><?php if($ffphyscore101 != ""){echo $gradephy101;}else{echo "-";} ?></td>
<td><?php echo $ssphyscore102;  ?></td>
<td><?php if($ssphyscore102 != ""){echo $gradephy102;}else{echo "-";} ?></td>
<td><?php echo $ttphyscore103;  ?></td>
<td><?php if($ttphyscore103 != ""){echo $gradephy103;}else{echo "-";} ?></td>
<td><?php echo $ffphyscore111;  ?></td>
<td><?php if($ffphyscore111 != ""){echo $gradephy111;}else{echo "-";} ?></td>
<td><?php echo $ssphyscore112;  ?></td>
<td><?php if($ssphyscore112 != ""){echo $gradephy112;}else{echo "-";} ?></td>
<td><?php echo $ttphyscore113;  ?></td>
<td><?php if($ttphyscore113 != ""){echo $gradephy113;}else{echo "-";} ?></td>
<td><?php echo $ffphyscore121;  ?></td>
<td><?php if($ffphyscore121 != ""){echo $gradephy121;}else{echo "-";} ?></td>
<td><?php echo $ssphyscore122;  ?></td>
<td><?php if($ssphyscore122 != ""){echo $gradephy122;}else{echo "-";} ?></td>
<td><?php echo $ttphyscore123;  ?></td>
<td><?php if($ttphyscore123 != ""){echo $gradephy123;}else{echo "-";} ?></td>
</tr>



<tr style="height: 13px;">
<td>SOCIOLOGY</td>
<?php
include "connection.php";	
// YEAR 10 DATA FOR SOCIOLOGY
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Sociology'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradesoci101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradesoci101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradesoci101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradesoci101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradesoci101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradesoci101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradesoci101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradesoci101 = "E8";}
								else if(($row["score"] <= 39)){$gradesoci101 = "F9";}
								else {$gradesoci101 = "NA";}
						$fsociscore101[] = $row['score'];						
						}
$ffsociscore101 = current($fsociscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Sociology'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradesoci102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradesoci102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradesoci102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradesoci102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradesoci102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradesoci102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradesoci102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradesoci102 = "E8";}
								else if(($row["score"] <= 39)){$gradesoci102 = "F9";}
								else {$gradesoci102 = "NA";}
						$ssociscore102[] = $row['score'];						
						}
$sssociscore102 = current($ssociscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Sociology'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradesoci103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradesoci103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradesoci103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradesoci103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradesoci103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradesoci103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradesoci103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradesoci103 = "E8";}
								else if(($row["score"] <= 39)){$gradesoci103 = "F9";}
								else {$gradesoci103 = "NA";}
						$tsociscore103[] = $row['score'];						
						}
$ttsociscore103 = current($tsociscore103);	
}

// YEAR 11 DATA FOR SOCIOLOGY
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Sociology'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradesoci111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradesoci111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeaoci111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradesoci111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradesoci111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradesoci111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradesoci111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradesoci111 = "E8";}
								else if(($row["score"] <= 39)){$gradesoci111 = "F9";}
								else {$gradesoci111 = "NA";}
						$fsociscore111[] = $row['score'];						
						}
$ffsociscore111 = current($fsociscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Sociology'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradesoci112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradesoci112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeaoci112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradesoci112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradesoci112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradesoci112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradesoci112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradesoci112 = "E8";}
								else if(($row["score"] <= 39)){$gradesoci112 = "F9";}
								else {$gradesoci112 = "NA";}
						$ssociscore112[] = $row['score'];						
						}
$sssociscore112 = current($ssociscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Sociology'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradesoci113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradesoci113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeaoci113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradesoci113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradesoci113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradesoci113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradesoci113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradesoci113 = "E8";}
								else if(($row["score"] <= 39)){$gradesoci113 = "F9";}
								else {$gradesoci113 = "NA";}
						$tsociscore113[] = $row['score'];						
						}
$ttsociscore113 = current($tsociscore113);				
}

// YEAR 12 DATA FOR SOCIOLOGY
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Sociology'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradesoci121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradesoci121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeaoci121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradesoci121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradesoci121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradesoci121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradesoci121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradesoci121 = "E8";}
								else if(($row["score"] <= 39)){$gradesoci121 = "F9";}
								else {$gradesoci121 = "NA";}
						$fsociscore121[] = $row['score'];						
						}
$ffsociscore121 = current($fsociscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Sociology'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradesoci122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradesoci122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeaoci122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradesoci122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradesoci122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradesoci122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradesoci122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradesoci122 = "E8";}
								else if(($row["score"] <= 39)){$gradesoci122 = "F9";}
								else {$gradesoci122 = "NA";}
						$ssociscore122[] = $row['score'];						
						}
		$sssociscore122 = current($ssociscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Sociology'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradesoci123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradesoci123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradesoci123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradesoci123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradesoci123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradesoci123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradesoci123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradesoci123 = "E8";}
								else if(($row["score"] <= 39)){$gradesoci123 = "F9";}
								else {$gradesoci123 = "NA";}
						$tsociscore123[] = $row['score'];						
						}
$ttsociscore123 = current($tsociscore123);		
}					
?>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td><?php echo $ffsociscore101;  ?></td>
<td><?php if($ffsociscore101 != ""){echo $gradesoci101;}else{echo "-";} ?></td>
<td><?php echo $sssociscore102;  ?></td>
<td><?php if($sssociscore102 != ""){echo $gradesoci102;}else{echo "-";} ?></td>
<td><?php echo $ttsociscore103;  ?></td>
<td><?php if($ttsociscore103 != ""){echo $gradesoci103;}else{echo "-";} ?></td>
<td><?php echo $ffsociscore111;  ?></td>
<td><?php if($ffsociscore111 != ""){echo $gradesoci111;}else{echo "-";} ?></td>
<td><?php echo $sssociscore112;  ?></td>
<td><?php if($sssociscore112 != ""){echo $gradesoci112;}else{echo "-";} ?></td>
<td><?php echo $ttsociscore113;  ?></td>
<td><?php if($ttsociscore113 != ""){echo $gradesoci113;}else{echo "-";} ?></td>
<td><?php echo $ffsociscore121;  ?></td>
<td><?php if($ffsociscore121 != ""){echo $gradesoci121;}else{echo "-";} ?></td>
<td><?php echo $sssociscore122;  ?></td>
<td><?php if($sssociscore122 != ""){echo $gradesoci122;}else{echo "-";} ?></td>
<td><?php echo $ttsociscore123;  ?></td>
<td><?php if($ttsociscore123 != ""){echo $gradesoci123;}else{echo "-";} ?></td>
</tr>





<tr style="height: 13px;">
<td>TECHNICAL DRAWING</td>
<?php
include "connection.php";	
// YEAR 10 DATA FOR TD
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='TD'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradetd101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradetd101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradetd101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradetd101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradetd101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradetd101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradetd101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradetd101 = "E8";}
								else if(($row["score"] <= 39)){$gradetd101 = "F9";}
								else {$gradetd101 = "NA";}
						$ftdscore101[] = $row['score'];						
						}
$fftdscore101 = current($ftdscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='TD'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradetd102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradetd102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradetd102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradetd102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradetd102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradetd102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradetd102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradetd102 = "E8";}
								else if(($row["score"] <= 39)){$gradetd102 = "F9";}
								else {$gradetd102 = "NA";}
						$stdscore102[] = $row['score'];						
						}
$sstdscore102 = current($stdscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='TD'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradetd103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradetd103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradetd103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradetd103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradetd103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradetd103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradetd103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradetd103 = "E8";}
								else if(($row["score"] <= 39)){$gradetd103 = "F9";}
								else {$gradetd103 = "NA";}
						$ttdscore103[] = $row['score'];						
						}
$tttdscore103 = current($ttdscore103);
}

// YEAR 11 DATA FOR TD
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='TD'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradetd111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradetd111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradetd111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradetd111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradetd111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradetd111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradetd111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradetd111 = "E8";}
								else if(($row["score"] <= 39)){$gradetd111 = "F9";}
								else {$gradetd111 = "NA";}
						$ftdscore111[] = $row['score'];						
						}
$fftdscore111 = current($ftdscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='TD'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradetd112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradetd112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradetd112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradetd112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradetd112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradetd112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradetd112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradetd112 = "E8";}
								else if(($row["score"] <= 39)){$gradetd112 = "F9";}
								else {$gradetd112 = "NA";}
						$stdscore112[] = $row['score'];						
						}
$sstdscore112 = current($stdscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='TD'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradetd113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradetd113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradetd113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradetd113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradetd113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradetd113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradetd113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradetd113 = "E8";}
								else if(($row["score"] <= 39)){$gradetd113 = "F9";}
								else {$gradetd113 = "NA";}
						$ttdscore113[] = $row['score'];						
						}
$tttdscore113 = current($ttdscore113);			
}

// YEAR 12 DATA FOR TD
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='TD'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradetd121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradetd121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradetd121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradetd121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradetd121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradetd121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradetd121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradetd121 = "E8";}
								else if(($row["score"] <= 39)){$gradetd121 = "F9";}
								else {$gradetd121 = "NA";}
						$ftdscore121[] = $row['score'];						
						}
$fftdscore121 = current($ftdscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='TD'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradetd122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradetd122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradetd122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradetd122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradetd122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradetd122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradetd122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradetd122 = "E8";}
								else if(($row["score"] <= 39)){$gradetd122 = "F9";}
								else {$gradetd122 = "NA";}
						$stdscore122[] = $row['score'];						
						}
$sstdscore122 = current($stdscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='TD'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradetd123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradetd123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradetd123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradetd123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradetd123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradetd123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradetd123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradetd123 = "E8";}
								else if(($row["score"] <= 39)){$gradetd123 = "F9";}
								else {$gradetd123 = "NA";}
						$ttdscore123[] = $row['score'];						
						}
$tttdscore123 = current($ttdscore123);	
}					
?>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td><?php echo $fftdscore101;  ?></td>
<td><?php if($fftdscore101 != ""){echo $gradetd101;}else{echo "-";} ?></td>
<td><?php echo $sstdscore102;  ?></td>
<td><?php if($sstdscore102 != ""){echo $gradetd102;}else{echo "-";} ?></td>
<td><?php echo $tttdscore103;  ?></td>
<td><?php if($tttdscore103 != ""){echo $gradetd103;}else{echo "-";} ?></td>
<td><?php echo $fftdscore111;  ?></td>
<td><?php if($fftdscore111 != ""){echo $gradetd111;}else{echo "-";} ?></td>
<td><?php echo $sstdscore112;  ?></td>
<td><?php if($sstdscore112 != ""){echo $gradetd112;}else{echo "-";} ?></td>
<td><?php echo $tttdscore113;  ?></td>
<td><?php if($tttdscore113 != ""){echo $gradetd113;}else{echo "-";} ?></td>
<td><?php echo $fftdscore121;  ?></td>
<td><?php if($fftdscore121 != ""){echo $gradetd121;}else{echo "-";} ?></td>
<td><?php echo $sstdscore122;  ?></td>
<td><?php if($sstdscore122 != ""){echo $gradetd122;}else{echo "-";} ?></td>
<td><?php echo $tttdscore123;  ?></td>
<td><?php if($tttdscore123 != ""){echo $gradetd123;}else{echo "-";} ?></td>
</tr>

<tr style="height: 13px;">
<td>VISUAL ART</td>
<?php
include "connection.php";	
// YEAR 10 DATA FOR VISUAL ART
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='VA'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeva101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeva101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeva101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeva101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeva101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeva101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeva101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeva101 = "E8";}
								else if(($row["score"] <= 39)){$gradeva101 = "F9";}
								else {$gradeva101 = "NA";}
						$fvascore101[] = $row['score'];						
						}
$ffvascore101 = current($fvascore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='VA'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradeva102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeva102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeva102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeva102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeva102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeva102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeva102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeva102 = "E8";}
								else if(($row["score"] <= 39)){$gradeva102 = "F9";}
								else {$gradeva102 = "NA";}
						$svascore102[] = $row['score'];						
						}
$ssvascore102 = current($svascore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='VA'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradeva103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeva103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeva103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeva103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeva103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeva103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeva103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeva103 = "E8";}
								else if(($row["score"] <= 39)){$gradeva103 = "F9";}
								else {$gradeva103 = "NA";}
						$tvascore103[] = $row['score'];						
						}
$ttvascore103 = current($tvascore103);
}

// YEAR 11 DATA FOR TD
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='VA'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeva111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeva111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeva111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeva111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeva111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeva111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeva111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeva111 = "E8";}
								else if(($row["score"] <= 39)){$gradeva111 = "F9";}
								else {$gradeva111 = "NA";}
						$fvascore111[] = $row['score'];						
						}
$ffvascore111 = current($fvascore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='VA'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeva112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeva112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeva112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeva112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeva112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeva112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeva112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeva112 = "E8";}
								else if(($row["score"] <= 39)){$gradeva112 = "F9";}
								else {$gradeva112 = "NA";}
						$svascore112[] = $row['score'];						
						}
$ssvascore112 = current($svascore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='VA'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeva113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeva113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeva113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeva113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeva113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeva113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeva113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeva113 = "E8";}
								else if(($row["score"] <= 39)){$gradeva1113 = "F9";}
								else {$gradeva113 = "NA";}
						$tvascore113[] = $row['score'];						
						}
$ttvascore113 = current($tvascore113);		
}

// YEAR 12 DATA FOR VISUAL ART
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='VA'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeva121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeva121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeva121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeva121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeva121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeva121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeva121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeva121 = "E8";}
								else if(($row["score"] <= 39)){$gradeva121 = "F9";}
								else {$gradeva121 = "NA";}
						$fvascore121[] = $row['score'];						
						}
$ffvascore121 = current($fvascore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='VA'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeva122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeva122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeva122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeva122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeva122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeva122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeva122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeva122 = "E8";}
								else if(($row["score"] <= 39)){$gradeva122 = "F9";}
								else {$gradeva122 = "NA";}
						$svascore122[] = $row['score'];						
						}
$ssvascore122 = current($svascore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='VA'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeva123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeva123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeva123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeva123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeva123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeva123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeva123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeva123 = "E8";}
								else if(($row["score"] <= 39)){$gradeva123 = "F9";}
								else {$gradeva123 = "NA";}
						$tvascore123[] = $row['score'];						
						}
$ttvascore123 = current($tvascore123);
}					
?>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td><?php echo $ffvascore101;  ?></td>
<td><?php if($ffvascore101 != ""){echo $gradeva101;}else{echo "-";} ?></td>
<td><?php echo $ssvascore102;  ?></td>
<td><?php if($ssvascore102 != ""){echo $gradeva102;}else{echo "-";} ?></td>
<td><?php echo $ttvascore103;  ?></td>
<td><?php if($ttvascore103 != ""){echo $gradeva103;}else{echo "-";} ?></td>
<td><?php echo $ffvascore111;  ?></td>
<td><?php if($ffvascore111 != ""){echo $gradeva111;}else{echo "-";} ?></td>
<td><?php echo $ssvascore112;  ?></td>
<td><?php if($ssvascore112 != ""){echo $gradeva112;}else{echo "-";} ?></td>
<td><?php echo $ttvascore113;  ?></td>
<td><?php if($ttvascore113 != ""){echo $gradeva113;}else{echo "-";} ?></td>
<td><?php echo $ffvascore121;  ?></td>
<td><?php if($ffvascore121 != ""){echo $gradeva121;}else{echo "-";} ?></td>
<td><?php echo $ssvascore122;  ?></td>
<td><?php if($ssvascore122 != ""){echo $gradeva122;}else{echo "-";} ?></td>
<td><?php echo $ttvascore123;  ?></td>
<td><?php if($ttvascore123 != ""){echo $gradeva123;}else{echo "-";} ?></td>
</tr>
</tbody>
</table>

<table style="width: 100%; text-align: center; font-size: 8pt;">
<tbody>
<tr>
<td colspan="7"><label style="margin-left:40%;">DESCRIPTION OF GRADES</label></td>
</tr>
<tr>
<td style="vertical-align: bottom;" rowspan="10">
<hr style="width:40%;" />
<br><label>&nbsp;ADEYOYIN ADESINA&nbsp;</label><br />PRINCIPAL</td>
<td colspan="2">IGCSE</td>
<td colspan="2">WASSCE</td>
<td colspan="2">BECE</td>
</tr>
<tr style="height: 10px;">
<td>&nbsp;90 - 100</td>
<td>&nbsp;A*</td>
<td>&nbsp;75 - 100</td>
<td>&nbsp;A1</td>
<td>&nbsp;70 - 100</td>
<td>&nbsp;A</td>
</tr>
<tr style="height: 13px;">
<td>&nbsp;80 - 89</td>
<td>&nbsp;A</td>
<td>&nbsp;70 - 74</td>
<td>&nbsp;B2</td>
<td>&nbsp;60 - 69</td>
<td>&nbsp;C</td>
</tr>
<tr style="height: 13px;">
<td>&nbsp;70 - 79</td>
<td>&nbsp;B</td>
<td>&nbsp;65 - 69</td>
<td>&nbsp;B3</td>
<td>&nbsp;50 - 59&nbsp;</td>
<td>&nbsp;P</td>
</tr>
<tr style="height: 13px;">
<td>&nbsp;60 - 69</td>
<td>&nbsp;C</td>
<td>&nbsp;60 - 64</td>
<td>&nbsp;C4</td>
<td>&nbsp;0 - 49</td>
<td>&nbsp;F</td>
</tr>
<tr style="height: 13px;">
<td>&nbsp;50 - 59</td>
<td>&nbsp;D</td>
<td>&nbsp;55 - 59</td>
<td>&nbsp;C5</td>
<td>&nbsp;-</td>
<td>&nbsp;-</td>
</tr>
<tr style="height: 13px;">
<td>&nbsp;40 - 49</td>
<td>&nbsp;E</td>
<td>&nbsp;50 - 54</td>
<td>&nbsp;C6</td>
<td>&nbsp;-</td>
<td>&nbsp;-</td>
</tr>
<tr style="height: 13px;">
<td>&nbsp;30 - 39</td>
<td>&nbsp;F</td>
<td>&nbsp;45 - 49</td>
<td>&nbsp;D7</td>
<td>&nbsp;-</td>
<td>&nbsp;-</td>
</tr>
<tr style="height: 13px;">
<td>&nbsp;20 - 29</td>
<td>&nbsp;G</td>
<td>&nbsp;40 - 44</td>
<td>&nbsp;E8</td>
<td>&nbsp;-</td>
<td>&nbsp;-</td>
</tr>
<tr style="height: 13px;">
<td>0 - 19</td>
<td>U</td>
<td>0 - 39</td>
<td>F9</td>
<td>-</td>
<td>-</td>
</tr>
</tbody>
</table>
</div>
<button class="pbutton" onclick="printDiv('printMe');" style="float: left;">PRINT TRANSCRIPT</button>
<form action="pdf4/examples/example05_tables.php" method="POST" style="float: left;">
<input type="text" name="rpic2" value="<?php echo $rpic2; ?>" />
<input type="text" name="stu_name2" value="<?php echo $stu_name2; ?>" />
<input type="text" name="yoa2" value="<?php echo $yoa2; ?>" />
<input type="text" name="maxgrad" value="<?php echo $maxgrad; ?>" />
<input type="text" name="sex2" value="<?php echo $sex2; ?>" />
<input type="text" name="reason2" value="<?php echo $reason2; ?>" />
<input type="text" name="caa2" value="<?php echo $caa2; ?>" />
<input type="text" name="classgrad2" value="<?php echo $classgrad2; ?>" />
<input type="text" name="admno2" value="<?php echo $admno2; ?>" />
<input type="text" name="y7" value="<?php echo $y7;  ?>" /><input type="text" name="y8" value="<?php echo $y8;  ?>" /><input type="text" name="y9" value="<?php echo $y9;  ?>" />
<input type="text" name="y10" value="<?php echo $y10;  ?>" /><input type="text" name="y11" value="<?php echo $y11;  ?>" /><input type="text" name="y12" value="<?php echo $y12;  ?>" />

<input type="text" name="ffengsc71" value="<?php echo $ffengsc71;  ?>" /><input type="text" name="gradeeng71" value="<?php echo $gradeeng71;  ?>" /><input type="text" name="ssengsc72" value="<?php echo $ssengsc72;  ?>" /><input type="text" name="gradeeng72" value="<?php echo $gradeeng72;  ?>" /><input type="text" name="ttengsc73" value="<?php echo $ttengsc73;  ?>" /><input type="text" name="gradeeng73" value="<?php echo $gradeeng73;  ?>" />
<input type="text" name="ffengsc81" value="<?php echo $ffengsc81;  ?>" /><input type="text" name="gradeeng81" value="<?php echo $gradeeng81;  ?>" /><input type="text" name="ssengsc82" value="<?php echo $ssengsc82;  ?>" /><input type="text" name="gradeeng82" value="<?php echo $gradeeng82;  ?>" /><input type="text" name="ttengsc83" value="<?php echo $ttengsc83;  ?>" /><input type="text" name="gradeeng83" value="<?php echo $gradeeng83;  ?>" />
<input type="text" name="ffengsc91" value="<?php echo $ffengsc91;  ?>" /><input type="text" name="gradeeng91" value="<?php echo $gradeeng91;  ?>" /><input type="text" name="ssengsc92" value="<?php echo $ssengsc92;  ?>" /><input type="text" name="gradeeng92" value="<?php echo $gradeeng92;  ?>" /><input type="text" name="ttengsc93" value="<?php echo $ttengsc93;  ?>" /><input type="text" name="gradeeng93" value="<?php echo $gradeeng93;  ?>" />
<input type="text" name="ffengsc101" value="<?php echo $ffengsc101;  ?>" /><input type="text" name="gradeeng101" value="<?php echo $gradeeng101;  ?>" /><input type="text" name="ssengsc102" value="<?php echo $ssengsc102;  ?>" /><input type="text" name="gradeeng102" value="<?php echo $gradeeng102;  ?>" /><input type="text" name="ttengsc103" value="<?php echo $ttengsc103;  ?>" /><input type="text" name="gradeeng103" value="<?php echo $gradeeng103;  ?>" />
<input type="text" name="ffengsc111" value="<?php echo $ffengsc111;  ?>" /><input type="text" name="gradeeng111" value="<?php echo $gradeeng111;  ?>" /><input type="text" name="ssengsc112" value="<?php echo $ssengsc112;  ?>" /><input type="text" name="gradeeng112" value="<?php echo $gradeeng112;  ?>" /><input type="text" name="ttengsc113" value="<?php echo $ttengsc113;  ?>" /><input type="text" name="gradeeng113" value="<?php echo $gradeeng113;  ?>" />
<input type="text" name="ffengsc121" value="<?php echo $ffengsc121;  ?>" /><input type="text" name="gradeeng121" value="<?php echo $gradeeng121;  ?>" /><input type="text" name="ssengsc122" value="<?php echo $ssengsc122;  ?>" /><input type="text" name="gradeeng122" value="<?php echo $gradeeng122;  ?>" /><input type="text" name="ttengsc123" value="<?php echo $ttengsc123;  ?>" /><input type="text" name="gradeeng123" value="<?php echo $gradeeng123;  ?>" />

<input type="text" name="ffmatsc71" value="<?php echo $ffmatsc71;  ?>" /><input type="text" name="grademat71" value="<?php echo $grademat71;  ?>" /><input type="text" name="ssmatsc72" value="<?php echo $ssmatsc72;  ?>" /><input type="text" name="grademat72" value="<?php echo $grademat72;  ?>" /><input type="text" name="ttmatsc73" value="<?php echo $ttmatsc73;  ?>" /><input type="text" name="grademat73" value="<?php echo $grademat73;  ?>" />
<input type="text" name="ffmatsc81" value="<?php echo $ffmatsc81;  ?>" /><input type="text" name="grademat81" value="<?php echo $grademat81;  ?>" /><input type="text" name="ssmatsc82" value="<?php echo $ssmatsc82;  ?>" /><input type="text" name="grademat82" value="<?php echo $grademat82;  ?>" /><input type="text" name="ttmatsc83" value="<?php echo $ttmatsc83;  ?>" /><input type="text" name="grademat83" value="<?php echo $grademat83;  ?>" />
<input type="text" name="ffmatsc91" value="<?php echo $ffmatsc91;  ?>" /><input type="text" name="grademat91" value="<?php echo $grademat91;  ?>" /><input type="text" name="ssmatsc92" value="<?php echo $ssmatsc92;  ?>" /><input type="text" name="grademat92" value="<?php echo $grademat92;  ?>" /><input type="text" name="ttmatsc93" value="<?php echo $ttmatsc93;  ?>" /><input type="text" name="grademat93" value="<?php echo $grademat93;  ?>" />
<input type="text" name="ffmatsc101" value="<?php echo $ffmatsc101;  ?>" /><input type="text" name="grademat101" value="<?php echo $grademat101;  ?>" /><input type="text" name="ssmatsc102" value="<?php echo $ssmatsc102;  ?>" /><input type="text" name="grademat102" value="<?php echo $grademat102;  ?>" /><input type="text" name="ttmatsc103" value="<?php echo $ttmatsc103;  ?>" /><input type="text" name="grademat103" value="<?php echo $grademat103;  ?>" />
<input type="text" name="ffmatsc111" value="<?php echo $ffmatsc111;  ?>" /><input type="text" name="grademat111" value="<?php echo $grademat111;  ?>" /><input type="text" name="ssmatsc112" value="<?php echo $ssmatsc112;  ?>" /><input type="text" name="grademat112" value="<?php echo $grademat112;  ?>" /><input type="text" name="ttmatsc113" value="<?php echo $ttmatsc113;  ?>" /><input type="text" name="grademat113" value="<?php echo $grademat113;  ?>" />
<input type="text" name="ffmatsc121" value="<?php echo $ffmatsc121;  ?>" /><input type="text" name="grademat121" value="<?php echo $grademat121;  ?>" /><input type="text" name="ssmatsc122" value="<?php echo $ssmatsc122;  ?>" /><input type="text" name="grademat122" value="<?php echo $grademat122;  ?>" /><input type="text" name="ttmatsc123" value="<?php echo $ttmatsc123;  ?>" /><input type="text" name="grademat123" value="<?php echo $grademat123;  ?>" />

<input type="text" name="ffagrsc71" value="<?php echo $ffagrsc71;  ?>" /><input type="text" name="gradeagr71" value="<?php echo $gradeagr71;  ?>" /><input type="text" name="ssagrsc72" value="<?php echo $ssagrsc72;  ?>" /><input type="text" name="gradeagr72" value="<?php echo $gradeagr72;  ?>" /><input type="text" name="ttagrsc73" value="<?php echo $ttagrsc73;  ?>" /><input type="text" name="gradeagr73" value="<?php echo $gradeagr73;  ?>" />
<input type="text" name="ffagrsc81" value="<?php echo $ffagrsc81;  ?>" /><input type="text" name="gradeagr81" value="<?php echo $gradeagr81;  ?>" /><input type="text" name="ssagrsc82" value="<?php echo $ssagrsc82;  ?>" /><input type="text" name="gradeagr82" value="<?php echo $gradeagr82;  ?>" /><input type="text" name="ttagrsc83" value="<?php echo $ttagrsc83;  ?>" /><input type="text" name="gradeagr83" value="<?php echo $gradeagr83;  ?>" />
<input type="text" name="ffagrsc91" value="<?php echo $ffagrsc91;  ?>" /><input type="text" name="gradeagr91" value="<?php echo $gradeagr91;  ?>" /><input type="text" name="ssagrsc92" value="<?php echo $ssagrsc92;  ?>" /><input type="text" name="gradeagr92" value="<?php echo $gradeagr92;  ?>" /><input type="text" name="ttagrsc93" value="<?php echo $ttagrsc93;  ?>" /><input type="text" name="gradeagr93" value="<?php echo $gradeagr93;  ?>" />
<input type="text" name="ffagrsc101" value="<?php echo $ffagrsc101;  ?>" /><input type="text" name="gradeagr101" value="<?php echo $gradeagr101;  ?>" /><input type="text" name="ssagrsc102" value="<?php echo $ssagrsc102;  ?>" /><input type="text" name="gradeagr102" value="<?php echo $gradeagr102;  ?>" /><input type="text" name="ttagrsc103" value="<?php echo $ttagrsc103;  ?>" /><input type="text" name="gradeagr103" value="<?php echo $gradeagr103;  ?>" />
<input type="text" name="ffagrsc111" value="<?php echo $ffagrsc111;  ?>" /><input type="text" name="gradeagr111" value="<?php echo $gradeagr111;  ?>" /><input type="text" name="ssagrsc112" value="<?php echo $ssagrsc112;  ?>" /><input type="text" name="gradeagr112" value="<?php echo $gradeagr112;  ?>" /><input type="text" name="ttagrsc113" value="<?php echo $ttagrsc113;  ?>" /><input type="text" name="gradeagr113" value="<?php echo $gradeagr113;  ?>" />
<input type="text" name="ffagrsc121" value="<?php echo $ffagrsc121;  ?>" /><input type="text" name="gradeagr121" value="<?php echo $gradeagr121;  ?>" /><input type="text" name="ssagrsc122" value="<?php echo $ssagrsc122;  ?>" /><input type="text" name="gradeagr122" value="<?php echo $gradeagr122;  ?>" /><input type="text" name="ttagrsc123" value="<?php echo $ttagrsc123;  ?>" /><input type="text" name="gradeagr123" value="<?php echo $gradeagr123;  ?>" />

<input type="text" name="ffbassc71" value="<?php echo $ffbassc71;  ?>" /><input type="text" name="gradebas71" value="<?php echo $gradebas71;  ?>" /><input type="text" name="ssbassc72" value="<?php echo $ssbassc72;  ?>" /><input type="text" name="gradebas72" value="<?php echo $gradebas72;  ?>" /><input type="text" name="ttbassc73" value="<?php echo $ttbassc73;  ?>" /><input type="text" name="gradebas73" value="<?php echo $gradebas73;  ?>" />
<input type="text" name="ffbassc81" value="<?php echo $ffbassc81;  ?>" /><input type="text" name="gradebas81" value="<?php echo $gradebas81;  ?>" /><input type="text" name="ssbassc82" value="<?php echo $ssbassc82;  ?>" /><input type="text" name="gradebas82" value="<?php echo $gradebas82;  ?>" /><input type="text" name="ttbassc83" value="<?php echo $ttbassc83;  ?>" /><input type="text" name="gradebas83" value="<?php echo $gradebas83;  ?>" />
<input type="text" name="ffbassc91" value="<?php echo $ffbassc91;  ?>" /><input type="text" name="gradebas91" value="<?php echo $gradebas91;  ?>" /><input type="text" name="ssbassc92" value="<?php echo $ssbassc92;  ?>" /><input type="text" name="gradebas92" value="<?php echo $gradebas92;  ?>" /><input type="text" name="ttbassc93" value="<?php echo $ttbassc93;  ?>" /><input type="text" name="gradebas93" value="<?php echo $gradebas93;  ?>" />

<input type="text" name="ffbiosc101" value="<?php echo $ffbiosc101;  ?>" /><input type="text" name="gradebio101" value="<?php echo $gradebio101;  ?>" /><input type="text" name="ssbiosc102" value="<?php echo $ssbiosc102;  ?>" /><input type="text" name="gradebio102" value="<?php echo $gradebio102;  ?>" /><input type="text" name="ttbiosc103" value="<?php echo $ttbiosc103;  ?>" /><input type="text" name="gradebio103" value="<?php echo $gradebio103;  ?>" />
<input type="text" name="ffbiosc111" value="<?php echo $ffbiosc111;  ?>" /><input type="text" name="gradebio111" value="<?php echo $gradebio111;  ?>" /><input type="text" name="ssbiosc112" value="<?php echo $ssbiosc112;  ?>" /><input type="text" name="gradebio112" value="<?php echo $gradebio112;  ?>" /><input type="text" name="ttbiosc113" value="<?php echo $ttbiosc113;  ?>" /><input type="text" name="gradebio113" value="<?php echo $gradebio113;  ?>" />
<input type="text" name="ffbiosc121" value="<?php echo $ffbiosc121;  ?>" /><input type="text" name="gradebio121" value="<?php echo $gradebio121;  ?>" /><input type="text" name="ssbiosc122" value="<?php echo $ssbiosc122;  ?>" /><input type="text" name="gradebio122" value="<?php echo $gradebio122;  ?>" /><input type="text" name="ttbiosc123" value="<?php echo $ttbiosc123;  ?>" /><input type="text" name="gradebio123" value="<?php echo $gradebio123;  ?>" />

<input type="text" name="ffbussc71" value="<?php echo $ffbussc71;  ?>" /><input type="text" name="gradebus71" value="<?php echo $gradebus71;  ?>" /><input type="text" name="ssbussc72" value="<?php echo $ssbussc72;  ?>" /><input type="text" name="gradebus72" value="<?php echo $gradebus72;  ?>" /><input type="text" name="ttbussc73" value="<?php echo $ttbussc73;  ?>" /><input type="text" name="gradebus73" value="<?php echo $gradebus73;  ?>" />
<input type="text" name="ffbussc81" value="<?php echo $ffbussc81;  ?>" /><input type="text" name="gradebus81" value="<?php echo $gradebus81;  ?>" /><input type="text" name="ssbussc82" value="<?php echo $ssbussc82;  ?>" /><input type="text" name="gradebus82" value="<?php echo $gradebus82;  ?>" /><input type="text" name="ttbussc83" value="<?php echo $ttbussc83;  ?>" /><input type="text" name="gradebus83" value="<?php echo $gradebus83;  ?>" />
<input type="text" name="ffbussc91" value="<?php echo $ffbussc91;  ?>" /><input type="text" name="gradebus91" value="<?php echo $gradebus91;  ?>" /><input type="text" name="ssbussc92" value="<?php echo $ssbussc92;  ?>" /><input type="text" name="gradebus92" value="<?php echo $gradebus92;  ?>" /><input type="text" name="ttbussc93" value="<?php echo $ttbussc93;  ?>" /><input type="text" name="gradebus93" value="<?php echo $gradebus93;  ?>" />

<input type="text" name="ffcatsc71" value="<?php echo $ffcatsc71;  ?>" /><input type="text" name="gradecat71" value="<?php echo $gradecat71;  ?>" /><input type="text" name="sscatsc72" value="<?php echo $sscatsc72;  ?>" /><input type="text" name="gradecat72" value="<?php echo $gradecat72;  ?>" /><input type="text" name="ttcatsc73" value="<?php echo $ttcatsc73;  ?>" /><input type="text" name="gradecat73" value="<?php echo $gradecat73;  ?>" />
<input type="text" name="ffcatsc81" value="<?php echo $ffcatsc81;  ?>" /><input type="text" name="gradecat81" value="<?php echo $gradecat81;  ?>" /><input type="text" name="sscatsc82" value="<?php echo $sscatsc82;  ?>" /><input type="text" name="gradecat82" value="<?php echo $gradecat82;  ?>" /><input type="text" name="ttcatsc83" value="<?php echo $ttcatsc83;  ?>" /><input type="text" name="gradecat83" value="<?php echo $gradecat83;  ?>" />
<input type="text" name="ffcatsc91" value="<?php echo $ffcatsc91;  ?>" /><input type="text" name="gradecat91" value="<?php echo $gradecat91;  ?>" /><input type="text" name="sscatsc92" value="<?php echo $sscatsc92;  ?>" /><input type="text" name="gradecat92" value="<?php echo $gradecat92;  ?>" /><input type="text" name="ttcatsc93" value="<?php echo $ttcatsc93;  ?>" /><input type="text" name="gradecat93" value="<?php echo $gradecat93;  ?>" />
<input type="text" name="ffcatsc101" value="<?php echo $ffcatsc101;  ?>" /><input type="text" name="gradecat101" value="<?php echo $gradecat101;  ?>" /><input type="text" name="sscatsc102" value="<?php echo $sscatsc102;  ?>" /><input type="text" name="gradecat102" value="<?php echo $gradecat102;  ?>" /><input type="text" name="ttcatsc103" value="<?php echo $ttcatsc103;  ?>" /><input type="text" name="gradecat103" value="<?php echo $gradecat103;  ?>" />
<input type="text" name="ffcatsc111" value="<?php echo $ffcatsc111;  ?>" /><input type="text" name="gradecat111" value="<?php echo $gradecat111;  ?>" /><input type="text" name="sscatsc112" value="<?php echo $sscatsc112;  ?>" /><input type="text" name="gradecat112" value="<?php echo $gradecat112;  ?>" /><input type="text" name="ttcatsc113" value="<?php echo $ttcatsc113;  ?>" /><input type="text" name="gradecat113" value="<?php echo $gradecat113;  ?>" />
<input type="text" name="ffcatsc121" value="<?php echo $ffcatsc121;  ?>" /><input type="text" name="gradecat121" value="<?php echo $gradecat121;  ?>" /><input type="text" name="sscatsc122" value="<?php echo $sscatsc122;  ?>" /><input type="text" name="gradecat122" value="<?php echo $gradecat122;  ?>" /><input type="text" name="ttcatsc123" value="<?php echo $ttcatsc123;  ?>" /><input type="text" name="gradecat123" value="<?php echo $gradecat123;  ?>" />

<input style="background-color:orange;" type="text" name="ffchescore101" value="<?php echo $ffchescore101;  ?>" /><input type="text" name="gradeche101" value="<?php echo $gradeche101;  ?>" /><input style="background-color:orange;"  type="text" name="sschescore102" value="<?php echo $sschescore102;  ?>" /><input type="text" name="gradeche102" value="<?php echo $gradeche102;  ?>" /><input type="text" name="ttchescore103" value="<?php echo $ttchescore103;  ?>" /><input type="text" name="gradeche103" value="<?php echo $gradeche103;  ?>" />
<input type="text" name="ffchescore111" value="<?php echo $ffchescore111;  ?>" /><input type="text" name="gradeche111" value="<?php echo $gradeche111;  ?>" /><input type="text" name="sschescore112" value="<?php echo $sschescore112;  ?>" /><input type="text" name="gradeche112" value="<?php echo $gradeche112;  ?>" /><input type="text" name="ttchescore113" value="<?php echo $ttchescore113;  ?>" /><input type="text" name="gradeche113" value="<?php echo $gradeche113;  ?>" />
<input type="text" name="ffchescore121" value="<?php echo $ffchescore121;  ?>" /><input type="text" name="gradeche121" value="<?php echo $gradeche121;  ?>" /><input type="text" name="sschescore122" value="<?php echo $sschescore122;  ?>" /><input type="text" name="gradeche122" value="<?php echo $gradeche122;  ?>" /><input type="text" name="ttchescore123" value="<?php echo $ttchescore123;  ?>" /><input type="text" name="gradeche123" value="<?php echo $gradeche123;  ?>" />

<input type="text" name="ffcivscore71" value="<?php echo $ffcivscore71;  ?>" /><input type="text" name="gradeciv71" value="<?php echo $gradeciv71;  ?>" /><input type="text" name="sscivscore72" value="<?php echo $sscivscore72;  ?>" /><input type="text" name="gradeciv72" value="<?php echo $gradeciv72;  ?>" /><input type="text" name="ttcivscore73" value="<?php echo $ttcivscore73;  ?>" /><input type="text" name="gradeciv73" value="<?php echo $gradeciv73;  ?>" />
<input type="text" name="ffcivscore81" value="<?php echo $ffcivscore81;  ?>" /><input type="text" name="gradeciv81" value="<?php echo $gradeciv81;  ?>" /><input type="text" name="sscivscore82" value="<?php echo $sscivscore82;  ?>" /><input type="text" name="gradeciv82" value="<?php echo $gradeciv82;  ?>" /><input type="text" name="ttcivscore83" value="<?php echo $ttcivscore83;  ?>" /><input type="text" name="gradeciv83" value="<?php echo $gradeciv83;  ?>" />
<input type="text" name="ffcivscore91" value="<?php echo $ffcivscore91;  ?>" /><input type="text" name="gradeciv91" value="<?php echo $gradeciv91;  ?>" /><input type="text" name="sscivscore92" value="<?php echo $sscivscore92;  ?>" /><input type="text" name="gradeciv92" value="<?php echo $gradeciv92;  ?>" /><input type="text" name="ttcivscore93" value="<?php echo $ttcivscore93;  ?>" /><input type="text" name="gradeciv93" value="<?php echo $gradeciv93;  ?>" />
<input style="background-color:orange;" type="text" name="ffcivscore101" value="<?php echo $ffcivscore101;  ?>" /><input type="text" name="gradeciv101" value="<?php echo $gradeciv101;  ?>" /><input style="background-color:orange;"  type="text" name="sscivscore102" value="<?php echo $sscivscore102;  ?>" /><input type="text" name="gradeciv102" value="<?php echo $gradeciv102;  ?>" /><input type="text" name="ttcivscore103" value="<?php echo $ttcivscore103;  ?>" /><input type="text" name="gradeciv103" value="<?php echo $gradeciv103;  ?>" />
<input type="text" name="ffcivscore111" value="<?php echo $ffcivscore111;  ?>" /><input type="text" name="gradeciv111" value="<?php echo $gradeciv111;  ?>" /><input type="text" name="sscivscore112" value="<?php echo $sscivscore112;  ?>" /><input type="text" name="gradeciv112" value="<?php echo $gradeciv112;  ?>" /><input type="text" name="ttcivscore113" value="<?php echo $ttcivscore113;  ?>" /><input type="text" name="gradeciv113" value="<?php echo $gradeciv113;  ?>" />
<input type="text" name="ffcivscore121" value="<?php echo $ffcivscore121;  ?>" /><input type="text" name="gradeciv121" value="<?php echo $gradeciv121;  ?>" /><input type="text" name="sscivscore122" value="<?php echo $sscivscore122;  ?>" /><input type="text" name="gradeciv122" value="<?php echo $gradeciv122;  ?>" /><input type="text" name="ttcivscore123" value="<?php echo $ttcivscore123;  ?>" /><input type="text" name="gradeciv123" value="<?php echo $gradeciv123;  ?>" />

<input type="text" name="ffcrkscore71" value="<?php echo $ffcrkscore71;  ?>" /><input type="text" name="gradecrk71" value="<?php echo $gradecrk71;  ?>" /><input type="text" name="sscrkscore72" value="<?php echo $sscrkscore72;  ?>" /><input type="text" name="gradecrk72" value="<?php echo $gradecrk72;  ?>" /><input type="text" name="ttcrkscore73" value="<?php echo $ttcrkscore73;  ?>" /><input type="text" name="gradecrk73" value="<?php echo $gradecrk73;  ?>" />
<input type="text" name="ffcrkscore81" value="<?php echo $ffcrkscore81;  ?>" /><input type="text" name="gradecrk81" value="<?php echo $gradecrk81;  ?>" /><input type="text" name="sscrkscore82" value="<?php echo $sscrkscore82;  ?>" /><input type="text" name="gradecrk82" value="<?php echo $gradecrk82;  ?>" /><input type="text" name="ttcrkscore83" value="<?php echo $ttcrkscore83;  ?>" /><input type="text" name="gradecrk83" value="<?php echo $gradecrk83;  ?>" />
<input type="text" name="ffcrkscore91" value="<?php echo $ffcrkscore91;  ?>" /><input type="text" name="gradecrk91" value="<?php echo $gradecrk91;  ?>" /><input type="text" name="sscrkscore92" value="<?php echo $sscrkscore92;  ?>" /><input type="text" name="gradecrk92" value="<?php echo $gradecrk92;  ?>" /><input type="text" name="ttcrkscore93" value="<?php echo $ttcrkscore93;  ?>" /><input type="text" name="gradecrk93" value="<?php echo $gradecrk93;  ?>" />
<input style="background-color:orange;" type="text" name="ffcrkscore101" value="<?php echo $ffcrkscore101;  ?>" /><input type="text" name="gradecrk101" value="<?php echo $gradecrk101;  ?>" /><input style="background-color:orange;"  type="text" name="sscrkscore102" value="<?php echo $sscrkscore102;  ?>" /><input type="text" name="gradecrk102" value="<?php echo $gradecrk102;  ?>" /><input type="text" name="ttcrkscore103" value="<?php echo $ttcrkscore103;  ?>" /><input type="text" name="gradecrk103" value="<?php echo $gradecrk103;  ?>" />
<input type="text" name="ffcrkscore111" value="<?php echo $ffcrkscore111;  ?>" /><input type="text" name="gradecrk111" value="<?php echo $gradecrk111;  ?>" /><input type="text" name="sscrkscore112" value="<?php echo $sscrkscore112;  ?>" /><input type="text" name="gradecrk112" value="<?php echo $gradecrk112;  ?>" /><input type="text" name="ttcrkscore113" value="<?php echo $ttcrkscore113;  ?>" /><input type="text" name="gradecrk113" value="<?php echo $gradecrk113;  ?>" />
<input type="text" name="ffcrkscore121" value="<?php echo $ffcrkscore121;  ?>" /><input type="text" name="gradecrk121" value="<?php echo $gradecrk121;  ?>" /><input type="text" name="sscrkscore122" value="<?php echo $sscrkscore122;  ?>" /><input type="text" name="gradecrk122" value="<?php echo $gradecrk122;  ?>" /><input type="text" name="ttcrkscore123" value="<?php echo $ttcrkscore123;  ?>" /><input type="text" name="gradecrk123" value="<?php echo $gradecrk123;  ?>" />

<input style="background-color:orange;" type="text" name="ffecoscore101" value="<?php echo $ffecoscore101;  ?>" /><input type="text" name="gradeeco101" value="<?php echo $gradeeco101;  ?>" /><input style="background-color:orange;"  type="text" name="ssecoscore102" value="<?php echo $ssecoscore102;  ?>" /><input type="text" name="gradeeco102" value="<?php echo $gradeeco102;  ?>" /><input type="text" name="ttecoscore103" value="<?php echo $ttecoscore103;  ?>" /><input type="text" name="gradeeco103" value="<?php echo $gradeeco103;  ?>" />
<input type="text" name="ffecoscore111" value="<?php echo $ffecoscore111;  ?>" /><input type="text" name="gradeeco111" value="<?php echo $gradeeco111;  ?>" /><input type="text" name="ssecoscore112" value="<?php echo $ssecoscore112;  ?>" /><input type="text" name="gradeeco112" value="<?php echo $gradeeco112;  ?>" /><input type="text" name="ttecoscore113" value="<?php echo $ttecoscore113;  ?>" /><input type="text" name="gradeeco113" value="<?php echo $gradeeco113;  ?>" />
<input type="text" name="ffecoscore121" value="<?php echo $ffecoscore121;  ?>" /><input type="text" name="gradeeco121" value="<?php echo $gradeeco121;  ?>" /><input type="text" name="ssecoscore122" value="<?php echo $ssecoscore122;  ?>" /><input type="text" name="gradeeco122" value="<?php echo $gradeeco122;  ?>" /><input type="text" name="ttecoscore123" value="<?php echo $ttecoscore123;  ?>" /><input type="text" name="gradeeco123" value="<?php echo $gradeeco123;  ?>" />

<input type="text" name="fffooscore71" value="<?php echo $fffooscore71;  ?>" /><input type="text" name="gradefoo71" value="<?php echo $gradefoo71;  ?>" /><input type="text" name="ssfooscore72" value="<?php echo $ssfooscore72;  ?>" /><input type="text" name="gradefoo72" value="<?php echo $gradefoo72;  ?>" /><input type="text" name="ttfooscore73" value="<?php echo $ttfooscore73;  ?>" /><input type="text" name="gradefoo73" value="<?php echo $gradefoo73;  ?>" />
<input type="text" name="fffooscore81" value="<?php echo $fffooscore81;  ?>" /><input type="text" name="gradefoo81" value="<?php echo $gradefoo81;  ?>" /><input type="text" name="ssfooscore82" value="<?php echo $ssfooscore82;  ?>" /><input type="text" name="gradefoo82" value="<?php echo $gradefoo82;  ?>" /><input type="text" name="ttfooscore83" value="<?php echo $ttfooscore83;  ?>" /><input type="text" name="gradefoo83" value="<?php echo $gradefoo83;  ?>" />
<input type="text" name="fffooscore91" value="<?php echo $fffooscore91;  ?>" /><input type="text" name="gradefoo91" value="<?php echo $gradefoo91;  ?>" /><input type="text" name="ssfooscore92" value="<?php echo $ssfooscore92;  ?>" /><input type="text" name="gradefoo92" value="<?php echo $gradefoo92;  ?>" /><input type="text" name="ttfooscore93" value="<?php echo $ttfooscore93;  ?>" /><input type="text" name="gradefoo93" value="<?php echo $gradefoo93;  ?>" />
<input style="background-color:orange;" type="text" name="fffooscore101" value="<?php echo $fffooscore101;  ?>" /><input type="text" name="gradefoo101" value="<?php echo $gradefoo101;  ?>" /><input style="background-color:orange;"  type="text" name="ssfooscore102" value="<?php echo $ssfooscore102;  ?>" /><input type="text" name="gradefoo102" value="<?php echo $gradefoo102;  ?>" /><input type="text" name="ttfooscore103" value="<?php echo $ttfooscore103;  ?>" /><input type="text" name="gradefoo103" value="<?php echo $gradefoo103;  ?>" />
<input type="text" name="fffooscore111" value="<?php echo $fffooscore111;  ?>" /><input type="text" name="gradefoo111" value="<?php echo $gradefoo111;  ?>" /><input type="text" name="ssfooscore112" value="<?php echo $ssfooscore112;  ?>" /><input type="text" name="gradefoo112" value="<?php echo $gradefoo112;  ?>" /><input type="text" name="ttfooscore113" value="<?php echo $ttfooscore113;  ?>" /><input type="text" name="gradefoo113" value="<?php echo $gradefoo113;  ?>" />
<input type="text" name="fffooscore121" value="<?php echo $fffooscore121;  ?>" /><input type="text" name="gradefoo121" value="<?php echo $gradefoo121;  ?>" /><input type="text" name="ssfooscore122" value="<?php echo $ssfooscore122;  ?>" /><input type="text" name="gradefoo122" value="<?php echo $gradefoo122;  ?>" /><input type="text" name="ttfooscore123" value="<?php echo $ttfooscore123;  ?>" /><input type="text" name="gradefoo123" value="<?php echo $gradefoo123;  ?>" />

<input type="text" name="fffrescore71" value="<?php echo $fffrescore71;  ?>" /><input type="text" name="gradefre71" value="<?php echo $gradefre71;  ?>" /><input type="text" name="ssfrescore72" value="<?php echo $ssfrescore72;  ?>" /><input type="text" name="gradefre72" value="<?php echo $gradefre72;  ?>" /><input type="text" name="ttfrescore73" value="<?php echo $ttfrescore73;  ?>" /><input type="text" name="gradefre73" value="<?php echo $gradefre73;  ?>" />
<input type="text" name="fffrescore81" value="<?php echo $fffrescore81;  ?>" /><input type="text" name="gradefre81" value="<?php echo $gradefre81;  ?>" /><input type="text" name="ssfrescore82" value="<?php echo $ssfrescore82;  ?>" /><input type="text" name="gradefre82" value="<?php echo $gradefre82;  ?>" /><input type="text" name="ttfrescore83" value="<?php echo $ttfrescore83;  ?>" /><input type="text" name="gradefre83" value="<?php echo $gradefre83;  ?>" />
<input type="text" name="fffrescore91" value="<?php echo $fffrescore91;  ?>" /><input type="text" name="gradefre91" value="<?php echo $gradefre91;  ?>" /><input type="text" name="ssfrescore92" value="<?php echo $ssfrescore92;  ?>" /><input type="text" name="gradefre92" value="<?php echo $gradefre92;  ?>" /><input type="text" name="ttfrescore93" value="<?php echo $ttfrescore93;  ?>" /><input type="text" name="gradefre93" value="<?php echo $gradefre93;  ?>" />
<input style="background-color:orange;" type="text" name="fffrescore101" value="<?php echo $fffrescore101;  ?>" /><input type="text" name="gradefre101" value="<?php echo $gradefre101;  ?>" /><input style="background-color:orange;"  type="text" name="ssfrescore102" value="<?php echo $ssfrescore102;  ?>" /><input type="text" name="gradefre102" value="<?php echo $gradefre102;  ?>" /><input type="text" name="ttfrescore103" value="<?php echo $ttfrescore103;  ?>" /><input type="text" name="gradefre103" value="<?php echo $gradefre103;  ?>" />
<input type="text" name="fffrescore111" value="<?php echo $fffrescore111;  ?>" /><input type="text" name="gradefre111" value="<?php echo $gradefre111;  ?>" /><input type="text" name="ssfrescore112" value="<?php echo $ssfrescore112;  ?>" /><input type="text" name="gradefre112" value="<?php echo $gradefre112;  ?>" /><input type="text" name="ttfrescore113" value="<?php echo $ttfrescore113;  ?>" /><input type="text" name="gradefre113" value="<?php echo $gradefre113;  ?>" />
<input type="text" name="fffrescore121" value="<?php echo $fffrescore121;  ?>" /><input type="text" name="gradefre121" value="<?php echo $gradefre121;  ?>" /><input type="text" name="ssfrescore122" value="<?php echo $ssfrescore122;  ?>" /><input type="text" name="gradefre122" value="<?php echo $gradefre122;  ?>" /><input type="text" name="ttfrescore123" value="<?php echo $ttfrescore123;  ?>" /><input type="text" name="gradefre123" value="<?php echo $gradefre123;  ?>" />

<input style="background-color:orange;" type="text" name="ffgovscore101" value="<?php echo $ffgovscore101;  ?>" /><input type="text" name="gradegov101" value="<?php echo $gradegov101;  ?>" /><input style="background-color:orange;"  type="text" name="ssgovscore102" value="<?php echo $ssgovscore102;  ?>" /><input type="text" name="gradegov102" value="<?php echo $gradegov102;  ?>" /><input type="text" name="ttgovscore103" value="<?php echo $ttgovscore103;  ?>" /><input type="text" name="gradegov103" value="<?php echo $gradegov103;  ?>" />
<input type="text" name="ffgovscore111" value="<?php echo $ffgovscore111;  ?>" /><input type="text" name="gradegov111" value="<?php echo $gradegov111;  ?>" /><input type="text" name="ssgovscore112" value="<?php echo $ssgovscore112;  ?>" /><input type="text" name="gradegov112" value="<?php echo $gradegov112;  ?>" /><input type="text" name="ttgovscore113" value="<?php echo $ttgovscore113;  ?>" /><input type="text" name="gradegov113" value="<?php echo $gradegov113;  ?>" />
<input type="text" name="ffgovscore121" value="<?php echo $ffgovscore121;  ?>" /><input type="text" name="gradegov121" value="<?php echo $gradegov121;  ?>" /><input type="text" name="ssgovscore122" value="<?php echo $ssgovscore122;  ?>" /><input type="text" name="gradegov122" value="<?php echo $gradegov122;  ?>" /><input type="text" name="ttgovscore123" value="<?php echo $ttgovscore123;  ?>" /><input type="text" name="gradegov123" value="<?php echo $gradegov123;  ?>" />

<input type="text" name="ffictscore71" value="<?php echo $ffictscore71;  ?>" /><input type="text" name="gradeict71" value="<?php echo $gradeict71;  ?>" /><input type="text" name="ssictscore72" value="<?php echo $ssictscore72;  ?>" /><input type="text" name="gradeict72" value="<?php echo $gradeict72;  ?>" /><input type="text" name="ttictscore73" value="<?php echo $ttictscore73;  ?>" /><input type="text" name="gradeict73" value="<?php echo $gradeict73;  ?>" />
<input type="text" name="ffictscore81" value="<?php echo $ffictscore81;  ?>" /><input type="text" name="gradeict81" value="<?php echo $gradeict81;  ?>" /><input type="text" name="ssictscore82" value="<?php echo $ssictscore82;  ?>" /><input type="text" name="gradeict82" value="<?php echo $gradeict82;  ?>" /><input type="text" name="ttictscore83" value="<?php echo $ttictscore83;  ?>" /><input type="text" name="gradeict83" value="<?php echo $gradeict83;  ?>" />
<input type="text" name="ffictscore91" value="<?php echo $ffictscore91;  ?>" /><input type="text" name="gradeict91" value="<?php echo $gradeict91;  ?>" /><input type="text" name="ssictscore92" value="<?php echo $ssictscore92;  ?>" /><input type="text" name="gradeict92" value="<?php echo $gradeict92;  ?>" /><input type="text" name="ttictscore93" value="<?php echo $ttictscore93;  ?>" /><input type="text" name="gradeict93" value="<?php echo $gradeict93;  ?>" />
<input style="background-color:orange;" type="text" name="ffictscore101" value="<?php echo $ffictscore101;  ?>" /><input type="text" name="gradeict101" value="<?php echo $gradeict101;  ?>" /><input style="background-color:orange;"  type="text" name="ssictscore102" value="<?php echo $ssictscore102;  ?>" /><input type="text" name="gradeict102" value="<?php echo $gradeict102;  ?>" /><input type="text" name="ttictscore103" value="<?php echo $ttictscore103;  ?>" /><input type="text" name="gradeict103" value="<?php echo $gradeict103;  ?>" />
<input type="text" name="ffictscore111" value="<?php echo $ffictscore111;  ?>" /><input type="text" name="gradeict111" value="<?php echo $gradeict111;  ?>" /><input type="text" name="ssictscore112" value="<?php echo $ssictscore112;  ?>" /><input type="text" name="gradeict112" value="<?php echo $gradeict112;  ?>" /><input type="text" name="ttictscore113" value="<?php echo $ttictscore113;  ?>" /><input type="text" name="gradeict113" value="<?php echo $gradeict113;  ?>" />
<input type="text" name="ffictscore121" value="<?php echo $ffictscore121;  ?>" /><input type="text" name="gradeict121" value="<?php echo $gradeict121;  ?>" /><input type="text" name="ssictscore122" value="<?php echo $ssictscore122;  ?>" /><input type="text" name="gradeict122" value="<?php echo $gradeict122;  ?>" /><input type="text" name="ttictscore123" value="<?php echo $ttictscore123;  ?>" /><input type="text" name="gradeict123" value="<?php echo $gradeict123;  ?>" />

<input type="text" name="ffigbscore71" value="<?php echo $ffigbscore71;  ?>" /><input type="text" name="gradeigb71" value="<?php echo $gradeigb71;  ?>" /><input type="text" name="ssigbscore72" value="<?php echo $ssigbscore72;  ?>" /><input type="text" name="gradeigb72" value="<?php echo $gradeigb72;  ?>" /><input type="text" name="ttigbscore73" value="<?php echo $ttigbscore73;  ?>" /><input type="text" name="gradeigb73" value="<?php echo $gradeigb73;  ?>" />
<input type="text" name="ffigbscore81" value="<?php echo $ffigbscore81;  ?>" /><input type="text" name="gradeigb81" value="<?php echo $gradeigb81;  ?>" /><input type="text" name="ssigbscore82" value="<?php echo $ssigbscore82;  ?>" /><input type="text" name="gradeigb82" value="<?php echo $gradeigb82;  ?>" /><input type="text" name="ttigbscore83" value="<?php echo $ttigbscore83;  ?>" /><input type="text" name="gradeigb83" value="<?php echo $gradeigb83;  ?>" />
<input type="text" name="ffigbscore91" value="<?php echo $ffigbscore91;  ?>" /><input type="text" name="gradeigb91" value="<?php echo $gradeigb91;  ?>" /><input type="text" name="ssigbscore92" value="<?php echo $ssigbscore92;  ?>" /><input type="text" name="gradeigb92" value="<?php echo $gradeigb92;  ?>" /><input type="text" name="ttigbscore93" value="<?php echo $ttigbscore93;  ?>" /><input type="text" name="gradeigb93" value="<?php echo $gradeigb93;  ?>" />
<input style="background-color:orange;" type="text" name="ffigbscore101" value="<?php echo $ffigbscore101;  ?>" /><input type="text" name="gradeigb101" value="<?php echo $gradeigb101;  ?>" /><input style="background-color:orange;"  type="text" name="ssigbscore102" value="<?php echo $ssigbscore102;  ?>" /><input type="text" name="gradeigb102" value="<?php echo $gradeigb102;  ?>" /><input type="text" name="ttigbscore103" value="<?php echo $ttigbscore103;  ?>" /><input type="text" name="gradeigb103" value="<?php echo $gradeigb103;  ?>" />
<input type="text" name="ffigbscore111" value="<?php echo $ffigbscore111;  ?>" /><input type="text" name="gradeigb111" value="<?php echo $gradeigb111;  ?>" /><input type="text" name="ssigbscore112" value="<?php echo $ssigbscore112;  ?>" /><input type="text" name="gradeigb112" value="<?php echo $gradeigb112;  ?>" /><input type="text" name="ttigbscore113" value="<?php echo $ttigbscore113;  ?>" /><input type="text" name="gradeigb113" value="<?php echo $gradeigb113;  ?>" />
<input type="text" name="ffigbscore121" value="<?php echo $ffigbscore121;  ?>" /><input type="text" name="gradeigb121" value="<?php echo $gradeigb121;  ?>" /><input type="text" name="ssigbscore122" value="<?php echo $ssigbscore122;  ?>" /><input type="text" name="gradeigb122" value="<?php echo $gradeigb122;  ?>" /><input type="text" name="ttigbscore123" value="<?php echo $ttigbscore123;  ?>" /><input type="text" name="gradeigb123" value="<?php echo $gradeigb123;  ?>" />

<input style="background-color:orange;" type="text" name="fflitscore101" value="<?php echo $fflitscore101;  ?>" /><input type="text" name="gradelit101" value="<?php echo $gradelit101;  ?>" /><input style="background-color:orange;"  type="text" name="sslitscore102" value="<?php echo $sslitscore102;  ?>" /><input type="text" name="gradelit102" value="<?php echo $gradelit102;  ?>" /><input type="text" name="ttlitscore103" value="<?php echo $ttlitscore103;  ?>" /><input type="text" name="gradelit103" value="<?php echo $gradelit103;  ?>" />
<input type="text" name="fflitscore111" value="<?php echo $fflitscore111;  ?>" /><input type="text" name="gradelit111" value="<?php echo $gradelit111;  ?>" /><input type="text" name="sslitscore112" value="<?php echo $sslitscore112;  ?>" /><input type="text" name="gradelit112" value="<?php echo $gradelit112;  ?>" /><input type="text" name="ttlitscore113" value="<?php echo $ttlitscore113;  ?>" /><input type="text" name="gradelit113" value="<?php echo $gradelit113;  ?>" />
<input type="text" name="fflitscore121" value="<?php echo $fflitscore121;  ?>" /><input type="text" name="gradelit121" value="<?php echo $gradelit121;  ?>" /><input type="text" name="sslitscore122" value="<?php echo $sslitscore122;  ?>" /><input type="text" name="gradelit122" value="<?php echo $gradelit122;  ?>" /><input type="text" name="ttlitscore123" value="<?php echo $ttlitscore123;  ?>" /><input type="text" name="gradelit123" value="<?php echo $gradelit123;  ?>" />

<input style="background-color:orange;" type="text" name="ffmarscore101" value="<?php echo $ffmarscore101;  ?>" /><input type="text" name="grademar101" value="<?php echo $grademar101;  ?>" /><input style="background-color:orange;"  type="text" name="ssmarscore102" value="<?php echo $ssmarscore102;  ?>" /><input type="text" name="grademar102" value="<?php echo $grademar102;  ?>" /><input type="text" name="ttmarscore103" value="<?php echo $ttmarscore103;  ?>" /><input type="text" name="grademar103" value="<?php echo $grademar103;  ?>" />
<input type="text" name="ffmarscore111" value="<?php echo $ffmarscore111;  ?>" /><input type="text" name="grademar111" value="<?php echo $grademar111;  ?>" /><input type="text" name="ssmarscore112" value="<?php echo $ssmarscore112;  ?>" /><input type="text" name="grademar112" value="<?php echo $grademar112;  ?>" /><input type="text" name="ttmarscore113" value="<?php echo $ttmarscore113;  ?>" /><input type="text" name="grademar113" value="<?php echo $grademar113;  ?>" />
<input type="text" name="ffmarscore121" value="<?php echo $ffmarscore121;  ?>" /><input type="text" name="grademar121" value="<?php echo $grademar121;  ?>" /><input type="text" name="ssmarscore122" value="<?php echo $ssmarscore122;  ?>" /><input type="text" name="grademar122" value="<?php echo $grademar122;  ?>" /><input type="text" name="ttmarscore123" value="<?php echo $ttmarscore123;  ?>" /><input type="text" name="grademar123" value="<?php echo $grademar123;  ?>" />

<input type="text" name="ffmusscore71" value="<?php echo $ffmusscore71;  ?>" /><input type="text" name="grademus71" value="<?php echo $grademus71;  ?>" /><input type="text" name="ssmusscore72" value="<?php echo $ssmusscore72;  ?>" /><input type="text" name="grademus72" value="<?php echo $grademus72;  ?>" /><input type="text" name="ttmusscore73" value="<?php echo $ttmusscore73;  ?>" /><input type="text" name="grademus73" value="<?php echo $grademus73;  ?>" />
<input type="text" name="ffmusscore81" value="<?php echo $ffmusscore81;  ?>" /><input type="text" name="grademus81" value="<?php echo $grademus81;  ?>" /><input type="text" name="ssmusscore82" value="<?php echo $ssmusscore82;  ?>" /><input type="text" name="grademus82" value="<?php echo $grademus82;  ?>" /><input type="text" name="ttmusscore83" value="<?php echo $ttmusscore83;  ?>" /><input type="text" name="grademus83" value="<?php echo $grademus83;  ?>" />
<input type="text" name="ffmusscore91" value="<?php echo $ffmusscore91;  ?>" /><input type="text" name="grademus91" value="<?php echo $grademus91;  ?>" /><input type="text" name="ssmusscore92" value="<?php echo $ssmusscore92;  ?>" /><input type="text" name="grademus92" value="<?php echo $grademus92;  ?>" /><input type="text" name="ttmusscore93" value="<?php echo $ttmusscore93;  ?>" /><input type="text" name="grademus93" value="<?php echo $grademus93;  ?>" />
<input style="background-color:orange;" type="text" name="ffmusscore101" value="<?php echo $ffmusscore101;  ?>" /><input type="text" name="grademus101" value="<?php echo $grademus101;  ?>" /><input style="background-color:orange;"  type="text" name="ssmusscore102" value="<?php echo $ssmusscore102;  ?>" /><input type="text" name="grademus102" value="<?php echo $grademus102;  ?>" /><input type="text" name="ttmusscore103" value="<?php echo $ttmusscore103;  ?>" /><input type="text" name="grademus103" value="<?php echo $grademus103;  ?>" />
<input type="text" name="ffmusscore111" value="<?php echo $ffmusscore111;  ?>" /><input type="text" name="grademus111" value="<?php echo $grademus111;  ?>" /><input type="text" name="ssmusscore112" value="<?php echo $ssmusscore112;  ?>" /><input type="text" name="grademus112" value="<?php echo $grademus112;  ?>" /><input type="text" name="ttmusscore113" value="<?php echo $ttmusscore113;  ?>" /><input type="text" name="grademus113" value="<?php echo $grademus113;  ?>" />
<input type="text" name="ffmusscore121" value="<?php echo $ffmusscore121;  ?>" /><input type="text" name="grademus121" value="<?php echo $grademus121;  ?>" /><input type="text" name="ssmusscore122" value="<?php echo $ssmusscore122;  ?>" /><input type="text" name="grademus122" value="<?php echo $grademus122;  ?>" /><input type="text" name="ttmusscore123" value="<?php echo $ttmusscore123;  ?>" /><input type="text" name="grademus123" value="<?php echo $grademus123;  ?>" />

<input type="text" name="ffphescore71" value="<?php echo $ffphescore71;  ?>" /><input type="text" name="gradephe71" value="<?php echo $gradephe71;  ?>" /><input type="text" name="ssphescore72" value="<?php echo $ssphescore72;  ?>" /><input type="text" name="gradephe72" value="<?php echo $gradephe72;  ?>" /><input type="text" name="ttphescore73" value="<?php echo $ttphescore73;  ?>" /><input type="text" name="gradephe73" value="<?php echo $gradephe73;  ?>" />
<input type="text" name="ffphescore81" value="<?php echo $ffphescore81;  ?>" /><input type="text" name="gradephe81" value="<?php echo $gradephe81;  ?>" /><input type="text" name="ssphescore82" value="<?php echo $ssphescore82;  ?>" /><input type="text" name="gradephe82" value="<?php echo $gradephe82;  ?>" /><input type="text" name="ttphescore83" value="<?php echo $ttphescore83;  ?>" /><input type="text" name="gradephe83" value="<?php echo $gradephe83;  ?>" />
<input type="text" name="ffphescore91" value="<?php echo $ffphescore91;  ?>" /><input type="text" name="gradephe91" value="<?php echo $gradephe91;  ?>" /><input type="text" name="ssphescore92" value="<?php echo $ssphescore92;  ?>" /><input type="text" name="gradephe92" value="<?php echo $gradephe92;  ?>" /><input type="text" name="ttphescore93" value="<?php echo $ttphescore93;  ?>" /><input type="text" name="gradephe93" value="<?php echo $gradephe93;  ?>" />
<input style="background-color:orange;" type="text" name="ffphescore101" value="<?php echo $ffphescore101;  ?>" /><input type="text" name="gradephe101" value="<?php echo $gradephe101;  ?>" /><input style="background-color:orange;"  type="text" name="ssphescore102" value="<?php echo $ssphescore102;  ?>" /><input type="text" name="gradephe102" value="<?php echo $gradephe102;  ?>" /><input type="text" name="ttphescore103" value="<?php echo $ttphescore103;  ?>" /><input type="text" name="gradephe103" value="<?php echo $gradephe103;  ?>" />
<input type="text" name="ffphescore111" value="<?php echo $ffphescore111;  ?>" /><input type="text" name="gradephe111" value="<?php echo $gradephe111;  ?>" /><input type="text" name="ssphescore112" value="<?php echo $ssphescore112;  ?>" /><input type="text" name="gradephe112" value="<?php echo $gradephe112;  ?>" /><input type="text" name="ttphescore113" value="<?php echo $ttphescore113;  ?>" /><input type="text" name="gradephe113" value="<?php echo $gradephe113;  ?>" />
<input type="text" name="ffphescore121" value="<?php echo $ffphescore121;  ?>" /><input type="text" name="gradephe121" value="<?php echo $gradephe121;  ?>" /><input type="text" name="ssphescore122" value="<?php echo $ssphescore122;  ?>" /><input type="text" name="gradephe122" value="<?php echo $gradephe122;  ?>" /><input type="text" name="ttphescore123" value="<?php echo $ttphescore123;  ?>" /><input type="text" name="gradephe123" value="<?php echo $gradephe123;  ?>" />

<input style="background-color:orange;" type="text" name="ffphyscore101" value="<?php echo $ffphyscore101;  ?>" /><input type="text" name="gradephy101" value="<?php echo $gradephy101;  ?>" /><input style="background-color:orange;"  type="text" name="ssphyscore102" value="<?php echo $ssphyscore102;  ?>" /><input type="text" name="gradephy102" value="<?php echo $gradephy102;  ?>" /><input type="text" name="ttphyscore103" value="<?php echo $ttphyscore103;  ?>" /><input type="text" name="gradephy103" value="<?php echo $gradephy103;  ?>" />
<input type="text" name="ffphyscore111" value="<?php echo $ffphyscore111;  ?>" /><input type="text" name="gradephy111" value="<?php echo $gradephy111;  ?>" /><input type="text" name="ssphyscore112" value="<?php echo $ssphyscore112;  ?>" /><input type="text" name="gradephy112" value="<?php echo $gradephy112;  ?>" /><input type="text" name="ttphyscore113" value="<?php echo $ttphyscore113;  ?>" /><input type="text" name="gradephy113" value="<?php echo $gradephy113;  ?>" />
<input type="text" name="ffphyscore121" value="<?php echo $ffphyscore121;  ?>" /><input type="text" name="gradephy121" value="<?php echo $gradephy121;  ?>" /><input type="text" name="ssphyscore122" value="<?php echo $ssphyscore122;  ?>" /><input type="text" name="gradephy122" value="<?php echo $gradephy122;  ?>" /><input type="text" name="ttphyscore123" value="<?php echo $ttphyscore123;  ?>" /><input type="text" name="gradephy123" value="<?php echo $gradephy123;  ?>" />

<input style="background-color:orange;" type="text" name="ffsociscore101" value="<?php echo $ffsociscore101;  ?>" /><input type="text" name="gradesoci101" value="<?php echo $gradesoci101;  ?>" /><input style="background-color:orange;"  type="text" name="sssociscore102" value="<?php echo $sssociscore102;  ?>" /><input type="text" name="gradesoci102" value="<?php echo $gradesoci102;  ?>" /><input type="text" name="ttsociscore103" value="<?php echo $ttsociscore103;  ?>" /><input type="text" name="gradesoci103" value="<?php echo $gradesoci103;  ?>" />
<input type="text" name="ffsociscore111" value="<?php echo $ffsociscore111;  ?>" /><input type="text" name="gradesoci111" value="<?php echo $gradesoci111;  ?>" /><input type="text" name="sssociscore112" value="<?php echo $sssociscore112;  ?>" /><input type="text" name="gradesoci112" value="<?php echo $gradesoci112;  ?>" /><input type="text" name="ttsociscore113" value="<?php echo $ttsociscore113;  ?>" /><input type="text" name="gradesoci113" value="<?php echo $gradesoci113;  ?>" />
<input type="text" name="ffsociscore121" value="<?php echo $ffsociscore121;  ?>" /><input type="text" name="gradesoci121" value="<?php echo $gradesoci121;  ?>" /><input type="text" name="sssociscore122" value="<?php echo $sssociscore122;  ?>" /><input type="text" name="gradesoci122" value="<?php echo $gradesoci122;  ?>" /><input type="text" name="ttsociscore123" value="<?php echo $ttsociscore123;  ?>" /><input type="text" name="gradesoci123" value="<?php echo $gradesoci123;  ?>" />

<input style="background-color:orange;" type="text" name="fftdscore101" value="<?php echo $fftdscore101;  ?>" /><input type="text" name="gradetd101" value="<?php echo $gradetd101;  ?>" /><input style="background-color:orange;"  type="text" name="sstdscore102" value="<?php echo $sstdscore102;  ?>" /><input type="text" name="gradetd102" value="<?php echo $gradetd102;  ?>" /><input type="text" name="tttdscore103" value="<?php echo $tttdscore103;  ?>" /><input type="text" name="gradetd103" value="<?php echo $gradetd103;  ?>" />
<input type="text" name="fftdscore111" value="<?php echo $fftdscore111;  ?>" /><input type="text" name="gradetd111" value="<?php echo $gradetd111;  ?>" /><input type="text" name="sstdscore112" value="<?php echo $sstdscore112;  ?>" /><input type="text" name="gradetd112" value="<?php echo $gradetd112;  ?>" /><input type="text" name="tttdscore113" value="<?php echo $tttdscore113;  ?>" /><input type="text" name="gradetd113" value="<?php echo $gradetd113;  ?>" />
<input type="text" name="fftdscore121" value="<?php echo $fftdscore121;  ?>" /><input type="text" name="gradetd121" value="<?php echo $gradetd121;  ?>" /><input type="text" name="sstdscore122" value="<?php echo $sstdscore122;  ?>" /><input type="text" name="gradetd122" value="<?php echo $gradetd122;  ?>" /><input type="text" name="tttdscore123" value="<?php echo $tttdscore123;  ?>" /><input type="text" name="gradetd123" value="<?php echo $gradetd123;  ?>" />

<input style="background-color:orange;" type="text" name="ffvascore101" value="<?php echo $ffvascore101;  ?>" /><input type="text" name="gradeva101" value="<?php echo $gradeva101;  ?>" /><input style="background-color:orange;"  type="text" name="ssvascore102" value="<?php echo $ssvascore102;  ?>" /><input type="text" name="gradeva102" value="<?php echo $gradeva102;  ?>" /><input type="text" name="ttvascore103" value="<?php echo $ttvascore103;  ?>" /><input type="text" name="gradeva103" value="<?php echo $gradeva103;  ?>" />
<input type="text" name="ffvascore111" value="<?php echo $ffvascore111;  ?>" /><input type="text" name="gradeva111" value="<?php echo $gradeva111;  ?>" /><input type="text" name="ssvascore112" value="<?php echo $ssvascore112;  ?>" /><input type="text" name="gradeva112" value="<?php echo $gradeva112;  ?>" /><input type="text" name="ttvascore113" value="<?php echo $ttvascore113;  ?>" /><input type="text" name="gradeva113" value="<?php echo $gradeva113;  ?>" />
<input type="text" name="ffvascore121" value="<?php echo $ffvascore121;  ?>" /><input type="text" name="gradeva121" value="<?php echo $gradeva121;  ?>" /><input type="text" name="ssvascore122" value="<?php echo $ssvascore122;  ?>" /><input type="text" name="gradeva122" value="<?php echo $gradeva122;  ?>" /><input type="text" name="ttvascore123" value="<?php echo $ttvascore123;  ?>" /><input type="text" name="gradeva123" value="<?php echo $gradeva123;  ?>" />

<input type="submit" name="submit" value="GENERATE PDF" />
</form>
<a href="index.php">HOME</a>
<?php }} ?>
</body>