<?php
session_start();
include("auth.php");
include ("connection.php");
$id=$_REQUEST['id']; 
							


 $checkimg = mysqli_query($db, "SELECT * FROM attend where id='$id'");
		while($rowimg = mysqli_fetch_assoc($checkimg))
							{
								$student_name2[] = $rowimg['student_name'];
								$class2[] = $rowimg['class'];
								$arms2[] = $rowimg['arms'];
								$year2[] = $rowimg['year'];
								$term2[] = $rowimg['term'];
								$datename2[] = $rowimg['datename'];
								$formt2[] = $rowimg['formt'];
								$school2[] = $rowimg['school'];
							}
							$st = current($student_name2);
							$cl = current($class2);
							$ar = current($arms2);
							$ye = current($year2);
							$te = current($term2);
							$da = current($datename2);
							$fo = current($formt2);
							$sc = current($school2);

$query = mysqli_query($db,"DELETE FROM attend WHERE student_name='$st' AND class='$cl' AND arms='$ar' AND year='$ye' AND term='$te' AND datename='$da' AND formt='$fo' AND school='$sc'");

		if (!$query)
			{
			echo '<img src="../images/492.png" /> &nbsp;! attendance not deleted';
			echo '<meta content="2;upatt.php" http-equiv="refresh" />';	
			}else{
			echo '<img src="../images/492.png" /> &nbsp;! attendance deleted successfully';
	
	$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
							
	if(($ctype=="Js")OR($ctype=="Primary")){
	if($cl=="Year 1"){
		$cll = "Primary 1";
	}
	else if($cl=="Year 2"){
		$cll = "Primary 2";
	}
	else if($cl=="Year 3"){
		$cll = "Primary 3";
	}
	else if($cl=="Year 4"){
		$cll = "Primary 4";
	}
	else if($cl=="Year 5"){
		$cll = "Primary 5";
	}
	else if($cl=="Year 6"){
		$cll = "Primary 6";
	}
	else if($cl=="Year 7"){
		$cll = "JS1";
	}
	else if($cl=="Year 8"){
		$cll = "JS2";
	}
	else if($cl=="Year 9"){
		$cll = "JS3";
	}
	else if($cl=="Year 10"){
		$cll = "SS1";
	}
	else if($cl=="Year 11"){
		$cll = "SS2";
	}
	else if($cl=="Year 12"){
		$cll = "SS3";
	}
	else{ $cll = "NA"; }
}else{ $cll = $cl; }		
			
			
			
				echo '<form action="upatt.php" method="post">';
echo '<input style="display: none;" readonly="readonly" type="text" id="formt" name="formt" value="'.$fo.'" />';
echo '<input readonly="readonly" type="text" id="class" name="classe" value="'.$cll.'" />';
echo '<input style="display: none;" readonly="readonly" type="text" id="arms" name="arms" value="'.$ar.'" />';
echo '<input style="display: none;" readonly="readonly" type="text" id="year" name="year" value="'.$ye.'" />'; 
echo '<input style="display: none;" readonly="readonly" type="text" id="term" name="term" value="'.$te.'" />';
echo '<input readonly="readonly" type="text" name="good" value="good" />';
echo '<input type="submit" style="background-color: green; color: white;" class="button" name="bt-upload2" value="Return to list of students in class." />';
echo '</form>';
			}
?>
