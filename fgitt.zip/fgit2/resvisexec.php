<?php
session_start();
	include("auth.php");
	include("connection.php"); 
 $student_name = $_POST['student_name'];
  $year = $_POST['year'];
   $class = $_POST['class_name'];
   $term = $_POST['term'];
   $arms = $_POST['arms'];
   $subject = $_POST['subject'];
   $resvisval = $_POST['resvisval'];
   if($resvisval==""){
	   $resvisval=1;
   }else{
	   $resvisval=0;
   }
  $query = "UPDATE scores SET resvis='$resvisval' WHERE student_name='$student_name' AND class_name='$class' AND term='$term' AND year='$year' AND school='".$_SESSION["school"]."'";  
      $result = mysqli_query($db, $query);  
 if($result){
	 $query2 = "SELECT resvis FROM scores WHERE student_name='$student_name' AND class_name='$class' AND term='$term' AND year='$year' AND school='".$_SESSION["school"]."'";  
	 $result2 = mysqli_query($db, $query2); 
	 while($rowtnames = mysqli_fetch_assoc($result2))
	{
$rt2[] = $rowtnames['resvis'];
	}
$rt = current($rt2);	
if($rt==1){
	$r = "visible";
}else{
	$r = "hidden";
}
	 echo "Result visibility altered. It is set to ".$r.".";
 }else{
	 echo "Result visibility could NOT be altered.";
 }
?>