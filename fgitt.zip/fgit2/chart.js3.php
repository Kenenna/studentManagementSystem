<?php
session_start();
include("auth.php");
include "connection.php";
$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
require 'class/ChartJS.php';
require 'class/ChartJS_Line.php';
require 'class/ChartJS_Bar.php';
require 'class/ChartJS_Radar.php';
require 'class/ChartJS_PolarArea.php';
require 'class/ChartJS_Pie.php';
require 'class/ChartJS_Doughnut.php';


//$y7fchart = $_POST['y7fchart'];
//$y7schart = $_POST['y7schart'];
//$y7tchart = $_POST['y7tchart'];


ChartJS::addDefaultColor(array('fill' => '#f2b21a', 'stroke' => '#e5801d', 'point' => '#e5801d', 'pointStroke' => '#e5801d'));
ChartJS::addDefaultColor(array('fill' => 'rgba(28,116,190,.8)', 'stroke' => '#1c74be', 'point' => '#1c74be', 'pointStroke' => '#1c74be'));
ChartJS::addDefaultColor(array('fill' => 'rgba(212,41,31,.7)', 'stroke' => '#d4291f', 'point' => '#d4291f', 'pointStroke' => '#d4291f'));
ChartJS::addDefaultColor(array('fill' => '#dc693c', 'stroke' => '#ff0000', 'point' => '#ff0000', 'pointStroke' => '#ff0000'));
ChartJS::addDefaultColor(array('fill' => 'rgba(46,204,113,.8)', 'stroke' => '#2ecc71', 'point' => '#2ecc71', 'pointStroke' => '#2ecc71'));
$class = $_POST['cla'];	
$stuname = $_POST['stuname'];
$subj = $_POST['subj'];
$class = $_POST['cla'];		
$year = $_POST['yr'];	
$term = $_POST['tm'];	
$arms = $_POST['arms'];


if($class == 'Year 1'){
$stuname = $_POST['stuname'];
$subj = $_POST['subj'];
$class = $_POST['cla'];	
$sig = $_POST['sig'];	
$resultclname = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rowclname = mysqli_fetch_assoc($resultclname))
							{  
								$clname2[] = $rowclname['class_name'];
							}	
							$clname = $clname2;
$y7arr = $_POST['y7arr'];
if($ctype == "Primary"){
	foreach($clname as $clnamee)
{
 if($clnamee=="Year 1"){ $clnamee="Primary 1"; }
 else if($clnamee=="Year 2"){ $clnamee="Primary 2"; }
 else if($clnamee=="Year 3"){ $clnamee="Primary 3"; }
 else if($clnamee=="Year 4"){ $clnamee="Primary 4"; }
 else if($clnamee=="Year 5"){ $clnamee="Primary 5"; }
 else{ $clnamee="Primary 6"; }
 $clnameeee[] = $clnamee;
}
$clnameee = $clnameeee;
$array_labels = $clnameee;
}
else{
$clnameee = $clname;	
$array_labels = $clnameee;
}

$y7arr = str_replace("[","",$y7arr);
$y7arr = str_replace("]","",$y7arr);
$y7arr = str_replace("\"","",$y7arr);

$yfst = explode(",",$y7arr);
$yff = array_fill(0, 1, $yfst[0]);
$yss = array_fill(0, 1, $yfst[1]);
$ytt = array_fill(0, 1, $yfst[2]);

$ffcount = count($yff);
$sscount = count($yss);
$ttcount = count($ytt);

$array_values = array($yff,$yss,$ytt);

$cc = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($r2 = mysqli_fetch_assoc($cc))
							{  
								$c2[] = $r2['class_name'];
							}	
							$c = $c2;

$ccount = count($c);
$cff_diff = $ccount - ($ffcount);
for ($i = 0; $i <= ((count($c)-1)-$cff_diff); $i++){
	$array_labelss[] = $array_labels[$i];
}

$yye1 = array($yff[0],$yss[0],$ytt[0]);

$Bar = new ChartJS_Bar('example_bar', 800, 500);
$Bar->addBars($array_values[0]);
$Bar->addBars($array_values[1]);
$Bar->addBars($array_values[2]);
$Bar->addLabels($array_labelss);
}



else if($class == 'Year 2'){
$stuname = $_POST['stuname'];
$subj = $_POST['subj'];
$class = $_POST['cla'];		
$resultclname = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rowclname = mysqli_fetch_assoc($resultclname))
							{  
								$clname2[] = $rowclname['class_name'];
							}	
							$clname = $clname2;
$y7arr = $_POST['y7arr'];
if(($ctype == "Js")OR($ctype == "Primary")){
	foreach($clname as $clnamee)
{
 if($clnamee=="Year 1"){ $clnamee="Primary 1"; }
 else if($clnamee=="Year 2"){ $clnamee="Primary 2"; }
 else if($clnamee=="Year 3"){ $clnamee="Primary 3"; }
 else if($clnamee=="Year 4"){ $clnamee="Primary 4"; }
 else if($clnamee=="Year 5"){ $clnamee="Primary 5"; }
 else{ $clnamee="Primary 6"; }
 $clnameeee[] = $clnamee;
}
$clnameee = $clnameeee;
$array_labels = $clnameee;
}
else{
$clnameee = $clname;	
$array_labels = $clnameee;
}

$y7arr = str_replace("[","",$y7arr);
$y7arr = str_replace("]","",$y7arr);
$y7arr = str_replace("\"","",$y7arr);
$y7arrr = explode("-",$y7arr);
$yf = $y7arrr[0];
$ys = $y7arrr[1];
$yt = $y7arrr[2];
$yf = rtrim($yf,',');
$ys = rtrim($ys,',');
$ys = ltrim($ys,',');
$yt = ltrim($yt,',');
$yff = explode(",",$yf);
$yss = explode(",",$ys);
$ytt = explode(",",$yt);


$cf1 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 1' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf1 = mysqli_fetch_assoc($cf1))
							{  
								$c11[] = $rf1['class_name'];
							}	
							$cff1 = $c11;
$cf2 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 2' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf2 = mysqli_fetch_assoc($cf2))
							{  
								$c22[] = $rf2['class_name'];
							}	
							$cff2 = $c22;
if(count($cff1)==0){
array_unshift($yff,0);
}	
if(count($cff2)==0){
array_push($yff,0);
}

$cs1 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 1' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs1 = mysqli_fetch_assoc($cs1))
							{  
								$c111[] = $rs1['class_name'];
							}	
							$css1 = $c111;
$cs2 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 2' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs2 = mysqli_fetch_assoc($cs2))
							{  
								$c222[] = $rs2['class_name'];
							}	
							$css2 = $c222;
if(count($css1)==0){
array_unshift($yss,0);
}	
if(count($css2)==0){
array_push($yss,0);
}

$ct1 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 1' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt1 = mysqli_fetch_assoc($ct1))
							{  
								$c1111[] = $rt1['class_name'];
							}	
							$ctt1 = $c1111;
$ct2 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 2' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt2 = mysqli_fetch_assoc($ct2))
							{  
								$c2222[] = $rt2['class_name'];
							}	
							$ctt2 = $c2222;
if(count($ctt1)==0){
array_unshift($ytt,0);
}	
if(count($ctt2)==0){
array_push($ytt,0);
}


$ffcount = count($yff);
$sscount = count($yss);
$ttcount = count($ytt);
$array_values = array($yff,$yss,$ytt);


$cc = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($r2 = mysqli_fetch_assoc($cc))
							{  
								$c2[] = $r2['class_name'];
							}	
							$c = $c2;

//print_r($yss);
//echo count($css2);

$ccount = count($c);
$cff_diff = $ccount - ($ffcount);
for ($i = 0; $i <= ((count($c)-1)-$cff_diff); $i++){
	$array_labelss[] = $array_labels[$i];
}

$yye1 = array($yff[0],$yss[0],$ytt[0]);
$yye2 = array($yff[1],$yss[1],$ytt[1]);

$Bar = new ChartJS_Bar('example_bar', 800, 500);
$Bar->addBars($array_values[0]);
$Bar->addBars($array_values[1]);
$Bar->addBars($array_values[2]);
$Bar->addLabels($array_labelss);
}




else if($class == 'Year 3'){
$stuname = $_POST['stuname'];
$subj = $_POST['subj'];
$class = $_POST['cla'];		
$resultclname = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rowclname = mysqli_fetch_assoc($resultclname))
							{  
								$clname2[] = $rowclname['class_name'];
							}	
							$clname = $clname2;
$y7arr = $_POST['y7arr'];
if(($ctype == "Js")OR($ctype == "Primary")){
	foreach($clname as $clnamee)
{
 if($clnamee=="Year 1"){ $clnamee="Primary 1"; }
 else if($clnamee=="Year 2"){ $clnamee="Primary 2"; }
 else if($clnamee=="Year 3"){ $clnamee="Primary 3"; }
 else if($clnamee=="Year 4"){ $clnamee="Primary 4"; }
 else if($clnamee=="Year 5"){ $clnamee="Primary 5"; }
 else if($clnamee=="Year 6"){ $clnamee="Primary 6"; }
 elseif($clnamee=="Year 7"){ $clnamee="JS1"; }
 else if($clnamee=="Year 8"){ $clnamee="JS2"; }
 else if($clnamee=="Year 9"){ $clnamee="JS3"; }
 else if($clnamee=="Year 10"){ $clnamee="SS1"; }
 else if($clnamee=="Year 11"){ $clnamee="SS2"; }
 else{ $clnamee="SS3"; }
 $clnameeee[] = $clnamee;
}
$clnameee = $clnameeee;
$array_labels = $clnameee;
}
else{
$clnameee = $clname;	
$array_labels = $clnameee;
}

$y7arr = str_replace("[","",$y7arr);
$y7arr = str_replace("]","",$y7arr);
$y7arr = str_replace("\"","",$y7arr);
$y7arrr = explode("-",$y7arr);
$yf = $y7arrr[0];
$ys = $y7arrr[1];
$yt = $y7arrr[2];
$yf = rtrim($yf,',');
$ys = rtrim($ys,',');
$ys = ltrim($ys,',');
$yt = ltrim($yt,',');
$yff = explode(",",$yf);
$yss = explode(",",$ys);
$ytt = explode(",",$yt);


$cf1 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 1' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf1 = mysqli_fetch_assoc($cf1))
							{  
								$c11[] = $rf1['class_name'];
							}	
							$cff1 = $c11;
$cf2 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 2' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf2 = mysqli_fetch_assoc($cf2))
							{  
								$c22[] = $rf2['class_name'];
							}	
							$cff2 = $c22;
$cf3 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 3' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf3 = mysqli_fetch_assoc($cf3))
							{  
								$c33[] = $rf3['class_name'];
							}	
							$cff3 = $c33;
if(count($cff1)==0){
array_unshift($yff,0);
}	
if(count($cff2)==0){
array_splice($yff,1,0,0);
}
if(count($cff3)==0){
array_push($yff,0);
}
$cs1 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 1' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs1 = mysqli_fetch_assoc($cs1))
							{  
								$c111[] = $rs1['class_name'];
							}	
							$css1 = $c111;
$cs2 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 2' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs2 = mysqli_fetch_assoc($cs2))
							{  
								$c222[] = $rs2['class_name'];
							}	
							$css2 = $c222;
$cs3 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 3' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs3 = mysqli_fetch_assoc($cs3))
							{  
								$c333[] = $rs3['class_name'];
							}	
							$css3 = $c333;
if(count($css1)==0){
array_unshift($yss,0);
}	
if(count($css2)==0){
array_splice($yss,1,0,0);
}
if(count($css3)==0){
array_push($yss,0);
}

$ct1 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 1' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt1 = mysqli_fetch_assoc($ct1))
							{  
								$c1111[] = $rt1['class_name'];
							}	
							$ctt1 = $c1111;
$ct2 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 2' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt2 = mysqli_fetch_assoc($ct2))
							{  
								$c2222[] = $rt2['class_name'];
							}	
							$ctt2 = $c2222;
$ct3 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 3' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt3 = mysqli_fetch_assoc($ct3))
							{  
								$c3333[] = $rt3['class_name'];
							}	
							$ctt3 = $c3333;
if(count($ctt1)==0){
array_unshift($ytt,0);
}	
if(count($ctt2)==0){
array_splice($ytt,1,0,0);
}
if(count($ctt3)==0){
array_push($ytt,0);
}

$array_values = array($yff,$yss,$ytt);

$cc = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($r2 = mysqli_fetch_assoc($cc))
							{  
								$c2[] = $r2['class_name'];
							}	
							$c = $c2;	
$ffcount = count($yff);
$ccount = count($c);
$cff_diff = $ccount - $ffcount;
for ($i = 0; $i <= ((count($c)-1)-$cff_diff); $i++){
	$array_labelss[] = $array_labels[$i];
}


$yye1 = array($yff[0],$yss[0],$ytt[0]);
$yye2 = array($yff[1],$yss[1],$ytt[1]);
$yye3 = array($yff[2],$yss[2],$ytt[2]);

$Bar = new ChartJS_Bar('example_bar', 800, 500);
$Bar->addBars($array_values[0]);
$Bar->addBars($array_values[1]);
$Bar->addBars($array_values[2]);
$Bar->addLabels($array_labelss);
}




elseif($class == 'Year 4'){
$stuname = $_POST['stuname'];
$subj = $_POST['subj'];
$class = $_POST['cla'];		
$resultclname = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rowclname = mysqli_fetch_assoc($resultclname))
							{  
								$clname2[] = $rowclname['class_name'];
							}	
							$clname = $clname2;	
$y7arr = $_POST['y7arr'];
if(($ctype == "Js")||($ctype == "Primary")){
	foreach($clname as $clnamee)
{
 if($clnamee=="Year 1"){ $clnamee="Primary 1"; }
 else if($clnamee=="Year 2"){ $clnamee="Primary 2"; }
 else if($clnamee=="Year 3"){ $clnamee="Primary 3"; }
 else if($clnamee=="Year 4"){ $clnamee="Primary 4"; }
 else if($clnamee=="Year 5"){ $clnamee="Primary 5"; }
 else if($clnamee=="Year 6"){ $clnamee="Primary 6"; }
 elseif($clnamee=="Year 7"){ $clnamee="JS1"; }
 else if($clnamee=="Year 8"){ $clnamee="JS2"; }
 else if($clnamee=="Year 9"){ $clnamee="JS3"; }
 else if($clnamee=="Year 10"){ $clnamee="SS1"; }
 else if($clnamee=="Year 11"){ $clnamee="SS2"; }
 else{ $clnamee="SS3"; }
 $clnameeee[] = $clnamee;
}
$clnameee = $clnameeee;
$array_labels = $clnameee;
}
else{
$clnameee = $clname;	
$array_labels = $clnameee;
}

$y7arr = str_replace("[","",$y7arr);
$y7arr = str_replace("]","",$y7arr);
$y7arr = str_replace("\"","",$y7arr);
$y7arrr = explode("-",$y7arr);
$yf = $y7arrr[0];
$ys = $y7arrr[1];
$yt = $y7arrr[2];
$yf = rtrim($yf,',');
$ys = rtrim($ys,',');
$ys = ltrim($ys,',');
$yt = ltrim($yt,',');
$yff = explode(",",$yf);
$yss = explode(",",$ys);
$ytt = explode(",",$yt);

$cf1 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 1' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf1 = mysqli_fetch_assoc($cf1))
							{  
								$c11[] = $rf1['class_name'];
							}	
							$cff1 = $c11;
$cf2 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 2' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf2 = mysqli_fetch_assoc($cf2))
							{  
								$c22[] = $rf2['class_name'];
							}	
							$cff2 = $c22;
$cf3 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 3' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf3 = mysqli_fetch_assoc($cf3))
							{  
								$c33[] = $rf3['class_name'];
							}	
							$cff3 = $c33;
$cf4 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 4' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf4 = mysqli_fetch_assoc($cf4))
							{  
								$c44[] = $rf4['class_name'];
							}	
							$cff4 = $c44;
if(count($cff1)==0){
array_unshift($yff,0);
}	
if(count($cff2)==0){
array_splice($yff,1,0,0);
}
if(count($cff3)==0){
array_splice($yff,2,0,0);
}
if(count($cff4)==0){
array_push($yff,0);
}
$cs1 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 1' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs1 = mysqli_fetch_assoc($cs1))
							{  
								$c111[] = $rs1['class_name'];
							}	
							$css1 = $c111;
$cs2 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 2' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs2 = mysqli_fetch_assoc($cs2))
							{  
								$c222[] = $rs2['class_name'];
							}	
							$css2 = $c222;
$cs3 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 3' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs3 = mysqli_fetch_assoc($cs3))
							{  
								$c333[] = $rs3['class_name'];
							}	
							$css3 = $c333;
$cs4 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 4' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs4 = mysqli_fetch_assoc($cs4))
							{  
								$c444[] = $rs4['class_name'];
							}	
							$css4 = $c444;
if(count($css1)==0){
array_unshift($yss,0);
}	
if(count($css2)==0){
array_splice($yss,1,0,0);
}
if(count($css3)==0){
array_splice($yss,2,0,0);
}
if(count($css4)==0){
array_push($yss,0);
}

$ct1 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 1' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt1 = mysqli_fetch_assoc($ct1))
							{  
								$c1111[] = $rt1['class_name'];
							}	
							$ctt1 = $c1111;
$ct2 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 2' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt2 = mysqli_fetch_assoc($ct2))
							{  
								$c2222[] = $rt2['class_name'];
							}	
							$ctt2 = $c2222;
$ct3 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 3' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt3 = mysqli_fetch_assoc($ct3))
							{  
								$c3333[] = $rt3['class_name'];
							}	
							$ctt3 = $c3333;
$ct4 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 4' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt4 = mysqli_fetch_assoc($ct4))
							{  
								$c4444[] = $rt4['class_name'];
							}	
							$ctt4 = $c4444;
if(count($ctt1)==0){
array_unshift($ytt,0);
}	
if(count($ctt2)==0){
array_splice($ytt,1,0,0);
}
if(count($ctt3)==0){
array_splice($ytt,2,0,0);
}
if(count($ctt4)==0){
array_push($ytt,0);
}

$array_values = array($yff,$yss,$ytt);

$cc = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($r2 = mysqli_fetch_assoc($cc))
							{  
								$c2[] = $r2['class_name'];
							}	
							$c = $c2;	
$ffcount = count($yff);
$ccount = count($c);
$cff_diff = $ccount - $ffcount;
for ($i = 0; $i <= ((count($c)-1)-$cff_diff); $i++){
	$array_labelss[] = $array_labels[$i];
}

$yye1 = array($yff[0],$yss[0],$ytt[0]);
$yye2 = array($yff[1],$yss[1],$ytt[1]);
$yye3 = array($yff[2],$yss[2],$ytt[2]);
$yye4 = array($yff[3],$yss[3],$ytt[3]);

$Bar = new ChartJS_Bar('example_bar', 800, 500);
$Bar->addBars($array_values[0]);
$Bar->addBars($array_values[1]);
$Bar->addBars($array_values[2]);
$Bar->addLabels($array_labelss);
}







elseif($class == 'Year 5'){
$stuname = $_POST['stuname'];
$subj = $_POST['subj'];
$class = $_POST['cla'];		
$resultclname = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rowclname = mysqli_fetch_assoc($resultclname))
							{  
								$clname2[] = $rowclname['class_name'];
							}	
							$clname = $clname2;
$y7arr = $_POST['y7arr'];
if(($ctype == "Js")||($ctype == "Primary")){
	foreach($clname as $clnamee)
{
 if($clnamee=="Year 1"){ $clnamee="Primary 1"; }
 else if($clnamee=="Year 2"){ $clnamee="Primary 2"; }
 else if($clnamee=="Year 3"){ $clnamee="Primary 3"; }
 else if($clnamee=="Year 4"){ $clnamee="Primary 4"; }
 else if($clnamee=="Year 5"){ $clnamee="Primary 5"; }
 else if($clnamee=="Year 6"){ $clnamee="Primary 6"; }
 elseif($clnamee=="Year 7"){ $clnamee="JS1"; }
 else if($clnamee=="Year 8"){ $clnamee="JS2"; }
 else if($clnamee=="Year 9"){ $clnamee="JS3"; }
 else if($clnamee=="Year 10"){ $clnamee="SS1"; }
 else if($clnamee=="Year 11"){ $clnamee="SS2"; }
 else{ $clnamee="SS3"; }
 $clnameeee[] = $clnamee;
}
$clnameee = $clnameeee;
$array_labels = $clnameee;
}
else{
$clnameee = $clname;	
$array_labels = $clnameee;
}

$y7arr = str_replace("[","",$y7arr);
$y7arr = str_replace("]","",$y7arr);
$y7arr = str_replace("\"","",$y7arr);
$y7arrr = explode("-",$y7arr);
$yf = $y7arrr[0];
$ys = $y7arrr[1];
$yt = $y7arrr[2];
$yf = rtrim($yf,',');
$ys = rtrim($ys,',');
$ys = ltrim($ys,',');
$yt = ltrim($yt,',');
$yff = explode(",",$yf);
$yss = explode(",",$ys);
$ytt = explode(",",$yt);

$cf1 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 1' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf1 = mysqli_fetch_assoc($cf1))
							{  
								$c11[] = $rf1['class_name'];
							}	
							$cff1 = $c11;
$cf2 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 2' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf2 = mysqli_fetch_assoc($cf2))
							{  
								$c22[] = $rf2['class_name'];
							}	
							$cff2 = $c22;
$cf3 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 3' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf3 = mysqli_fetch_assoc($cf3))
							{  
								$c33[] = $rf3['class_name'];
							}	
							$cff3 = $c33;
$cf4 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 4' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf4 = mysqli_fetch_assoc($cf4))
							{  
								$c44[] = $rf4['class_name'];
							}	
							$cff4 = $c44;
$cf5 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 5' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf5 = mysqli_fetch_assoc($cf5))
							{  
								$c55[] = $rf5['class_name'];
							}	
							$cff5 = $c55;
if(count($cff1)==0){
array_unshift($yff,0);
}	
if(count($cff2)==0){
array_splice($yff,1,0,0);
}
if(count($cff3)==0){
array_splice($yff,2,0,0);
}
if(count($cff4)==0){
array_splice($yff,3,0,0);
}
if(count($cff5)==0){
array_push($yff,0);
}
$cs1 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 1' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs1 = mysqli_fetch_assoc($cs1))
							{  
								$c111[] = $rs1['class_name'];
							}	
							$css1 = $c111;
$cs2 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 2' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs2 = mysqli_fetch_assoc($cs2))
							{  
								$c222[] = $rs2['class_name'];
							}	
							$css2 = $c222;
$cs3 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 3' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs3 = mysqli_fetch_assoc($cs3))
							{  
								$c333[] = $rs3['class_name'];
							}	
							$css3 = $c333;
$cs4 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 4' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs4 = mysqli_fetch_assoc($cs4))
							{  
								$c444[] = $rs4['class_name'];
							}	
							$css4 = $c444;
$cs5 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 5' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs5 = mysqli_fetch_assoc($cs5))
							{  
								$c555[] = $rs5['class_name'];
							}	
							$css5 = $c555;
if(count($css1)==0){
array_unshift($yss,0);
}	
if(count($css2)==0){
array_splice($yss,1,0,0);
}
if(count($css3)==0){
array_splice($yss,2,0,0);
}
if(count($css4)==0){
array_splice($yss,3,0,0);
}
if(count($css5)==0){
array_push($yss,0);
}

$ct1 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 1' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt1 = mysqli_fetch_assoc($ct1))
							{  
								$c1111[] = $rt1['class_name'];
							}	
							$ctt1 = $c1111;
$ct2 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 2' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt2 = mysqli_fetch_assoc($ct2))
							{  
								$c2222[] = $rt2['class_name'];
							}	
							$ctt2 = $c2222;
$ct3 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 3' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt3 = mysqli_fetch_assoc($ct3))
							{  
								$c3333[] = $rt3['class_name'];
							}	
							$ctt3 = $c3333;
$ct4 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 4' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt4 = mysqli_fetch_assoc($ct4))
							{  
								$c4444[] = $rt4['class_name'];
							}	
							$ctt4 = $c4444;
$ct5 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 5' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt5 = mysqli_fetch_assoc($ct5))
							{  
								$c5555[] = $rt5['class_name'];
							}	
							$ctt5 = $c5555;
							
if(count($ctt1)==0){
array_unshift($ytt,0);
}	
if(count($ctt2)==0){
array_splice($ytt,1,0,0);
}
if(count($ctt3)==0){
array_splice($ytt,2,0,0);
}
if(count($ctt4)==0){
array_splice($ytt,3,0,0);
}
if(count($ctt5)==0){
array_push($ytt,0);
}


$array_values = array($yff,$yss,$ytt);

$cc = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($r2 = mysqli_fetch_assoc($cc))
							{  
								$c2[] = $r2['class_name'];
							}	
							$c = $c2;	
$ffcount = count($yff);
$ccount = count($c);
$cff_diff = $ccount - $ffcount;
for ($i = 0; $i <= ((count($c)-1)-$cff_diff); $i++){
	$array_labelss[] = $array_labels[$i];
}


$yye1 = array($yff[0],$yss[0],$ytt[0]);
$yye2 = array($yff[1],$yss[1],$ytt[1]);
$yye3 = array($yff[2],$yss[2],$ytt[2]);
$yye4 = array($yff[3],$yss[3],$ytt[3]);
$yye5 = array($yff[4],$yss[4],$ytt[4]);

$Bar = new ChartJS_Bar('example_bar', 800, 500);
$Bar->addBars($array_values[0]);
$Bar->addBars($array_values[1]);
$Bar->addBars($array_values[2]);
$Bar->addLabels($array_labelss);
}





elseif($class == 'Year 6'){
$stuname = $_POST['stuname'];
$subj = $_POST['subj'];
$class = $_POST['cla'];		
$resultclname = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rowclname = mysqli_fetch_assoc($resultclname))
							{  
								$clname2[] = $rowclname['class_name'];
							}	
							$clname = $clname2;
							
$y7arr = $_POST['y7arr'];
if(($ctype == "Js")||($ctype == "Primary")){
	foreach($clname as $clnamee)
{
 if($clnamee=="Year 1"){ $clnamee="Primary 1"; }
 else if($clnamee=="Year 2"){ $clnamee="Primary 2"; }
 else if($clnamee=="Year 3"){ $clnamee="Primary 3"; }
 else if($clnamee=="Year 4"){ $clnamee="Primary 4"; }
 else if($clnamee=="Year 5"){ $clnamee="Primary 5"; }
 else if($clnamee=="Year 6"){ $clnamee="Primary 6"; }
 elseif($clnamee=="Year 7"){ $clnamee="JS1"; }
 else if($clnamee=="Year 8"){ $clnamee="JS2"; }
 else if($clnamee=="Year 9"){ $clnamee="JS3"; }
 else if($clnamee=="Year 10"){ $clnamee="SS1"; }
 else if($clnamee=="Year 11"){ $clnamee="SS2"; }
 else{ $clnamee="SS3"; }
 $clnameeee[] = $clnamee;
}
$clnameee = $clnameeee;
$array_labels = $clnameee;
}
else{
$clnameee = $clname;	
$array_labels = $clnameee;
}

$y7arr = str_replace("[","",$y7arr);
$y7arr = str_replace("]","",$y7arr);
$y7arr = str_replace("\"","",$y7arr);
$y7arrr = explode("-",$y7arr);
$yf = $y7arrr[0];
$ys = $y7arrr[1];
$yt = $y7arrr[2];
$yf = rtrim($yf,',');
$ys = rtrim($ys,',');
$ys = ltrim($ys,',');
$yt = ltrim($yt,',');
$yff = explode(",",$yf);
$yss = explode(",",$ys);
$ytt = explode(",",$yt);


$cf1 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 1' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf1 = mysqli_fetch_assoc($cf1))
							{  
								$c11[] = $rf1['class_name'];
							}	
							$cff1 = $c11;
$cf2 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 2' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf2 = mysqli_fetch_assoc($cf2))
							{  
								$c22[] = $rf2['class_name'];
							}	
							$cff2 = $c22;
$cf3 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 3' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf3 = mysqli_fetch_assoc($cf3))
							{  
								$c33[] = $rf3['class_name'];
							}	
							$cff3 = $c33;
$cf4 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 4' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf4 = mysqli_fetch_assoc($cf4))
							{  
								$c44[] = $rf4['class_name'];
							}	
							$cff4 = $c44;
$cf5 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 5' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf5 = mysqli_fetch_assoc($cf5))
							{  
								$c55[] = $rf5['class_name'];
							}	
							$cff5 = $c55;
$cf6 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 6' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf6 = mysqli_fetch_assoc($cf6))
							{  
								$c66[] = $rf6['class_name'];
							}	
							$cff6 = $c66;
if(count($cff1)==0){
array_unshift($yff,0);
}	
if(count($cff2)==0){
array_splice($yff,1,0,0);
}
if(count($cff3)==0){
array_splice($yff,2,0,0);
}
if(count($cff4)==0){
array_splice($yff,3,0,0);
}
if(count($cff5)==0){
array_splice($yff,4,0,0);
}
if(count($cff6)==0){
array_push($yff,0);
}
$cs1 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 1' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs1 = mysqli_fetch_assoc($cs1))
							{  
								$c111[] = $rs1['class_name'];
							}	
							$css1 = $c111;
$cs2 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 2' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs2 = mysqli_fetch_assoc($cs2))
							{  
								$c222[] = $rs2['class_name'];
							}	
							$css2 = $c222;
$cs3 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 3' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs3 = mysqli_fetch_assoc($cs3))
							{  
								$c333[] = $rs3['class_name'];
							}	
							$css3 = $c333;
$cs4 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 4' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs4 = mysqli_fetch_assoc($cs4))
							{  
								$c444[] = $rs4['class_name'];
							}	
							$css4 = $c444;
$cs5 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 5' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs5 = mysqli_fetch_assoc($cs5))
							{  
								$c555[] = $rs5['class_name'];
							}	
							$css5 = $c555;
$cs6 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 6' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs6 = mysqli_fetch_assoc($cs6))
							{  
								$c666[] = $rs6['class_name'];
							}	
							$css6 = $c666;
if(count($css1)==0){
array_unshift($yss,0);
}	
if(count($css2)==0){
array_splice($yss,1,0,0);
}
if(count($css3)==0){
array_splice($yss,2,0,0);
}
if(count($css4)==0){
array_splice($yss,3,0,0);
}
if(count($css5)==0){
array_splice($yss,4,0,0);
}
if(count($css6)==0){
array_push($yss,0);
}

$ct1 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 1' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt1 = mysqli_fetch_assoc($ct1))
							{  
								$c1111[] = $rt1['class_name'];
							}	
							$ctt1 = $c1111;
$ct2 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 2' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt2 = mysqli_fetch_assoc($ct2))
							{  
								$c2222[] = $rt2['class_name'];
							}	
							$ctt2 = $c2222;
$ct3 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 3' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt3 = mysqli_fetch_assoc($ct3))
							{  
								$c3333[] = $rt3['class_name'];
							}	
							$ctt3 = $c3333;
$ct4 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 4' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt4 = mysqli_fetch_assoc($ct4))
							{  
								$c4444[] = $rt4['class_name'];
							}	
							$ctt4 = $c4444;
$ct5 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 5' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt5 = mysqli_fetch_assoc($ct5))
							{  
								$c5555[] = $rt5['class_name'];
							}	
							$ctt5 = $c5555;
$ct6 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 6' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt6 = mysqli_fetch_assoc($ct6))
							{  
								$c6666[] = $rt6['class_name'];
							}	
							$ctt6 = $c6666;							
if(count($ctt1)==0){
array_unshift($ytt,0);
}	
if(count($ctt2)==0){
array_splice($ytt,1,0,0);
}
if(count($ctt3)==0){
array_splice($ytt,2,0,0);
}
if(count($ctt4)==0){
array_splice($ytt,3,0,0);
}
if(count($ctt5)==0){
array_splice($ytt,4,0,0);
}
if(count($ctt6)==0){
array_push($ytt,0);
}

$array_values = array($yff,$yss,$ytt);

$cc = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($r2 = mysqli_fetch_assoc($cc))
							{  
								$c2[] = $r2['class_name'];
							}	
							$c = $c2;	
$ffcount = count($yff);
$ccount = count($c);
$cff_diff = $ccount - $ffcount;
for ($i = 0; $i <= ((count($c)-1)-$cff_diff); $i++){
	$array_labelss[] = $array_labels[$i];
}


$yye1 = array($yff[0],$yss[0],$ytt[0]);
$yye2 = array($yff[1],$yss[1],$ytt[1]);
$yye3 = array($yff[2],$yss[2],$ytt[2]);
$yye4 = array($yff[3],$yss[3],$ytt[3]);
$yye5 = array($yff[4],$yss[4],$ytt[4]);
$yye6 = array($yff[5],$yss[5],$ytt[5]);
$yye7 = array($yff[5],$yss[5],$ytt[5]);
$Bar = new ChartJS_Bar('example_bar', 800, 500);
$Bar->addBars($array_values[0]);
$Bar->addBars($array_values[1]);
$Bar->addBars($array_values[2]);
$Bar->addLabels($array_labelss);
}






elseif($class == 'Year 7'){
$stuname = $_POST['stuname'];
$subj = $_POST['subj'];
$class = $_POST['cla'];	
$sig = $_POST['sig'];	
$resultclname = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rowclname = mysqli_fetch_assoc($resultclname))
							{  
								$clname2[] = $rowclname['class_name'];
							}	
							$clname = $clname2;
$y7arr = $_POST['y7arr'];
if($ctype == "Js"){
	foreach($clname as $clnamee)
{
 if($clnamee=="Year 7"){ $clnamee="JS1"; }
 else if($clnamee=="Year 8"){ $clnamee="JS2"; }
 else if($clnamee=="Year 9"){ $clnamee="JS3"; }
 else if($clnamee=="Year 10"){ $clnamee="SS1"; }
 else if($clnamee=="Year 11"){ $clnamee="SS2"; }
 else{ $clnamee="SS3"; }
 $clnameeee[] = $clnamee;
}
$clnameee = $clnameeee;
$array_labels = $clnameee;
}
else{
$clnameee = $clname;	
$array_labels = $clnameee;
}

$y7arr = str_replace("[","",$y7arr);
$y7arr = str_replace("]","",$y7arr);
$y7arr = str_replace("\"","",$y7arr);

$yfst = explode(",",$y7arr);
$yff = array_fill(0, 1, $yfst[0]);
$yss = array_fill(0, 1, $yfst[1]);
$ytt = array_fill(0, 1, $yfst[2]);

$ffcount = count($yff);
$sscount = count($yss);
$ttcount = count($ytt);

$array_values = array($yff,$yss,$ytt);

$cc = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($r2 = mysqli_fetch_assoc($cc))
							{  
								$c2[] = $r2['class_name'];
							}	
							$c = $c2;

$ccount = count($c);
$cff_diff = $ccount - ($ffcount);
for ($i = 0; $i <= ((count($c)-1)-$cff_diff); $i++){
	$array_labelss[] = $array_labels[$i];
}

$yye7 = array($yff[0],$yss[0],$ytt[0]);

$Bar = new ChartJS_Bar('example_bar', 800, 500);
$Bar->addBars($array_values[0]);
$Bar->addBars($array_values[1]);
$Bar->addBars($array_values[2]);
$Bar->addLabels($array_labelss);
}

else if($class == 'Year 8'){
$stuname = $_POST['stuname'];
$subj = $_POST['subj'];
$class = $_POST['cla'];		
$resultclname = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rowclname = mysqli_fetch_assoc($resultclname))
							{  
								$clname2[] = $rowclname['class_name'];
							}	
							$clname = $clname2;
$y7arr = $_POST['y7arr'];
if($ctype == "Js"){
	foreach($clname as $clnamee)
{
 if($clnamee=="Year 7"){ $clnamee="JS1"; }
 else if($clnamee=="Year 8"){ $clnamee="JS2"; }
 else if($clnamee=="Year 9"){ $clnamee="JS3"; }
 else if($clnamee=="Year 10"){ $clnamee="SS1"; }
 else if($clnamee=="Year 11"){ $clnamee="SS2"; }
 else{ $clnamee="SS3"; }
 $clnameeee[] = $clnamee;
}
$clnameee = $clnameeee;
$array_labels = $clnameee;
}
else{
$clnameee = $clname;	
$array_labels = $clnameee;
}

$y7arr = str_replace("[","",$y7arr);
$y7arr = str_replace("]","",$y7arr);
$y7arr = str_replace("\"","",$y7arr);
$y7arrr = explode("-",$y7arr);
$yf = $y7arrr[0];
$ys = $y7arrr[1];
$yt = $y7arrr[2];
$yf = rtrim($yf,',');
$ys = rtrim($ys,',');
$ys = ltrim($ys,',');
$yt = ltrim($yt,',');
$yff = explode(",",$yf);
$yss = explode(",",$ys);
$ytt = explode(",",$yt);


$cf1 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 7' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf1 = mysqli_fetch_assoc($cf1))
							{  
								$c11[] = $rf1['class_name'];
							}	
							$cff1 = $c11;
$cf2 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 8' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf2 = mysqli_fetch_assoc($cf2))
							{  
								$c22[] = $rf2['class_name'];
							}	
							$cff2 = $c22;
if(count($cff1)==0){
array_unshift($yff,0);
}	
if(count($cff2)==0){
array_push($yff,0);
}

$cs1 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 7' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs1 = mysqli_fetch_assoc($cs1))
							{  
								$c111[] = $rs1['class_name'];
							}	
							$css1 = $c111;
$cs2 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 8' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs2 = mysqli_fetch_assoc($cs2))
							{  
								$c222[] = $rs2['class_name'];
							}	
							$css2 = $c222;
if(count($css1)==0){
array_unshift($yss,0);
}	
if(count($css2)==0){
array_push($yss,0);
}

$ct1 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 7' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt1 = mysqli_fetch_assoc($ct1))
							{  
								$c1111[] = $rt1['class_name'];
							}	
							$ctt1 = $c1111;
$ct2 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 8' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt2 = mysqli_fetch_assoc($ct2))
							{  
								$c2222[] = $rt2['class_name'];
							}	
							$ctt2 = $c2222;
if(count($ctt1)==0){
array_unshift($ytt,0);
}	
if(count($ctt2)==0){
array_push($ytt,0);
}


$ffcount = count($yff);
$sscount = count($yss);
$ttcount = count($ytt);
$array_values = array($yff,$yss,$ytt);


$cc = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($r2 = mysqli_fetch_assoc($cc))
							{  
								$c2[] = $r2['class_name'];
							}	
							$c = $c2;

//print_r($yss);
//echo count($css2);

$ccount = count($c);
$cff_diff = $ccount - ($ffcount);
for ($i = 0; $i <= ((count($c)-1)-$cff_diff); $i++){
	$array_labelss[] = $array_labels[$i];
}

$yye7 = array($yff[0],$yss[0],$ytt[0]);
$yye8 = array($yff[1],$yss[1],$ytt[1]);

$Bar = new ChartJS_Bar('example_bar', 800, 500);
$Bar->addBars($array_values[0]);
$Bar->addBars($array_values[1]);
$Bar->addBars($array_values[2]);
$Bar->addLabels($array_labelss);
}

else if($class == 'Year 9'){
$stuname = $_POST['stuname'];
$subj = $_POST['subj'];
$class = $_POST['cla'];		
$resultclname = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rowclname = mysqli_fetch_assoc($resultclname))
							{  
								$clname2[] = $rowclname['class_name'];
							}	
							$clname = $clname2;
$y7arr = $_POST['y7arr'];
if($ctype == "Js"){
	foreach($clname as $clnamee)
{
 if($clnamee=="Year 7"){ $clnamee="JS1"; }
 else if($clnamee=="Year 8"){ $clnamee="JS2"; }
 else if($clnamee=="Year 9"){ $clnamee="JS3"; }
 else if($clnamee=="Year 10"){ $clnamee="SS1"; }
 else if($clnamee=="Year 11"){ $clnamee="SS2"; }
 else{ $clnamee="SS3"; }
 $clnameeee[] = $clnamee;
}
$clnameee = $clnameeee;
$array_labels = $clnameee;
}
else{
$clnameee = $clname;	
$array_labels = $clnameee;
}

$y7arr = str_replace("[","",$y7arr);
$y7arr = str_replace("]","",$y7arr);
$y7arr = str_replace("\"","",$y7arr);
$y7arrr = explode("-",$y7arr);
$yf = $y7arrr[0];
$ys = $y7arrr[1];
$yt = $y7arrr[2];
$yf = rtrim($yf,',');
$ys = rtrim($ys,',');
$ys = ltrim($ys,',');
$yt = ltrim($yt,',');
$yff = explode(",",$yf);
$yss = explode(",",$ys);
$ytt = explode(",",$yt);


$cf1 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 7' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf1 = mysqli_fetch_assoc($cf1))
							{  
								$c11[] = $rf1['class_name'];
							}	
							$cff1 = $c11;
$cf2 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 8' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf2 = mysqli_fetch_assoc($cf2))
							{  
								$c22[] = $rf2['class_name'];
							}	
							$cff2 = $c22;
$cf3 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 9' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf3 = mysqli_fetch_assoc($cf3))
							{  
								$c33[] = $rf3['class_name'];
							}	
							$cff3 = $c33;
if(count($cff1)==0){
array_unshift($yff,0);
}	
if(count($cff2)==0){
array_splice($yff,1,0,0);
}
if(count($cff3)==0){
array_push($yff,0);
}
$cs1 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 7' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs1 = mysqli_fetch_assoc($cs1))
							{  
								$c111[] = $rs1['class_name'];
							}	
							$css1 = $c111;
$cs2 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 8' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs2 = mysqli_fetch_assoc($cs2))
							{  
								$c222[] = $rs2['class_name'];
							}	
							$css2 = $c222;
$cs3 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 9' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs3 = mysqli_fetch_assoc($cs3))
							{  
								$c333[] = $rs3['class_name'];
							}	
							$css3 = $c333;
if(count($css1)==0){
array_unshift($yss,0);
}	
if(count($css2)==0){
array_splice($yss,1,0,0);
}
if(count($css3)==0){
array_push($yss,0);
}

$ct1 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 7' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt1 = mysqli_fetch_assoc($ct1))
							{  
								$c1111[] = $rt1['class_name'];
							}	
							$ctt1 = $c1111;
$ct2 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 8' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt2 = mysqli_fetch_assoc($ct2))
							{  
								$c2222[] = $rt2['class_name'];
							}	
							$ctt2 = $c2222;
$ct3 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 9' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt3 = mysqli_fetch_assoc($ct3))
							{  
								$c3333[] = $rt3['class_name'];
							}	
							$ctt3 = $c3333;
if(count($ctt1)==0){
array_unshift($ytt,0);
}	
if(count($ctt2)==0){
array_splice($ytt,1,0,0);
}
if(count($ctt3)==0){
array_push($ytt,0);
}

$array_values = array($yff,$yss,$ytt);

$cc = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($r2 = mysqli_fetch_assoc($cc))
							{  
								$c2[] = $r2['class_name'];
							}	
							$c = $c2;	
$ffcount = count($yff);
$ccount = count($c);
$cff_diff = $ccount - $ffcount;
for ($i = 0; $i <= ((count($c)-1)-$cff_diff); $i++){
	$array_labelss[] = $array_labels[$i];
}


$yye7 = array($yff[0],$yss[0],$ytt[0]);
$yye8 = array($yff[1],$yss[1],$ytt[1]);
$yye9 = array($yff[2],$yss[2],$ytt[2]);

$Bar = new ChartJS_Bar('example_bar', 800, 500);
$Bar->addBars($array_values[0]);
$Bar->addBars($array_values[1]);
$Bar->addBars($array_values[2]);
$Bar->addLabels($array_labelss);
}

elseif($class == 'Year 10'){
$stuname = $_POST['stuname'];
$subj = $_POST['subj'];
$class = $_POST['cla'];		
$resultclname = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rowclname = mysqli_fetch_assoc($resultclname))
							{  
								$clname2[] = $rowclname['class_name'];
							}	
							$clname = $clname2;	
$y7arr = $_POST['y7arr'];
if($ctype == "Js"){
	foreach($clname as $clnamee)
{
 if($clnamee=="Year 7"){ $clnamee="JS1"; }
 else if($clnamee=="Year 8"){ $clnamee="JS2"; }
 else if($clnamee=="Year 9"){ $clnamee="JS3"; }
 else if($clnamee=="Year 10"){ $clnamee="SS1"; }
 else if($clnamee=="Year 11"){ $clnamee="SS2"; }
 else{ $clnamee="SS3"; }
 $clnameeee[] = $clnamee;
}
$clnameee = $clnameeee;
$array_labels = $clnameee;
}
else{
$clnameee = $clname;	
$array_labels = $clnameee;
}

$y7arr = str_replace("[","",$y7arr);
$y7arr = str_replace("]","",$y7arr);
$y7arr = str_replace("\"","",$y7arr);
$y7arrr = explode("-",$y7arr);
$yf = $y7arrr[0];
$ys = $y7arrr[1];
$yt = $y7arrr[2];
$yf = rtrim($yf,',');
$ys = rtrim($ys,',');
$ys = ltrim($ys,',');
$yt = ltrim($yt,',');
$yff = explode(",",$yf);
$yss = explode(",",$ys);
$ytt = explode(",",$yt);

$cf1 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 7' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf1 = mysqli_fetch_assoc($cf1))
							{  
								$c11[] = $rf1['class_name'];
							}	
							$cff1 = $c11;
$cf2 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 8' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf2 = mysqli_fetch_assoc($cf2))
							{  
								$c22[] = $rf2['class_name'];
							}	
							$cff2 = $c22;
$cf3 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 9' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf3 = mysqli_fetch_assoc($cf3))
							{  
								$c33[] = $rf3['class_name'];
							}	
							$cff3 = $c33;
$cf4 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 10' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf4 = mysqli_fetch_assoc($cf4))
							{  
								$c44[] = $rf4['class_name'];
							}	
							$cff4 = $c44;
if(count($cff1)==0){
array_unshift($yff,0);
}	
if(count($cff2)==0){
array_splice($yff,1,0,0);
}
if(count($cff3)==0){
array_splice($yff,2,0,0);
}
if(count($cff4)==0){
array_push($yff,0);
}
$cs1 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 7' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs1 = mysqli_fetch_assoc($cs1))
							{  
								$c111[] = $rs1['class_name'];
							}	
							$css1 = $c111;
$cs2 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 8' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs2 = mysqli_fetch_assoc($cs2))
							{  
								$c222[] = $rs2['class_name'];
							}	
							$css2 = $c222;
$cs3 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 9' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs3 = mysqli_fetch_assoc($cs3))
							{  
								$c333[] = $rs3['class_name'];
							}	
							$css3 = $c333;
$cs4 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 10' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs4 = mysqli_fetch_assoc($cs4))
							{  
								$c444[] = $rs4['class_name'];
							}	
							$css4 = $c444;
if(count($css1)==0){
array_unshift($yss,0);
}	
if(count($css2)==0){
array_splice($yss,1,0,0);
}
if(count($css3)==0){
array_splice($yss,2,0,0);
}
if(count($css4)==0){
array_push($yss,0);
}

$ct1 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 7' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt1 = mysqli_fetch_assoc($ct1))
							{  
								$c1111[] = $rt1['class_name'];
							}	
							$ctt1 = $c1111;
$ct2 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 8' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt2 = mysqli_fetch_assoc($ct2))
							{  
								$c2222[] = $rt2['class_name'];
							}	
							$ctt2 = $c2222;
$ct3 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 9' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt3 = mysqli_fetch_assoc($ct3))
							{  
								$c3333[] = $rt3['class_name'];
							}	
							$ctt3 = $c3333;
$ct4 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 10' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt4 = mysqli_fetch_assoc($ct4))
							{  
								$c4444[] = $rt4['class_name'];
							}	
							$ctt4 = $c4444;
if(count($ctt1)==0){
array_unshift($ytt,0);
}	
if(count($ctt2)==0){
array_splice($ytt,1,0,0);
}
if(count($ctt3)==0){
array_splice($ytt,2,0,0);
}
if(count($ctt4)==0){
array_push($ytt,0);
}




$array_values = array($yff,$yss,$ytt);

$cc = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($r2 = mysqli_fetch_assoc($cc))
							{  
								$c2[] = $r2['class_name'];
							}	
							$c = $c2;	
$ffcount = count($yff);
$ccount = count($c);
$cff_diff = $ccount - $ffcount;
for ($i = 0; $i <= ((count($c)-1)-$cff_diff); $i++){
	$array_labelss[] = $array_labels[$i];
}

$yye7 = array($yff[0],$yss[0],$ytt[0]);
$yye8 = array($yff[1],$yss[1],$ytt[1]);
$yye9 = array($yff[2],$yss[2],$ytt[2]);
$yye10 = array($yff[3],$yss[3],$ytt[3]);

$Bar = new ChartJS_Bar('example_bar', 800, 500);
$Bar->addBars($array_values[0]);
$Bar->addBars($array_values[1]);
$Bar->addBars($array_values[2]);
$Bar->addLabels($array_labelss);
}

elseif($class == 'Year 11'){
$stuname = $_POST['stuname'];
$subj = $_POST['subj'];
$class = $_POST['cla'];		
$resultclname = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rowclname = mysqli_fetch_assoc($resultclname))
							{  
								$clname2[] = $rowclname['class_name'];
							}	
							$clname = $clname2;
$y7arr = $_POST['y7arr'];
if($ctype == "Js"){
	foreach($clname as $clnamee)
{
 if($clnamee=="Year 7"){ $clnamee="JS1"; }
 else if($clnamee=="Year 8"){ $clnamee="JS2"; }
 else if($clnamee=="Year 9"){ $clnamee="JS3"; }
 else if($clnamee=="Year 10"){ $clnamee="SS1"; }
 else if($clnamee=="Year 11"){ $clnamee="SS2"; }
 else{ $clnamee="SS3"; }
 $clnameeee[] = $clnamee;
}
$clnameee = $clnameeee;
$array_labels = $clnameee;
}
else{
$clnameee = $clname;	
$array_labels = $clnameee;
}

$y7arr = str_replace("[","",$y7arr);
$y7arr = str_replace("]","",$y7arr);
$y7arr = str_replace("\"","",$y7arr);
$y7arrr = explode("-",$y7arr);
$yf = $y7arrr[0];
$ys = $y7arrr[1];
$yt = $y7arrr[2];
$yf = rtrim($yf,',');
$ys = rtrim($ys,',');
$ys = ltrim($ys,',');
$yt = ltrim($yt,',');
$yff = explode(",",$yf);
$yss = explode(",",$ys);
$ytt = explode(",",$yt);

$cf1 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 7' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf1 = mysqli_fetch_assoc($cf1))
							{  
								$c11[] = $rf1['class_name'];
							}	
							$cff1 = $c11;
$cf2 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 8' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf2 = mysqli_fetch_assoc($cf2))
							{  
								$c22[] = $rf2['class_name'];
							}	
							$cff2 = $c22;
$cf3 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 9' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf3 = mysqli_fetch_assoc($cf3))
							{  
								$c33[] = $rf3['class_name'];
							}	
							$cff3 = $c33;
$cf4 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 10' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf4 = mysqli_fetch_assoc($cf4))
							{  
								$c44[] = $rf4['class_name'];
							}	
							$cff4 = $c44;
$cf5 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 11' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf5 = mysqli_fetch_assoc($cf5))
							{  
								$c55[] = $rf5['class_name'];
							}	
							$cff5 = $c55;
if(count($cff1)==0){
array_unshift($yff,0);
}	
if(count($cff2)==0){
array_splice($yff,1,0,0);
}
if(count($cff3)==0){
array_splice($yff,2,0,0);
}
if(count($cff4)==0){
array_splice($yff,3,0,0);
}
if(count($cff5)==0){
array_push($yff,0);
}
$cs1 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 7' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs1 = mysqli_fetch_assoc($cs1))
							{  
								$c111[] = $rs1['class_name'];
							}	
							$css1 = $c111;
$cs2 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 8' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs2 = mysqli_fetch_assoc($cs2))
							{  
								$c222[] = $rs2['class_name'];
							}	
							$css2 = $c222;
$cs3 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 9' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs3 = mysqli_fetch_assoc($cs3))
							{  
								$c333[] = $rs3['class_name'];
							}	
							$css3 = $c333;
$cs4 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 10' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs4 = mysqli_fetch_assoc($cs4))
							{  
								$c444[] = $rs4['class_name'];
							}	
							$css4 = $c444;
$cs5 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 11' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs5 = mysqli_fetch_assoc($cs5))
							{  
								$c555[] = $rs5['class_name'];
							}	
							$css5 = $c555;
if(count($css1)==0){
array_unshift($yss,0);
}	
if(count($css2)==0){
array_splice($yss,1,0,0);
}
if(count($css3)==0){
array_splice($yss,2,0,0);
}
if(count($css4)==0){
array_splice($yss,3,0,0);
}
if(count($css5)==0){
array_push($yss,0);
}

$ct1 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 7' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt1 = mysqli_fetch_assoc($ct1))
							{  
								$c1111[] = $rt1['class_name'];
							}	
							$ctt1 = $c1111;
$ct2 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 8' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt2 = mysqli_fetch_assoc($ct2))
							{  
								$c2222[] = $rt2['class_name'];
							}	
							$ctt2 = $c2222;
$ct3 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 9' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt3 = mysqli_fetch_assoc($ct3))
							{  
								$c3333[] = $rt3['class_name'];
							}	
							$ctt3 = $c3333;
$ct4 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 10' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt4 = mysqli_fetch_assoc($ct4))
							{  
								$c4444[] = $rt4['class_name'];
							}	
							$ctt4 = $c4444;
$ct5 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 11' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt5 = mysqli_fetch_assoc($ct5))
							{  
								$c5555[] = $rt5['class_name'];
							}	
							$ctt5 = $c5555;
							
if(count($ctt1)==0){
array_unshift($ytt,0);
}	
if(count($ctt2)==0){
array_splice($ytt,1,0,0);
}
if(count($ctt3)==0){
array_splice($ytt,2,0,0);
}
if(count($ctt4)==0){
array_splice($ytt,3,0,0);
}
if(count($ctt5)==0){
array_push($ytt,0);
}


$array_values = array($yff,$yss,$ytt);

$cc = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($r2 = mysqli_fetch_assoc($cc))
							{  
								$c2[] = $r2['class_name'];
							}	
							$c = $c2;	
$ffcount = count($yff);
$ccount = count($c);
$cff_diff = $ccount - $ffcount;
for ($i = 0; $i <= ((count($c)-1)-$cff_diff); $i++){
	$array_labelss[] = $array_labels[$i];
}


$yye7 = array($yff[0],$yss[0],$ytt[0]);
$yye8 = array($yff[1],$yss[1],$ytt[1]);
$yye9 = array($yff[2],$yss[2],$ytt[2]);
$yye10 = array($yff[3],$yss[3],$ytt[3]);
$yye11 = array($yff[4],$yss[4],$ytt[4]);

$Bar = new ChartJS_Bar('example_bar', 800, 500);
$Bar->addBars($array_values[0]);
$Bar->addBars($array_values[1]);
$Bar->addBars($array_values[2]);
$Bar->addLabels($array_labelss);
}
else{
$stuname = $_POST['stuname'];
$subj = $_POST['subj'];
$class = $_POST['cla'];		
$resultclname = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rowclname = mysqli_fetch_assoc($resultclname))
							{  
								$clname2[] = $rowclname['class_name'];
							}	
							$clname = $clname2;
							
$y7arr = $_POST['y7arr'];
if($ctype == "Js"){
	foreach($clname as $clnamee)
{
 if($clnamee=="Year 7"){ $clnamee="JS1"; }
 else if($clnamee=="Year 8"){ $clnamee="JS2"; }
 else if($clnamee=="Year 9"){ $clnamee="JS3"; }
 else if($clnamee=="Year 10"){ $clnamee="SS1"; }
 else if($clnamee=="Year 11"){ $clnamee="SS2"; }
 else{ $clnamee="SS3"; }
 $clnameeee[] = $clnamee;
}
$clnameee = $clnameeee;
$array_labels = $clnameee;
}
else{
$clnameee = $clname;	
$array_labels = $clnameee;
}

$y7arr = str_replace("[","",$y7arr);
$y7arr = str_replace("]","",$y7arr);
$y7arr = str_replace("\"","",$y7arr);
$y7arrr = explode("-",$y7arr);
$yf = $y7arrr[0];
$ys = $y7arrr[1];
$yt = $y7arrr[2];
$yf = rtrim($yf,',');
$ys = rtrim($ys,',');
$ys = ltrim($ys,',');
$yt = ltrim($yt,',');
$yff = explode(",",$yf);
$yss = explode(",",$ys);
$ytt = explode(",",$yt);


$cf1 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 7' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf1 = mysqli_fetch_assoc($cf1))
							{  
								$c11[] = $rf1['class_name'];
							}	
							$cff1 = $c11;
$cf2 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 8' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf2 = mysqli_fetch_assoc($cf2))
							{  
								$c22[] = $rf2['class_name'];
							}	
							$cff2 = $c22;
$cf3 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 9' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf3 = mysqli_fetch_assoc($cf3))
							{  
								$c33[] = $rf3['class_name'];
							}	
							$cff3 = $c33;
$cf4 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 10' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf4 = mysqli_fetch_assoc($cf4))
							{  
								$c44[] = $rf4['class_name'];
							}	
							$cff4 = $c44;
$cf5 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 11' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf5 = mysqli_fetch_assoc($cf5))
							{  
								$c55[] = $rf5['class_name'];
							}	
							$cff5 = $c55;
$cf6 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='First Term' AND class_name='Year 12' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rf6 = mysqli_fetch_assoc($cf6))
							{  
								$c66[] = $rf6['class_name'];
							}	
							$cff6 = $c66;
if(count($cff1)==0){
array_unshift($yff,0);
}	
if(count($cff2)==0){
array_splice($yff,1,0,0);
}
if(count($cff3)==0){
array_splice($yff,2,0,0);
}
if(count($cff4)==0){
array_splice($yff,3,0,0);
}
if(count($cff5)==0){
array_splice($yff,4,0,0);
}
if(count($cff6)==0){
array_push($yff,0);
}
$cs1 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 7' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs1 = mysqli_fetch_assoc($cs1))
							{  
								$c111[] = $rs1['class_name'];
							}	
							$css1 = $c111;
$cs2 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 8' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs2 = mysqli_fetch_assoc($cs2))
							{  
								$c222[] = $rs2['class_name'];
							}	
							$css2 = $c222;
$cs3 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 9' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs3 = mysqli_fetch_assoc($cs3))
							{  
								$c333[] = $rs3['class_name'];
							}	
							$css3 = $c333;
$cs4 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 10' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs4 = mysqli_fetch_assoc($cs4))
							{  
								$c444[] = $rs4['class_name'];
							}	
							$css4 = $c444;
$cs5 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 11' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs5 = mysqli_fetch_assoc($cs5))
							{  
								$c555[] = $rs5['class_name'];
							}	
							$css5 = $c555;
$cs6 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Second Term' AND class_name='Year 12' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rs6 = mysqli_fetch_assoc($cs6))
							{  
								$c666[] = $rs6['class_name'];
							}	
							$css6 = $c666;
if(count($css1)==0){
array_unshift($yss,0);
}	
if(count($css2)==0){
array_splice($yss,1,0,0);
}
if(count($css3)==0){
array_splice($yss,2,0,0);
}
if(count($css4)==0){
array_splice($yss,3,0,0);
}
if(count($css5)==0){
array_splice($yss,4,0,0);
}
if(count($css6)==0){
array_push($yss,0);
}

$ct1 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 7' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt1 = mysqli_fetch_assoc($ct1))
							{  
								$c1111[] = $rt1['class_name'];
							}	
							$ctt1 = $c1111;
$ct2 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 8' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt2 = mysqli_fetch_assoc($ct2))
							{  
								$c2222[] = $rt2['class_name'];
							}	
							$ctt2 = $c2222;
$ct3 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 9' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt3 = mysqli_fetch_assoc($ct3))
							{  
								$c3333[] = $rt3['class_name'];
							}	
							$ctt3 = $c3333;
$ct4 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 10' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt4 = mysqli_fetch_assoc($ct4))
							{  
								$c4444[] = $rt4['class_name'];
							}	
							$ctt4 = $c4444;
$ct5 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 11' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt5 = mysqli_fetch_assoc($ct5))
							{  
								$c5555[] = $rt5['class_name'];
							}	
							$ctt5 = $c5555;
$ct6 = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE term='Third Term' AND class_name='Year 12' AND student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($rt6 = mysqli_fetch_assoc($ct6))
							{  
								$c6666[] = $rt6['class_name'];
							}	
							$ctt6 = $c6666;							
if(count($ctt1)==0){
array_unshift($ytt,0);
}	
if(count($ctt2)==0){
array_splice($ytt,1,0,0);
}
if(count($ctt3)==0){
array_splice($ytt,2,0,0);
}
if(count($ctt4)==0){
array_splice($ytt,3,0,0);
}
if(count($ctt5)==0){
array_splice($ytt,4,0,0);
}
if(count($ctt6)==0){
array_push($ytt,0);
}

$array_values = array($yff,$yss,$ytt);

$cc = mysqli_query($db, "SELECT DISTINCT(class_name) FROM scores WHERE student_name='$stuname' AND subject='$subj' AND school='".$_SESSION["school"]."' ORDER BY year ASC");
						while($r2 = mysqli_fetch_assoc($cc))
							{  
								$c2[] = $r2['class_name'];
							}	
							$c = $c2;	
$ffcount = count($yff);
$ccount = count($c);
$cff_diff = $ccount - $ffcount;
for ($i = 0; $i <= ((count($c)-1)-$cff_diff); $i++){
	$array_labelss[] = $array_labels[$i];
}


$yye7 = array($yff[0],$yss[0],$ytt[0]);
$yye8 = array($yff[1],$yss[1],$ytt[1]);
$yye9 = array($yff[2],$yss[2],$ytt[2]);
$yye10 = array($yff[3],$yss[3],$ytt[3]);
$yye11 = array($yff[4],$yss[4],$ytt[4]);
$yye12 = array($yff[5],$yss[5],$ytt[5]);

$Bar = new ChartJS_Bar('example_bar', 800, 500);
$Bar->addBars($array_values[0]);
$Bar->addBars($array_values[1]);
$Bar->addBars($array_values[2]);
$Bar->addLabels($array_labelss);
}
?><!DOCTYPE html>
<html>
<head>
    <title>chart by subject</title>
<link rel="stylesheet" href="css/styles.css">
	<style>
ul.topnav {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}
ul.topnav li {float: left;}
ul.topnav li a {
    display: inline-block;
    color: #f2f2f2;
    text-align: center;
    padding: 12px 14px;
    text-decoration: none;
    transition: 0.3s;
    font-size: 14px;
}
ul.topnav li a:hover {background-color: #555;}
ul.topnav li.icon {display: none;}

@media screen and (max-width:680px) {
  ul.topnav li:not(:first-child) {display: none;}
  ul.topnav li.icon {
    float: right;
    display: inline-block;
  }
}
@media screen and (max-width:680px) {
  ul.topnav.responsive {position: relative;}
  ul.topnav.responsive li.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  ul.topnav.responsive li {
    float: none;
    display: inline;
  }
  ul.topnav.responsive li a {
    display: block;
    text-align: left;
  }
}
</style>
<style>
.pbutton {
	background-color:#44c767;
	-moz-border-radius:28px;
	-webkit-border-radius:28px;
	border-radius:2px;
	border:1px solid #18ab29;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:15px;
	padding:6px 24px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
	float: left;
}
.pbutton:hover {
	background-color:#5cbf2a;
}
.pbutton:active {
	position:relative;
	top:1px;
}
</style>
<link rel="stylesheet" href="style.css" type="text/css" />
<script src="Chart.js"></script>
<script src="chart.js-php.js"></script>

 <script src="gr2/js/jquery.js"></script>
    <script src="gr2/js/highchart.js"></script>
    <script src="gr2/js/exporting.js"></script>
    <script src="gr2/js/jspdf.js"></script>
    <script src="gr2/js/rgbcolor.js"></script>
    <script src="gr2/js/canvg.js"></script>
  
   <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>
  <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>	
</head>
<body>
<?php
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
elseif($_SESSION['role'] == 'student'){
include("headerstudent.php");
}
else{header("location: logout.php");}
?>
<br>
<br>

 <h6>
<div style="text-align: center; font-size: 14px;"><?php echo strtoupper($stuname); ?>'S PERFORMANCE IN <?php echo strtoupper($subj) ?><br>with focus on class</div>
<table style="width: 30%;">
<tr>
<td style="background-color:#44c767; font-weight: bold;" >
<?php
echo '<form name="maxform" action="getresult.php" method="post">';
echo '<input style="display: none;" name="student_name" type="text" value="'.$stuname. '">';
echo '<input style="display: none;" name="class_name" type="text" value="'.$class. '">';
echo '<input  style="display: none;" name="year" type="text" value="'.$year. '">';
echo '<input style="display: none;" name="term" type="text" value="'.$term. '">';
echo '<input   style="display: none;" name="arms" type="text" value="'.$arms. '">';
echo '<input   style="display: none;" name="sig" type="text" value="'.$sig. '">';
echo '<input type="submit" class="pbutton" style="height: 100%;" name="submit8" value="Back to Result" />';
?>
</td><td><a class="pbutton" href="teagetresult.php">Result Request Page</a></td><td style="background-color: #f2b21a;">1st Term Scores</td><td style="background-color: rgba(61, 138, 190, 1); color: white;">2nd Term Scores</td>
<td style="background-color: rgba(212,41,31,.7); color: white;">3rd Term Scores</td>
</tr></table></h6>
<?php
echo $Bar;
?>
<script>
    (function () {
        loadChartJsPhp();
    })();
</script>
<br>
<button id="export_all" class="pbutton" >Save as PDF</button>
<?php
//echo '<form action="tochart.php" method="POST">';
//echo '<input  name="student_name2" type="text" value="'.$stuname.'">';
//echo '<input class="pbutton" type="submit" name="btnuploadsubj" value="Back" />';
//echo '</form>';

if($class=="Year 1"){
		if($ctype=="Js"){
		$charlab1 = "JS1";
	}elseif($ctype=="Primary"){
		$charlab1 = "Primary 1";
	}else{
		$charlab1 = "Year 1";
}}
if($class=="Year 2"){
		if($ctype=="Js"){
		$charlab1 = "JS1";
		$charlab2 = "JS2";
	}elseif($ctype=="Primary"){
		$charlab1 = "Primary 1";
		$charlab2 = "Primary 2";
	}else{
		$charlab1 = "Year 1";
		$charlab2 = "Year 2";
	}}
if($class=="Year 3"){
		if($ctype=="Js"){
		$charlab1 = "JS1";
		$charlab2 = "JS2";
		$charlab3 = "JS3";
	}elseif($ctype=="Primary"){
		$charlab1 = "Primary 1";
		$charlab2 = "Primary 2";
		$charlab3 = "Primary 3";
	}else{
		$charlab1 = "Year 1";
		$charlab2 = "Year 2";
		$charlab3 = "Year 3";
	}}
if($class=="Year 4"){
		if($ctype=="Js"){
		$charlab1 = "JS1";
		$charlab2 = "JS2";
		$charlab3 = "JS3";
		$charlab4 = "SS1";
	}elseif($ctype=="Primary"){
		$charlab1 = "Primary 1";
		$charlab2 = "Primary 2";
		$charlab3 = "Primary 3";
		$charlab4 = "Primary 4";
	}else{
		$charlab1 = "Year 1";
		$charlab2 = "Year 2";
		$charlab3 = "Year 3";
		$charlab4 = "Year 4";
	}}
if($class=="Year 5"){
		if($ctype=="Js"){
		$charlab1 = "JS1";
		$charlab2 = "JS2";
		$charlab3 = "JS3";
		$charlab4 = "SS1";
		$charlab5 = "SS2";
	}elseif($ctype=="Primary"){
		$charlab1 = "Primary 1";
		$charlab2 = "Primary 2";
		$charlab3 = "Primary 3";
		$charlab4 = "Primary 4";
		$charlab5 = "Primary 5";
	}else{
		$charlab1 = "Year 1";
		$charlab2 = "Year 2";
		$charlab3 = "Year 3";
		$charlab4 = "Year 4";
		$charlab5 = "Year 5";
	}}
if($class=="Year 6"){
		if($ctype=="Js"){
		$charlab1 = "JS1";
		$charlab2 = "JS2";
		$charlab3 = "JS3";
		$charlab4 = "SS1";
		$charlab5 = "SS2";
		$charlab6 = "SS3";
	}elseif($ctype=="Primary"){
		$charlab1 = "Primary 1";
		$charlab2 = "Primary 2";
		$charlab3 = "Primary 3";
		$charlab4 = "Primary 4";
		$charlab5 = "Primary 5";
		$charlab6 = "Primary 6";
	}else{
		$charlab1 = "Year 1";
		$charlab2 = "Year 2";
		$charlab3 = "Year 3";
		$charlab4 = "Year 4";
		$charlab5 = "Year 5";
		$charlab6 = "Year 6";
	}}	
if($class=="Year 7"){
		if($ctype=="Js"){
		$charlab7 = "JS1";
	}else{
		$charlab7 = "Year 7";
}}
if($class=="Year 8"){
		if($ctype=="Js"){
		$charlab7 = "JS1";
		$charlab8 = "JS2";
	}else{
		$charlab7 = "Year 7";
		$charlab8 = "Year 8";
	}}
if($class=="Year 9"){
		if($ctype=="Js"){
		$charlab7 = "JS1";
		$charlab8 = "JS2";
		$charlab9 = "JS3";
	}else{
		$charlab7 = "Year 7";
		$charlab8 = "Year 8";
		$charlab9 = "Year 9";
	}}
if($class=="Year 10"){
		if($ctype=="Js"){
		$charlab7 = "JS1";
		$charlab8 = "JS2";
		$charlab9 = "JS3";
		$charlab10 = "SS1";
	}else{
		$charlab7 = "Year 7";
		$charlab8 = "Year 8";
		$charlab9 = "Year 9";
		$charlab10 = "Year 10";
	}}
if($class=="Year 11"){
		if($ctype=="Js"){
		$charlab7 = "JS1";
		$charlab8 = "JS2";
		$charlab9 = "JS3";
		$charlab10 = "SS1";
		$charlab11 = "SS2";
	}else{
		$charlab7 = "Year 7";
		$charlab8 = "Year 8";
		$charlab9 = "Year 9";
		$charlab10 = "Year 10";
		$charlab11 = "Year 11";
	}}
if($class=="Year 12"){
		if($ctype=="Js"){
		$charlab7 = "JS1";
		$charlab8 = "JS2";
		$charlab9 = "JS3";
		$charlab10 = "SS1";
		$charlab11 = "SS2";
		$charlab12 = "SS3";
	}else{
		$charlab7 = "Year 7";
		$charlab8 = "Year 8";
		$charlab9 = "Year 9";
		$charlab10 = "Year 10";
		$charlab11 = "Year 11";
		$charlab12 = "Year 12";
	}}			
$stuname = $_POST['stuname'];
$subj = $_POST['subj'];	
?>
<br><br>
<div id="chart1" class="myChart" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
<script>
    $(document).ready(function() {
        // create canvas function from highcharts example http://jsfiddle.net/highcharts/PDnmQ/
        (function(H) {
            H.Chart.prototype.createCanvas = function(divId) {
                var svg = this.getSVG(),
                    width = parseInt(svg.match(/width="([0-9]+)"/)[1]),
                    height = parseInt(svg.match(/height="([0-9]+)"/)[1]),
                    canvas = document.createElement('canvas');

                canvas.setAttribute('width', width);
                canvas.setAttribute('height', height);

                if (canvas.getContext && canvas.getContext('2d')) {

                    canvg(canvas, svg);

                    return canvas.toDataURL("image/jpeg");

                } 
                else {
                    alert("Your browser doesn't support this feature, please use a modern browser");
                    return false;
                }

            }
        }(Highcharts));

        $('#export_all').click(function(ev) {
			ev.preventDefault();
            var doc = new jsPDF();

            // chart height defined here so each chart can be palced
            // in a different position
            var chartHeight = 80;

            // All units are in the set measurement for the document
            // This can be changed to "pt" (points), "mm" (Default), "cm", "in"
            doc.setFontSize(40);
            doc.text(35, 25, "");

            //loop through each chart
            $('.myChart').each(function(index) {
                var imageData = $(this).highcharts().createCanvas();

                // add image to doc, if you have lots of charts,
                // you will need to check if you have gone bigger 
                // than a page and do doc.addPage() before adding 
                // another image.

                /**
                 * addImage(imagedata, type, x, y, width, height)
                 */
                doc.addImage(imageData, 'JPEG', 45, (index * chartHeight) + 40, 120, chartHeight);
            });


            //save with name
            doc.save('demo.pdf');
        });
		
		var classs = <?php echo json_encode($class); ?>;
		var stuname = <?php echo json_encode($stuname); ?>;
		var subject = <?php echo json_encode($subj); ?>;
		
		if(classs=="Year 1"){
		var y1 = <?php echo json_encode($yye1); ?>;	
		var charlab11 = <?php echo json_encode($charlab1); ?>;	
		var array1 = JSON.parse("[" + y1 + "]");
		}
		else if(classs=="Year 2"){
		var y1 = <?php echo json_encode($yye1); ?>;	
		var y2 = <?php echo json_encode($yye2); ?>;	
		var charlab11 = <?php echo json_encode($charlab1); ?>;	
		var charlab22 = <?php echo json_encode($charlab2); ?>;
		var array1 = JSON.parse("[" + y1 + "]");
		var array2 = JSON.parse("[" + y2 + "]");
		}
		else if(classs=="Year 3"){
		var y1 = <?php echo json_encode($yye1); ?>;	
		var y2 = <?php echo json_encode($yye2); ?>;	
		var y3 = <?php echo json_encode($yye3); ?>;	
		var charlab11 = <?php echo json_encode($charlab1); ?>;	
		var charlab22 = <?php echo json_encode($charlab2); ?>;
		var charlab33 = <?php echo json_encode($charlab3); ?>;
		var array1 = JSON.parse("[" + y1 + "]");
		var array2 = JSON.parse("[" + y2 + "]");
		var array3 = JSON.parse("[" + y3 + "]");
		}
		else if(classs=="Year 4"){
		var y1 = <?php echo json_encode($yye1); ?>;	
		var y2 = <?php echo json_encode($yye2); ?>;	
		var y3 = <?php echo json_encode($yye3); ?>;
		var y4 = <?php echo json_encode($yye4); ?>;	
		var charlab11 = <?php echo json_encode($charlab1); ?>;	
		var charlab22 = <?php echo json_encode($charlab2); ?>;
		var charlab33 = <?php echo json_encode($charlab3); ?>;
		var charlab44 = <?php echo json_encode($charlab4); ?>;	
		var array1 = JSON.parse("[" + y1 + "]");
		var array2 = JSON.parse("[" + y2 + "]");
		var array3 = JSON.parse("[" + y3 + "]");
		var array4 = JSON.parse("[" + y4 + "]");
		}
		else if(classs=="Year 5"){
		var y1 = <?php echo json_encode($yye1); ?>;	
		var y2 = <?php echo json_encode($yye2); ?>;	
		var y3 = <?php echo json_encode($yye3); ?>;
		var y4 = <?php echo json_encode($yye4); ?>;	
		var y5 = <?php echo json_encode($yye5); ?>;	
		var charlab11 = <?php echo json_encode($charlab1); ?>;	
		var charlab22 = <?php echo json_encode($charlab2); ?>;
		var charlab33 = <?php echo json_encode($charlab3); ?>;
		var charlab44 = <?php echo json_encode($charlab4); ?>;	
		var charlab55 = <?php echo json_encode($charlab5); ?>;	
		var array1 = JSON.parse("[" + y1 + "]");
		var array2 = JSON.parse("[" + y2 + "]");
		var array3 = JSON.parse("[" + y3 + "]");
		var array4 = JSON.parse("[" + y4 + "]");
		var array5 = JSON.parse("[" + y5 + "]");
		}
		else if(classs=="Year 6"){
		var y1 = <?php echo json_encode($yye1); ?>;	
		var y2 = <?php echo json_encode($yye2); ?>;	
		var y3 = <?php echo json_encode($yye3); ?>;
		var y4 = <?php echo json_encode($yye4); ?>;	
		var y5 = <?php echo json_encode($yye5); ?>;	
		var y6 = <?php echo json_encode($yye6); ?>;	
		var charlab11 = <?php echo json_encode($charlab1); ?>;	
		var charlab22 = <?php echo json_encode($charlab2); ?>;
		var charlab33 = <?php echo json_encode($charlab3); ?>;
		var charlab44 = <?php echo json_encode($charlab4); ?>;	
		var charlab55 = <?php echo json_encode($charlab5); ?>;
		var charlab66 = <?php echo json_encode($charlab6); ?>;		
		var array1 = JSON.parse("[" + y1 + "]");
		var array2 = JSON.parse("[" + y2 + "]");
		var array3 = JSON.parse("[" + y3 + "]");
		var array4 = JSON.parse("[" + y4 + "]");
		var array5 = JSON.parse("[" + y5 + "]");
		var array6 = JSON.parse("[" + y6 + "]");
		}
		else if(classs=="Year 7"){
		var y7 = <?php echo json_encode($yye7); ?>;	
		var charlab77 = <?php echo json_encode($charlab7); ?>;	
		var array7 = JSON.parse("[" + y7 + "]");
		}
		else if(classs=="Year 8"){
		var y7 = <?php echo json_encode($yye7); ?>;	
		var y8 = <?php echo json_encode($yye8); ?>;	
		var charlab77 = <?php echo json_encode($charlab7); ?>;	
		var charlab88 = <?php echo json_encode($charlab8); ?>;
		var array7 = JSON.parse("[" + y7 + "]");
		var array8 = JSON.parse("[" + y8 + "]");
		}
		else if(classs=="Year 9"){
		var y7 = <?php echo json_encode($yye7); ?>;	
		var y8 = <?php echo json_encode($yye8); ?>;	
		var y9 = <?php echo json_encode($yye9); ?>;
		var charlab77 = <?php echo json_encode($charlab7); ?>;	
		var charlab88 = <?php echo json_encode($charlab8); ?>;
		var charlab99 = <?php echo json_encode($charlab9); ?>;
		var array7 = JSON.parse("[" + y7 + "]");
		var array8 = JSON.parse("[" + y8 + "]");
		var array9 = JSON.parse("[" + y9 + "]");
		}
		else if(classs=="Year 10"){
		var y7 = <?php echo json_encode($yye7); ?>;	
		var y8 = <?php echo json_encode($yye8); ?>;	
		var y9 = <?php echo json_encode($yye9); ?>;
		var y10 = <?php echo json_encode($yye10); ?>;	
		var charlab77 = <?php echo json_encode($charlab7); ?>;	
		var charlab88 = <?php echo json_encode($charlab8); ?>;
		var charlab99 = <?php echo json_encode($charlab9); ?>;
		var charlab1010 = <?php echo json_encode($charlab10); ?>;	
		var array7 = JSON.parse("[" + y7 + "]");
		var array8 = JSON.parse("[" + y8 + "]");
		var array9 = JSON.parse("[" + y9 + "]");
		var array10 = JSON.parse("[" + y10 + "]");
		}
		else if(classs=="Year 11"){
		var y7 = <?php echo json_encode($yye7); ?>;	
		var y8 = <?php echo json_encode($yye8); ?>;	
		var y9 = <?php echo json_encode($yye9); ?>;
		var y10 = <?php echo json_encode($yye10); ?>;	
		var y11 = <?php echo json_encode($yye11); ?>;	
		var charlab77 = <?php echo json_encode($charlab7); ?>;	
		var charlab88 = <?php echo json_encode($charlab8); ?>;
		var charlab99 = <?php echo json_encode($charlab9); ?>;
		var charlab1010 = <?php echo json_encode($charlab10); ?>;	
		var charlab1111 = <?php echo json_encode($charlab11); ?>;
		var array7 = JSON.parse("[" + y7 + "]");
		var array8 = JSON.parse("[" + y8 + "]");
		var array9 = JSON.parse("[" + y9 + "]");
		var array10 = JSON.parse("[" + y10 + "]");
		var array11 = JSON.parse("[" + y11 + "]");
		}
		else{
		var y7 = <?php echo json_encode($yye7); ?>;	
		var y8 = <?php echo json_encode($yye8); ?>;	
		var y9 = <?php echo json_encode($yye9); ?>;
		var y10 = <?php echo json_encode($yye10); ?>;	
		var y11 = <?php echo json_encode($yye11); ?>;	
		var y12 = <?php echo json_encode($yye12); ?>;
		var charlab77 = <?php echo json_encode($charlab7); ?>;	
		var charlab88 = <?php echo json_encode($charlab8); ?>;
		var charlab99 = <?php echo json_encode($charlab9); ?>;
		var charlab1010 = <?php echo json_encode($charlab10); ?>;	
		var charlab1111 = <?php echo json_encode($charlab11); ?>;
		var charlab1212 = <?php echo json_encode($charlab12); ?>;
		var array7 = JSON.parse("[" + y7 + "]");
		var array8 = JSON.parse("[" + y8 + "]");
		var array9 = JSON.parse("[" + y9 + "]");
		var array10 = JSON.parse("[" + y10 + "]");
		var array11 = JSON.parse("[" + y11 + "]");
		var array12 = JSON.parse("[" + y12 + "]");
		}
		
		if(classs=="Year 7"){
        $('#chart1').highcharts({
            navigation: {
                buttonOptions: {
                    enabled: false
                }
            },
            title: {
                text: stuname.toUpperCase()+'\'s PERFORMANCE IN '.toUpperCase()+subject.toUpperCase(),
                x: -20 //center
            },
            subtitle: {
                text: 'with focus on term',
                x: -20
            },
            xAxis: {
                categories: ['First Term', 'Second Term', 'Third Term'
                ]
            },
            yAxis: {
                title: {
                    text: 'Scores (%)'
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                valueSuffix: '%'
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle',
                borderWidth: 0
            },
            series: [{
                name: charlab77,
                data:  array7					
            }]
        });
		}
		else if(classs=="Year 1"){
        $('#chart1').highcharts({
            navigation: {
                buttonOptions: {
                    enabled: false
                }
            },
            title: {
                text: stuname.toUpperCase()+'\'s PERFORMANCE IN '.toUpperCase()+subject.toUpperCase(),
                x: -20 //center
            },
            subtitle: {
                text: 'with focus on term',
                x: -20
            },
            xAxis: {
                categories: ['First Term', 'Second Term', 'Third Term'
                ]
            },
            yAxis: {
                title: {
                    text: 'Scores (%)'
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                valueSuffix: '%'
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle',
                borderWidth: 0
            },
            series: [{
                name: charlab11,
                data:  array1					
            }]
        });
		}
		else if(classs=="Year 2"){
        $('#chart1').highcharts({
            navigation: {
                buttonOptions: {
                    enabled: false
                }
            },
             title: {
                text: stuname.toUpperCase()+'\'s PERFORMANCE IN '.toUpperCase()+subject.toUpperCase(),
                x: -20 //center
            },
            subtitle: {
                text: 'with focus on term',
                x: -20
            },
            xAxis: {
                categories: ['First Term', 'Second Term', 'Third Term'
                ]
            },
            yAxis: {
                title: {
                    text: 'Scores (%)'
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                valueSuffix: '%'
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle',
                borderWidth: 0
            },
            series: [{
                name: charlab11,
                data:  array1					
            }, {
                name: charlab22,
                data: array2
            }]
        });
		}
		else if(classs=="Year 3"){
        $('#chart1').highcharts({
            navigation: {
                buttonOptions: {
                    enabled: false
                }
            },
             title: {
                text: stuname.toUpperCase()+'\'s PERFORMANCE IN '.toUpperCase()+subject.toUpperCase(),
                x: -20 //center
            },
            subtitle: {
                text: 'with focus on term',
                x: -20
            },
            xAxis: {
                categories: ['First Term', 'Second Term', 'Third Term'
                ]
            },
            yAxis: {
                title: {
                    text: 'Scores (%)'
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                valueSuffix: '%'
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle',
                borderWidth: 0
            },
            series: [{
                name: charlab11,
                data:  array1					
            }, {
                name: charlab22,
                data: array2
            }, {
                name: charlab33,
                data: array3
            }]
        });
		}
		else if(classs=="Year 4"){
        $('#chart1').highcharts({
            navigation: {
                buttonOptions: {
                    enabled: false
                }
            },
             title: {
                text: stuname.toUpperCase()+'\'s PERFORMANCE IN '.toUpperCase()+subject.toUpperCase(),
                x: -20 //center
            },
            subtitle: {
                text: 'with focus on term',
                x: -20
            },
            xAxis: {
                categories: ['First Term', 'Second Term', 'Third Term'
                ]
            },
            yAxis: {
                title: {
                    text: 'Scores (%)'
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                valueSuffix: '%'
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle',
                borderWidth: 0
            },
            series: [{
                name: charlab11,
                data:  array1					
            }, {
                name: charlab22,
                data: array2
            }, {
                name: charlab33,
                data: array3
            }, {
                name: charlab44,
                data: array4
            }]
        });
		}
		else if(classs=="Year 5"){
        $('#chart1').highcharts({
            navigation: {
                buttonOptions: {
                    enabled: false
                }
            },
             title: {
                text: stuname.toUpperCase()+'\'s PERFORMANCE IN '.toUpperCase()+subject.toUpperCase(),
                x: -20 //center
            },
            subtitle: {
                text: 'with focus on term',
                x: -20
            },
            xAxis: {
                categories: ['First Term', 'Second Term', 'Third Term'
                ]
            },
            yAxis: {
                title: {
                    text: 'Scores (%)'
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                valueSuffix: '%'
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle',
                borderWidth: 0
            },
            series: [{
                name: charlab11,
                data:  array1					
            }, {
                name: charlab22,
                data: array2
            }, {
                name: charlab33,
                data: array3
            }, {
                name: charlab44,
                data: array4
            }, {
                name: charlab55,
                data: array5
            }]
        });
		}
		else if(classs=="Year 6"){
        $('#chart1').highcharts({
            navigation: {
                buttonOptions: {
                    enabled: false
                }
            },
             title: {
                text: stuname.toUpperCase()+'\'s PERFORMANCE IN '.toUpperCase()+subject.toUpperCase(),
                x: -20 //center
            },
            subtitle: {
                text: 'with focus on term',
                x: -20
            },
            xAxis: {
                categories: ['First Term', 'Second Term', 'Third Term'
                ]
            },
            yAxis: {
                title: {
                    text: 'Scores (%)'
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                valueSuffix: '%'
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle',
                borderWidth: 0
            },
            series: [{
                name: charlab11,
                data:  array1					
            }, {
                name: charlab22,
                data: array2
            }, {
                name: charlab33,
                data: array3
            }, {
                name: charlab44,
                data: array4
            }, {
                name: charlab55,
                data: array5
            }, {
                name: charlab66,
                data: array6
            }]
        });
		}
		else if(classs=="Year 8"){
        $('#chart1').highcharts({
            navigation: {
                buttonOptions: {
                    enabled: false
                }
            },
             title: {
                text: stuname.toUpperCase()+'\'s PERFORMANCE IN '.toUpperCase()+subject.toUpperCase(),
                x: -20 //center
            },
            subtitle: {
                text: 'with focus on term',
                x: -20
            },
            xAxis: {
                categories: ['First Term', 'Second Term', 'Third Term'
                ]
            },
            yAxis: {
                title: {
                    text: 'Scores (%)'
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                valueSuffix: '%'
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle',
                borderWidth: 0
            },
            series: [{
                name: charlab77,
                data:  array7					
            }, {
                name: charlab88,
                data: array8
            }]
        });
		}
		else if(classs=="Year 9"){
        $('#chart1').highcharts({
            navigation: {
                buttonOptions: {
                    enabled: false
                }
            },
             title: {
                text: stuname.toUpperCase()+'\'s PERFORMANCE IN '.toUpperCase()+subject.toUpperCase(),
                x: -20 //center
            },
            subtitle: {
                text: 'with focus on term',
                x: -20
            },
            xAxis: {
                categories: ['First Term', 'Second Term', 'Third Term'
                ]
            },
            yAxis: {
                title: {
                    text: 'Scores (%)'
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                valueSuffix: '%'
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle',
                borderWidth: 0
            },
            series: [{
                name: charlab77,
                data:  array7					
            }, {
                name: charlab88,
                data: array8
            }, {
                name: charlab99,
                data: array9
            }]
        });
		}
		else if(classs=="Year 10"){
        $('#chart1').highcharts({
            navigation: {
                buttonOptions: {
                    enabled: false
                }
            },
             title: {
                text: stuname.toUpperCase()+'\'s PERFORMANCE IN '.toUpperCase()+subject.toUpperCase(),
                x: -20 //center
            },
            subtitle: {
                text: 'with focus on term',
                x: -20
            },
            xAxis: {
                categories: ['First Term', 'Second Term', 'Third Term'
                ]
            },
            yAxis: {
                title: {
                    text: 'Scores (%)'
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                valueSuffix: '%'
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle',
                borderWidth: 0
            },
            series: [{
                name: charlab77,
                data:  array7					
            }, {
                name: charlab88,
                data: array8
            }, {
                name: charlab99,
                data: array9
            }, {
                name: charlab1010,
                data: array10
            }]
        });
		}
		else if(classs=="Year 11"){
        $('#chart1').highcharts({
            navigation: {
                buttonOptions: {
                    enabled: false
                }
            },
             title: {
                text: stuname.toUpperCase()+'\'s PERFORMANCE IN '.toUpperCase()+subject.toUpperCase(),
                x: -20 //center
            },
            subtitle: {
                text: 'with focus on term',
                x: -20
            },
            xAxis: {
                categories: ['First Term', 'Second Term', 'Third Term'
                ]
            },
            yAxis: {
                title: {
                    text: 'Scores (%)'
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                valueSuffix: '%'
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle',
                borderWidth: 0
            },
            series: [{
                name: charlab77,
                data:  array7					
            }, {
                name: charlab88,
                data: array8
            }, {
                name: charlab99,
                data: array9
            }, {
                name: charlab1010,
                data: array10
            }, {
                name: charlab1111,
                data: array11
            }]
        });
		}
		else if(classs=="Year 11"){
        $('#chart1').highcharts({
            navigation: {
                buttonOptions: {
                    enabled: false
                }
            },
             title: {
                text: stuname.toUpperCase()+'\'s PERFORMANCE IN '.toUpperCase()+subject.toUpperCase(),
                x: -20 //center
            },
            subtitle: {
                text: 'with focus on term',
                x: -20
            },
            xAxis: {
                categories: ['First Term', 'Second Term', 'Third Term'
                ]
            },
            yAxis: {
                title: {
                    text: 'Scores (%)'
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                valueSuffix: '%'
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle',
                borderWidth: 0
            },
            series: [{
                name: charlab77,
                data:  array7					
            }, {
                name: charlab88,
                data: array8
            }, {
                name: charlab99,
                data: array9
            }, {
                name: charlab1010,
                data: array10
            }, {
                name: charlab1111,
                data: array11
            }]
        });
		}
		else if(classs=="Year 12"){
        $('#chart1').highcharts({
            navigation: {
                buttonOptions: {
                    enabled: false
                }
            },
             title: {
                text: stuname.toUpperCase()+'\'s PERFORMANCE IN '.toUpperCase()+subject.toUpperCase(),
                x: -20 //center
            },
            subtitle: {
                text: 'with focus on term',
                x: -20
            },
            xAxis: {
                categories: ['First Term', 'Second Term', 'Third Term'
                ]
            },
            yAxis: {
                title: {
                    text: 'Scores (%)'
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                valueSuffix: '%'
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle',
                borderWidth: 0
            },
            series: [{
                name: charlab77,
                data:  array7					
            }, {
                name: charlab88,
                data: array8
            }, {
                name: charlab99,
                data: array9
            }, {
                name: charlab1010,
                data: array10
            }, {
                name: charlab1111,
                data: array11
            }, {
                name: charlab1212,
                data: array12
            }]
        });
		}
    });
    </script>
<?php
include("footer.php");
?>
</body>
</html>