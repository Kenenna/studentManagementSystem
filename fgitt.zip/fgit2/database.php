<?php
$username = 'thetutor_user';
$password = 'Uandme_12';
$connection = new PDO( 'mysql:host=localhost;dbname=thetutor_db', $username, $password );
?>