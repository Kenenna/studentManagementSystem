<?php
	include("auth.php");	
	
	include 'connection.php';
//$score = $_POST['score'];
$teacher_id = $_POST['teacher_id'];
$student_name = $_POST['student_name'];
$subject = $_POST['subject'];
$remark = $_POST['remark'];
$teacher_name = $_POST['teacher'];
$class_name = $_POST['class_name'];
$year = $_POST['year'];
$term = $_POST['term'];
$camax = $_POST['camax'];
$exammax = $_POST['exammax'];

$ca2 = $_POST['ca'];	
$exam2 = $_POST['exam'];



for ($i = 0; $i <= (count($student_name)-1); $i++){
	//$ca[$i] = round(($ca2[$i]/$camax[$i])*40);
	//$exam[$i] = round(($exam2[$i]/$exammax[$i])*60);
	//$score[$i] = $ca[$i] + $exam[$i];
    $t = mysqli_query($db,"INSERT INTO scores(score,ca,exam,teacher_id,student_name,subject,remark,teacher_name,class_name,year,term,camaxname,exammaxname) VALUES(((('$ca2[$i]'/'$camax[$i]')*40)+(('$exam2[$i]'/'$exammax[$i]')*60)),(('$ca2[$i]'/'$camax[$i]')*40),(('$exam2[$i]'/'$exammax[$i]')*60),'$teacher_id[$i]','$student_name[$i]','".ucfirst($subject[$i])."','$remark[$i]','$teacher_name[$i]','$class_name[$i]','$year[$i]','$term[$i]','$camax[$i]','$exammax[$i]')");
    //$t = mysqli_query($db,"INSERT INTO scores(score,ca,exam,teacher_id,student_name,subject,remark,teacher_name,class_name,year,term,camaxname, exammaxname) VALUES('$score[$i]','$ca[$i]','$exam[$i]','$teacher_id[$i]','$student_name[$i]','".ucfirst($subject[$i])."','$remark[$i]','$teacher_name[$i]','$class_name[$i]','$year[$i]','$term[$i]','$camax[$i]','$exammax[$i]')");
}	
if($t){
echo "<p align='center'>scores saved successfully</p>";
echo '<meta content="2;index.php" http-equiv="refresh" />';
}	
else{
echo "<p align='center'>NOT SAVED! PLEASE CHECK TO ENSURE YOU HAVE INPUTTED MAX SCORES!</p>";
echo '<meta content="2;index.php" http-equiv="refresh" />';
}
?>

