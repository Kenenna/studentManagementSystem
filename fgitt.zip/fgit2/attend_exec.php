<?php
	session_start();
	include("auth.php");	
	
	include 'connection.php';
$student_name = $_POST['student_name'];
$attend = $_POST['attend'];
$class = $_POST['class'];
$arms = $_POST['arms'];
$year = $_POST['year'];
$term = $_POST['term'];
$datename = $_POST['datename'];
$formt = $_POST['formt'];
$dtime = $_POST['dtime'];
$schopen = $_POST['schopen'];


$resultsex = mysqli_query($db, "SELECT * FROM regstu where school='".$_SESSION["school"]."'");
while ($row3 = mysqli_fetch_assoc($resultsex)) {
$sex1[] = $row3['sex'];
$student_namereg[] =  $row3['student_name'];	
}
$sex = $sex1;
$student_nameregi = $student_namereg;
$mer = array_intersect($student_nameregi, $student_name);
$v = array_unique(array_merge($student_name, $mer));
//print_r($v);
for ($i = 0; $i <= (count($v)-1); $i++){
$resultsex = mysqli_query($db, "SELECT * FROM regstu where student_name='$student_name[$i]' AND school='".$_SESSION["school"]."'");	
while ($row3 = mysqli_fetch_assoc($resultsex)) {
	if($row3['student_name'] == $student_name[$i]){
	$se[] = $row3['sex'];
}}}
$ses = $se;
$s = array_merge($ses, $ses);


$clcl= $class[0];
$arar= $arms[0];
$yryr= $year[0];
$terter= $term[0];
$dada= $datename[0];
$fofo= $formt[0];
$alreadytaken = mysqli_query($db, "SELECT * FROM attend where class='$clcl' AND arms='$arar' AND year='$yryr' AND term='$terter' AND datename='$dada' AND formt='$fofo' AND school='".$_SESSION["school"]."'");	
$alreadytakenno = mysqli_query($db, "SELECT DISTINCT(student_name) FROM studentsbyclass where class='$clcl' AND year='$yryr' AND term='$terter' AND formt='$fofo' AND arms='$arar' AND school='".$_SESSION["school"]."'");
$alreadytakenyes = mysqli_query($db, "SELECT DISTINCT(student_name) FROM attend where class='$clcl' AND arms='$arar' AND year='$yryr' AND term='$terter' AND formt='$fofo' AND datename='$dada' AND school='".$_SESSION["school"]."'");	

$alreadytakencount = mysqli_num_rows($alreadytaken);
$alreadytakencountno = mysqli_num_rows($alreadytakenno);
$alreadytakencountyes = mysqli_num_rows($alreadytakenyes);
$takencount = $alreadytakencountno - $alreadytakencountyes;
if($alreadytakencount < 1){
	if($takencount > 0){
for ($i = 0; $i <= (count($student_name)-1); $i++){
	if($attend[$i] == "present"){
		$status[$i] = "present";
	}elseif($attend[$i] == "midterm"){
		$status[$i] = "midterm";
	}else
	{
		$status[$i] = "absent";
	}
	
	if($dada==null){
		
	}else{
    $t = mysqli_query($db,"INSERT INTO attend(student_name,class,arms,year,term,attend,datename,formt, sex, dtime, schoolopen, school) VALUES('$student_name[$i]','$class[$i]','$arms[$i]','$year[$i]','$term[$i]','$status[$i]','$datename[$i]','$formt[$i]','$s[$i]','$dtime[$i]','$schopen[$i]','".$_SESSION["school"]."')");
	}
}
}
}
else if($alreadytakencount >= 1){
	if($takencount > 0){
for ($i = 0; $i <= (count($student_name)-1); $i++){
	if($attend[$i] == "present"){
		$status[$i] = "present";
	}elseif($attend[$i] == "midterm"){
		$status[$i] = "midterm";
	}else
	{
		$status[$i] = "absent";
	}
	
	if($dada==null){
		
	}else{
    $t = mysqli_query($db,"INSERT INTO attend(student_name,class,arms,year,term,attend,datename,formt, sex, dtime, schoolopen, school) VALUES('$student_name[$i]','$class[$i]','$arms[$i]','$year[$i]','$term[$i]','$status[$i]','$datename[$i]','$formt[$i]','$s[$i]','$dtime[$i]','$schopen[$i]','".$_SESSION["school"]."')");
	}
}
}
}
else{
	
}
	
if($t){
	//echo "<p align='center'>attendance taken successfully</p>";
	//echo '<meta content="2;index.php" http-equiv="refresh" />';
	echo 1;
}	
else{
	//echo "<p align='center'>not saved</p>";
	//echo '<meta content="2;index.php" http-equiv="refresh" />';
	echo 0;
} 

?>

