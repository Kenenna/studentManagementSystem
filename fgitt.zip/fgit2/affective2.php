<?php 
include("auth.php"); //include auth.php file on all secure pages

if(isset($_POST['btn-upload'])){
include "connection.php";
        $teacher_id = $_POST['teacher_id'];
		$teacher_name = $_POST['teacher_name'];
        $class_id = $_POST['class_id'];
		$year_id = $_POST['year_id'];
		$term_id = $_POST['term_id'];
		$subject_id = $_POST['subject_id'];
        $query = ("INSERT into `teachers` (teacher_id, teacher_name, class_id, year_id, term_id, subject_id) VALUES ('$teacher_id', '$teacher_name', '$class_id', '$year_id', '$term_id', '$subject_id')");
        $result = mysqli_query($db,$query);
        if($result){
            echo "<div class='form'><h3>Data was sent successfully.</h3></div>";
			echo '<meta content="2;index.php" http-equiv="refresh" />';
        }
    }
?>


<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Domains</title>
<link rel="stylesheet" href="style.css" type="text/css" />
<link rel="stylesheet" href="css/style.css" />
		<link href="table/css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
        <link rel="stylesheet" type="text/css" href="table/css/DT_bootstrap.css">

	<script src="table/js/jquery.js" type="text/javascript"></script>
<script src="table/js/bootstrap.js" type="text/javascript"></script>
	
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/jquery.dataTables.js"></script>
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/DT_bootstrap.js"></script>

<style>
ul.topnav {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}
ul.topnav li {float: left;}
ul.topnav li a {
    display: inline-block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    transition: 0.3s;
    font-size: 17px;
}
ul.topnav li a:hover {background-color: #555;}
ul.topnav li.icon {display: none;}

@media screen and (max-width:680px) {
  ul.topnav li:not(:first-child) {display: none;}
  ul.topnav li.icon {
    float: right;
    display: inline-block;
  }
}
@media screen and (max-width:680px) {
  ul.topnav.responsive {position: relative;}
  ul.topnav.responsive li.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  ul.topnav.responsive li {
    float: none;
    display: inline;
  }
  ul.topnav.responsive li a {
    display: block;
    text-align: left;
  }
}
</style>

<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>
</head>

<body>
<ul class="topnav" id="myTopnav">
  <li><a href="index.php">Classes You Teach</a></li>
  <li><a href="teacher-student.php">Add scores</a></li>
  <li><a href="update-score.php">Update scores</a></li>
  <li><a href="#contact"><a href="formclasses.php">Your Classes as Form Tutor</a></a></li>
  <li><a href="logout.php">Logout</a></li>
  <li class="icon">
    <a href="javascript:void(0);" onclick="myFunction()">&#9776;</a>
  </li>
</ul>
<p>Welcome <?php echo $_SESSION['username']; ?>!</p>

<br>

<?php
include "connection.php";
$user=$_SESSION['username'];
$result2 = mysqli_query($db, "SELECT * FROM users2 where username='$user'");
while($row2 = mysqli_fetch_assoc($result2))
{
	$a = $row2['teacher_id'];
	$b = $row2['teacher'];
}
$s =  $a;
$t = $b;

echo '<center>';
echo '<div class="row-fluid" style="width:100%;">';
echo '<div class="span12">';
echo '<div class="container" style="width:100%;">';
echo '<table style="width:100%; text-align: center;" cellpadding="1" cellspacing="1" border="1" class="table table-striped table-bordered" id="example">';
echo '<thead><tr>';
echo '<th style="display: none;"></th><th style="display: none;">Tutor ID</th><th style="text-align: center;">Tutor</th><th style="text-align: center;">Class</th><th style="text-align: center;">Year</th><th style="text-align: center;">Term</th><th style="text-align: center;">Action</th><th style="display: none;"></th>';
echo '</thead></tr>';
 

$result = mysqli_query($db, "SELECT * FROM formt where teacher_id='$s' ORDER BY id ASC");
while($row = mysqli_fetch_assoc($result)){
echo '<tr>';
echo '<td style="display: none;"><form action="tableedit.php" method="POST"></td>';
echo '<td style="display: none;"><input type="hidden" name="teacher_id" value="'.$row['teacher_id'].'" /></td>';
echo '<td style="text-align: center;"><input type="hidden" name="teacher" value="'.$t.'" />'.$t.'</td>';
echo '<td style="text-align: center;"><input type="hidden" name="class" value="'.$row['class_name'].'" />'.$row['class_name'].'</td>';
echo '<td style="text-align: center;"><input type="hidden" name="year" value="'.$row['year'].'" />'.$row['year'].'</td>';
echo '<td style="text-align: center;"><input type="hidden" name="term" value="'.$row['term'].'" />'.$row['term'].'</td>';
echo '<td style="text-align: center;"><input type="submit" name="btn-upload" value="View the students" /></td>';
echo '<td style="display: none;"></form></td>';
echo '</tr>';
}
?>
</table>
</div></div></div>
</center>
<br>