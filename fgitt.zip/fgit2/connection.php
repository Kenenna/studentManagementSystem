<?php
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'thetutor_user');
define('DB_PASSWORD', 'Uandme_12');
define('DB_DATABASE', 'thetutor_db');
$db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>