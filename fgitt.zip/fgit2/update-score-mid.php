<?php
	session_start();
	include "connection.php";
	include("auth.php"); 
	include('db.php');
	
	$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Update Scores</title>
<link rel="stylesheet" href="style.css" type="text/css" />
<link rel="stylesheet" href="css/style.css" />
	<script src="table/js/jquery.js" type="text/javascript"></script>
		<script src="datatablejs.js" type="text/javascript"></script>
	<!--<script src="https://cdn.datatables.net/buttons/1.4.2/js/dataTables.buttons.min.js" type="text/javascript"></script>-->
	<!--<script src="//cdn.datatables.net/buttons/1.4.2/js/buttons.colVis.min.js" type="text/javascript"></script>-->
	<link rel="stylesheet" type="text/css" href="datatablecss.css">
	 <link rel="stylesheet" type="text/css" href="datatablebuttoncss.css">
    <script type="text/javascript">
    $(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
		paging: false,
        buttons: [
        {
            extend: 'colvis',
            columns: ':gt(1)'
        }
    ]
    });
	
});
    </script>
  
   <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
   
   
$("#class_name option").eq(7).css("display","none");
$("#class_name").on("change",function(){
var bb = $("#class_name").find(":selected").text();
var b = null;
if(bb=="Primary 1"){
	b = "Year 1";
}
else if(bb=="Primary 2"){
	b = "Year 2";
}
else if(bb=="Primary 3"){
	b = "Year 3";
}
else if(bb=="Primary 4"){
	b = "Year 4";
}
else if(bb=="Primary 5"){
	b = "Year 5";
}
else if(bb=="Primary 6"){
	b = "Year 6";
}
else if(bb=="JS1"){
	b = "Year 7";
}
else if(bb=="JS2"){
	b = "Year 8";
}
else if(bb=="JS3"){
	b = "Year 9";
}
else if(bb=="SS1"){
	b = "Year 10";
}
else if(bb=="SS2"){
	b = "Year 11";
}
else if(bb=="SS3"){
	b = "Year 12";
}
else{
	b = bb;
}
$("#class_name").find(":selected").val(b);
var c = $("#class_name").find(":selected").val();
//alert(c);
  }); 
  });
 </script>
<style>
ul.topnav {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}
ul.topnav li {float: left;}
ul.topnav li a {
    display: inline-block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    transition: 0.3s;
    font-size: 17px;
}
ul.topnav li a:hover {background-color: #555;}
ul.topnav li.icon {display: none;}

@media screen and (max-width:680px) {
  ul.topnav li:not(:first-child) {display: none;}
  ul.topnav li.icon {
    float: right;
    display: inline-block;
  }
}
@media screen and (max-width:680px) {
  ul.topnav.responsive {position: relative;}
  ul.topnav.responsive li.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  ul.topnav.responsive li {
    float: none;
    display: inline;
  }
  ul.topnav.responsive li a {
    display: block;
    text-align: left;
  }
}
</style>

<script>
$(document).ready(function(){
	var inihw = $(".newhwmax").val();
	var inicw = $(".newcwmax").val();
	var initest = $(".newtestmax").val();
	$("#txtFirstName").val(inihw);
	$("#txtFirstName1").val(inicw);
	$("#txtFirstName2").val(initest); 
	$("#txtFirstName").css("width","30px");
	$("#txtFirstName1").css("width","30px");
	$("#txtFirstName2").css("width","30px");
	$("#txtFirstName").before("<span>HW MAX:</span> ");
	$("#txtFirstName1").before("<span>CW MAX:</span> ");
	$("#txtFirstName2").before("<span>TEST MAX:</span> ");
	$("#dosomething").click(function(){	
	var inihw2 = $(".newhwmax").val();
	var inicw2 = $(".newcwmax").val();
	var initest2 = $(".newtestmax").val();
	
	var valueit=$('#txtFirstName').val();
	var valueit1=$('#txtFirstName1').val();	
	var valueit2=$('#txtFirstName2').val();	
 if(valueit == 0){
	 $(".newhwmax").val(inihw);
				}
 else{
	 $(".newhwmax").val(valueit);
	}				
	if(valueit1 == 0){
	 $(".newcwmax").val(inicw);
				}
 else{
	 $(".newcwmax").val(valueit1);
	}
	if(valueit2 == 0){
	 $(".newtestmax").val(initest);
				}
 else{
	 $(".newtestmax").val(valueit2);
	}
});
});
</script>

<script>
$(document).ready(function() {
	var countabs = $('table#example tr:last').index()+1;
	//alert(countabs);
 $("#takest").html("Show Students Request Form");
$("#takestu").hide();
 $("#takest").click(function( event ) {
		event.preventDefault();
		var hi = $("#takest").html();
		if(hi == "Show Students Request Form"){	
		$("#takest").html("Hide Students Request Form");
		$("#takestu").show();
		$("#pushit").hide();
		}
		else if(hi == "Hide Students Request Form"){	
		$("#takest").html("Show Students Request Form");
		$("#takestu").hide();
		$("#pushit").show();
		}
	 });	
	 
$(".vertclasscont").click(function() {	
$("#formid").submit();
}); 
		
$("#formid").submit(function( event ) {
event.preventDefault();	
$.ajax({
type: "POST",
url: "update_score_mid_exec.php",
data: $("#formid").serializeArray(),	
success: function(response){
	var rowed = response.split("|")
		response0 = rowed[0];
		response1 = rowed[1];
		response2 = rowed[2];
		response3 = rowed[3];
		response4 = rowed[4];
		response5 = rowed[5];
		response6 = rowed[6];
		response7 = rowed[7];
	var rowedd1 = response1.split("-");
	var rowedd2 = response2.split("-");
	var rowedd3 = response3.split("-");
	var rowedd4 = response4.split("-");
	var rowedd5 = response5.split("-");
	var rowedd6 = response6.split("-");
	  $( ".scoreraw" ).each(function( index ){
	   var scid2 = this.id;
	   var scid = scid2.slice(8);
	  $('[id=scoreraw'+scid+']').val(rowedd1[index]);
	});
	
	var countab = $('table#example tr:last').index()+1;
	
   $( ".score" ).each(function( index ){
	  var cc = this.id;
	  var c = cc.slice(5);
	  if(countabs==countab){
	   $('[id=score'+index+']').val(rowedd2[index]);
	    $('[id=scoreraw'+index+']').val(rowedd1[index]);
		$('[id=hwraw_id_'+index+']').val(rowedd3[index]);
		$('[id=hw'+index+']').val(rowedd4[index]);
		$('[id=cw'+index+']').val(rowedd5[index]);
		$('[id=test'+index+']').val(rowedd6[index]);
	  }else{
		 $('[id=score'+c+']').val(rowedd2[c]);
	    $('[id=scoreraw'+c+']').val(rowedd1[c]);
		$('[id=hw'+c+']').val(rowedd4[c]);
		$('[id=cw'+c+']').val(rowedd5[c]);
		$('[id=test'+c+']').val(rowedd6[c]);
	  }
	});
		
 if(response7=="1") { 
		event.preventDefault();
		$(".success").fadeIn();
		setTimeout(function() { $(".success").fadeOut(); }, 2000); 
    } else {
		 $(".error").show();
		setTimeout(function() { $(".error").fadeOut(); }, 2000);
		}
		}
});	
});	 
});
</script>


 <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
   <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>

</head>
<body>
<?php
echo '<div id="headerit">';
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");
}
elseif($_SESSION['role'] == 'student'){
include("headerstudent.php");
}
else{header("location: logout.php");}
echo '</div>';
?>
<?php
$user = $_SESSION['username'];
?>
<BR><BR><br>
<center>
<a style="color: red; font-weight: bold; font-size: 20px; text-decoration: none;" href="#" id="takest"></a><br>
</center>
<center>
<form action="" method="post" class="cls" id="takestu" enctype="multipart/form-data">
 <div>
 <?php 
include "connection.php";
	$cccc = 0;
	$cccc2 = 0;	
?> 
	<label><select style="width:15%;" name="class_name" id="class_name" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM classes");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option>';
								if($ctype=="Js"){
								if($cccc == 0){	
									$cccc++;
									echo 'SELECT A CLASS';
									continue;
									}		
								if($cccc <= 3){
								echo 'JS'.$cccc;	
								}
								elseif($cccc >= 4 && $cccc <= 6){
									if($cccc == 4){	
									$cccc++;
									echo 'SS'.($cccc2 - 2);	
									continue;
									}
									if($cccc == 5){	
									$cccc++;
									echo 'SS'.($cccc2 - 1);	
									continue;
									}
									if($cccc == 6){	
									$cccc++;
									echo 'SS'.($cccc2 - 0);	
									continue;
									}
								}else{
									break;
								}
								$cccc++;	
								$cccc2++;
									}
								else{	
								if($ctype=="Primary"){
									if($cccc == 0){	
									$cccc++;
									echo 'SELECT A CLASS';
									continue;
									}
								echo 'Primary '.$cccc;
								if($cccc > 5){
									break;
								}
								$cccc++;	
								}
								else{
								echo 'Year '.$cccc;
								if($cccc > 11){
									break;
								}
								$cccc++;	
								}
								}//end of else
								echo '</option>';
							}
						?>
      </select>
	   <br>
	  <?php
	  echo '<select style="width: 210px; height: auto; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="arms" id="arms" required >';
	 $result = mysqli_query($db,"SELECT * FROM school where school='".$_SESSION["school"]."'");
				while($row = mysqli_fetch_assoc($result)){
					$arrr2[] = $row["arms"];
				}
				$a = implode(',',$arrr2);
				$b = explode(',',$a);
				$f = (array_filter($b));
				
						for($i=0; $i<=(count($f)-1); $i++)
							{  
								echo '<option value="'.$f[$i].'">';
								echo $f[$i];
								echo '</option>';
							}
    echo '</select>';
?>	
	  <br>
	  <select style="width:15%;" name="year" id="year" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM years");
	echo '<option value="none" disabled="disabled" selected>SESSION COMMENCING</option>';
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['year'].'">';
								echo $row['year'];
								echo '</option>';
							}
						?>
      </select>
	  
	  
	   <br>
	  <select style="width:15%;" name="term" id="term" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM terms");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['term'].'">';
								echo $row['term'];
								echo '</option>';
							}
						?>
      </select>
	   <br>
	  <select style="width:15%;" name="subject" id="subject" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM subjects ORDER BY subject ASC");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['subject'].'">';
								echo $row['subject'];
								echo '</option>';
							}
						?>
      </select>
	  
	   <br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM users2 where username='$user' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<input style="display:none" type="hidden" name="teacher_id" value="'.$row['teacher_id'].'">';
							}
						?>  
	  
	  </label>
	  
  <label>
      <input type="submit" class="button" name="btn-upload" id="sbutt" value="Submit Form" />
    </label>

  </div>
  </center>
</form><br>

<div id="formclass">
<?php
//if(isset($_POST['btn-upload'])){
	
$user=$_SESSION['username'];
$result3 = mysqli_query($db, "SELECT * FROM users2 where username='$user' AND school='".$_SESSION["school"]."'");
while($rowtid = mysqli_fetch_assoc($result3))
{
	$a = $rowtid['teacher_id'];
}
$tid =  $a;	
		
$classd = $_POST['class_name'];
$year = $_POST['year'];
$term = $_POST['term'];
$subject = $_POST['subject'];
$teacher_id = $tid;  
$arms = $_POST['arms'];


if($classd=='Primary 1'){
		$class_name = 'Year 1';
	}
	elseif($classd=='Primary 2'){
		$class_name = 'Year 2';
	}
	elseif($classd=='Primary 3'){
		$class_name = 'Year 3';
	}
	elseif($classd=='Primary 4'){
		$class_name = 'Year 4';
	}
	elseif($classd=='Primary 5'){
		$class_name = 'Year 5';
	}	
	elseif($classd=='Primary 6'){
		$class_name = 'Year 6';
	}
	elseif($classd=='JS1'){
		$class_name = 'Year 7';
	}
	elseif($classd=='JS2'){
		$class_name = 'Year 8';
	}
	elseif($classd=='JS3'){
		$class_name = 'Year 9';
	}
	elseif($classd=='SS1'){
		$class_name = 'Year 10';
	}
	elseif($classd=='SS2'){
		$class_name = 'Year 11';
	}	
	elseif($classd=='SS3'){
		$class_name = 'Year 12';
	}		
	else{
		$class_name = $classd;
	}

$resultcheck2 = mysqli_query($db, "SELECT * FROM scoresmid where arms='$arms' AND class_name='$class_name' AND year='$year' AND term='$term' AND subject='$subject' AND teacher_id='$teacher_id' AND school='".$_SESSION["school"]."'");
$resultcount2 = mysqli_num_rows($resultcheck2);   
if($resultcount2 == 0){
	echo ''; 
}else{
echo '<center>';
echo '<input type="text" placeholder="Max Hw Score" class="txtFirstName" id="txtFirstName">&nbsp;&nbsp;';
echo '<input type="text" placeholder="Max Cw Score" class="txtFirstName1" id="txtFirstName1">&nbsp;&nbsp;';
echo '<input type="text" placeholder="Max Test Score" class="txtFirstName2" id="txtFirstName2"><br>';
echo '<button id="dosomething" style="background-color: green; color: white;">Update Max Scores</button>';
echo '<div style="color: red;">NOTE THAT MAX HW, CW AND TEST SCORES ARE FOR ONLY THE 1ST HALF OF THE TERM.<br>TO UPDATE MAX SCORES FOR 2ND HALF, <a href="update-score.php">CLICK HERE.</a></div>';
echo '</center><br>';
}






$resultcheck = mysqli_query($db, "SELECT * FROM scoresmid where arms='$arms' AND class_name='$class_name' AND year='$year' AND term='$term' AND subject='$subject' AND teacher_id='$teacher_id' AND school='".$_SESSION["school"]."'");
$resultcount = mysqli_num_rows($resultcheck);   
if($resultcount == 0){
	if(isset($_POST['btn-upload'])){
	echo '<center><span style="color: red; font-size: 16px;">No scores to be updated for students in your '.$term. ', '.$year.', '.$classd.' '.$arms.' '.$subject.' class.<br /></span></center>'; 
	}
	}else{
echo '<center><span style="color: green; font-size: 16px;">Update the scores of students in your '.$term. ', '.$year.', '.$classd.' '.$arms.' '.$subject.' class.<br /></span></center>';            
	include "connection.php";
	
	echo '<div class="row-fluid" style="width:100%;">';
echo '<div class="span12">';
echo '<div class="container" style="width:100%;">';
echo '<form  name="form" class="formid" id="formid">';


echo '<div style="border: 0;">';
echo '<input type="submit" class="submit_button" name="submit" value="Update Scores" />';
echo '<label style="border: 0;">';
echo '<span class="error" style="display:none; color: red;"><img src="table/del.jpg" width="60" height="60"/>An update error has just occurred.</span>';
echo '<span class="success" style="display:none; color: green;"><img src="table/492.png" width="60" height="60"/> Scores updated successfully.</span>';
echo '</label>';
echo '</div>';

echo '<div style="float: left; width: 100%;">';
echo '<table style="width:100%;" cellpadding="1" cellspacing="1" border="1" class="display" id="example">';
echo '<thead><tr style="text-align:left;">';
echo '<th style="display: none;">Score ID</th><th style="text-align: center; width: 3%">Student\'s Name</th><th style="text-align: center; width: 3%">Total(%)</th><th style="text-align: center; width: 3%">Total (Raw)</th><th style="text-align: center; width: 3%">HW (RAW)</th><th style="text-align: center; width: 3%">CW (RAW)</th><th style="text-align: center; width: 3%">TEST (RAW)</th><th style="text-align: center; width: 3%">HW (30)</th><th style="text-align: center; width: 3%">CW (30)</th><th style="text-align: center; width: 3%">TEST (40)</th><th style="text-align: center; width: 3%">Remark</th><th style="display: none;">Class</th><th style="display: none;">Year</th><th style="display: none;" >Arm</th><th style="display: none;">Term</th><th style="display: none;">Subject</th><th style="display: none;">Teacher ID</th><th style="display: none;">HW Max</th><th style="display: none;">CW Max</th><th style="display: none;">Test Max</th>';
echo '</tr></thead>';
	$countmid = 0;
	$counter = 0;
$result = mysqli_query($db, "SELECT * FROM scoresmid where arms='$arms' AND class_name='$class_name' AND year='$year' AND term='$term' AND subject='$subject' AND teacher_id='$teacher_id' AND school='".$_SESSION["school"]."' ORDER BY student_name ASC");
						while($row = mysqli_fetch_assoc($result))
							{  
							 echo '<tr id="tr'.$counter.'" class="trclass">';
							  echo '<td style="display: none;" ><input type="text" id="id_'.$counter.'" class="clas" style="width:220px;" name="score_id[]" value="'.$row['score_id'].'" readonly="readonly" /></td>';
							 echo '<td style="text-align: center; width: 3%"><input id="student_name_id_'.$counter.'" class="student_name" style="text-align: center; width: 80%; display: none;" type="text" name="student_name[]" value="'.$row['student_name'].'" readonly />'.$row['student_name'].'</td>';
							 echo '<td style="text-align: center; width: 3%"><input style="text-align: center; width: 40%" type="text" value="'.$row['score'].'" name="score[]" class="score" id="score'.$counter.'" readonly/></td>';
							 echo '<td style="text-align: center; width: 3%"><input style="text-align: center; width: 60%" type="text" value="'.$row['scoreraw'].'" name="scoreraw[]" class="scoreraw" id="scoreraw'.$counter.'" readonly/></td>'; 
							 
							 echo '<td style="text-align: center; width: 3%"><input id="hwraw_id_'.$counter.'" class="clas" style="text-align: center; width: 60%; color: white; background-color: green;" type="text" value="'.$row['hwraw'].'" name="hwraw[]" /></td>';
							 echo '<td style="text-align: center; width: 3%"><input id="cwraw_id_'.$counter.'" class="clas" style="text-align: center; width: 60%; color: white; background-color: green;" type="text" value="'.$row['cwraw'].'" name="cwraw[]"  /></td>';
							 echo '<td style="text-align: center; width: 3%"><input id="test_id_'.$counter.'" class="clas" style="text-align: center; width: 60%; color: white; background-color: green;" type="text" value="'.$row['testraw'].'" name="testraw[]" /></td>';
							  
							 echo '<td style="text-align: center; width: 3%"><input style="text-align: center; width: 60%;" id="hw'.$counter.'" type="text" value="'.$row['hw'].'" name="hw[]" readonly/></td>';
							 echo '<td style="text-align: center; width: 3%"><input style="text-align: center; width: 60%;" id="cw'.$counter.'" type="text" value="'.$row['cw'].'" name="cw[]" readonly/></td>';
							 echo '<td style="text-align: center; width: 3%"><input style="text-align: center; width: 60%;" id="test'.$counter.'" type="text" value="'.$row['test'].'" name="test[]"  readonly/></td>';
							 echo '<td style="text-align: center; width: 50%; height: 70px;"><textarea style="text-align: left; width: 100%; height: 100%;" type="text" value="'.$row['remark'].'" name="remark[]" class="remark" id="remark_'.$countmid.'" />'.$row['remark'].'</textarea></td>';
							 echo '<td style="display: none;"><input type="text" name="class_name[]" id="class_name" value="'.$row['class_name'].'"></td>';
							 echo '<td style="display: none;"><input type="text" name="year[]" id="year" value="'.$row['year'].'"></td>';
							 echo '<td style="display: none;"><input type="text" name="arms[]" id="arms" value="'.$row['arms'].'"></td>';
							 echo '<td style="display: none;"><input type="text" name="term[]" id="term" value="'.$row['term'].'"></td>';
							 echo '<td style="display: none;"><input type="text" name="subject[]" id="subject" value="'.$row['subject'].'"></td>';
							 echo '<td style="display: none;" class="novis"><input type="text" name="teacher_id[]" id="teacher_id" value="'.$row['teacher_id'].'"></td>';
							 echo '<td style="display: none;" ><input style="text-align: center; width: 60%;" class="newhwmax" type="text" name="hwmaxname[]" id="hwmaxname" value="'.$row['hwmaxname'].'" readonly /></td>';
							 echo '<td style="display: none;" ><input style="text-align: center; width: 60%;" class="newcwmax" type="text" name="cwmaxname[]" id="cwmaxname" value="'.$row['cwmaxname'].'" readonly /></td>';
							echo '<td style="display: none;" ><input style="text-align: center; width: 60%;" class="newtestmax" type="text" name="testmaxname[]" id="testmaxname" value="'.$row['testmaxname'].'" readonly /></td>';
							echo  '</tr>';
							$countmid++;
							$counter++;
							}
echo '</table>';
echo '</div>';						
echo '<div style="border: 0;">';
echo '<input type="submit" class="submit_button" name="submit" value="Update Scores" />';
echo '<label style="border: 0;">';
echo '<span class="error" style="display:none; color: red;"><img src="table/del.jpg" width="60" height="60"/>An update error has just occurred.</span>';
echo '<span class="success" style="display:none; color: green;"><img src="table/492.png" width="60" height="60"/> Scores updated successfully.</span>';
echo '</label>';
echo '</div>';
//echo '<td style="display: none;"></td><td><input type="submit" class="submit_button" name="submit" value="Update Scores" /></td><td style="display: none;"></td><td style="display: none;"></td><td></td><td></td><td></td><td style="display: none;"></td><td></td><td></td><td></td><td style="display: none;"></td><td style="display: none;"></td><td style="display: none;"></td><td style="display: none;"></td>';	
echo '</form>';		
echo '</div></div></div>';
}//}
?>
<br>
<div id="pushit"><div id="pushit2">&nbsp;</div><br><br><br><br><br><br><br></div>
<?php
include("footer.php");
?>
<body>
</html>