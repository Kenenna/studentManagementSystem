<?php
	include("check.php");	
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Home</title>
<link rel="stylesheet" href="style.css" type="text/css" />
</head>

<body>
<h1 class="hello">Hello, <em><?php echo $login_user;?>!</em></h1>
<a href="subjstudents.php" style="font-size:18px">Select teachers with students</a><br>
<a href="update-score.php" style="font-size:18px">Update scores</a><br>

<a href="logout.php" style="font-size:18px">Logout?</a>
</body>
</html>