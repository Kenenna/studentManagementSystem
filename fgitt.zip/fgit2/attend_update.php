<?php
	include("auth.php"); 
	include('db.php');
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Insert Attendance</title>
<link rel="stylesheet" href="css/style.css" />
		<link href="table/css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
        <link rel="stylesheet" type="text/css" href="table/css/DT_bootstrap.css">

	<script src="table/js/jquery.js" type="text/javascript"></script>
<script src="table/js/bootstrap.js" type="text/javascript"></script>
	
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/jquery.dataTables.js"></script>
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/DT_bootstrap.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script>
$(document).ready(function() {
	var rowCount = $('.checkSingles').length;
	$(".checkSingles").slice( 0, (rowCount/2) ).css( "background-color", "green" );
	$(".checkSingles").slice(0, (rowCount/2)).css( "color", "white" );
	$(".checkSingles").slice((rowCount/2), rowCount).css( "color", "white" );
	$(".checkSingles").slice((rowCount/2), rowCount).css( "background-color", "blue" );
	$("input.checkSingleaft").slice( 0, (rowCount/2) ).val( "Morning" );
	$("input.checkSingleaft").slice((rowCount/2), rowCount).val( "Afternnon" );
	
  $("#checkedAll").change(function(){
    if(this.checked){
      $(".checkSingle").each(function(){
        this.checked=true;
      })              
    }else{
      $(".checkSingle").each(function(){
        this.checked=false;
      })              
    }
  });

  $(".checkSingle").click(function () {
    if ($(this).is(":checked")){
      var isAllChecked = 0;
      $(".checkSingle").each(function(){
        if(!this.checked)
           isAllChecked = 1;
      })              
      if(isAllChecked == 0){ $("#checkedAll").prop("checked", true); }     
    }
    else {
      $("#checkedAll").prop("checked", false);
    }
  });
  
  $(".checkSingle").click(function() {
    var chatt = this.id;
	//alert(chatt);
	var $ss = $('[id='+chatt+']').val();
	if($ss == 'absent'){
	 $('[id='+chatt+']').val("present");
	}
	else if($ss == 'present'){
	$('[id='+chatt+']').val("midterm");
	}
	else if($ss == 'midterm'){
	$('[id='+chatt+']').val("absent");
	}
	else{
	$('[id='+chatt+']').val("present");	
	}
	return false;
});
	$(".txtFirstName1").hide();
	$(".txtFirstName2").hide();
	$(".txtFirstName3").hide();
	var pr = $(".txtFirstName1").val("present");
    $("#dosomething1").click(function(){
	$(".checkSingle").val("present");
	});
   var abs = $(".txtFirstName2").val("absent");
    $("#dosomething2").click(function(){
	$(".checkSingle").val("absent");
	});
	var mterm = $(".txtFirstName3").val("midterm");
	$("#dosomething3").click(function(){
	$(".checkSingle").val("midterm");
	});
});
</script>


<style>
ul.topnav {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}
ul.topnav li {float: left;}
ul.topnav li a {
    display: inline-block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    transition: 0.3s;
    font-size: 17px;
}
ul.topnav li a:hover {background-color: #555;}
ul.topnav li.icon {display: none;}

@media screen and (max-width:680px) {
  ul.topnav li:not(:first-child) {display: none;}
  ul.topnav li.icon {
    float: right;
    display: inline-block;
  }
}
@media screen and (max-width:680px) {
  ul.topnav.responsive {position: relative;}
  ul.topnav.responsive li.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  ul.topnav.responsive li {
    float: none;
    display: inline;
  }
  ul.topnav.responsive li a {
    display: block;
    text-align: left;
  }
}
input.checkSingle{
	cursor: pointer;
}
</style>

<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>
</head>

<body>
<ul class="topnav" id="myTopnav">
  <li><a href="index.php">Classes You Teach</a></li>
  <li><a href="update-score.php">Update scores</a></li>
  <li><a href="formclasses.php">Your Classes as Form Tutor</a></li>
  <li><a href="affective.php">Input Ranks (Affective)</a></li>
  <li><a href="logout.php">Logout</a></li>
  <li class="icon">
    <a href="javascript:void(0);" onclick="myFunction()">&#9776;</a>
  </li>
</ul>
<?php
$user = $_SESSION['username'];
?>
<h1 class="hello">Hello, <em><?php echo $user;?>!</em></h1>

<form action="" method="post" enctype="multipart/form-data">
<center>
 <div>
  <?php include "connection.php"; ?>
   <label>Take Attendance</label><br><br>
	<label>
	<select style="width:15%;" name="class" id="class" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM classes");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['class_name'].'">';
								echo $row['class_name'];
								echo '</option>';
							}
						?>
      </select><br>
	  <select style="width:15%;" name="arms" id="arms" required >
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM arms");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['arms'].'">';
								echo $row['arms'];
								echo '</option>';
							}
						?>
      </select>
	  
	  <br>
	  <select style="width:15%;" name="year" id="year" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM years");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['year'].'">';
								echo $row['year'];
								echo '</option>';
							}
						?>
      </select>
	  
	  
	   <br>
	  <select style="width:15%;" name="term" id="term" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM terms");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['term'].'">';
								echo $row['term'];
								echo '</option>';
							}
						?>
      </select>

	
<br>
      <input type="date"  style="width:15%;" name="datename" />
    </label>
	
  <br>
      <input type="submit" style="background-color: green; color: white;" class="button" name="btn-upload" value="Get Students" />
   

  </div>
  </center>
</form>

<br>
<hr />
<br>

<form action="upatt.php" method="post" enctype="multipart/form-data">
<center>
 <div>
  <?php include "connection.php"; ?>
   <label>View Attendance</label><br><br>
	<label><select style="width:15%;" name="class" id="class" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM classes");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['class_name'].'">';
								echo $row['class_name'];
								echo '</option>';
							}
						?>
      </select>
	  
	  <br>
	  <select style="width:15%;" name="arms" id="arms" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM arms");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['arms'].'">';
								echo $row['arms'];
								echo '</option>';
							}
						?>
      </select>
	  
	  <br>
	  <select style="width:15%;" name="year" id="year" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM years");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['year'].'">';
								echo $row['year'];
								echo '</option>';
							}
						?>
      </select>
	  
	  
	   <br>
	  <select style="width:15%;" name="term" id="term" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM terms");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['term'].'">';
								echo $row['term'];
								echo '</option>';
							}
						?>
      </select>
	  </label>
  <br>
      <input type="submit" style="background-color: green; color: white;" class="button" name="btn-upload2" value="View Students" />

  </div>
  </center>
</form>
<center>
<br>
<!--<form action="upit.php" method="POST">
  <input type="submit" style="background-color: green; color: white;" class="button" name="btn-uploadup" value="View Students" />
  </form>-->

<?php
if(isset($_POST['btn-upload'])){	
$class = $_POST['class'];
$year = $_POST['year'];
$term = $_POST['term'];
$arms = $_POST['arms'];
$datename = $_POST['datename'];


$user=$_SESSION['username'];
$result3 = mysqli_query($db, "SELECT * FROM users2 where username='$user'");
while($rowtid = mysqli_fetch_assoc($result3))
{
	$tname = $rowtid['teacher'];
}
$tna = $tname;


$result = mysqli_query($db, "SELECT * FROM studentsbyclass where class='$class' AND year='$year' AND term='$term' AND formt='$tna' AND arms='$arms'");
$result2 = mysqli_query($db, "SELECT * FROM attend where class='$class' AND year='$year' AND term='$term' AND formt='$tna' AND datename='$datename' AND arms='$arms'");

while($row2 = mysqli_fetch_assoc($result2))
{  						
$values2[] = $row2['student_name'];
$values2attend[] = $row2['attend']; //for the attendance table
}
$values2 = array_merge($values2, $values2);
$values22 =($values2);
$valattend = ($values2attend);
$vtu = count($values22);

while($row = mysqli_fetch_assoc($result))
{  						
$values[] = $row['student_name']; 
$valuesclass[] = $row['class']; 
$valuesyear[] = $row['year']; 
$valuesterm[] = $row['term'];
$valuesarms[] = $row['arms']; 
}
$values = array_merge($values, $values);
$vallue = $values;

$vtuu = count($values);

current($valuesclass);
current($valuesyear);
current($valuesterm);
current($valuesarms);

$r = array_diff($vallue, $values22); 
echo '<br>';
//print_r($vallue);
//print_r($values22);
//print_r($r);
//echo $r;
$vtuuu = $vtuu - $vtu;
//echo $vtuuu;

include "connection.php";
$result3 = mysqli_query($db, "SELECT * FROM maxattname WHERE year='$year' AND term='$term'");
while ($row3 = mysqli_fetch_assoc($result3)) {
$termbegin1[] = $row3['termbegin'];	
}
$termbegin = current($termbegin1);



if($vtuuu < 1){
	
	echo "<span style='color:red; font-size:16px; text-decoration: underline;'>Either you have no students currently enrolled, or you have already inputed the attendance for the students enrolled in your class under the selected criteria!</span><br>";
}
else if($vtu == 0){
	//$valllue = current($vallue);
	//echo $valllue;
	$values22[] = "nothingham";
	//print_r($values22);
	$r = array_diff($vallue, $values22);
echo '<span style="color: green; font-size: 16px;">Take attendance of Students in '.current($valuesclass).''.current($valuesarms).' for '.current($valuesterm).', '.current($valuesyear).'</span><br />';		
echo '<br>';
echo '<center>';
echo '<input type="text" class="txtFirstName1" id="txtFirstName1">';
echo '<button id="dosomething1" style="background-color: green; color: white;">Set All TO PRESENT</button>';
echo '<input type="text" class="txtFirstName2" id="txtFirstName2">';
echo '<button id="dosomething2" style="background-color: green; color: white;">Set All TO ABSENT</button>';
echo '<input type="text" class="txtFirstName3" id="txtFirstName3"><br>';
echo '<button id="dosomething3" style="background-color: green; color: white;">Set All TO MIDTERM</button>';
echo '</center><br>';
echo '<br>';
echo '<form action="attend_exec.php" method="post">';
echo '<table id="fhalf"><thead><tr><th colspan="6"></th><tr></thead>';
echo '<tr><td style="text-align:center; font-weight: bold;">Student Name</td><td style="text-align:center; font-weight: bold;">Present</td><td style="display: none;">Class</td><td style="display: none;">Arm</td><td style="display: none;">Year</td><td style="display: none;">Term</td><td style="display: none;">Date</td><td style="font-weight: bold;">Day Period</td></tr>';		
$counter = 0;
foreach ($r as $key => $r['student_name']) {
echo '<tr class="checkSingles">';	
echo '<td style="text-align:center;"><input type="hidden" name="student_name[]" value="'.$r['student_name'].'" />'.$r['student_name'].'</td>';
echo '<td style="text-align:center;"><input style="width: 50%;" id="in_'.$counter.'" class="checkSingle" readonly="readonly" type="text" name="attend[]" value="absent" id="attend" /></td>';
echo '<td style="display: none;"><input type="text"  name="class[]" id="class_name" value="'.current($valuesclass).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="arms[]" id="arms" value="'.current($valuesarms).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="year[]" id="year" value="'.current($valuesyear).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="term[]" id="term" value="'.current($valuesterm).'" /></td>';
echo '<td style="display: none;"><input type="text" name="datename[]" id="datename" value="'.$datename.'"/></td>';
echo '<td style="display: none;"><input type="text" name="formt[]" id="formt" value="'.$tna.'"/></td>';
echo '<td><input readonly="readonly" style="width: 50%;" class="checkSingleaft" type="text" name="dtime[]" id="dtime" /></td>';
echo '</tr>';
$counter++;	
}
echo '<tr>';
echo '<td colspan="5"><input style="float: right;" type="submit" class="submit_button" name="submit" value="Submit Attendance" /></td>';
echo '</tr>';
echo '</table>';
echo '</form>';		
}
else{
echo '<center>';
echo '<span style="color: green; font-size: 16px;">Take attendance of Students in '.current($valuesclass).''.current($valuesclass).' for '.current($valuesterm).', '.current($valuesyear).'</span><br />';	
echo '<br>';
echo 'Check All<br />';		
echo '<form>';
echo '<input type="checkbox" name="checkedAll" id="checkedAll"></input>';
echo '</form><br>';
echo '<form action="teacher-student_exec.php" method="post">';
echo '<table id="fhalf" ><thead><tr><th style="text-align:center;">Student Name</th><th style="text-align:center;">Present</th><th style="display: none;">Class</th><th style="display: none;">Arm</th><th style="display: none;">Year</th><th style="display: none;">Term</th><th style="display: none;">Date</th></tr></thead>';
foreach ($r as $key => $r['student_name']) {
echo '<tr class="checkSingles">';
echo '<td style="text-align:center;"><input type="hidden" name="student_name[]" value="'.$r['student_name'].'" />'.$r['student_name'].'</td>';
echo '<td class="checkSingles" style="text-align:center;"><input class="checkSingle" type="checkbox" name="attend[]" value="present" id="attend" /></td>';
echo '<td style="display: none;"><input type="text"  name="class[]" id="class_name" value="'.current($valuesclass).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="arms[]" id="class_name" value="'.current($valuesarms).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="year[]" id="year" value="'.current($valuesyear).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="term[]" id="term" value="'.current($valuesterm).'" /></td>';
echo '<td style="display: none;"><input type="text" name="datename[]" id="datename" value="'.$datename.'"/></td>';
echo '<td style="display: none;"><input type="text" name="formt[]" id="formt" value="'.$tna.'"/></td>';
echo '</tr>';
}
echo '<tr>';
echo '<td colspan="5"><input style="float: right;" type="submit" class="submit_button" name="submit" value="Submit Scores" /></td>';
echo '</tr>';
echo '</table>';
echo '</form>';	
echo '</center>';
}
}
?>
<br>



</body>
</html>