<?php 
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";	
if(isset($_POST['submit2'])){

        $teacher_id = $_POST['teacher_id'];
		$teacher_name = $_POST['teacher_name'];
        //$class_id = $_POST['class_id'];
		$year_id = $_POST['year_id'];
		$term_id = $_POST['term_id'];
		$subject_id = $_POST['subject_id'];
		$caaz = $_POST['class_name'];
		
		if($caaz=='Primary 1'){
		$caa = 'Year 1';
	}
	elseif($caaz=='Primary 2'){
		$caa = 'Year 2';
	}
	elseif($caaz=='Primary 3'){
		$caa = 'Year 3';
	}
	elseif($caaz=='Primary 4'){
		$caa = 'Year 4';
	}
	elseif($caaz=='Primary 5'){
		$caa = 'Year 5';
	}	
	elseif($caaz=='Primary 6'){
		$caa = 'Year 6';
	}	
	else{
		$caa = $caaz;
	}	
			
		$resultsb = mysqli_query($db, "SELECT * FROM subjects where subject_id='$subject_id'");
						while($rowsb = mysqli_fetch_assoc($resultsb))
							{ 
						$subject = $rowsb['subject'];
							}
							$subject;
							
		$resultsb2 = mysqli_query($db, "SELECT * FROM classes where class_name='$caa'");
						while($rowsb2 = mysqli_fetch_assoc($resultsb2))
							{ 
						$class_id = $rowsb2['class_id'];
							}
							$class_id;
	
		$checkteach = mysqli_query($db, "SELECT * FROM teachers where teacher_name='$teacher_name' AND class_id='$class_id' AND year_id='$year_id' AND term_id='$term_id' AND subject_id='$subject_id' AND class_name='$caa' AND subject='$subject' AND school='".$_SESSION["school"]."'");
		$countteach = mysqli_num_rows($checkteach);
		if($countteach < 1){
	  $query = ("INSERT into `teachers` (teacher_id, teacher_name, class_id, year_id, term_id, subject_id, class_name, subject, school) VALUES ('$teacher_id', '$teacher_name', '$class_id', '$year_id', '$term_id', '$subject_id', '$caa', '$subject', '".$_SESSION["school"]."')");
        $result = mysqli_query($db,$query);
        if($result){
            $msg =  "<div class='form'><h3>Teacher was enrolled successfully.</h3></div>";
			$refres =  '<meta content="2;index2.php" http-equiv="refresh" />'; 
        }
		else{
			 $msg =  "<div class='form'><h3>Teacher was NOT enrolled.</h3></div>";
			$refres =  '<meta content="2;index2.php" http-equiv="refresh" />';
		}
		}
		else{
			 $msg =  "<div class='form'><h5 style='color: red;'>A Teacher with the given data has already been enrolled.</h5></div>";
			$refres =  '<meta content="2;index2.php" http-equiv="refresh" />';
		}
    }

$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);

	
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Enrol Teacher</title>
<link rel="stylesheet" href="css/style.css" />
	
        <link rel="stylesheet" type="text/css" href="table/css/DT_bootstrap.css">

	<script src="table/js/jquery.js" type="text/javascript"></script>
<script src="table/js/bootstrap.js" type="text/javascript"></script>
	
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/jquery.dataTables.js"></script>
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/DT_bootstrap.js"></script>
   
   <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() { 
  $("#class_name").on("change",function(){
var a = $("#class_name").find(":selected").text(); 
  });
 
  var gggg = $("[data-j=cn] option").length;	
if(gggg==8){
$("[data-j=cn] option").eq(7).css("display","none");
}
 
 
$("#subdbutton").on("click",function(){
var bb = $("[data-j=cn]").find(":selected").text();
var b = "";
if(bb=="Primary 1"){
	b = "Year 1";
}
else if(bb=="Primary 2"){
	b = "Year 2";
}
else if(bb=="Primary 3"){
	b = "Year 3";
}
else if(bb=="Primary 4"){
	b = "Year 4";
}
else if(bb=="Primary 5"){
	b = "Year 5";
}
else if(bb=="Primary 6"){
	b = "Year 6";
}
else if(bb=="JS1"){
	b = "Year 7";
}
else if(bb=="JS2"){
	b = "Year 8";
}
else if(bb=="JS3"){
	b = "Year 9";
}
else if(bb=="SS1"){
	b = "Year 10";
}
else if(bb=="SS2"){
	b = "Year 11";
}
else if(bb=="SS3"){
	b = "Year 12";
}
else{
	b = bb;
}
$("[data-j=cn]").find(":selected").val(b);
var c = $("[data-j=cn]").find(":selected").val();
//alert(c);
//alert(bb);
 });
  
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>
 <link rel="stylesheet" href="css/footer-distributed.css">
  <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
</head>
<body>
<?php
$resultrole2 = mysqli_query($db, "SELECT role, adminlevel FROM users2 where username='".$_SESSION['username']."'");
while($rowrole2 = mysqli_fetch_assoc($resultrole2))
{
	$arole[] = $rowrole2['role'];
	$adminlevel2[] = $rowrole2['adminlevel'];
}
$_SESSION['role'] =  current($arole);
$_SESSION['adminlevel'] =  current($adminlevel2);
if($_SESSION['role'] == 'teacher'){
	?>
<?php
include("header.php");
?>
<?php
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");
}
elseif($_SESSION['role'] == 'student'){
include("headerstudent.php");
}
else{header("location: logout.php");}
echo '<br>';
echo $msg;
echo '<br>';
echo $refres;
?>
<?php
if(isset($_POST['submit1'])){
$teacher = $_POST['teacher'];
$coun= "SELECT * FROM users2 WHERE teacher='$teacher' AND school='".$_SESSION['school']."'";
if ($result=mysqli_query($db, $coun)){
$rowcount=mysqli_num_rows($result);
if($rowcount == 1){	
 echo '<br><br><br>';   
echo '<div class="form">';
echo '<h1>Enrol A Teacher</h1>';
echo '<form name="registration" action="" method="post">';
while($row = mysqli_fetch_assoc($result)){
echo '<input type="hidden" name="teacher_id" value="'.$row['teacher_id'].'" required />';
echo '<input type="text" readonly="readonly" name="teacher_name" value="'.$row['teacher'].'" required /><br>';
}
$cccc = 0;
$cccc2 = 0;
echo '<select data-j="cn" style="width: 210px; height: auto; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 5px;" name="class_name" class="class_name" id="class_name" required >';
	$resultcl = mysqli_query($db, "SELECT * FROM classes");
						while($rowcl = mysqli_fetch_assoc($resultcl))
							{  
								$class1[] = $rowcl['class_id']; 
								echo '<option>';
								if($ctype=="Js"){
								if($cccc == 0){	
									$cccc++;
									echo 'SELECT A CLASS';
									continue;
									}		
								if($cccc <= 3){
								echo 'JS'.$cccc;	
								}
								elseif($cccc >= 4 && $cccc <= 6){
									if($cccc == 4){	
									$cccc++;
									echo 'SS'.($cccc2 - 2);	
									continue;
									}
									if($cccc == 5){	
									$cccc++;
									echo 'SS'.($cccc2 - 1);	
									continue;
									}
									if($cccc == 6){	
									$cccc++;
									echo 'SS'.($cccc2 - 0);	
									continue;
									}
								}else{
									break;
								}
								$cccc++;	
								$cccc2++;
									}
								else{	
								if($ctype=="Primary"){
									if($cccc == 0){	
									$cccc++;
									echo 'SELECT A CLASS';
									continue;
									}
								echo 'Primary '.$cccc;
								if($cccc > 5){
									break;
								}
								$cccc++;	
								}
								else{
								echo 'Year '.($cccc+1);
								if($cccc > 11){
									break;
								}
								$cccc++;	
								}
								}//end of else
								echo '</option>';
							}
echo '</select>';
echo '<select style="width: 210px; height: auto; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="year_id" class="year_id" id="year_id" required >';
echo '<option value="none" disabled="disabled" selected>SESSION COMMENCING</option>';
	$resultyr = mysqli_query($db, "SELECT year, year_id FROM years");
						while($rowyr = mysqli_fetch_assoc($resultyr))
							{  
								echo '<option value="'.$rowyr['year_id'].'">';
								echo $rowyr['year'];
								echo '</option>';
							}
echo '</select>';
echo '<select style="width: 210px; height: auto; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="term_id" class="term_id" id="term_id" required >';
include "connection.php";
	$resulttm = mysqli_query($db, "SELECT term, term_id FROM terms");
						while($rowtm = mysqli_fetch_assoc($resulttm))
							{  
								echo '<option value="'.$rowtm['term_id'].'">';
								echo $rowtm['term'];
								echo '</option>';
							}
echo '</select>';
echo '<select style="width: 210px; height: auto; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="subject_id" class="subject_id" id="subject_id" required >';

	$resultsb = mysqli_query($db, "SELECT subject, subject_id FROM subjects ORDER BY subject");
						while($rowsb = mysqli_fetch_assoc($resultsb))
							{  
								$rowbb = $rowsb['subject'];
								echo '<option value="'.$rowsb['subject_id'].'">';
								echo $rowbb;
								echo '</option>';
							}
echo '</select>';
echo '<input type="submit" name="submit2" id="subdbutton" value="Register" />';
echo '</form><br>';
echo '</div>';
}
else{
    echo '<br><br><br>';   
	echo "Teacher not registered yet.<br>";
	echo '<meta content="2;index2.php" http-equiv="refresh" />';
}
}
}
?>
<?php
include("footer.php");
	?>	
</body>