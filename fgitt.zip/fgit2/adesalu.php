<?php
$today = date("d/m/Y");
echo $today."<br>";
$fnum = 20;
$snum = 4;
$d = $fnum/$snum;
//echo $d;
if($d >8){
	echo "Hurray I am five";
}else{
	echo "Oops I am NOT five";
}
?>