<?php
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
$sourcePath = $_FILES['userImage']['tmp_name'];
$targetPath = "images/".$_FILES['userImage']['name'];
$id = $_POST['id'];
$img = $_POST['image2'];
if(move_uploaded_file($sourcePath,$targetPath)){
	$g = $targetPath;
}else{
	$g = $img;
}
	if($targetPath=="images/"){
	$sql3=mysqli_query($db,"UPDATE users2 SET img='$g' WHERE teacher_id='$id'");		
	}elseif($targetPath==""){
	$sql4=mysqli_query($db,"UPDATE users2 SET img='$g' WHERE teacher_id='$id'");	
	}elseif($img=="images/"){
	$sql5=mysqli_query($db,"UPDATE users2 SET img='$g' WHERE teacher_id='$id'");	
	}
	else{
	$sql6=mysqli_query($db,"UPDATE users2 SET img='$g' WHERE teacher_id='$id'");	
		}

if($sql3){
	echo $img;
}
elseif($sql4){
	echo $img;
}
elseif($sql5){
	echo $targetPath;
}
else{
	echo $targetPath;
}
?>