<?php
session_start();
	include "connection.php";
	include("auth.php"); 
$teacher_id = $_POST['teacher_id'];
$teacher_name = $_POST['teacher'];
$class = $_POST['class'];
$year = $_POST['year'];
$term = $_POST['term'];
$arm = $_POST['arm'];
$subject = $_POST['subject'];
$school= $_POST['school'];
$quiz_name = $_POST['quiz_name'];
date_default_timezone_set('Africa/Lagos');
$startt = $_POST['startt'];
$startd = $_POST['startd'];
$endt = $_POST['endt'];
$endd = $_POST['endd'];
$date_created = date('Y-m-d H:i:s');
$start_time = date("Y-m-d H:i:s", strtotime($startd.$startt));
$end_time = date("Y-m-d H:i:s", strtotime($endd.$endt));
$duration = $_POST['duration'];

$s = date("d/m/Y H:i:s", strtotime($start_time));
$e = date("d/m/Y H:i:s", strtotime($end_time));
$d = $duration;

$V = mysqli_query($db,"SELECT start_time, end_time, duration FROM teacher_quiz WHERE teacher_id='$teacher_id' AND teacher_name='$teacher_name' AND class='$class' AND year='$year' AND term='$term' AND arm='$arm' AND subject='$subject' AND school='$school' AND quiz_name='$quiz_name'");	
while($row = mysqli_fetch_assoc($V))
{
$sst2[] = $row['start_time'];
$eet2[] = $row['end_time'];
$dudu2[] = $row['duration'];
}
$sst = current($sst2);
$s2 = date("d/m/Y H:i:s", strtotime($sst));
$eet = current($eet2);
$e2 = date("d/m/Y H:i:s", strtotime($eet));
$dudu = current($dudu2);

if($s=='01/01/1970 01:00:00'){
	$start_time = $sst;
	$s = $s2;
}else{
	$start_time = $start_time;
	$s = $s;
}
if($e=='01/01/1970 01:00:00'){
	$end_time = $eet;
	$e = $e2;
}else{
	$end_time = $end_time;
	$e = $e;
}
$t = mysqli_query($db,"UPDATE teacher_quiz SET start_time='$start_time', end_time='$end_time', duration='$duration' WHERE teacher_id='$teacher_id' AND teacher_name='$teacher_name' AND class='$class' AND year='$year' AND term='$term' AND arm='$arm' AND subject='$subject' AND school='$school' AND quiz_name='$quiz_name'");	
if($t){
echo $s."|".$e."|".$d;
}
else{
	echo "Could NOT Update";
}
?>