<?php
	session_start();
	include("auth.php");	
	include 'db.php';
$student_name = $_POST['student_name'];
$class = $_POST['class'];
$year = $_POST['year'];
$term = $_POST['term'];
$formt = $_POST['formt'];
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$midname = $_POST['midname'];
$pfirstname = $_POST['pfirstname'];
$plastname = $_POST['plastname'];
$pmidname = $_POST['pmidname'];
$arm = $_POST['arm'];



for ($i = 0; $i <= (count($student_name)-1); $i++){
    $t = mysql_query("INSERT INTO affective(student_name,class,year,term,formt,firstname,lastname,midname,pfirstname,plastname,pmidname,ppfirstname,school) VALUES('$student_name[$i]','$class[$i]','$year[$i]','$term[$i]','$formt[$i]','$firstname[$i]','$lastname[$i]','$midname[$i]','$pfirstname[$i]','$plastname[$i]','$pmidname[$i]','$arm[$i]','".$_SESSION["school"]."')");
   }	
if($t){
echo "<p align='center'>Ratings saved successfully</p>";
echo '<meta content="2;affective.php" http-equiv="refresh" />';
}	
else{
echo "<p align='center'>NOT SAVED! PLEASE CHECK TO ENSURE YOU HAVE INPUTTED REQUIRED DATA!</p>";
echo '<meta content="2;affective.php" http-equiv="refresh" />';
}
?>

