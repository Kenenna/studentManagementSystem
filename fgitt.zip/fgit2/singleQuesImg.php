<?php
session_start();
include("auth.php");
include "connection.php";
$school = $_SESSION['school'];
$username = $_SESSION['username'];	
$sourcePath = $_FILES['userImg']['tmp_name'];
//$targetPath = "images/".$_FILES['userImg']['name'];
$targetPath = 'quiz/upload/'.$username.$school.'qfolder/'.$_FILES['userImg']['name'];
$targetPath2 = 'upload/'.$username.$school.'qfolder/'.$_FILES['userImg']['name'];
$id = $_POST['userId'];
move_uploaded_file($sourcePath,$targetPath);
	$g = $targetPath2;
	$sql3=mysqli_query($db,"UPDATE teacher_quiz SET question_name='$g' WHERE id='$id'");		
if($sql3){	
echo $g;
}
else{
	echo "could not update";
}
?>