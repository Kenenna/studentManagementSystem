<?php
session_start();
	include("auth.php");
	include("connection.php");
 if(isset($_POST["query"]))  
 {  
      $output = '';  
      $query = "SELECT * FROM regstu WHERE student_name LIKE '%".$_POST["query"]."%' AND school='".$_SESSION["school"]."'";  
      $result = mysqli_query($db, $query);  
      $output = '<ul class="list-unstyled">';  
      if(mysqli_num_rows($result) > 0)  
      {  
           while($row = mysqli_fetch_array($result))  
           {  
                $output .= '<li class="listit">'.$row["student_name"].'</li>';  
           }  
      }  
      else  
      {  
           $output .= '<li class="listit">Student not on record</li>';  
      }  
      $output .= '</ul>';  
      echo $output;  
 }  
?>