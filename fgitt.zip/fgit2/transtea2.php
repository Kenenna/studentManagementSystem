<?php
session_start();
include("auth.php"); //include auth.php file on all secure pages
include("connection.php");
$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Transcript</title>
<script type="text/javascript" src="js/jquery-2.1.4.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script>
$(document).ready(function() {	
$("#transpdfform").submit(function( evt ) {
			evt.preventDefault();
var countlist = $("#resultlist li").length;	
if(countlist > 0){
$(".liresultlist").fadeOut(500); 	
}		
$.ajax({
type: "POST",
url: "pdf4/examples/example05_tables2.php",
cache: false,
beforeSend: function(){
	$("#loadit").addClass("loader");
	$("#loadit").after("<label id='forremoval' style='color: red;' >We are preparing your download. Please wait...</label>");
	$('#attpdfsubmit').attr( 'onClick', 'return false' );
	},
data: $("#transpdfform").serialize(),
//$("#forresult").fadeOut(); 
success: function(response){	
$("#resultlist").append("<li class='liresultlist'><a class='pbutton' style='margin: auto; text-align: center;' id='forresult' href='pdf4/examples/"+response+"' download>download your transcript</a></li>");	
},
complete: function(){
$("#loadit").removeClass("loader");	
$("#forremoval").remove();
$('#attpdfsubmit').attr( 'onClick', 'return true' );
}
});			
});
});
</script>
<script>
$(document).ready(function(){
	$( "input[type=text]" ).css( "display", "none" );
	$("input[type=submit], .pbutton").hover(
	function(){$(this).css("background-color", "red");},
	function(){$(this).css("background-color", "grey");}
	);
	$("input[type=submit], .pbutton").hover(
	function(){$(this).css("color", "white");},
	function(){$(this).css("color", "red");}
	);
	$( "input[type=submit]" ).css("color", "black");
	$( "tr:even" ).css( "background-color", "white" );
	$( "tr:odd" ).css( "background-color", "white" );
	$( "tr:even" ).css( "color", "black" );
	$( "td:empty" ).text( "-" );
});
</script>

<script>
function printDiv(eleId){
    var PW = window.open('', '_blank', 'Print content');
 
    //IF YOU HAVE DIV STYLE IN CSS, REMOVE BELOW COMMENT AND ADD CSS ADDRESS
    //PW.document.write('<link rel="stylesheet" type="text/css" href="CSS-FILE-ADDRESS"/>');
 
    PW.document.write(document.getElementById(eleId).innerHTML);
    PW.document.close();
    PW.focus();
    PW.print();
    PW.close();
}
</script>
<style>
.pbutton {
	background-color:#44c767;
	-moz-border-radius:28px;
	-webkit-border-radius:28px;
	border-radius:2px;
	border:1px solid #18ab29;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:15px;
	padding:6px 12px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
	float: left;
	margin: 0;
}
.pbutton:hover {
	background-color:#5cbf2a;
}
.pbutton:active {
	position:relative;
	top:1px;
}
.loader {
  border: 8px solid #f3f3f3;
  border-radius: 50%;
  border-top: 8px solid blue;
  border-right: 8px solid green;
  border-bottom: 8px solid red;
  width: 20px;
  height: 20px;
  -webkit-animation: spin 2s linear infinite;
  animation: spin 2s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.dnone{
	display: none;
}
</style>

</head>
<body>
<br>
<?php
$class_name = $_POST['class_name'];
$year = $_POST['year'];
//include "connection.php";
$user1 = $_SESSION['username'];
$resultreguser = mysqli_query($db, "SELECT * FROM users2 WHERE username='$user1' AND school='".$_SESSION["school"]."'");
while($resultreguser2 = mysqli_fetch_assoc($resultreguser)){ 
$st_name[] = $resultreguser2['teacher'];
}
$student_name2 = current($st_name);
$student_name = $_POST['student_name'];
$resultreg = mysqli_query($db, "SELECT * FROM regstu WHERE caa='$class_name' AND yoa='$year' AND student_name='$student_name2' AND school='".$_SESSION["school"]."'");
$resultreg33 = mysqli_query($db, "SELECT * FROM regstu WHERE caa='$class_name' AND yoa='$year' AND student_name='$student_name' AND school='".$_SESSION["school"]."'");
$regcount = mysqli_num_rows($resultreg);
$regcount33 = mysqli_num_rows($resultreg33);



if(($_SESSION['role'] == 'teacher') OR ($_SESSION['role'] == 'principal') OR ($_SESSION['role'] == 'student') OR ($_SESSION['role'] == 'admin')){
if($regcount33 != 1){
	echo "<div style='color:red; width:100%; text-align: center;'>YOUR YEAR OF ADMISSION OR CLASS AT ADMISSION IS INCORRECT</div>";
	echo '<meta content="2;index2.php" http-equiv="refresh" />';
	}
else{
    while($resultreg2 = mysqli_fetch_assoc($resultreg33)){ 			
$stu_name[] = $resultreg2['student_name'];
$sex[] = $resultreg2['sex'];
$caa[] = $resultreg2['caa'];
$yoa[] = $resultreg2['yoa'];
$admno[] = $resultreg2['admno'];
$reason[] = $resultreg2['reason'];
$dob[] = $resultreg2['dob'];
}
$stu_name2 = current($stu_name);
$sex2 = current($sex);	
$caa2 = current($caa);
$yoa2 = current($yoa);
$admno2 = current($admno);
$reason2 = current($reason);
$dob2 = current($dob);

$year1 = $_POST['year'];
$year2 = $year1 + 1;
$year3 = $year1 + 2;
$year4 = $year1 + 3;
$year5 = $year1 + 4;
$year6 = $year1 + 5;
//include "connection.php";
$resultgrad = mysqli_query($db, "SELECT * FROM studentsbyclass WHERE student_name='$stu_name2' AND (year='$year1' OR year='$year2' OR year='$year3' OR year='$year4' OR year='$year5' OR year='$year6') AND (term='First Term' OR term='Second Term' OR term='Third Term') AND school='".$_SESSION["school"]."'");
while($rowgrad = mysqli_fetch_assoc($resultgrad))
							{ 			
$yeargrad[] = $rowgrad['year'];
}
$yeargrad2 = $yeargrad;
$maxgrad = max($yeargrad2);

$resultclass = mysqli_query($db, "SELECT * FROM studentsbyclass WHERE student_name='$stu_name2' AND year='$maxgrad' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND school='".$_SESSION["school"]."'");
while($rowclass = mysqli_fetch_assoc($resultclass))
							{ 			
$classgrad[] = $rowclass['class'];
}
$classgrad2 = current($classgrad);
?>
<!--<button onclick="printDiv('printMe');">Print Transcript</button>-->
<?php
$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsc = mysqli_fetch_assoc($resultsch))
							{  
								$school2[] = $rowsc['school'];
								$address2[] = $rowsc['address'];
								$tel2[] = $rowsc['tel'];
								$fax2[] = $rowsc['fax'];
								$email2[] = $rowsc['email'];
								$img2[] = $rowsc['img'];
							}
							$schooll = current($school2);
							$address = current($address2);
							$tel = current($tel2);
							$fax = current($fax2);
							$email = current($email2);
							$img = current($img2);

?>
<div id="printMe">
<table style="width: 100%;">
<tbody style="width: 100%;">
<tr style="width: 100%;">
<td style="width: 6%;"><img src="<?php echo $img; ?>" align="left" height="70" width="90" /></td>
<td style="text-align: left; width: 78%;" colspan="2">
<span style="font-size: 12pt;"><?php echo strtoupper($schooll); ?></span>
<span style="font-size: 9pt;"><br><?php echo strtoupper($address); ?></span><br>
<span style="font-size: 8pt;">Tel: <?php echo $tel; ?>; &nbsp;&nbsp;Fax: <?php echo $fax; ?></span></span><br>
<span style="font-size: 8pt;"><span>Email: <?php echo $email; ?></span></span><br>
</td>
<td style="width: 6%;">
<?php
//include "connection.php";	
$student_name = $_POST['student_name'];
$resultpic = mysqli_query($db, "SELECT * FROM img WHERE student_name='$student_name' AND school='".$_SESSION["school"]."'");
						while($rowpic = mysqli_fetch_assoc($resultpic))
							{
$rpic[] = $rowpic['img'];							
echo '<img style="float:right;" src="'.$rowpic['img'].'" height="80" width="100"/>';
}
$rpic2 = current($rpic);
?>
</td>
</tr>
<tr style="width: 100%;">
<td colspan="2" style="font-size: 11px; width: 50%;">NAME: <?php echo strtoupper($stu_name2); ?></td>
<td colspan="2" style="text-align: right; font-size: 10px; width: 50%;">YEAR OF ENTRY: <?php echo strtoupper($yoa2); ?> &nbsp;&nbsp;/&nbsp;&nbsp; YEAR OF LEAVING: <?php echo $maxgrad ?></td>
</tr>
<tr style="width: 100%;">
<td colspan="2" style="font-size: 10px; width: 50%;">SEX: <?php echo strtoupper($sex2); ?></td>
<td colspan="2" style="text-align: right; font-size: 10px; width: 50%;">REASON FOR LEAVING: <?php echo strtoupper($reason2); ?></td>
</tr>
<tr style="width: 100%;">
<?php 
if($ctype=="Js"){
if($caa2 == "Year 7"){ $caa2 = "JS1";}
else if($caa2 == "Year 8"){ $caa2 = "JS2";}
else if($caa2 == "Year 9"){ $caa2 = "JS3";}
else if($caa2 == "Year 10"){ $caa2 = "SS1";}
else if($caa2 == "Year 11"){ $caa2 = "SS2";}
else if($caa2 == "Year 12"){ $caa2 = "SS3";}
else{}
}elseif($ctype=="Primary"){
if($caa2 == "Year 1"){ $caa2 = "Primary 1";}
else if($caa2 == "Year 2"){ $caa2 = "Primary 2";}
else if($caa2 == "Year 3"){ $caa2 = "Primary 3";}
else if($caa2 == "Year 4"){ $caa2 = "Primary 4";}
else if($caa2 == "Year 5"){ $caa2 = "Primary 5";}
else if($caa2 == "Year 6"){ $caa2 = "Primary 6";}
else{}
}else{
if($caa2 == "Year 7"){ $caa2 = "Year 7";}	
else if($caa2 == "Year 8"){ $caa2 = "Year 8";}
else if($caa2 == "Year 9"){ $caa2 = "Year 9";}
else if($caa2 == "Year 10"){ $caa2 = "Year 10";}
else if($caa2 == "Year 11"){ $caa2 = "Year 11";}
else if($caa2 == "Year 12"){ $caa2 = "Year 12";}
else{}
}

if($ctype=="Js"){
if($classgrad2 == "Year 7"){ $classgrad2 = "JS1";}
else if($classgrad2 == "Year 8"){ $classgrad2= "JS2";}
else if($classgrad2 == "Year 9"){ $classgrad2 = "JS3";}
else if($classgrad2 == "Year 10"){ $classgrad2 = "SS1";}
else if($classgrad2 == "Year 11"){ $classgrad2 = "SS2";}
else if($classgrad2 == "Year 12"){ $classgrad2 = "SS3";}
else{}
}elseif($ctype=="Primary"){
if($classgrad2 == "Year 1"){ $classgrad2 = "Primary 1";}
else if($classgrad2 == "Year 2"){ $classgrad2 = "Primary 2";}
else if($classgrad2 == "Year 3"){ $classgrad2 = "Primary 3";}
else if($classgrad2 == "Year 4"){ $classgrad2 = "Primary 4";}
else if($classgrad2 == "Year 5"){ $classgrad2 = "Primary 5";}
else if($classgrad2 == "Year 6"){ $classgrad2 = "Primary 6";}
else{}
}else{
if($classgrad2 == "Year 7"){ $classgrad2 = "Year 7";}	
else if($classgrad2 == "Year 8"){ $classgrad2 = "Year 8";}
else if($classgrad2 == "Year 9"){ $classgrad2 = "Year 9";}
else if($classgrad2 == "Year 10"){ $classgrad2 = "Year 10";}
else if($classgrad2 == "Year 11"){ $classgrad2= "Year 11";}
else if($classgrad2 == "Year 12"){ $classgrad2 = "Year 12";}
else{}
}		
?>
<td colspan="2" style="font-size: 10px; width: 50%;">CLASS: <?php echo strtoupper($caa2); ?> - <?php echo strtoupper($classgrad2); ?></td>
<td colspan="2" style="text-align: right; font-size: 10px; width: 50%;">ADMISSION NO: <?php echo $admno2; ?><br>DATE OF BIRTH: <?php echo strtoupper(date('l jS \of F Y', strtotime($dob2))); ?></td>
</tr>
</tbody>
</table>
<table style="height: auto; width: 100%; text-align: center;">
<tr><td><span style="font-size: 12pt;">TRANSCRIPT</span></td></tr>
</table>


<table id="tb1" style="font-size: 11px; width: 100%; text-align: center;" border="1">
<tbody>
<tr style="height: 2px;">
<td rowspan="3">SUBJECT</td>
<?php
$class_name = $_POST['class_name'];
if($class_name == 'Year 6'){
echo "";
}
else{
//include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];

		if($class_name == 'Year 1'){
		if($ctype=="Primary"){
		$y7 = 'Primary 1';
		}else{
		$y7 = 'Year 1';	
		}
		}
		else if($class_name == 'Year 2'){
		if($ctype=="Primary"){
		$y7 = 'Primary 2';
		}else{
		$y7 = 'Year 2';	
		}
		}
		else if($class_name == 'Year 3'){
		if($ctype=="Primary"){
		$y7 = 'Primary 3';
		}else{
		$y7 = 'Year 3';	
		}
		}
		else if($class_name == 'Year 4'){
		if($ctype=="Primary"){
		$y7 = 'Primary 4';
		}else{
		$y7 = 'Year 4';		
		}
		}
		else if($class_name == 'Year 5'){
		if($ctype=="Primary"){
		$y7 = 'Primary 5';
		}else{
		$y7 = 'Year 5';		
		}
		}
		else if($class_name == 'Year 6'){
		if($ctype=="Primary"){
		$y7 = 'Primary 6';
		}else{
		$y7 = 'Year 6';		
		}
		}
		else{
			$y7 = 'NOT APPLICABLE';
		}
	?>
<td  colspan="6"><?php echo $y7; ?></td>
<?php } ?>

<?php
$class_name = $_POST['class_name'];
if(($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
	//include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 1'){
		if($ctype=="Primary"){	
		$y8 = 'Primary 2';
		}else{
		$y8 = 'Year 2';	
		}
		}
		else if($class_name == 'Year 2'){
		if($ctype=="Primary"){		
		$y8 = 'Primary 3';
		}else{
		$y8 = 'Year 3';	
		}
		}
		else if($class_name == 'Year 3'){
		if($ctype=="Primary"){	
		$y8 = 'Primary 4';
		}else{
		$y8 = 'Year 4';
		}
		}
		else if($class_name == 'Year 4'){
		if($ctype=="Primary"){	
		$y8 = 'Primary 5';
		}else{
		$y8 = 'Year 5';
		}
		}
		else if($class_name == 'Year 5'){
		if($ctype=="Primary"){	
		$y8 = 'Primary 6';
		}else{
		$y8 = 'Year 6';
		}
		}
		else if($class_name == 'Year 6'){
		$y8 = 'NOT APPLICABLE';
		}
		else{
			$y8 = 'NOT APPLICABLE';
		}
	?>
<td colspan="6"><?php echo $y8; ?></td>
	<?php } ?>
	
	
<?php
$class_name = $_POST['class_name'];
if(($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
	//include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 1'){
		if($ctype=="Primary"){
		$y9 = 'Primary 3';
		}else{
		$y9 = 'Year 3';
		}
		}
		else if($class_name == 'Year 2'){
		if($ctype=="Primary"){
		$y9 = 'Primary 4';
		}else{
		$y9 = 'Year 4';
		}
		}
		else if($class_name == 'Year 3'){
		if($ctype=="Primary"){
		$y9 = 'Primary 5';
		}else{
		$y9 = 'Year 5';
		}
		}
		else if($class_name == 'Year 4'){
		if($ctype=="Primary"){
		$y9 = 'Primary 6';	
		}else{
		$y9 = 'Year 6';
		}
		}
		else if($class_name == 'Year 5'){
		$y9 = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y9 = 'NOT APPLICABLE';
		}
		else{
			$y9 = 'NOT APPLICABLE';
		}
	?>
<td colspan="6"><?php echo $y9; ?></td>
	<?php } ?>
	
<?php
$class_name = $_POST['class_name'];
if(($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
	//include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 1'){
		if($ctype=="Primary"){
		$y10 = 'Primary 4';
		}else{
		$y10 = 'Year 4';
		}
		}
		else if($class_name == 'Year 2'){
		if($ctype=="Primary"){
		$y10 = 'Primary 5';	
		}else{
		$y10 = 'Year 5';
		}
		}
		else if($class_name == 'Year 3'){
		if($ctype=="Primary"){
		$y10 = 'Primary 6';	
		}else{
		$y10 = 'Year 6';
		}
		}
		else if($class_name == 'Year 4'){
		$y10 = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y10 = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y10 = 'NOT APPLICABLE';
		}
		else{
			$y10 = 'NOT APPLICABLE';
		}
	?>
<td colspan="6"><?php echo $y10; ?></td>
	<?php } ?>
	
<?php
$class_name = $_POST['class_name'];
if(($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
	//include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 1'){
		if($ctype=="Primary"){
		$y11 = 'Primary 5';
		}else{
		$y11 = 'Year 5';
		}
		}
		else if($class_name == 'Year 2'){
		if($ctype=="Primary"){
		$y11 = 'Primary 6';
		}else{
		$y11 = 'Year 6';
		}
		}
		else if($class_name == 'Year 3'){
		$y11 = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y11 = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y11 = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y11 = 'NOT APPLICABLE';
		}
		else{
			$y11 = 'NOT APPLICABLE';
		}
	?>
<td colspan="6"><?php echo $y11; ?></td>
	<?php } ?>
	
<?php
$class_name = $_POST['class_name'];
if(($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
	//include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 1'){
		if($ctype=="Primary"){
		$y12 = 'Primary 6';	
		}else{
		$y12 = 'Year 6';
		}
		}
		else if($class_name == 'Year 2'){
		$y12 = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 3'){
		$y12 = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y12 = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y12 = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y12 = 'NOT APPLICABLE';
		}
		else{
			$y12 = 'NA';
		}
	?>
<td colspan="6"><?php echo $y12; ?></td>
	<?php } ?>
</tr>
<tr style="height: 13px;">
<td colspan="2">1st Term</td>
<td colspan="2">2nd Term</td>
<td colspan="2">3rd Term</td>

<td  colspan="2">1st Term</td>
<td  colspan="2">2nd Term</td>
<td colspan="2">3rd Term</td>

<td  colspan="2">1st Term</td>
<td  colspan="2">2nd Term</td>
<td colspan="2">3rd Term</td>

<td  colspan="2">1st Term</td>
<td  colspan="2">2nd Term</td>
<td colspan="2">3rd Term</td>

<td  colspan="2">1st Term</td>
<td  colspan="2">2nd Term</td>
<td colspan="2">3rd Term</td>

<td  colspan="2">1st Term</td>
<td  colspan="2">2nd Term</td>
<td colspan="2">3rd Term</td>
</tr>
<tr style="height: 13px;">
<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>

<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>

<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>

<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>

<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>

<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>
</tr>


<tr style="height: 13px;">
<td>ENGLISH</td>
<?php
//include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
//YEAR 1 DATA FOR ENGLISH
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 1'){
		$y = 'Year 1';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 6'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='English' AND school='".$_SESSION["school"]."'");
				while($row = mysqli_fetch_assoc($result))
							{
						$term111[] = $row['term'];						
						$score111[] = $row['score'];						
						}
$fscore111 = $score111;
$fterm111 = $term111;
$c = array_combine($fterm111, $fscore111);
$eng7 = $c;
ksort($eng7);
$ffengsc71 = $eng7['First Term'];
$ssengsc72 = $eng7['Second Term'];
$ttengsc73 = $eng7['Third Term'];
if($ffengsc71 >= 70){$gradeeng71 = "A"; }
else if(($ffengsc71 >= 60) AND ($ffengsc71 <= 69)){$gradeeng71 = "C";}
else if(($ffengsc71 >= 50) AND ($ffengsc71 <= 59)){$gradeeng71 = "P";}
else if(($ffengsc71 <= 49)){$gradeeng71 = "F";}
else {$gradeeng71 = "NA";}	
if($ssengsc72 >= 70){$gradeeng72 = "A"; }
else if(($ssengsc72 >= 60) AND ($ssengsc72 <= 69)){$gradeeng72 = "C";}
else if(($ssengsc72 >= 50) AND ($ssengsc72 <= 59)){$gradeeng72 = "P";}
else if(($ssengsc72 <= 49)){$gradeeng72 = "F";}
else {$gradeeng72 = "NA";}	
if($ttengsc73 >= 70){$gradeeng73 = "A"; }
else if(($ttengsc73 >= 60) AND ($ttengsc73 <= 69)){$gradeeng73 = "C";}
else if(($ttengsc73 >= 50) AND ($ttengsc73 <= 59)){$gradeeng73 = "P";}
else if(($ttengsc73 <= 49)){$gradeeng73 = "F";}
else {$gradeeng73 = "NA";}	
}

// YEAR 2 DATA FOR ENGLISH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 1'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='English' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeeng81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeeng81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeeng81 = "P";}
								else if(($row["score"] <= 49)){$gradeeng81 = "F";}
								else {$gradeeng81 = "NA";}
						$fengscore81[] = $row['score'];	
						}
$ffengsc81 = current($fengscore81);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='English' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeeng82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeeng82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeeng82 = "P";}
								else if(($row["score"] <= 49)){$gradeeng82 = "F";}
								else {$gradeeng82 = "NA";}
						$sengscore82[] = $row['score'];	
						}
$ssengsc82 = current($sengscore82);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='English' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeeng83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeeng83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeeng83 = "P";}
								else if(($row["score"] <= 49)){$gradeeng83 = "F";}
								else {$gradeeng83 = "NA";}
						$tengscore83[] = $row['score'];	
						}
$ttengsc83 = current($tengscore83);	
}
// YEAR 3 DATA FOR ENGLISH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 1'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='English' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeeng91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeeng91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeeng91 = "P";}
								else if(($row["score"] <= 49)){$gradeeng91 = "F";}
								else {$gradeeng91 = "NA";}
						$fengscore91[] = $row['score'];	
						}
$ffengsc91 = current($fengscore91);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='English' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeeng92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeeng92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeeng92 = "P";}
								else if(($row["score"] <= 49)){$gradeeng92 = "F";}
								else {$gradeeng92 = "NA";}
						$sengscore92[] = $row['score'];	
						}
$ssengsc92 = current($sengscore92);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='English' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeeng93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeeng93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeeng93 = "P";}
								else if(($row["score"] <= 49)){$gradeeng93 = "F";}
								else {$gradeeng93 = "NA";}
						$tengscore93[] = $row['score'];	
						}
$ttengsc93 = current($tengscore93);	
}	

// YEAR 4 DATA FOR ENGLISH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 1'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='English' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeeng101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeng101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeng101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeng101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeng101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeng101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeng101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeng101 = "E8";}
								else if(($row["score"] <= 39)){$gradeeng101 = "F9";}
								else {$gradeeng101 = "NA";}
						$fengscore101[] = $row['score'];						
						}
$ffengsc101 = current($fengscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='English' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeeng102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeng102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeng102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeng102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeng102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeng102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeng102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeng102 = "E8";}
								else if(($row["score"] <= 39)){$gradeeng102 = "F9";}
								else {$gradeeng102 = "NA";}
						$sengscore102[] = $row['score'];						
						}
$ssengsc102 = current($sengscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='English' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$gradeeng103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeng103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeng103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeng103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeng103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeng103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeng103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeng103 = "E8";}
								else if(($row["score"] <= 39)){$gradeeng103 = "F9";}
								else {$gradeeng103 = "NA";}
						$tengscore103[] = $row['score'];						
						}
$ttengsc103 = current($tengscore103);
}

// YEAR 5 DATA FOR ENGLISH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 1'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='English' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeeng111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeng111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeng111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeng111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeng111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeng111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeng111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeng111 = "E8";}
								else if(($row["score"] <= 39)){$gradeeng111 = "F9";}
								else {$gradeeng111 = "NA";}
						$fengscore111[] = $row['score'];						
						}
$ffengsc111 = current($fengscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='English' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$gradeeng112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeng112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeng112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeng112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeng112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeng112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeng112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeng112 = "E8";}
								else if(($row["score"] <= 39)){$gradeeng112 = "F9";}
								else {$gradeeng112 = "NA";}
						$sengscore112[] = $row['score'];						
						}
$ssengsc112 = current($sengscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='English' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradeeng113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeng113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeng113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeng113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeng113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeng113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeng113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeng113 = "E8";}
								else if(($row["score"] <= 39)){$gradeeng113 = "F9";}
								else {$gradeeng113 = "NA";}
						$tengscore113[] = $row['score'];						
						}
$ttengsc113 = current($tengscore113);		
}

// YEAR 6 DATA FOR ENGLISH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 1'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 2'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='English' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeeng121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeng121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeng121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeng121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeng121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeng121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeng121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeng121 = "E8";}
								else if(($row["score"] <= 39)){$gradeeng121 = "F9";}
								else {$gradeeng121 = "NA";}
						$fengscore121[] = $row['score'];						
						}
$ffengsc121 = current($fengscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='English' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeeng122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeng122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeng122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeng122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeng122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeng122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeng122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeng122 = "E8";}
								else if(($row["score"] <= 39)){$gradeeng122 = "F9";}
								else {$gradeeng122 = "NA";}
						$sengscore122[] = $row['score'];						
						}
$ssengsc122 = current($sengscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='English' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeeng123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeng123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeng123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeng123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeng123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeng123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeng123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeng123 = "E8";}
								else if(($row["score"] <= 39)){$gradeeng123 = "F9";}
								else {$gradeeng123 = "NA";}
						$tengscore123[] = $row['score'];						
						}
$ttengsc123 = current($tengscore123);
}					
?>
<td><?php echo $ffengsc71;  ?></td>
<td><?php if($ffengsc71 != ""){echo $gradeeng71;}else{echo "-";} ?></td>
<td><?php echo $ssengsc72;  ?></td>
<td><?php if($ssengsc72 != ""){echo $gradeeng72;}else{echo "-";} ?></td>
<td><?php echo $ttengsc73;  ?></td>
<td><?php if($ttengsc73 != ""){echo $gradeeng73;}else{echo "-";} ?></td>
<td><?php echo $ffengsc81;  ?></td>
<td><?php if($ffengsc81 != ""){echo $gradeeng81;}else{echo "-";} ?></td>
<td><?php echo $ssengsc82;  ?></td>
<td><?php if($ssengsc82 != ""){echo $gradeeng82;}else{echo "-";} ?></td>
<td><?php echo $ttengsc83;  ?></td>
<td><?php if($ttengsc83 != ""){echo $gradeeng83;}else{echo "-";} ?></td>
<td><?php echo $ffengsc91;  ?></td>
<td><?php if($ffengsc91 != ""){echo $gradeeng91;}else{echo "-";} ?></td>
<td><?php echo $ssengsc92;  ?></td>
<td><?php if($ssengsc92 != ""){echo $gradeeng92;}else{echo "-";} ?></td>
<td><?php echo $ttengsc93;  ?></td>
<td><?php if($ttengsc93 != ""){echo $gradeeng93;}else{echo "-";} ?></td>
<td><?php echo $ffengsc101;  ?></td>
<td><?php if($ffengsc101 != ""){echo $gradeeng101;}else{echo "-";} ?></td>
<td><?php echo $ssengsc102;  ?></td>
<td><?php if($ssengsc102 != ""){echo $gradeeng102;}else{echo "-";} ?></td>
<td><?php echo $ttengsc103;  ?></td>
<td><?php if($ttengsc103 != ""){echo $gradeeng103;}else{echo "-";} ?></td>
<td><?php echo $ffengsc111;  ?></td>
<td><?php if($ffengsc111 != ""){echo $gradeeng111;}else{echo "-";} ?></td>
<td><?php echo $ssengsc112;  ?></td>
<td><?php if($ssengsc112 != ""){echo $gradeeng112;}else{echo "-";} ?></td>
<td><?php echo $ttengsc113;  ?></td>
<td><?php if($ttengsc113 != ""){echo $gradeeng113;}else{echo "-";} ?></td>
<td><?php echo $ffengsc121;  ?></td>
<td><?php if($ffengsc121 != ""){echo $gradeeng121;}else{echo "-";} ?></td>
<td><?php echo $ssengsc122;  ?></td>
<td><?php if($ssengsc122 != ""){echo $gradeeng122;}else{echo "-";} ?></td>
<td><?php echo $ttengsc123;  ?></td>
<td><?php if($ttengsc123 != ""){echo $gradeeng123;}else{echo "-";} ?></td>
</tr>


<tr style="height: 13px;">
<td>MATHEMATICS</td>
<?php
include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
//YEAR 1 DATA FOR MATH
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 1'){
		$y = 'Year 1';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 6'){
		$y = 'Year 6';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='Mathematics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademat71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademat71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademat71 = "P";}
								else if(($row["score"] <= 49)){$grademat71 = "F";}
								else {$grademat71 = "NA";}
						$fmatscore71[] = $row['score'];	
						}
$ffmatsc71 = current($fmatscore71);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='Mathematics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademat72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademat72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademat72 = "P";}
								else if(($row["score"] <= 49)){$grademat72 = "F";}
								else {$grademat72 = "NA";}
						$smatscore72[] = $row['score'];	
						}
$ssmatsc72 = current($smatscore72);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='Mathematics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademat73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademat73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademat73 = "P";}
								else if(($row["score"] <= 49)){$grademat73 = "F";}
								else {$grademat73 = "NA";}
						$tmatscore73[] = $row['score'];	
						}
$ttmatsc73 = current($tmatscore73);
}
// YEAR 2 DATA FOR MATHS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 1'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Mathematics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademat81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademat81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademat81 = "P";}
								else if(($row["score"] <= 49)){$grademat81 = "F";}
								else {$grademat81 = "NA";}
						$fmatscore81[] = $row['score'];	
						}
$ffmatsc81 = current($fmatscore81);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Mathematics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademat82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademat82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademat82 = "P";}
								else if(($row["score"] <= 49)){$grademat82 = "F";}
								else {$grademat82 = "NA";}
						$smatscore82[] = $row['score'];	
						}
$ssmatsc82 = current($smatscore82);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Mathematics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademat83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademat83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademat83 = "P";}
								else if(($row["score"] <= 49)){$grademat83 = "F";}
								else {$grademat83 = "NA";}
						$tmatscore83[] = $row['score'];	
						}
$ttmatsc83 = current($tmatscore83);
}
// YEAR 3 DATA FOR MATHS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 1'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Mathematics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademat91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademat91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademat91 = "P";}
								else if(($row["score"] <= 49)){$grademat91 = "F";}
								else {$grademat91 = "NA";}
						$fmatscore91[] = $row['score'];	
						}
$ffmatsc91 = current($fmatscore91);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Mathematics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademat92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademat92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademat92 = "P";}
								else if(($row["score"] <= 49)){$grademat92 = "F";}
								else {$grademat92 = "NA";}
						$smatscore92[] = $row['score'];	
						}
$ssmatsc92 = current($smatscore92);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Mathematics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademat93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademat93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademat93 = "P";}
								else if(($row["score"] <= 49)){$grademat93 = "F";}
								else {$grademat93 = "NA";}
						$tmatscore93[] = $row['score'];	
						}
$ttmatsc93 = current($tmatscore93);
}	

// YEAR 4 DATA FOR MATHS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 1'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Mathematics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$grademat101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademat101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademat101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademat101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademat101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademat101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademat101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademat101 = "E8";}
								else if(($row["score"] <= 39)){$grademat101 = "F9";}
								else {$grademat101 = "NA";}
						$fmatscore101[] = $row['score'];						
						}
$ffmatsc101 = current($fmatscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Mathematics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$grademat102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademat102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademat102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademat102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademat102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademat102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademat102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademat102 = "E8";}
								else if(($row["score"] <= 39)){$grademat102 = "F9";}
								else {$grademat102 = "NA";}
						$smatscore102[] = $row['score'];						
						}
$ssmatsc102 = current($smatscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Mathematics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$grademat103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademat103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademat103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademat103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademat103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademat103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademat103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademat103 = "E8";}
								else if(($row["score"] <= 39)){$grademat103 = "F9";}
								else {$grademat103 = "NA";}
						$tmatscore103[] = $row['score'];						
						}
$ttmatsc103 = current($tmatscore103);
}

// YEAR 5 DATA FOR MATHS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 1'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Mathematics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$grademat111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademat111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademat111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademat111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademat111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademat111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademat111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademat111 = "E8";}
								else if(($row["score"] <= 39)){$grademat111 = "F9";}
								else {$grademat111 = "NA";}
						$fmatscore111[] = $row['score'];						
						}
$ffmatsc111 = current($fmatscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Mathematics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$grademat112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademat112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademat112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademat112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademat112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademat112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademat112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademat112 = "E8";}
								else if(($row["score"] <= 39)){$grademat112 = "F9";}
								else {$grademat112 = "NA";}
						$smatscore112[] = $row['score'];						
						}
$ssmatsc112 = current($smatscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Mathematics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grademat113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademat113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademat113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademat113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademat113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademat113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademat113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademat113 = "E8";}
								else if(($row["score"] <= 39)){$grademat113 = "F9";}
								else {$grademat113 = "NA";}
						$tmatscore113[] = $row['score'];						
						}
$ttmatsc113 = current($tmatscore113);		
}

// YEAR 6 DATA FOR MATHS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 1'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 2'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Mathematics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$grademat121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademat121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademat121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademat121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademat121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademat121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademat121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademat121 = "E8";}
								else if(($row["score"] <= 39)){$grademat121 = "F9";}
								else {$grademat121 = "NA";}
						$fmatscore121[] = $row['score'];						
						}
$ffmatsc121 = current($fmatscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Mathematics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$grademat122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademat122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademat122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademat122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademat122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademat122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademat122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademat122 = "E8";}
								else if(($row["score"] <= 39)){$grademat122 = "F9";}
								else {$grademat122 = "NA";}
						$smatscore122[] = $row['score'];						
						}
$ssmatsc122 = current($smatscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Mathematics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$grademat123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademat123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademat123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademat123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademat123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademat123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademat123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademat123 = "E8";}
								else if(($row["score"] <= 39)){$grademat123 = "F9";}
								else {$grademat123 = "NA";}
						$tmatscore123[] = $row['score'];						
						}
$ttmatsc123 = current($tmatscore123);
}					
?>
<td><?php echo $ffmatsc71;  ?></td>
<td><?php if($ffmatsc71 != ""){echo $grademat71;}else{echo "-";} ?></td>
<td><?php echo $ssmatsc72;  ?></td>
<td><?php if($ssmatsc72 != ""){echo $grademat72;}else{echo "-";} ?></td>
<td><?php echo $ttmatsc73;  ?></td>
<td><?php if($ttmatsc73 != ""){echo $grademat73;}else{echo "-";} ?></td>
<td><?php echo $ffmatsc81;  ?></td>
<td><?php if($ffmatsc81 != ""){echo $grademat81;}else{echo "-";} ?></td>
<td><?php echo $ssmatsc82;  ?></td>
<td><?php if($ssmatsc82 != ""){echo $grademat82;}else{echo "-";} ?></td>
<td><?php echo $ttmatsc83;  ?></td>
<td><?php if($ttmatsc83 != ""){echo $grademat83;}else{echo "-";} ?></td>
<td><?php echo $ffmatsc91;  ?></td>
<td><?php if($ffmatsc91 != ""){echo $grademat91;}else{echo "-";} ?></td>
<td><?php echo $ssmatsc92;  ?></td>
<td><?php if($ssmatsc92 != ""){echo $grademat92;}else{echo "-";} ?></td>
<td><?php echo $ttmatsc93;  ?></td>
<td><?php if($ttmatsc93 != ""){echo $grademat93;}else{echo "-";} ?></td>
<td><?php echo $ffmatsc101;  ?></td>
<td><?php if($ffmatsc101 != ""){echo $grademat101;}else{echo "-";} ?></td>
<td><?php echo $ssmatsc102;  ?></td>
<td><?php if($ssmatsc102 != ""){echo $grademat102;}else{echo "-";} ?></td>
<td><?php echo $ttmatsc103;  ?></td>
<td><?php if($ttmatsc103 != ""){echo $grademat103;}else{echo "-";} ?></td>
<td><?php echo $ffmatsc111;  ?></td>
<td><?php if($ffmatsc111 != ""){echo $grademat111;}else{echo "-";} ?></td>
<td><?php echo $ssmatsc112;  ?></td>
<td><?php if($ssmatsc112 != ""){echo $grademat112;}else{echo "-";} ?></td>
<td><?php echo $ttmatsc113;  ?></td>
<td><?php if($ttmatsc113 != ""){echo $grademat113;}else{echo "-";} ?></td>
<td><?php echo $ffmatsc121;  ?></td>
<td><?php if($ffmatsc121 != ""){echo $grademat121;}else{echo "-";} ?></td>
<td><?php echo $ssmatsc122;  ?></td>
<td><?php if($ssmatsc122 != ""){echo $grademat122;}else{echo "-";} ?></td>
<td><?php echo $ttmatsc123;  ?></td>
<td><?php if($ttmatsc123 != ""){echo $grademat123;}else{echo "-";} ?></td>
</tr>


<tr style="height: 13px;">
<td>AGRIC SC.</td>
<?php
//include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 6'){
echo "";
}
else{
//YEAR 1 DATA FOR AGRIC
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 1'){
		$y = 'Year 1';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 6'){
		$y = 'Year 6';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeagr71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeagr71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeagr71 = "P";}
								else if(($row["score"] <= 49)){$gradeagr71 = "F";}
								else {$gradeagr71 = "NA";}
						$fagrscore71[] = $row['score'];	
						}
$ffagrsc71 = current($fagrscore71);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeagr72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeagr72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeagr72 = "P";}
								else if(($row["score"] <= 49)){$gradeagr72 = "F";}
								else {$gradeagr72 = "NA";}
						$sagrscore72[] = $row['score'];	
						}
$ssagrsc72 = current($sagrscore72);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeagr73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeagr73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeagr73 = "P";}
								else if(($row["score"] <= 49)){$gradeagr73 = "F";}
								else {$gradeagr73 = "NA";}
						$tagrscore73[] = $row['score'];	
						}
$ttagrsc73 = current($tagrscore73);	
}
// YEAR 2 DATA FOR AGRIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 1'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeagr81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeagr81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeagr81 = "P";}
								else if(($row["score"] <= 49)){$gradeagr81 = "F";}
								else {$gradeagr81 = "NA";}
						$fagrscore81[] = $row['score'];	
						}
$ffagrsc81 = current($fagrscore81);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeagr82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeagr82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeagr82 = "P";}
								else if(($row["score"] <= 49)){$gradeagr82 = "F";}
								else {$gradeagr82 = "NA";}
						$sagrscore82[] = $row['score'];	
						}
$ssagrsc82 = current($sagrscore82);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeagr83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeagr83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeagr83 = "P";}
								else if(($row["score"] <= 49)){$gradeagr83 = "F";}
								else {$gradeagr83 = "NA";}
						$tagrscore83[] = $row['score'];	
						}
$ttagrsc83 = current($tagrscore83);	
}
// YEAR 3 DATA FOR AGR
$class_name = $_POST['class_name'];
if(($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 1'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeagr91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeagr91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeagr91 = "P";}
								else if(($row["score"] <= 49)){$gradeagr91 = "F";}
								else {$gradeagr91 = "NA";}
						$fagrscore91[] = $row['score'];	
						}
$ffagrsc91 = current($fagrscore91);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeagr92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeagr92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeagr92 = "P";}
								else if(($row["score"] <= 49)){$gradeagr92 = "F";}
								else {$gradeagr92 = "NA";}
						$sagrscore92[] = $row['score'];	
						}
$ssagrsc92 = current($sagrscore92);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeagr93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeagr93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeagr93 = "P";}
								else if(($row["score"] <= 49)){$gradeagr93 = "F";}
								else {$gradeagr93 = "NA";}
						$tagrscore93[] = $row['score'];	
						}
$ttagrsc93 = current($tagrscore93);	
}	

// YEAR 4 DATA FOR AGRIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 1'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 1'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeagr101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeagr101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeagr101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeagr101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeagr101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeagr101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeagr101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeagr101 = "E8";}
								else if(($row["score"] <= 39)){$gradeagr101 = "F9";}
								else {$gradeagr101 = "NA";}
						$fagrscore101[] = $row['score'];						
						}
$ffagrsc101 = current($fagrscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeagr102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeagr102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeagr102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeagr102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeagr102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeagr102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeagr102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeagr102 = "E8";}
								else if(($row["score"] <= 39)){$gradeagr102 = "F9";}
								else {$gradeagr102 = "NA";}
						$sagrscore102[] = $row['score'];						
						}
$ssagrsc102 = current($sagrscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradeagr103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeagr103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeagr103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeagr103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeagr103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeagr103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeagr103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeagr103 = "E8";}
								else if(($row["score"] <= 39)){$gradeagr103 = "F9";}
								else {$gradeagr103 = "NA";}
						$tagrscore103[] = $row['score'];						
						}
$ttagrsc103 = current($tagrscore103);
}

// YEAR 5 DATA FOR AGRIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 1'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeagr111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeagr111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeagr111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeagr111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeagr111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeagr111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeagr111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeagr111 = "E8";}
								else if(($row["score"] <= 39)){$gradeagr101 = "F9";}
								else {$gradeagr111 = "NA";}
						$fagrscore111[] = $row['score'];						
						}
$ffagrsc111 = current($fagrscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$gradeagr112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeagr112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeagr112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeagr112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeagr112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeagr112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeagr112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeagr112 = "E8";}
								else if(($row["score"] <= 39)){$gradeagr112 = "F9";}
								else {$gradeagr112 = "NA";}
						$sagrscore112[] = $row['score'];						
						}
$ssagrsc112 = current($sagrscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradeagr113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeagr113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeagr113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeagr113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeagr113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeagr113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeagr113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeagr113 = "E8";}
								else if(($row["score"] <= 39)){$gradeagr113 = "F9";}
								else {$gradeagr113 = "NA";}
						$tagrscore113[] = $row['score'];						
						}
$ttagrsc113 = current($tagrscore113);		
}

// YEAR 6 DATA FOR AGRIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 1'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 2'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeagr121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeagr121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeagr121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeagr121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeagr121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeagr121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeagr121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeagr121 = "E8";}
								else if(($row["score"] <= 39)){$gradeagr121 = "F9";}
								else {$gradeagr121 = "NA";}
						$fagrscore121[] = $row['score'];						
						}
$ffagrsc121 = current($fagrscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradeagr122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeagr122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeagr122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeagr122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeagr122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeagr122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeagr122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeagr122 = "E8";}
								else if(($row["score"] <= 39)){$gradeagr122 = "F9";}
								else {$gradeagr122 = "NA";}
						$sagrscore122[] = $row['score'];						
						}
$ssagrsc122 = current($sagrscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeagr123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeagr123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeagr123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeagr123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeagr123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeagr123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeagr123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeagr123 = "E8";}
								else if(($row["score"] <= 39)){$gradeagr123 = "F9";}
								else {$gradeagr123 = "NA";}
						$tagrscore123[] = $row['score'];						
						}
$ttagrsc123 = current($tagrscore123);
}					
?>
<td><?php echo $ffagrsc71;  ?></td>
<td><?php if($ffagrsc71 != ""){echo $gradeagr71;}else{echo "-";} ?></td>
<td><?php echo $ssagrsc72;  ?></td>
<td><?php if($ssagrsc72 != ""){echo $gradeagr72;}else{echo "-";} ?></td>
<td><?php echo $ttagrsc73;  ?></td>
<td><?php if($ttagrsc73 != ""){echo $gradeagr73;}else{echo "-";} ?></td>
<td><?php echo $ffagrsc81;  ?></td>
<td><?php if($ffagrsc81 != ""){echo $gradeagr81;}else{echo "-";} ?></td>
<td><?php echo $ssagrsc82;  ?></td>
<td><?php if($ssagrsc82 != ""){echo $gradeagr82;}else{echo "-";} ?></td>
<td><?php echo $ttagrsc83;  ?></td>
<td><?php if($ttagrsc83 != ""){echo $gradeagr83;}else{echo "-";} ?></td>
<td><?php echo $ffagrsc91;  ?></td>
<td><?php if($ffagrsc91 != ""){echo $gradeagr91;}else{echo "-";} ?></td>
<td><?php echo $ssagrsc92;  ?></td>
<td><?php if($ssagrsc92 != ""){echo $gradeagr92;}else{echo "-";} ?></td>
<td><?php echo $ttagrsc93;  ?></td>
<td><?php if($ttagrsc93 != ""){echo $gradeagr93;}else{echo "-";} ?></td>
<td><?php echo $ffagrsc101;  ?></td>
<td><?php if($ffagrsc101 != ""){echo $gradeagr101;}else{echo "-";} ?></td>
<td><?php echo $ssagrsc102;  ?></td>
<td><?php if($ssagrsc102 != ""){echo $gradeagr102;}else{echo "-";} ?></td>
<td><?php echo $ttagrsc103;  ?></td>
<td><?php if($ttagrsc103 != ""){echo $gradeagr103;}else{echo "-";} ?></td>
<td><?php echo $ffagrsc111;  ?></td>
<td><?php if($ffagrsc111 != ""){echo $gradeagr111;}else{echo "-";} ?></td>
<td><?php echo $ssagrsc112;  ?></td>
<td><?php if($ssagrsc112 != ""){echo $gradeagr112;}else{echo "-";} ?></td>
<td><?php echo $ttagrsc113;  ?></td>
<td><?php if($ttagrsc113 != ""){echo $gradeagr113;}else{echo "-";} ?></td>
<td><?php echo $ffagrsc121;  ?></td>
<td><?php if($ffagrsc121 != ""){echo $gradeagr121;}else{echo "-";} ?></td>
<td><?php echo $ssagrsc122;  ?></td>
<td><?php if($ssagrsc122 != ""){echo $gradeagr122;}else{echo "-";} ?></td>
<td><?php echo $ttagrsc123;  ?></td>
<td><?php if($ttagrsc123 != ""){echo $gradeagr123;}else{echo "-";} ?></td>
</tr>


<tr style="height: 13px;">
<td>BASIC SC.</td>
<?php
//include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 6'){
echo "";
}
else{
//YEAR 1 DATA FOR BASIC SC
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 1'){
		$y = 'Year 1';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 6'){
		$y = 'Year 6';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='Basic Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebas71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebas71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebas71 = "P";}
								else if(($row["score"] <= 49)){$gradebas71 = "F";}
								else {$gradebas71 = "NA";}
						$fbasscore71[] = $row['score'];	
						}
$ffbassc71 = current($fbasscore71);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='Basic Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebas72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebas72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebas72 = "P";}
								else if(($row["score"] <= 49)){$gradebas72 = "F";}
								else {$gradebas72 = "NA";}
						$sbasscore72[] = $row['score'];	
						}
$ssbassc72 = current($sbasscore72);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='Basic Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebas73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebas73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebas73 = "P";}
								else if(($row["score"] <= 49)){$gradebas73 = "F";}
								else {$gradebas73 = "NA";}
						$tbasscore73[] = $row['score'];	
						}
$ttbassc73 = current($tbasscore73);	
//echo $ttbassc73;
}
// YEAR 2 DATA FOR BASIC SC.
$class_name = $_POST['class_name'];
if(($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 1'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Basic Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebas81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebas81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebas81 = "P";}
								else if(($row["score"] <= 49)){$gradebas81 = "F";}
								else {$gradebas81 = "NA";}
						$fbasscore81[] = $row['score'];	
						}
$ffbassc81 = current($fbasscore81);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Basic Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebas82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebas82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebas82 = "P";}
								else if(($row["score"] <= 49)){$gradebas82 = "F";}
								else {$gradebas82 = "NA";}
						$sbasscore82[] = $row['score'];	
						}
$ssbassc82 = current($sbasscore82);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Basic Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebas83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebas83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebas83 = "P";}
								else if(($row["score"] <= 49)){$gradebas83 = "F";}
								else {$gradebas83 = "NA";}
						$tbasscore83[] = $row['score'];	
						}
$ttbassc83 = current($tbasscore83);	
}
// YEAR 3 DATA FOR BASIC SCIENCE
$class_name = $_POST['class_name'];
if(($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 1'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Basic Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebas91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebas91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebas91 = "P";}
								else if(($row["score"] <= 49)){$gradebas91 = "F";}
								else {$gradebas91 = "NA";}
						$fbasscore91[] = $row['score'];	
						}
$ffbassc91 = current($fbasscore91);		

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Basic Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebas92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebas92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebas92 = "P";}
								else if(($row["score"] <= 49)){$gradebas92 = "F";}
								else {$gradebas92 = "NA";}
						$sbasscore92[] = $row['score'];	
						}
$ssbassc92 = current($sbasscore92);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Basic Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebas93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebas93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebas93 = "P";}
								else if(($row["score"] <= 49)){$gradebas93 = "F";}
								else {$gradebas93 = "NA";}
						$tbasscore93[] = $row['score'];	
						}
$ttbassc93 = current($tbasscore93);		
}	
// YEAR 4 DATA FOR BASIC SCIENCE
$class_name = $_POST['class_name'];
if(($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 1'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 1'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Basic Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebas101 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebas101 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebas101 = "P";}
								else if(($row["score"] <= 49)){$gradebas101 = "F";}
								else {$gradebas101 = "NA";}
						$fbasscore101[] = $row['score'];	
						}
$ffbassc101 = current($fbasscore101);		

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Basic Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebas102 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebas102 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebas102 = "P";}
								else if(($row["score"] <= 49)){$gradebas102 = "F";}
								else {$gradebas102 = "NA";}
						$sbasscore102[] = $row['score'];	
						}
$ssbassc102 = current($sbasscore102);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Basic Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebas103 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebas103 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebas103 = "P";}
								else if(($row["score"] <= 49)){$gradebas103 = "F";}
								else {$gradebas103 = "NA";}
						$tbasscore103[] = $row['score'];	
						}
$ttbassc103 = current($tbasscore103);		
}
// YEAR 5 DATA FOR BASIC SCIENCE
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 1'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Basic Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebas111 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebas111 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebas111 = "P";}
								else if(($row["score"] <= 49)){$gradebas111 = "F";}
								else {$gradebas111 = "NA";}
						$fbasscore111[] = $row['score'];	
						}
$ffbassc111 = current($fbasscore111);		

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Basic Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebas112 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebas112 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebas112 = "P";}
								else if(($row["score"] <= 49)){$gradebas112 = "F";}
								else {$gradebas112 = "NA";}
						$sbasscore112[] = $row['score'];	
						}
$ssbassc112 = current($sbasscore112);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Basic Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebas113 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebas113 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebas113 = "P";}
								else if(($row["score"] <= 49)){$gradebas113 = "F";}
								else {$gradebas113 = "NA";}
						$tbasscore113[] = $row['score'];	
						}
$ttbassc113 = current($tbasscore113);		
}
// YEAR 6 DATA FOR BASIC SCIENCE
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 1'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 2'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Basic Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebas121 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebas121 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebas121 = "P";}
								else if(($row["score"] <= 49)){$gradebas121 = "F";}
								else {$gradebas121 = "NA";}
						$fbasscore121[] = $row['score'];	
						}
$ffbassc121 = current($fbasscore121);		

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Basic Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebas122 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebas122 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebas122 = "P";}
								else if(($row["score"] <= 49)){$gradebas122 = "F";}
								else {$gradebas122 = "NA";}
						$sbasscore122[] = $row['score'];	
						}
$ssbassc122 = current($sbasscore122);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Basic Science' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradebas123 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradebas123 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradebas123 = "P";}
								else if(($row["score"] <= 49)){$gradebas123 = "F";}
								else {$gradebas123 = "NA";}
						$tbasscore123[] = $row['score'];	
						}
$ttbassc123 = current($tbasscore123);		
}		
?>
<td><?php echo $ffbassc71;  ?></td>
<td><?php if($ffbassc71 != ""){echo $gradebas71;}else{echo "-";} ?></td>
<td><?php echo $ssbassc72;  ?></td>
<td><?php if($ssbassc72 != ""){echo $gradebas72;}else{echo "-";} ?></td>
<td><?php echo $ttbassc73;  ?></td>
<td><?php if($ttbassc73 != ""){echo $gradebas73;}else{echo "-";} ?></td>
<td><?php echo $ffbassc81;  ?></td>
<td><?php if($ffbassc81 != ""){echo $gradebas81;}else{echo "-";} ?></td>
<td><?php echo $ssbassc82;  ?></td>
<td><?php if($ssbassc82 != ""){echo $gradebas82;}else{echo "-";} ?></td>
<td><?php echo $ttbassc83;  ?></td>
<td><?php if($ttbassc83 != ""){echo $gradebas83;}else{echo "-";} ?></td>
<td><?php echo $ffbassc91;  ?></td>
<td><?php if($ffbassc91 != ""){echo $gradebas91;}else{echo "-";} ?></td>
<td><?php echo $ssbassc92;  ?></td>
<td><?php if($ssbassc92 != ""){echo $gradebas92;}else{echo "-";} ?></td>
<td><?php echo $ttbassc93;  ?></td>
<td><?php if($ttbassc93 != ""){echo $gradebas93;}else{echo "-";} ?></td>
<td><?php echo $ffbassc101;  ?></td>
<td><?php if($ffbassc101 != ""){echo $gradebas101;}else{echo "-";} ?></td>
<td><?php echo $ssbassc102;  ?></td>
<td><?php if($ssbassc102 != ""){echo $gradebas102;}else{echo "-";} ?></td>
<td><?php echo $ttbassc103;  ?></td>
<td><?php if($ttbassc103 != ""){echo $gradebas103;}else{echo "-";} ?></td>
<td><?php echo $ffbassc111;  ?></td>
<td><?php if($ffbassc111 != ""){echo $gradebas111;}else{echo "-";} ?></td>
<td><?php echo $ssbassc112;  ?></td>
<td><?php if($ssbassc112 != ""){echo $gradebas112;}else{echo "-";} ?></td>
<td><?php echo $ttbassc113;  ?></td>
<td><?php if($ttbassc113 != ""){echo $gradebas113;}else{echo "-";} ?></td>
<td><?php echo $ffbassc121;  ?></td>
<td><?php if($ffbassc121 != ""){echo $gradebas121;}else{echo "-";} ?></td>
<td><?php echo $ssbassc122;  ?></td>
<td><?php if($ssbassc122 != ""){echo $gradebas122;}else{echo "-";} ?></td>
<td><?php echo $ttbassc123;  ?></td>
<td><?php if($ttbassc123 != ""){echo $gradebas123;}else{echo "-";} ?></td>
</tr>

<tr style="height: 13px;">
<td>CIVIC EDU</td>
<?php
//include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 6'){
echo "";
}
else{
//YEAR 1 DATA FOR CIVIC EDU
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 1'){
		$y = 'Year 1';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 6'){
		$y = 'Year 6';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='Civic Education' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeciv71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeciv71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeciv71 = "P";}
								else if(($row["score"] <= 49)){$gradeciv71 = "F";}
								else {$gradeciv71 = "NA";}
						$fcivscore71[] = $row['score'];						
						}
$ffcivscore71 = current($fcivscore71);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='Civic Education' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeciv72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeciv72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeciv72 = "P";}
								else if(($row["score"] <= 49)){$gradeciv72 = "F";}
								else {$gradeciv72 = "NA";}
						$scivscore72[] = $row['score'];						
						}
$sscivscore72 = current($scivscore72);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='Civic Education' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeciv73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeciv73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeciv73 = "P";}
								else if(($row["score"] <= 49)){$gradeciv73 = "F";}
								else {$gradeciv73 = "NA";}
						$tcivscore73[] = $row['score'];						
}
$ttcivscore73 = current($tcivscore73);
}
// YEAR 2 DATA FOR CIVIC EDU
$class_name = $_POST['class_name'];
if(($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 1'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Civic Education' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeciv81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeciv81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeciv81 = "P";}
								else if(($row["score"] <= 49)){$gradeciv81 = "F";}
								else {$gradeciv81 = "NA";}
						$fcivscore81[] = $row['score'];						
						}
$ffcivscore81 = current($fcivscore81);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Civic Education' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeciv82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeciv82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeciv82 = "P";}
								else if(($row["score"] <= 49)){$gradeciv82 = "F";}
								else {$gradeciv82 = "NA";}
						$scivscore82[] = $row['score'];						
						}
$sscivscore82 = current($scivscore82);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Civic Education' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeciv83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeciv83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeciv83 = "P";}
								else if(($row["score"] <= 49)){$gradeciv83 = "F";}
								else {$gradeciv83 = "NA";}
						$tcivscore83[] = $row['score'];						
}
$ttcivscore83 = current($tcivscore83);				
}

// YEAR 3 DATA FOR CIVIC EDU
$class_name = $_POST['class_name'];
if(($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 1'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Civic Education' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeciv91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeciv91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeciv91 = "P";}
								else if(($row["score"] <= 49)){$gradeciv91 = "F";}
								else {$gradeciv91 = "NA";}
						$fcivscore91[] = $row['score'];						
						}
$ffcivscore91 = current($fcivscore91);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Civic Education' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeciv92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeciv92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeciv92 = "P";}
								else if(($row["score"] <= 49)){$gradeciv92 = "F";}
								else {$gradeciv92 = "NA";}
						$scivscore92[] = $row['score'];						
						}
$sscivscore92 = current($scivscore92);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Civic Education' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeciv93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeciv93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeciv93 = "P";}
								else if(($row["score"] <= 49)){$gradeciv93 = "F";}
								else {$gradeciv93 = "NA";}
						$tcivscore93[] = $row['score'];						
}
$ttcivscore93 = current($tcivscore93);				
}	

// YEAR 4 DATA FOR CIVIC EDU
$class_name = $_POST['class_name'];
if(($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 1'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Civic Education' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeciv101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeciv101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeciv101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeciv101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeciv101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeciv101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeciv101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeciv101 = "E8";}
								else if(($row["score"] <= 39)){$gradeciv101 = "F9";}
								else {$gradeciv101 = "NA";}
						$fcivscore101[] = $row['score'];						
						}
$ffcivscore101 = current($fcivscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Civic Education' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeciv102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeciv102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeciv102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeciv102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeciv102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeciv102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeciv102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeciv102 = "E8";}
								else if(($row["score"] <= 39)){$gradecat102 = "F9";}
								else {$gradeciv102 = "NA";}
						$scivscore102[] = $row['score'];						
						}
$sscivscore102 = current($scivscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Civic Education' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeciv103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeciv103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeciv103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeciv103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeciv103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeciv103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeciv103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeciv103 = "E8";}
								else if(($row["score"] <= 39)){$gradecat102 = "F9";}
								else {$gradeciv103 = "NA";}
						$tcivscore103[] = $row['score'];						
}
$ttcivscore103 = current($tcivscore103);				
}

// YEAR 5 DATA FOR CIVIC EDU
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 1'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Civic Education' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeciv111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeciv111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeciv111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeciv111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeciv111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeciv111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeciv111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeciv111 = "E8";}
								else if(($row["score"] <= 39)){$gradeciv111 = "F9";}
								else {$gradeciv111 = "NA";}
						$fcivscore111[] = $row['score'];						
						}
$ffcivscore111 = current($fcivscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Civic Education' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$gradecat112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeciv112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeciv112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeciv112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeciv112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeciv112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeciv112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeciv112 = "E8";}
								else if(($row["score"] <= 39)){$gradeciv112 = "F9";}
								else {$gradeciv112 = "NA";}
						$scivscore112[] = $row['score'];						
						}
$sscivscore112 = current($scivscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Civic Education' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$gradecat111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeciv113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeciv113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeciv113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeciv113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeciv113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeciv113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeciv113 = "E8";}
								else if(($row["score"] <= 39)){$gradeciv113 = "F9";}
								else {$gradeciv113 = "NA";}
						$tcivscore113[] = $row['score'];						
}
$ttcivscore113 = current($tcivscore113);				
}

// YEAR 6 DATA FOR CIVIC EDU
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 1'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 2'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Civic Education' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeciv121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeciv121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeciv121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeciv121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeciv121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeciv121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeciv121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeciv121 = "E8";}
								else if(($row["score"] <= 39)){$gradeciv121 = "F9";}
								else {$gradeciv121 = "NA";}
						$fcivscore121[] = $row['score'];						
						}
$ffcivscore121 = current($fcivscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Civic Education' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecat122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeciv122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeciv122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeciv122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeciv122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeciv122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeciv122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeciv122 = "E8";}
								else if(($row["score"] <= 39)){$gradeciv122 = "F9";}
								else {$gradeciv122 = "NA";}
						$scivscore122[] = $row['score'];						
						}
$sscivscore122 = current($scivscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Civic Education' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecat123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeciv123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeciv123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeciv123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeciv123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeciv123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeciv123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeciv123 = "E8";}
								else if(($row["score"] <= 39)){$gradeciv123 = "F9";}
								else {$gradeciv123 = "NA";}
						$tcivscore123[] = $row['score'];						
}
$ttcivscore123 = current($tcivscore123);				
}					
?>
<td><?php echo $ffcivscore71;  ?></td>
<td><?php if($ffcivscore71 != ""){echo $gradeciv71;}else{echo "-";} ?></td>
<td><?php echo $sscivscore72;  ?></td>
<td><?php if($sscivscore72 != ""){echo $gradeciv72;}else{echo "-";} ?></td>
<td><?php echo $ttcivscore73;  ?></td>
<td><?php if($ttcivscore73 != ""){echo $gradeciv73;}else{echo "-";} ?></td>
<td><?php echo $ffcivscore81;  ?></td>
<td><?php if($ffcivscore81 != ""){echo $gradeciv81;}else{echo "-";} ?></td>
<td><?php echo $sscivscore82;  ?></td>
<td><?php if($sscivscore82 != ""){echo $gradeciv82;}else{echo "-";} ?></td>
<td><?php echo $ttcivscore83;  ?></td>
<td><?php if($ttcivscore83 != ""){echo $gradeciv83;}else{echo "-";} ?></td>
<td><?php echo $ffcivscore91;  ?></td>
<td><?php if($ffcivscore91 != ""){echo $gradeciv91;}else{echo "-";} ?></td>
<td><?php echo $sscivscore92;  ?></td>
<td><?php if($sscivscore92 != ""){echo $gradeciv92;}else{echo "-";} ?></td>
<td><?php echo $ttcivscore93;  ?></td>
<td><?php if($ttcivscore93 != ""){echo $gradeciv93;}else{echo "-";} ?></td>
<td><?php echo $ffcivscore101;  ?></td>
<td><?php if($ffcivscore101 != ""){echo $gradeciv101;}else{echo "-";} ?></td>
<td><?php echo $sscivscore102;  ?></td>
<td><?php if($sscivscore102 != ""){echo $gradeciv102;}else{echo "-";} ?></td>
<td><?php echo $ttcivscore103;  ?></td>
<td><?php if($ttcivscore103 != ""){echo $gradeciv103;}else{echo "-";} ?></td>
<td><?php echo $ffcivscore111;  ?></td>
<td><?php if($ffcivscore111 != ""){echo $gradeciv111;}else{echo "-";} ?></td>
<td><?php echo $sscivscore112;  ?></td>
<td><?php if($sscivscore112 != ""){echo $gradeciv112;}else{echo "-";} ?></td>
<td><?php echo $ttcivscore113;  ?></td>
<td><?php if($ttcivscore113 != ""){echo $gradeciv113;}else{echo "-";} ?></td>
<td><?php echo $ffcivscore121;  ?></td>
<td><?php if($ffcivscore121 != ""){echo $gradeciv121;}else{echo "-";} ?></td>
<td><?php echo $sscivscore122;  ?></td>
<td><?php if($sscivscore122 != ""){echo $gradeciv122;}else{echo "-";} ?></td>
<td><?php echo $ttcivscore123;  ?></td>
<td><?php if($ttcivscore123 != ""){echo $gradeciv123;}else{echo "-";} ?></td>
</tr>


<tr style="height: 13px;">
<td>CRK</td>
<?php
//include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 6'){
echo "";
}
else{
//YEAR 1 DATA FOR CRK
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 1'){
		$y = 'Year 1';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 6'){
		$y = 'Year 6';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='CRK' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecrk71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecrk71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecrk71 = "P";}
								else if(($row["score"] <= 49)){$gradecrk71 = "F";}
								else {$gradecrk71 = "NA";}
						$fcrkscore71[] = $row['score'];						
						}
$ffcrkscore71 = current($fcrkscore71);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='CRK' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecrk72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecrk72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecrk72 = "P";}
								else if(($row["score"] <= 49)){$gradecrk72 = "F";}
								else {$gradecrk72 = "NA";}
						$scrkscore72[] = $row['score'];						
						}
$sscrkscore72 = current($scrkscore72);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='CRK' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecrk73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecrk73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecrk73 = "P";}
								else if(($row["score"] <= 49)){$gradecrk73 = "F";}
								else {$gradecrk73 = "NA";}
						$tcrkscore73[] = $row['score'];						
}
$ttcrkscore73 = current($tcrkscore73);
}
// YEAR 2 DATA FOR CRK
$class_name = $_POST['class_name'];
if(($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 1'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='CRK' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecrk81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecrk81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecrk81 = "P";}
								else if(($row["score"] <= 49)){$gradecrk81 = "F";}
								else {$gradecrk81 = "NA";}
						$fcrkscore81[] = $row['score'];						
						}
$ffcrkscore81 = current($fcrkscore81);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='CRK' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecrk82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecrk82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecrk82 = "P";}
								else if(($row["score"] <= 49)){$gradecrk82 = "F";}
								else {$gradecrk82 = "NA";}
						$scrkscore82[] = $row['score'];						
						}
$sscrkscore82 = current($scrkscore82);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='CRK' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecrk83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecrk83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecrk83 = "P";}
								else if(($row["score"] <= 49)){$gradecrk83 = "F";}
								else {$gradecrk83 = "NA";}
						$tcrkscore83[] = $row['score'];						
}
$ttcrkscore83 = current($tcrkscore83);				
}

// YEAR 3 DATA FOR CRK
$class_name = $_POST['class_name'];
if(($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 1'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='CRK' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecrk91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecrk91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecrk91 = "P";}
								else if(($row["score"] <= 49)){$gradecrk91 = "F";}
								else {$gradecrk91 = "NA";}
						$fcrkscore91[] = $row['score'];						
						}
$ffcrkscore91 = current($fcrkscore91);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='CRK' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecrk92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecrk92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecrk92 = "P";}
								else if(($row["score"] <= 49)){$gradecrk92 = "F";}
								else {$gradecrk92 = "NA";}
						$scrkscore92[] = $row['score'];						
						}
$sscrkscore92 = current($scrkscore92);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='CRK' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecrk93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecrk93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecrk93 = "P";}
								else if(($row["score"] <= 49)){$gradecrk93 = "F";}
								else {$gradecrk93 = "NA";}
						$tcrkscore93[] = $row['score'];						
}
$ttcrkscore93 = current($tcrkscore93);				
}	

// YEAR 4 DATA FOR CRK
$class_name = $_POST['class_name'];
if(($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 1'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='CRK' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradecrk101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecrk101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecrk101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecrk101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecrk101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecrk101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecrk101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecrk101 = "E8";}
								else if(($row["score"] <= 39)){$gradecrk101 = "F9";}
								else {$gradecrk101 = "NA";}
						$fcrkscore101[] = $row['score'];						
						}
$ffcrkscore101 = current($fcrkscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='CRK' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecrk102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecrk102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecrk102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecrk102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecrk102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecrk102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecrk102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecrk102 = "E8";}
								else if(($row["score"] <= 39)){$gradecrk102 = "F9";}
								else {$gradecrk102 = "NA";}
						$scrkscore102[] = $row['score'];						
						}
$sscrkscore102 = current($scrkscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='CRK' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecrk103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecrk103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecrk103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecrk103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecrk103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecrk103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecrk103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecrk103 = "E8";}
								else if(($row["score"] <= 39)){$gradecrk103 = "F9";}
								else {$gradecrk103 = "NA";}
						$tcrkscore103[] = $row['score'];						
}
$ttcrkscore103 = current($tcrkscore103);				
}

// YEAR 5 DATA FOR CRK
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 1'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='CRK' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradecrk111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecrk111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecrk111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecrk111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecrk111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecrk111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecrk111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecrk111 = "E8";}
								else if(($row["score"] <= 39)){$gradecrk111 = "F9";}
								else {$gradecrk111 = "NA";}
						$fcrkscore111[] = $row['score'];						
						}
$ffcrkscore111 = current($fcrkscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='CRK' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecrk112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecrk112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecrk112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecrk112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecrk112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecrk112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecrk112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecrk112 = "E8";}
								else if(($row["score"] <= 39)){$gradecrk112 = "F9";}
								else {$gradecrk112 = "NA";}
						$scrkscore112[] = $row['score'];						
						}
$sscrkscore112 = current($scrkscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='CRK' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$gradecrk113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecrk113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecrk113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecrk113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecrk113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecrk113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecrk113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecrk113 = "E8";}
								else if(($row["score"] <= 39)){$gradecrk113 = "F9";}
								else {$gradecrk113 = "NA";}
						$tcrkscore113[] = $row['score'];						
}
$ttcrkscore113 = current($tcrkscore113);				
}

// YEAR 6 DATA FOR CRK
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 1'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 2'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='CRK' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradecrk121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecrk121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecrk121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecrk121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecrk121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecrk121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecrk121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecrk121 = "E8";}
								else if(($row["score"] <= 39)){$gradecrk121 = "F9";}
								else {$gradecrk121 = "NA";}
						$fcrkscore121[] = $row['score'];						
						}
$ffcrkscore121 = current($fcrkscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='CRK' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecrk122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecrk122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecrk122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecrk122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecrk122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecrk122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecrk122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecrk122 = "E8";}
								else if(($row["score"] <= 39)){$gradecrk122 = "F9";}
								else {$gradecrk122 = "NA";}
						$scrkscore122[] = $row['score'];						
						}
$sscrkscore122 = current($scrkscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='CRK' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecrk123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecrk123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecrk123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecrk123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecrk123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecrk123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecrk123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecrk123 = "E8";}
								else if(($row["score"] <= 39)){$gradecrk123 = "F9";}
								else {$gradecrk123 = "NA";}
						$tcrkscore123[] = $row['score'];						
}
$ttcrkscore123 = current($tcrkscore123);				
}					
?>
<td><?php echo $ffcrkscore71;  ?></td>
<td><?php if($ffcrkscore71 != ""){echo $gradecrk71;}else{echo "-";} ?></td>
<td><?php echo $sscrkscore72;  ?></td>
<td><?php if($sscrkscore72 != ""){echo $gradecrk72;}else{echo "-";} ?></td>
<td><?php echo $ttcrkscore73;  ?></td>
<td><?php if($ttcrkscore73 != ""){echo $gradecrk73;}else{echo "-";} ?></td>
<td><?php echo $ffcrkscore81;  ?></td>
<td><?php if($ffcrkscore81 != ""){echo $gradecrk81;}else{echo "-";} ?></td>
<td><?php echo $sscrkscore82;  ?></td>
<td><?php if($sscrkscore82 != ""){echo $gradecrk82;}else{echo "-";} ?></td>
<td><?php echo $ttcrkscore83;  ?></td>
<td><?php if($ttcrkscore83 != ""){echo $gradecrk83;}else{echo "-";} ?></td>
<td><?php echo $ffcrkscore91;  ?></td>
<td><?php if($ffcrkscore91 != ""){echo $gradecrk91;}else{echo "-";} ?></td>
<td><?php echo $sscrkscore92;  ?></td>
<td><?php if($sscrkscore92 != ""){echo $gradecrk92;}else{echo "-";} ?></td>
<td><?php echo $ttcrkscore93;  ?></td>
<td><?php if($ttcrkscore93 != ""){echo $gradecrk93;}else{echo "-";} ?></td>
<td><?php echo $ffcrkscore101;  ?></td>
<td><?php if($ffcrkscore101 != ""){echo $gradecrk101;}else{echo "-";} ?></td>
<td><?php echo $sscrkscore102;  ?></td>
<td><?php if($sscrkscore102 != ""){echo $gradecrk102;}else{echo "-";} ?></td>
<td><?php echo $ttcrkscore103;  ?></td>
<td><?php if($ttcrkscore103 != ""){echo $gradecrk103;}else{echo "-";} ?></td>
<td><?php echo $ffcrkscore111;  ?></td>
<td><?php if($ffcrkscore111 != ""){echo $gradecrk111;}else{echo "-";} ?></td>
<td><?php echo $sscrkscore112;  ?></td>
<td><?php if($sscrkscore112 != ""){echo $gradecrk112;}else{echo "-";} ?></td>
<td><?php echo $ttcrkscore113;  ?></td>
<td><?php if($ttcrkscore113 != ""){echo $gradecrk113;}else{echo "-";} ?></td>
<td><?php echo $ffcrkscore121;  ?></td>
<td><?php if($ffcrkscore121 != ""){echo $gradecrk121;}else{echo "-";} ?></td>
<td><?php echo $sscrkscore122;  ?></td>
<td><?php if($sscrkscore122 != ""){echo $gradecrk122;}else{echo "-";} ?></td>
<td><?php echo $ttcrkscore123;  ?></td>
<td><?php if($ttcrkscore123 != ""){echo $gradecrk123;}else{echo "-";} ?></td>
</tr>


<tr style="height: 13px;">
<td>CREATIVE &amp; CULTURAL ARTS</td>
<?php
//include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 6'){
echo "";
}
else{
//YEAR 1 DATA FOR CREATIVE & CULTURAL ARTS
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 1'){
		$y = 'Year 1';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 6'){
		$y = 'Year 6';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='Creative and Cultural Arts' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecre71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecre71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecre71 = "P";}
								else if(($row["score"] <= 49)){$gradecre71 = "F";}
								else {$gradecre71 = "NA";}
						$fcrescore71[] = $row['score'];						
						}
$ffcrescore71 = current($fcrescore71);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='Creative and Cultural Arts' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecre72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecre72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecre72 = "P";}
								else if(($row["score"] <= 49)){$gradecre72 = "F";}
								else {$gradecre72 = "NA";}
						$screscore72[] = $row['score'];						
						}
$sscrescore72 = current($screscore72);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='Creative and Cultural Arts' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecre73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecre73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecre73 = "P";}
								else if(($row["score"] <= 49)){$gradecre73 = "F";}
								else {$gradecre73 = "NA";}
						$tcrescore73[] = $row['score'];						
}
$ttcrescore73 = current($tcrescore73);
}
// YEAR 2 DATA FOR CREATIVE AND Cultural ARTS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 1'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Creative and Cultural Arts' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecre81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecre81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecre81 = "P";}
								else if(($row["score"] <= 49)){$gradecre81 = "F";}
								else {$gradecre81 = "NA";}
						$fcrescore81[] = $row['score'];						
						}
$ffcrescore81 = current($fcrescore81);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Creative and Cultural Arts' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecre82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecre82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecre82 = "P";}
								else if(($row["score"] <= 49)){$gradecre82 = "F";}
								else {$gradecre82 = "NA";}
						$screscore82[] = $row['score'];						
						}
$sscrescore82 = current($screscore82);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Creative and Cultural Arts' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecre83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecre83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecre83 = "P";}
								else if(($row["score"] <= 49)){$gradecre83 = "F";}
								else {$gradecre83 = "NA";}
						$tcrescore83[] = $row['score'];						
}
$ttcrescore83 = current($tcrescore83);				
}

// YEAR 3 DATA FOR CREATIVE AND Cultural ARTS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 1'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Creative and Cultural Arts' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecre91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecre91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecre91 = "P";}
								else if(($row["score"] <= 49)){$gradecre91 = "F";}
								else {$gradecre91 = "NA";}
						$fcrescore91[] = $row['score'];						
						}
$ffcrescore91 = current($fcrescore91);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Creative and Cultural Arts' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecre92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecre92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecre92 = "P";}
								else if(($row["score"] <= 49)){$gradecre92 = "F";}
								else {$gradecre92 = "NA";}
						$screscore92[] = $row['score'];						
						}
$sscrescore92 = current($screscore92);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Creative and Cultural Arts' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecre93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecre93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecre93 = "P";}
								else if(($row["score"] <= 49)){$gradecre93 = "F";}
								else {$gradecre93 = "NA";}
						$tcrescore93[] = $row['score'];						
}
$ttcrescore93 = current($tcrescore93);				
}	

// YEAR 4 DATA FOR CREATIVE AND Cultural ARTS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 1'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Creative and Cultural Arts' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradecre101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecre101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecre101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecre101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecre101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecre101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecre101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecre101 = "E8";}
								else if(($row["score"] <= 39)){$gradecre101 = "F9";}
								else {$gradecre101 = "NA";}
						$fcrescore101[] = $row['score'];						
						}
$ffcrescore101 = current($fcrescore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='CRK' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecre102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecre102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecre102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecre102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecre102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecre102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecre102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecre102 = "E8";}
								else if(($row["score"] <= 39)){$gradecre102 = "F9";}
								else {$gradecre102 = "NA";}
						$fcrescore102[] = $row['score'];						
						}
$sscrescore102 = current($screscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='CRK' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecre103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecre103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecre103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecre103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecre103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecre103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecre103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecre103 = "E8";}
								else if(($row["score"] <= 39)){$gradecre103 = "F9";}
								else {$gradecre103 = "NA";}
						$fcrescore103[] = $row['score'];						
}
$ttcrescore103 = current($tcrescore103);				
}

// YEAR 5 DATA FOR CREATIVE AND Cultural ARTS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 1'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Creative and Cultural Arts' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradecre111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecre111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecre111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecre111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecre111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecre111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecre111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecre111 = "E8";}
								else if(($row["score"] <= 39)){$gradecre111 = "F9";}
								else {$gradecre111 = "NA";}
						$fcrescore111[] = $row['score'];							
						}
$ffcrescore111 = current($fcrescore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Creative and Cultural Arts' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecre112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecre112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecre112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecre112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecre112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecre112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecre112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecre112 = "E8";}
								else if(($row["score"] <= 39)){$gradecre112 = "F9";}
								else {$gradecre112 = "NA";}
						$fcrescore112[] = $row['score'];						
						}
$sscrescore112 = current($screscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Creative and Cultural Arts' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecre113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecre113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecre113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecre113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecre113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecre113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecre113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecre113 = "E8";}
								else if(($row["score"] <= 39)){$gradecre113 = "F9";}
								else {$gradecre113 = "NA";}
						$fcrescore113[] = $row['score'];						
}
$ttcrescore113 = current($tcrescore113);				
}

// YEAR 6 DATA FOR CREATIVE AND Cultural ARTS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 1'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 2'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Creative and Cultural Arts' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradecre121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecre121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecre121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecre121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecre121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecre121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecre121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecre121 = "E8";}
								else if(($row["score"] <= 39)){$gradecre121 = "F9";}
								else {$gradecre121 = "NA";}
						$fcrescore121[] = $row['score'];						
						}
$ffcrescore121 = current($fcrescore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Creative and Cultural Arts' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradecre122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecre122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecre122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecre122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecre122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecre122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecre122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecre122 = "E8";}
								else if(($row["score"] <= 39)){$gradecre122 = "F9";}
								else {$gradecre122 = "NA";}
						$fcrescore122[] = $row['score'];						
						}
$sscrescore122 = current($screscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Creative and Cultural Arts' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradecre123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecre123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecre123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecre123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecre123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecre123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecre123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecre123 = "E8";}
								else if(($row["score"] <= 39)){$gradecre123 = "F9";}
								else {$gradecre123 = "NA";}
						$fcrescore123[] = $row['score'];						
}
$ttcrescore123 = current($tcrescore123);				
}					
?>
<td><?php echo $ffcrescore71;  ?></td>
<td><?php if($ffcrescore71 != ""){echo $gradecre71;}else{echo "-";} ?></td>
<td><?php echo $sscrescore72;  ?></td>
<td><?php if($sscrescore72 != ""){echo $gradecre72;}else{echo "-";} ?></td>
<td><?php echo $ttcrescore73;  ?></td>
<td><?php if($ttcrescore73 != ""){echo $gradecre73;}else{echo "-";} ?></td>
<td><?php echo $ffcrescore81;  ?></td>
<td><?php if($ffcrescore81 != ""){echo $gradecre81;}else{echo "-";} ?></td>
<td><?php echo $sscrescore82;  ?></td>
<td><?php if($sscrescore82 != ""){echo $gradecre82;}else{echo "-";} ?></td>
<td><?php echo $ttcrescore83;  ?></td>
<td><?php if($ttcrescore83 != ""){echo $gradecre83;}else{echo "-";} ?></td>
<td><?php echo $ffcrescore91;  ?></td>
<td><?php if($ffcrescore91 != ""){echo $gradecre91;}else{echo "-";} ?></td>
<td><?php echo $sscrescore92;  ?></td>
<td><?php if($sscrescore92 != ""){echo $gradecre92;}else{echo "-";} ?></td>
<td><?php echo $ttcrescore93;  ?></td>
<td><?php if($ttcrescore93 != ""){echo $gradecre93;}else{echo "-";} ?></td>
<td><?php echo $ffcrescore101;  ?></td>
<td><?php if($ffcrescore101 != ""){echo $gradecre101;}else{echo "-";} ?></td>
<td><?php echo $sscrescore102;  ?></td>
<td><?php if($sscrescore102 != ""){echo $gradecre102;}else{echo "-";} ?></td>
<td><?php echo $ttcrescore103;  ?></td>
<td><?php if($ttcrescore103 != ""){echo $gradecre103;}else{echo "-";} ?></td>
<td><?php echo $ffcrescore111;  ?></td>
<td><?php if($ffcrescore111 != ""){echo $gradecre111;}else{echo "-";} ?></td>
<td><?php echo $sscrescore112;  ?></td>
<td><?php if($sscrescore112 != ""){echo $gradecre112;}else{echo "-";} ?></td>
<td><?php echo $ttcrescore113;  ?></td>
<td><?php if($ttcrescore113 != ""){echo $gradecre113;}else{echo "-";} ?></td>
<td><?php echo $ffcrescore121;  ?></td>
<td><?php if($ffcrescore121 != ""){echo $gradecre121;}else{echo "-";} ?></td>
<td><?php echo $sscrescore122;  ?></td>
<td><?php if($sscrescore122 != ""){echo $gradecre122;}else{echo "-";} ?></td>
<td><?php echo $ttcrescore123;  ?></td>
<td><?php if($ttcrescore123 != ""){echo $gradecre123;}else{echo "-";} ?></td>
</tr>








<tr style="height: 13px;">
<td>FRENCH.</td>
<?php
//include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 6'){
echo "";
}
else{
//YEAR 1 DATA FOR FRENCH
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 1'){
		$y = 'Year 1';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 6'){
		$y = 'Year 6';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='French' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefre71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefre71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefre71 = "P";}
								else if(($row["score"] <= 49)){$gradefre71 = "F";}
								else {$gradefre71 = "NA";}
						$ffrescore71[] = $row['score'];						
						}
$fffrescore71 = current($ffrescore71);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='French' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefre72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefre72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefre72 = "P";}
								else if(($row["score"] <= 49)){$gradefre72 = "F";}
								else {$gradefre72 = "NA";}
						$sfrescore72[] = $row['score'];						
						}
$ssfrescore72 = current($sfrescore72);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='French' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefre73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefre73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefre73 = "P";}
								else if(($row["score"] <= 49)){$gradefre73 = "F";}
								else {$gradefre73 = "NA";}
						$tfrescore73[] = $row['score'];						
						}
$ttfrescore73 = current($tfrescore73);
}
// YEAR 2 DATA FOR FRENCH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 1'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='French' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefre81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefre81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefre81 = "P";}
								else if(($row["score"] <= 49)){$gradefre81 = "F";}
								else {$gradefre81 = "NA";}
						$ffrescore81[] = $row['score'];						
						}
$fffrescore81 = current($ffrescore81);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='French' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefre82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefre82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefre82 = "P";}
								else if(($row["score"] <= 49)){$gradefre82 = "F";}
								else {$gradefre82 = "NA";}
						$sfrescore82[] = $row['score'];						
						}
$ssfrescore82 = current($sfrescore82);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='French' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefre83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefre83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefre83 = "P";}
								else if(($row["score"] <= 49)){$gradefre83 = "F";}
								else {$gradefre83 = "NA";}
						$tfrescore83[] = $row['score'];						
						}
$ttfrescore83 = current($tfrescore83);
}

// YEAR 3 DATA FOR FRENCH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 1'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='French' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefre91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefre91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefre91 = "P";}
								else if(($row["score"] <= 49)){$gradefre91 = "F";}
								else {$gradefre91 = "NA";}
						$ffrescore91[] = $row['score'];						
						}
$fffrescore91 = current($ffrescore91);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='French' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefre92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefre92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefre92 = "P";}
								else if(($row["score"] <= 49)){$gradefre92 = "F";}
								else {$gradefoo92 = "NA";}
						$sfrescore92[] = $row['score'];						
						}
$ssfrescore92 = current($sfrescore92);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='French' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefre93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefre93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefre93 = "P";}
								else if(($row["score"] <= 49)){$gradefre93 = "F";}
								else {$gradefre93 = "NA";}
						$tfrescore93[] = $row['score'];						
						}
$ttfrescore93 = current($tfrescore93);				
}	

// YEAR 4 DATA FOR FRENCH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 1'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='French' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradefre101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefre101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefre101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefre101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefre101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefre101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefre101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefre101 = "E8";}
								else if(($row["score"] <= 39)){$gradefre101 = "F9";}
								else {$gradefre101 = "NA";}
						$ffrescore101[] = $row['score'];						
						}
$fffrescore101 = current($ffrescore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='French' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradefre102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefre102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefre102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefre102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefre102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefre102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefre102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefre102 = "E8";}
								else if(($row["score"] <= 39)){$gradefre102 = "F9";}
								else {$gradefre102 = "NA";}
						$sfrescore102[] = $row['score'];						
						}
$ssfrescore102 = current($sfrescore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='French' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradefre103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefre103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefre103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefre103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefre103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefre103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefre103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefre103 = "E8";}
								else if(($row["score"] <= 39)){$gradefre103 = "F9";}
								else {$gradefre103 = "NA";}
						$tfrescore103[] = $row['score'];						
						}
$ttfrescore103 = current($tfrescore103);		
}

// YEAR 5 DATA FOR FRENCH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 1'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='French' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradefre111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefre111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefre111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefre111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefre111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefre111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefre111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefre111 = "E8";}
								else if(($row["score"] <= 39)){$gradefre111 = "F9";}
								else {$gradefre111 = "NA";}
						$ffrescore111[] = $row['score'];						
						}
$fffrescore111 = current($ffrescore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='French' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradefre112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefre112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefre112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefre112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefre112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefre112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefre112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefre112 = "E8";}
								else if(($row["score"] <= 39)){$gradefre112 = "F9";}
								else {$gradefre112 = "NA";}
						$sfrescore112[] = $row['score'];						
						}
$ssfrescore112 = current($sfrescore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='French' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradefre113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefre113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefre113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefre113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefre113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefre113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefre113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefre113 = "E8";}
								else if(($row["score"] <= 39)){$gradefre113 = "F9";}
								else {$gradefre113 = "NA";}
						$tfrescore113[] = $row['score'];						
						}
$ttfrescore113 = current($tfrescore113);				
}

// YEAR 6 DATA FOR FRENCH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 1'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 2'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='French' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradefre121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefre121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefre121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefre121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefre121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefre121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefre121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefre121 = "E8";}
								else if(($row["score"] <= 39)){$gradefre121 = "F9";}
								else {$gradefre121 = "NA";}
						$ffrescore121[] = $row['score'];						
						}
$fffrescore121 = current($ffrescore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='French' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradefre122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefre122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefre122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefre122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefre122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefre122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefre122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefre122 = "E8";}
								else if(($row["score"] <= 39)){$gradefre122 = "F9";}
								else {$gradefre122 = "NA";}
						$sfrescore122[] = $row['score'];						
						}
$ssfrescore122 = current($sfrescore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='French' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradefre123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefre123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefre123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefre123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefre123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefre123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefre123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefre123 = "E8";}
								else if(($row["score"] <= 39)){$gradefre123 = "F9";}
								else {$gradefre123 = "NA";}
						$tfrescore123[] = $row['score'];						
						}
$ttfrescore123 = current($tfrescore123);			
}					
?>
<td><?php echo $fffrescore71;  ?></td>
<td><?php if($fffrescore71 != ""){echo $gradefre71;}else{echo "-";} ?></td>
<td><?php echo $ssfrescore72;  ?></td>
<td><?php if($ssfrescore72 != ""){echo $gradefre72;}else{echo "-";} ?></td>
<td><?php echo $ttfrescore73;  ?></td>
<td><?php if($ttfrescore73 != ""){echo $gradefre73;}else{echo "-";} ?></td>
<td><?php echo $fffrescore81;  ?></td>
<td><?php if($fffrescore81 != ""){echo $gradefre81;}else{echo "-";} ?></td>
<td><?php echo $ssfrescore82;  ?></td>
<td><?php if($ssfrescore82 != ""){echo $gradefre82;}else{echo "-";} ?></td>
<td><?php echo $ttfrescore83;  ?></td>
<td><?php if($ttfrescore83 != ""){echo $gradefre83;}else{echo "-";} ?></td>
<td><?php echo $fffrescore91;  ?></td>
<td><?php if($fffrescore91 != ""){echo $gradefre91;}else{echo "-";} ?></td>
<td><?php echo $ssfrescore92;  ?></td>
<td><?php if($ssfrescore92 != ""){echo $gradefre92;}else{echo "-";} ?></td>
<td><?php echo $ttfrescore93;  ?></td>
<td><?php if($ttfrescore93 != ""){echo $gradefre93;}else{echo "-";} ?></td>
<td><?php echo $fffrescore101;  ?></td>
<td><?php if($fffrescore101 != ""){echo $gradefre101;}else{echo "-";} ?></td>
<td><?php echo $ssfrescore102;  ?></td>
<td><?php if($ssfrescore102 != ""){echo $gradefre102;}else{echo "-";} ?></td>
<td><?php echo $ttfrescore103;  ?></td>
<td><?php if($ttfrescore103 != ""){echo $gradefre103;}else{echo "-";} ?></td>
<td><?php echo $fffrescore111;  ?></td>
<td><?php if($fffrescore111 != ""){echo $gradefre111;}else{echo "-";} ?></td>
<td><?php echo $ssfrescore112;  ?></td>
<td><?php if($ssfrescore112 != ""){echo $gradefre112;}else{echo "-";} ?></td>
<td><?php echo $ttfrescore113;  ?></td>
<td><?php if($ttfrescore113 != ""){echo $gradefre113;}else{echo "-";} ?></td>
<td><?php echo $fffrescore121;  ?></td>
<td><?php if($fffrescore121 != ""){echo $gradefre121;}else{echo "-";} ?></td>
<td><?php echo $ssfrescore122;  ?></td>
<td><?php if($ssfrescore122 != ""){echo $gradefre122;}else{echo "-";} ?></td>
<td><?php echo $ttfrescore123;  ?></td>
<td><?php if($ttfrescore123 != ""){echo $gradefre123;}else{echo "-";} ?></td>
</tr>

<tr style="height: 13px;">
<td>HANDWRITING</td>
<?php
//include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
//YEAR 1 DATA FOR Handwriting
		$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 1'){
		$y = 'Year 1';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 6'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Handwriting' AND school='".$_SESSION["school"]."'");
				while($row = mysqli_fetch_assoc($result))
							{
						$term111[] = $row['term'];						
						$score111[] = $row['score'];						
						}
$fscore111 = $score111;
$fterm111 = $term111;
$c = array_combine($fterm111, $fscore111);
$hw7 = $c;
ksort($hw7);
$ffhwsc71 = $hw7['First Term'];
$sshwsc72 = $hw7['Second Term'];
$tthwsc73 = $hw7['Third Term'];
if($ffhwsc71 >= 70){$gradehw71 = "A"; }
else if(($ffhwsc71 >= 60) AND ($ffhwsc71 <= 69)){$gradehw71 = "C";}
else if(($ffhwsc71 >= 50) AND ($ffhwsc71 <= 59)){$gradehw71 = "P";}
else if(($ffhwsc71 <= 49)){$gradehw71 = "F";}
else {$gradehw71 = "NA";}	
if($sshwsc72 >= 70){$gradehw72 = "A"; }
else if(($sshwsc72 >= 60) AND ($sshwsc72 <= 69)){$gradehw72 = "C";}
else if(($sshwsc72 >= 50) AND ($sshwsc72 <= 59)){$gradehw72 = "P";}
else if(($sshwsc72 <= 49)){$gradehw72 = "F";}
else {$gradehw72 = "NA";}	
if($tthwsc73 >= 70){$gradehw73 = "A"; }
else if(($tthwsc73 >= 60) AND ($tthwsc73 <= 69)){$gradehw73 = "C";}
else if(($tthwsc73 >= 50) AND ($tthwsc73 <= 59)){$gradehw73 = "P";}
else if(($tthwsc73 <= 49)){$gradehw73 = "F";}
else {$gradehw73 = "NA";}	
}

// YEAR 2 DATA FOR HANDWRITING
$class_name = $_POST['class_name'];
if(($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 1'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Handwriting' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradehw81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradehw81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradehw81 = "P";}
								else if(($row["score"] <= 49)){$gradehw81 = "F";}
								else {$gradehw81 = "NA";}
						$fhwscore81[] = $row['score'];	
						}
$ffhwsc81 = current($fhwscore81);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Handwriting' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 70){$gradehw82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradehw82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradehw82 = "P";}
								else if(($row["score"] <= 49)){$gradehw82 = "F";}
								else {$gradehw82 = "NA";}
						$fhwscore82[] = $row['score'];	
						}
$sshwsc82 = current($shwscore82);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Handwriting' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradehw83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradehw83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradehw83 = "P";}
								else if(($row["score"] <= 49)){$gradehw83 = "F";}
								else {$gradehw83 = "NA";}
						$thwscore83[] = $row['score'];	
						}
$tthwsc83 = current($thwscore83);	
}
// YEAR 3 DATA FOR HANDWRITING
$class_name = $_POST['class_name'];
if(($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 1'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Handwriting' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradehw91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradehw91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradehw91 = "P";}
								else if(($row["score"] <= 49)){$gradehw91 = "F";}
								else {$gradehw91 = "NA";}
						$fhwscore91[] = $row['score'];	
						}
$ffhwsc91 = current($fhwscore91);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Handwriting' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 70){$gradehw92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradehw92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradehw92 = "P";}
								else if(($row["score"] <= 49)){$gradehw92 = "F";}
								else {$gradehw92 = "NA";}
						$fhwscore92[] = $row['score'];	
						}
$ssvrsc92 = current($svrscore92);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Handwriting' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 70){$gradehw93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradehw93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradehw93 = "P";}
								else if(($row["score"] <= 49)){$gradehw93 = "F";}
								else {$gradehw93 = "NA";}
						$fhwscore93[] = $row['score'];	
						}
$tthwsc93 = current($thwscore93);	
}	

// YEAR 4 DATA FOR HANDWRITING
$class_name = $_POST['class_name'];
if(($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 1'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Handwriting' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradehw101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradehw101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradehw101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradehw101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradehw101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradehw101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradehw101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradehw101 = "E8";}
								else if(($row["score"] <= 39)){$gradehw101 = "F9";}
								else {$gradehw101 = "NA";}
						$fhwscore101[] = $row['score'];						
						}
$ffhwsc101 = current($fhwscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Handwriting' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradehw102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradehw102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradehw102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradehw102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradehw102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradehw102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradehw102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradehw102 = "E8";}
								else if(($row["score"] <= 39)){$gradehw102 = "F9";}
								else {$gradehw102 = "NA";}
						$fhwscore102[] = $row['score'];							
						}
$sshwsc102 = current($shwscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Handwriting' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradehw103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradehw103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradehw103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradehw103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradehw103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradehw103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradehw103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradehw103 = "E8";}
								else if(($row["score"] <= 39)){$gradehw103 = "F9";}
								else {$gradehw103 = "NA";}
						$fhwscore103[] = $row['score'];						
						}
$tthwsc103 = current($thwscore103);
}

// YEAR 5 DATA FOR HANDWRITING
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 1'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Handwriting' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradehw111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradehw111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradehw111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradehw111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradehw111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradehw111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradehw111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradehw111 = "E8";}
								else if(($row["score"] <= 39)){$gradehw111 = "F9";}
								else {$gradehw111 = "NA";}
						$fhwscore111[] = $row['score'];							
						}
$ffhwsc111 = current($fhwscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Handwriting' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradehw112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradehw112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradehw112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradehw112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradehw112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradehw112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradehw112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradehw112 = "E8";}
								else if(($row["score"] <= 39)){$gradehw112 = "F9";}
								else {$gradehw112 = "NA";}
						$fhwscore112[] = $row['score'];					
						}
$sshwsc112 = current($shwscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Handwriting' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradehw113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradehw113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradehw113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradehw113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradehw113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradehw113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradehw113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradehw113 = "E8";}
								else if(($row["score"] <= 39)){$gradehw113 = "F9";}
								else {$gradehw113 = "NA";}
						$fhwscore113[] = $row['score'];							
						}
$tthwsc113 = current($thwscore113);		
}

// YEAR 6 DATA FOR HANDWRITING
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 1'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 2'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Handwriting' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
							if($row["score"] >= 80){$gradehw121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradehw121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradehw121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradehw121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradehw121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradehw121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradehw121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradehw121 = "E8";}
								else if(($row["score"] <= 39)){$gradehw121 = "F9";}
								else {$gradehw121 = "NA";}
						$fhwscore121[] = $row['score'];							
						}
$ffhwsc121 = current($fhwscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Handwriting' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradehw122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradehw122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradehw122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradehw122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradehw122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradehw122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradehw122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradehw122 = "E8";}
								else if(($row["score"] <= 39)){$gradehw122 = "F9";}
								else {$gradehw122 = "NA";}
						$fhwscore122[] = $row['score'];						
						}
$sshwsc122 = current($shwscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Handwriting' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradehw123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradehw123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradehw123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradehw123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradehw123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradehw123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradehw123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradehw123 = "E8";}
								else if(($row["score"] <= 39)){$gradehw123 = "F9";}
								else {$gradehw123 = "NA";}
						$fhwscore123[] = $row['score'];						
						}
$tthwsc123 = current($thwscore123);
}					
?>
<td><?php echo $ffhwsc71;  ?></td>
<td><?php if($ffhwsc71 != ""){echo $gradehw71;}else{echo "-";} ?></td>
<td><?php echo $sshwsc72;  ?></td>
<td><?php if($sshwsc72 != ""){echo $gradehw72;}else{echo "-";} ?></td>
<td><?php echo $tthwsc73;  ?></td>
<td><?php if($tthwsc73 != ""){echo $gradehw73;}else{echo "-";} ?></td>
<td><?php echo $ffhwsc81;  ?></td>
<td><?php if($ffhwsc81 != ""){echo $gradehw81;}else{echo "-";} ?></td>
<td><?php echo $sshwsc82;  ?></td>
<td><?php if($sshwsc82 != ""){echo $gradehw82;}else{echo "-";} ?></td>
<td><?php echo $tthwsc83;  ?></td>
<td><?php if($tthwsc83 != ""){echo $gradehw83;}else{echo "-";} ?></td>
<td><?php echo $ffhwsc91;  ?></td>
<td><?php if($ffhwsc91 != ""){echo $gradehw91;}else{echo "-";} ?></td>
<td><?php echo $sshwsc92;  ?></td>
<td><?php if($sshwsc92 != ""){echo $gradehw92;}else{echo "-";} ?></td>
<td><?php echo $tthwsc93;  ?></td>
<td><?php if($tthwsc93 != ""){echo $gradehw93;}else{echo "-";} ?></td>
<td><?php echo $ffhwsc101;  ?></td>
<td><?php if($ffhwsc101 != ""){echo $gradehw101;}else{echo "-";} ?></td>
<td><?php echo $sshwsc102;  ?></td>
<td><?php if($sshwsc102 != ""){echo $gradehw102;}else{echo "-";} ?></td>
<td><?php echo $tthwsc103;  ?></td>
<td><?php if($tthwsc103 != ""){echo $gradehw103;}else{echo "-";} ?></td>
<td><?php echo $ffhwsc111;  ?></td>
<td><?php if($ffhwsc111 != ""){echo $gradehw111;}else{echo "-";} ?></td>
<td><?php echo $sshwsc112;  ?></td>
<td><?php if($sshwsc112 != ""){echo $gradehw112;}else{echo "-";} ?></td>
<td><?php echo $tthwsc113;  ?></td>
<td><?php if($tthwsc113 != ""){echo $gradehw113;}else{echo "-";} ?></td>
<td><?php echo $ffhwsc121;  ?></td>
<td><?php if($ffhwsc121 != ""){echo $gradehw121;}else{echo "-";} ?></td>
<td><?php echo $sshwsc122;  ?></td>
<td><?php if($sshwsc122 != ""){echo $gradehw122;}else{echo "-";} ?></td>
<td><?php echo $tthwsc123;  ?></td>
<td><?php if($tthwsc123 != ""){echo $gradehw123;}else{echo "-";} ?></td>
</tr>


<tr style="height: 13px;">
<td>HAUSA</td>
<?php
//include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 6'){
echo "";
}
else{
//YEAR 1 DATA FOR HAUSA
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 1'){
		$y = 'Year 1';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 6'){
		$y = 'Year 6';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='Hausa' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradehau71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradehau71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradehau71 = "P";}
								else if(($row["score"] <= 49)){$gradehau71 = "F";}
								else {$gradehau71 = "NA";}
						$fhauscore71[] = $row['score'];						
						}
$ffhauscore71 = current($fhauscore71);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='Hausa' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradehau72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradehau72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradehau72 = "P";}
								else if(($row["score"] <= 49)){$gradehau72 = "F";}
								else {$gradehau72 = "NA";}
						$shauscore72[] = $row['score'];						
						}
$sshauscore72 = current($shauscore72);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='Hausa' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradehau73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradehau73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradehau73 = "P";}
								else if(($row["score"] <= 49)){$gradehau73 = "F";}
								else {$gradehau73 = "NA";}
						$thauscore73[] = $row['score'];						
						}
$tthauscore73 = current($thauscore73);
}
// YEAR 2 DATA FOR HAUSA
$class_name = $_POST['class_name'];
if(($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 1'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Hausa' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradehau81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradehau81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradehau81 = "P";}
								else if(($row["score"] <= 49)){$gradehau81 = "F";}
								else {$gradehau81 = "NA";}
						$fhauscore81[] = $row['score'];						
						}
$ffhauscore81 = current($fhauscore81);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Hausa' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradehau82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradehau82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradehau82 = "P";}
								else if(($row["score"] <= 49)){$gradehau82 = "F";}
								else {$gradehau82 = "NA";}
						$shauscore82[] = $row['score'];						
						}
$sshauscore82 = current($shauscore82);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Hausa' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradehau83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradehau83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradehau83 = "P";}
								else if(($row["score"] <= 49)){$gradehau83 = "F";}
								else {$gradehau83 = "NA";}
						$thauscore83[] = $row['score'];						
						}
$tthauscore83 = current($thauscore83);
}
// YEAR 3 DATA FOR HAUSA
$class_name = $_POST['class_name'];
if(($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 1'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Hausa' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradehau91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradehau91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradehau91 = "P";}
								else if(($row["score"] <= 49)){$gradehau91 = "F";}
								else {$gradehau91 = "NA";}
						$fhauscore91[] = $row['score'];						
						}
$ffhauscore91 = current($fhauscore91);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Hausa' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradehau92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradehau92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradehau92 = "P";}
								else if(($row["score"] <= 49)){$gradehau92 = "F";}
								else {$gradehau92 = "NA";}
						$shauscore92[] = $row['score'];						
						}
$sshauscore92 = current($shauscore92);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Hausa' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradehau93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradehau93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradehau93 = "P";}
								else if(($row["score"] <= 49)){$gradehau93 = "F";}
								else {$gradehau93 = "NA";}
						$thauscore93[] = $row['score'];						
						}
$tthauscore93 = current($thauscore93);	
}	

// YEAR 4 DATA FOR HAUSA
$class_name = $_POST['class_name'];
if(($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 1'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Hausa' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradehau101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradehau101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradehau101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradehau101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradehau101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradehau101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradehau101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradehau101 = "E8";}
								else if(($row["score"] <= 39)){$gradehau101 = "F9";}
								else {$gradehau101 = "NA";}
						$fhauscore101[] = $row['score'];						
						}
$ffhauscore101 = current($fhauscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Hausa' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradehau102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradehau102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradehau102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradehau102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradehau102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradehau102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradehau102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradehau102 = "E8";}
								else if(($row["score"] <= 39)){$gradehau102 = "F9";}
								else {$gradehau102 = "NA";}
						$fhauscore102[] = $row['score'];						
						}
$sshauscore102 = current($shauscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Hausa' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradehau103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradehau103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradehau103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradehau103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradehau103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradehau103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradehau103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradehau103 = "E8";}
								else if(($row["score"] <= 39)){$gradehau103 = "F9";}
								else {$gradehau103 = "NA";}
						$fhauscore103[] = $row['score'];						
						}
$tthauscore103 = current($thauscore103);	
}

// YEAR 5 DATA FOR HAUSA
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 1'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Hausa' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradehau111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradehau111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradehau111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradehau111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradehau111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradehau111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradehau111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradehau111 = "E8";}
								else if(($row["score"] <= 39)){$gradehau111 = "F9";}
								else {$gradehau111 = "NA";}
						$fhauscore111[] = $row['score'];						
						}
$ffhauscore111 = current($fhauscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Hausa' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradehau112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradehau112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradehau112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradehau112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradehau112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradehau112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradehau112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradehau112 = "E8";}
								else if(($row["score"] <= 39)){$gradehau112 = "F9";}
								else {$gradehau112 = "NA";}
						$fhauscore112[] = $row['score'];						
						}
$sshauscore112 = current($shauscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Hausa' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradehau113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradehau113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradehau113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradehau113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradehau113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradehau113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradehau113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradehau113 = "E8";}
								else if(($row["score"] <= 39)){$gradehau113 = "F9";}
								else {$gradehau113 = "NA";}
						$fhauscore113[] = $row['score'];						
						}
$tthauscore113 = current($thauscore113);				
}

// YEAR 6 DATA FOR HAUSA
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 1'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 2'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Hausa' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradehau121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradehau121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradehau121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradehau121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradehau121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradehau121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradehau121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradehau121 = "E8";}
								else if(($row["score"] <= 39)){$gradehau121 = "F9";}
								else {$gradehau121 = "NA";}
						$fhauscore121[] = $row['score'];						
						}
$ffhauscore121 = current($fhauscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Hausa' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradehau122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradehau122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradehau122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradehau122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradehau122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradehau122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradehau122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradehau122 = "E8";}
								else if(($row["score"] <= 39)){$gradehau122 = "F9";}
								else {$gradehau122 = "NA";}
						$fhauscore122[] = $row['score'];					
						}
$sshauscore122 = current($shauscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Hausa' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradehau123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradehau123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradehau123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradehau123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradehau123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradehau123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradehau123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradehau123 = "E8";}
								else if(($row["score"] <= 39)){$gradehau123 = "F9";}
								else {$gradehau123 = "NA";}
						$fhauscore123[] = $row['score'];						
						}
$tthauscore123 = current($thauscore123);		
}					
?>
<td><?php echo $ffhauscore71;  ?></td>
<td><?php if($ffhauscore71 != ""){echo $gradehau71;}else{echo "-";} ?></td>
<td><?php echo $sshauscore72;  ?></td>
<td><?php if($sshauscore72 != ""){echo $gradehau72;}else{echo "-";} ?></td>
<td><?php echo $tthauscore73;  ?></td>
<td><?php if($tthauscore73 != ""){echo $gradehau73;}else{echo "-";} ?></td>
<td><?php echo $ffhauscore81;  ?></td>
<td><?php if($ffhauscore81 != ""){echo $gradehau81;}else{echo "-";} ?></td>
<td><?php echo $sshauscore82;  ?></td>
<td><?php if($sshauscore82 != ""){echo $gradehau82;}else{echo "-";} ?></td>
<td><?php echo $tthauscore83;  ?></td>
<td><?php if($tthauscore83 != ""){echo $gradehau83;}else{echo "-";} ?></td>
<td><?php echo $ffhauscore91;  ?></td>
<td><?php if($ffhauscore91 != ""){echo $gradehau91;}else{echo "-";} ?></td>
<td><?php echo $sshauscore92;  ?></td>
<td><?php if($sshauscore92 != ""){echo $gradehau92;}else{echo "-";} ?></td>
<td><?php echo $tthauscore93;  ?></td>
<td><?php if($tthauscore93 != ""){echo $gradehau93;}else{echo "-";} ?></td>
<td><?php echo $ffhauscore101;  ?></td>
<td><?php if($ffhauscore101 != ""){echo $gradehau101;}else{echo "-";} ?></td>
<td><?php echo $sshauscore102;  ?></td>
<td><?php if($sshauscore102 != ""){echo $gradehau102;}else{echo "-";} ?></td>
<td><?php echo $tthauscore103;  ?></td>
<td><?php if($tthauscore103 != ""){echo $gradehau103;}else{echo "-";} ?></td>
<td><?php echo $ffhauscore111;  ?></td>
<td><?php if($ffhauscore111 != ""){echo $gradehau111;}else{echo "-";} ?></td>
<td><?php echo $sshauscore112;  ?></td>
<td><?php if($sshauscore112 != ""){echo $gradehau112;}else{echo "-";} ?></td>
<td><?php echo $tthauscore113;  ?></td>
<td><?php if($tthauscore113 != ""){echo $gradehau113;}else{echo "-";} ?></td>
<td><?php echo $ffhauscore121;  ?></td>
<td><?php if($ffhauscore121 != ""){echo $gradehau121;}else{echo "-";} ?></td>
<td><?php echo $sshauscore122;  ?></td>
<td><?php if($sshauscore122 != ""){echo $gradehau122;}else{echo "-";} ?></td>
<td><?php echo $tthauscore123;  ?></td>
<td><?php if($tthauscore123 != ""){echo $gradehau123;}else{echo "-";} ?></td>
</tr>

<tr style="height: 13px;">
<td>ICT</td>
<?php
//include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 6'){
echo "";
}
else{
//YEAR 1 DATA FOR ICT
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 1'){
		$y = 'Year 1';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 6'){
		$y = 'Year 6';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='ICT' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeict71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeict71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeict71 = "P";}
								else if(($row["score"] <= 49)){$gradeict71 = "F";}
								else {$gradeict71 = "NA";}
						$fictscore71[] = $row['score'];						
						}
$ffictscore71 = current($fictscore71);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='ICT' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeict72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeict72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeict72 = "P";}
								else if(($row["score"] <= 49)){$gradeict72 = "F";}
								else {$gradeict72 = "NA";}
						$sictscore72[] = $row['score'];						
						}
$ssictscore72 = current($sictscore72);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='ICT' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeict73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeict73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeict73 = "P";}
								else if(($row["score"] <= 49)){$gradeict73 = "F";}
								else {$gradeict73 = "NA";}
						$tictscore73[] = $row['score'];						
						}
$ttictscore73 = current($tictscore73);
}
// YEAR 2 DATA FOR ICT
$class_name = $_POST['class_name'];
if(($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 1'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='ICT' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeict81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeict81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeict81 = "P";}
								else if(($row["score"] <= 49)){$gradeict81 = "F";}
								else {$gradeict81 = "NA";}
						$fictscore81[] = $row['score'];						
						}
$ffictscore81 = current($fictscore81);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='ICT' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeict82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeict82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeict82 = "P";}
								else if(($row["score"] <= 49)){$gradeict82 = "F";}
								else {$gradeict82 = "NA";}
						$sictscore82[] = $row['score'];						
						}
$ssictscore82 = current($sictscore82);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='ICT' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeict83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeict83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeict83 = "P";}
								else if(($row["score"] <= 49)){$gradeict83 = "F";}
								else {$gradeict83 = "NA";}
						$tictscore83[] = $row['score'];						
						}
$ttictscore83 = current($tictscore83);
}
// YEAR 3 DATA FOR ICT
$class_name = $_POST['class_name'];
if(($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 1'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='ICT' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeict91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeict91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeict91 = "P";}
								else if(($row["score"] <= 49)){$gradeict91 = "F";}
								else {$gradeict91 = "NA";}
						$fictscore91[] = $row['score'];						
						}
$ffictscore91 = current($fictscore91);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='ICT' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeict92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeict92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeict92 = "P";}
								else if(($row["score"] <= 49)){$gradeict92 = "F";}
								else {$gradeict92 = "NA";}
						$sictscore92[] = $row['score'];						
						}
$ssictscore92 = current($sictscore92);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='ICT' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeict93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeict93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeict93 = "P";}
								else if(($row["score"] <= 49)){$gradeict93 = "F";}
								else {$gradeict93 = "NA";}
						$tictscore93[] = $row['score'];						
						}
$ttictscore93 = current($tictscore93);	
}	

// YEAR 4 DATA FOR ICT
$class_name = $_POST['class_name'];
if(($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 1'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='ICT' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeict101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeict101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeict101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeict101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeict101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeict101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeict101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeict101 = "E8";}
								else if(($row["score"] <= 39)){$gradeict101 = "F9";}
								else {$gradeict101 = "NA";}
						$fictscore101[] = $row['score'];						
						}
$ffictscore101 = current($fictscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='ICT' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeict102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeict102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeict102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeict102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeict102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeict102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeict102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeict102 = "E8";}
								else if(($row["score"] <= 39)){$gradeict102 = "F9";}
								else {$gradeict102 = "NA";}
						$sictscore102[] = $row['score'];						
						}
$ssictscore102 = current($sictscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='ICT' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeict103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeict103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeict103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeict103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeict103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeict103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeict103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeict103 = "E8";}
								else if(($row["score"] <= 39)){$gradeict103 = "F9";}
								else {$gradeict103 = "NA";}
						$tictscore103[] = $row['score'];						
						}
$ttictscore103 = current($tictscore103);	
}

// YEAR 5 DATA FOR ICT
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 1'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='ICT' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeict111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeict111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeict111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeict111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeict111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeict111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeict111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeict111 = "E8";}
								else if(($row["score"] <= 39)){$gradeict111 = "F9";}
								else {$gradeict111 = "NA";}
						$fictscore111[] = $row['score'];						
						}
$ffictscore111 = current($fictscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='ICT' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$gradeict112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeict112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeict112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeict112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeict112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeict112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeict112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeict112 = "E8";}
								else if(($row["score"] <= 39)){$gradeict112 = "F9";}
								else {$gradeict112 = "NA";}
						$sictscore112[] = $row['score'];						
						}
$ssictscore112 = current($sictscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='ICT' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeict113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeict113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeict113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeict113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeict113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeict113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeict113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeict113 = "E8";}
								else if(($row["score"] <= 39)){$gradeict113 = "F9";}
								else {$gradeict113 = "NA";}
						$tictscore113[] = $row['score'];						
						}
$ttictscore113 = current($tictscore113);				
}

// YEAR 6 DATA FOR ICT
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 1'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 2'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='ICT' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeict121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeict121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeict121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeict121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeict121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeict121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeict121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeict121 = "E8";}
								else if(($row["score"] <= 39)){$gradeict121 = "F9";}
								else {$gradeict121 = "NA";}
						$fictscore121[] = $row['score'];						
						}
$ffictscore121 = current($fictscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='ICT' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeict122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeict122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeict122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeict122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeict122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeict122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeict122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeict122 = "E8";}
								else if(($row["score"] <= 39)){$gradeict122 = "F9";}
								else {$gradeict122 = "NA";}
						$sictscore122[] = $row['score'];						
						}
$ssictscore122 = current($sictscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='ICT' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeict123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeict123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeict123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeict123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeict123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeict123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeict123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeict123 = "E8";}
								else if(($row["score"] <= 39)){$gradeict123 = "F9";}
								else {$gradeict123 = "NA";}
						$tictscore123[] = $row['score'];						
						}
$ttictscore123 = current($tictscore123);		
}					
?>
<td><?php echo $ffictscore71;  ?></td>
<td><?php if($ffictscore71 != ""){echo $gradeict71;}else{echo "-";} ?></td>
<td><?php echo $ssictscore72;  ?></td>
<td><?php if($ssictscore72 != ""){echo $gradeict72;}else{echo "-";} ?></td>
<td><?php echo $ttictscore73;  ?></td>
<td><?php if($ttictscore73 != ""){echo $gradeict73;}else{echo "-";} ?></td>
<td><?php echo $ffictscore81;  ?></td>
<td><?php if($ffictscore81 != ""){echo $gradeict81;}else{echo "-";} ?></td>
<td><?php echo $ssictscore82;  ?></td>
<td><?php if($ssictscore82 != ""){echo $gradeict82;}else{echo "-";} ?></td>
<td><?php echo $ttictscore83;  ?></td>
<td><?php if($ttictscore83 != ""){echo $gradeict83;}else{echo "-";} ?></td>
<td><?php echo $ffictscore91;  ?></td>
<td><?php if($ffictscore91 != ""){echo $gradeict91;}else{echo "-";} ?></td>
<td><?php echo $ssictscore92;  ?></td>
<td><?php if($ssictscore92 != ""){echo $gradeict92;}else{echo "-";} ?></td>
<td><?php echo $ttictscore93;  ?></td>
<td><?php if($ttictscore93 != ""){echo $gradeict93;}else{echo "-";} ?></td>
<td><?php echo $ffictscore101;  ?></td>
<td><?php if($ffictscore101 != ""){echo $gradeict101;}else{echo "-";} ?></td>
<td><?php echo $ssictscore102;  ?></td>
<td><?php if($ssictscore102 != ""){echo $gradeict102;}else{echo "-";} ?></td>
<td><?php echo $ttictscore103;  ?></td>
<td><?php if($ttictscore103 != ""){echo $gradeict103;}else{echo "-";} ?></td>
<td><?php echo $ffictscore111;  ?></td>
<td><?php if($ffictscore111 != ""){echo $gradeict111;}else{echo "-";} ?></td>
<td><?php echo $ssictscore112;  ?></td>
<td><?php if($ssictscore112 != ""){echo $gradeict112;}else{echo "-";} ?></td>
<td><?php echo $ttictscore113;  ?></td>
<td><?php if($ttictscore113 != ""){echo $gradeict113;}else{echo "-";} ?></td>
<td><?php echo $ffictscore121;  ?></td>
<td><?php if($ffictscore121 != ""){echo $gradeict121;}else{echo "-";} ?></td>
<td><?php echo $ssictscore122;  ?></td>
<td><?php if($ssictscore122 != ""){echo $gradeict122;}else{echo "-";} ?></td>
<td><?php echo $ttictscore123;  ?></td>
<td><?php if($ttictscore123 != ""){echo $gradeict123;}else{echo "-";} ?></td>
</tr>

<tr style="height: 13px;">
<td>IGBO</td>
<?php
//include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 6'){
echo "";
}
else{
//YEAR 1 DATA FOR IGBO
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 1'){
		$y = 'Year 1';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 6'){
		$y = 'Year 6';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='Igbo' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeigb71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeigb71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeigb71 = "P";}
								else if(($row["score"] <= 49)){$gradeigb71 = "F";}
								else {$gradeigb71 = "NA";}
						$figbscore71[] = $row['score'];						
						}
$ffigbscore71 = current($figbscore71);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='Igbo' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeigb72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeigb72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeigb72 = "P";}
								else if(($row["score"] <= 49)){$gradeigb72 = "F";}
								else {$gradeigb72 = "NA";}
						$sigbscore72[] = $row['score'];						
						}
$ssigbscore72 = current($sigbscore72);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='Igbo' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeigb73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeigb73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeigb73 = "P";}
								else if(($row["score"] <= 49)){$gradeigb73 = "F";}
								else {$gradeigb73 = "NA";}
						$tigbscore73[] = $row['score'];						
						}
$ttigbscore73 = current($tigbscore73);
}
// YEAR 2 DATA FOR IGBO
$class_name = $_POST['class_name'];
if(($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 1'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Igbo' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeigb81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeigb81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeigb81 = "P";}
								else if(($row["score"] <= 49)){$gradeigb81 = "F";}
								else {$gradeigb81 = "NA";}
						$figbscore81[] = $row['score'];						
						}
$ffigbscore81 = current($figbscore81);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Igbo' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeigb82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeigb82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeigb82 = "P";}
								else if(($row["score"] <= 49)){$gradeigb82 = "F";}
								else {$gradeigb82 = "NA";}
						$sigbscore82[] = $row['score'];						
						}
$ssigbscore82 = current($sigbscore82);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Igbo' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeigb83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeigb83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeigb83 = "P";}
								else if(($row["score"] <= 49)){$gradeigb83 = "F";}
								else {$gradeigb83 = "NA";}
						$tigbscore83[] = $row['score'];						
						}
$ttigbscore83 = current($tigbscore83);
}
// YEAR 3 DATA FOR IGBO
$class_name = $_POST['class_name'];
if(($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 1'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Igbo' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeigb91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeigb91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeigb91 = "P";}
								else if(($row["score"] <= 49)){$gradeigb91 = "F";}
								else {$gradeigb91 = "NA";}
						$figbscore91[] = $row['score'];						
						}
$ffigbscore91 = current($figbscore91);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Igbo' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeigb92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeigb92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeigb92 = "P";}
								else if(($row["score"] <= 49)){$gradeigb92 = "F";}
								else {$gradeigb92 = "NA";}
						$sigbscore92[] = $row['score'];						
						}
$ssigbscore92 = current($sigbscore92);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Igbo' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeigb93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeigb93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeigb93 = "P";}
								else if(($row["score"] <= 49)){$gradeigb93 = "F";}
								else {$gradeigb93 = "NA";}
						$tigbscore93[] = $row['score'];						
						}
$ttigbscore93 = current($tigbscore93);
}	

// YEAR 4 DATA FOR IGBO
$class_name = $_POST['class_name'];
if(($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 1'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Igbo' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeigb101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeigb101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeigb101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeigb101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeigb101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeigb101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeigb101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeigb101 = "E8";}
								else if(($row["score"] <= 39)){$gradeigb101 = "F9";}
								else {$gradeigb101 = "NA";}
						$figbscore101[] = $row['score'];						
						}
$ffigbscore101 = current($figbscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Igbo' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeigb102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeigb102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeigb102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeigb102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeigb102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeigb102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeigb102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeigb102 = "E8";}
								else if(($row["score"] <= 39)){$gradeigb102 = "F9";}
								else {$gradeigb102 = "NA";}
						$sigbscore102[] = $row['score'];						
						}
$ssigbscore102 = current($sigbscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Igbo' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeigb103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeigb103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeigb103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeigb103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeigb103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeigb103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeigb103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeigb103 = "E8";}
								else if(($row["score"] <= 39)){$gradeigb103 = "F9";}
								else {$gradeigb103 = "NA";}
						$tigbscore103[] = $row['score'];						
						}
$ttigbscore103 = current($tigbscore103);	
}

// YEAR 5 DATA FOR IGBO
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 1'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Igbo' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeigb111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeigb111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeigb111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeigb111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeigb111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeigb111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeigb111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeigb111 = "E8";}
								else if(($row["score"] <= 39)){$gradeigb111 = "F9";}
								else {$gradeigb111 = "NA";}
						$figbscore111[] = $row['score'];						
						}
$ffigbscore111 = current($figbscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Igbo' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$gradeigb112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeigb112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeigb112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeigb112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeigb112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeigb112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeigb112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeigb112 = "E8";}
								else if(($row["score"] <= 39)){$gradeigb112 = "F9";}
								else {$gradeigb112 = "NA";}
						$sigbscore112[] = $row['score'];						
						}
$ssigbscore112 = current($sigbscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Igbo' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeigb113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeigb113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeigb113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeigb113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeigb113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeigb113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeigb113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeigb113 = "E8";}
								else if(($row["score"] <= 39)){$gradeigb113 = "F9";}
								else {$gradeigb113 = "NA";}
						$tigbscore113[] = $row['score'];						
						}
$ttigbscore113 = current($tigbscore113);				
}

// YEAR 6 DATA FOR IGBO
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 1'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 2'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Igbo' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeigb121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeigb121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeigb121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeigb121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeigb121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeigb121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeigb121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeigb121 = "E8";}
								else if(($row["score"] <= 39)){$gradeigb121 = "F9";}
								else {$gradeigb121 = "NA";}
						$figbscore121[] = $row['score'];						
						}
$ffigbscore121 = current($figbscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Igbo' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeigb122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeigb122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeigb122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeigb122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeigb122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeigb122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeigb122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeigb122 = "E8";}
								else if(($row["score"] <= 39)){$gradeigb122 = "F9";}
								else {$gradeigb122 = "NA";}
						$sigbscore122[] = $row['score'];						
						}
$ssigbscore122 = current($sigbscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Igbo' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeigb123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeigb123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeigb123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeigb123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeigb123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeigb123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeigb123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeigb123 = "E8";}
								else if(($row["score"] <= 39)){$gradeigb123 = "F9";}
								else {$gradeigb123 = "NA";}
						$tigbscore123[] = $row['score'];						
						}
$ttigbscore123 = current($tigbscore123);
}					
?>
<td><?php echo $ffigbscore71;  ?></td>
<td><?php if($ffigbscore71 != ""){echo $gradeigb71;}else{echo "-";} ?></td>
<td><?php echo $ssigbscore72;  ?></td>
<td><?php if($ssigbscore72 != ""){echo $gradeigb72;}else{echo "-";} ?></td>
<td><?php echo $ttigbscore73;  ?></td>
<td><?php if($ttigbscore73 != ""){echo $gradeigb73;}else{echo "-";} ?></td>
<td><?php echo $ffigbscore81;  ?></td>
<td><?php if($ffigbscore81 != ""){echo $gradeigb81;}else{echo "-";} ?></td>
<td><?php echo $ssigbscore82;  ?></td>
<td><?php if($ssigbscore82 != ""){echo $gradeigb82;}else{echo "-";} ?></td>
<td><?php echo $ttigbscore83;  ?></td>
<td><?php if($ttigbscore83 != ""){echo $gradeigb83;}else{echo "-";} ?></td>
<td><?php echo $ffigbscore91;  ?></td>
<td><?php if($ffigbscore91 != ""){echo $gradeigb91;}else{echo "-";} ?></td>
<td><?php echo $ssigbscore92;  ?></td>
<td><?php if($ssigbscore92 != ""){echo $gradeigb92;}else{echo "-";} ?></td>
<td><?php echo $ttigbscore93;  ?></td>
<td><?php if($ttigbscore93 != ""){echo $gradeigb93;}else{echo "-";} ?></td>
<td><?php echo $ffigbscore101;  ?></td>
<td><?php if($ffigbscore101 != ""){echo $gradeigb101;}else{echo "-";} ?></td>
<td><?php echo $ssigbscore102;  ?></td>
<td><?php if($ssigbscore102 != ""){echo $gradeigb102;}else{echo "-";} ?></td>
<td><?php echo $ttigbscore103;  ?></td>
<td><?php if($ttigbscore103 != ""){echo $gradeigb103;}else{echo "-";} ?></td>
<td><?php echo $ffigbscore111;  ?></td>
<td><?php if($ffigbscore111 != ""){echo $gradeigb111;}else{echo "-";} ?></td>
<td><?php echo $ssigbscore112;  ?></td>
<td><?php if($ssigbscore112 != ""){echo $gradeigb112;}else{echo "-";} ?></td>
<td><?php echo $ttigbscore113;  ?></td>
<td><?php if($ttigbscore113 != ""){echo $gradeigb113;}else{echo "-";} ?></td>
<td><?php echo $ffigbscore121;  ?></td>
<td><?php if($ffigbscore121 != ""){echo $gradeigb121;}else{echo "-";} ?></td>
<td><?php echo $ssigbscore122;  ?></td>
<td><?php if($ssigbscore122 != ""){echo $gradeigb122;}else{echo "-";} ?></td>
<td><?php echo $ttigbscore123;  ?></td>
<td><?php if($ttigbscore123 != ""){echo $gradeigb123;}else{echo "-";} ?></td>
</tr>


<tr style="height: 13px;">
<td>ISLAMIC REL. STUDIES</td>
<?php
//include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 6'){
echo "";
}
else{
//YEAR 1 DATA FOR ISLAMIC RELIGIOUS STUDIES
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 1'){
		$y = 'Year 1';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 6'){
		$y = 'Year 6';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='Islamic Religious Studies' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeirs71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeirs71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeirs71 = "P";}
								else if(($row["score"] <= 49)){$gradeirs71 = "F";}
								else {$gradeirs71 = "NA";}
						$firsscore71[] = $row['score'];	
						}
$ffirssc71 = current($firsscore71);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='Islamic Religious Studies' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeirs72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeirs72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeirs72 = "P";}
								else if(($row["score"] <= 49)){$gradeirs72 = "F";}
								else {$gradeirs72 = "NA";}
						$sirsscore72[] = $row['score'];	
						}
$ssirssc72 = current($sirsscore72);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='Islamic Religious Studies' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeirs73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeirs73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeirs73 = "P";}
								else if(($row["score"] <= 49)){$gradeirs73 = "F";}
								else {$gradeirs73 = "NA";}
						$tirsscore73[] = $row['score'];	
						}
$ttirssc73 = current($tirsscore73);	
}
// YEAR 2 DATA FOR ISLAMIC RELIGIOUS STUDIES.
$class_name = $_POST['class_name'];
if(($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 1'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Islamic Religious Studies' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeirs81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeirs81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeirs81 = "P";}
								else if(($row["score"] <= 49)){$gradeirs81 = "F";}
								else {$gradeirs81 = "NA";}
						$firsscore81[] = $row['score'];	
						}
$ffirssc81 = current($firsscore81);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Islamic Religious Studies' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeirs82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeirs82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeirs82 = "P";}
								else if(($row["score"] <= 49)){$gradeirs82 = "F";}
								else {$gradeirs82 = "NA";}
						$sirsscore82[] = $row['score'];	
						}
$ssirssc82 = current($sirsscore82);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Islamic Religious Studies' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeirs83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeirs83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeirs83 = "P";}
								else if(($row["score"] <= 49)){$gradeirs83 = "F";}
								else {$gradeirs83 = "NA";}
						$tirsscore83[] = $row['score'];	
						}
$ttirssc83 = current($tirsscore83);	
}
// YEAR 3 DATA FOR ISLAMIC RELIGIOUS STUDIES
$class_name = $_POST['class_name'];
if(($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 1'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Islamic Religious Studies' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeirs91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeirs91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeirs91 = "P";}
								else if(($row["score"] <= 49)){$gradeirs91 = "F";}
								else {$gradeirs91 = "NA";}
						$firsscore91[] = $row['score'];	
						}
$ffirssc91 = current($firsscore91);		

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Islamic Religious Studies' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeirs92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeirs92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeirs92 = "P";}
								else if(($row["score"] <= 49)){$gradeirs92 = "F";}
								else {$gradeirs92 = "NA";}
						$sirsscore92[] = $row['score'];	
						}
$ssirssc92 = current($sirsscore92);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Islamic Religious Studies' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeirs93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeirs93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeirs93 = "P";}
								else if(($row["score"] <= 49)){$gradeirs93 = "F";}
								else {$gradeirs93 = "NA";}
						$tirsscore93[] = $row['score'];	
						}
$ttirssc93 = current($tirsscore93);		
}	
// YEAR 4 DATA FOR ISLAMIC RELIGIOUS STUDIES
$class_name = $_POST['class_name'];
if(($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 1'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Islamic Religious Studies' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradeirs101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeirs101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeirs101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeirs101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeirs101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeirs101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeirs101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeirs101 = "E8";}
								else if(($row["score"] <= 39)){$gradeirs101 = "F9";}
								else {$gradeirs101 = "NA";}
						$firsscore101[] = $row['score'];		
						}
$ffirssc101 = current($firsscore101);		

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Islamic Religious Studies' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeirs102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeirs102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeirs102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeirs102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeirs102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeirs102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeirs102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeirs102 = "E8";}
								else if(($row["score"] <= 39)){$gradeirs102 = "F9";}
								else {$gradeirs102 = "NA";}
						$firsscore102[] = $row['score'];
						}
$ssirssc102 = current($sirsscore102);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Islamic Religious Studies' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradeirs103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeirs103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeirs103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeirs103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeirs103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeirs103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeirs103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeirs103 = "E8";}
								else if(($row["score"] <= 39)){$gradeirs103 = "F9";}
								else {$gradeirs103 = "NA";}
						$firsscore103[] = $row['score'];	
						}
$ttirssc103 = current($tirsscore103);		
}
// YEAR 5 DATA FOR ISLAMIC RELIGIOUS STUDIES
$class_name = $_POST['class_name'];
if(($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 1'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Islamic Religious Studies' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradeirs111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeirs111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeirs111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeirs111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeirs111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeirs111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeirs111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeirs111 = "E8";}
								else if(($row["score"] <= 39)){$gradeirs111 = "F9";}
								else {$gradeirs111 = "NA";}
						$firsscore111[] = $row['score'];		
						}
$ffirssc111 = current($firsscore111);		

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Islamic Religious Studies' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeirs112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeirs112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeirs112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeirs112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeirs112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeirs112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeirs112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeirs112 = "E8";}
								else if(($row["score"] <= 39)){$gradeirs112 = "F9";}
								else {$gradeirs112 = "NA";}
						$firsscore112[] = $row['score'];
						}
$ssirssc112 = current($sirsscore112);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Islamic Religious Studies' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradeirs113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeirs113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeirs113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeirs113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeirs113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeirs113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeirs113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeirs113 = "E8";}
								else if(($row["score"] <= 39)){$gradeirs113 = "F9";}
								else {$gradeirs113 = "NA";}
						$firsscore113[] = $row['score'];	
						}
$ttirssc113 = current($tirsscore113);		
}
// YEAR 6 DATA FOR ISLAMIC RELIGIOUS STUDIES
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 1'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 2'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Islamic Religious Studies' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
							if($row["score"] >= 80){$gradeirs121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeirs121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeirs121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeirs121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeirs121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeirs121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeirs121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeirs121 = "E8";}
								else if(($row["score"] <= 39)){$gradeirs121 = "F9";}
								else {$gradeirs121 = "NA";}
						$firsscore121[] = $row['score'];	
						}
$ffirssc121 = current($firsscore121);		

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Islamic Religious Studies' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradeirs122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeirs122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeirs122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeirs122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeirs122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeirs122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeirs122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeirs122 = "E8";}
								else if(($row["score"] <= 39)){$gradeirs122 = "F9";}
								else {$gradeirs122 = "NA";}
						$firsscore122[] = $row['score'];
						}
$ssirssc122 = current($sirsscore122);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Islamic Religious Studies' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradeirs123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeirs123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeirs123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeirs123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeirs123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeirs123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeirs123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeirs123 = "E8";}
								else if(($row["score"] <= 39)){$gradeirs123 = "F9";}
								else {$gradeirs123 = "NA";}
						$firsscore123[] = $row['score'];	
						}
$ttirssc123 = current($tirsscore123);		
}		
?>
<td><?php echo $ffirssc71;  ?></td>
<td><?php if($ffirssc71 != ""){echo $gradeirs71;}else{echo "-";} ?></td>
<td><?php echo $ssirssc72;  ?></td>
<td><?php if($ssirssc72 != ""){echo $gradeirs72;}else{echo "-";} ?></td>
<td><?php echo $ttirssc73;  ?></td>
<td><?php if($ttirssc73 != ""){echo $gradeirs73;}else{echo "-";} ?></td>
<td><?php echo $ffirssc81;  ?></td>
<td><?php if($ffirssc81 != ""){echo $gradeirs81;}else{echo "-";} ?></td>
<td><?php echo $ssirssc82;  ?></td>
<td><?php if($ssirssc82 != ""){echo $gradeirs82;}else{echo "-";} ?></td>
<td><?php echo $ttirssc83;  ?></td>
<td><?php if($ttirssc83 != ""){echo $gradeirs83;}else{echo "-";} ?></td>
<td><?php echo $ffirssc91;  ?></td>
<td><?php if($ffirssc91 != ""){echo $gradeirs91;}else{echo "-";} ?></td>
<td><?php echo $ssirssc92;  ?></td>
<td><?php if($ssirssc92 != ""){echo $gradeirs92;}else{echo "-";} ?></td>
<td><?php echo $ttirssc93;  ?></td>
<td><?php if($ttirssc93 != ""){echo $gradeirs93;}else{echo "-";} ?></td>
<td><?php echo $ffirssc101;  ?></td>
<td><?php if($ffirssc101 != ""){echo $gradeirs101;}else{echo "-";} ?></td>
<td><?php echo $ssirssc102;  ?></td>
<td><?php if($ssirssc102 != ""){echo $gradeirs102;}else{echo "-";} ?></td>
<td><?php echo $ttirssc103;  ?></td>
<td><?php if($ttirssc103 != ""){echo $gradeirs103;}else{echo "-";} ?></td>
<td><?php echo $ffirssc111;  ?></td>
<td><?php if($ffirssc111 != ""){echo $gradeirs111;}else{echo "-";} ?></td>
<td><?php echo $ssirssc112;  ?></td>
<td><?php if($ssirssc112 != ""){echo $gradeirs112;}else{echo "-";} ?></td>
<td><?php echo $ttirssc113;  ?></td>
<td><?php if($ttirssc113 != ""){echo $gradeirs113;}else{echo "-";} ?></td>
<td><?php echo $ffirssc121;  ?></td>
<td><?php if($ffirssc121 != ""){echo $gradeirs121;}else{echo "-";} ?></td>
<td><?php echo $ssirssc122;  ?></td>
<td><?php if($ssirssc122 != ""){echo $gradeirs122;}else{echo "-";} ?></td>
<td><?php echo $ttirssc123;  ?></td>
<td><?php if($ttirssc123 != ""){echo $gradeirs123;}else{echo "-";} ?></td>
</tr>






<tr style="height: 13px;">
<td>MUSIC</td>
<?php
//include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 6'){
echo "";
}
else{
//YEAR 1 DATA FOR MUSIC
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 1'){
		$y = 'Year 1';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 6'){
		$y = 'Year 6';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='Music' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademus71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademus71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademus71 = "P";}
								else if(($row["score"] <= 49)){$grademus71 = "F";}
								else {$grademus71 = "NA";}
						$fmusscore71[] = $row['score'];						
						}
$ffmusscore71 = current($fmusscore71);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='Music' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademus72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademus72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademus72 = "P";}
								else if(($row["score"] <= 49)){$grademus72 = "F";}
								else {$grademus72 = "NA";}
						$smusscore72[] = $row['score'];						
						}
$ssmusscore72 = current($smusscore72);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='Music' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademus73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademus73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademus73 = "P";}
								else if(($row["score"] <= 49)){$grademus73 = "F";}
								else {$grademus73 = "NA";}
						$tmusscore73[] = $row['score'];						
						}
$ttmusscore73 = current($tmusscore73);
}
// YEAR 2 DATA FOR MUSIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 1'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Music' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademus81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademus81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademus81 = "P";}
								else if(($row["score"] <= 49)){$grademus81 = "F";}
								else {$grademus81 = "NA";}
						$fmusscore81[] = $row['score'];						
						}
$ffmusscore81 = current($fmusscore81);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Music' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademus82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademus82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademus82 = "P";}
								else if(($row["score"] <= 49)){$grademus82 = "F";}
								else {$grademus82 = "NA";}
						$smusscore82[] = $row['score'];						
						}
$ssmusscore82 = current($smusscore82);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Music' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademus83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademus83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademus83 = "P";}
								else if(($row["score"] <= 49)){$grademus83 = "F";}
								else {$grademus83 = "NA";}
						$tmusscore83[] = $row['score'];						
						}
$ttmusscore83 = current($tmusscore83);
}
// YEAR 3 DATA FOR MUSIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 1'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Music' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademus91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademus91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademus91 = "P";}
								else if(($row["score"] <= 49)){$grademus91 = "F";}
								else {$grademus91 = "NA";}
						$fmusscore91[] = $row['score'];						
						}
$ffmusscore91 = current($fmusscore91);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Music' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademus92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademus92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademus92 = "P";}
								else if(($row["score"] <= 49)){$grademus92 = "F";}
								else {$grademus92 = "NA";}
						$smusscore92[] = $row['score'];						
						}
$ssmusscore92 = current($smusscore92);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Music' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grademus93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grademus93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grademus93 = "P";}
								else if(($row["score"] <= 49)){$grademus93 = "F";}
								else {$grademus93 = "NA";}
						$tmusscore93[] = $row['score'];						
						}
$ttmusscore93 = current($tmusscore93);
}	

// YEAR 4 DATA FOR MUSIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 1'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Music' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$grademus101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademus101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademus101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademus101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademus101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademus101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademus101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademus101 = "E8";}
								else if(($row["score"] <= 39)){$grademus101 = "F9";}
								else {$grademus101 = "NA";}
						$fmusscore101[] = $row['score'];						
						}
$ffmusscore101 = current($fmusscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Music' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$grademus102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademus102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademus102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademus102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademus102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademus102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademus102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademus102 = "E8";}
								else if(($row["score"] <= 39)){$grademus102 = "F9";}
								else {$grademus102 = "NA";}
						$smusscore102[] = $row['score'];						
						}
$ssmusscore102 = current($smusscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Music' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$grademus103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademus103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademus103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademus103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademus103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademus103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademus103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademus103 = "E8";}
								else if(($row["score"] <= 39)){$grademus103 = "F9";}
								else {$grademus103 = "NA";}
						$tmusscore103[] = $row['score'];						
						}
$ttmusscore103 = current($tmusscore103);	
}

// YEAR 5 DATA FOR MUSIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 1'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Music' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$grademus111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademus111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademus111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademus111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademus111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademus111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademus111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademus111 = "E8";}
								else if(($row["score"] <= 39)){$grademus111 = "F9";}
								else {$grademus111 = "NA";}
						$fmusscore111[] = $row['score'];						
						}
$ffmusscore111 = current($fmusscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Music' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$grademus112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademus112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademus112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademus112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademus112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademus112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademus112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademus112 = "E8";}
								else if(($row["score"] <= 39)){$grademus112 = "F9";}
								else {$grademus112 = "NA";}
						$smusscore112[] = $row['score'];						
						}
$ssmusscore112 = current($smusscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Music' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$grademus113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademus113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademus113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademus113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademus113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademus113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademus113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademus113 = "E8";}
								else if(($row["score"] <= 39)){$grademus113 = "F9";}
								else {$grademus113 = "NA";}
						$tmusscore113[] = $row['score'];						
						}
$ttmusscore113 = current($tmusscore113);			
}

// YEAR 12 DATA FOR MUSIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 1'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 2'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Music' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$grademus121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademus121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademus121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademus121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademus121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademus121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademus121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademus121 = "E8";}
								else if(($row["score"] <= 39)){$grademus121 = "F9";}
								else {$grademus121 = "NA";}
						$fmusscore121[] = $row['score'];						
						}
$ffmusscore121 = current($fmusscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Music' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$grademus122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademus122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademus122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademus122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademus122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademus122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademus122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademus122 = "E8";}
								else if(($row["score"] <= 39)){$grademus122 = "F9";}
								else {$grademus122 = "NA";}
						$smusscore122[] = $row['score'];						
						}
$ssmusscore122 = current($smusscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Music' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$grademus123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grademus123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grademus123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grademus123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grademus123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grademus123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grademus123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grademus123 = "E8";}
								else if(($row["score"] <= 39)){$grademus123 = "F9";}
								else {$grademus123 = "NA";}
						$tmusscore123[] = $row['score'];						
						}
$ttmusscore123 = current($tmusscore123);
}					
?>
<td><?php echo $ffmusscore71;  ?></td>
<td><?php if($ffmusscore71 != ""){echo $grademus71;}else{echo "-";} ?></td>
<td><?php echo $ssmusscore72;  ?></td>
<td><?php if($ssmusscore72 != ""){echo $grademus72;}else{echo "-";} ?></td>
<td><?php echo $ttmusscore73;  ?></td>
<td><?php if($ttmusscore73 != ""){echo $grademus73;}else{echo "-";} ?></td>
<td><?php echo $ffmusscore81;  ?></td>
<td><?php if($ffmusscore81 != ""){echo $grademus81;}else{echo "-";} ?></td>
<td><?php echo $ssmusscore82;  ?></td>
<td><?php if($ssmusscore82 != ""){echo $grademus82;}else{echo "-";} ?></td>
<td><?php echo $ttmusscore83;  ?></td>
<td><?php if($ttmusscore83 != ""){echo $grademus83;}else{echo "-";} ?></td>
<td><?php echo $ffmusscore91;  ?></td>
<td><?php if($ffmusscore91 != ""){echo $grademus91;}else{echo "-";} ?></td>
<td><?php echo $ssmusscore92;  ?></td>
<td><?php if($ssmusscore92 != ""){echo $grademus92;}else{echo "-";} ?></td>
<td><?php echo $ttmusscore93;  ?></td>
<td><?php if($ttmusscore93 != ""){echo $grademus93;}else{echo "-";} ?></td>
<td><?php echo $ffmusscore101;  ?></td>
<td><?php if($ffmusscore101 != ""){echo $grademus101;}else{echo "-";} ?></td>
<td><?php echo $ssmusscore102;  ?></td>
<td><?php if($ssmusscore102 != ""){echo $grademus102;}else{echo "-";} ?></td>
<td><?php echo $ttmusscore103;  ?></td>
<td><?php if($ttmusscore103 != ""){echo $grademus103;}else{echo "-";} ?></td>
<td><?php echo $ffmusscore111;  ?></td>
<td><?php if($ffmusscore111 != ""){echo $grademus111;}else{echo "-";} ?></td>
<td><?php echo $ssmusscore112;  ?></td>
<td><?php if($ssmusscore112 != ""){echo $grademus112;}else{echo "-";} ?></td>
<td><?php echo $ttmusscore113;  ?></td>
<td><?php if($ttmusscore113 != ""){echo $grademus113;}else{echo "-";} ?></td>
<td><?php echo $ffmusscore121;  ?></td>
<td><?php if($ffmusscore121 != ""){echo $grademus121;}else{echo "-";} ?></td>
<td><?php echo $ssmusscore122;  ?></td>
<td><?php if($ssmusscore122 != ""){echo $grademus122;}else{echo "-";} ?></td>
<td><?php echo $ttmusscore123;  ?></td>
<td><?php if($ttmusscore123 != ""){echo $grademus123;}else{echo "-";} ?></td>
</tr>





<tr style="height: 13px;">
<td>PHE</td>
<?php
//include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 6'){
echo "";
}
else{
//YEAR 1 DATA FOR PHE
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 1'){
		$y = 'Year 1';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 6'){
		$y = 'Year 6';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='PHE' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradephe71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradephe71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradephe71 = "P";}
								else if(($row["score"] <= 49)){$gradephe71 = "F";}
								else {$gradephe71 = "NA";}
						$fphescore71[] = $row['score'];						
						}
$ffphescore71 = current($fphescore71);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='PHE' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradephe72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradephe72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradephe72 = "P";}
								else if(($row["score"] <= 49)){$gradephe72 = "F";}
								else {$gradephe72 = "NA";}
						$sphescore72[] = $row['score'];						
						}
$ssphescore72 = current($sphescore72);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='PHE' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradephe73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradephe73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradephe73 = "P";}
								else if(($row["score"] <= 49)){$gradephe73 = "F";}
								else {$gradephe73 = "NA";}
						$tphescore73[] = $row['score'];						
						}
$ttphescore73 = current($tphescore73);
}
// YEAR 2 DATA FOR PHE
$class_name = $_POST['class_name'];
if(($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 1'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='PHE' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradephe81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradephe81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradephe81 = "P";}
								else if(($row["score"] <= 49)){$gradephe81 = "F";}
								else {$gradephe81 = "NA";}
						$fphescore81[] = $row['score'];						
						}
$ffphescore81 = current($fphescore81);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='PHE' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradephe82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradephe82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradephe82 = "P";}
								else if(($row["score"] <= 49)){$gradephe82 = "F";}
								else {$gradephe82 = "NA";}
						$sphescore82[] = $row['score'];						
						}
$ssphescore82 = current($sphescore82);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='PHE' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradephe83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradephe83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradephe83 = "P";}
								else if(($row["score"] <= 49)){$gradephe83 = "F";}
								else {$gradephe83 = "NA";}
						$tphescore83[] = $row['score'];						
						}
$ttphescore83 = current($tphescore83);
}
// YEAR 3 DATA FOR PHE
$class_name = $_POST['class_name'];
if(($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 1'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='PHE' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradephe91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradephe91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradephe91 = "P";}
								else if(($row["score"] <= 49)){$gradephe91 = "F";}
								else {$gradephe91 = "NA";}
						$fphescore91[] = $row['score'];						
						}
$ffphescore91 = current($fphescore91);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='PHE' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradephe92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradephe92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradephe92 = "P";}
								else if(($row["score"] <= 49)){$gradephe92 = "F";}
								else {$gradephe92 = "NA";}
						$sphescore92[] = $row['score'];						
						}
$ssphescore92 = current($sphescore92);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='PHE' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradephe93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradephe93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradephe93 = "P";}
								else if(($row["score"] <= 49)){$gradephe93 = "F";}
								else {$gradephe93 = "NA";}
						$tphescore93[] = $row['score'];						
						}
$ttphescore93 = current($tphescore93);
}	

// YEAR 4 DATA FOR PHE
$class_name = $_POST['class_name'];
if(($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 1'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='PHE' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradephe101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradephe101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradephe101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradephe101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradephe101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradephe101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradephe101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradephe101 = "E8";}
								else if(($row["score"] <= 39)){$gradephe101 = "F9";}
								else {$gradephe101 = "NA";}
						$fphescore101[] = $row['score'];						
						}
$ffphescore101 = current($fphescore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='PHE' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradephe102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradephe102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradephe102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradephe102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradephe102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradephe102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradephe102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradephe102 = "E8";}
								else if(($row["score"] <= 39)){$gradephe102 = "F9";}
								else {$gradephe102 = "NA";}
						$sphescore102[] = $row['score'];						
						}
$ssphescore102 = current($sphescore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='PHE' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradephe103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradephe103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradephe103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradephe103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradephe103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradephe103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradephe103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradephe103 = "E8";}
								else if(($row["score"] <= 39)){$gradephe103 = "F9";}
								else {$gradephe103 = "NA";}
						$tphescore103[] = $row['score'];						
						}
$ttphescore103 = current($tphescore103);
}

// YEAR 5 DATA FOR PHE
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 1'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='PHE' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradephe111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradephe111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradephe111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradephe111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradephe111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradephe111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradephe111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradephe111 = "E8";}
								else if(($row["score"] <= 39)){$gradephe111 = "F9";}
								else {$gradephe111 = "NA";}
						$fphescore111[] = $row['score'];						
						}
$ffphescore111 = current($fphescore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='PHE' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradephe112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradephe112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradephe112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradephe112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradephe112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradephe112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradephe112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradephe112 = "E8";}
								else if(($row["score"] <= 39)){$gradephe112 = "F9";}
								else {$gradephe112 = "NA";}
						$sphescore112[] = $row['score'];						
						}
$ssphescore112 = current($sphescore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='PHE' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$gradephe113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradephe113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradephe113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradephe113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradephe113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradephe113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradephe113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradephe113 = "E8";}
								else if(($row["score"] <= 39)){$gradephe113 = "F9";}
								else {$gradephe113 = "NA";}
						$tphescore113[] = $row['score'];						
						}
$ttphescore113 = current($tphescore113);			
}

// YEAR 6 DATA FOR PHE
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 1'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 2'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='PHE' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradephe121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradephe121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradephe121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradephe121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradephe121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradephe121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradephe121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradephe121 = "E8";}
								else if(($row["score"] <= 39)){$gradephe121 = "F9";}
								else {$gradephe121 = "NA";}
						$fphescore121[] = $row['score'];						
						}
$ffphescore121 = current($fphescore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='PHE' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradephe122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradephe122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradephe122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradephe122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradephe122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradephe122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradephe122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradephe122 = "E8";}
								else if(($row["score"] <= 39)){$gradephe122 = "F9";}
								else {$gradephe122 = "NA";}
						$sphescore122[] = $row['score'];						
						}
$ssphescore122 = current($sphescore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='PHE' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradephe123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradephe123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradephe123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradephe123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradephe123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradephe123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradephe123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradephe123 = "E8";}
								else if(($row["score"] <= 39)){$gradephe123 = "F9";}
								else {$gradephe123 = "NA";}
						$tphescore123[] = $row['score'];						
						}
$ttphescore123 = current($tphescore123);
}					
?>
<td><?php echo $ffphescore71;  ?></td>
<td><?php if($ffphescore71 != ""){echo $gradephe71;}else{echo "-";} ?></td>
<td><?php echo $ssphescore72;  ?></td>
<td><?php if($ssphescore72 != ""){echo $gradephe72;}else{echo "-";} ?></td>
<td><?php echo $ttphescore73;  ?></td>
<td><?php if($ttphescore73 != ""){echo $gradephe73;}else{echo "-";} ?></td>
<td><?php echo $ffphescore81;  ?></td>
<td><?php if($ffphescore81 != ""){echo $gradephe81;}else{echo "-";} ?></td>
<td><?php echo $ssphescore82;  ?></td>
<td><?php if($ssphescore82 != ""){echo $gradephe82;}else{echo "-";} ?></td>
<td><?php echo $ttphescore83;  ?></td>
<td><?php if($ttphescore83 != ""){echo $gradephe83;}else{echo "-";} ?></td>
<td><?php echo $ffphescore91;  ?></td>
<td><?php if($ffphescore91 != ""){echo $gradephe91;}else{echo "-";} ?></td>
<td><?php echo $ssphescore92;  ?></td>
<td><?php if($ssphescore92 != ""){echo $gradephe92;}else{echo "-";} ?></td>
<td><?php echo $ttphescore93;  ?></td>
<td><?php if($ttphescore93 != ""){echo $gradephe93;}else{echo "-";} ?></td>
<td><?php echo $ffphescore101;  ?></td>
<td><?php if($ffphescore101 != ""){echo $gradephe101;}else{echo "-";} ?></td>
<td><?php echo $ssphescore102;  ?></td>
<td><?php if($ssphescore102 != ""){echo $gradephe102;}else{echo "-";} ?></td>
<td><?php echo $ttphescore103;  ?></td>
<td><?php if($ttphescore103 != ""){echo $gradephe103;}else{echo "-";} ?></td>
<td><?php echo $ffphescore111;  ?></td>
<td><?php if($ffphescore111 != ""){echo $gradephe111;}else{echo "-";} ?></td>
<td><?php echo $ssphescore112;  ?></td>
<td><?php if($ssphescore112 != ""){echo $gradephe112;}else{echo "-";} ?></td>
<td><?php echo $ttphescore113;  ?></td>
<td><?php if($ttphescore113 != ""){echo $gradephe113;}else{echo "-";} ?></td>
<td><?php echo $ffphescore121;  ?></td>
<td><?php if($ffphescore121 != ""){echo $gradephe121;}else{echo "-";} ?></td>
<td><?php echo $ssphescore122;  ?></td>
<td><?php if($ssphescore122 != ""){echo $gradephe122;}else{echo "-";} ?></td>
<td><?php echo $ttphescore123;  ?></td>
<td><?php if($ttphescore123 != ""){echo $gradephe123;}else{echo "-";} ?></td>
</tr>


<tr style="height: 13px;">
<td>PHONICS</td>
<?php
//include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 6'){
echo "";
}
else{
//YEAR 1 DATA FOR PHONICS
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 1'){
		$y = 'Year 1';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 6'){
		$y = 'Year 6';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='Phonics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradepho71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradepho71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradepho71 = "P";}
								else if(($row["score"] <= 49)){$gradepho71 = "F";}
								else {$gradepho71 = "NA";}
						$fphoscore71[] = $row['score'];						
						}
$ffphoscore71 = current($fphoscore71);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='Phonics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradepho72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradepho72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradepho72 = "P";}
								else if(($row["score"] <= 49)){$gradepho72 = "F";}
								else {$gradepho72 = "NA";}
						$sphoscore72[] = $row['score'];						
						}
$ssphoscore72 = current($sphoscore72);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='Phonics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradepho73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradepho73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradepho73 = "P";}
								else if(($row["score"] <= 49)){$gradepho73 = "F";}
								else {$gradepho73 = "NA";}
						$tphoscore73[] = $row['score'];						
						}
$ttphoscore73 = current($tphoscore73);
}
// YEAR 2 DATA FOR PHONICS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 1'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Phonics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradepho81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradepho81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradepho81 = "P";}
								else if(($row["score"] <= 49)){$gradepho81 = "F";}
								else {$gradepho81 = "NA";}
						$fphoscore81[] = $row['score'];						
						}
$ffphoscore81 = current($fphoscore81);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Phonics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradepho82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradepho82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradepho82 = "P";}
								else if(($row["score"] <= 49)){$gradepho82 = "F";}
								else {$gradepho82 = "NA";}
						$sphoscore82[] = $row['score'];						
						}
$ssphoscore82 = current($sphoscore82);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Phonics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradepho83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradepho83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradepho83 = "P";}
								else if(($row["score"] <= 49)){$gradepho83 = "F";}
								else {$gradepho83 = "NA";}
						$tphoscore83[] = $row['score'];						
						}
$ttphoscore83 = current($tphoscore83);
}
// YEAR 3 DATA FOR PHONICS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 1'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Phonics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradepho91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradepho91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradepho91 = "P";}
								else if(($row["score"] <= 49)){$gradepho91 = "F";}
								else {$gradepho91 = "NA";}
						$fphoscore91[] = $row['score'];						
						}
$ffphoscore91 = current($fphoscore91);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Phonics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradepho92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradepho92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradepho92 = "P";}
								else if(($row["score"] <= 49)){$gradepho92 = "F";}
								else {$gradepho92 = "NA";}
						$sphoscore92[] = $row['score'];						
						}
$ssphoscore92 = current($sphoscore92);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Phonics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradepho93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradepho93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradepho93 = "P";}
								else if(($row["score"] <= 49)){$gradepho93 = "F";}
								else {$gradepho93 = "NA";}
						$tphoscore93[] = $row['score'];						
						}
$ttphoscore93 = current($tphoscore93);
}	

// YEAR 10 DATA FOR PHONICS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 1'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Phonics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradepho101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradepho101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradepho101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradepho101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradepho101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradepho101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradepho101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradepho101 = "E8";}
								else if(($row["score"] <= 39)){$gradepho101 = "F9";}
								else {$gradepho101 = "NA";}
						$fphoscore101[] = $row['score'];						
						}
$ffphoscore101 = current($fphoscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Phonics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradepho102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradepho102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradepho102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradepho102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradepho102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradepho102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradepho102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradepho102 = "E8";}
								else if(($row["score"] <= 39)){$gradepho102 = "F9";}
								else {$gradepho102 = "NA";}
						$fphoscore102[] = $row['score'];						
						}
$ssphoscore102 = current($sphoscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Phonics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradepho103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradepho103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradepho103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradepho103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradepho103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradepho103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradepho103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradepho103 = "E8";}
								else if(($row["score"] <= 39)){$gradepho103 = "F9";}
								else {$gradepho103 = "NA";}
						$fphoscore103[] = $row['score'];						
						}
$ttphoscore103 = current($tphoscore103);
}

// YEAR 11 DATA FOR PHONICS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 1'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Phonics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradepho111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradepho111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradepho111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradepho111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradepho111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradepho111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradepho111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradepho111 = "E8";}
								else if(($row["score"] <= 39)){$gradepho111 = "F9";}
								else {$gradepho111 = "NA";}
						$fphoscore111[] = $row['score'];						
						}
$ffphoscore111 = current($fphoscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Phonics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradepho112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradepho112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradepho112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradepho112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradepho112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradepho112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradepho112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradepho112 = "E8";}
								else if(($row["score"] <= 39)){$gradepho112 = "F9";}
								else {$gradepho112 = "NA";}
						$fphoscore112[] = $row['score'];						
						}
$ssphoscore112 = current($sphoscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Phonics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradepho113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradepho113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradepho113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradepho113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradepho113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradepho113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradepho113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradepho113 = "E8";}
								else if(($row["score"] <= 39)){$gradepho113 = "F9";}
								else {$gradepho113 = "NA";}
						$fphoscore113[] = $row['score'];						
						}
$ttphoscore113 = current($tphoscore113);			
}

// YEAR 6 DATA FOR PHONICS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 1'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 2'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Phonics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradepho121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradepho121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradepho121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradepho121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradepho121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradepho121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradepho121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradepho121 = "E8";}
								else if(($row["score"] <= 39)){$gradepho121 = "F9";}
								else {$gradepho121 = "NA";}
						$fphoscore121[] = $row['score'];						
						}
$ffphoscore121 = current($fphoscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Phonics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradepho122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradepho122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradepho122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradepho122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradepho122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradepho122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradepho122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradepho122 = "E8";}
								else if(($row["score"] <= 39)){$gradepho122 = "F9";}
								else {$gradepho122 = "NA";}
						$fphoscore122[] = $row['score'];					
						}
$ssphoscore122 = current($sphoscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Phonics' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradepho123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradepho123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradepho123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradepho123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradepho123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradepho123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradepho123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradepho123 = "E8";}
								else if(($row["score"] <= 39)){$gradepho123 = "F9";}
								else {$gradepho123 = "NA";}
						$fphoscore123[] = $row['score'];						
						}
$ttphoscore123 = current($tphoscore123);
}					
?>
<td><?php echo $ffphoscore71;  ?></td>
<td><?php if($ffphoscore71 != ""){echo $gradepho71;}else{echo "-";} ?></td>
<td><?php echo $ssphoscore72;  ?></td>
<td><?php if($ssphoscore72 != ""){echo $gradepho72;}else{echo "-";} ?></td>
<td><?php echo $ttphoscore73;  ?></td>
<td><?php if($ttphoscore73 != ""){echo $gradepho73;}else{echo "-";} ?></td>
<td><?php echo $ffphoscore81;  ?></td>
<td><?php if($ffphoscore81 != ""){echo $gradepho81;}else{echo "-";} ?></td>
<td><?php echo $ssphoscore82;  ?></td>
<td><?php if($ssphoscore82 != ""){echo $gradepho82;}else{echo "-";} ?></td>
<td><?php echo $ttphoscore83;  ?></td>
<td><?php if($ttphoscore83 != ""){echo $gradepho83;}else{echo "-";} ?></td>
<td><?php echo $ffphoscore91;  ?></td>
<td><?php if($ffphoscore91 != ""){echo $gradepho91;}else{echo "-";} ?></td>
<td><?php echo $ssphescore92;  ?></td>
<td><?php if($ssphoscore92 != ""){echo $gradepho92;}else{echo "-";} ?></td>
<td><?php echo $ttphoscore93;  ?></td>
<td><?php if($ttphoscore93 != ""){echo $gradepho93;}else{echo "-";} ?></td>
<td><?php echo $ffphoscore101;  ?></td>
<td><?php if($ffphoscore101 != ""){echo $gradepho101;}else{echo "-";} ?></td>
<td><?php echo $ssphoscore102;  ?></td>
<td><?php if($ssphoscore102 != ""){echo $gradepho102;}else{echo "-";} ?></td>
<td><?php echo $ttphoscore103;  ?></td>
<td><?php if($ttphoscore103 != ""){echo $gradepho103;}else{echo "-";} ?></td>
<td><?php echo $ffphoscore111;  ?></td>
<td><?php if($ffphoscore111 != ""){echo $gradepho111;}else{echo "-";} ?></td>
<td><?php echo $ssphoscore112;  ?></td>
<td><?php if($ssphoscore112 != ""){echo $gradepho112;}else{echo "-";} ?></td>
<td><?php echo $ttphoscore113;  ?></td>
<td><?php if($ttphoscore113 != ""){echo $gradepho113;}else{echo "-";} ?></td>
<td><?php echo $ffphoscore121;  ?></td>
<td><?php if($ffphoscore121 != ""){echo $gradepho121;}else{echo "-";} ?></td>
<td><?php echo $ssphoscore122;  ?></td>
<td><?php if($ssphoscore122 != ""){echo $gradepho122;}else{echo "-";} ?></td>
<td><?php echo $ttphoscore123;  ?></td>
<td><?php if($ttphoscore123 != ""){echo $gradepho123;}else{echo "-";} ?></td>
</tr>





<tr style="height: 13px;">
<td>QUANTITATIVE REASONING</td>
<?php
//include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 6'){
echo "";
}
else{
//YEAR 1 DATA FOR QUANTITATIVE REASONING
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 1'){
		$y = 'Year 1';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 6'){
		$y = 'Year 6';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Quantitative Reasoning' AND school='".$_SESSION["school"]."'");
				while($row = mysqli_fetch_assoc($result))
							{
						$term111[] = $row['term'];						
						$score111[] = $row['score'];						
						}
$fscore111 = $score111;
$fterm111 = $term111;
$c = array_combine($fterm111, $fscore111);
$qr7 = $c;
ksort($qr7);
$ffqrsc71 = $qr7['First Term'];
$ssqrsc72 = $qr7['Second Term'];
$ttqrsc73 = $qr7['Third Term'];
if($ffqrsc71 >= 70){$gradeqr71 = "A"; }
else if(($ffqrsc71 >= 60) AND ($ffqrsc71 <= 69)){$gradeqr71 = "C";}
else if(($ffqrsc71 >= 50) AND ($ffqrsc71 <= 59)){$gradeqr71 = "P";}
else if(($ffqrsc71 <= 49)){$gradeqr71 = "F";}
else {$gradeqr71 = "NA";}	
if($ssqrsc72 >= 70){$gradeqr72 = "A"; }
else if(($ssqrsc72 >= 60) AND ($ssqrsc72 <= 69)){$gradeqr72 = "C";}
else if(($ssqrsc72 >= 50) AND ($ssqrsc72 <= 59)){$gradeqr72 = "P";}
else if(($ssqrsc72 <= 49)){$gradeqr72 = "F";}
else {$gradeqr72 = "NA";}	
if($ttqrsc73 >= 70){$gradeqr73 = "A"; }
else if(($ttqrsc73 >= 60) AND ($ttqrsc73 <= 69)){$gradeqr73 = "C";}
else if(($ttqrsc73 >= 50) AND ($ttqrsc73 <= 59)){$gradeqr73 = "P";}
else if(($ttqrsc73 <= 49)){$gradeqr73 = "F";}
else {$gradeqr73 = "NA";}	
}

// YEAR 2 DATA FOR QUANTITATIVE REASONING
$class_name = $_POST['class_name'];
if(($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 1'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Quantitative Reasoning' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeqr81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeqr81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeqr81 = "P";}
								else if(($row["score"] <= 49)){$gradeqr81 = "F";}
								else {$gradeqr81 = "NA";}
						$fqrscore81[] = $row['score'];	
						}
$ffqrsc81 = current($fqrscore81);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Quantitative Reasoning' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 70){$gradeqr82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeqr82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeqr82 = "P";}
								else if(($row["score"] <= 49)){$gradeqr82 = "F";}
								else {$gradeqr82 = "NA";}
						$fqrscore82[] = $row['score'];	
						}
$ssqrsc82 = current($sqrscore82);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Quantitative Reasoning' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeqr83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeqr83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeqr83 = "P";}
								else if(($row["score"] <= 49)){$gradeqr83 = "F";}
								else {$gradeqr83 = "NA";}
						$tqrscore83[] = $row['score'];	
						}
$ttqrsc83 = current($tqrscore83);	
}
// YEAR 3 DATA FOR QUANTITATIVE REASONING
$class_name = $_POST['class_name'];
if(($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 1'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Quantitative Reasoning' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeqr91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeqr91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeqr91 = "P";}
								else if(($row["score"] <= 49)){$gradeqr91 = "F";}
								else {$gradeqr91 = "NA";}
						$fqrscore91[] = $row['score'];	
						}
$ffqrsc91 = current($fqrscore91);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Quantitative Reasoning' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 70){$gradeqr92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeqr92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeqr92 = "P";}
								else if(($row["score"] <= 49)){$gradeqr82 = "F";}
								else {$gradeqr92 = "NA";}
						$fqrscore92[] = $row['score'];	
						}
$ssqrsc92 = current($sqrscore92);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Quantitative Reasoning' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeqr93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeqr93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeqr93 = "P";}
								else if(($row["score"] <= 49)){$gradeqr93 = "F";}
								else {$gradeqr93 = "NA";}
						$tqrscore93[] = $row['score'];	
						}
$ttqrsc93 = current($tqrscore93);	
}	

// YEAR 4 DATA FOR QUANTITATIVE REASONING
$class_name = $_POST['class_name'];
if(($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 1'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Quantitative Reasoning' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeqr101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeqr101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeqr101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeqr101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeqr101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeqr101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeqr101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeqr101 = "E8";}
								else if(($row["score"] <= 39)){$gradeqr101 = "F9";}
								else {$gradeqr101 = "NA";}
						$fqrscore101[] = $row['score'];						
						}
$ffqrsc101 = current($fqrscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Quantitative Reasoning' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeqr102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeqr102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeqr102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeqr102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeqr102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeqr102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeqr102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeqr102 = "E8";}
								else if(($row["score"] <= 39)){$gradeqr102 = "F9";}
								else {$gradeqr102 = "NA";}
						$fqrscore102[] = $row['score'];								
						}
$ssqrsc102 = current($sqrscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Quantitative Reasoning' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeqr103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeqr103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeqr103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeqr103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeqr103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeqr103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeqr103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeqr103 = "E8";}
								else if(($row["score"] <= 39)){$gradeqr103 = "F9";}
								else {$gradeqr103 = "NA";}
						$fqrscore103[] = $row['score'];							
						}
$ttqrsc103 = current($tqrscore103);
}

// YEAR 5 DATA FOR QUANTITATIVE REASONING
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 1'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Quantitative Reasoning' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeqr111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeqr111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeqr111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeqr111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeqr111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeqr111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeqr111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeqr111 = "E8";}
								else if(($row["score"] <= 39)){$gradeqr111 = "F9";}
								else {$gradeqr111 = "NA";}
						$fqrscore111[] = $row['score'];							
						}
$ffqrsc111 = current($fqrscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Quantitative Reasoning' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradeqr112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeqr112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeqr112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeqr112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeqr112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeqr112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeqr112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeqr112 = "E8";}
								else if(($row["score"] <= 39)){$gradeqr112 = "F9";}
								else {$gradeqr112 = "NA";}
						$fqrscore112[] = $row['score'];							
						}
$ssqrsc112 = current($sqrscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Quantitative Reasoning' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeqr113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeqr113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeqr113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeqr113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeqr113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeqr113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeqr113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeqr113 = "E8";}
								else if(($row["score"] <= 39)){$gradeqr113 = "F9";}
								else {$gradeqr113 = "NA";}
						$fqrscore113[] = $row['score'];							
						}
$ttqrsc113 = current($tqrscore113);		
}

// YEAR 6 DATA FOR QUANTITATIVE REASONING
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 1'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 2'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Quantitative Reasoning' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
							if($row["score"] >= 80){$gradeqr121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeqr121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeqr121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeqr121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeqr121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeqr121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeqr121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeqr121 = "E8";}
								else if(($row["score"] <= 39)){$gradeqr121 = "F9";}
								else {$gradeqr121 = "NA";}
						$fqrscore121[] = $row['score'];							
						}
$ffqrsc121 = current($fqrscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Quantitative Reasoning' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradeqr122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeqr122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeqr122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeqr122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeqr122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeqr122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeqr122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeqr122 = "E8";}
								else if(($row["score"] <= 39)){$gradeqr122 = "F9";}
								else {$gradeqr122 = "NA";}
						$fqrscore122[] = $row['score'];						
						}
$ssqrsc122 = current($sqrscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Quantitative Reasoning' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradeqr123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeqr123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeqr123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeqr123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeqr123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeqr123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeqr123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeqr123 = "E8";}
								else if(($row["score"] <= 39)){$gradeqr123 = "F9";}
								else {$gradeqr123 = "NA";}
						$fqrscore123[] = $row['score'];						
						}
$ttqrsc123 = current($tqrscore123);
}					
?>
<td><?php echo $ffqrsc71;  ?></td>
<td><?php if($ffqrsc71 != ""){echo $gradeqr71;}else{echo "-";} ?></td>
<td><?php echo $ssqrsc72;  ?></td>
<td><?php if($ssqrsc72 != ""){echo $gradeqr72;}else{echo "-";} ?></td>
<td><?php echo $ttqrsc73;  ?></td>
<td><?php if($ttqrsc73 != ""){echo $gradeqr73;}else{echo "-";} ?></td>
<td><?php echo $ffqrsc81;  ?></td>
<td><?php if($ffqrsc81 != ""){echo $gradeqr81;}else{echo "-";} ?></td>
<td><?php echo $ssqrsc82;  ?></td>
<td><?php if($ssqrsc82 != ""){echo $gradeqr82;}else{echo "-";} ?></td>
<td><?php echo $ttqrsc83;  ?></td>
<td><?php if($ttqrsc83 != ""){echo $gradeqr83;}else{echo "-";} ?></td>
<td><?php echo $ffqrsc91;  ?></td>
<td><?php if($ffqrsc91 != ""){echo $gradeqr91;}else{echo "-";} ?></td>
<td><?php echo $ssqrsc92;  ?></td>
<td><?php if($ssqrsc92 != ""){echo $gradeqr92;}else{echo "-";} ?></td>
<td><?php echo $ttqrsc93;  ?></td>
<td><?php if($ttqrsc93 != ""){echo $gradeqr93;}else{echo "-";} ?></td>
<td><?php echo $ffqrsc101;  ?></td>
<td><?php if($ffqrsc101 != ""){echo $gradeqr101;}else{echo "-";} ?></td>
<td><?php echo $ssqrsc102;  ?></td>
<td><?php if($ssqrsc102 != ""){echo $gradeqr102;}else{echo "-";} ?></td>
<td><?php echo $ttqrsc103;  ?></td>
<td><?php if($ttqrsc103 != ""){echo $gradeqr103;}else{echo "-";} ?></td>
<td><?php echo $ffqrsc111;  ?></td>
<td><?php if($ffqrsc111 != ""){echo $gradeqr111;}else{echo "-";} ?></td>
<td><?php echo $ssqrsc112;  ?></td>
<td><?php if($ssqrsc112 != ""){echo $gradeqr112;}else{echo "-";} ?></td>
<td><?php echo $ttqrsc113;  ?></td>
<td><?php if($ttqrsc113 != ""){echo $gradeqr113;}else{echo "-";} ?></td>
<td><?php echo $ffqrsc121;  ?></td>
<td><?php if($ffqrsc121 != ""){echo $gradeqr121;}else{echo "-";} ?></td>
<td><?php echo $ssqrsc122;  ?></td>
<td><?php if($ssqrsc122 != ""){echo $gradeqr122;}else{echo "-";} ?></td>
<td><?php echo $ttqrsc123;  ?></td>
<td><?php if($ttqrsc123 != ""){echo $gradeqr123;}else{echo "-";} ?></td>
</tr>


<tr style="height: 13px;">
<td>VERBAL REASONING</td>
<?php
//include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
//YEAR 1 DATA FOR VERBAL REASONING
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 1'){
		$y = 'Year 1';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 6'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Verbal Reasoning' AND school='".$_SESSION["school"]."'");
				while($row = mysqli_fetch_assoc($result))
							{
						$term111[] = $row['term'];						
						$score111[] = $row['score'];						
						}
$fscore111 = $score111;
$fterm111 = $term111;
$c = array_combine($fterm111, $fscore111);
$vr7 = $c;
ksort($vr7);
$ffvrsc71 = $vr7['First Term'];
$ssvrsc72 = $vr7['Second Term'];
$ttvrsc73 = $vr7['Third Term'];
if($ffvrsc71 >= 70){$gradevr71 = "A"; }
else if(($ffvrsc71 >= 60) AND ($ffvrsc71 <= 69)){$gradevr71 = "C";}
else if(($ffvrsc71 >= 50) AND ($ffvrsc71 <= 59)){$gradevr71 = "P";}
else if(($ffvrsc71 <= 49)){$gradevr71 = "F";}
else {$gradevr71 = "NA";}	
if($ssvrsc72 >= 70){$gradevr72 = "A"; }
else if(($ssvrsc72 >= 60) AND ($ssvrsc72 <= 69)){$gradevr72 = "C";}
else if(($ssvrsc72 >= 50) AND ($ssvrsc72 <= 59)){$gradevr72 = "P";}
else if(($ssvrsc72 <= 49)){$gradevr72 = "F";}
else {$gradevr72 = "NA";}	
if($ttvrsc73 >= 70){$gradevr73 = "A"; }
else if(($ttvrsc73 >= 60) AND ($ttvrsc73 <= 69)){$gradevr73 = "C";}
else if(($ttvrsc73 >= 50) AND ($ttvrsc73 <= 59)){$gradevr73 = "P";}
else if(($ttvrsc73 <= 49)){$gradevr73 = "F";}
else {$gradevr73 = "NA";}	
}

// YEAR 2 DATA FOR VERBAL REASONING
$class_name = $_POST['class_name'];
if(($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 1'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Verbal Reasoning' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradevr81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradevr81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradevr81 = "P";}
								else if(($row["score"] <= 49)){$gradevr81 = "F";}
								else {$gradevr81 = "NA";}
						$fvrscore81[] = $row['score'];	
						}
$ffvrsc81 = current($fvrscore81);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Verbal Reasoning' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 70){$gradevr82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradevr82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradevr82 = "P";}
								else if(($row["score"] <= 49)){$gradevr82 = "F";}
								else {$gradevr82 = "NA";}
						$fvrscore82[] = $row['score'];	
						}
$ssvrsc82 = current($svrscore82);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Verbal Reasoning' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradevr83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradevr83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradevr83 = "P";}
								else if(($row["score"] <= 49)){$gradevr83 = "F";}
								else {$gradevr83 = "NA";}
						$tvrscore83[] = $row['score'];	
						}
$ttvrsc83 = current($tvrscore83);	
}
// YEAR 3 DATA FOR VERBAL REASONING
$class_name = $_POST['class_name'];
if(($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 1'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Verbal Reasoning' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradevr91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradevr91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradevr91 = "P";}
								else if(($row["score"] <= 49)){$gradevr91 = "F";}
								else {$gradevr91 = "NA";}
						$fvrscore91[] = $row['score'];	
						}
$ffvrsc91 = current($fvrscore91);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Verbal Reasoning' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 70){$gradevr92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradevr92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradevr92 = "P";}
								else if(($row["score"] <= 49)){$gradevr82 = "F";}
								else {$gradevr92 = "NA";}
						$fvrscore92[] = $row['score'];	
						}
$ssvrsc92 = current($svrscore92);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Verbal Reasoning' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradevr93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradevr93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradevr93 = "P";}
								else if(($row["score"] <= 49)){$gradevr93 = "F";}
								else {$gradevr93 = "NA";}
						$tvrscore93[] = $row['score'];	
						}
$ttvrsc93 = current($tvrscore93);	
}	

// YEAR 4 DATA FOR VERBAL REASONING
$class_name = $_POST['class_name'];
if(($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 1'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Verbal Reasoning' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradevr101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradevr101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradevr101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradevr101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradevr101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradevr101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradevr101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradevr101 = "E8";}
								else if(($row["score"] <= 39)){$gradevr101 = "F9";}
								else {$gradevr101 = "NA";}
						$fvrscore101[] = $row['score'];						
						}
$ffvrsc101 = current($fvrscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Verbal Reasoning' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradevr102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradevr102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradevr102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradevr102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradevr102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradevr102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradevr102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradevr102 = "E8";}
								else if(($row["score"] <= 39)){$gradevr102 = "F9";}
								else {$gradevr102 = "NA";}
						$fvrscore102[] = $row['score'];								
						}
$ssvrsc102 = current($svrscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Verbal Reasoning' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradevr103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradevr103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradevr103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradevr103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradevr103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradevr103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradevr103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradevr103 = "E8";}
								else if(($row["score"] <= 39)){$gradevr103 = "F9";}
								else {$gradevr103 = "NA";}
						$fvrscore103[] = $row['score'];						
						}
$ttvrsc103 = current($tvrscore103);
}

// YEAR 5 DATA FOR VERBAL REASONING
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 1'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Verbal Reasoning' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradevr111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradevr111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradevr111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradevr111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradevr111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradevr111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradevr111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradevr111 = "E8";}
								else if(($row["score"] <= 39)){$gradevr111 = "F9";}
								else {$gradevr111 = "NA";}
						$fvrscore111[] = $row['score'];							
						}
$ffvrsc111 = current($fvrscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Verbal Reasoning' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradevr112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradevr112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradevr112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradevr112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradevr112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradevr112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradevr112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradevr112 = "E8";}
								else if(($row["score"] <= 39)){$gradevr112 = "F9";}
								else {$gradevr112 = "NA";}
						$fvrscore112[] = $row['score'];						
						}
$ssvrsc112 = current($svrscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Verbal Reasoning' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradevr113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradevr113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradevr113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradevr113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradevr113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradevr113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradevr113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradevr113 = "E8";}
								else if(($row["score"] <= 39)){$gradevr113 = "F9";}
								else {$gradevr113 = "NA";}
						$fvrscore113[] = $row['score'];							
						}
$ttvrsc113 = current($tvrscore113);		
}

// YEAR 6 DATA FOR VERBAL REASONING
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 1'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 2'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Verbal Reasoning' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
							if($row["score"] >= 80){$gradevr121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradevr121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradevr121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradevr121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradevr121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradevr121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradevr121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradevr121 = "E8";}
								else if(($row["score"] <= 39)){$gradevr121 = "F9";}
								else {$gradevr121 = "NA";}
						$fvrscore121[] = $row['score'];							
						}
$ffvrsc121 = current($fvrscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Verbal Reasoning' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradevr122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradevr122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradevr122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradevr122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradevr122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradevr122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradevr122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradevr122 = "E8";}
								else if(($row["score"] <= 39)){$gradevr122 = "F9";}
								else {$gradevr122 = "NA";}
						$fvrscore122[] = $row['score'];						
						}
$ssvrsc122 = current($svrscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Verbal Reasoning' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradevr123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradevr123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradevr123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradevr123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradevr123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradevr123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradevr123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradevr123 = "E8";}
								else if(($row["score"] <= 39)){$gradevr123 = "F9";}
								else {$gradevr123 = "NA";}
						$fvrscore123[] = $row['score'];						
						}
$ttvrsc123 = current($tvrscore123);
}					
?>
<td><?php echo $ffvrsc71;  ?></td>
<td><?php if($ffvrsc71 != ""){echo $gradevr71;}else{echo "-";} ?></td>
<td><?php echo $ssvrsc72;  ?></td>
<td><?php if($ssvrsc72 != ""){echo $gradevr72;}else{echo "-";} ?></td>
<td><?php echo $ttvrsc73;  ?></td>
<td><?php if($ttvrsc73 != ""){echo $gradevr73;}else{echo "-";} ?></td>
<td><?php echo $ffvrsc81;  ?></td>
<td><?php if($ffvrsc81 != ""){echo $gradevr81;}else{echo "-";} ?></td>
<td><?php echo $ssvrsc82;  ?></td>
<td><?php if($ssvrsc82 != ""){echo $gradevr82;}else{echo "-";} ?></td>
<td><?php echo $ttvrsc83;  ?></td>
<td><?php if($ttvrsc83 != ""){echo $gradevr83;}else{echo "-";} ?></td>
<td><?php echo $ffvrsc91;  ?></td>
<td><?php if($ffvrsc91 != ""){echo $gradevr91;}else{echo "-";} ?></td>
<td><?php echo $ssvrsc92;  ?></td>
<td><?php if($ssvrsc92 != ""){echo $gradevr92;}else{echo "-";} ?></td>
<td><?php echo $ttvrsc93;  ?></td>
<td><?php if($ttvrsc93 != ""){echo $gradevr93;}else{echo "-";} ?></td>
<td><?php echo $ffvrsc101;  ?></td>
<td><?php if($ffvrsc101 != ""){echo $gradevr101;}else{echo "-";} ?></td>
<td><?php echo $ssvrsc102;  ?></td>
<td><?php if($ssvrsc102 != ""){echo $gradevr102;}else{echo "-";} ?></td>
<td><?php echo $ttvrsc103;  ?></td>
<td><?php if($ttvrsc103 != ""){echo $gradevr103;}else{echo "-";} ?></td>
<td><?php echo $ffvrsc111;  ?></td>
<td><?php if($ffvrsc111 != ""){echo $gradevr111;}else{echo "-";} ?></td>
<td><?php echo $ssvrsc112;  ?></td>
<td><?php if($ssvrsc112 != ""){echo $gradevr112;}else{echo "-";} ?></td>
<td><?php echo $ttvrsc113;  ?></td>
<td><?php if($ttvrsc113 != ""){echo $gradevr113;}else{echo "-";} ?></td>
<td><?php echo $ffvrsc121;  ?></td>
<td><?php if($ffvrsc121 != ""){echo $gradevr121;}else{echo "-";} ?></td>
<td><?php echo $ssvrsc122;  ?></td>
<td><?php if($ssvrsc122 != ""){echo $gradevr122;}else{echo "-";} ?></td>
<td><?php echo $ttvrsc123;  ?></td>
<td><?php if($ttvrsc123 != ""){echo $gradevr123;}else{echo "-";} ?></td>
</tr>

<tr style="height: 13px;">
<td>VOCATIONAL APTITUDE</td>
<?php
//include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
//YEAR 1 DATA FOR VOCATIONAL APTITUDE
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 1'){
		$y = 'Year 1';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 6'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Vocational Aptitude' AND school='".$_SESSION["school"]."'");
				while($row = mysqli_fetch_assoc($result))
							{
						$term111[] = $row['term'];						
						$score111[] = $row['score'];						
						}
$fscore111 = $score111;
$fterm111 = $term111;
$c = array_combine($fterm111, $fscore111);
$vr7 = $c;
ksort($vr7);
$ffvapsc71 = $vr7['First Term'];
$ssvapsc72 = $vr7['Second Term'];
$ttvapsc73 = $vr7['Third Term'];
if($ffvapsc71 >= 70){$gradevap71 = "A"; }
else if(($ffvapsc71 >= 60) AND ($ffvapsc71 <= 69)){$gradevap71 = "C";}
else if(($ffvapsc71 >= 50) AND ($ffvapsc71 <= 59)){$gradevap71 = "P";}
else if(($ffvapsc71 <= 49)){$gradevap71 = "F";}
else {$gradevap71 = "NA";}	
if($ssvapsc72 >= 70){$gradevap72 = "A"; }
else if(($ssvapsc72 >= 60) AND ($ssvapsc72 <= 69)){$gradevap72 = "C";}
else if(($ssvapsc72 >= 50) AND ($ssvapsc72 <= 59)){$gradevap72 = "P";}
else if(($ssvapsc72 <= 49)){$gradevap72 = "F";}
else {$gradevap72 = "NA";}	
if($ttvapsc73 >= 70){$gradevap73 = "A"; }
else if(($ttvapsc73 >= 60) AND ($ttvapsc73 <= 69)){$gradevap73 = "C";}
else if(($ttvapsc73 >= 50) AND ($ttvapsc73 <= 59)){$gradevap73 = "P";}
else if(($ttvapsc73 <= 49)){$gradevap73 = "F";}
else {$gradevap73 = "NA";}	
}

// YEAR 2 DATA FOR VOCATIONAL APTITUDE
$class_name = $_POST['class_name'];
if(($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 1'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Vocational Aptitude' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradevap81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradevap81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradevap81 = "P";}
								else if(($row["score"] <= 49)){$gradevap81 = "F";}
								else {$gradevap81 = "NA";}
						$fvapscore81[] = $row['score'];	
						}
$ffvapsc81 = current($fvapscore81);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Vocational Aptitude' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 70){$gradevap82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradevap82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradevap82 = "P";}
								else if(($row["score"] <= 49)){$gradevap82 = "F";}
								else {$gradevap82 = "NA";}
						$fvapscore82[] = $row['score'];	
						}
$ssvapsc82 = current($svapscore82);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Vocational Aptitude' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradevap83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradevap83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradevap83 = "P";}
								else if(($row["score"] <= 49)){$gradevap83 = "F";}
								else {$gradevap83 = "NA";}
						$tvapscore83[] = $row['score'];	
						}
$ttvapsc83 = current($tvapscore83);	
}
// YEAR 3 DATA FOR VOCATIONAL APTITUDE
$class_name = $_POST['class_name'];
if(($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 1'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Vocational Aptitude' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradevap91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradevap91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradevap91 = "P";}
								else if(($row["score"] <= 49)){$gradevap91 = "F";}
								else {$gradevap91 = "NA";}
						$fvapscore91[] = $row['score'];	
						}
$ffvapsc91 = current($fvapscore91);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Vocational Aptitude' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 70){$gradevap92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradevap92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradevap92 = "P";}
								else if(($row["score"] <= 49)){$gradevap82 = "F";}
								else {$gradevap92 = "NA";}
						$fvapscore92[] = $row['score'];	
						}
$ssvapsc92 = current($svapscore92);	

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Vocational Aptitude' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradevap93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradevap93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradevap93 = "P";}
								else if(($row["score"] <= 49)){$gradevap93 = "F";}
								else {$gradevap93 = "NA";}
						$tvapscore93[] = $row['score'];	
						}
$ttvapsc93 = current($tvapscore93);	
}	

// YEAR 4 DATA FOR VOCATIONAL APTITUDE
$class_name = $_POST['class_name'];
if(($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 1'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Vocational Aptitude' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradevap101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradevap101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradevap101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradevap101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradevap101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradevap101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradevap101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradevap101 = "E8";}
								else if(($row["score"] <= 39)){$gradevap101 = "F9";}
								else {$gradevap101 = "NA";}
						$fvapscore101[] = $row['score'];						
						}
$ffvapsc101 = current($fvapscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Vocational Aptitude' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradevap102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradevap102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradevap102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradevap102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradevap102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradevap102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradevap102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradevap102 = "E8";}
								else if(($row["score"] <= 39)){$gradevap102 = "F9";}
								else {$gradevap102 = "NA";}
						$fvapscore102[] = $row['score'];							
						}
$ssvapsc102 = current($svapscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Vocational Aptitude' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradevap103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradevap103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradevap103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradevap103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradevap103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradevap103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradevap103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradevap103 = "E8";}
								else if(($row["score"] <= 39)){$gradevap103 = "F9";}
								else {$gradevap103 = "NA";}
						$fvapscore103[] = $row['score'];					
						}
$ttvapsc103 = current($tvapscore103);
}

// YEAR 5 DATA FOR VOCATIONAL APTITUDE
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 1'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Vocational Aptitude' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradevap111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradevap111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradevap111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradevap111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradevap111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradevap111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradevap111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradevap111 = "E8";}
								else if(($row["score"] <= 39)){$gradevap111 = "F9";}
								else {$gradevap111 = "NA";}
						$fvapscore111[] = $row['score'];							
						}
$ffvapsc111 = current($fvapscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Vocational Aptitude' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradevap112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradevap112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradevap112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradevap112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradevap112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradevap112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradevap112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradevap112 = "E8";}
								else if(($row["score"] <= 39)){$gradevap112 = "F9";}
								else {$gradevap112 = "NA";}
						$fvapscore112[] = $row['score'];							
						}
$ssvapsc112 = current($svapscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Vocational Aptitude' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradevap113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradevap113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradevap113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradevap113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradevap113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradevap113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradevap113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradevap113 = "E8";}
								else if(($row["score"] <= 39)){$gradevap113 = "F9";}
								else {$gradevap113 = "NA";}
						$fvapscore113[] = $row['score'];							
						}
$ttvapsc113 = current($tvapscore113);		
}

// YEAR 6 DATA FOR VOCATIONAL APTITUDE
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 1'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 2'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Vocational Aptitude' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
							if($row["score"] >= 80){$gradevap121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradevap121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradevap121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradevap121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradevap121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradevap121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradevap121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradevap121 = "E8";}
								else if(($row["score"] <= 39)){$gradevap121 = "F9";}
								else {$gradevap121 = "NA";}
						$fvapscore121[] = $row['score'];							
						}
$ffvapsc121 = current($fvapscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Vocational Aptitude' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradevap122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradevap122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradevap122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradevap122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradevap122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradevap122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradevap122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradevap122 = "E8";}
								else if(($row["score"] <= 39)){$gradevap122 = "F9";}
								else {$gradevap122 = "NA";}
						$fvapscore122[] = $row['score'];					
						}
$ssvapsc122 = current($svapscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Vocational Aptitude' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradevap123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradevap123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradevap123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradevap123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradevap123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradevap123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradevap123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradevap123 = "E8";}
								else if(($row["score"] <= 39)){$gradevap123 = "F9";}
								else {$gradevap123 = "NA";}
						$fvapscore121[] = $row['score'];					
						}
$ttvapsc123 = current($tvapscore123);
}					
?>
<td><?php echo $ffvapsc71;  ?></td>
<td><?php if($ffvapsc71 != ""){echo $gradevap71;}else{echo "-";} ?></td>
<td><?php echo $ssvapsc72;  ?></td>
<td><?php if($ssvapsc72 != ""){echo $gradevap72;}else{echo "-";} ?></td>
<td><?php echo $ttvapsc73;  ?></td>
<td><?php if($ttvapsc73 != ""){echo $gradevap73;}else{echo "-";} ?></td>
<td><?php echo $ffvapsc81;  ?></td>
<td><?php if($ffvapsc81 != ""){echo $gradevap81;}else{echo "-";} ?></td>
<td><?php echo $ssvapsc82;  ?></td>
<td><?php if($ssvapsc82 != ""){echo $gradevap82;}else{echo "-";} ?></td>
<td><?php echo $ttvapsc83;  ?></td>
<td><?php if($ttvapsc83 != ""){echo $gradevap83;}else{echo "-";} ?></td>
<td><?php echo $ffvapsc91;  ?></td>
<td><?php if($ffvapsc91 != ""){echo $gradevap91;}else{echo "-";} ?></td>
<td><?php echo $ssvapsc92;  ?></td>
<td><?php if($ssvapsc92 != ""){echo $gradevap92;}else{echo "-";} ?></td>
<td><?php echo $ttvapsc93;  ?></td>
<td><?php if($ttvapsc93 != ""){echo $gradevap93;}else{echo "-";} ?></td>
<td><?php echo $ffvapsc101;  ?></td>
<td><?php if($ffvapsc101 != ""){echo $gradevap101;}else{echo "-";} ?></td>
<td><?php echo $ssvapsc102;  ?></td>
<td><?php if($ssvapsc102 != ""){echo $gradevap102;}else{echo "-";} ?></td>
<td><?php echo $ttvapsc103;  ?></td>
<td><?php if($ttvapsc103 != ""){echo $gradevap103;}else{echo "-";} ?></td>
<td><?php echo $ffvapsc111;  ?></td>
<td><?php if($ffvapsc111 != ""){echo $gradevap111;}else{echo "-";} ?></td>
<td><?php echo $ssvapsc112;  ?></td>
<td><?php if($ssvapsc112 != ""){echo $gradevap112;}else{echo "-";} ?></td>
<td><?php echo $ttvapsc113;  ?></td>
<td><?php if($ttvapsc113 != ""){echo $gradevap113;}else{echo "-";} ?></td>
<td><?php echo $ffvapsc121;  ?></td>
<td><?php if($ffvapsc121 != ""){echo $gradevap121;}else{echo "-";} ?></td>
<td><?php echo $ssvapsc122;  ?></td>
<td><?php if($ssvapsc122 != ""){echo $gradevap122;}else{echo "-";} ?></td>
<td><?php echo $ttvapsc123;  ?></td>
<td><?php if($ttvapsc123 != ""){echo $gradevap123;}else{echo "-";} ?></td>
</tr>

<tr style="height: 13px;">
<td>YORUBA</td>
<?php
//include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 6'){
echo "";
}
else{
//YEAR 1 DATA FOR YORUBA
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 1'){
		$y = 'Year 1';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 6'){
		$y = 'Year 6';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='Yoruba' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeyor71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeyor71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeyor71 = "P";}
								else if(($row["score"] <= 49)){$gradeyor71 = "F";}
								else {$gradeyor71 = "NA";}
						$fyorscore71[] = $row['score'];						
						}
$ffyorscore71 = current($fyorscore71);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='Yoruba' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeyor72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeyor72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeyor72 = "P";}
								else if(($row["score"] <= 49)){$gradeyor72 = "F";}
								else {$gradeyor72 = "NA";}
						$syorscore72[] = $row['score'];						
						}
$ssyorscore72 = current($syorscore72);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='Yoruba' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeyor73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeyor73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeyor73 = "P";}
								else if(($row["score"] <= 49)){$gradeyor73 = "F";}
								else {$gradeyor73 = "NA";}
						$tyorscore73[] = $row['score'];						
						}
$ttyorscore73 = current($tyorscore73);
}
// YEAR 2 DATA FOR YORUBA
$class_name = $_POST['class_name'];
if(($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 1'){
		$y = 'Year 2';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 5'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Yoruba' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeyor81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeyor81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeyor81 = "P";}
								else if(($row["score"] <= 49)){$gradeyor81 = "F";}
								else {$gradeyor81 = "NA";}
						$fyorscore81[] = $row['score'];						
						}
$ffyorscore81 = current($fyorscore81);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Yoruba' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeyor82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeyor82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeyor82 = "P";}
								else if(($row["score"] <= 49)){$gradeyor82 = "F";}
								else {$gradeyor82 = "NA";}
						$syorscore82[] = $row['score'];						
						}
$ssyorscore82 = current($syorscore82);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Yoruba' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeyor83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeyor83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeyor83 = "P";}
								else if(($row["score"] <= 49)){$gradeyor83 = "F";}
								else {$gradeyor83 = "NA";}
						$tyorscore83[] = $row['score'];						
						}
$ttyorscore83 = current($tyorscore83);
}
// YEAR 3 DATA FOR YORUBA
$class_name = $_POST['class_name'];
if(($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 1'){
		$y = 'Year 3';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 4'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Yoruba' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeyor91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeyor91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeyor91 = "P";}
								else if(($row["score"] <= 49)){$gradeyor91 = "F";}
								else {$gradeyor91 = "NA";}
						$fyorscore91[] = $row['score'];						
						}
$ffyorscore91 = current($fyorscore91);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Yoruba' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeyor92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeyor92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeyor92 = "P";}
								else if(($row["score"] <= 49)){$gradeyor92 = "F";}
								else {$gradeyor92 = "NA";}
						$syorscore92[] = $row['score'];						
						}
$ssyorscore92 = current($syorscore92);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Yoruba' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeyor93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeyor93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeyor93 = "P";}
								else if(($row["score"] <= 49)){$gradeyor93 = "F";}
								else {$gradeyor93 = "NA";}
						$tyorscore93[] = $row['score'];						
						}
$ttyorscore93 = current($tyorscore93);
}	

// YEAR 4 DATA FOR YORUBA
$class_name = $_POST['class_name'];
if(($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 1'){
		$y = 'Year 4';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 3'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Yoruba' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeyor101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeyor101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeyor101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeyor101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeyor101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeyor101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeyor101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeyor101 = "E8";}
								else if(($row["score"] <= 39)){$gradeyor101 = "F9";}
								else {$gradeyor101 = "NA";}
						$fyorscore101[] = $row['score'];						
						}
$ffyorscore101 = current($fyorscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Yoruba' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeyor102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeyor102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeyor102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeyor102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeyor102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeyor102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeyor102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeyor102 = "E8";}
								else if(($row["score"] <= 39)){$gradeyor102 = "F9";}
								else {$gradeyor102 = "NA";}
						$syorscore102[] = $row['score'];						
						}
$ssyorscore102 = current($syorscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Yoruba' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$gradeyor103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeyor103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeyor103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeyor103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeyor103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeyor103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeyor103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeyor103 = "E8";}
								else if(($row["score"] <= 39)){$gradeyor103 = "F9";}
								else {$gradeyor103 = "NA";}
						$tyorscore103[] = $row['score'];						
						}
$ttyorscore103 = current($tyorscore103);	
}

// YEAR 5 DATA FOR YORUBA
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 1'){
		$y = 'Year 5';
		}
		else if($class_name == 'Year 2'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Yoruba' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeyor111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeyor111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeyor111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeyor111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeyor111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeyor111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeyor111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeyor111 = "E8";}
								else if(($row["score"] <= 39)){$gradeyor111 = "F9";}
								else {$gradeyor111 = "NA";}
						$fyorscore111[] = $row['score'];						
						}
$ffyorscore111 = current($fyorscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Yoruba' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeyor112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeyor112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeyor112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeyor112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeyor112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeyor112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeyor112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeyor112 = "E8";}
								else if(($row["score"] <= 39)){$gradeyor112 = "F9";}
								else {$gradeyor112 = "NA";}
						$syorscore112[] = $row['score'];						
						}
$ssyorscore112 = current($syorscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Yoruba' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeyor113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeyor113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeyor113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeyor113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeyor113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeyor113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeyor113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeyor113 = "E8";}
								else if(($row["score"] <= 39)){$gradeyor113 = "F9";}
								else {$gradeyor113 = "NA";}
						$tyorscore113[] = $row['score'];						
						}
$ttyorscore113 = current($tyorscore113);				
}

// YEAR 12 DATA FOR YORUBA
$class_name = $_POST['class_name'];
if(($class_name == 'Year 2') OR ($class_name == 'Year 3') OR ($class_name == 'Year 4') OR ($class_name == 'Year 5') OR ($class_name == 'Year 6')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 1'){
		$y = 'Year 6';
		}
		else if($class_name == 'Year 2'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 3'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 4'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 5'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 6'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Yoruba' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeyor121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeyor121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeyor121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeyor121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeyor121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeyor121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeyor121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeyor121 = "E8";}
								else if(($row["score"] <= 39)){$gradeyor121 = "F9";}
								else {$gradeyor121 = "NA";}
						$figbscore121[] = $row['score'];						
						}
$ffyorscore121 = current($fyorscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Yoruba' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeyor122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeyor122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeyor122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeyor122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeyor122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeyor122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeyor122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeyor122 = "E8";}
								else if(($row["score"] <= 39)){$gradeyor122 = "F9";}
								else {$gradeyor122 = "NA";}
						$syorscore122[] = $row['score'];						
						}
$ssyorscore122 = current($syorscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Yoruba' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeyor123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeyor123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeyor123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeyor123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeyor123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeyor123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeyor123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeyor123 = "E8";}
								else if(($row["score"] <= 39)){$gradeyor123 = "F9";}
								else {$gradeyor123 = "NA";}
						$tyorscore123[] = $row['score'];						
						}
$ttyorscore123 = current($tyorscore123);
}					
?>
<td><?php echo $ffyorscore71;  ?></td>
<td><?php if($ffyorscore71 != ""){echo $gradeyor71;}else{echo "-";} ?></td>
<td><?php echo $ssyorscore72;  ?></td>
<td><?php if($ssyorscore72 != ""){echo $gradeyor72;}else{echo "-";} ?></td>
<td><?php echo $ttyorscore73;  ?></td>
<td><?php if($ttyorscore73 != ""){echo $gradeyor73;}else{echo "-";} ?></td>
<td><?php echo $ffyorscore81;  ?></td>
<td><?php if($ffyorscore81 != ""){echo $gradeyor81;}else{echo "-";} ?></td>
<td><?php echo $ssyorscore82;  ?></td>
<td><?php if($ssyorscore82 != ""){echo $gradeyor82;}else{echo "-";} ?></td>
<td><?php echo $ttyorscore83;  ?></td>
<td><?php if($ssyorscore83 != ""){echo $gradeyor83;}else{echo "-";} ?></td>
<td><?php echo $ffyorscore91;  ?></td>
<td><?php if($ssyorscore91 != ""){echo $gradeyor91;}else{echo "-";} ?></td>
<td><?php echo $ssyorscore92;  ?></td>
<td><?php if($ssyorscore92 != ""){echo $gradeyor92;}else{echo "-";} ?></td>
<td><?php echo $ttyorscore93;  ?></td>
<td><?php if($ttyorcore93 != ""){echo $gradeyor93;}else{echo "-";} ?></td>
<td><?php echo $ttyorscore101;  ?></td>
<td><?php if($ttyorcore101 != ""){echo $gradeyor101;}else{echo "-";} ?></td>
<td><?php echo $ssyorscore102;  ?></td>
<td><?php if($ssyorscore102 != ""){echo $gradeyor102;}else{echo "-";} ?></td>
<td><?php echo $ttyorscore103;  ?></td>
<td><?php if($ttyorscore103 != ""){echo $gradeyor103;}else{echo "-";} ?></td>
<td><?php echo $ffyorscore111;  ?></td>
<td><?php if($ffyorscore111 != ""){echo $gradeyor111;}else{echo "-";} ?></td>
<td><?php echo $ssyorscore112;  ?></td>
<td><?php if($ssyorscore112 != ""){echo $gradeyor112;}else{echo "-";} ?></td>
<td><?php echo $ttyorscore113;  ?></td>
<td><?php if($ttyorscore113 != ""){echo $gradeyor113;}else{echo "-";} ?></td>
<td><?php echo $ffyorscore121;  ?></td>
<td><?php if($ffyorscore121 != ""){echo $gradeyor121;}else{echo "-";} ?></td>
<td><?php echo $ssyorscore122;  ?></td>
<td><?php if($ssyorscore122 != ""){echo $gradeyor122;}else{echo "-";} ?></td>
<td><?php echo $ttyorscore123;  ?></td>
<td><?php if($ttyorscore123 != ""){echo $gradeyor123;}else{echo "-";} ?></td>
</tr>
</tbody>
</table>



<table style="width: 40%; text-align: center; font-size: 8pt; float: left;">
<tbody>
<tr>
<?php
$year = $_POST['year'];
$resultsig = mysqli_query($db, "SELECT * FROM principal where year='$year' AND school='".$_SESSION["school"]."'");
while($rowsig = mysqli_fetch_assoc($resultsig))
{
$sign2[] = $rowsig['sig'];
$imgpr2[] = $rowsig['img'];
$princiname2[] = $rowsig['teacher_name'];
}
$princiname = current($princiname2);
?>
<td><br><br><br><br><br><br><br><br><br><br><br><label>&nbsp;<hr style="width:40%;" /><?php echo strtoupper($princiname); ?>&nbsp;</label><br />HEAD TEACHER</td>
<?php
$ccaa4 = trim(substr($caa2,0,-1))." 4";
$ccaa6 = trim(substr($caa2,0,-1))." 6";
$ccaa1 = trim(substr($caa2,0,-1))." 1";
$ccaa3 = trim(substr($caa2,0,-1))." 3";
?>
</tr>
</tbody>
</table>


<table border="2" style="width: 60%; text-align: center; font-size: 8pt;">
<tbody>
<tr>
<td colspan="4" border="2"><label>DESCRIPTION OF GRADES</label></td>
</tr>
<tr>
<td style="width: 50%; text-align: center;" colspan="2"><?php echo $ccaa1."&nbsp;&dash;&nbsp;".$ccaa3; ?></td>
<td style="width: 50%; text-align: center;" colspan="2"><?php echo $ccaa4."&nbsp;&dash;&nbsp;".$ccaa6; ?></td>
</tr>
<tr >
<td style="width: 25%;">&nbsp;100 -70</td>
<td style="width: 25%;">&nbsp;A</td>
<td style="width: 25%;">&nbsp;100 - 80</td>
<td style="width: 25%;">&nbsp;A1</td>
</tr>
<tr>
<td style="width: 25%;">&nbsp;69 - 60</td>
<td style="width: 25%;">&nbsp;C</td>
<td style="width: 25%;">&nbsp;70 - 79</td>
<td style="width: 25%;">&nbsp;B2</td>
</tr>
<tr style="height: 13px;">
<td style="width: 25%;">&nbsp;59 - 50</td>
<td style="width: 25%;">&nbsp;P</td>
<td style="width: 25%;">&nbsp;65 - 69</td>
<td style="width: 25%;">&nbsp;B3</td>
</tr>
<tr style="height: 13px;">
<td>&nbsp;49 - 0</td>
<td>&nbsp;F</td>
<td>&nbsp;60 - 64</td>
<td>&nbsp;C4</td>
</tr>
<tr style="height: 13px;">
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;55 - 59</td>
<td>&nbsp;C5</td>
</tr>
<tr style="height: 13px;">
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;50 - 54</td>
<td>&nbsp;C6</td>
</tr>
<tr style="height: 13px;">
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;45 - 49</td>
<td>&nbsp;D7</td>
</tr>
<tr style="height: 13px;">
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;40 - 44</td>
<td>&nbsp;E8</td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>0 - 39</td>
<td>F9</td>
</tr>
</tbody>
</table>
</div><br><br>
<!--<button class="pbutton" onclick="printDiv('printMe');">PRINT TRANSCRIPT</button>-->
<form id="transpdfform" style="float: left;">
<input type="text" name="rpic2" value="<?php echo $rpic2; ?>" />
<input type="text" name="stu_name2" value="<?php echo $stu_name2; ?>" />
<input type="text" name="yoa2" value="<?php echo $yoa2; ?>" />
<input type="text" name="maxgrad" value="<?php echo $maxgrad; ?>" />
<input type="text" name="sex2" value="<?php echo $sex2; ?>" />
<input type="text" name="reason2" value="<?php echo $reason2; ?>" />
<input type="text" name="caa2" value="<?php echo $caa2; ?>" />
<input type="text" name="classgrad2" value="<?php echo $classgrad2; ?>" />
<input type="text" name="admno2" value="<?php echo $admno2; ?>" />
<input type="text" name="y7" value="<?php echo $y7;  ?>" /><input type="text" name="y8" value="<?php echo $y8;  ?>" /><input type="text" name="y9" value="<?php echo $y9;  ?>" />
<input type="text" name="y10" value="<?php echo $y10;  ?>" /><input type="text" name="y11" value="<?php echo $y11;  ?>" /><input type="text" name="y12" value="<?php echo $y12;  ?>" />

<input type="text" name="ffengsc71" value="<?php echo $ffengsc71;  ?>" /><input type="text" name="gradeeng71" value="<?php echo $gradeeng71;  ?>" /><input type="text" name="ssengsc72" value="<?php echo $ssengsc72;  ?>" /><input type="text" name="gradeeng72" value="<?php echo $gradeeng72;  ?>" /><input type="text" name="ttengsc73" value="<?php echo $ttengsc73;  ?>" /><input type="text" name="gradeeng73" value="<?php echo $gradeeng73;  ?>" />
<input type="text" name="ffengsc81" value="<?php echo $ffengsc81;  ?>" /><input type="text" name="gradeeng81" value="<?php echo $gradeeng81;  ?>" /><input type="text" name="ssengsc82" value="<?php echo $ssengsc82;  ?>" /><input type="text" name="gradeeng82" value="<?php echo $gradeeng82;  ?>" /><input type="text" name="ttengsc83" value="<?php echo $ttengsc83;  ?>" /><input type="text" name="gradeeng83" value="<?php echo $gradeeng83;  ?>" />
<input type="text" name="ffengsc91" value="<?php echo $ffengsc91;  ?>" /><input type="text" name="gradeeng91" value="<?php echo $gradeeng91;  ?>" /><input type="text" name="ssengsc92" value="<?php echo $ssengsc92;  ?>" /><input type="text" name="gradeeng92" value="<?php echo $gradeeng92;  ?>" /><input type="text" name="ttengsc93" value="<?php echo $ttengsc93;  ?>" /><input type="text" name="gradeeng93" value="<?php echo $gradeeng93;  ?>" />
<input type="text" name="ffengsc101" value="<?php echo $ffengsc101;  ?>" /><input type="text" name="gradeeng101" value="<?php echo $gradeeng101;  ?>" /><input type="text" name="ssengsc102" value="<?php echo $ssengsc102;  ?>" /><input type="text" name="gradeeng102" value="<?php echo $gradeeng102;  ?>" /><input type="text" name="ttengsc103" value="<?php echo $ttengsc103;  ?>" /><input type="text" name="gradeeng103" value="<?php echo $gradeeng103;  ?>" />
<input type="text" name="ffengsc111" value="<?php echo $ffengsc111;  ?>" /><input type="text" name="gradeeng111" value="<?php echo $gradeeng111;  ?>" /><input type="text" name="ssengsc112" value="<?php echo $ssengsc112;  ?>" /><input type="text" name="gradeeng112" value="<?php echo $gradeeng112;  ?>" /><input type="text" name="ttengsc113" value="<?php echo $ttengsc113;  ?>" /><input type="text" name="gradeeng113" value="<?php echo $gradeeng113;  ?>" />
<input type="text" name="ffengsc121" value="<?php echo $ffengsc121;  ?>" /><input type="text" name="gradeeng121" value="<?php echo $gradeeng121;  ?>" /><input type="text" name="ssengsc122" value="<?php echo $ssengsc122;  ?>" /><input type="text" name="gradeeng122" value="<?php echo $gradeeng122;  ?>" /><input type="text" name="ttengsc123" value="<?php echo $ttengsc123;  ?>" /><input type="text" name="gradeeng123" value="<?php echo $gradeeng123;  ?>" />

<input type="text" name="ffmatsc71" value="<?php echo $ffmatsc71;  ?>" /><input type="text" name="grademat71" value="<?php echo $grademat71;  ?>" /><input type="text" name="ssmatsc72" value="<?php echo $ssmatsc72;  ?>" /><input type="text" name="grademat72" value="<?php echo $grademat72;  ?>" /><input type="text" name="ttmatsc73" value="<?php echo $ttmatsc73;  ?>" /><input type="text" name="grademat73" value="<?php echo $grademat73;  ?>" />
<input type="text" name="ffmatsc81" value="<?php echo $ffmatsc81;  ?>" /><input type="text" name="grademat81" value="<?php echo $grademat81;  ?>" /><input type="text" name="ssmatsc82" value="<?php echo $ssmatsc82;  ?>" /><input type="text" name="grademat82" value="<?php echo $grademat82;  ?>" /><input type="text" name="ttmatsc83" value="<?php echo $ttmatsc83;  ?>" /><input type="text" name="grademat83" value="<?php echo $grademat83;  ?>" />
<input type="text" name="ffmatsc91" value="<?php echo $ffmatsc91;  ?>" /><input type="text" name="grademat91" value="<?php echo $grademat91;  ?>" /><input type="text" name="ssmatsc92" value="<?php echo $ssmatsc92;  ?>" /><input type="text" name="grademat92" value="<?php echo $grademat92;  ?>" /><input type="text" name="ttmatsc93" value="<?php echo $ttmatsc93;  ?>" /><input type="text" name="grademat93" value="<?php echo $grademat93;  ?>" />
<input type="text" name="ffmatsc101" value="<?php echo $ffmatsc101;  ?>" /><input type="text" name="grademat101" value="<?php echo $grademat101;  ?>" /><input type="text" name="ssmatsc102" value="<?php echo $ssmatsc102;  ?>" /><input type="text" name="grademat102" value="<?php echo $grademat102;  ?>" /><input type="text" name="ttmatsc103" value="<?php echo $ttmatsc103;  ?>" /><input type="text" name="grademat103" value="<?php echo $grademat103;  ?>" />
<input type="text" name="ffmatsc111" value="<?php echo $ffmatsc111;  ?>" /><input type="text" name="grademat111" value="<?php echo $grademat111;  ?>" /><input type="text" name="ssmatsc112" value="<?php echo $ssmatsc112;  ?>" /><input type="text" name="grademat112" value="<?php echo $grademat112;  ?>" /><input type="text" name="ttmatsc113" value="<?php echo $ttmatsc113;  ?>" /><input type="text" name="grademat113" value="<?php echo $grademat113;  ?>" />
<input type="text" name="ffmatsc121" value="<?php echo $ffmatsc121;  ?>" /><input type="text" name="grademat121" value="<?php echo $grademat121;  ?>" /><input type="text" name="ssmatsc122" value="<?php echo $ssmatsc122;  ?>" /><input type="text" name="grademat122" value="<?php echo $grademat122;  ?>" /><input type="text" name="ttmatsc123" value="<?php echo $ttmatsc123;  ?>" /><input type="text" name="grademat123" value="<?php echo $grademat123;  ?>" />

<input type="text" name="ffagrsc71" value="<?php echo $ffagrsc71;  ?>" /><input type="text" name="gradeagr71" value="<?php echo $gradeagr71;  ?>" /><input type="text" name="ssagrsc72" value="<?php echo $ssagrsc72;  ?>" /><input type="text" name="gradeagr72" value="<?php echo $gradeagr72;  ?>" /><input type="text" name="ttagrsc73" value="<?php echo $ttagrsc73;  ?>" /><input type="text" name="gradeagr73" value="<?php echo $gradeagr73;  ?>" />
<input type="text" name="ffagrsc81" value="<?php echo $ffagrsc81;  ?>" /><input type="text" name="gradeagr81" value="<?php echo $gradeagr81;  ?>" /><input type="text" name="ssagrsc82" value="<?php echo $ssagrsc82;  ?>" /><input type="text" name="gradeagr82" value="<?php echo $gradeagr82;  ?>" /><input type="text" name="ttagrsc83" value="<?php echo $ttagrsc83;  ?>" /><input type="text" name="gradeagr83" value="<?php echo $gradeagr83;  ?>" />
<input type="text" name="ffagrsc91" value="<?php echo $ffagrsc91;  ?>" /><input type="text" name="gradeagr91" value="<?php echo $gradeagr91;  ?>" /><input type="text" name="ssagrsc92" value="<?php echo $ssagrsc92;  ?>" /><input type="text" name="gradeagr92" value="<?php echo $gradeagr92;  ?>" /><input type="text" name="ttagrsc93" value="<?php echo $ttagrsc93;  ?>" /><input type="text" name="gradeagr93" value="<?php echo $gradeagr93;  ?>" />
<input type="text" name="ffagrsc101" value="<?php echo $ffagrsc101;  ?>" /><input type="text" name="gradeagr101" value="<?php echo $gradeagr101;  ?>" /><input type="text" name="ssagrsc102" value="<?php echo $ssagrsc102;  ?>" /><input type="text" name="gradeagr102" value="<?php echo $gradeagr102;  ?>" /><input type="text" name="ttagrsc103" value="<?php echo $ttagrsc103;  ?>" /><input type="text" name="gradeagr103" value="<?php echo $gradeagr103;  ?>" />
<input type="text" name="ffagrsc111" value="<?php echo $ffagrsc111;  ?>" /><input type="text" name="gradeagr111" value="<?php echo $gradeagr111;  ?>" /><input type="text" name="ssagrsc112" value="<?php echo $ssagrsc112;  ?>" /><input type="text" name="gradeagr112" value="<?php echo $gradeagr112;  ?>" /><input type="text" name="ttagrsc113" value="<?php echo $ttagrsc113;  ?>" /><input type="text" name="gradeagr113" value="<?php echo $gradeagr113;  ?>" />
<input type="text" name="ffagrsc121" value="<?php echo $ffagrsc121;  ?>" /><input type="text" name="gradeagr121" value="<?php echo $gradeagr121;  ?>" /><input type="text" name="ssagrsc122" value="<?php echo $ssagrsc122;  ?>" /><input type="text" name="gradeagr122" value="<?php echo $gradeagr122;  ?>" /><input type="text" name="ttagrsc123" value="<?php echo $ttagrsc123;  ?>" /><input type="text" name="gradeagr123" value="<?php echo $gradeagr123;  ?>" />

<input type="text" name="ffbassc71" value="<?php echo $ffbassc71;  ?>" /><input type="text" name="gradebas71" value="<?php echo $gradebas71;  ?>" /><input type="text" name="ssbassc72" value="<?php echo $ssbassc72;  ?>" /><input type="text" name="gradebas72" value="<?php echo $gradebas72;  ?>" /><input type="text" name="ttbassc73" value="<?php echo $ttbassc73;  ?>" /><input type="text" name="gradebas73" value="<?php echo $gradebas73;  ?>" />
<input type="text" name="ffbassc81" value="<?php echo $ffbassc81;  ?>" /><input type="text" name="gradebas81" value="<?php echo $gradebas81;  ?>" /><input type="text" name="ssbassc82" value="<?php echo $ssbassc82;  ?>" /><input type="text" name="gradebas82" value="<?php echo $gradebas82;  ?>" /><input type="text" name="ttbassc83" value="<?php echo $ttbassc83;  ?>" /><input type="text" name="gradebas83" value="<?php echo $gradebas83;  ?>" />
<input type="text" name="ffbassc91" value="<?php echo $ffbassc91;  ?>" /><input type="text" name="gradebas91" value="<?php echo $gradebas91;  ?>" /><input type="text" name="ssbassc92" value="<?php echo $ssbassc92;  ?>" /><input type="text" name="gradebas92" value="<?php echo $gradebas92;  ?>" /><input type="text" name="ttbassc93" value="<?php echo $ttbassc93;  ?>" /><input type="text" name="gradebas93" value="<?php echo $gradebas93;  ?>" />
<input type="text" name="ffbassc101" value="<?php echo $ffbassc101;  ?>" /><input type="text" name="gradebas101" value="<?php echo $gradebas101;  ?>" /><input type="text" name="ssbassc102" value="<?php echo $ssbassc102;  ?>" /><input type="text" name="gradebas102" value="<?php echo $gradebas102;  ?>" /><input type="text" name="ttbassc103" value="<?php echo $ttbassc103;  ?>" /><input type="text" name="gradebas103" value="<?php echo $gradebas103;  ?>" />
<input type="text" name="ffbassc111" value="<?php echo $ffbassc111;  ?>" /><input type="text" name="gradebas111" value="<?php echo $gradebas111;  ?>" /><input type="text" name="ssbassc112" value="<?php echo $ssbassc112;  ?>" /><input type="text" name="gradebas112" value="<?php echo $gradebas112;  ?>" /><input type="text" name="ttbassc113" value="<?php echo $ttbassc113;  ?>" /><input type="text" name="gradebas113" value="<?php echo $gradebas113;  ?>" />
<input type="text" name="ffbassc121" value="<?php echo $ffbassc121;  ?>" /><input type="text" name="gradebas121" value="<?php echo $gradebas121;  ?>" /><input type="text" name="ssbassc122" value="<?php echo $ssbassc122;  ?>" /><input type="text" name="gradebas122" value="<?php echo $gradebas122;  ?>" /><input type="text" name="ttbassc123" value="<?php echo $ttbassc123;  ?>" /><input type="text" name="gradebas123" value="<?php echo $gradebas123;  ?>" />

<input type="text" name="ffcatsc71" value="<?php echo $ffcatsc71;  ?>" /><input type="text" name="gradecat71" value="<?php echo $gradecat71;  ?>" /><input type="text" name="sscatsc72" value="<?php echo $sscatsc72;  ?>" /><input type="text" name="gradecat72" value="<?php echo $gradecat72;  ?>" /><input type="text" name="ttcatsc73" value="<?php echo $ttcatsc73;  ?>" /><input type="text" name="gradecat73" value="<?php echo $gradecat73;  ?>" />
<input type="text" name="ffcatsc81" value="<?php echo $ffcatsc81;  ?>" /><input type="text" name="gradecat81" value="<?php echo $gradecat81;  ?>" /><input type="text" name="sscatsc82" value="<?php echo $sscatsc82;  ?>" /><input type="text" name="gradecat82" value="<?php echo $gradecat82;  ?>" /><input type="text" name="ttcatsc83" value="<?php echo $ttcatsc83;  ?>" /><input type="text" name="gradecat83" value="<?php echo $gradecat83;  ?>" />
<input type="text" name="ffcatsc91" value="<?php echo $ffcatsc91;  ?>" /><input type="text" name="gradecat91" value="<?php echo $gradecat91;  ?>" /><input type="text" name="sscatsc92" value="<?php echo $sscatsc92;  ?>" /><input type="text" name="gradecat92" value="<?php echo $gradecat92;  ?>" /><input type="text" name="ttcatsc93" value="<?php echo $ttcatsc93;  ?>" /><input type="text" name="gradecat93" value="<?php echo $gradecat93;  ?>" />
<input type="text" name="ffcatsc101" value="<?php echo $ffcatsc101;  ?>" /><input type="text" name="gradecat101" value="<?php echo $gradecat101;  ?>" /><input type="text" name="sscatsc102" value="<?php echo $sscatsc102;  ?>" /><input type="text" name="gradecat102" value="<?php echo $gradecat102;  ?>" /><input type="text" name="ttcatsc103" value="<?php echo $ttcatsc103;  ?>" /><input type="text" name="gradecat103" value="<?php echo $gradecat103;  ?>" />
<input type="text" name="ffcatsc111" value="<?php echo $ffcatsc111;  ?>" /><input type="text" name="gradecat111" value="<?php echo $gradecat111;  ?>" /><input type="text" name="sscatsc112" value="<?php echo $sscatsc112;  ?>" /><input type="text" name="gradecat112" value="<?php echo $gradecat112;  ?>" /><input type="text" name="ttcatsc113" value="<?php echo $ttcatsc113;  ?>" /><input type="text" name="gradecat113" value="<?php echo $gradecat113;  ?>" />
<input type="text" name="ffcatsc121" value="<?php echo $ffcatsc121;  ?>" /><input type="text" name="gradecat121" value="<?php echo $gradecat121;  ?>" /><input type="text" name="sscatsc122" value="<?php echo $sscatsc122;  ?>" /><input type="text" name="gradecat122" value="<?php echo $gradecat122;  ?>" /><input type="text" name="ttcatsc123" value="<?php echo $ttcatsc123;  ?>" /><input type="text" name="gradecat123" value="<?php echo $gradecat123;  ?>" />

<input type="text" name="ffcivscore71" value="<?php echo $ffcivscore71;  ?>" /><input type="text" name="gradeciv71" value="<?php echo $gradeciv71;  ?>" /><input type="text" name="sscivscore72" value="<?php echo $sscivscore72;  ?>" /><input type="text" name="gradeciv72" value="<?php echo $gradeciv72;  ?>" /><input type="text" name="ttcivscore73" value="<?php echo $ttcivscore73;  ?>" /><input type="text" name="gradeciv73" value="<?php echo $gradeciv73;  ?>" />
<input type="text" name="ffcivscore81" value="<?php echo $ffcivscore81;  ?>" /><input type="text" name="gradeciv81" value="<?php echo $gradeciv81;  ?>" /><input type="text" name="sscivscore82" value="<?php echo $sscivscore82;  ?>" /><input type="text" name="gradeciv82" value="<?php echo $gradeciv82;  ?>" /><input type="text" name="ttcivscore83" value="<?php echo $ttcivscore83;  ?>" /><input type="text" name="gradeciv83" value="<?php echo $gradeciv83;  ?>" />
<input type="text" name="ffcivscore91" value="<?php echo $ffcivscore91;  ?>" /><input type="text" name="gradeciv91" value="<?php echo $gradeciv91;  ?>" /><input type="text" name="sscivscore92" value="<?php echo $sscivscore92;  ?>" /><input type="text" name="gradeciv92" value="<?php echo $gradeciv92;  ?>" /><input type="text" name="ttcivscore93" value="<?php echo $ttcivscore93;  ?>" /><input type="text" name="gradeciv93" value="<?php echo $gradeciv93;  ?>" />
<input style="background-color:orange;" type="text" name="ffcivscore101" value="<?php echo $ffcivscore101;  ?>" /><input type="text" name="gradeciv101" value="<?php echo $gradeciv101;  ?>" /><input style="background-color:orange;"  type="text" name="sscivscore102" value="<?php echo $sscivscore102;  ?>" /><input type="text" name="gradeciv102" value="<?php echo $gradeciv102;  ?>" /><input type="text" name="ttcivscore103" value="<?php echo $ttcivscore103;  ?>" /><input type="text" name="gradeciv103" value="<?php echo $gradeciv103;  ?>" />
<input type="text" name="ffcivscore111" value="<?php echo $ffcivscore111;  ?>" /><input type="text" name="gradeciv111" value="<?php echo $gradeciv111;  ?>" /><input type="text" name="sscivscore112" value="<?php echo $sscivscore112;  ?>" /><input type="text" name="gradeciv112" value="<?php echo $gradeciv112;  ?>" /><input type="text" name="ttcivscore113" value="<?php echo $ttcivscore113;  ?>" /><input type="text" name="gradeciv113" value="<?php echo $gradeciv113;  ?>" />
<input type="text" name="ffcivscore121" value="<?php echo $ffcivscore121;  ?>" /><input type="text" name="gradeciv121" value="<?php echo $gradeciv121;  ?>" /><input type="text" name="sscivscore122" value="<?php echo $sscivscore122;  ?>" /><input type="text" name="gradeciv122" value="<?php echo $gradeciv122;  ?>" /><input type="text" name="ttcivscore123" value="<?php echo $ttcivscore123;  ?>" /><input type="text" name="gradeciv123" value="<?php echo $gradeciv123;  ?>" />

<input type="text" name="ffcrkscore71" value="<?php echo $ffcrkscore71;  ?>" /><input type="text" name="gradecrk71" value="<?php echo $gradecrk71;  ?>" /><input type="text" name="sscrkscore72" value="<?php echo $sscrkscore72;  ?>" /><input type="text" name="gradecrk72" value="<?php echo $gradecrk72;  ?>" /><input type="text" name="ttcrkscore73" value="<?php echo $ttcrkscore73;  ?>" /><input type="text" name="gradecrk73" value="<?php echo $gradecrk73;  ?>" />
<input type="text" name="ffcrkscore81" value="<?php echo $ffcrkscore81;  ?>" /><input type="text" name="gradecrk81" value="<?php echo $gradecrk81;  ?>" /><input type="text" name="sscrkscore82" value="<?php echo $sscrkscore82;  ?>" /><input type="text" name="gradecrk82" value="<?php echo $gradecrk82;  ?>" /><input type="text" name="ttcrkscore83" value="<?php echo $ttcrkscore83;  ?>" /><input type="text" name="gradecrk83" value="<?php echo $gradecrk83;  ?>" />
<input type="text" name="ffcrkscore91" value="<?php echo $ffcrkscore91;  ?>" /><input type="text" name="gradecrk91" value="<?php echo $gradecrk91;  ?>" /><input type="text" name="sscrkscore92" value="<?php echo $sscrkscore92;  ?>" /><input type="text" name="gradecrk92" value="<?php echo $gradecrk92;  ?>" /><input type="text" name="ttcrkscore93" value="<?php echo $ttcrkscore93;  ?>" /><input type="text" name="gradecrk93" value="<?php echo $gradecrk93;  ?>" />
<input style="background-color:orange;" type="text" name="ffcrkscore101" value="<?php echo $ffcrkscore101;  ?>" /><input type="text" name="gradecrk101" value="<?php echo $gradecrk101;  ?>" /><input style="background-color:orange;"  type="text" name="sscrkscore102" value="<?php echo $sscrkscore102;  ?>" /><input type="text" name="gradecrk102" value="<?php echo $gradecrk102;  ?>" /><input type="text" name="ttcrkscore103" value="<?php echo $ttcrkscore103;  ?>" /><input type="text" name="gradecrk103" value="<?php echo $gradecrk103;  ?>" />
<input type="text" name="ffcrkscore111" value="<?php echo $ffcrkscore111;  ?>" /><input type="text" name="gradecrk111" value="<?php echo $gradecrk111;  ?>" /><input type="text" name="sscrkscore112" value="<?php echo $sscrkscore112;  ?>" /><input type="text" name="gradecrk112" value="<?php echo $gradecrk112;  ?>" /><input type="text" name="ttcrkscore113" value="<?php echo $ttcrkscore113;  ?>" /><input type="text" name="gradecrk113" value="<?php echo $gradecrk113;  ?>" />
<input type="text" name="ffcrkscore121" value="<?php echo $ffcrkscore121;  ?>" /><input type="text" name="gradecrk121" value="<?php echo $gradecrk121;  ?>" /><input type="text" name="sscrkscore122" value="<?php echo $sscrkscore122;  ?>" /><input type="text" name="gradecrk122" value="<?php echo $gradecrk122;  ?>" /><input type="text" name="ttcrkscore123" value="<?php echo $ttcrkscore123;  ?>" /><input type="text" name="gradecrk123" value="<?php echo $gradecrk123;  ?>" />

<input type="text" name="ffcrescore71" value="<?php echo $ffcrescore71;  ?>" /><input type="text" name="gradecre71" value="<?php echo $gradecre71;  ?>" /><input type="text" name="sscrescore72" value="<?php echo $sscrescore72;  ?>" /><input type="text" name="gradecre72" value="<?php echo $gradecre72;  ?>" /><input type="text" name="ttcrescore73" value="<?php echo $ttcrescore73;  ?>" /><input type="text" name="gradecre73" value="<?php echo $gradecre73;  ?>" />
<input type="text" name="ffcrescore81" value="<?php echo $ffcrescore81;  ?>" /><input type="text" name="gradecre81" value="<?php echo $gradecre81;  ?>" /><input type="text" name="sscrescore82" value="<?php echo $sscrescore82;  ?>" /><input type="text" name="gradecre82" value="<?php echo $gradecre82;  ?>" /><input type="text" name="ttcrescore83" value="<?php echo $ttcrescore83;  ?>" /><input type="text" name="gradecre83" value="<?php echo $gradecre83;  ?>" />
<input type="text" name="ffcrescore91" value="<?php echo $ffcrescore91;  ?>" /><input type="text" name="gradecre91" value="<?php echo $gradecre91;  ?>" /><input type="text" name="sscrescore92" value="<?php echo $sscrescore92;  ?>" /><input type="text" name="gradecre92" value="<?php echo $gradecre92;  ?>" /><input type="text" name="ttcrescore93" value="<?php echo $ttcrescore93;  ?>" /><input type="text" name="gradecre93" value="<?php echo $gradecre93;  ?>" />
<input style="background-color:orange;" type="text" name="ffcrescore101" value="<?php echo $ffcrescore101;  ?>" /><input type="text" name="gradecre101" value="<?php echo $gradecre101;  ?>" /><input style="background-color:orange;"  type="text" name="sscrescore102" value="<?php echo $sscrescore102;  ?>" /><input type="text" name="gradecre102" value="<?php echo $gradecre102;  ?>" /><input type="text" name="ttcrescore103" value="<?php echo $ttcrescore103;  ?>" /><input type="text" name="gradecre103" value="<?php echo $gradecre103;  ?>" />
<input type="text" name="ffcrescore111" value="<?php echo $ffcrescore111;  ?>" /><input type="text" name="gradecre111" value="<?php echo $gradecre111;  ?>" /><input type="text" name="sscrescore112" value="<?php echo $sscrescore112;  ?>" /><input type="text" name="gradecre112" value="<?php echo $gradecre112;  ?>" /><input type="text" name="ttcrescore113" value="<?php echo $ttcrescore113;  ?>" /><input type="text" name="gradecre113" value="<?php echo $gradecre113;  ?>" />
<input type="text" name="ffcrescore121" value="<?php echo $ffcrescore121;  ?>" /><input type="text" name="gradecre121" value="<?php echo $gradecre121;  ?>" /><input type="text" name="sscrescore122" value="<?php echo $sscrescore122;  ?>" /><input type="text" name="gradecre122" value="<?php echo $gradecre122;  ?>" /><input type="text" name="ttcrescore123" value="<?php echo $ttcrescore123;  ?>" /><input type="text" name="gradecre123" value="<?php echo $gradecre123;  ?>" />

<input type="text" name="fffooscore71" value="<?php echo $fffooscore71;  ?>" /><input type="text" name="gradefoo71" value="<?php echo $gradefoo71;  ?>" /><input type="text" name="ssfooscore72" value="<?php echo $ssfooscore72;  ?>" /><input type="text" name="gradefoo72" value="<?php echo $gradefoo72;  ?>" /><input type="text" name="ttfooscore73" value="<?php echo $ttfooscore73;  ?>" /><input type="text" name="gradefoo73" value="<?php echo $gradefoo73;  ?>" />
<input type="text" name="fffooscore81" value="<?php echo $fffooscore81;  ?>" /><input type="text" name="gradefoo81" value="<?php echo $gradefoo81;  ?>" /><input type="text" name="ssfooscore82" value="<?php echo $ssfooscore82;  ?>" /><input type="text" name="gradefoo82" value="<?php echo $gradefoo82;  ?>" /><input type="text" name="ttfooscore83" value="<?php echo $ttfooscore83;  ?>" /><input type="text" name="gradefoo83" value="<?php echo $gradefoo83;  ?>" />
<input type="text" name="fffooscore91" value="<?php echo $fffooscore91;  ?>" /><input type="text" name="gradefoo91" value="<?php echo $gradefoo91;  ?>" /><input type="text" name="ssfooscore92" value="<?php echo $ssfooscore92;  ?>" /><input type="text" name="gradefoo92" value="<?php echo $gradefoo92;  ?>" /><input type="text" name="ttfooscore93" value="<?php echo $ttfooscore93;  ?>" /><input type="text" name="gradefoo93" value="<?php echo $gradefoo93;  ?>" />
<input style="background-color:orange;" type="text" name="fffooscore101" value="<?php echo $fffooscore101;  ?>" /><input type="text" name="gradefoo101" value="<?php echo $gradefoo101;  ?>" /><input style="background-color:orange;"  type="text" name="ssfooscore102" value="<?php echo $ssfooscore102;  ?>" /><input type="text" name="gradefoo102" value="<?php echo $gradefoo102;  ?>" /><input type="text" name="ttfooscore103" value="<?php echo $ttfooscore103;  ?>" /><input type="text" name="gradefoo103" value="<?php echo $gradefoo103;  ?>" />
<input type="text" name="fffooscore111" value="<?php echo $fffooscore111;  ?>" /><input type="text" name="gradefoo111" value="<?php echo $gradefoo111;  ?>" /><input type="text" name="ssfooscore112" value="<?php echo $ssfooscore112;  ?>" /><input type="text" name="gradefoo112" value="<?php echo $gradefoo112;  ?>" /><input type="text" name="ttfooscore113" value="<?php echo $ttfooscore113;  ?>" /><input type="text" name="gradefoo113" value="<?php echo $gradefoo113;  ?>" />
<input type="text" name="fffooscore121" value="<?php echo $fffooscore121;  ?>" /><input type="text" name="gradefoo121" value="<?php echo $gradefoo121;  ?>" /><input type="text" name="ssfooscore122" value="<?php echo $ssfooscore122;  ?>" /><input type="text" name="gradefoo122" value="<?php echo $gradefoo122;  ?>" /><input type="text" name="ttfooscore123" value="<?php echo $ttfooscore123;  ?>" /><input type="text" name="gradefoo123" value="<?php echo $gradefoo123;  ?>" />

<input type="text" name="fffrescore71" value="<?php echo $fffrescore71;  ?>" /><input type="text" name="gradefre71" value="<?php echo $gradefre71;  ?>" /><input type="text" name="ssfrescore72" value="<?php echo $ssfrescore72;  ?>" /><input type="text" name="gradefre72" value="<?php echo $gradefre72;  ?>" /><input type="text" name="ttfrescore73" value="<?php echo $ttfrescore73;  ?>" /><input type="text" name="gradefre73" value="<?php echo $gradefre73;  ?>" />
<input type="text" name="fffrescore81" value="<?php echo $fffrescore81;  ?>" /><input type="text" name="gradefre81" value="<?php echo $gradefre81;  ?>" /><input type="text" name="ssfrescore82" value="<?php echo $ssfrescore82;  ?>" /><input type="text" name="gradefre82" value="<?php echo $gradefre82;  ?>" /><input type="text" name="ttfrescore83" value="<?php echo $ttfrescore83;  ?>" /><input type="text" name="gradefre83" value="<?php echo $gradefre83;  ?>" />
<input type="text" name="fffrescore91" value="<?php echo $fffrescore91;  ?>" /><input type="text" name="gradefre91" value="<?php echo $gradefre91;  ?>" /><input type="text" name="ssfrescore92" value="<?php echo $ssfrescore92;  ?>" /><input type="text" name="gradefre92" value="<?php echo $gradefre92;  ?>" /><input type="text" name="ttfrescore93" value="<?php echo $ttfrescore93;  ?>" /><input type="text" name="gradefre93" value="<?php echo $gradefre93;  ?>" />
<input style="background-color:orange;" type="text" name="fffrescore101" value="<?php echo $fffrescore101;  ?>" /><input type="text" name="gradefre101" value="<?php echo $gradefre101;  ?>" /><input style="background-color:orange;"  type="text" name="ssfrescore102" value="<?php echo $ssfrescore102;  ?>" /><input type="text" name="gradefre102" value="<?php echo $gradefre102;  ?>" /><input type="text" name="ttfrescore103" value="<?php echo $ttfrescore103;  ?>" /><input type="text" name="gradefre103" value="<?php echo $gradefre103;  ?>" />
<input type="text" name="fffrescore111" value="<?php echo $fffrescore111;  ?>" /><input type="text" name="gradefre111" value="<?php echo $gradefre111;  ?>" /><input type="text" name="ssfrescore112" value="<?php echo $ssfrescore112;  ?>" /><input type="text" name="gradefre112" value="<?php echo $gradefre112;  ?>" /><input type="text" name="ttfrescore113" value="<?php echo $ttfrescore113;  ?>" /><input type="text" name="gradefre113" value="<?php echo $gradefre113;  ?>" />
<input type="text" name="fffrescore121" value="<?php echo $fffrescore121;  ?>" /><input type="text" name="gradefre121" value="<?php echo $gradefre121;  ?>" /><input type="text" name="ssfrescore122" value="<?php echo $ssfrescore122;  ?>" /><input type="text" name="gradefre122" value="<?php echo $gradefre122;  ?>" /><input type="text" name="ttfrescore123" value="<?php echo $ttfrescore123;  ?>" /><input type="text" name="gradefre123" value="<?php echo $gradefre123;  ?>" />

<input type="text" name="ffhauscore71" value="<?php echo $ffhauscore71;  ?>" /><input type="text" name="gradehau71" value="<?php echo $gradehau71;  ?>" /><input type="text" name="sshauscore72" value="<?php echo $sshauscore72;  ?>" /><input type="text" name="gradehau72" value="<?php echo $gradehau72;  ?>" /><input type="text" name="tthauscore73" value="<?php echo $tthauscore73;  ?>" /><input type="text" name="gradehau73" value="<?php echo $gradehau73;  ?>" />
<input type="text" name="ffhauscore81" value="<?php echo $ffhauscore81;  ?>" /><input type="text" name="gradehau81" value="<?php echo $gradehau81;  ?>" /><input type="text" name="sshauscore82" value="<?php echo $sshauscore82;  ?>" /><input type="text" name="gradehau82" value="<?php echo $gradehau82;  ?>" /><input type="text" name="tthauscore83" value="<?php echo $tthauscore83;  ?>" /><input type="text" name="gradehau83" value="<?php echo $gradehau83;  ?>" />
<input type="text" name="ffhauscore91" value="<?php echo $ffhauscore91;  ?>" /><input type="text" name="gradehau91" value="<?php echo $gradehau91;  ?>" /><input type="text" name="sshauscore92" value="<?php echo $sshauscore92;  ?>" /><input type="text" name="gradehau92" value="<?php echo $gradehau92;  ?>" /><input type="text" name="tthauscore93" value="<?php echo $tthauscore93;  ?>" /><input type="text" name="gradehau93" value="<?php echo $gradehau93;  ?>" />
<input style="background-color:orange;" type="text" name="ffhauscore101" value="<?php echo $ffhauscore101;  ?>" /><input type="text" name="gradehau101" value="<?php echo $gradehau101;  ?>" /><input style="background-color:orange;"  type="text" name="sshauscore102" value="<?php echo $sshauscore102;  ?>" /><input type="text" name="gradehau102" value="<?php echo $gradehau102;  ?>" /><input type="text" name="tthauscore103" value="<?php echo $tthauscore103;  ?>" /><input type="text" name="gradehau103" value="<?php echo $gradehau103;  ?>" />
<input type="text" name="ffhauscore111" value="<?php echo $ffhauscore111;  ?>" /><input type="text" name="gradehau111" value="<?php echo $gradehau111;  ?>" /><input type="text" name="sshauscore112" value="<?php echo $sshauscore112;  ?>" /><input type="text" name="gradehau112" value="<?php echo $gradehau112;  ?>" /><input type="text" name="tthauscore113" value="<?php echo $tthauscore113;  ?>" /><input type="text" name="gradehau113" value="<?php echo $gradehau113;  ?>" />
<input type="text" name="ffhauscore121" value="<?php echo $ffhauscore121;  ?>" /><input type="text" name="gradehau121" value="<?php echo $gradehau121;  ?>" /><input type="text" name="sshauscore122" value="<?php echo $sshauscore122;  ?>" /><input type="text" name="gradehau122" value="<?php echo $gradehau122;  ?>" /><input type="text" name="tthauscore123" value="<?php echo $tthauscore123;  ?>" /><input type="text" name="gradehau123" value="<?php echo $gradehau123;  ?>" />

<input type="text" name="ffictscore71" value="<?php echo $ffictscore71;  ?>" /><input type="text" name="gradeict71" value="<?php echo $gradeict71;  ?>" /><input type="text" name="ssictscore72" value="<?php echo $ssictscore72;  ?>" /><input type="text" name="gradeict72" value="<?php echo $gradeict72;  ?>" /><input type="text" name="ttictscore73" value="<?php echo $ttictscore73;  ?>" /><input type="text" name="gradeict73" value="<?php echo $gradeict73;  ?>" />
<input type="text" name="ffictscore81" value="<?php echo $ffictscore81;  ?>" /><input type="text" name="gradeict81" value="<?php echo $gradeict81;  ?>" /><input type="text" name="ssictscore82" value="<?php echo $ssictscore82;  ?>" /><input type="text" name="gradeict82" value="<?php echo $gradeict82;  ?>" /><input type="text" name="ttictscore83" value="<?php echo $ttictscore83;  ?>" /><input type="text" name="gradeict83" value="<?php echo $gradeict83;  ?>" />
<input type="text" name="ffictscore91" value="<?php echo $ffictscore91;  ?>" /><input type="text" name="gradeict91" value="<?php echo $gradeict91;  ?>" /><input type="text" name="ssictscore92" value="<?php echo $ssictscore92;  ?>" /><input type="text" name="gradeict92" value="<?php echo $gradeict92;  ?>" /><input type="text" name="ttictscore93" value="<?php echo $ttictscore93;  ?>" /><input type="text" name="gradeict93" value="<?php echo $gradeict93;  ?>" />
<input style="background-color:orange;" type="text" name="ffictscore101" value="<?php echo $ffictscore101;  ?>" /><input type="text" name="gradeict101" value="<?php echo $gradeict101;  ?>" /><input style="background-color:orange;"  type="text" name="ssictscore102" value="<?php echo $ssictscore102;  ?>" /><input type="text" name="gradeict102" value="<?php echo $gradeict102;  ?>" /><input type="text" name="ttictscore103" value="<?php echo $ttictscore103;  ?>" /><input type="text" name="gradeict103" value="<?php echo $gradeict103;  ?>" />
<input type="text" name="ffictscore111" value="<?php echo $ffictscore111;  ?>" /><input type="text" name="gradeict111" value="<?php echo $gradeict111;  ?>" /><input type="text" name="ssictscore112" value="<?php echo $ssictscore112;  ?>" /><input type="text" name="gradeict112" value="<?php echo $gradeict112;  ?>" /><input type="text" name="ttictscore113" value="<?php echo $ttictscore113;  ?>" /><input type="text" name="gradeict113" value="<?php echo $gradeict113;  ?>" />
<input type="text" name="ffictscore121" value="<?php echo $ffictscore121;  ?>" /><input type="text" name="gradeict121" value="<?php echo $gradeict121;  ?>" /><input type="text" name="ssictscore122" value="<?php echo $ssictscore122;  ?>" /><input type="text" name="gradeict122" value="<?php echo $gradeict122;  ?>" /><input type="text" name="ttictscore123" value="<?php echo $ttictscore123;  ?>" /><input type="text" name="gradeict123" value="<?php echo $gradeict123;  ?>" />

<input type="text" name="ffigbscore71" value="<?php echo $ffigbscore71;  ?>" /><input type="text" name="gradeigb71" value="<?php echo $gradeigb71;  ?>" /><input type="text" name="ssigbscore72" value="<?php echo $ssigbscore72;  ?>" /><input type="text" name="gradeigb72" value="<?php echo $gradeigb72;  ?>" /><input type="text" name="ttigbscore73" value="<?php echo $ttigbscore73;  ?>" /><input type="text" name="gradeigb73" value="<?php echo $gradeigb73;  ?>" />
<input type="text" name="ffigbscore81" value="<?php echo $ffigbscore81;  ?>" /><input type="text" name="gradeigb81" value="<?php echo $gradeigb81;  ?>" /><input type="text" name="ssigbscore82" value="<?php echo $ssigbscore82;  ?>" /><input type="text" name="gradeigb82" value="<?php echo $gradeigb82;  ?>" /><input type="text" name="ttigbscore83" value="<?php echo $ttigbscore83;  ?>" /><input type="text" name="gradeigb83" value="<?php echo $gradeigb83;  ?>" />
<input type="text" name="ffigbscore91" value="<?php echo $ffigbscore91;  ?>" /><input type="text" name="gradeigb91" value="<?php echo $gradeigb91;  ?>" /><input type="text" name="ssigbscore92" value="<?php echo $ssigbscore92;  ?>" /><input type="text" name="gradeigb92" value="<?php echo $gradeigb92;  ?>" /><input type="text" name="ttigbscore93" value="<?php echo $ttigbscore93;  ?>" /><input type="text" name="gradeigb93" value="<?php echo $gradeigb93;  ?>" />
<input style="background-color:orange;" type="text" name="ffigbscore101" value="<?php echo $ffigbscore101;  ?>" /><input type="text" name="gradeigb101" value="<?php echo $gradeigb101;  ?>" /><input style="background-color:orange;"  type="text" name="ssigbscore102" value="<?php echo $ssigbscore102;  ?>" /><input type="text" name="gradeigb102" value="<?php echo $gradeigb102;  ?>" /><input type="text" name="ttigbscore103" value="<?php echo $ttigbscore103;  ?>" /><input type="text" name="gradeigb103" value="<?php echo $gradeigb103;  ?>" />
<input type="text" name="ffigbscore111" value="<?php echo $ffigbscore111;  ?>" /><input type="text" name="gradeigb111" value="<?php echo $gradeigb111;  ?>" /><input type="text" name="ssigbscore112" value="<?php echo $ssigbscore112;  ?>" /><input type="text" name="gradeigb112" value="<?php echo $gradeigb112;  ?>" /><input type="text" name="ttigbscore113" value="<?php echo $ttigbscore113;  ?>" /><input type="text" name="gradeigb113" value="<?php echo $gradeigb113;  ?>" />
<input type="text" name="ffigbscore121" value="<?php echo $ffigbscore121;  ?>" /><input type="text" name="gradeigb121" value="<?php echo $gradeigb121;  ?>" /><input type="text" name="ssigbscore122" value="<?php echo $ssigbscore122;  ?>" /><input type="text" name="gradeigb122" value="<?php echo $gradeigb122;  ?>" /><input type="text" name="ttigbscore123" value="<?php echo $ttigbscore123;  ?>" /><input type="text" name="gradeigb123" value="<?php echo $gradeigb123;  ?>" />

<input type="text" name="ffmusscore71" value="<?php echo $ffmusscore71;  ?>" /><input type="text" name="grademus71" value="<?php echo $grademus71;  ?>" /><input type="text" name="ssmusscore72" value="<?php echo $ssmusscore72;  ?>" /><input type="text" name="grademus72" value="<?php echo $grademus72;  ?>" /><input type="text" name="ttmusscore73" value="<?php echo $ttmusscore73;  ?>" /><input type="text" name="grademus73" value="<?php echo $grademus73;  ?>" />
<input type="text" name="ffmusscore81" value="<?php echo $ffmusscore81;  ?>" /><input type="text" name="grademus81" value="<?php echo $grademus81;  ?>" /><input type="text" name="ssmusscore82" value="<?php echo $ssmusscore82;  ?>" /><input type="text" name="grademus82" value="<?php echo $grademus82;  ?>" /><input type="text" name="ttmusscore83" value="<?php echo $ttmusscore83;  ?>" /><input type="text" name="grademus83" value="<?php echo $grademus83;  ?>" />
<input type="text" name="ffmusscore91" value="<?php echo $ffmusscore91;  ?>" /><input type="text" name="grademus91" value="<?php echo $grademus91;  ?>" /><input type="text" name="ssmusscore92" value="<?php echo $ssmusscore92;  ?>" /><input type="text" name="grademus92" value="<?php echo $grademus92;  ?>" /><input type="text" name="ttmusscore93" value="<?php echo $ttmusscore93;  ?>" /><input type="text" name="grademus93" value="<?php echo $grademus93;  ?>" />
<input style="background-color:orange;" type="text" name="ffmusscore101" value="<?php echo $ffmusscore101;  ?>" /><input type="text" name="grademus101" value="<?php echo $grademus101;  ?>" /><input style="background-color:orange;"  type="text" name="ssmusscore102" value="<?php echo $ssmusscore102;  ?>" /><input type="text" name="grademus102" value="<?php echo $grademus102;  ?>" /><input type="text" name="ttmusscore103" value="<?php echo $ttmusscore103;  ?>" /><input type="text" name="grademus103" value="<?php echo $grademus103;  ?>" />
<input type="text" name="ffmusscore111" value="<?php echo $ffmusscore111;  ?>" /><input type="text" name="grademus111" value="<?php echo $grademus111;  ?>" /><input type="text" name="ssmusscore112" value="<?php echo $ssmusscore112;  ?>" /><input type="text" name="grademus112" value="<?php echo $grademus112;  ?>" /><input type="text" name="ttmusscore113" value="<?php echo $ttmusscore113;  ?>" /><input type="text" name="grademus113" value="<?php echo $grademus113;  ?>" />
<input type="text" name="ffmusscore121" value="<?php echo $ffmusscore121;  ?>" /><input type="text" name="grademus121" value="<?php echo $grademus121;  ?>" /><input type="text" name="ssmusscore122" value="<?php echo $ssmusscore122;  ?>" /><input type="text" name="grademus122" value="<?php echo $grademus122;  ?>" /><input type="text" name="ttmusscore123" value="<?php echo $ttmusscore123;  ?>" /><input type="text" name="grademus123" value="<?php echo $grademus123;  ?>" />

<input type="text" name="ffphescore71" value="<?php echo $ffphescore71;  ?>" /><input type="text" name="gradephe71" value="<?php echo $gradephe71;  ?>" /><input type="text" name="ssphescore72" value="<?php echo $ssphescore72;  ?>" /><input type="text" name="gradephe72" value="<?php echo $gradephe72;  ?>" /><input type="text" name="ttphescore73" value="<?php echo $ttphescore73;  ?>" /><input type="text" name="gradephe73" value="<?php echo $gradephe73;  ?>" />
<input type="text" name="ffphescore81" value="<?php echo $ffphescore81;  ?>" /><input type="text" name="gradephe81" value="<?php echo $gradephe81;  ?>" /><input type="text" name="ssphescore82" value="<?php echo $ssphescore82;  ?>" /><input type="text" name="gradephe82" value="<?php echo $gradephe82;  ?>" /><input type="text" name="ttphescore83" value="<?php echo $ttphescore83;  ?>" /><input type="text" name="gradephe83" value="<?php echo $gradephe83;  ?>" />
<input type="text" name="ffphescore91" value="<?php echo $ffphescore91;  ?>" /><input type="text" name="gradephe91" value="<?php echo $gradephe91;  ?>" /><input type="text" name="ssphescore92" value="<?php echo $ssphescore92;  ?>" /><input type="text" name="gradephe92" value="<?php echo $gradephe92;  ?>" /><input type="text" name="ttphescore93" value="<?php echo $ttphescore93;  ?>" /><input type="text" name="gradephe93" value="<?php echo $gradephe93;  ?>" />
<input style="background-color:orange;" type="text" name="ffphescore101" value="<?php echo $ffphescore101;  ?>" /><input type="text" name="gradephe101" value="<?php echo $gradephe101;  ?>" /><input style="background-color:orange;"  type="text" name="ssphescore102" value="<?php echo $ssphescore102;  ?>" /><input type="text" name="gradephe102" value="<?php echo $gradephe102;  ?>" /><input type="text" name="ttphescore103" value="<?php echo $ttphescore103;  ?>" /><input type="text" name="gradephe103" value="<?php echo $gradephe103;  ?>" />
<input type="text" name="ffphescore111" value="<?php echo $ffphescore111;  ?>" /><input type="text" name="gradephe111" value="<?php echo $gradephe111;  ?>" /><input type="text" name="ssphescore112" value="<?php echo $ssphescore112;  ?>" /><input type="text" name="gradephe112" value="<?php echo $gradephe112;  ?>" /><input type="text" name="ttphescore113" value="<?php echo $ttphescore113;  ?>" /><input type="text" name="gradephe113" value="<?php echo $gradephe113;  ?>" />
<input type="text" name="ffphescore121" value="<?php echo $ffphescore121;  ?>" /><input type="text" name="gradephe121" value="<?php echo $gradephe121;  ?>" /><input type="text" name="ssphescore122" value="<?php echo $ssphescore122;  ?>" /><input type="text" name="gradephe122" value="<?php echo $gradephe122;  ?>" /><input type="text" name="ttphescore123" value="<?php echo $ttphescore123;  ?>" /><input type="text" name="gradephe123" value="<?php echo $gradephe123;  ?>" />

<input type="text" name="ffyorscore71" value="<?php echo $ffyorscore71;  ?>" /><input type="text" name="gradeyor71" value="<?php echo $gradeyor71;  ?>" /><input type="text" name="ssyorscore72" value="<?php echo $ssyorscore72;  ?>" /><input type="text" name="gradeyor72" value="<?php echo $gradeyor72;  ?>" /><input type="text" name="ttyorscore73" value="<?php echo $ttyorscore73;  ?>" /><input type="text" name="gradeyor73" value="<?php echo $gradeyor73;  ?>" />
<input type="text" name="ffyorscore81" value="<?php echo $ffyorscore81;  ?>" /><input type="text" name="gradeyor81" value="<?php echo $gradeyor81;  ?>" /><input type="text" name="ssyorscore82" value="<?php echo $ssyorscore82;  ?>" /><input type="text" name="gradeyor82" value="<?php echo $gradeyor82;  ?>" /><input type="text" name="ttyorscore83" value="<?php echo $ttyorscore83;  ?>" /><input type="text" name="gradeyor83" value="<?php echo $gradeyor83;  ?>" />
<input type="text" name="ffyorscore91" value="<?php echo $ffyorscore91;  ?>" /><input type="text" name="gradeyor91" value="<?php echo $gradeyor91;  ?>" /><input type="text" name="ssyorscore92" value="<?php echo $ssyorscore92;  ?>" /><input type="text" name="gradeyor92" value="<?php echo $gradeyor92;  ?>" /><input type="text" name="ttyorscore93" value="<?php echo $ttyorscore93;  ?>" /><input type="text" name="gradeyor93" value="<?php echo $gradeyor93;  ?>" />
<input style="background-color:orange;" type="text" name="ffyorscore101" value="<?php echo $ffyorscore101;  ?>" /><input type="text" name="gradeyor101" value="<?php echo $gradeyor101;  ?>" /><input style="background-color:orange;"  type="text" name="ssyorscore102" value="<?php echo $ssyorscore102;  ?>" /><input type="text" name="gradeyor102" value="<?php echo $gradeyor102;  ?>" /><input type="text" name="ttyorscore103" value="<?php echo $ttyorscore103;  ?>" /><input type="text" name="gradeyor103" value="<?php echo $gradeyor103;  ?>" />
<input type="text" name="ffyorscore111" value="<?php echo $ffyorscore111;  ?>" /><input type="text" name="gradeyor111" value="<?php echo $gradeyor111;  ?>" /><input type="text" name="ssyorscore112" value="<?php echo $ssyorscore112;  ?>" /><input type="text" name="gradeyor112" value="<?php echo $gradeyor112;  ?>" /><input type="text" name="ttyorscore113" value="<?php echo $ttyorscore113;  ?>" /><input type="text" name="gradeyor113" value="<?php echo $gradeyor113;  ?>" />
<input type="text" name="ffyorscore121" value="<?php echo $ffyorscore121;  ?>" /><input type="text" name="gradeyor121" value="<?php echo $gradeyor121;  ?>" /><input type="text" name="ssyorscore122" value="<?php echo $ssyorscore122;  ?>" /><input type="text" name="gradeyor122" value="<?php echo $gradeyor122;  ?>" /><input type="text" name="ttyorscore123" value="<?php echo $ttyorscore123;  ?>" /><input type="text" name="gradeyor123" value="<?php echo $gradeyor123;  ?>" />

<input type="text" name="ffqrsc71" value="<?php echo $ffqrsc71;  ?>" /><input type="text" name="gradeqr71" value="<?php echo $gradeqr71;  ?>" /><input type="text" name="ssqrsc72" value="<?php echo $ssqrsc72;  ?>" /><input type="text" name="gradeqr72" value="<?php echo $gradeqr72;  ?>" /><input type="text" name="ttqrsc73" value="<?php echo $ttqrsc73;  ?>" /><input type="text" name="gradeqr73" value="<?php echo $gradeqr73;  ?>" />
<input type="text" name="ffqrsc81" value="<?php echo $ffqrsc81;  ?>" /><input type="text" name="gradeqr81" value="<?php echo $gradeqr81;  ?>" /><input type="text" name="ssqrsc82" value="<?php echo $ssqrsc82;  ?>" /><input type="text" name="gradeqr82" value="<?php echo $gradeqr82;  ?>" /><input type="text" name="ttqrsc83" value="<?php echo $ttqrsc83;  ?>" /><input type="text" name="gradeqr83" value="<?php echo $gradeqr83;  ?>" />
<input type="text" name="ffqrsc91" value="<?php echo $ffqrsc91;  ?>" /><input type="text" name="gradeqr91" value="<?php echo $gradeqr91;  ?>" /><input type="text" name="ssqrsc92" value="<?php echo $ssqrsc92;  ?>" /><input type="text" name="gradeqr92" value="<?php echo $gradeqr92;  ?>" /><input type="text" name="ttqrsc93" value="<?php echo $ttqrsc93;  ?>" /><input type="text" name="gradeqr93" value="<?php echo $gradeqr93;  ?>" />
<input style="background-color:orange;" type="text" name="ffqrsc101" value="<?php echo $ffqrsc101;  ?>" /><input type="text" name="gradeqr101" value="<?php echo $gradeqr101;  ?>" /><input style="background-color:orange;"  type="text" name="ssqrsc102" value="<?php echo $ssqrsc102;  ?>" /><input type="text" name="gradeqr102" value="<?php echo $gradeqr102;  ?>" /><input type="text" name="ttqrsc103" value="<?php echo $ttqrsc103;  ?>" /><input type="text" name="gradeqr103" value="<?php echo $gradeqr103;  ?>" />
<input type="text" name="ffqrsc111" value="<?php echo $ffqrsc111;  ?>" /><input type="text" name="gradeqr111" value="<?php echo $gradeqr111;  ?>" /><input type="text" name="ssyqrsc112" value="<?php echo $ssqrsc112;  ?>" /><input type="text" name="gradeqr112" value="<?php echo $gradeqr112;  ?>" /><input type="text" name="ttqrsc113" value="<?php echo $ttqrsc113;  ?>" /><input type="text" name="gradeqr113" value="<?php echo $gradeqr113;  ?>" />
<input type="text" name="ffqrsc121" value="<?php echo $ffqrsc121;  ?>" /><input type="text" name="gradeqr121" value="<?php echo $gradeqr121;  ?>" /><input type="text" name="ssqrsc122" value="<?php echo $ssqrsc122;  ?>" /><input type="text" name="gradeqr122" value="<?php echo $gradeqr122;  ?>" /><input type="text" name="ttqrsc123" value="<?php echo $ttqrsc123;  ?>" /><input type="text" name="gradeqr123" value="<?php echo $gradeqr123;  ?>" />

<input type="text" name="ffvrsc71" value="<?php echo $ffvrsc71;  ?>" /><input type="text" name="gradevr71" value="<?php echo $gradevr71;  ?>" /><input type="text" name="ssvrsc72" value="<?php echo $ssvrsc72;  ?>" /><input type="text" name="gradevr72" value="<?php echo $gradevr72;  ?>" /><input type="text" name="ttvrsc73" value="<?php echo $ttvrsc73;  ?>" /><input type="text" name="gradevr73" value="<?php echo $gradevr73;  ?>" />
<input type="text" name="ffvrsc81" value="<?php echo $ffvrsc81;  ?>" /><input type="text" name="gradevr81" value="<?php echo $gradevr81;  ?>" /><input type="text" name="ssvrsc82" value="<?php echo $ssvrsc82;  ?>" /><input type="text" name="gradevr82" value="<?php echo $gradevr82;  ?>" /><input type="text" name="ttvrsc83" value="<?php echo $ttvrsc83;  ?>" /><input type="text" name="gradevr83" value="<?php echo $gradevr83;  ?>" />
<input type="text" name="ffvrsc91" value="<?php echo $ffvrsc91;  ?>" /><input type="text" name="gradevr91" value="<?php echo $gradevr91;  ?>" /><input type="text" name="ssvrsc92" value="<?php echo $ssvrsc92;  ?>" /><input type="text" name="gradevr92" value="<?php echo $gradevr92;  ?>" /><input type="text" name="ttvrsc93" value="<?php echo $ttvrsc93;  ?>" /><input type="text" name="gradevr93" value="<?php echo $gradevr93;  ?>" />
<input style="background-color:orange;" type="text" name="ffvrsc101" value="<?php echo $ffvrsc101;  ?>" /><input type="text" name="gradevr101" value="<?php echo $gradevr101;  ?>" /><input style="background-color:orange;"  type="text" name="ssvrsc102" value="<?php echo $ssvrsc102;  ?>" /><input type="text" name="gradevr102" value="<?php echo $gradevr102;  ?>" /><input type="text" name="ttvrsc103" value="<?php echo $ttvrsc103;  ?>" /><input type="text" name="gradevr103" value="<?php echo $gradevr103;  ?>" />
<input type="text" name="ffvrsc111" value="<?php echo $ffvrsc111;  ?>" /><input type="text" name="gradevr111" value="<?php echo $gradevr111;  ?>" /><input type="text" name="ssvrsc112" value="<?php echo $ssvrsc112;  ?>" /><input type="text" name="gradevr112" value="<?php echo $gradevr112;  ?>" /><input type="text" name="ttvrsc113" value="<?php echo $ttvrsc113;  ?>" /><input type="text" name="gradevr113" value="<?php echo $gradevr113;  ?>" />
<input type="text" name="ffvrsc121" value="<?php echo $ffvrsc121;  ?>" /><input type="text" name="gradevr121" value="<?php echo $gradevr121;  ?>" /><input type="text" name="ssvrsc122" value="<?php echo $ssvrsc122;  ?>" /><input type="text" name="gradevr122" value="<?php echo $gradevr122;  ?>" /><input type="text" name="ttvrsc123" value="<?php echo $ttvrsc123;  ?>" /><input type="text" name="gradevr123" value="<?php echo $gradevr123;  ?>" />

<input type="text" name="ffvapsc71" value="<?php echo $ffvapsc71;  ?>" /><input type="text" name="gradevap71" value="<?php echo $gradevap71;  ?>" /><input type="text" name="ssvapsc72" value="<?php echo $ssvapsc72;  ?>" /><input type="text" name="gradevap72" value="<?php echo $gradevap72;  ?>" /><input type="text" name="ttvapsc73" value="<?php echo $ttvapsc73;  ?>" /><input type="text" name="gradevap73" value="<?php echo $gradevap73;  ?>" />
<input type="text" name="ffvapsc81" value="<?php echo $ffvapsc81;  ?>" /><input type="text" name="gradevap81" value="<?php echo $gradevap81;  ?>" /><input type="text" name="ssvapsc82" value="<?php echo $ssvapsc82;  ?>" /><input type="text" name="gradevap82" value="<?php echo $gradevap82;  ?>" /><input type="text" name="ttvapsc83" value="<?php echo $ttvapsc83;  ?>" /><input type="text" name="gradevap83" value="<?php echo $gradevap83;  ?>" />
<input type="text" name="ffvapsc91" value="<?php echo $ffvapsc91;  ?>" /><input type="text" name="gradevap91" value="<?php echo $gradevap91;  ?>" /><input type="text" name="ssvapsc92" value="<?php echo $ssvapsc92;  ?>" /><input type="text" name="gradevap92" value="<?php echo $gradevap92;  ?>" /><input type="text" name="ttvapsc93" value="<?php echo $ttvapsc93;  ?>" /><input type="text" name="gradevap93" value="<?php echo $gradevap93;  ?>" />
<input style="background-color:orange;" type="text" name="ffvapsc101" value="<?php echo $ffvapsc101;  ?>" /><input type="text" name="gradevap101" value="<?php echo $gradevap101;  ?>" /><input style="background-color:orange;"  type="text" name="ssvapsc102" value="<?php echo $ssvapsc102;  ?>" /><input type="text" name="gradevap102" value="<?php echo $gradevap102;  ?>" /><input type="text" name="ttvapsc103" value="<?php echo $ttvapsc103;  ?>" /><input type="text" name="gradevap103" value="<?php echo $gradevap103;  ?>" />
<input type="text" name="ffvapsc111" value="<?php echo $ffvapsc111;  ?>" /><input type="text" name="gradevap111" value="<?php echo $gradevap111;  ?>" /><input type="text" name="ssvapsc112" value="<?php echo $ssvapsc112;  ?>" /><input type="text" name="gradevap112" value="<?php echo $gradevap112;  ?>" /><input type="text" name="ttvapsc113" value="<?php echo $ttvapsc113;  ?>" /><input type="text" name="gradevap113" value="<?php echo $gradevap113;  ?>" />
<input type="text" name="ffvapsc121" value="<?php echo $ffvapsc121;  ?>" /><input type="text" name="gradevap121" value="<?php echo $gradevap121;  ?>" /><input type="text" name="ssvapsc122" value="<?php echo $ssvapsc122;  ?>" /><input type="text" name="gradevap122" value="<?php echo $gradevap122;  ?>" /><input type="text" name="ttvapsc123" value="<?php echo $ttvapsc123;  ?>" /><input type="text" name="gradevap123" value="<?php echo $gradevap123;  ?>" />

<input type="text" name="ffhwsc71" value="<?php echo $ffhwsc71;  ?>" /><input type="text" name="gradehw71" value="<?php echo $gradehw71;  ?>" /><input type="text" name="sshwsc72" value="<?php echo $sshwsc72;  ?>" /><input type="text" name="gradehw72" value="<?php echo $gradehw72;  ?>" /><input type="text" name="tthwsc73" value="<?php echo $tthwsc73;  ?>" /><input type="text" name="gradehw73" value="<?php echo $gradehw73;  ?>" />
<input type="text" name="ffhwsc81" value="<?php echo $ffhwsc81;  ?>" /><input type="text" name="gradehw81" value="<?php echo $gradehw81;  ?>" /><input type="text" name="sshwsc82" value="<?php echo $sshwsc82;  ?>" /><input type="text" name="gradehw82" value="<?php echo $gradehw82;  ?>" /><input type="text" name="tthwsc83" value="<?php echo $tthwsc83;  ?>" /><input type="text" name="gradehw83" value="<?php echo $gradehw83;  ?>" />
<input type="text" name="ffhwsc91" value="<?php echo $ffhwsc91;  ?>" /><input type="text" name="gradehw91" value="<?php echo $gradehw91;  ?>" /><input type="text" name="sshwsc92" value="<?php echo $sshwsc92;  ?>" /><input type="text" name="gradehw92" value="<?php echo $gradehw92;  ?>" /><input type="text" name="tthwsc93" value="<?php echo $tthwsc93;  ?>" /><input type="text" name="gradehw93" value="<?php echo $gradehw93;  ?>" />
<input style="background-color:orange;" type="text" name="ffhwsc101" value="<?php echo $ffhwsc101;  ?>" /><input type="text" name="gradehw101" value="<?php echo $gradehw101;  ?>" /><input style="background-color:orange;"  type="text" name="sshwsc102" value="<?php echo $sshwsc102;  ?>" /><input type="text" name="gradehw102" value="<?php echo $gradehw102;  ?>" /><input type="text" name="tthwsc103" value="<?php echo $tthwsc103;  ?>" /><input type="text" name="gradehw103" value="<?php echo $gradehw103;  ?>" />
<input type="text" name="ffhwsc111" value="<?php echo $ffhwsc111;  ?>" /><input type="text" name="gradehw111" value="<?php echo $gradehw111;  ?>" /><input type="text" name="ssyhwsc112" value="<?php echo $sshwsc112;  ?>" /><input type="text" name="gradehw112" value="<?php echo $gradehw112;  ?>" /><input type="text" name="tthwsc113" value="<?php echo $tthwsc113;  ?>" /><input type="text" name="gradehw113" value="<?php echo $gradehw113;  ?>" />
<input type="text" name="ffhwsc121" value="<?php echo $ffhwsc121;  ?>" /><input type="text" name="gradehw121" value="<?php echo $gradehw121;  ?>" /><input type="text" name="sshwsc122" value="<?php echo $sshwsc122;  ?>" /><input type="text" name="gradehw122" value="<?php echo $gradehw122;  ?>" /><input type="text" name="tthwsc123" value="<?php echo $tthwsc123;  ?>" /><input type="text" name="gradehw123" value="<?php echo $gradehw123;  ?>" />

<input type="text" name="ffirssc71" value="<?php echo $ffirssc71;  ?>" /><input type="text" name="gradeirs71" value="<?php echo $gradeirs71;  ?>" /><input type="text" name="ssirssc72" value="<?php echo $ssirssc72;  ?>" /><input type="text" name="gradeirs72" value="<?php echo $gradeirs72;  ?>" /><input type="text" name="ttirssc73" value="<?php echo $ttirssc73;  ?>" /><input type="text" name="gradeirs73" value="<?php echo $gradeirs73;  ?>" />
<input type="text" name="ffirssc81" value="<?php echo $ffirssc81;  ?>" /><input type="text" name="gradeirs81" value="<?php echo $gradeirs81;  ?>" /><input type="text" name="ssirssc82" value="<?php echo $ssirssc82;  ?>" /><input type="text" name="gradeirs82" value="<?php echo $gradeirs82;  ?>" /><input type="text" name="ttirssc83" value="<?php echo $ttirssc83;  ?>" /><input type="text" name="gradeirs83" value="<?php echo $gradeirs83;  ?>" />
<input type="text" name="ffirssc91" value="<?php echo $ffirssc91;  ?>" /><input type="text" name="gradeirs91" value="<?php echo $gradeirs91;  ?>" /><input type="text" name="ssirssc92" value="<?php echo $ssirssc92;  ?>" /><input type="text" name="gradeirs92" value="<?php echo $gradeirs92;  ?>" /><input type="text" name="ttirssc93" value="<?php echo $ttirssc93;  ?>" /><input type="text" name="gradeirs93" value="<?php echo $gradeirs93;  ?>" />
<input style="background-color:orange;" type="text" name="ffirssc101" value="<?php echo $ffirssc101;  ?>" /><input type="text" name="gradeirs101" value="<?php echo $gradeirs101;  ?>" /><input style="background-color:orange;"  type="text" name="ssirssc102" value="<?php echo $ssirssc102;  ?>" /><input type="text" name="gradeirs102" value="<?php echo $gradeirs102;  ?>" /><input type="text" name="ttirssc103" value="<?php echo $ttirssc103;  ?>" /><input type="text" name="gradeirs103" value="<?php echo $gradeirs103;  ?>" />
<input type="text" name="ffirssc111" value="<?php echo $ffirssc111;  ?>" /><input type="text" name="gradeirs111" value="<?php echo $gradeirs111;  ?>" /><input type="text" name="ssyirssc112" value="<?php echo $ssirssc112;  ?>" /><input type="text" name="gradeirs112" value="<?php echo $gradeirs112;  ?>" /><input type="text" name="ttirssc113" value="<?php echo $ttirssc113;  ?>" /><input type="text" name="gradeirs113" value="<?php echo $gradeirs113;  ?>" />
<input type="text" name="ffirssc121" value="<?php echo $ffirssc121;  ?>" /><input type="text" name="gradeirs121" value="<?php echo $gradeirs121;  ?>" /><input type="text" name="ssirssc122" value="<?php echo $ssirssc122;  ?>" /><input type="text" name="gradeirs122" value="<?php echo $gradeirs122;  ?>" /><input type="text" name="ttirssc123" value="<?php echo $ttirssc123;  ?>" /><input type="text" name="gradeirs123" value="<?php echo $gradeirs123;  ?>" />

<input type="text" name="ffphoscore71" value="<?php echo $ffphoscore71;  ?>" /><input type="text" name="gradepho71" value="<?php echo $gradepho71;  ?>" /><input type="text" name="ssphoscore72" value="<?php echo $ssphoscore72;  ?>" /><input type="text" name="gradepho72" value="<?php echo $gradepho72;  ?>" /><input type="text" name="ttphoscore73" value="<?php echo $ttphoscore73;  ?>" /><input type="text" name="gradepho73" value="<?php echo $gradepho73;  ?>" />
<input type="text" name="ffphoscore81" value="<?php echo $ffphoscore81;  ?>" /><input type="text" name="gradepho81" value="<?php echo $gradepho81;  ?>" /><input type="text" name="ssphoscore82" value="<?php echo $ssphoscore82;  ?>" /><input type="text" name="gradepho82" value="<?php echo $gradepho82;  ?>" /><input type="text" name="ttphoscore83" value="<?php echo $ttphoscore83;  ?>" /><input type="text" name="gradepho83" value="<?php echo $gradepho83;  ?>" />
<input type="text" name="ffphoscore91" value="<?php echo $ffphoscore91;  ?>" /><input type="text" name="gradepho91" value="<?php echo $gradepho91;  ?>" /><input type="text" name="ssphoscore92" value="<?php echo $ssphoscore92;  ?>" /><input type="text" name="gradepho92" value="<?php echo $gradepho92;  ?>" /><input type="text" name="ttphoscore93" value="<?php echo $ttphoscore93;  ?>" /><input type="text" name="gradepho93" value="<?php echo $gradepho93;  ?>" />
<input style="background-color:orange;" type="text" name="ffphoscore101" value="<?php echo $ffphoscore101;  ?>" /><input type="text" name="gradepho101" value="<?php echo $gradepho101;  ?>" /><input style="background-color:orange;"  type="text" name="ssphoscore102" value="<?php echo $ssphoscore102;  ?>" /><input type="text" name="gradepho102" value="<?php echo $gradepho102;  ?>" /><input type="text" name="ttphoscore103" value="<?php echo $ttphoscore103;  ?>" /><input type="text" name="gradepho103" value="<?php echo $gradepho103;  ?>" />
<input type="text" name="ffphoscore111" value="<?php echo $ffphoscore111;  ?>" /><input type="text" name="gradepho111" value="<?php echo $gradepho111;  ?>" /><input type="text" name="ssphoscore112" value="<?php echo $ssphoscore112;  ?>" /><input type="text" name="gradepho112" value="<?php echo $gradepho112;  ?>" /><input type="text" name="ttphoscore113" value="<?php echo $ttphoscore113;  ?>" /><input type="text" name="gradepho113" value="<?php echo $gradepho113;  ?>" />
<input type="text" name="ffphoscore121" value="<?php echo $ffphoscore121;  ?>" /><input type="text" name="gradepho121" value="<?php echo $gradepho121;  ?>" /><input type="text" name="ssphoscore122" value="<?php echo $ssphoscore122;  ?>" /><input type="text" name="gradepho122" value="<?php echo $gradepho122;  ?>" /><input type="text" name="ttphoscore123" value="<?php echo $ttphoscore123;  ?>" /><input type="text" name="gradepho123" value="<?php echo $gradepho123;  ?>" />

<input type="text" name="princiname" value="<?php echo $princiname;  ?>" />
<input type="text" name="schooll" value="<?php echo $schooll;  ?>" />
<input type="text" name="address" value="<?php echo $address;  ?>" />
<input type="text" name="tel" value="<?php echo $tel;  ?>" />
<input type="text" name="fax" value="<?php echo $fax;  ?>" />
<input type="text" name="email" value="<?php echo $email;  ?>" />
<input type="text" name="img" value="<?php echo $img;  ?>" />
<input type="text" name="ccaa1" value="<?php echo $ccaa1;  ?>" />
<input type="text" name="ccaa3" value="<?php echo $ccaa3;  ?>" />
<input type="text" name="ccaa4" value="<?php echo $ccaa4;  ?>" />
<input type="text" name="ccaa6" value="<?php echo $ccaa6;  ?>" />
<input type="submit" class="pbutton" name="submit" value="GENERATE PDF" />
</form>
<a href="teagetresult.php" class="pbutton" >BACK</a>
<a href="index2.php" class="pbutton" >HOME</a>
<center>
<div id="loadit"></div>	
<div id="afterthis" style="margin-top: -20px;" ><ul id="resultlist" style="list-style-type: none;" ></ul></div>
</center>
<br><br>
<?php }} ?>
</body>