<?php
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
	
$formt = $_POST['formt'];
$class = $_POST['class'];
$year = $_POST['year'];
$arms = $_POST['arms'];
$term = $_POST['term'];
$altschopen = $_POST['altschopen'];
$schopenstatus = $_POST['schopenstatus'];

$result = mysqli_query($db, "SELECT attend FROM attend where datename='$altschopen' AND school='".$_SESSION["school"]."'");
$resultcount = mysqli_num_rows($result);	
while($row = mysqli_fetch_assoc($result))
							{  
								$s2[] = $row['attend'];
							}
							$s = current($s2);

//if($resultcount>0){
if($schopenstatus=='no'){
$schopenstatus="";
}
$sql2=mysqli_query($db,"UPDATE attend SET schoolopen='$schopenstatus' WHERE datename='$altschopen' AND school='".$_SESSION["school"]."'");	
//}	

if($sql2){
	echo date('D jS \of F Y', strtotime($altschopen));
}	
else{
	echo "nothing";
}
?>