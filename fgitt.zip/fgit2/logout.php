<?php
if(session_destroy()) // Destroying All Sessions
{
    session_destroy(); 
//header("Location: index.php"); // Redirecting To Home Page
'<meta content="2;index.php" http-equiv="refresh" />'; 
}
//else{
 session_destroy();
header("Location: index.php"); // Redirecting To Home Page
//}
?>