<?php
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
if (!isset($_POST['btn-upload'])) {
	echo "";
	}else{
	$img_id= $_POST['img_id'];	
	$house = $_POST['house'];	
	$queryim = mysqli_query($db, "select * from img where img_id='$img_id'");	
	while($row = mysqli_fetch_assoc($queryim))
							{ 
							$student_name2[] = $row['student_name'];
							$img2[] = $row['img'];
							}
							$student_name = current($student_name2);	
							$img = current($img2);
		
	 $file = $_FILES['file']['name'];
 	$file_loc = $_FILES['file']['tmp_name'];
 	$file_size = $_FILES['file']['size'];
 	$file_type = $_FILES['file']['type'];
 
  if($file_size > 500000 OR $file_type =! 'image/jpg' OR $file_type =! 'image/png' OR $file_type =! 'image/gif'){
	echo 'file size is too large or image is not right type';
}
else{
	if(move_uploaded_file($file_loc,$file)){
		$ny = mysqli_num_rows($queryim);
		if($ny == 1){
		$update=mysqli_query($db,"UPDATE img SET img='$file', house='$house' WHERE img_id='$img_id'");
					}
	}
	else{
		$update=mysqli_query($db,"UPDATE img SET img='$img', house='$house' WHERE img_id='$img_id'");
		}
	}					
	$queryimm = mysqli_query($db,"select * from regstu where student_name='$student_name'");
	while($rowmm = mysqli_fetch_assoc($queryimm))
							{ 
							$caa2[] = $rowmm['caa'];
							$yoa2[] = $rowmm['yoa'];
							}
							$caa = current($caa2);
							$yoa = current($yoa2);	
	$updatehouse=mysqli_query($db,"UPDATE regstu SET house='$house' WHERE student_name='$student_name' AND caa='$caa' AND yoa='$yoa'");	
	$updatehousestudentsbyclass=mysqli_query($db,"UPDATE studentsbyclass SET house='$house' WHERE student_name='$student_name' AND class='$caa' AND year='$yoa'");	
		if($update){
			//echo 'ttttttt';
		echo '<center>';
		echo '<div style="margin-top: 20%;">';
		echo '<form id="formit"  class="formit" name="formit" action="addstudentsbyadmin.php" method="post">';
		echo '<input style="display: none;" type="text" id="caa" name="caa" value="'.$caa.'" />';
		echo '<input style="display: none;" type="text" id="yoa" name="yoa" value="'.$yoa.'" />';
		echo '<input style="display: block; width: 400px; background-color: green; color: white;" type="submit" id="submit" class="submit" name="submitimg" value="Back to list of students admitted into '.$caa.' in '.$yoa.'"/>';
		echo '</form>';
		echo '<a  href="adstuadmin.php" style="display: block; width: 400px; background-color: green; color: white;">Add students</a>';
		echo '<div>';
		echo '</center>';
		}
			else{
			echo '<img src="table/del.jpg" /> &nbsp;! photo not updated';
			echo '<meta content="2;addstudentsbyadmin.php" http-equiv="refresh" />';
			}
			
			}

?>
<!DOCTYPE html>

<html class="no-js" lang="en">
<head>
<meta name="viewport" content="width=device-width" />
	<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" href="img/season-change.jpg" type="image/x-icon">
		<title>Update Student Image</title>
        <link rel="stylesheet" type="text/css" href="table/css/DT_bootstrap.css">
		
		<script src="table/js/jquery.js" type="text/javascript"></script>
		
	 
   <style>
#fd {
  background: -webkit-linear-gradient(bottom, #CCCCCC, #EEEEEE 175px);
  background: -moz-linear-gradient(bottom, #CCCCCC, #EEEEEE 175px);
  background: linear-gradient(bottom, #CCCCCC, #EEEEEE 175px);
  margin: auto;
  position: relative;
  width: 50%;
  height: 350px;
  font-family: Tahoma, Geneva, sans-serif;
  font-size: 12px;
  font-style: italic;
  line-height: 24px;
  font-weight: bold;
  color: #09C;
  text-decoration: none;
  border-radius: 10px;
  padding: 10px;
  border: 1px solid #999;
  border: inset 1px solid #333;
  -webkit-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  -moz-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
}


input {
  width: 50%;
  display: block;
  border: 1px solid #999;
  height: 20px;
  -webkit-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  -moz-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
}

select#upload {
  width: 40%;
  height: 30px;
  display: block;
}

.button {
  width: 100px;
  position: absolute;
  right: 20px;
  bottom: 20px;
  background: #09C;
  color: #fff;
  font-family: Tahoma, Geneva, sans-serif;
  height: 30px;
  border-radius: 15px;
  border: 1p solid #999;
}

input.button:hover {
  background: #fff;
  color: #09C;
}

select:focus, input:focus {
  border: 1px solid #09C;
}
</style> 
<script src="table/js/jquery.js" type="text/javascript"></script>
	<script src="table/js/bootstrap.js" type="text/javascript"></script>
	
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/jquery.dataTables.js"></script>
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/DT_bootstrap.js"></script>
   
   <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
 var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
  });
 </script>
  <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script> 
 
</head>

<body>
<?php
include "connection.php";

$resultrole2 = mysqli_query($db, "SELECT * FROM users2 where username='".$_SESSION['username']."'");
while($rowrole2 = mysqli_fetch_assoc($resultrole2))
{
	$arole[] = $rowrole2['role'];
	$adminlevel2[] = $rowrole2['adminlevel'];
}
$_SESSION['role'] =  current($arole);
$_SESSION['adminlevel'] =  current($adminlevel2);
if($_SESSION['role'] == 'teacher'){
	?>
<?php
include("header.php");
?>
<?php
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");
}
elseif($_SESSION['role'] == 'student'){
echo '<ul class="topnav" id="myTopnav">';
echo '<li><a href="teagetresultmid.php">Midterm Result</a></li>';
echo '<li><a href="teagetresult.php">Term Result</a></li>';
echo '<li><a href="newpass.php">Change Pass</a></li>';
echo '<li><a href="logout.php">Logout</a></li>';
echo '<li class="icon">';
echo '<a href="javascript:void(0);" onclick="myFunction()">&#9776;</a>';
echo '</li>';
echo '</ul>';
}
else{ header("location: logout.php"); }
echo "<br>";
if($formforback==""){
	echo " ";
}
else{
	echo $formforback;
}
$img_id = $_GET['img_id'];
$query1 = mysqli_query($db, "select * from img where img_id=$img_id");
echo '<center><br><br><br><br>';
while ($row1 = mysqli_fetch_array($query1)) {
echo '<form action="'.$_SERVER['PHP_SELF'].'" method="post" id="fd" enctype="multipart/form-data">';
echo '<div>'.$row1['student_name'].'</div>';		
echo '<div><img src="'.$row1['img'].'" alt="no image" height="80" width="80" /></div>';	
echo '<div>';
echo '<h1>Edit Student\'s Photo and/or House:</h1>';
echo '<label>';
echo  '<input id="img_id" type="hidden" name="img_id" value="'.$row1['img_id'].'"/><br>';
echo  '<input id="file" name="file"  type="file"/><br>';
echo  '<input id="house" name="house"  type="text" value="'.$row1['house'].'"/>';
echo  '</label><br>';
echo '<label>';
 echo   '<input type="submit" class="button" name="btn-upload" value="Submit Form" />';
  echo  '</label>';
echo '</div>';
echo '</form><br>';
}
echo '</center>';
include("footer.php");
?>

</body>
</html>