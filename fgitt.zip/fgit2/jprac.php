<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Index</title>
<link rel="stylesheet" href="css/style.css" />
<script type="text/javascript" src="js/jquery-2.1.4.js"></script>
<script>
$(document).ready(function(){
$("button").one("click", function(){
    $("#classd").append("<div>cool</div>");
});
});
</script>
</head>

<body>
<button id="btn1">Append text</button>
<label id="classd">input added</label>
</body>