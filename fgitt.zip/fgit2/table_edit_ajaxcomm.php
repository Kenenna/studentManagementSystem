<?php
session_start();
include("auth.php");
include("db.php");
if($_POST['id'])
{
$id=mysql_escape_String($_POST['id']);
$firstname=mysql_escape_String($_POST['firstname']);
$sql = "update ftcomments set firstname='$firstname' where id='$id' AND school='".$_SESSION["school"]."'";
mysql_query($sql);
}
?>