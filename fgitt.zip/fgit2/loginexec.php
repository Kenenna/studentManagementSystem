<?php
session_start();
include("connection.php");	
		$role = $_POST['role'];
		$teacher = $_POST['teacher'];
        $username = $_POST['username'];
        $password = $_POST['password'];
		$password = $password;
        $query = "SELECT * FROM `users2` WHERE role='$role' and username='$username' and password='".md5($password)."'";
		$result = mysqli_query($db,$query);
		while($row = mysqli_fetch_assoc($result)){
			$status2[] = $row["status"];
		}
		$status = current($status2);
		$rows = mysqli_num_rows($result);
        if($rows>=1){
			$_SESSION['username'] = $username;
			$_SESSION['role'] = $role;
			//echo $role;
			if(($role!="admin" && $role!="principal") || (($role=="admin" || $role=="principal")&& $status!=0)){
		header("Location: chooseschool.php"); // Redirect user to index
			}else{
			   header("Location: index.php"); // Redirect user to index 
			}
			}else{
			  header("Location: index.php"); // Redirect user to index  
			}
	?>