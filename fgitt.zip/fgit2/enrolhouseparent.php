<?php 
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
if(isset($_POST['subsubmit2'])){
     $teacher_id = $_POST['teacher_id2'];
		$teacher_name = $_POST['teacher_name2'];
		$year = $_POST['year2'];
		$house = $_POST['house2'];  
		$checkteach = mysqli_query($db, "SELECT * FROM subhouseparent where teacher_name='$teacher_name' AND year='$year' AND house='$house' AND school='".$_SESSION["school"]."'");	
		$checkteachcount=mysqli_num_rows($checkteach);
	//	echo $checkteachcount;
	if($checkteachcount > 0){
	    $msg = "<br><br><div class='form'><h5 style='color:red'>".$teacher_name." has already been enrolled as ".$house." House Parent for Session beginning, ".$year."</h5></div>";
	$refres = '<meta content="2;index2.php" http-equiv="refresh" />';
	}else{
	   	$query = mysqli_query($db,"INSERT into `subhouseparent` (teacher_id, teacher_name, year, house, school) VALUES ('$teacher_id', '$teacher_name', '$year', '$house', '".$_SESSION["school"]."')");
        if($query){
        $msg = "<br><br><div class='form'><h4>House Parent was enrolled successfully.</h4></div>";
		$refres = '<meta content="2;index2.php" http-equiv="refresh" />';
        } // for if
        else{
        $msg = "<br><br><div class='form'><h4>House Parent was NOT enrolled successfully.</h4></div>";
		$refres = '<meta content="2;index2.php" http-equiv="refresh" />';
        } //for else for result
	}// for else for insert
	}//for isset


if(isset($_POST['submit2'])){
        $teacher_id = $_POST['teacher_id'];
		$teacher_name = $_POST['teacher_name'];
		$year = $_POST['year'];
		$house = $_POST['house'];
		
	$checkteach = mysqli_query($db, "SELECT * FROM houseparent where teacher_name='$teacher_name' AND year='$year' AND house='$house' AND school='".$_SESSION["school"]."'");
	$checkteach2 = mysqli_query($db, "SELECT * FROM houseparent where year='$year' AND house='$house' AND school='".$_SESSION["school"]."'");
	while($rowyr = mysqli_fetch_assoc($checkteach2))
							{ 
								$rowtutor2[] = $rowyr['teacher_name'];
							}
							$rowtutor = current($rowtutor2);
	
	$countteach = mysqli_num_rows($checkteach);
	$countteach2 = mysqli_num_rows($checkteach2);
	
	if($countteach2 > 0){
		$msg = "<br><br><div class='form' style='color:red'>A House Parent has already been assigned that House.</div><br>";
	    $msg .= '<div class="form"><div style="color:red">If you still wish to enrol '.$teacher_name.' as House Parent for '.$house.' House in '.$year.'/'.($year+1).' Session, Click</div>';

$msg .= '<form name="registration" action="enrolhouseparent.php" method="post">';
$msg .= '<input type="hidden" name="teacher_id2" value="'.$_POST['teacher_id'].'" />';
$msg .= '<input type="text" style="display: none;" readonly="readonly" name="teacher_name2" value="'.$_POST['teacher_name'].'" />';
$msg .= '<input type="text" style="display: none;" readonly="readonly" name="house2" value="'.$_POST['house'].'" />';
$msg .= '<input type="text" style="display: none;" readonly="readonly" name="year2" value="'.$_POST['year'].'" />';
$msg .= '<input type="submit" name="subsubmit2" value="Assign" />';
$msg .= '</form><br><br>';  
		
		if($countteach > 0){
		$msg = "<div class='form'><h5 style='color:red'>".$rowtutor." has already been enrolled as ".$house." House Parent for Session beginning, ".$year."</h5></div>";
		$refres = '<meta content="2;index2.php" http-equiv="refresh" />';
	}
	}
	
	elseif($countteach < 1){
	$query = ("INSERT into `houseparent` (teacher_id, teacher_name, year, house, school) VALUES ('$teacher_id', '$teacher_name', '$year', '$house', '".$_SESSION["school"]."')");
        $result = mysqli_query($db,$query);
        if($result){
            $msg = "<div class='form'><h4>House Parent was enrolled successfully.</h4></div>";
			$refres = '<meta content="2;index2.php" http-equiv="refresh" />';
        }
	}
	
	else{
		 $msg =  "<div class='form'><h5 style='color: red;'>A House Parent has already been enrolled for the House.</h5></div>";
		 $refres =  '<meta content="2;index2.php" http-equiv="refresh" />';
	}
    }	
	
	$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
	
	
?>


<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Add House Parent</title>
<link rel="stylesheet" href="css/style.css" />
        <link rel="stylesheet" type="text/css" href="table/css/DT_bootstrap.css">

	<script src="table/js/jquery.js" type="text/javascript"></script>

   
   <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
 var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>
  <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
</head>
<body>
<?php
$resultrole2 = mysqli_query($db, "SELECT role, adminlevel FROM users2 where username='".$_SESSION['username']."'");
while($rowrole2 = mysqli_fetch_assoc($resultrole2))
{
	$arole[] = $rowrole2['role'];
	$adminlevel2[] = $rowrole2['adminlevel'];
}
$_SESSION['role'] =  current($arole);
$_SESSION['adminlevel'] =  current($adminlevel2);
if($_SESSION['role'] == 'teacher'){
	?>
<?php
include("header.php");
?>
<?php
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");
}
elseif($_SESSION['role'] == 'student'){
include("headerstudent.php");
}
else{header("location: logout.php");}



echo '<br>';
echo '<br>';
echo '<center>';
echo $msg;
echo '</center>';
echo '<br>';
echo $refres;
?>
<br>

<?php
if(isset($_POST['submit1'])){
$teacher = $_POST['teacher'];
$coun= "SELECT * FROM users2 WHERE teacher='$teacher' AND school='".$_SESSION["school"]."'";
if ($result=mysqli_query($db, $coun)){
$rowcount=mysqli_num_rows($result);
if($rowcount == 1){	
    echo "<br><br>";
echo '<div class="form">';
echo '<h5>Assign A House To This Teacher</h5>';
echo '<form name="registration" action="enrolhouseparent.php" method="post">';
while($row = mysqli_fetch_assoc($result)){
echo '<input type="hidden" name="teacher_id" value="'.$row['teacher_id'].'" required />';
echo '<input type="text" readonly="readonly" name="teacher_name" value="'.$row['teacher'].'" required /><br>';
}
echo '<select style="width: 210px; border-radius: 2px; height: auto; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="house" class="house" id="house" required >';
$resulthouse = mysqli_query($db,"SELECT * FROM school where school='".$_SESSION["school"]."'");
				while($rowhouse = mysqli_fetch_assoc($resulthouse)){
					$arrr2[] = $rowhouse["house"];
				}
				$a = implode(',',$arrr2);
				$b = explode(',',$a);
				$f = (array_filter($b));

	for($i = 0; $i <= (count($f)-1); $i++){
								echo '<option value="'.$f[$i].'">';
								echo $f[$i];
								echo '</option>';
							}
echo '</select>';
echo '<br><label>For Session Beginning:</label>';
echo '<select style="width: 210px; border-radius: 2px; height: auto; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="year" class="year" id="year" required >';

	$resultyr = mysqli_query($db, "SELECT * FROM years");
						while($rowyr = mysqli_fetch_assoc($resultyr))
							{  
								echo '<option value="'.$rowyr['year'].'">';
								echo $rowyr['year'];
								echo '</option>';
							}
echo '</select>';
echo '<input type="submit" name="submit2" value="Assign" />';
echo '</form><br><br>';
echo '<br>';
echo '</div>';
}
else{
	echo "<br><br><br><br>House Parent not registered yet.<br><br><br><br>";
	echo '<meta content="2;index2.php" http-equiv="refresh" />';
}
}
}
?>
<?php
include("footer.php");
	?>	
</body>