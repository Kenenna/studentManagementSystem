<?php
	session_start();
	include "connection.php";
	include("auth.php"); 
	include('db.php');
	
	$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Update Scores</title>
<link rel="stylesheet" href="style.css" type="text/css" />
<link rel="stylesheet" href="css/style.css" />
	<script src="table/js/jquery.js" type="text/javascript"></script>
	<script src="datatablejs.js" type="text/javascript"></script>
	<!--<script src="https://cdn.datatables.net/buttons/1.4.2/js/dataTables.buttons.min.js" type="text/javascript"></script>-->
	<!--<script src="//cdn.datatables.net/buttons/1.4.2/js/buttons.colVis.min.js" type="text/javascript"></script>-->
	<link rel="stylesheet" type="text/css" href="datatablecss.css">
	 <link rel="stylesheet" type="text/css" href="datatablebuttoncss.css">
<script>
	$(document).ready(function() {
    $('#example').DataTable( {
        "paging":   false,
        "ordering": false,
        "info":     false
    } );
} );
</script>
 
  <link rel="stylesheet" href="css/styles.css">
   <script src="js/scriptmenu.js"></script>
<script>
$(document).ready(function(){
	var inihw = $(".newhwmax").val();
	var inicw = $(".newcwmax").val();
	var initest = $(".newtestmax").val();
	var iniexam = $(".newexammax").val();
	$("#txtFirstName").val(inihw);
	$("#txtFirstName1").val(inicw);
	$("#txtFirstName2").val(initest);
	$("#txtFirstName3").val(iniexam); 
	$("#txtFirstName").css("width","30px");
	$("#txtFirstName1").css("width","30px");
	$("#txtFirstName2").css("width","30px");
	$("#txtFirstName3").css("width","30px");
	$("#txtFirstName").before("<span>HW MAX:</span> ");
	$("#txtFirstName1").before("<span>CW MAX:</span> ");
	$("#txtFirstName2").before("<span>TEST MAX:</span> ");
	$("#txtFirstName3").before(" <span>EXAM MAX:</span> ");
	$("#dosomething").click(function(){
	//$("#txtFirstName").fadeIn(3000);
	//$("#txtFirstName1").fadeIn(3000);		
	var inihw2 = $(".newhwmax").val();
	var inicw2 = $(".newcwmax").val();
	var initest2 = $(".newtestmax").val();
	var iniexam2 = $(".newexammax").val();
	
	var valueit=$('#txtFirstName').val();
	var valueit1=$('#txtFirstName1').val();	
	var valueit2=$('#txtFirstName2').val();	
	var valueit3=$('#txtFirstName3').val();	
 if(valueit == 0){
	 $(".newhwmax").val(inihw);
				}
 else{
	 $(".newhwmax").val(valueit);
	}				
	if(valueit1 == 0){
	 $(".newcwmax").val(inicw);
				}
 else{
	 $(".newcwmax").val(valueit1);
	}
	if(valueit2 == 0){
	 $(".newtestmax").val(initest);
				}
 else{
	 $(".newtestmax").val(valueit2);
	}
	if(valueit3 == 0){
	 $(".newexammax").val(iniexam);
				}
 else{
	 $(".newexammax").val(valueit3);
	}	
});

$(".remark").css("cursor","pointer");
$(".remark").click(function(){
	var chatt = this.id;
	var ss = $('[id='+chatt+']').val();
	var comm = prompt("Enter comment",ss);
	if(comm==null){
	 $('[id='+chatt+']').val(ss);
	}else{
	 $('[id='+chatt+']').val(comm);	
	}
});
});
</script>

<script>
$(document).ready(function() {
$("#showscorerequestform").click(function(){
	$("#scoresrequestform").show();
	$("#showscorerequestform").hide();
});
$("#getscoresbutton").click(function(){
    $("#scoresrequestform").hide();
});
});
</script>

<script>
$(document).ready(function() {
$("#formid").submit(function( event ) {
event.preventDefault();	
$.ajax({
type: "POST",
url: "update_score_exec.php",
data: $("#formid").serializeArray(),	
success: function(response){
 if(response==1) { 
		event.preventDefault();
		$(".success").fadeIn();
		setTimeout(function() { $(".success").fadeOut(); }, 2000); 
		//setTimeout(function() { $(".cls").submit(); }, 1000);
    } else {
		 $(".error").show();
		setTimeout(function() { $(".error").fadeOut(); }, 2000);
		}
		}
});	
});	 
});
</script>
<script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>
 <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
</head>

<body>
<?php
echo '<div id="headerit">';
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");
}
elseif($_SESSION['role'] == 'student'){
include("headerstudent.php");
}
else{header("location: logout.php");}
echo '</div>';
?>
<?php
$user = $_SESSION['username'];
?>
<BR><BR><br><br>
<center><button class="button" style="background-color: green; color: white;" id="showscorerequestform">Show Scores Request Form</button></center>
<center><button class="button" style="display: none; background-color: green; color: white;" id="replacebutton">Show Scores Request Form</button></center>
<form action="" method="post" class="cls" style="display: none;" id="scoresrequestform" enctype="multipart/form-data">
<center>
 <div>
 <?php 
include "connection.php";
?> 
	<label><select style="width:15%;" name="class_name" id="class_name" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM classes");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['class_name'].'">';
								if($ctype=="Js"){
								echo $row['class_name2'];
												}
								else{
								echo $row['class_name'];	
								}
								echo '</option>';
							}
						?>
      </select>
	   <br>
	  <?php
	  echo '<select style="width: 210px; height: auto; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="arms" id="arms" required >';
	 $result = mysqli_query($db,"SELECT * FROM school where school='".$_SESSION["school"]."'");
				while($row = mysqli_fetch_assoc($result)){
					$arrr2[] = $row["arms"];
				}
				$a = implode(',',$arrr2);
				$b = explode(',',$a);
				$f = (array_filter($b));
				
						for($i=0; $i<=(count($f)-1); $i++)
							{  
								echo '<option value="'.$f[$i].'">';
								echo $f[$i];
								echo '</option>';
							}
    echo '</select>';
?>	
	  <br>
	  <select style="width:15%;" name="year" id="year" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM years");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['year'].'">';
								echo $row['year'];
								echo '</option>';
							}
						?>
      </select>
	  
	  
	   <br>
	  <select style="width:15%;" name="term" id="term" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM terms");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['term'].'">';
								echo $row['term'];
								echo '</option>';
							}
						?>
      </select>
	   <br>
	  <select style="width:15%;" name="subject" id="subject" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM subjects");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['subject'].'">';
								echo $row['subject'];
								echo '</option>';
							}
						?>
      </select>
	  
	   <br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM users2 where username='$user' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<input style="display:none" type="hidden" name="teacher_id" value="'.$row['teacher_id'].'">';
							}
						?>  
	  
	  </label>
	  
  <label>
      <input type="submit" class="button" name="btn-upload" id="getscoresbutton" value="Get Scores" />
    </label>

  </div>
  </center>
</form><br>

<?php
//if(isset($_POST['btn-upload'])){
	
$user=$_SESSION['username'];
$result3 = mysqli_query($db, "SELECT * FROM users2 where username='$user' AND school='".$_SESSION["school"]."'");
while($rowtid = mysqli_fetch_assoc($result3))
{
	$a = $rowtid['teacher_id'];
}
$tid =  $a;	
		
$class_name = $_POST['class_name'];
$year = $_POST['year'];
$term = $_POST['term'];
$subject = $_POST['subject'];
$arms = $_POST['arms'];
$teacher_id = $tid;  


$resultcheck2 = mysqli_query($db, "SELECT * FROM scores where arms='$arms' AND class_name='$class_name' AND year='$year' AND term='$term' AND subject='$subject' AND teacher_id='$teacher_id' AND school='".$_SESSION["school"]."' ORDER BY student_name ASC");
$resultcount2 = mysqli_num_rows($resultcheck2);   
if($resultcount2 == 0){
	echo ''; 
}else{
echo '<center>';
echo '<input type="text" placeholder="Max Hw Score" class="txtFirstName" id="txtFirstName"><br>';
echo '<input type="text" placeholder="Max Cw Score" class="txtFirstName1" id="txtFirstName1"><br>';
echo '<input type="text" placeholder="Max Test Score" class="txtFirstName2" id="txtFirstName2"><br>';
echo '<input type="text" placeholder="Max Exam Score" class="txtFirstName3" id="txtFirstName3"><br>';
echo '<button id="dosomething" style="background-color: green; color: white;">Update Max Scores</button>';
echo '<div>NOTE THAT MAX CW, HW AND TEST SCORES ARE FOR ONLY THE 2ND HALF OF THE TERM.<br>TO UPDATE MAX SCORES FOR FIRST HALF, <a href="update-score-mid.php">CLICK HERE.</a></div>';
echo '</center><br>';
}

$resultcheck = mysqli_query($db, "SELECT * FROM scores where arms='$arms' AND class_name='$class_name' AND year='$year' AND term='$term' AND subject='$subject' AND teacher_id='$teacher_id' AND school='".$_SESSION["school"]."' ORDER BY student_name ASC");
$resultcount = mysqli_num_rows($resultcheck);   
if($resultcount == 0){
	echo '<center><span style="color: red; font-size: 16px;">no scores to be updated, given the selected criteria.<br /></span></center>'; 
}else{
echo '<center><span style="color: green; font-size: 16px;">Update the scores of students in your '.$term. ', '.$year.', '.$cl.' '.$arms.', '.$subject.' class.<br /></span></center>';            
	include "connection.php";
	
$resultcheckstu = mysqli_query($db, "SELECT * FROM scores where arms='$arms' AND class_name='$class_name' AND year='$year' AND term='$term' AND subject='$subject' AND teacher_id='$teacher_id' AND school='".$_SESSION["school"]."' ORDER BY student_name ASC");
while($rowmidstu = mysqli_fetch_assoc($resultcheckstu))
{
	$student_na2[] = $rowmidstu['student_name'];
}
$student_na = $student_na2;

$student_nacount = count($student_na);

for($ccount = 0; $ccount<$student_nacount; $ccount++)
{
//include "connection.php";	
$resultmidstt = mysqli_query($db, "SELECT * FROM scoresmid WHERE arms='$arms' AND student_name='$student_na[$ccount]' AND class_name='$class_name' AND year='$year' AND term='$term' AND subject='$subject' AND teacher_id='$teacher_id' AND school='".$_SESSION["school"]."' ORDER BY student_name ASC");	
while($rowmidstt = mysqli_fetch_assoc($resultmidstt))
{ 
 $scor2[] = $rowmidstt['score'];
 $scorraw2[] = $rowmidstt['scoreraw'];
 $hwmaxmid2[] = $rowmidstt['hwmaxname'];
 $cwmaxmid2[] = $rowmidstt['cwmaxname'];
 $testmaxmid2[] = $rowmidstt['testmaxname'];
 break;
}
}
$scor = $scor2;
$scorraw = $scorraw2;
$hwmaxmid = $hwmaxmid2;
$cwmaxmid = $cwmaxmid2;
$testmaxmid = $testmaxmid2;
	$countmid = 0;

echo '<div class="row-fluid" style="width:100%;">';
echo '<div class="span12">';
echo '<div class="container" style="width:100%;">';
echo '<form class="formid" id="formid">';
echo '<table style="width:100%;" cellpadding="1" cellspacing="1" border="1" class="display" id="example">';
echo '<thead><tr style="text-align:left;">';
echo '<th style="display: none;">Score ID</th>';
echo '<th style="text-align: center; width: 3%">Student\'s Name</th>';
echo '<th style="text-align: center; width: 3%">Term Total (%)</th>';
echo '<th style="text-align: center; width: 3%">Midterm Total (%)</th>';
echo '<th style="text-align: center; width: 3%">Midterm Total (Raw)</th>';
echo '<th style="text-align: center; width: 3%">HW (RAW)</th>';
echo '<th style="text-align: center; width: 3%">CW (RAW)</th>';
echo '<th style="text-align: center; width: 3%">TEST (RAW)</th>';
echo '<th style="text-align: center; width: 3%">CA (RAW)</th>';
echo '<th style="text-align: center; width: 3%">EXAM (RAW)</th>';
echo '<th style="text-align: center; width: 3%">HW (30)</th>';
echo '<th style="text-align: center; width: 3%;">CW (30)</th>';
echo '<th style="text-align: center; width: 3%;">TEST (40)</th>';
echo '<th style="text-align: center; width: 3%;">CA (40)</th>';
echo '<th style="text-align: center; width: 3%;">Exam (60)</th>';
echo '<th style="text-align: center; width: 18%;" colspan="4">Remark</th>';
echo '<th style="display: none;">Class</th>';
echo '<th style="display: none;">Year</th>';
echo '<th style="display: none;" >Arm</th>';
echo '<th style="display: none;">Term</th>';
echo '<th style="display: none;">Subject</th>';
echo '<th style="display: none;">Teacher ID</th>';
echo '<th style="text-align: center; width: 3%;">HW Max</th>';
echo '<th style="text-align: center; width: 3%;">CW Max</th>';
echo '<th style="text-align: center; width: 3%;">Test Max</th>';
echo '<th style="text-align: center; width: 3%;">Exam Max</th>';
echo '<th style="text-align: center; width: 3%; display: none;">Mid Hw Max</th>';
echo '<th style="text-align: center; width: 3%; display: none;">Mid Cw Max</th>';
echo '<th style="text-align: center; width: 3%; display: none;">Mid Test Max</th>';
echo '</tr></thead>';
	
$countmidupd = 0;	
$upd = mysqli_query($db, "SELECT * FROM scores where arms='$arms' AND class_name='$class_name' AND year='$year' AND term='$term' AND subject='$subject' AND teacher_id='$teacher_id' AND school='".$_SESSION["school"]."' ORDER BY student_name ASC");
					while($rowupd = mysqli_fetch_assoc($upd))
							{  
							if($scor[$countmidupd]!=""){
							$scoreupd2[] = round(((($rowupd['hw']+$rowupd['cw']+$rowupd['test']+$scor[$countmidupd])/200)*40)+$rowupd['exam']);
							$carawupd2[] = round($rowupd['hwraw']+$rowupd['cwraw']+$rowupd['testraw']+$scorraw[$countmidupd]);
							$caallupd2[] = round(((($rowupd['hw']+$rowupd['cw']+$rowupd['test']+$scor[$countmidupd])/200)*40));
							}
							else{
							$scoreupd2[] = round(((($rowupd['hw']+$rowupd['cw']+$rowupd['test'])/100)*40)+$rowupd['exam']);
							$carawupd2[] = round($rowupd['hwraw']+$rowupd['cwraw']+$rowupd['testraw']);	
							$caallupd2[] = round(((($rowupd['hw']+$rowupd['cw']+$rowupd['test'])/100)*40));
							}
							$countmidupd++;
							}
							$scoreupd = $scoreupd2;
							$carawupd = $carawupd2;
							$caallupd = $caallupd2;
	
$result = mysqli_query($db, "SELECT * FROM scores where arms='$arms' AND class_name='$class_name' AND year='$year' AND term='$term' AND subject='$subject' AND teacher_id='$teacher_id' AND school='".$_SESSION["school"]."' ORDER BY student_name ASC");
					while($row = mysqli_fetch_assoc($result))
							{  
						 echo '<tr>';
							echo '<td style="display: none;  width: 1%;"><input type="text" style="width:60%;" name="score_id[]" id="score_id" value="'.$row['score_id'].'" readonly="readonly" /></td>';
							echo '<td style="text-align: center; width: 13%;"><input style="text-align: center; width: 90%; display: none;" type="text" name="student_name[]" id="student_name" value="'.$row['student_name'].'" readonly />'.$row['student_name'].'</td>';
							 echo '<td style="text-align: center; width: 2%;"><input style="text-align: center; width: 80%;" type="text" value="'.$scoreupd[$countmid].'" name="score[]" id="score" readonly/></td>';
							 echo '<td style="text-align: center; width: 2%;"><input style="text-align: center; width: 80;%" type="text" value="'.$scor[$countmid].'" name="scoremid[]" id="scoremid" readonly/></td>';
							 echo '<td style="text-align: center; width: 2%;"><input style="text-align: center; width: 80;%" type="text" value="'.$scorraw[$countmid].'" name="scoremidraw[]" id="scoremidraw" readonly/></td>'; 
							 
							 echo '<td style="text-align: center; width: 3%;"><input style="text-align: center; width: 60%;" type="text" value="'.$row['hwraw'].'" name="hwraw[]" id="hwraw" /></td>';
							 echo '<td style="text-align: center; width: 3%;"><input style="text-align: center; width: 60%;" type="text" value="'.$row['cwraw'].'" name="cwraw[]" id="cwraw" /></td>';
							 echo '<td style="text-align: center; width: 3%;"><input style="text-align: center; width: 60%;" type="text" value="'.$row['testraw'].'" name="testraw[]" id="testraw" /></td>';
							 echo '<td style="text-align: center; width: 3%;"><input style="text-align: center; width: 60%;" type="text" value="'.$carawupd[$countmid].'" name="caraw[]" id="caraw" readonly/></td>';
							 echo '<td style="text-align: center; width: 3%;"><input style="text-align: center; width: 60%;" type="text"  value="'.$row['examraw'].'" name="examraw[]" id="examraw" /></td>';
							
							 echo '<td style="text-align: center; width: 2%;"><input style="text-align: center; width: 60%;" type="text" value="'.$row['hw'].'" name="hw[]" id="hw" readonly/></td>';
							 echo '<td style="text-align: center; width: 2%;"><input style="text-align: center; width: 60%;" type="text" value="'.$row['cw'].'" name="cw[]" id="cw" readonly/></td>';
							 echo '<td style="text-align: center; width: 2%;"><input style="text-align: center; width: 60%;" type="text" value="'.$row['test'].'" name="test[]" id="test" readonly/></td>';
							 echo '<td style="text-align: center; width: 2%;"><input style="text-align: center; width: 60%;" type="text" value="'.$caallupd[$countmid].'" name="ca[]" id="ca" readonly/></td>';
							 echo '<td style="text-align: center; width: 2%;"><input style="text-align: center; width: 60%;" type="text"  value="'.$row['exam'].'" name="exam[]" id="exam" readonly/></td>';
							 echo '<td colspan="4" style="text-align: center;"><input class="remark" style="text-align: center; width: 80%;" type="text" value="'.$row['remark'].'" name="remark[]" id="remark_'.$countmid.'" /></td>';
							 echo '<td style="display: none;"><input type="text" name="class_name[]" id="class_name" value="'.$row['class_name'].'"></td>';
							 echo '<td style="display: none;"><input type="text" name="year[]" id="year" value="'.$row['year'].'"></td>';
							 echo '<td style="display: none;"><input type="text" name="arms[]" id="arms" value="'.$row['arms'].'"></td>';
							 echo '<td style="display: none;"><input type="text" name="term[]" id="term" value="'.$row['term'].'"></td>';
							 echo '<td style="display: none;"><input type="text" name="subject[]" id="subject" value="'.$row['subject'].'"></td>';
							 echo '<td style="display: none;"><input type="text" name="teacher_id[]" id="teacher_id" value="'.$row['teacher_id'].'"></td>';
							 echo '<td style="text-align: center; width: 3%;"><input style="text-align: center; width: 80%;" class="newhwmax" type="text" name="hwmaxname[]" id="hwmaxname" value="'.$row['hwmaxname'].'" readonly></td>';
							 echo '<td style="text-align: center; width: 3%;"><input style="text-align: center; width: 80;%" class="newcwmax" type="text" name="cwmaxname[]" id="cwmaxname" value="'.$row['cwmaxname'].'" readonly></td>';
							echo '<td style="text-align: center; width: 3%;"><input style="text-align: center; width: 80%;" class="newtestmax" type="text" name="testmaxname[]" id="testmaxname" value="'.$row['testmaxname'].'" readonly></td>';
							 echo '<td style="text-align: center; width: 3%;"><input style="text-align: center; width: 80%;" class="newexammax" type="text" name="exammaxname[]" id="exammaxname" value="'.$row['exammaxname'].'" readonly></td>';
							 echo '<td style="text-align: center; width: 3%; display: none;"><input style="text-align: center; width: 80%;" class="hwmaxmid" type="text" name="hwmaxmid[]" id="hwmaxmid" value="'.$hwmaxmid[$countmid].'" readonly></td>';
							 echo '<td style="text-align: center; width: 3%; display: none;"><input style="text-align: center; width: 80%;" class="cwmaxmid" type="text" name="cwmaxmid[]" id="cwmaxmid" value="'.$cwmaxmid[$countmid].'" readonly></td>';
							echo '<td style="text-align: center; width: 3%; display: none;"><input style="text-align: center; width: 80%;" class="testmaxmid" type="text" name="testmaxmid[]" id="testmaxmid" value="'.$testmaxmid[$countmid].'" readonly></td>';
							echo  '</tr>';
							$countmid++;
							}
echo '</table>';						
echo '<div style="border: 0;">';
echo '<input type="submit" class="submit_button" name="submit" value="Update Scores" />';
echo '<label style="border: 0;">';
echo '<span class="error" style="display:none; color: red;"><img src="table/del.jpg" width="60" height="60"/>An update error has just occurred.</span>';
echo '<span class="success" style="display:none; color: green;"><img src="table/492.png" width="60" height="60"/> Scores updated successfully.</span>';
echo '</label>';
echo '</div>';
echo '</form>';		
echo '</div></div></div>';
}//}
?>
<br>
</div>
<div id="pushit"><div id="pushit2">&nbsp;</div><br><br><br><br><br><br><br><br><br><br></div>
<?php
include("footer.php");
?>
</html>