<?php
	session_start();
	include("auth.php"); 
	include('db.php');
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>subj chart</title>
<!--<link rel="stylesheet" href="style.css" type="text/css" />-->
<script src="table/js/jquery.js" type="text/javascript"></script>
<script>
$(document).ready(function() {	
$("#subjform").submit(function( evt ) {
			evt.preventDefault();
var subj = 	$("#subject").val();		
$.ajax({
type: "POST",
url: "tochart2mid.php",
data: $("#subjform").serialize(),
dataType: 'json',
cache: false,
beforeSend: function(){
$("#subit").after("<div id='pleasewait' >We are preparing your chart. Please wait!</div>");	
},	
success: function(response){
	$('#scores').val(JSON.stringify(response));
	$("#s").val(subj);
	$("#pleasewait").fadeOut(1000);	
	$("#subbuttv").click();
}
});				
});
});
</script>
  
   <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>

<style>
ul.topnav {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}
ul.topnav li {float: left;}
ul.topnav li a {
    display: inline-block;
    color: #f2f2f2;
    text-align: center;
    padding: 12px 14px;
    text-decoration: none;
    transition: 0.3s;
    font-size: 14px;
}
ul.topnav li a:hover {background-color: #555;}
ul.topnav li.icon {display: none;}

@media screen and (max-width:680px) {
  ul.topnav li:not(:first-child) {display: none;}
  ul.topnav li.icon {
    float: right;
    display: inline-block;
  }
}
@media screen and (max-width:680px) {
  ul.topnav.responsive {position: relative;}
  ul.topnav.responsive li.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  ul.topnav.responsive li {
    float: none;
    display: inline;
  }
  ul.topnav.responsive li a {
    display: block;
    text-align: left;
  }
}
</style>
<style>
#subjform, #subjform2, #viewchar {
  margin: auto;
  position: relative;
  width: 100%;
  height: 100%;
  font-family: Tahoma, Geneva, sans-serif;
  font-size: 12px;
  font-style: italic;
  line-height: 24px;
  font-weight: bold;
  color: #09C;
  text-decoration: none;
  border-radius: 10px;
  padding: 10px;
}


input {
  width: 150px;
  display: block;
  border: 1px solid #999;
  height: 20px;
  -webkit-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  -moz-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
}

select {
  width: 60px;
  display: block;
  border: 1px solid #999;
  height: 30px;
  -webkit-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  -moz-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
}

select#upload {
  width: 140px;
  height: 30px;
  display: block;
}

.button {
  width: 100px;
  position: absolute;
  right: 5px;
  bottom: 8px;
  background: #09C;
  color: #fff;
  font-family: Tahoma, Geneva, sans-serif;
  height: 30px;
  border-radius: 15px;
  border: 1p solid #999;
}

input.button:hover {
  background: #fff;
  color: #09C;
}

select:focus, input:focus {
  border: 1px solid #09C;
}
</style>  
 <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
</head>
<body>
<?php
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
elseif($_SESSION['role'] == 'student'){
include("headerstudent.php");
}
else{header("location: logout.php");}
?>
<br><br><br>
<center>
<form id="subjform"  method="post" enctype="multipart/form-data">
	  <select style="width:150px;" name="subject" id="subject" required ><br>        
                    <?php
	include "connection.php";
	$result = mysqli_query($db, "SELECT subject FROM subjects ORDER BY subject ASC");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['subject'].'">';
								echo $row['subject'];
								echo '</option>';
							}
						?>
      </select>
	   <br>
	   <input  type="text"  style="display: none" name="student_name2" value="<?php echo $_POST['student_name']; ?>" />	  
		<input  type="text" style="display: none" name="class2" value="<?php echo $_POST['class_name']; ?>" />
		<input  type="text" style="display: none" name="year2" value="<?php echo $_POST['year']; ?>" />
		<input  type="text" style="display: none" name="term2" value="<?php echo $_POST['term']; ?>" />
		<input  style="display: none;" name="byarm" type="text" value="<?php echo $_POST['byarm']; ?>" />
		<input  style="display: none;" name="arms" type="text" value="<?php echo $_POST['arms']; ?>" />
      <input type="submit" style="background-color: green; color: white;" id='subit' name="btnuploadsubj" value="Submit Subject" />
	  </form>
	  
	<form id="subjform2" action="getresultmid.php" method="post" enctype="multipart/form-data">
		<?php  
$su1 = $_POST['arrsubj'];
$su = unserialize(base64_decode($su1));
$cwork1 = $_POST['cwork'];
$cwork = unserialize(base64_decode($cwork1));
$hwork1 = $_POST['hwork'];
$hwork = unserialize(base64_decode($hwork1));
$test1 = $_POST['test'];
$test = unserialize(base64_decode($test1));
$score1 = $_POST['score'];
$score = unserialize(base64_decode($score1));
$ccav1 = $_POST['ccav'];
$ccav = unserialize(base64_decode($ccav1));
$grade1 = $_POST['grade'];
$grade = unserialize(base64_decode($grade1));
$tn1 = $_POST['tn'];
$tn = unserialize(base64_decode($tn1));
$re1 = $_POST['remark'];
$re = unserialize(base64_decode($re1));
$student_name = $_POST['student_name'];
$class_name = $_POST['class_name'];
$year = $_POST['year'];
$term = $_POST['term'];
$byarm = $_POST['byarm'];
$arms = $_POST['arms'];
		echo '<input  style="display: none;" name="su2" type="text" value="'.base64_encode(serialize($su)). '">';
		echo '<input  style="display: none;" name="ca2" type="text" value="'.base64_encode(serialize($cwork)). '">';
		echo '<input  style="display: none;" name="exam2" type="text" value="'.base64_encode(serialize($hwork)). '">';
		echo '<input  style="display: none;" name="cc2" type="text" value="'.base64_encode(serialize($test)). '">';
		echo '<input  style="display: none;" name="dd2" type="text" value="'.base64_encode(serialize($score)). '">';
		echo '<input  style="display: none;" name="tt2" type="text" value="'.base64_encode(serialize($ccav)). '">';
		echo '<input  style="display: none;" name="av2" type="text" value="'.base64_encode(serialize($grade)). '">';
		echo '<input  style="display: none;" name="ccav2" type="text" value="'.base64_encode(serialize($tn)). '">';
		echo '<input  style="display: none;" name="grade2" type="text" value="'.base64_encode(serialize($re)). '">';
		?>
	   <input  type="text"  style="display: none" name="student_name" value="<?php echo $_POST['student_name']; ?>" />	  
		<input  type="text" style="display: none" name="class_name" value="<?php echo $_POST['class_name']; ?>" />
		<input  type="text" style="display: none" name="year" value="<?php echo $_POST['year']; ?>" />
		<input  type="text" style="display: none;" name="term" value="<?php echo $_POST['term']; ?>" />
		<input  type="text" style="display: none" name="arms" value="<?php echo $_POST['arms']; ?>" />
		<input  type="text" style="display: none;" name="byarm" value="<?php echo $_POST['byarm']; ?>" />
      <input type="submit" style="background-color: green; color: white;" id='subit' name="halftermsub" value="Back" />
	  </form>  
  
  <form id="viewchar" style="display: none;" action="chart.js3mid.php" method="post">
		<input  style="display: none;" type="text"  name="y7arr" id="scores" />
		<input  style="display: none;" type="text"  name="subj" id="s" />
		<input  style="display: none;" type="text"   id="stuname" name="stuname" value="<?php echo $_POST['student_name']; ?>" />	  
		<input  style="display: none;" type="text"  name="cla" value="<?php echo $_POST['class_name']; ?>" />
		<input  type="text" style="display: none" name="yr" value="<?php echo $_POST['year']; ?>" />
		<input  type="text" style="display: none;" name="tm" value="<?php echo $_POST['term']; ?>" />
		<input  type="text" style="display: none" name="arms" value="<?php echo $_POST['arms']; ?>" />
		<input  type="text" style="display: none;" name="sig" value="<?php echo $_POST['sig']; ?>" />
		<input  type="text" style="display: none" name="arms" value="<?php echo $_POST['arms']; ?>" />
		<input  type="text" style="display: none;" name="byarm" value="<?php echo $_POST['byarm']; ?>" />
      <input type="submit" id="subbuttv" style="background-color: green; color: white;" name="btnuploadsubj2" value="View Graph" />
  </form>
  </center>
  <?php
  include("footer.php");
  ?>
</body>