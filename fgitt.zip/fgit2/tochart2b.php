<?php
	session_start();
	include("auth.php"); 
	include('db.php');

$year2 = $_POST['year2'];
$student_name2 = $_POST['student_name2'];	
$subject2 = $_POST['subject'];
$class2 = $_POST['class2'];
$arms2 = $_POST['arms2'];
	include ("connection.php");
	
	if($class2 == 'Year 7'){
		if($arms2==""){
	$resub1 = mysqli_query($db, "SELECT * FROM scores WHERE subject='$subject2' AND class_name='Year 7'  AND term='First Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub2 = mysqli_query($db, "SELECT * FROM scores WHERE subject='$subject2' AND class_name='Year 7'  AND term='Second Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub3 = mysqli_query($db, "SELECT * FROM scores WHERE subject='$subject2' AND class_name='Year 7'  AND term='Third Term' AND student_name='$student_name2' ORDER BY year ASC");
		}
		else{
	$resub1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms2' AND subject='$subject2' AND class_name='Year 7'  AND term='First Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms2' AND subject='$subject2' AND class_name='Year 7'  AND term='Second Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms2' AND subject='$subject2' AND class_name='Year 7'  AND term='Third Term' AND student_name='$student_name2' ORDER BY year ASC");		
		}
	$count7f = mysqli_num_rows($resub1);
	$count7s = mysqli_num_rows($resub2);
	$count7t = mysqli_num_rows($resub3);
	
	if($count7f == 0){
	$y7f = array_fill(0, 1, "0");
	}else{
	while($rowsub1 = mysqli_fetch_assoc($resub1))
							{
							$y7fir[] = $rowsub1['score'];
							}
							$y7f = $y7fir;
	}
	
	
	if($count7s == 0){
	$y7s = array_fill(0, 1, "0");
	}else{
	while($rowsub2 = mysqli_fetch_assoc($resub2))
							{
							$y7sec[] = $rowsub2['score'];
							}
							$y7s = $y7sec;
	}
	
	if($count7t == 0){
	$y7t = array_fill(0, 1, "0");
	}else{
	while($rowsub3 = mysqli_fetch_assoc($resub3))
							{
							$y7thir[] = $rowsub3['score'];
							}
							$y7t = $y7thir;	
	}
	$y7fst = array_merge($y7f,$y7s,$y7t);						
		echo json_encode($y7fst);											
	}

	
	if($class2 == 'Year 1'){
		if($arms2==""){
	$resub1 = mysqli_query($db, "SELECT * FROM scores WHERE subject='$subject2' AND class_name='Year 1'  AND term='First Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub2 = mysqli_query($db, "SELECT * FROM scores WHERE subject='$subject2' AND class_name='Year 1'  AND term='Second Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub3 = mysqli_query($db, "SELECT * FROM scores WHERE subject='$subject2' AND class_name='Year 1'  AND term='Third Term' AND student_name='$student_name2' ORDER BY year ASC");
		}
		else{
	$resub1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms2' AND subject='$subject2' AND class_name='Year 1'  AND term='First Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms2' AND subject='$subject2' AND class_name='Year 1'  AND term='Second Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms2' AND subject='$subject2' AND class_name='Year 1'  AND term='Third Term' AND student_name='$student_name2' ORDER BY year ASC");		
		}
	$count7f = mysqli_num_rows($resub1);
	$count7s = mysqli_num_rows($resub2);
	$count7t = mysqli_num_rows($resub3);
	
	if($count7f == 0){
	$y7f = array_fill(0, 1, "0");
	}else{
	while($rowsub1 = mysqli_fetch_assoc($resub1))
							{
							$y7fir[] = $rowsub1['score'];
							}
							$y7f = $y7fir;
	}
	
	
	if($count7s == 0){
	$y7s = array_fill(0, 1, "0");
	}else{
	while($rowsub2 = mysqli_fetch_assoc($resub2))
							{
							$y7sec[] = $rowsub2['score'];
							}
							$y7s = $y7sec;
	}
	
	if($count7t == 0){
	$y7t = array_fill(0, 1, "0");
	}else{
	while($rowsub3 = mysqli_fetch_assoc($resub3))
							{
							$y7thir[] = $rowsub3['score'];
							}
							$y7t = $y7thir;	
	}
	$y7fst = array_merge($y7f,$y7s,$y7t);						
		echo json_encode($y7fst);											
	}
	
	
	
	
	elseif($class2 == 'Year 2'){
		if($arms2==""){
	$resub1 = mysqli_query($db, "SELECT * FROM scores WHERE subject='$subject2' AND (class_name='Year 1' OR class_name='Year 2') AND term='First Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub2 = mysqli_query($db, "SELECT * FROM scores WHERE subject='$subject2' AND (class_name='Year 1' OR class_name='Year 2')  AND term='Second Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub3 = mysqli_query($db, "SELECT * FROM scores WHERE subject='$subject2' AND (class_name='Year 1' OR class_name='Year 2')  AND term='Third Term' AND student_name='$student_name2' ORDER BY year ASC");
		}
		else{
	$resub1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms2' AND subject='$subject2' AND (class_name='Year 1' OR class_name='Year 2')  AND term='First Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms2' AND subject='$subject2' AND (class_name='Year 1' OR class_name='Year 2')  AND term='Second Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms2' AND subject='$subject2' AND (class_name='Year 1' OR class_name='Year 2')  AND term='Third Term' AND student_name='$student_name2' ORDER BY year ASC");		
		}
	$count7f = mysqli_num_rows($resub1);
	$count7s = mysqli_num_rows($resub2);
	$count7t = mysqli_num_rows($resub3);
	
	if($count7f == 0){
	$y7f = array("0","0");
	}else{
	while($rowsub1 = mysqli_fetch_assoc($resub1))
							{
							$y7fir[] = $rowsub1['score'];
							}
							$y7f = $y7fir;
	}
	
	
	if($count7s == 0){
	$y7s = array("0","0");
	}else{
	while($rowsub2 = mysqli_fetch_assoc($resub2))
							{
							$y7sec[] = $rowsub2['score'];
							}
							$y7s = $y7sec;
	}
	
	if($count7t == 0){
	$y7t = array("0","0");
	}else{
	while($rowsub3 = mysqli_fetch_assoc($resub3))
							{
							$y7thir[] = $rowsub3['score'];
							}
							$y7t = $y7thir;	
	}
	array_push($y7f,"-");
	array_push($y7s,"-");
	$y7fst = array_merge($y7f,$y7s,$y7t);						
		echo json_encode($y7fst);											
	}
		
	elseif($class2 == 'Year 3'){
		if($arms2==""){
	$resub1 = mysqli_query($db, "SELECT * FROM scores WHERE subject='$subject2' AND (class_name='Year 1' OR class_name='Year 2' OR class_name='Year 3') AND term='First Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub2 = mysqli_query($db, "SELECT * FROM scores WHERE subject='$subject2' AND (class_name='Year 1' OR class_name='Year 2' OR class_name='Year 3')  AND term='Second Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub3 = mysqli_query($db, "SELECT * FROM scores WHERE subject='$subject2' AND (class_name='Year 1' OR class_name='Year 2' OR class_name='Year 3')  AND term='Third Term' AND student_name='$student_name2' ORDER BY year ASC");
		}
		else{
	$resub1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms2' AND subject='$subject2' AND (class_name='Year 1' OR class_name='Year 2' OR class_name='Year 3')  AND term='First Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms2' AND subject='$subject2' AND (class_name='Year 1' OR class_name='Year 2' OR class_name='Year 3')  AND term='Second Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms2' AND subject='$subject2' AND (class_name='Year 1' OR class_name='Year 2' OR class_name='Year 3')  AND term='Third Term' AND student_name='$student_name2' ORDER BY year ASC");		
		}
	$count7f = mysqli_num_rows($resub1);
	$count7s = mysqli_num_rows($resub2);
	$count7t = mysqli_num_rows($resub3);
	
	if($count7f == 0){
	$y7f = array("0","0","0");
	}else{
	while($rowsub1 = mysqli_fetch_assoc($resub1))
							{
							$y7fir[] = $rowsub1['score'];
							}
							$y7f = $y7fir;
	}
	
	
	if($count7s == 0){
	$y7s = array("0","0","0");
	}else{
	while($rowsub2 = mysqli_fetch_assoc($resub2))
							{
							$y7sec[] = $rowsub2['score'];
							}
							$y7s = $y7sec;
	}
	
	if($count7t == 0){
	$y7t = array("0","0","0");
	}else{
	while($rowsub3 = mysqli_fetch_assoc($resub3))
							{
							$y7thir[] = $rowsub3['score'];
							}
							$y7t = $y7thir;	
	if(count($y7t)==2){
	array_push($y7t,"0");	
	}
	if(count($y7t)==1){
	array_push($y7t,"0,0");	
	}
	}
	array_push($y7f,"-");
	array_push($y7s,"-");
	$y7fst = array_merge($y7f,$y7s,$y7t);						
		echo json_encode($y7fst);											
	}
		
	
	else if($class2 == 'Year 8'){
		if($arms2=""){
	$resub1 = mysqli_query($db, "SELECT * FROM scores WHERE subject='$subject2' AND (class_name='Year 7' OR class_name='Year 8')  AND term='First Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub2 = mysqli_query($db, "SELECT * FROM scores WHERE subject='$subject2' AND (class_name='Year 7' OR class_name='Year 8')  AND term='Second Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub3 = mysqli_query($db, "SELECT * FROM scores WHERE subject='$subject2' AND (class_name='Year 7' OR class_name='Year 8')  AND term='Third Term' AND student_name='$student_name2' ORDER BY year ASC");
		}
		else{
	$resub1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms2' AND subject='$subject2' AND (class_name='Year 7' OR class_name='Year 8')  AND term='First Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms2' AND subject='$subject2' AND (class_name='Year 7' OR class_name='Year 8')  AND term='Second Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms2' AND subject='$subject2' AND (class_name='Year 7' OR class_name='Year 8')  AND term='Third Term' AND student_name='$student_name2' ORDER BY year ASC");		
		}
	while($rowsub1 = mysqli_fetch_assoc($resub1))
							{
							$y7fir[] = $rowsub1['score'];
							}
							$y7f = $y7fir;
	while($rowsub2 = mysqli_fetch_assoc($resub2))
							{
							$y7sec[] = $rowsub2['score'];
							}
							$y7s = $y7sec;
	while($rowsub3 = mysqli_fetch_assoc($resub3))
							{
							$y7thir[] = $rowsub3['score'];
							}
							$y7t = $y7thir;
	if(count($y7f)==0){
		$y7f = array("0","0");
	}
	if(count($y7s)==0){
		$y7s = array("0","0");
	}
	if(count($y7t)==0){
		$y7t = array("0","0");
	}
	array_push($y7f,"-");
	array_push($y7s,"-");
	$y7fst = array_merge($y7f,$y7s,$y7t);						
		echo json_encode($y7fst);											
	}
	
	
	
	
	
	
	
else if($class2 == 'Year 9'){
	if($arms2=""){
	$resub1 = mysqli_query($db, "SELECT * FROM scores WHERE subject='$subject2' AND (class_name='Year 7' OR class_name='Year 8' OR class_name='Year 9')  AND term='First Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub2 = mysqli_query($db, "SELECT * FROM scores WHERE subject='$subject2' AND (class_name='Year 7' OR class_name='Year 8' OR class_name='Year 9')  AND term='Second Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub3 = mysqli_query($db, "SELECT * FROM scores WHERE subject='$subject2' AND (class_name='Year 7' OR class_name='Year 8' OR class_name='Year 9')  AND term='Third Term' AND student_name='$student_name2' ORDER BY year ASC");
	}
	else{
	$resub1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms2' AND subject='$subject2' AND (class_name='Year 7' OR class_name='Year 8' OR class_name='Year 9')  AND term='First Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms2' AND subject='$subject2' AND (class_name='Year 7' OR class_name='Year 8' OR class_name='Year 9')  AND term='Second Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms2' AND subject='$subject2' AND (class_name='Year 7' OR class_name='Year 8' OR class_name='Year 9')  AND term='Third Term' AND student_name='$student_name2' ORDER BY year ASC");	
	}
	while($rowsub1 = mysqli_fetch_assoc($resub1))
							{
							$y7fir[] = $rowsub1['score'];
							}
							$y7f = $y7fir;
	while($rowsub2 = mysqli_fetch_assoc($resub2))
							{
							$y7sec[] = $rowsub2['score'];
							}
							$y7s = $y7sec;
	while($rowsub3 = mysqli_fetch_assoc($resub3))
							{
							$y7thir[] = $rowsub3['score'];
							}
							$y7t = $y7thir;
							
	if(count($y7f)==0){
		$y7f = array("0","0");
	}
	if(count($y7s)==0){
		$y7s = array("0","0");
	}
	if(count($y7t)==0){
		$y7t = array("0","0");
	}						
	array_push($y7f,"-");
	array_push($y7s,"-");	
	$y7fst = array_merge($y7f,$y7s,$y7t);						
		echo json_encode($y7fst);												
	}
elseif($class2 == 'Year 10'){
	if($arms2=""){
	$resub1 = mysqli_query($db, "SELECT * FROM scores WHERE subject='$subject2' AND (class_name='Year 7' OR class_name='Year 8' OR class_name='Year 9' OR class_name='Year 10')  AND term='First Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub2 = mysqli_query($db, "SELECT * FROM scores WHERE subject='$subject2' AND (class_name='Year 7' OR class_name='Year 8' OR class_name='Year 9' OR class_name='Year 10')  AND term='Second Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub3 = mysqli_query($db, "SELECT * FROM scores WHERE subject='$subject2' AND (class_name='Year 7' OR class_name='Year 8' OR class_name='Year 9' OR class_name='Year 10')  AND term='Third Term' AND student_name='$student_name2' ORDER BY year ASC");
	}
	else{
	$resub1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms2' AND subject='$subject2' AND (class_name='Year 7' OR class_name='Year 8' OR class_name='Year 9' OR class_name='Year 10')  AND term='First Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms2' AND subject='$subject2' AND (class_name='Year 7' OR class_name='Year 8' OR class_name='Year 9' OR class_name='Year 10')  AND term='Second Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms2' AND subject='$subject2' AND (class_name='Year 7' OR class_name='Year 8' OR class_name='Year 9' OR class_name='Year 10')  AND term='Third Term' AND student_name='$student_name2' ORDER BY year ASC");	
	}
	while($rowsub1 = mysqli_fetch_assoc($resub1))
							{
							$y7fir[] = $rowsub1['score'];
							}
							$y7f = $y7fir;
	while($rowsub2 = mysqli_fetch_assoc($resub2))
							{
							$y7sec[] = $rowsub2['score'];
							}
							$y7s = $y7sec;
	while($rowsub3 = mysqli_fetch_assoc($resub3))
							{
							$y7thir[] = $rowsub3['score'];
							}
							$y7t = $y7thir;
							
	if(count($y7f)==0){
		$y7f = array("0","0");
	}
	if(count($y7s)==0){
		$y7s = array("0","0");
	}
	if(count($y7t)==0){
		$y7t = array("0","0");
	}
	array_push($y7f,"-");
	array_push($y7s,"-");	
	$y7fst = array_merge($y7f,$y7s,$y7t);						
		echo json_encode($y7fst);												
	}
elseif($class2 == 'Year 11'){
	if($arms2==""){
	$resub1 = mysqli_query($db, "SELECT * FROM scores WHERE subject='$subject2' AND (class_name='Year 7' OR class_name='Year 8' OR class_name='Year 9' OR class_name='Year 10' OR class_name='Year 11')  AND term='First Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub2 = mysqli_query($db, "SELECT * FROM scores WHERE subject='$subject2' AND (class_name='Year 7' OR class_name='Year 8' OR class_name='Year 9' OR class_name='Year 10' OR class_name='Year 11')  AND term='Second Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub3 = mysqli_query($db, "SELECT * FROM scores WHERE subject='$subject2' AND (class_name='Year 7' OR class_name='Year 8' OR class_name='Year 9' OR class_name='Year 10' OR class_name='Year 11')  AND term='Third Term' AND student_name='$student_name2' ORDER BY year ASC");
	}
	else{
	$resub1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms2' AND subject='$subject2' AND (class_name='Year 7' OR class_name='Year 8' OR class_name='Year 9' OR class_name='Year 10' OR class_name='Year 11')  AND term='First Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms2' AND subject='$subject2' AND (class_name='Year 7' OR class_name='Year 8' OR class_name='Year 9' OR class_name='Year 10' OR class_name='Year 11')  AND term='Second Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms2' AND subject='$subject2' AND (class_name='Year 7' OR class_name='Year 8' OR class_name='Year 9' OR class_name='Year 10' OR class_name='Year 11')  AND term='Third Term' AND student_name='$student_name2' ORDER BY year ASC");	
	}
	while($rowsub1 = mysqli_fetch_assoc($resub1))
							{
							$y7fir[] = $rowsub1['score'];
							}
							$y7f = $y7fir;
	while($rowsub2 = mysqli_fetch_assoc($resub2))
							{
							$y7sec[] = $rowsub2['score'];
							}
							$y7s = $y7sec;
	while($rowsub3 = mysqli_fetch_assoc($resub3))
							{
							$y7thir[] = $rowsub3['score'];
							}
							$y7t = $y7thir;
							
	if(count($y7f)==0){
		$y7f = array("0","0");
	}
	if(count($y7s)==0){
		$y7s = array("0","0");
	}
	if(count($y7t)==0){
		$y7t = array("0","0");
	}
	array_push($y7f,"-");
	array_push($y7s,"-");	
	$y7fst = array_merge($y7f,$y7s,$y7t);						
		echo json_encode($y7fst);											
	}		
else{
	if($arms2=""){
	$resub1 = mysqli_query($db, "SELECT * FROM scores WHERE subject='$subject2' AND (class_name='Year 7' OR class_name='Year 8' OR class_name='Year 9' OR class_name='Year 10' OR class_name='Year 11' OR class_name='Year 12')  AND term='First Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub2 = mysqli_query($db, "SELECT * FROM scores WHERE subject='$subject2' AND (class_name='Year 7' OR class_name='Year 8' OR class_name='Year 9' OR class_name='Year 10' OR class_name='Year 11' OR class_name='Year 12')  AND term='Second Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub3 = mysqli_query($db, "SELECT * FROM scores WHERE subject='$subject2' AND (class_name='Year 7' OR class_name='Year 8' OR class_name='Year 9' OR class_name='Year 10' OR class_name='Year 11' OR class_name='Year 12')  AND term='Third Term' AND student_name='$student_name2' ORDER BY year ASC");
	}
	else{
	$resub1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms2' AND subject='$subject2' AND (class_name='Year 7' OR class_name='Year 8' OR class_name='Year 9' OR class_name='Year 10' OR class_name='Year 11' OR class_name='Year 12')  AND term='First Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms2' AND subject='$subject2' AND (class_name='Year 7' OR class_name='Year 8' OR class_name='Year 9' OR class_name='Year 10' OR class_name='Year 11' OR class_name='Year 12')  AND term='Second Term' AND student_name='$student_name2' ORDER BY year ASC");
	$resub3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms2' AND subject='$subject2' AND (class_name='Year 7' OR class_name='Year 8' OR class_name='Year 9' OR class_name='Year 10' OR class_name='Year 11' OR class_name='Year 12')  AND term='Third Term' AND student_name='$student_name2' ORDER BY year ASC");	
	}
	while($rowsub1 = mysqli_fetch_assoc($resub1))
							{
							$y7fir[] = $rowsub1['score'];
							}
							$y7f = $y7fir;
	while($rowsub2 = mysqli_fetch_assoc($resub2))
							{
							$y7sec[] = $rowsub2['score'];
							}
							$y7s = $y7sec;
	while($rowsub3 = mysqli_fetch_assoc($resub3))
							{
							$y7thir[] = $rowsub3['score'];
							}
							$y7t = $y7thir;
							
	if(count($y7f)==0){
		$y7f = array("0","0");
	}
	if(count($y7s)==0){
		$y7s = array("0","0");
	}
	if(count($y7t)==0){
		$y7t = array("0","0");
	}
	array_push($y7f,"-");
	array_push($y7s,"-");	
	$y7fst = array_merge($y7f,$y7s,$y7t);						
		echo json_encode($y7fst);
}	
?>