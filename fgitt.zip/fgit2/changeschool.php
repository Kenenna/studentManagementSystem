<?php
include("db.php");
$sql = "update regstu set school='CSS'";
mysql_query($sql);

/*
echo '<form id="resetpass" method="POST" action="changeitall.php">';
echo '<input id="username" style="display: none;" type="text" name="username" value="'.$_SESSION['username'].'" />';
echo '<input id="oldp" placeholder="Current Password" type="password" name="oldp" required/>';
echo '<input id="newp" placeholder="New Password" type="password" name="password" required/>';
echo '<input id="confp" placeholder="Confirm New Password" type="password" name="confp" required/>';
echo '<input type="submit" name="submit8" value="Change Password" />';
echo '</form>';	
*/




?>

