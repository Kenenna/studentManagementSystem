<?php
	session_start();
	include("auth.php"); 
	include('db.php');
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>subj chart</title>
<link rel="stylesheet" href="style.css" type="text/css" />
<script src="table/js/jquery.js" type="text/javascript"></script>
<script>
$(document).ready(function() {	
$("#subjform").submit(function( evt ) {
			evt.preventDefault();
var subj = 	$("#subject").val();		
$.ajax({
type: "POST",
url: "tochart2.php",
data: $("#subjform").serialize(),
dataType: 'json',
cache: false,
beforeSend: function(){
$("#subit").after("<div id='pleasewait' >We are preparing your chart. Please wait!</div>");	
},	
success: function(response){
	$('#scores').val(JSON.stringify(response));
	$("#s").val(subj);
	$("#pleasewait").fadeOut(1000);	
	$("#subbuttv").click();
}
});				
});

});
</script>
  
   <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>

<style>
ul.topnav {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}
ul.topnav li {float: left;}
ul.topnav li a {
    display: inline-block;
    color: #f2f2f2;
    text-align: center;
    padding: 12px 14px;
    text-decoration: none;
    transition: 0.3s;
    font-size: 14px;
}
ul.topnav li a:hover {background-color: #555;}
ul.topnav li.icon {display: none;}

@media screen and (max-width:680px) {
  ul.topnav li:not(:first-child) {display: none;}
  ul.topnav li.icon {
    float: right;
    display: inline-block;
  }
}
@media screen and (max-width:680px) {
  ul.topnav.responsive {position: relative;}
  ul.topnav.responsive li.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  ul.topnav.responsive li {
    float: none;
    display: inline;
  }
  ul.topnav.responsive li a {
    display: block;
    text-align: left;
  }
}
</style>
<style>
#subjform, #subjform2, #viewchar {
  margin: auto;
  position: relative;
  width: 100%;
  height: 100%;
  font-family: Tahoma, Geneva, sans-serif;
  font-size: 12px;
  font-style: italic;
  line-height: 24px;
  font-weight: bold;
  color: #09C;
  text-decoration: none;
  border-radius: 10px;
  padding: 10px;
}


input {
  width: 150px;
  display: block;
  border: 1px solid #999;
  height: 20px;
  -webkit-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  -moz-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
}

select {
  width: 60px;
  display: block;
  border: 1px solid #999;
  height: 30px;
  -webkit-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  -moz-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
}

select#upload {
  width: 140px;
  height: 30px;
  display: block;
}

.button {
  width: 100px;
  position: absolute;
  right: 5px;
  bottom: 8px;
  background: #09C;
  color: #fff;
  font-family: Tahoma, Geneva, sans-serif;
  height: 30px;
  border-radius: 15px;
  border: 1p solid #999;
}

input.button:hover {
  background: #fff;
  color: #09C;
}

select:focus, input:focus {
  border: 1px solid #09C;
}
</style>  
<link rel="stylesheet" href="css/styles.css">
   <script src="js/scriptmenu.js"></script>
</head>
<body>
<?php
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
elseif($_SESSION['role'] == 'student'){
include("headerstudent.php");
}
else{header("location: logout.php");}
?>
<br><br><br>
<center>
<form id="subjform"  method="post" enctype="multipart/form-data">
	  <select style="width:150px;" name="subject" id="subject" required ><br>
                   
                    <?php
	include "connection.php";
	$result = mysqli_query($db, "SELECT subject FROM subjects ORDER BY subject ASC");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['subject'].'">';
								echo $row['subject'];
								echo '</option>';
							}
						?>
      </select>
	   <br>
	   <input  type="text"  style="display: none" name="student_name2" value="<?php echo $_POST['student_name']; ?>" />	  
		<input  type="text" style="display: none" name="class2" value="<?php echo $_POST['class_name']; ?>" />
		<input  type="text" style="display: none" name="year2" value="<?php echo $_POST['year']; ?>" />
		<input  type="text" style="display: none" name="term2" value="<?php echo $_POST['term']; ?>" />
		<input  type="text" style="display: none" name="arms2" value="<?php echo $_POST['arms']; ?>" />
		<input  type="text"  style="display: none;" name="sig" value="<?php echo $_POST['sig']; ?>" />
      <input type="submit" style="background-color: green; color: white;" id='subit' name="btnuploadsubj" value="Submit Subject" />
	  </form>
	  
	<form id="subjform2" action="getresult.php" method="post" enctype="multipart/form-data">
		<?php  $strsubj = $_POST["arrsubj"]; 
				$arrsubj = unserialize(base64_decode($strsubj));
				//print_r($arrsubj);
				//echo "<br>";
				$strca = $_POST["ca"]; 
				$arrca = unserialize(base64_decode($strca));
				//echo "<br>";
				//$strca = $_POST["ca"]; 
				//$arrca = unserialize(base64_decode($strca));
				//echo "<br>";
				$strexam = $_POST["exam"]; 
				$arrexam = unserialize(base64_decode($strexam));
				//echo "<br>";
				$strfir = $_POST["fir"]; 
				$arrfir = unserialize(base64_decode($strfir));
				//echo "<br>";
				$strsec = $_POST["sec"]; 
				$arrsec = unserialize(base64_decode($strsec));
				//echo "<br>";
				$strthir = $_POST["thir"]; 
				$arrthir = unserialize(base64_decode($strthir));
				//echo "<br>";
				$stravv = $_POST["avv"]; 
				$arravv = unserialize(base64_decode($stravv));
				//echo "<br>";
				$strccavv = $_POST["ccavv"]; 
				$arrccavv = unserialize(base64_decode($strccavv));
				//echo "<br>";
				$strgrad = $_POST["grad"]; 
				$arrgrad = unserialize(base64_decode($strgrad));
				//echo "<br>";
				$strteacher = $_POST["teacher"]; 
				$arrteacher = unserialize(base64_decode($strteacher));
				//echo "<br>";
				$strremark = $_POST["remark"]; 
				$arrremark = unserialize(base64_decode($strremark));
				//echo "<br>";
				$strhs = $_POST["hs"]; 
				$arrhs = unserialize(base64_decode($strhs));
				//echo "<br>";
		echo '<input  style="display: none;" name="su2" type="text" value="'.base64_encode(serialize($arrsubj)). '">';
		echo '<input  style="display: none;" name="ca2" type="text" value="'.base64_encode(serialize($arrca)). '">';
		echo '<input  style="display: none;" name="exam2" type="text" value="'.base64_encode(serialize($arrexam)). '">';
		echo '<input  style="display: none;" name="cc2" type="text" value="'.base64_encode(serialize($arrfir)). '">';
		echo '<input  style="display: none;" name="dd2" type="text" value="'.base64_encode(serialize($arrsec)). '">';
		echo '<input  style="display: none;" name="tt2" type="text" value="'.base64_encode(serialize($arrthir)). '">';
		echo '<input  style="display: none;" name="av2" type="text" value="'.base64_encode(serialize($arravv)). '">';
		echo '<input  style="display: none;" name="ccav2" type="text" value="'.base64_encode(serialize($arrccavv)). '">';
		echo '<input  style="display: none;" name="grade2" type="text" value="'.base64_encode(serialize($arrgrad)). '">';
		echo '<input  style="display: none;" name="tn2" type="text" value="'.base64_encode(serialize($arrteacher)). '">';
		echo '<input  style="display: none;" name="re2" type="text" value="'.base64_encode(serialize($arrremark)). '">';
		echo '<input  style="display: none;" name="hs2" type="text" value="'.base64_encode(serialize($arrhs)). '">';
		?>
	   <input  type="text"  style="display: none" name="student_name" value="<?php echo $_POST['student_name']; ?>" />	  
		<input  type="text" style="display: none" name="class_name" value="<?php echo $_POST['class_name']; ?>" />
		<input  type="text" style="display: none" name="year" value="<?php echo $_POST['year']; ?>" />
		<input  type="text" style="display: none;" name="term" value="<?php echo $_POST['term']; ?>" />
		<input  type="text" style="display: none;" name="arms" value="<?php echo $_POST['arms']; ?>" />
		<input  type="text" style="display: none;" name="sig" value="<?php echo $_POST['sig']; ?>" />
      <input type="submit" style="background-color: green; color: white;" id='subit' name="submittoresult" value="Back" />
	  </form>  
  
  <form id="viewchar" style="display: none;" action="chart.js3.php" method="post">
		<input  style="display: none;" type="text"  name="y7arr" id="scores" />
		<input  style="display: none;" type="text"  name="subj" id="s" />
		<input  style="display: none;" type="text"   id="stuname" name="stuname" value="<?php echo $_POST['student_name']; ?>" />	  
		<input  style="display: none;" type="text"  name="cla" value="<?php echo $_POST['class_name']; ?>" />
		<input  type="text" style="display: none" name="yr" value="<?php echo $_POST['year']; ?>" />
		<input  type="text" style="display: none;" name="tm" value="<?php echo $_POST['term']; ?>" />
		<input  type="text" style="display: none" name="arms" value="<?php echo $_POST['arms']; ?>" />
		<input  type="text" style="display: none;" name="sig" value="<?php echo $_POST['sig']; ?>" />
      <input type="submit" id="subbuttv" style="background-color: green; color: white;" name="btnuploadsubj2" value="View Graph" />
  </form>
  </center>
  <?php
  include("footer.php");
  ?>
</body>