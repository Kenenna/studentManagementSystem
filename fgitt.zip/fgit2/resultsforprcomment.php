<?php
session_start();
include("auth.php"); //include auth.php file on all secure pages
require_once("connection.php");
$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class'];
		$year = $_POST['year'];
		$term = $_POST['term'];

if($term == "Third Term"){	
	$result1 = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	$sql2 = mysqli_query($db, "SELECT * FROM maxes where subjectname='$subject' AND classname='$class' AND yearname='$year' AND termname='$term' AND teachername='$tna' AND teacheridname='$tid' AND school='".$_SESSION["school"]."'");
					
						while($row1 = mysqli_fetch_assoc($result1))
							{ 
								$firsubject[] = $row1['subject'];
								$firscore[] = $row1['score'];
							}
							$firsubject11 = $firsubject;
							$firscore11 = $firscore;
							$c = array_combine($firsubject11, $firscore11);
							ksort($c);
							$c = array_values($c);
							
	$result2 = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
						while($row2 = mysqli_fetch_assoc($result2))
							{ 
								$secsubject[] = $row2['subject'];
								$secscore[] = $row2['score'];
							}
							$secsubject22 = $secsubject;
							$secscore22 = $secscore;
							$d = array_combine($secsubject22, $secscore22);
							ksort($d);
							$d = array_values($d);
				
							
	$result3 = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
						while($row3 = mysqli_fetch_assoc($result3))
							{ 
								$thirsubject[] = $row3['subject'];
								$thirscore[] = $row3['score'];
							}
							$thirsubject33 = $thirsubject;
							$thirscore33 = $thirscore;
							$t = array_combine($thirsubject33, $thirscore33);
							ksort($t);
							$t = array_values($t);						
							
							$e = array_map(function () {
							return array_sum(func_get_args());
							},$c, $d, $t);
							ksort($e);
$rimg = mysqli_query($db, "SELECT * FROM img WHERE student_name='$student_name' AND school='".$_SESSION["school"]."'");
						while($rowimgg = mysqli_fetch_assoc($rimg))
							{
									$rr2 = $rowimgg['img'];
							}
							$rr = $rr2;
$res = '<label id="rsn" style="text-align: center;">PERFORMANCE DATA ON '.strtoupper($student_name).'</label><label style="float: right;"><img src="'.$rr.'" width="60" height="60" /></label><br>';
$res .= '<table id="tbn" >';									
$res .= '<tr id="heading"><td>SUBJ.</td><td>CA</td><td>EXAM</td><td>FT</td><td>ST</td><td>TT</td><td>AV.</td><td>CLASS AV.</td><td>GRADE</td></td></tr>';	
	
	$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."' ORDER BY subject ASC");
	
	$recav = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
	while($rowcav = mysqli_fetch_assoc($recav))
							{
							$agrcavin[]	= $rowcav['score'];
							}
							//$ag = array_values($agrcav);
							$agrcav = array_filter($agrcavin);
							$agrcav2 = array_sum($agrcav);
	$numbagr = count(array_filter($agrcav));
	$agrcav3 = $agrcav2/$numbagr;
	
	$recav1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Basic Science' AND school='".$_SESSION["school"]."'");
	while($rowcav1 = mysqli_fetch_assoc($recav1))
							{
							$bascavin[]	= $rowcav1['score'];
							}
							$bascav = array_filter($bascavin);
							$bascav2 = array_sum($bascav);
	$numbbas = count(array_filter($bascav));
	$bascav3 = $bascav2/$numbbas;
	
	$recav2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='English' AND school='".$_SESSION["school"]."'");
	while($rowcav2 = mysqli_fetch_assoc($recav2))
							{
							$engcavin[]	= $rowcav2['score'];
							}
							$engcav = array_filter($engcavin);
							$engcav2 = array_sum($engcav);
	$numbeng = count(array_filter($engcav));
	$engcav3 = round($engcav2/$numbeng);
	
	$recav3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Business Studies' AND school='".$_SESSION["school"]."'");
	while($rowcav3 = mysqli_fetch_assoc($recav3))
							{
							$buscavin[]	= $rowcav3['score'];
							}
							$buscav = array_filter($buscavin);
							$buscav2 = array_sum($buscav);
	$numbbus = count(array_filter($buscav));
	$buscav3 = round($buscav2/$numbbus);
	
	$recav4 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Catering' AND school='".$_SESSION["school"]."'");
	while($rowcav4 = mysqli_fetch_assoc($recav4))
							{
							$catcavin[]	= $rowcav4['score'];
							}
							$catcav = array_filter($catcavin);
							$catcav2 = array_sum($catcav);
	$numbcat = count(array_filter($catcav));
	$catcav3 = $catcav2/$numbcat;
	
	$recav5 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Civic Education' AND school='".$_SESSION["school"]."'");
	while($rowcav5 = mysqli_fetch_assoc($recav5))
							{
							$civcavin[]	= $rowcav5['score'];
							}
							$civcav = array_filter($civcavin);
							$civcav2 = array_sum($civcav);
	$numbciv = count(array_filter($civcav));
	$civcav3 = $civcav2/$numbciv;
	
	$recav6 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Crk' AND school='".$_SESSION["school"]."'");
	while($rowcav6 = mysqli_fetch_assoc($recav6))
							{
							$crkcavin[]	= $rowcav6['score'];
							}
							$crkcav = array_filter($crkcavin);
							$crkcav2 = array_sum($crkcav);
	$numbcrk = count(array_filter($crkcav));
	$crkcav3 = $crkcav2/$numbcrk;
	
	$recav7 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Food and Nutrition' AND school='".$_SESSION["school"]."'");
	while($rowcav7 = mysqli_fetch_assoc($recav7))
							{
							$foocavin[]	= $rowcav7['score'];
							}
							$foocav = array_filter($foocavin);
							$foocav2 = array_sum($foocav);
	$numbfoo = count(array_filter($foocav));
	$foocav3 = $foocav2/$numbfoo;
	
	$recav8 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='French' AND school='".$_SESSION["school"]."'");
	while($rowcav8 = mysqli_fetch_assoc($recav8))
							{
							$frecavin[]	= $rowcav8['score'];
							}
							$frecav = array_filter($frecavin);
							$frecav2 = array_sum($frecav);
	$numbfre = count(array_filter($frecav));
	$frecav3 = $frecav2/$numbfre;
	
	$recav9 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='ICT' AND school='".$_SESSION["school"]."'");
	while($rowcav9 = mysqli_fetch_assoc($recav9))
							{
							$ictcavin[]	= $rowcav9['score'];
							}
							$ictcav = array_filter($ictcavin);
							$ictcav2 = array_sum($ictcav);
	$numbict = count(array_filter($ictcav));
	$ictcav3 = $ictcav2/$numbict;
	
	$recav10 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Igbo' AND school='".$_SESSION["school"]."'");
	while($rowcav10 = mysqli_fetch_assoc($recav10))
							{
							$igbcavin[]	= $rowcav10['score'];
							}
							$igbcav = array_filter($igbcavin);
							$igbcav2 = array_sum($igbcav);
	$numbigb = count(array_filter($igbcav));
	$igbcav3 = $igbcav2/$numbigb;
	
	$recav11 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Mathematics' AND school='".$_SESSION["school"]."'");
	while($rowcav11 = mysqli_fetch_assoc($recav11))
							{
							$matcavin[]	= $rowcav11['score'];
							}
							$matcav = array_filter($matcavin);
							$matcav2 = array_sum($matcav);
	$numbmat = count(array_filter($matcav));
	$matcav3 = $matcav2/$numbmat;
	
	$recav12 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Music' AND school='".$_SESSION["school"]."'");
	while($rowcav12 = mysqli_fetch_assoc($recav12))
							{
							$muscavin[]	= $rowcav12['score'];
							}
							$muscav = array_filter($muscavin);
							$muscav2 = array_sum($muscav);
	$numbmus = count(array_filter($muscav));
	$muscav3 = $muscav2/$numbmus;
	
	$recav13 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='PHE' AND school='".$_SESSION["school"]."'");
	while($rowcav13 = mysqli_fetch_assoc($recav13))
							{
							$phecavin[]	= $rowcav13['score'];
							}
							$phecav = array_filter($phecavin);
							$phecav2 = array_sum($phecav);
	$numbphe = count(array_filter($phecav));
	$phecav3 = $phecav2/$numbphe;

	$recav14 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Social Studies' AND school='".$_SESSION["school"]."'");
	while($rowcav14 = mysqli_fetch_assoc($recav14))
							{
							$soccavin[]	= $rowcav14['score'];
							}
							$soccav = array_filter($soccavin);
							$soccav2 = array_sum($soccav);
	$numbsoc = count(array_filter($soccav));
	$soccav3 = $soccav2/$numbsoc;
	
	$recav15 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Biology' AND school='".$_SESSION["school"]."'");
	while($rowcav15 = mysqli_fetch_assoc($recav15))
							{
							$biocavin[]	= $rowcav15['score'];
							}
							$biocav = array_filter($biocavin);
							$biocav2 = array_sum($biocav);
	$numbbio = count(array_filter($biocav));
	$biocav3 = $biocav2/$numbbio;
	
	$recav16 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Chemistry' AND school='".$_SESSION["school"]."'");
	while($rowcav16 = mysqli_fetch_assoc($recav16))
							{
							$checavin[]	= $rowcav16['score'];
							}
							$checav = array_filter($checavin);
							$checav2 = array_sum($checav);
	$numbche = count(array_filter($checav));
	$checav3 = $checav2/$numbche;
	
	$recav17 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Economics' AND school='".$_SESSION["school"]."'");
	while($rowcav17 = mysqli_fetch_assoc($recav17))
							{
							$ecocavin[]	= $rowcav17['score'];
							}
							$ecocav = array_filter($ecocavin);
							$ecocav2 = array_sum($ecocav);
	$numbeco = count(array_filter($ecocav));
	$ecocav3 = $ecocav2/$numbeco;
	
	$recav18 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Government' AND school='".$_SESSION["school"]."'");
	while($rowcav18 = mysqli_fetch_assoc($recav18))
							{
							$govcavin[]	= $rowcav18['score'];
							}
							$govcav = array_filter($govcavin);
							$govcav2 = array_sum($govcav);
	$numbgov = count(array_filter($govcav));
	$govcav3 = $govcav2/$numbgov;
	
	$recav19 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='VA' AND school='".$_SESSION["school"]."'");
	while($rowcav19 = mysqli_fetch_assoc($recav19))
							{
							$vacavin[]	= $rowcav19['score'];
							}
							$vacav = array_filter($vacavin);
							$vacav2 = array_sum($vacav);
	$numbva = count(array_filter($vacav));
	$vacav3 = $vacav2/$numbva;
	
	$recav20 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='TD' AND school='".$_SESSION["school"]."'");
	while($rowcav20 = mysqli_fetch_assoc($recav20))
							{
							$tdcavin[]	= $rowcav20['score'];
							}
							$vacav = array_filter($tdcavin);
							$tdcav2 = array_sum($tdcav);
	$numbtd = count(array_filter($tdcav));
	$tdcav3 = $tdcav2/$numbtd;
	
	$recav21 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Sociology' AND school='".$_SESSION["school"]."'");
	while($rowcav21 = mysqli_fetch_assoc($recav21))
							{
							$socicavin[]	= $rowcav21['score'];
							}
							$socicav = array_filter($socicavin);
							$socicav2 = array_sum($socicav);
	$numbsoci = count(array_filter($socicav));
	$socicav3 = $socicav2/$numbsoci;
							
	$recav22 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Physics' AND school='".$_SESSION["school"]."'");
	while($rowcav22 = mysqli_fetch_assoc($recav22))
							{
							$phycavin[]	= $rowcav22['score'];
							}
							$phycav = array_filter($phycavin);
							$phycav2 = array_sum($phycav);
	$numbphy = count(array_filter($phycav));
	$phycav3 = $phycav2/$numbphy;
	
	$recav23 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Marketing' AND school='".$_SESSION["school"]."'");
	while($rowcav23 = mysqli_fetch_assoc($recav23))
							{
							$marcavin[]	= $rowcav23['score'];
							}
							$marcav = array_filter($marcavin);
							$marcav2 = array_sum($marcav);
	$numbmar = count(array_filter($marcav));
	$marcav3 = $marcav2/$numbmar;
	
	$recav24 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Lit in English' AND school='".$_SESSION["school"]."'");
	while($rowcav24 = mysqli_fetch_assoc($recav24))
							{
							$litcavin[]	= $rowcav24['score'];
							}
							$litcav = array_filter($litcavin);
							$litcav2 = array_sum($litcav);
	$numblit = count(array_filter($litcav));
	$litcav3 = $litcav2/$numblit;
	
	$recav25 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Yoruba' AND school='".$_SESSION["school"]."'");
	while($rowcav25 = mysqli_fetch_assoc($recav25))
							{
							$yorcavin[]	= $rowcav25['score'];
							}
							$yorcav = array_filter($yorcavin);
							$yorcav2 = array_sum($yorcav);
	$numbyor = count(array_filter($yorcav));
	$yorcav3 = $yorcav2/$numbyor;
	
	$recav26 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Quantitative Reasoning' AND school='".$_SESSION["school"]."'");
	while($rowcav26 = mysqli_fetch_assoc($recav26))
							{
							$qrcavin[]	= $rowcav26['score'];
							}
							$qrcav = array_filter($qrcavin);
							$qrcav2 = array_sum($qrcav);
	$numbqr = count(array_filter($qrcav));
	$qrcav3 = $qrcav2/$numbqr;
	
	$recav27 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Quantitative Reasoning' AND school='".$_SESSION["school"]."'");
	while($rowcav27 = mysqli_fetch_assoc($recav27))
							{
							$vrcavin[]	= $rowcav27['score'];
							}
							$vrcav = array_filter($vrcavin);
							$vrcav2 = array_sum($vrcav);
	$numbvr = count(array_filter($vrcav));
	$vrcav3 = $vrcav2/$numbvr;
	
	$recav28 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Geography' AND school='".$_SESSION["school"]."'");
	while($rowcav28 = mysqli_fetch_assoc($recav28))
							{
							$geocavin[]	= $rowcav28['score'];
							}
							$geocav = array_filter($geocavin);
							$geocav2 = array_sum($geocav);
	$numbgeo = count(array_filter($geocav));
	$geocav3 = $geocav2/$numbgeo;
	
	$recav29 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Handwriting' AND school='".$_SESSION["school"]."'");
	while($rowcav29 = mysqli_fetch_assoc($recav29))
							{
							$hwcavin[]	= $rowcav29['score'];
							}
							$hwcav = array_filter($hwcavin);
							$hwcav2 = array_sum($hwcav);
	$numbhw = count(array_filter($hwcav));
	$hwcav3 = $hwcav2/$numbhw;
	
	$recav30 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Vocational Aptitude' AND school='".$_SESSION["school"]."'");
	while($rowcav30 = mysqli_fetch_assoc($recav30))
							{
							$vapcavin[]	= $rowcav30['score'];
							}
							$vapcav = array_filter($vapcavin);
							$vapcav2 = array_sum($vapcav);
	$numbvap = count(array_filter($vapcav));
	$vapcav3 = $vapcav2/$numbvap;
	
	$counter = 0;
	$counted = 0;
	while($row = mysqli_fetch_assoc($result))
							{								
		$to = Array($c[$counted], $d[$counted], $t[$counted]);
		if(($t[$counted] == 0) AND ($c[$counted] != 0) AND ($d[$counted] != 0)){$avdiv = 2; $t[$counted] = "-";}
		elseif(($t[$counted] == 0) AND ($c[$counted] != 0) AND ($d[$counted] == 0)){$avdiv = 1; $t[$counted] = "-"; $d[$counted] = "-";}
		elseif(($t[$counted] != 0) AND ($c[$counted] != 0) AND ($d[$counted] != 0)){$avdiv = 3;}
		else{$avdiv = 3;}
		$to2 = array_sum($to);
		$av = round($to2/$avdiv);
								//$av = round(($e[$counter++]) / 3);
								$cc = $c[$counted];
								$dd = $d[$counted];
								$tt = $t[$counted];
								if($av >= 80){$grade = "A1"; }
								else if(($av >= 70) AND ($av <= 79)){$grade = "B2";}
								else if(($av >= 65) AND ($av <= 69)){$grade = "B3";}
								else if(($av >= 60) AND ($av <= 64)){$grade = "C4";}
								else if(($av >= 55) AND ($av <= 59)){$grade = "C5";}
								else if(($av >= 50) AND ($av <= 54)){$grade = "C6";}
								else if(($av >= 45) AND ($av <= 49)){$grade = "D7";}
								else if(($av >= 40) AND ($av <= 44)){$grade = "E8";}
								else if(($av <= 39) AND ($av != 0)){$grade = "F9";}
								else if(($av == 0)){$grade = "-";}
								else if(($av == "")){$grade = "-";}
								else {$grade = "NA";}
								
								if($row["subject"] == "Agricultural Science"){$ccav = $agrcav3;}
								elseif($row["subject"] == "Basic Science"){$ccav = $bascav3;}
								elseif($row["subject"] == "English"){$ccav = $engcav3;}
								elseif($row["subject"] == "Business Studies"){$ccav = $buscav3;}
								elseif($row["subject"] == "Catering"){$ccav = $catcav3;}
								elseif($row["subject"] == "Civic Education"){$ccav = $civcav3;}
								elseif($row["subject"] == "Crk"){$ccav = $crkcav3;}
								elseif($row["subject"] == "Food and Nutrition"){$ccav = $foocav3;}
								elseif($row["subject"] == "ICT"){$ccav = $ictcav3;}
								elseif($row["subject"] == "French"){$ccav = $frecav3;}
								elseif($row["subject"] == "Igbo"){$ccav = $igbcav3;}
								elseif($row["subject"] == "Mathematics"){$ccav = $matcav3;}
								elseif($row["subject"] == "Music"){$ccav = $muscav3;}
								elseif($row["subject"] == "PHE"){$ccav = $phecav3;}
								elseif($row["subject"] == "Social Studies"){$ccav = $soccav3;}
								elseif($row["subject"] == "Biology"){$ccav = $biocav3;}
								elseif($row["subject"] == "Chemistry"){$ccav = $checav3;}
								elseif($row["subject"] == "Economics"){$ccav = $ecocav3;}
								elseif($row["subject"] == "Government"){$ccav = $govcav3;}
								elseif($row["subject"] == "VA"){$ccav = $vacav3;}
								elseif($row["subject"] == "TD"){$ccav = $tdcav3;}
								elseif($row["subject"] == "Sociology"){$ccav = $socicav3;}
								elseif($row["subject"] == "Marketing"){$ccav = $marcav3;}
								elseif($row["subject"] == "Physics"){$ccav = $phycav3;}
								elseif($row["subject"] == "Lit in English"){$ccav = $litcav3;}
								elseif($row["subject"] == "Yoruba"){$ccav = $yorcav3;}
								elseif($row["subject"] == "Quantitative Reasoning"){$ccav = $qrcav3;}
								elseif($row["subject"] == "Verbal Reasoning"){$ccav = $vrcav3;}
								elseif($row["subject"] == "Geography"){$ccav = $geocav3;}
								elseif($row["subject"] == "Handwriting"){$ccav = $hwcav3;}
								elseif($row["subject"] == "Vocational Aptitude"){$ccav = $vapcav3;}
								elseif($ccav == ""){$ccav = "-";}
								else{$ccav = "-";}
								$su = $row["subject"];
								$tn = $row["teacher_name"];
								$re = $row["remark"];
								$ct = $row["ca"];
								$ex = $row["exam"];
'<tr><td>'.$su.'</td><td>'.$ct.'</td><td>'.$ex.'</td><td>'.$tt.'</td><td>'.$dd.'</td><td>'.$cc.'</td><td>'.$av.'</td><td id="mytd">'.round($ccav).'</td><td>'.$grade.'</td><td>'.$tn.'</td><td>'.$re.'</td></tr>';	
	$res .= "<tr><td>".$su."</td><td>".$ct."</td><td>".$ex."</td><td>".$cc."</td><td>".$dd."</td><td>".$tt."</td><td>".$av."</td><td>".round($ccav)."</td><td>".$grade."</td></tr>";
							$counted++;
							$arrsubj2[] = $su;
							$ca2[] = $ct;
							$exam2[] = $ex;
							$fir2[] = $cc;
							$sec2[] = $dd;
							$thir2[] = $tt;
							$av2[] = $av;
							$ccav2[] = round($ccav);
							$grad2[] = $grade;
							$teacher2[] = $tn;
							$remark2[] = $re;
							}
	$res .= "</table>";
	echo $res;
	}
	else{
$res = '<label id="rsn" style="text-align: center;">PERFORMANCE DATA ON '.strtoupper($student_name).'</label><br>';
$res .= '<table id="tbn" >';									
$res .= '<tr id="heading"><td>SUBJ.</td><td>CA</td><td>EXAM</td><td>TOTAL</td><td>GRADE</td></td></tr>';	
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39) AND ($row["score"] != 0)){$grade = "F9";}
								else if(($row["score"] == 0)){$grade = "-";}
								else if(($row["score"] == "")){$grade = "-";}
								else {$grade = "NA";}
$res .= '<tr><td>'.$row["subject"].'</td><td>'.$row["ca"].'</td><td>'.$row["exam"].'</td><td>'.$row["score"].'</td><td>'.$grade.'</td></tr>';								
							}
	$res .= "</table>";
	echo $res;						
	}
?>