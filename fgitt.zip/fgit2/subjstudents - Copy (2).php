<?php
	include("check.php");	
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Home</title>
<link rel="stylesheet" href="style.css" type="text/css" />

</head>

<body>
<h1 class="hello">Hello, <em><?php echo $login_user;?>!</em></h1>



<form action="" method="post" enctype="multipart/form-data">
<center>
 <div>
   
	<label><select style="width:15%;" name="class_name" id="class" required ><br>
                   
                    <?php
	include "connection.php";
	$result = mysqli_query($db, "SELECT * FROM classes");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['class_name'].'">';
								echo $row['class_name'];
								echo '</option>';
							}
						?>
      </select>
	  
	  <br><br>
	  <select style="width:15%;" name="year" id="year" required ><br>
                   
                    <?php
	include "connection.php";
	$result = mysqli_query($db, "SELECT * FROM years");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['year'].'">';
								echo $row['year'];
								echo '</option>';
							}
						?>
      </select>
	  
	  
	   <br><br>
	  <select style="width:15%;" name="term" id="term" required ><br>
                   
                    <?php
	include "connection.php";
	$result = mysqli_query($db, "SELECT * FROM terms");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['term'].'">';
								echo $row['term'];
								echo '</option>';
							}
						?>
      </select>
	   <br><br>
	   
	   <select style="width:15%;" name="subject" id="subject" required ><br>
                   
                    <?php
	include "connection.php";
	$result = mysqli_query($db, "SELECT * FROM subjects");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['subject'].'">';
								echo $row['subject'];
								echo '</option>';
							}
						?>
      </select>
	   <br> 
	   
	  <br>
                   
                    <?php
	include "connection.php";
	$result = mysqli_query($db, "SELECT * FROM users where username='$login_user'");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<input type="hidden" name="teacher_id" value="'.$row['teacher_id'].'">';
							}
						?>  
	   <br>
	  </label>
	  
  <label><br><br>
      <input type="submit" class="button" name="btn-upload" value="Submit Form" />
    </label>

  </div>
  </center><BR><BR>
</form><br>



<?php
//if(isset($_POST['btn-upload'])){	
$class = $_POST['class_name'];
$year = $_POST['year'];
$term = $_POST['term'];
$subject = $_POST['subject'];
$teacher_id = $_POST['teacher_id'];

//echo '<form action="studentbyclass.php" method="post">';
echo 'Select Students<br />';
include "connection.php";
$result = mysqli_query($db, "SELECT * FROM studentsbyclass where class='$class' AND year='$year' AND term='$term'");
$result2 = mysqli_query($db, "SELECT * FROM students where class_name='$class' AND year='$year' AND term='$term' AND teacher_id='$teacher_id' AND subject='$subject'");
$values = array();
$values2= array();

while($row2 = mysqli_fetch_assoc($result2))
{  						
//echo '<input type="checkbox" name="student_name[]" value="'.$row['student_name'].'" />'.$row['student_name'].'<br />';
//echo '<input type="hidden" name="teacher_id" value="'.$teacher_id.'" /><input type="hidden" name="class" value="'.$row['class'].'" /><input type="hidden" name="subject" value="'.$subject.'" /><input type="hidden" name="year" value="'.$row['year'].'" /><input type="hidden" name="term" value="'.$row['term'].'" /><br /><br>';
$values2[] = $row2['student_name'];
}
//print_r($values2);
echo '<br>';
while($row = mysqli_fetch_assoc($result))
{  						
//echo '<input type="checkbox" name="student_name[]" value="'.$row['student_name'].'" />'.$row['student_name'].'<br />';
//echo '<input type="hidden" name="teacher_id" value="'.$teacher_id.'" /><input type="hidden" name="class" value="'.$row['class'].'" /><input type="hidden" name="subject" value="'.$subject.'" /><input type="hidden" name="year" value="'.$row['year'].'" /><input type="hidden" name="term" value="'.$row['term'].'" /><br /><br>';
$values[] = $row['student_name'];
}
//echo '<input type="submit" name="submit" value="Submit" />';
//print_r($values);
//}
echo '<br>';

$r = array_diff($values, $values2); 


if(count($r) < 1){
	echo "NO STUDENTS FOUND!<br>";
}
else{
echo '<br>';
echo '<form action="studentbyclass.php" method="post">';
foreach ($r as $key => $student_name) {
echo '<input type="checkbox" name="student_name[]" value="'.$student_name.'" />'.$student_name.'<br />';
echo '<input type="hidden" name="teacher_id" value="'.$teacher_id.'" /><input type="hidden" name="class" value="'.$class.'" /><input type="hidden" name="subject" value="'.$subject.'" /><input type="hidden" name="year" value="'.$year.'" /><input type="hidden" name="term" value="'.$term.'" /><br><br>';
//echo '<input type="hidden" name="class" value="'.$class.'" /><br>';
//echo '<input type="hidden" name="subject" value="'.$subject.'" /><br>';
//echo '<input type="hidden" name="year" value="'.$year.'" /><br>';
//echo '<input type="hidden" name="term" value="'.$term.'" /><br /><br>';
}
echo '<input type="submit" name="submit" value="Submit" />';
echo '</form>';
}
?>


<br><br>
<a href="home.php" style="font-size:18px">Dashboard</a><br>
<a href="teacher-student.php" style="font-size:18px">Insert Scores</a><br>
<a href="logout.php" style="font-size:18px">Logout</a>
</body>
</html>