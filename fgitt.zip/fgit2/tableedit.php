<?php
session_start();
include("auth.php");
include('db.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Edit Affective</title>
<script type="text/javascript" src="edittablejs.js"></script>
  
   <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>
<script type="text/javascript">
$(document).ready(function(){
 $(".tdinput").keypress(function (e) {
if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
	alert("not a number");
	return false;
}
});
 $(".editbox").keypress(function (e) {
if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
	alert("not a number");
	return false;
}
});
});
</script>
<script type="text/javascript">
$(document).ready(function()
{
$(".edit_tr").click(function()
{
var ID=$(this).attr('id');
var firstt=$("#first_"+ID).html();
$("#ff").val(firstt);
var lastt=$("#last_"+ID).html();
$("#ll").val(lastt);
var midd=$("#mid_"+ID).html();
$("#mm").val(midd);
var nn=$("#pfirst_"+ID).html();
$("#nn").val(nn);
var oo=$("#plast_"+ID).html();
$("#oo").val(oo);
var pp=$("#pmid_"+ID).html();
$("#pp").val(pp);

$("#first_"+ID).hide();
$("#last_"+ID).hide();
$("#mid_"+ID).hide();
$("#pfirst_"+ID).hide();
$("#plast_"+ID).hide();
$("#pmid_"+ID).hide();
$("#first_input_"+ID).show();
$("#last_input_"+ID).show();
$("#mid_input_"+ID).show();
$("#pfirst_input_"+ID).show();
$("#plast_input_"+ID).show();
$("#pmid_input_"+ID).show();
}).change(function()
{
var ID=$(this).attr('id');
var first=$("#first_input_"+ID).val();
var last=$("#last_input_"+ID).val();
var mid=$("#mid_input_"+ID).val();
var pfirst=$("#pfirst_input_"+ID).val();
var plast=$("#plast_input_"+ID).val();
var pmid=$("#pmid_input_"+ID).val();
var dataString = 'id='+ ID +'&firstname='+first+'&lastname='+last+'&midname='+mid+'&pfirstname='+pfirst+'&plastname='+plast+'&pmidname='+pmid;
//$("#imgroller").html('<img src="load.gif" />');
if(first.length && last.length>0)
{
if(first>5 || first<1){
alert('Enter a number from 1-5');
$("#first_input_"+ID).focus();
$("#first_"+ID).show();
$("#last_"+ID).show();
$("#mid_"+ID).show();
$("#pfirst_"+ID).show();
$("#plast_"+ID).show();
$("#pmid_"+ID).show();
$("#first_input_"+ID).hide();
$("#last_input_"+ID).hide();
$("#mid_input_"+ID).hide();
$("#pfirst_input_"+ID).hide();
$("#plast_input_"+ID).hide();
$("#pmid_input_"+ID).hide();
}	
else if(last>5){
alert('Enter a number from 1-5');
$("#last_input_"+ID).focus();
$("#first_"+ID).show();
$("#last_"+ID).show();
$("#mid_"+ID).show();
$("#pfirst_"+ID).show();
$("#plast_"+ID).show();
$("#pmid_"+ID).show();
$("#first_input_"+ID).hide();
$("#last_input_"+ID).hide();
$("#mid_input_"+ID).hide();
$("#pfirst_input_"+ID).hide();
$("#plast_input_"+ID).hide();
$("#pmid_input_"+ID).hide();
}
else if(mid>5){
alert('Enter a number from 1-5');
$("#mid_input_"+ID).focus();
$("#first_"+ID).show();
$("#last_"+ID).show();
$("#mid_"+ID).show();
$("#pfirst_"+ID).show();
$("#plast_"+ID).show();
$("#pmid_"+ID).show();
$("#first_input_"+ID).hide();
$("#last_input_"+ID).hide();
$("#mid_input_"+ID).hide();
$("#pfirst_input_"+ID).hide();
$("#plast_input_"+ID).hide();
$("#pmid_input_"+ID).hide();
}
else if(pfirst>5){
alert('Enter a number from 1-5');    
$("#pfirst_input_"+ID).focus();
$("#first_"+ID).show();
$("#last_"+ID).show();
$("#mid_"+ID).show();
$("#pfirst_"+ID).show();
$("#plast_"+ID).show();
$("#pmid_"+ID).show();
$("#first_input_"+ID).hide();
$("#last_input_"+ID).hide();
$("#mid_input_"+ID).hide();
$("#pfirst_input_"+ID).hide();
$("#plast_input_"+ID).hide();
$("#pmid_input_"+ID).hide();
}
else if(plast>5){
alert('Enter a number from 1-5');    
$("#plast_input_"+ID).focus();
$("#first_"+ID).show();
$("#last_"+ID).show();
$("#mid_"+ID).show();
$("#pfirst_"+ID).show();
$("#plast_"+ID).show();
$("#pmid_"+ID).show();
$("#first_input_"+ID).hide();
$("#last_input_"+ID).hide();
$("#mid_input_"+ID).hide();
$("#pfirst_input_"+ID).hide();
$("#plast_input_"+ID).hide();
$("#pmid_input_"+ID).hide();
}
else if(pmid>5){
alert('Enter a number from 1-5');   
$("#pmid_input_"+ID).focus();
$("#first_"+ID).show();
$("#last_"+ID).show();
$("#mid_"+ID).show();
$("#pfirst_"+ID).show();
$("#plast_"+ID).show();
$("#pmid_"+ID).show();
$("#first_input_"+ID).hide();
$("#last_input_"+ID).hide();
$("#mid_input_"+ID).hide();
$("#pfirst_input_"+ID).hide();
$("#plast_input_"+ID).hide();
$("#pmid_input_"+ID).hide();
}
if(first>5 || first<1 || last>5 || last<1 || mid>5 || mid<1 || pfirst>5 || pfirst<1 || plast>5 || plast<1 || pmid>5 || pmid<1){
$("#first_"+ID).html($("#ff").val());
$("#first_input_"+ID).val($("#ff").val());
$("#last_"+ID).html($("#ll").val());
$("#last_input_"+ID).val($("#ll").val());
$("#mid_"+ID).html($("#mm").val());
$("#mid_input_"+ID).val($("#mm").val());
$("#pfirst_"+ID).html($("#nn").val());
$("#pfirst_input_"+ID).val($("#nn").val());
$("#plast_"+ID).html($("#oo").val());
$("#plast_input_"+ID).val($("#oo").val());
$("#pmid_"+ID).html($("#pp").val());
$("#pmid_input_"+ID).val($("#pp").val());
}else{
$.ajax({
type: "POST",
url: "table_edit_ajax.php",
data: dataString,
cache: false,
success: function(html)
{
$("#first_"+ID).html(first);
$("#last_"+ID).html(last);
$("#mid_"+ID).html(mid);
$("#pfirst_"+ID).html(pfirst);
$("#plast_"+ID).html(plast);
$("#pmid_"+ID).html(pmid);
}
});
}
//$("#imgroller").html('<img src="load.gif" />');
}
else
{
alert('Enter something.');
}
});

$(".editbox").mouseup(function() 
{
return false
});

$(document).mouseup(function(){
$(".editbox").hide();
$(".text").show();
});

});
</script>
<style>
body
{
font-family:Arial, Helvetica, sans-serif;
font-size:14px;
}
.editbox
{
display:none
}
td
{
padding:7px;
}
.editbox
{
font-size:14px;
width:80px;
background-color:#ffffcc;

border:solid 1px #000;
padding:4px;
}
.edit_tr:hover
{
background:url(edit.png) right no-repeat #80C8E5;
cursor:pointer;
}
th
{
font-weight:bold;
text-align:left;
padding:4px;
}
.head
{
background-color:#333;
color:#FFFFFF
}

.pbutton {
	background-color:#44c767;
	-moz-border-radius:28px;
	-webkit-border-radius:28px;
	border-radius:2px;
	border:1px solid #18ab29;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:15px;
	padding:6px 12px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
	margin: auto;
	margin: auto;
}
.pbutton:hover {
	background-color:#5cbf2a;
}
.pbutton:active {
	position:relative;
	top:1px;
}
nav ul li ul li{
    float: left;
}
</style>
   <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
</head>

<body>
<?php
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");
}
else{header("location: logout.php");}
?>
<br>
<center>
<br><br><br><br>
<div style='width: 100%; color: red; font-size: 16px; text-align: center; font-weight: bold;'>&nbsp;&nbsp;&nbsp;AFFECTIVE AND PSYCHOMOTOR DOMAINS</div>
<div style="margin:0 auto; padding:10px; background-color:#fff; height: auto; width: 100%;">
<?php
if(isset($_POST['btn-upload'])){
        $teacher_id = $_POST['teacher_id'];
		$teacher = $_POST['teacher'];
        $class = $_POST['class'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		$arms = $_POST['arms'];
include ("db.php");
$user = $_SESSION['username'];
$result11 = mysql_query("SELECT * FROM users2 where username='$user' AND school='".$_SESSION["school"]."'");
while ($row11 = mysql_fetch_assoc($result11)) {
	$a[] = $rowt11['teacher_id'];
	$tname[] = $row11['teacher'];
}
$tid =  current($a);
$tna = current($tname);


$resulttnamm = mysqli_query($db, "SELECT formt FROM attend where class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while($rowtnamm = mysqli_fetch_assoc($resulttnamm))
{
$tnamm22[] = $rowtnamm['formt'];
}
$tnamm2 = current($tnamm22);

//echo $tnamm2;
//echo $tna;

if($tnamm2 != ""){
    if($tnamm2==$tna){
 $tna = $tna; 
    }else{
 $tna = $tnamm2;      
    }
}else{
$tna = $tna;
}


$sqll = mysql_query("SELECT * FROM affective where class='$class' AND year='$year' AND term='$term' AND formt='$tna' AND ppfirstname='$arms' AND school='".$_SESSION["school"]."' ORDER BY student_name ASC");
$sqll2 = mysql_query("SELECT * FROM studentsbyclass where class='$class' AND year='$year' AND term='$term' AND formt='$tna' AND arms='$arms' AND school='".$_SESSION["school"]."' ORDER BY student_name ASC");

include("connection.php");
$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
							while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);

if($class=="Year 1"){
	if($ctype=="Js"){
	$cl = "JS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 1";
}else{
	$cl = "Year 1";
}
}
elseif($class=="Year 2"){
	if($ctype=="Js"){
	$cl = "JS2";
}elseif($ctype=="Primary"){
	$cl = "Primary 2";
}else{
	$cl = "Year 2";
}
}
elseif($class=="Year 3"){
	if($ctype=="Js"){
	$cl = "JS3";
}elseif($ctype=="Primary"){
	$cl = "Primary 3";
}else{
	$cl = "Year 3";
}
}
elseif($class=="Year 4"){
	if($ctype=="Js"){
	$cl = "SS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 4";
}else{
	$cl = "Year 4";
}
}
elseif($class=="Year 5"){
	if($ctype=="Js"){
	$cl = "SS2";
}elseif($ctype=="Primary"){
	$cl = "Primary 5";
}else{
	$cl = "Year 5";
}
}
elseif($class=="Year 6"){
	if($ctype=="Js"){
	$cl = "SS3";
}elseif($ctype=="Primary"){
	$cl = "Primary 6";
}else{
	$cl = "Year 6";
}
}
elseif($class=="Year 7"){
	if($ctype=="Js"){
	$cl = "JS1";
}else{
	$cl = "Year 7";
}
}
else if($class=="Year 8"){
	if($ctype=="Js"){
	$cl = "JS2";
}else{
	$cl = "Year 8";
}
}else if($class=="Year 9"){
	if($ctype=="Js"){
	$cl = "JS3";
}else{
	$cl = "Year 9";
}
}else if($class=="Year 10"){
	if($ctype=="Js"){
	$cl = "SS1";
}else{
	$cl = "Year 10";
}
}else if($class=="Year 11"){
	if($ctype=="Js"){
	$cl = "SS2";
}else{
	$cl = "Year 11";
}
}else if($class=="Year 12"){
	if($ctype=="Js"){
	$cl = "SS3";
}else{
	$cl = "Year 12";
}
}else{
	$cl = "NOT APPLICABLE";
}

echo "<span id='imgroller'></span><input style='display: none;' type='text' id='ff' /><input style='display: none;' type='text' id='ll' /><input style='display: none;' type='text' id='mm' /><input style='display: none;' type='text' id='nn' /><input style='display: none;' type='text' id='oo' /><input style='display: none;' type='text' id='pp' />";
echo "<br><div style='width: 100%; color: red; font-size: 16px;'>Data on ".$cl." students, ".$term." of ".$year."/".($year+1)." Session</div>";		
?>
<br>
<?php 
if((mysql_num_rows($sqll)>0) AND (mysql_num_rows($sqll2)<1)){
?>
<span>It is ranked on a scale of 1 - 5. One is the lowest obtainable and Five is the maximum.</span>
<table style="width: 70%;">
<tr class="head">
<th>Student's Name</th><th>Honesty</th><th>Attentiveness</th><th>Cooperation</th><th>Handwriting</th><th>Painting</th><th>Athletics</th>
</tr>
<?php		
$i=1;
while($row=mysql_fetch_array($sqll))
{
$id=$row['id'];
$firstname=$row['firstname'];
$lastname=$row['lastname'];
$midname=$row['midname'];
$pfirstname=$row['pfirstname'];
$plastname=$row['plastname'];
$pmidname=$row['pmidname'];
$stuname=$row['student_name'];
if($i%2)
{
?>
<tr id="<?php echo $id; ?>" class="edit_tr">
<?php } else { ?>
<tr id="<?php echo $id; ?>" bgcolor="#f2f2f2" class="edit_tr">
<?php } ?>
<td width="10%" class="edit_td">
<span id="stu_<?php echo $id; ?>" class="text"><?php echo $stuname; ?></span>
<input type="text" value="<?php echo $stuname; ?>" class="editbox" id="stu_input_<?php echo $id; ?>" />
</td>
<td width="10%" class="edit_td">
<span id="first_<?php echo $id; ?>" class="text"><?php echo $firstname; ?></span>
<input type="text" value="<?php echo $firstname; ?>" class="editbox" id="first_input_<?php echo $id; ?>" />
</td>
<td width="10%" class="edit_td">
<span id="last_<?php echo $id; ?>" class="text"><?php echo $lastname; ?></span> 
<input type="text" value="<?php echo $lastname; ?>"  class="editbox" id="last_input_<?php echo $id; ?>"/>
</td>
<td width="10%" class="edit_td">
<span id="mid_<?php echo $id; ?>" class="text"><?php echo $midname; ?></span> 
<input type="text" value="<?php echo $midname; ?>"  class="editbox" id="mid_input_<?php echo $id; ?>"/>
</td>
<td width="10%" class="edit_td">
<span id="pfirst_<?php echo $id; ?>" class="text"><?php echo $pfirstname; ?></span> 
<input type="text" value="<?php echo $pfirstname; ?>"  class="editbox" id="pfirst_input_<?php echo $id; ?>"/>
</td>
<td width="10%" class="edit_td">
<span id="plast_<?php echo $id; ?>" class="text"><?php echo $plastname; ?></span> 
<input type="text" value="<?php echo $plastname; ?>"  class="editbox" id="plast_input_<?php echo $id; ?>"/>
</td>
<td width="10%" class="edit_td">
<span id="pmid_<?php echo $id; ?>" class="text"><?php echo $pmidname; ?></span> 
<input type="text" value="<?php echo $pmidname; ?>"  class="editbox" id="pmid_input_<?php echo $id; ?>"/>
</td>
</tr>

<?php
$i++;
}
?>
</table>
<?php
} //end of if sqll for updating

else if((mysql_num_rows($sqll)>0) AND (mysql_num_rows($sqll2)>0)){ //beginning of inserting
$result = mysql_query("SELECT * FROM studentsbyclass where class='$class' AND year='$year' AND term='$term' AND formt='$tna' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$result2 = mysql_query("SELECT * FROM affective WHERE class='$class' AND year='$year' AND term='$term' AND formt='$tna' AND ppfirstname='$arms' AND school='".$_SESSION["school"]."'");
while($row2 = mysql_fetch_assoc($result2))
{  						
$student_name2[] = $row2['student_name'];
}
$student_namearr =($student_name2);
$countaff = count($student_namearr);
	
while($row = mysql_fetch_assoc($result))
{  						
$values[] = $row['student_name']; 
$valuesclass[] = $row['class']; 
$valuesyear[] = $row['year']; 
$valuesterm[] = $row['term']; 
$valuesarm[] = $row['arms']; 
}
$vallue = $values;
$countstubyclass = count($vallue);

current($valuesclass);
current($valuesyear);
current($valuesterm);
current($valuesarm);

if($countaff==0){
$student_namearr[] = "nothingham";
}
$r = array_diff($vallue, $student_namearr); 
$v = $countstubyclass - $countaff;	

	
	
if($countaff == 0){
	echo '<br>';
echo '<form action="rate_exec.php" method="post">';
echo '<table style="text-align: center; width: 66%;"><thead style="text-align: center;">';
echo '<tr style="text-align: center;">';
echo '<th style="text-align: center; width: 8%;">Student</th>';
echo '<th style="text-align: center; width: 3%;">Honesty</th>';
echo '<th style="text-align: center; width: 3%;">Attentiveness</th>';
echo '<th style="text-align: center; width: 3%;">Cooperation</th>';
echo '<th style="text-align: center; width: 3%;">Handwriting</th>';
echo '<th style="text-align: center; width: 3%;">Painting</th>';
echo '<th style="text-align: center; width: 3%;">Athletics</th>';
echo '<th style="text-align: center; width: 8%; display: none;">Tutor</th>';
echo '<th style="text-align: center; width: 8%; display: none;">Class</th>';
echo '<th style="text-align: center; width: 8%; display: none;">Year</th>';
echo '<th style="text-align: center; width: 8%; display: none;">Term</th>';
echo '<th style="text-align: center; width: 8%; display: none;">Arm</th>';
echo '</tr></thead>';
foreach ($r as $key => $r['student_name']) {
echo '<tr style="border: 1px solid black;">';
echo '<td style="text-align: center; width: 8%;" class="suname"><input class="tdinput" style="display: none;" type="hidden" name="student_name[]" value="'.$r['student_name'].'" />'.$r['student_name'].'</td>';
echo '<td style="text-align: center; width: 3%;"><input class="tdinput" type="text"  name="firstname[]" id="firstname" />';
echo '<td style="text-align: center; width: 3%;"><input class="tdinput" type="text"  name="lastname[]" id="lastname" />';
echo '<td style="text-align: center; width: 3%;"><input class="tdinput" type="text"  name="midname[]" id="midname" />';
echo '<td style="text-align: center; width: 3%;"><input class="tdinput" type="text"  name="pfirstname[]" id="pfirstname" />';
echo '<td style="text-align: center; width: 3%;"><input class="tdinput" type="text"  name="plastname[]" id="plastname" />';
echo '<td style="text-align: center; width: 3%;"><input class="tdinput" type="text"  name="pmidname[]" id="pmidname" />';
echo '<td style="text-align: center; width: 8%; display: none;"><input class="tdinput" type="text"  name="formt[]" id="formt" value="'.$tna.'" />';
echo '<td style="text-align: center; width: 8%; display: none;"><input class="tdinput" type="text"  name="class[]" id="class" value="'.current($valuesclass).'" /></td>';
echo '<td style="text-align: center; width: 8%; display: none;"><input class="tdinput" type="text"  name="year[]" id="year" value="'.current($valuesyear).'" /></td>';
echo '<td style="text-align: center; width: 8%; display: none;"><input class="tdinput" type="text"  name="term[]" id="term" value="'.current($valuesterm).'" /></td>';
echo '<td style="text-align: center; width: 8%; display: none;"><input class="tdinput" type="text"  name="arm[]" id="arm" value="'.current($valuesarm).'" /></td>';
echo '</tr>';
}
echo '<tr>';
echo '<td colspan="12"><input  style="background-color: green; color: white; float:left;" type="submit" class="submit_button" name="submit" value="Submit Performance Ratings" /></td>';
echo '</tr>';
echo '</table>';
echo '</form>';	
}	
	


else if($v > 0){
	echo '<br>';
echo '<form action="rate_exec.php" method="post">';
echo '<table style="text-align: center; width: 66%;"><thead style="text-align: center;">';
echo '<tr style="text-align: center;">';
echo '<th style="text-align: center; width: 8%;">Student</th>';
echo '<th style="text-align: center; width: 3%;">Honesty</th>';
echo '<th style="text-align: center; width: 3%;">Attentiveness</th>';
echo '<th style="text-align: center; width: 3%;">Cooperation</th>';
echo '<th style="text-align: center; width: 3%;">Handwriting</th>';
echo '<th style="text-align: center; width: 3%;">Painting</th>';
echo '<th style="text-align: center; width: 3%;">Athletics</th>';
echo '<th style="text-align: center; width: 8%; display: none;">Tutor</th>';
echo '<th style="text-align: center; width: 8%; display: none;">Class</th>';
echo '<th style="text-align: center; width: 8%; display: none;">Year</th>';
echo '<th style="text-align: center; width: 8%; display: none;">Term</th>';
echo '<th style="text-align: center; width: 8%; display: none;">Arm</th>';
echo '</tr></thead>';
foreach ($r as $key => $r['student_name']) {
echo '<tr style="border: 1px solid black;">';
echo '<td style="text-align: center; width: 8%;" class="suname"><input class="tdinput" style="display: none;" type="hidden" name="student_name[]" value="'.$r['student_name'].'" />'.$r['student_name'].'</td>';
echo '<td style="text-align: center; width: 3%;"><input class="tdinput" type="text"  name="firstname[]" id="firstname" />';
echo '<td style="text-align: center; width: 3%;"><input class="tdinput" type="text"  name="lastname[]" id="lastname" />';
echo '<td style="text-align: center; width: 3%;"><input class="tdinput" type="text"  name="midname[]" id="midname" />';
echo '<td style="text-align: center; width: 3%;"><input class="tdinput" type="text"  name="pfirstname[]" id="pfirstname" />';
echo '<td style="text-align: center; width: 3%;"><input class="tdinput" type="text"  name="plastname[]" id="plastname" />';
echo '<td style="text-align: center; width: 3%;"><input class="tdinput" type="text"  name="pmidname[]" id="pmidname" />';
echo '<td style="text-align: center; width: 8%; display: none;"><input class="tdinput" type="text"  name="formt[]" id="formt" value="'.$tna.'" />';
echo '<td style="text-align: center; width: 8%; display: none;"><input class="tdinput" type="text"  name="class[]" id="class" value="'.current($valuesclass).'" /></td>';
echo '<td style="text-align: center; width: 8%; display: none;"><input class="tdinput" type="text"  name="year[]" id="year" value="'.current($valuesyear).'" /></td>';
echo '<td style="text-align: center; width: 8%; display: none;"><input class="tdinput" type="text"  name="term[]" id="term" value="'.current($valuesterm).'" /></td>';
echo '<td style="text-align: center; width: 8%; display: none;"><input class="tdinput" type="text"  name="arm[]" id="arm" value="'.current($valuesarm).'" /></td>';
echo '</tr>';
}
echo '<tr>';
echo '<td colspan="12"><input  style="background-color: green; color: white; float:left;" type="submit" class="submit_button" name="submit" value="Submit Performance Ratings" /></td>';
echo '</tr>';
echo '</table>';
echo '</form>';	
}
	
else{	
?>	
<span>It is ranked on a scale of 1 - 5. One is the lowest obtainable and Five is the maximum.</span>
<table style="width: 70%;">
<tr class="head">
<th>Student's Name</th><th>Honesty</th><th>Attentiveness</th><th>Cooperation</th><th>Handwriting</th><th>Painting</th><th>Athletics</th>
</tr>
<?php		
$i=1;
while($row=mysql_fetch_array($sqll))
{
$id=$row['id'];
$firstname=$row['firstname'];
$lastname=$row['lastname'];
$midname=$row['midname'];
$pfirstname=$row['pfirstname'];
$plastname=$row['plastname'];
$pmidname=$row['pmidname'];
$stuname=$row['student_name'];
if($i%2)
{
?>
<tr id="<?php echo $id; ?>" class="edit_tr">
<?php } else { ?>
<tr id="<?php echo $id; ?>" bgcolor="#f2f2f2" class="edit_tr">
<?php } ?>
<td width="10%" class="edit_td">
<span id="stu_<?php echo $id; ?>" class="text"><?php echo $stuname; ?></span>
<input type="text" value="<?php echo $stuname; ?>" class="editbox" id="stu_input_<?php echo $id; ?>" />
</td>
<td width="10%" class="edit_td">
<span id="first_<?php echo $id; ?>" class="text"><?php echo $firstname; ?></span>
<input type="text" value="<?php echo $firstname; ?>" class="editbox" id="first_input_<?php echo $id; ?>" />
</td>
<td width="10%" class="edit_td">
<span id="last_<?php echo $id; ?>" class="text"><?php echo $lastname; ?></span> 
<input type="text" value="<?php echo $lastname; ?>"  class="editbox" id="last_input_<?php echo $id; ?>"/>
</td>
<td width="10%" class="edit_td">
<span id="mid_<?php echo $id; ?>" class="text"><?php echo $midname; ?></span> 
<input type="text" value="<?php echo $midname; ?>"  class="editbox" id="mid_input_<?php echo $id; ?>"/>
</td>
<td width="10%" class="edit_td">
<span id="pfirst_<?php echo $id; ?>" class="text"><?php echo $pfirstname; ?></span> 
<input type="text" value="<?php echo $pfirstname; ?>"  class="editbox" id="pfirst_input_<?php echo $id; ?>"/>
</td>
<td width="10%" class="edit_td">
<span id="plast_<?php echo $id; ?>" class="text"><?php echo $plastname; ?></span> 
<input type="text" value="<?php echo $plastname; ?>"  class="editbox" id="plast_input_<?php echo $id; ?>"/>
</td>
<td width="10%" class="edit_td">
<span id="pmid_<?php echo $id; ?>" class="text"><?php echo $pmidname; ?></span> 
<input type="text" value="<?php echo $pmidname; ?>"  class="editbox" id="pmid_input_<?php echo $id; ?>"/>
</td>
</tr>

<?php
$i++;
}
?>
</table>	
<?php	
	
} // end of ELSE if for UPDATING when all insertions fail


	
} // end of ELSE if for inserting and NOT UPDATING
else{


$result = mysql_query("SELECT * FROM studentsbyclass where class='$class' AND year='$year' AND term='$term' AND formt='$tna' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$result2 = mysql_query("SELECT * FROM affective WHERE class='$class' AND year='$year' AND term='$term' AND formt='$tna' AND ppfirstname='$arms' AND school='".$_SESSION["school"]."'");
while($row2 = mysql_fetch_assoc($result2))
{  						
$student_name2[] = $row2['student_name'];
}
$student_namearr =($student_name2);
$countaff = count($student_namearr);
	
while($row = mysql_fetch_assoc($result))
{  						
$values[] = $row['student_name']; 
$valuesclass[] = $row['class']; 
$valuesyear[] = $row['year']; 
$valuesterm[] = $row['term']; 
$valuesarm[] = $row['arms']; 
}
$vallue = $values;
$countstubyclass = count($vallue);

current($valuesclass);
current($valuesyear);
current($valuesterm);
current($valuesarm);

if($countaff==0){
$student_namearr[] = "nothingham";
}
$r = array_diff($vallue, $student_namearr); 
$v = $countstubyclass - $countaff;


echo '<form action="rate_exec.php" method="post">';
echo '<table style="text-align: center; width: 66%;"><thead style="text-align: center;">';
echo '<tr style="text-align: center;">';
echo '<th style="text-align: center; width: 8%;">Student</th>';
echo '<th style="text-align: center; width: 3%;">Honesty</th>';
echo '<th style="text-align: center; width: 3%;">Attentiveness</th>';
echo '<th style="text-align: center; width: 3%;">Cooperation</th>';
echo '<th style="text-align: center; width: 3%;">Handwriting</th>';
echo '<th style="text-align: center; width: 3%;">Painting</th>';
echo '<th style="text-align: center; width: 3%;">Athletics</th>';
echo '<th style="text-align: center; width: 8%; display: none;">Tutor</th>';
echo '<th style="text-align: center; width: 8%; display: none;">Class</th>';
echo '<th style="text-align: center; width: 8%; display: none;">Year</th>';
echo '<th style="text-align: center; width: 8%; display: none;">Term</th>';
echo '<th style="text-align: center; width: 8%; display: none;">Arm</th>';
echo '</tr></thead>';
foreach ($r as $key => $r['student_name']) {
echo '<tr style="border: 1px solid black;">';
echo '<td style="text-align: center; width: 8%;" class="suname"><input class="tdinput" style="display: none;" type="hidden" name="student_name[]" value="'.$r['student_name'].'" />'.$r['student_name'].'</td>';
echo '<td style="text-align: center; width: 3%;"><input class="tdinput" type="text"  name="firstname[]" id="firstname" />';
echo '<td style="text-align: center; width: 3%;"><input class="tdinput" type="text"  name="lastname[]" id="lastname" />';
echo '<td style="text-align: center; width: 3%;"><input class="tdinput" type="text"  name="midname[]" id="midname" />';
echo '<td style="text-align: center; width: 3%;"><input class="tdinput" type="text"  name="pfirstname[]" id="pfirstname" />';
echo '<td style="text-align: center; width: 3%;"><input class="tdinput" type="text"  name="plastname[]" id="plastname" />';
echo '<td style="text-align: center; width: 3%;"><input class="tdinput" type="text"  name="pmidname[]" id="pmidname" />';
echo '<td style="text-align: center; width: 8%; display: none;"><input class="tdinput" type="text"  name="formt[]" id="formt" value="'.$tna.'" />';
echo '<td style="text-align: center; width: 8%; display: none;"><input class="tdinput" type="text"  name="class[]" id="class" value="'.current($valuesclass).'" /></td>';
echo '<td style="text-align: center; width: 8%; display: none;"><input class="tdinput" type="text"  name="year[]" id="year" value="'.current($valuesyear).'" /></td>';
echo '<td style="text-align: center; width: 8%; display: none;"><input class="tdinput" type="text"  name="term[]" id="term" value="'.current($valuesterm).'" /></td>';
echo '<td style="text-align: center; width: 8%; display: none;"><input class="tdinput" type="text"  name="arm[]" id="arm" value="'.current($valuesarm).'" /></td>';
echo '</tr>';
}
echo '<tr>';
echo '<td colspan="12"><input  style="background-color: green; color: white; float:left;" type="submit" class="submit_button" name="submit" value="Submit Performance Ratings" /></td>';
echo '</tr>';
echo '</table>';
echo '</form>';		
	
	
	
	
	
	
	
	
	
	
} // end of ELSE if for inserting and NOT UPDATING








} // end of isset
?>

</center>
</div>
<center>
<?php echo "<br><a class='pbutton' href='affective.php'>back</a>"; ?>
</center>
<?php
include("footer.php");
?>
</body>
</html>
