<?php 
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
if(isset($_POST['btn-upload'])){
        $teacher_id = $_POST['teacher_id'];
		$teacher_name = $_POST['teacher_name'];
        $class_id = $_POST['class_id'];
		$year_id = $_POST['year_id'];
		$term_id = $_POST['term_id'];
		$subject_id = $_POST['subject_id'];
        $query = ("INSERT into `teachers` (teacher_id, teacher_name, class_id, year_id, term_id, subject_id) VALUES ('$teacher_id', '$teacher_name', '$class_id', '$year_id', '$term_id', '$subject_id')");
        $result = mysqli_query($db,$query);
        if($result){
            echo "<div class='form'><h3>Data was inserted successfully.</h3></div>";
			echo '<meta content="2;index2.php" http-equiv="refresh" />';
        }
    }
	
	$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Index</title>
<link rel="stylesheet" href="style.css" type="text/css" />
<link rel="stylesheet" href="css/style.css" />
	<script src="table/js/jquery.js" type="text/javascript"></script>
	<script src="datatablejs.js" type="text/javascript"></script>
	<link rel="stylesheet" type="text/css" href="datatablecss.css">
	 <link rel="stylesheet" type="text/css" href="datatablebuttoncss.css">
	 <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
<style>
[type=file]::-webkit-file-upload-button{
    color: white;
    border: 1px solid green;
    border-radius: 5px;
    background: green;
}
a:hover{
	color: orange;
}
nav ul li ul li{
    float: left;
    z-index: 1000;
}
</style>
<script>
$(document).ready(function() {
$("#takest").html("Show Grade System Request Form");
$("#gradebands").hide();
 $("#takest").click(function( event ) {
		event.preventDefault();
		var hi = $("#takest").html();
		if(hi == "Show Grade System Request Form"){	
		$("#takest").html("Hide Grade System Request Form");
		$("#gradebands").show();
		}
		else if(hi == "Hide Grade System Request Form"){	
		$("#takest").html("Show Grade System Request Form");
		$("#gradebands").hide();
		}
	 });	
	
$("#csy").submit(function(evts) {
	evts.preventDefault();
$.ajax({
type: "POST",
url: "classsystem.php",
data: $("#csy").serialize(),	
success: function(responsecl){
 if(responsecl==1) { 
		$(".success").fadeIn();
		setTimeout(function() { $(".success").fadeOut(); }, 3000); 
    } else {
		 $(".error").show();
		setTimeout(function() { $(".error").fadeOut(); }, 3000);
		}
}	
});	
});

$(".thesband").attr("readonly", "readonly");
$("#grange, #srange").on("change", function(){
if($("#grange").is(":checked")){
	$("#submitgrades").prop("name","submitgrades");
	$("#submitgrades").val("Set Grade Bands");
	$(".thesband").attr("readonly", "readonly");
	$(".thegband").removeAttr('readonly');
}else{
	$("#submitgrades").prop("name","submitsrange");
	$("#submitgrades").val("Set Scores Range");
	$(".thegband").attr("readonly", "readonly");
	$(".thesband").removeAttr('readonly');
}
});

$(document).on("submit", "#gradebands", function(evtss) {
	evtss.preventDefault();
var thegbandarr = [];
var gb = [];
$(".thegband").each(function() {
  thegbandarr.push($(this).val());
});
  for (var i=0;i<=(thegbandarr.length-1);i++) {
	  var flag = 0;
	 for(var j=0;j<=i;j++) {
	if(thegbandarr[i]==thegbandarr[j]){
	  flag++;
		}
	 } //end of inner for
      gb.push(flag);
  } //end of outer for
  
if(jQuery.inArray(2, gb) != -1) {
    alert("No two grades must be the same!");
	return false;
} else {
   $.ajax({
type: "POST",
url: "gradebands.php",
data: $("#gradebands").serialize(),	
beforeSend: function(){
	$("#gradebands").after("<label id='forremoval' style='color: red;' >Sending...Please wait!</label>");
	$('#submitgrades').attr( 'onClick', 'return false' );
	},
success: function(responsegr){
		//alert(responsegr);
if(responsegr==1) { 
		$(".successgr").fadeIn();
		setTimeout(function() { $(".successgr").fadeOut(); }, 4000); 
		} else if(responsegr==2) { 
		$(".successgr2").fadeIn();
		setTimeout(function() { $(".successgr2").fadeOut(); }, 4000); 
		} else {
		 $(".errorgr").show();
		setTimeout(function() { $(".errorgr").fadeOut(); }, 4000);
}	
},
complete: function(){
	$("#forremoval").remove();
	$('#submitgrades').removeAttr('onClick');
	 $('#divref').load("index2.php #refreshgband");
	}
});	
} 	
});
});
</script>

<script>
$(document).ready(function() {	
$("#yearsig").on("change", function(){
	var yrvalue = $("#yearsig option:selected").val();
	var princiid = $("#sigsystem").find("#princiid2").val();
	var priname = $("#priname2").val();
	dataString = 'year='+yrvalue+'&teacher_id='+princiid+'&teacher_name='+priname;
$.ajax({
type: "POST",
url: "classsystem2.php",
data: dataString,	
success: function(response){	
$("#sigstatus").html("CURRENT STATUS FOR YEAR "+yrvalue+" IS:"+response);
setTimeout(function() { $("#sigstatus").html(""); }, 2000);
}
});
});
});
</script>
<script>
$(document).ready(function() {	
$("#sigsystem").on("submit", function(aa){
	aa.preventDefault();
	var yrvalue = $("#yearsig option:selected").val();
	var princiid = $("#sigsystem").find("#princiid2").val();
	var priname = $("#priname2").val();
	var sig = $("#sig").val();
	dataString = 'year='+yrvalue+'&teacher_id='+princiid+'&teacher_name='+priname+'&sig='+sig;
$.ajax({
type: "POST",
url: "classsystem3.php",
data: dataString,	
success: function(response){	
if(response==1) { 
		$(".success2").fadeIn();
		setTimeout(function() { $(".success2").fadeOut(); }, 3000); 
    } else {
		 $(".error2").show();
		setTimeout(function() { $(".error2").fadeOut(); }, 3000);
		}
}
});
});
});
</script>
<script>
$(document).ready(function() {	
$("#princisystem").submit(function( evt ) {
			evt.preventDefault();	
var yr = $('#year').val();
$.ajax({
type: "POST",
url: "princisystem.php",
data:  new FormData(this),
contentType: false,
cache: false,
processData:false,	
success: function(response){
 if(response==1) { 
	$('#showtheyear').html(yr);
		$(".success").fadeIn();
		setTimeout(function() { $(".success").fadeOut(); }, 3000); 
		$('#removepic').val("");
    } else {
		$('#showtheyear2').html(yr);
		 $(".error").show();
		setTimeout(function() { $(".error").fadeOut(); }, 3000);
		$('#removepic').val("");
		}
//alert(response);
}
});	
});
});
</script>

 <style>
.containers:after { /*clear float*/
    content: "";
    display: table;
    clear: both;
}
.containers > div {
    float: left;
    width: 33.33%;
    box-sizing: border-box;
    text-align: center;
}
@media (max-width: 480px) { /*breakpoint*/
    .containers > div {
        float: none;
        width: 100%;
    }
}
 </style>

<script>
	$(document).ready(function() {
    $('#example').DataTable();
	});
	</script>
	 <script>
$(document).ready(function(){
 var gggg = $("[data-j=cnnn] option").length;	
if(gggg==8){
$("[data-j=cnnn] option").eq(7).css("display","none");
}
 $("#studsub").on("click",function(){
var bb = $("[data-j=cnnn]").find(":selected").text();
var b = null;
if(bb=="Primary 1"){
	b = "Year 1";
}
else if(bb=="Primary 2"){
	b = "Year 2";
}
else if(bb=="Primary 3"){
	b = "Year 3";
}
else if(bb=="Primary 4"){
	b = "Year 4";
}
else if(bb=="Primary 5"){
	b = "Year 5";
}
else if(bb=="Primary 6"){
	b = "Year 6";
}
else if(bb=="JS1"){
	b = "Year 7";
}
else if(bb=="JS2"){
	b = "Year 8";
}
else if(bb=="JS3"){
	b = "Year 9";
}
else if(bb=="SS1"){
	b = "Year 10";
}
else if(bb=="SS2"){
	b = "Year 11";
}
else if(bb=="SS3"){
	b = "Year 12";
}
else{
	b = bb;
}
$("[data-j=cnnn]").find(":selected").val(b);
var c = $("[data-j=cnnn]").find(":selected").val();
 });

  var gggg = $("[data-j=cnnnn] option").length;	
if(gggg==8){
$("[data-j=cnnnn] option").eq(7).css("display","none");
}	
 
 $("#studsub2").on("click",function(){ 
var bb = $("[data-j=cnnnn]").find(":selected").text();
var b = null;
if(bb=="Primary 1"){
	b = "Year 1";
}
else if(bb=="Primary 2"){
	b = "Year 2";
}
else if(bb=="Primary 3"){
	b = "Year 3";
}
else if(bb=="Primary 4"){
	b = "Year 4";
}
else if(bb=="Primary 5"){
	b = "Year 5";
}
else if(bb=="Primary 6"){
	b = "Year 6";
}
else if(bb=="JS1"){
	b = "Year 7";
}
else if(bb=="JS2"){
	b = "Year 8";
}
else if(bb=="JS3"){
	b = "Year 9";
}
else if(bb=="SS1"){
	b = "Year 10";
}
else if(bb=="SS2"){
	b = "Year 11";
}
else if(bb=="SS3"){
	b = "Year 12";
}
else{
	b = bb;
}
$("[data-j=cnnnn]").find(":selected").val(b);
var c = $("[data-j=cnnnn]").find(":selected").val();
if(c=="Year 1" || c=="Year 2" || c=="Year 3" || c=="Year 4" || c=="Year 5" || c=="Year 6"){
	$("#transcriptform").prop("action","transtea2.php");
}
//alert(c);
//alert(bb);
 });
});
</script>
              <script type="text/javascript">
         $(document).ready(function () {
             	$(document).on("click", "#imghref", function(evm){
		evm.preventDefault();
	$("#imgform").fadeIn(3000);	
	});
 $("#userimgform").submit(function(ev){
	ev.preventDefault();
	var dataSt = new FormData(this);
        $.ajax({
            type:'POST',
            url:'userimg.php',
            data: dataSt,
			cache: false,
			contentType: false,
			processData: false,
            success:function(response){
          $('#userimgsub').removeAttr("disabled");
		  $("#imgform").fadeOut(3000);
		$('#photo').replaceWith('<img id="photo" src="'+response+'" width="60" height="60" />'); 
            }
			});
			});					

         });
	</script>
	  <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>

	</head>
<body>


<?php
$resultrole2 = mysqli_query($db, "SELECT role, adminlevel, teacher_id, img FROM users2 where username='".$_SESSION['username']."' AND school='".$_SESSION['school']."'");
while($rowrole2 = mysqli_fetch_assoc($resultrole2))
{
	$arole[] = $rowrole2['role'];
	$adminlevel2[] = $rowrole2['adminlevel'];
	$aid2[] = $rowrole2['teacher_id'];
	$img2[] = $rowrole2['img'];
}
$imgg = current($img2);
$_SESSION['role'] =  current($arole);
$aid =  current($aid2);
$_SESSION['adminlevel'] =  current($adminlevel2);

echo '<div id="headerit">';
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");
}
elseif($_SESSION['role'] == 'student'){
include("headerstudent.php");
}
else{header("location: logout.php");}
echo '</div>';

?>
<?php
if($_POST['school']==""){
	$_SESSION['school'] = $_SESSION['school'];
}else{
$_SESSION['school'] = $_POST['school'];
}
echo '<br>';
?>
				<center>
					<?php
echo '<div class="ssuccesss" style="display: none; color: green;" >Your photo was successfully updated.</div>';	
echo '<div class="eerrors" style="display: none; color: red;" >Your photo could NOT be updated.</div>';
					?>
					<div style="display: none; margin-left: auto; margin-right: auto; width: 100%; padding: auto;" id="imgform" >
					<form role="forms" id="userimgform">
					 <div class="form-group" style="display: none;">
                        <label for="inputID">ID</label>
                        <input type="text" class="form-control" id="id" name="id" value="<?php  echo $aid ?>" />
                    </div>
					<div style="margin-right: auto;" class="form-group">
                     <input type="file" class="form-control" id="image" name="userImage" />
					  <input type="text" style="display: none;" class="form-control" id="image2" name="image2" value="<?php echo $imgg; ?>" />
                    </div>
					<div class="form-group" style="margin-right: auto; margin-left: -12%;">
					<input type="submit" class="btn btn-primary submitBtn" id="userimgsub" value="Submit" />
					</div>
				</form>
				</div>
				</center>
<?php
if($_SESSION['role'] == 'teacher'){
$user=$_SESSION['username'];
$result2 = mysqli_query($db, "SELECT * FROM users2 where username='$user' AND school='".$_SESSION['school']."'");
while($row2 = mysqli_fetch_assoc($result2))
{
	$a = $row2['teacher_id'];
	$pna2[] = $row2['teacher'];
}
$s =  $a;
$pna = current($pna2);
echo '<br><br><br><br>';
echo '<table id="example" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">';
echo '<thead><tr style="text-align:left;">';
echo '<th style="text-align: center; color: red;"><br>Enrol Students</th>';
echo '</thead></tr>';
$result = mysqli_query($db, "SELECT * FROM teachers where teacher_id='$s' AND school='".$_SESSION['school']."'");
while($row = mysqli_fetch_assoc($result)){
if($row['class_id']==1)
{ 
$class_name= 'Year 7';
}
elseif($row['class_id']==2)
{ 
$class_name= 'Year 8';
}
elseif($row['class_id']==3)
{ 
$class_name= 'Year 9';
}
elseif($row['class_id']==4)
{ 
$class_name= 'Year 10';
}
elseif($row['class_id']==5)
{ 
$class_name= 'Year 11';
}
elseif($row['class_id']==6)
{ 
$class_name= 'Year 12';
}
elseif($row['class_id']==7)
{ 
$class_name= 'Year 1';
}
elseif($row['class_id']==8)
{ 
$class_name= 'Year 2';
}
elseif($row['class_id']==9)
{ 
$class_name= 'Year 3';
}
elseif($row['class_id']==10)
{ 
$class_name= 'Year 4';
}
elseif($row['class_id']==11)
{ 
$class_name= 'Year 5';
}
elseif($row['class_id']==12)
{ 
$class_name= 'Year 6';
}
else{
	
}

if($row['term_id']==1)
{ 
$term= 'First Term';
}
elseif($row['term_id']==2)
{ 
$term= 'Second Term';
}
elseif($row['term_id']==3)
{ 
$term= 'Third Term';
}
else{
	
}
if($row['year_id']==1){
	$year = '2012';
}
elseif($row['year_id']==2){
	$year = '2013';
}
if($row['year_id']==3){
	$year = '2014';
}
if($row['year_id']==4){
	$year = '2015';
}
if($row['year_id']==5){
	$year = '2016';
}
if($row['year_id']==6){
	$year = '2017';
}
if($row['year_id']==7){
	$year = '2018';
}
if($row['year_id']==8){
	$year = '2019';
}
if($row['year_id']==9){
	$year = '2020';
}
if($row['year_id']==10){
	$year = '2021';
}
if($row['year_id']==11){
	$year = '2022';
}
if($row['year_id']==12){
	$year = '2023';
}
else{
	
}

if($ctype=="Js"){
	if($class_name=="Year 7"){
		$cl = "JS1";
	}
	else if($class_name=="Year 8"){
		$cl = "JS2";
	}
	else if($class_name=="Year 9"){
		$cl = "JS3";
	}
	else if($class_name=="Year 10"){
		$cl = "SS1";
	}
	else if($class_name=="Year 11"){
		$cl = "SS2";
	}
	else if($class_name=="Year 12"){
		$cl = "SS3";
	}
	else{ $cl = "NA"; }
}


elseif($ctype=="Primary"){
	if($class_name=="Year 1"){
		$cl = "Primary 1";
	}
	else if($class_name=="Year 2"){
		$cl = "Primary 2";
	}
	else if($class_name=="Year 3"){
		$cl = "Primary 3";
	}
	else if($class_name=="Year 4"){
		$cl = "Primary 4";
	}
	else if($class_name=="Year 5"){
		$cl = "Primary 5";
	}
	else if($class_name=="Year 6"){
		$cl = "Primary 6";
	}
	else{ $cl = "NA"; }
}
else{ $cl = $row['class_name']; }
//echo '<hr />';
echo '<tr><td><form action="subjstudents.php" method="POST"><input type="hidden" name="teacher_id" value="'.$row['teacher_id'].'" /><input type="hidden" name="class" style="color: red;" value="'.$row['class_name'].'" /><span style="color: red;">'.$cl.'</span>&nbsp;<select style="width: 150px; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 2px; height: auto;" name="arms" id="arms" required >';
	 $resultar = mysqli_query($db,"SELECT * FROM school where school='".$_SESSION["school"]."'");
				while($rowar = mysqli_fetch_assoc($resultar)){
					if(in_array($rowar["arms"], $arrr2)){
						continue;
					}else{
					$arrr2[] = $rowar["arms"];
						}
				}
				$a = implode(',',$arrr2);
				$b = explode(',',$a);
				$f = (array_filter($b));
				
						for($i=0; $i<=(count($f)-1); $i++)
							{  
								echo '<option value="'.$f[$i].'">';
								echo $f[$i];
								echo '</option>';
							}
    echo '</select><br><input type="hidden" name="year" value="'.$year.'" />'.$year.'<br><input type="hidden" name="term" value="'.$term.'" />'.$term.'<br><input type="hidden" name="subject" value="'.$row['subject'].'" />'.$row['subject'].'<br><input type="submit" name="btn-upload" value="students NOT enrolled" /><br><br><br></form></td></tr>';
}

echo '</table>';
?>

<?php
echo '<br><br>';
}
else if($_SESSION['role'] == 'student'){
echo '<div class="form">';
echo '<br><br><br><br>';
echo '<h5 style="color: red;">GET YOUR SCORES</h5>';
echo '<form name="registration" action="getresult.php" method="post">';
	$resultst = mysqli_query($db, "SELECT * FROM users2 WHERE username='".$_SESSION['username']."'");
						while($rowst = mysqli_fetch_assoc($resultst))
							{ $uses[] = $rowst['teacher']; }
						$uses2 = current($uses);
						echo '<input type="hidden" name="student_name" value="'.$uses2.'" required />';
	echo '<select data-j="cnnn" style="width: 210px; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; height: auto; font-size: 14px; margin-top: 10px;" name="class_name" id="class_name" required >';
$cccc = 0;
$cccc2 = 0;	
	$result = mysqli_query($db, "SELECT * FROM classes");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option>';
								if($ctype=="Js"){
								if($cccc == 0){	
									$cccc++;
									echo 'SELECT A CLASS';
									continue;
									}		
								if($cccc <= 3){
								echo 'JS'.$cccc;	
								}
								elseif($cccc >= 4 && $cccc <= 6){
									if($cccc == 4){	
									$cccc++;
									echo 'SS'.($cccc2 - 2);	
									continue;
									}
									if($cccc == 5){	
									$cccc++;
									echo 'SS'.($cccc2 - 1);	
									continue;
									}
									if($cccc == 6){	
									$cccc++;
									echo 'SS'.($cccc2 - 0);	
									continue;
									}
								}else{
									break;
								}
								$cccc++;	
								$cccc2++;
									}
								else{	
								if($ctype=="Primary"){
									if($cccc == 0){	
									$cccc++;
									echo 'SELECT A CLASS';
									continue;
									}
								echo 'Primary '.$cccc;
								if($cccc > 5){
									break;
								}
								$cccc++;	
								}
								else{
								echo 'Year '.$cccc;
								if($cccc > 11){
									break;
								}
								$cccc++;	
								}
								}//end of else
								echo '</option>';
							}
    echo '</select>';
	echo '<select style="width: 210px; border-radius: 2px; border: 1px solid #CCC; height: auto; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="year" id="year" required >';
	echo '<option value="none" disabled="disabled" selected>SESSION COMMENCING</option>';
	$result = mysqli_query($db, "SELECT * FROM years");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['year'].'">';
								echo $row['year'];
								echo '</option>';
							}
    echo '</select>';
	echo '<select style="width: 210px; border-radius: 2px; border: 1px solid #CCC; padding: 10px; height: auto; color: #333; font-size: 14px; margin-top: 10px;" name="term" id="term" required >';
	
	$resulttm = mysqli_query($db, "SELECT * FROM terms");
						while($row = mysqli_fetch_assoc($resulttm))
							{  
								echo '<option value="'.$row['term'].'">';
								echo $row['term'];
								echo '</option>';
							}
    echo '</select>';
echo '<input type="submit" name="submit3" id="studsub" value="Get Result" />';
echo '</form>';
echo '</div>';
echo '<br><br><br><br><br>';

}
else if($_SESSION['role'] == 'admin'){
echo "<br><br><br>";    
echo '<div class="containers">';
echo '<div id="div1">';	
echo '<div class="success" style="display: none; color: green;" >Class Naming System is set.</div>';	
echo '<div class="error" style="display: none; color: red;" >Error in setting class naming system!</div>';
echo '</center>';
echo '<div class="form">';
echo '<h5>SET CLASS NAMING SYSTEM</h5>';
echo '<form id="csy" >';
echo '<select style="width: 210px; border-radius: 2px; height: auto; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="classtype" id="classtype" required >';
$resultct = mysqli_query($db, "SELECT classtype FROM classtype ORDER BY classtype ASC");
						while($rowct = mysqli_fetch_assoc($resultct))
							{  
						if($rowct['classtype']=="Js"){ $ct = "JS1 - SS3";}elseif($rowct['classtype']=="Primary"){$ct = "Primary 1 - Primary 6";}else{$ct = "Year 1 - Year 12";}
								echo '<option value="'.$rowct['classtype'].'">';
								echo $ct;
								echo '</option>';
							}
echo '</select><br>';
echo '<input type="submit" value="set it" />';
echo '</form>';	
echo '</div>';

echo '<br>';
echo '<div class="form">';
echo '<h5>CHECK IF SUBJECT TEACHER IS REGISTERED</h5>';
echo '<form name="registration" action="enrolteach.php" method="post">';
echo '<input type="text" name="teacher" placeholder="Teacher Name" required />';
echo '<input type="submit" name="submit1" value="Check" />';
echo '</form>';
echo '</div>';


echo '<br>';
echo '<div id="divref">';
echo '<div id="refreshgband" class="form">';
echo '<h5>SET GRADE BANDS</h5>';
echo '<div class="successgr" style="display: none; color: green;" >Grades are set.</div>';	
echo '<div class="successgr2" style="display: none; color: green;" >Score ranges are set.</div>';	
echo '<div class="errorgr" style="display: none; color: red;" >Error in setting grading system!</div>';
$resultgr = mysqli_query($db,"SELECT DISTINCT(grade) FROM gradeband");
while($rowgr = mysqli_fetch_assoc($resultgr)){
					$gr[] = $rowgr["grade"];
				}
for($i=0; $i<=(count($gr)-1); $i++){
$resultsc = mysqli_query($db,"SELECT MIN(score) AS mi, MAX(score) AS ma FROM gradeband WHERE grade='".$gr[$i]."'");
while($rowggr = mysqli_fetch_assoc($resultsc)){
					$gmi2 = $rowggr["mi"];
					$gma2 = $rowggr["ma"];
				}
			$gmi[] = $gmi2;
			$gma[] = $gma2;
	}
	
echo '<a style="color: red; font-weight: bold; font-size: 12px; text-decoration: none;" href="#" id="takest"></a>';
echo '<form name="gradebands" id="gradebands">';
echo '<input type="radio" name="rangeit" id="srange" value="srange" /> Scores Range &nbsp;&nbsp;&nbsp;';
echo '<input type="radio" name="rangeit" value="grange" id="grange" checked /> Set Grades<br>';
echo '<input class="thesband" type="text" name="s1" style="width: 45px; height: 25px;" placeholder="from" value="'.$gmi[0].'" /> - <input class="thesband" type="text" name="ss1" style="width: 45px; height: 25px;" placeholder="to" value="'.$gma[0].'" /> is <input class="thegband" type="text" name="fir" style="width: 40px; height: 25px;" value="'.$gr[0].'" />';
echo '<br><input class="thesband" type="text" name="s2" style="width: 40px; height: 25px;" placeholder="from" value="'.$gmi[1].'" /> - <input class="thesband" type="text" name="ss2" style="width: 40px; height: 25px;" placeholder="to" value="'.$gma[1].'" /> is <input class="thegband" type="text" name="sec" style="width: 40px; height: 25px;"  value="'.$gr[1].'" />';
echo '<br><input class="thesband" type="text" name="s3" style="width: 40px; height: 25px;" placeholder="from" value="'.$gmi[2].'" /> - <input class="thesband" type="text" name="ss3" style="width: 40px; height: 25px;" placeholder="to" value="'.$gma[2].'" /> is <input class="thegband" type="text" name="thir" style="width: 40px; height: 25px;" value="'.$gr[2].'" />';
echo '<br><input class="thesband" type="text" name="s4" style="width: 40px; height: 25px;" placeholder="from" value="'.$gmi[3].'" /> - <input class="thesband" type="text" name="ss4" style="width: 40px; height: 25px;" placeholder="to" value="'.$gma[3].'" /> is <input class="thegband" type="text" name="fou" style="width: 40px; height: 25px;" value="'.$gr[3].'" />';
echo '<br><input class="thesband" type="text" name="s5" style="width: 40px; height: 25px;" placeholder="from" value="'.$gmi[4].'" /> - <input class="thesband" type="text" name="ss5" style="width: 40px; height: 25px;" placeholder="to" value="'.$gma[4].'" /> is <input class="thegband" type="text" name="fiv" style="width: 40px; height: 25px;" value="'.$gr[4].'" />';
echo '<br><input class="thesband" type="text" name="s6" style="width: 40px; height: 25px;" placeholder="from" value="'.$gmi[5].'" /> - <input class="thesband" type="text" name="ss6" style="width: 40px; height: 25px;" placeholder="to" value="'.$gma[5].'" /> is <input class="thegband" type="text" name="six" style="width: 40px; height: 25px;" value="'.$gr[5].'" />';
echo '<br><input class="thesband" type="text" name="s7" style="width: 40px; height: 25px;" placeholder="from" value="'.$gmi[6].'" /> - <input class="thesband" type="text" name="ss7" style="width: 40px; height: 25px;" placeholder="to" value="'.$gma[6].'" /> is <input class="thegband" type="text" name="sev" style="width: 40px; height: 25px;" value="'.$gr[6].'" />';
echo '<br><input class="thesband" type="text" name="s8" style="width: 40px; height: 25px;" placeholder="from" value="'.$gmi[7].'" /> - <input class="thesband" type="text" name="ss8" style="width: 40px; height: 25px;" placeholder="to" value="'.$gma[7].'" /> is <input class="thegband" type="text" name="eig" style="width: 40px; height: 25px;" value="'.$gr[7].'" />';
echo '<br><input class="thesband" type="text" name="s9" style="width: 40px; height: 25px;" placeholder="from" value="'.$gmi[8].'" /> - <input class="thesband" type="text" name="ss9" style="width: 40px; height: 25px;" placeholder="to" value="'.$gma[8].'" /> is <input class="thegband" type="text" name="nin" style="width: 40px; height: 25px;" value="'.$gr[8].'" />';
echo '<input style="display: none;" type="text" name="numr" value="'.mysqli_num_rows($resultgr).'" />';
echo '<br><input type="submit" name="submitgrades" id="submitgrades" value="Set Grade Bands" />';
//echo '<br><input type="submit" style="display: none;" id="submitsrange" name="submitsrange" value="Set Scores Range" />';
echo '</form>';
//echo '<button ></button>';
echo '</div>';
echo '</div>'; // for divref
echo '</div>';

echo '<div id="div2">';	
echo '<div class="form">';
echo '<h5>VIEW STUDENTS</h5>';
echo '<form name="registration" action="addstudentsbyadmin.php" method="post">';
echo '<input id="yoa" placeholder="Year of Admission" type="text" name="yoa" required/>';
echo '<input id="caa" placeholder="Class at Admission" type="text" name="caa" required/>';
echo '<input type="submit" name="submit8" value="View" />';
echo '</form>';	
echo '</div>';
echo '<br>';
echo '<div class="form">';
echo '<h5>CHECK IF HOUSE PARENT IS REGISTERED</h5>';
echo '<form name="registration" action="enrolhouseparent.php" method="post">';
echo '<input type="text" name="teacher" placeholder="Teacher Name" required />';
echo '<input type="submit" name="submit1" value="Check" />';
echo '</form>';
echo '</div>';
echo '</div>';	

echo '<div id="div3">';	
echo '<div class="form">';
echo '<h5>SET MAXIMUM ATTENDANCE FOR TERM</h5>';
echo '<form action="addmaxatt.php" method="post">';
echo '<input name="maxattname" placeholder="No of Times Sch Open" type="text" required /><br>';
echo '<label>Term Begins:<br><input name="termbegin" type="date" required /></label><br>';
echo '<label>Mid Term Begins:<br><input name="midtermday" type="date" required /></label>';
echo '<select style="width: 210px; height: auto; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="year" id="year" required >';
	
	$result = mysqli_query($db, "SELECT * FROM years");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['year'].'">';
								echo $row['year'];
								echo '</option>';
							}
echo '</select>';
echo '<select style="width: 210px; border-radius: 2px; height: auto; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="term" id="term" required >';
	
	$resulttm = mysqli_query($db, "SELECT * FROM terms");
						while($row = mysqli_fetch_assoc($resulttm))
							{  
								echo '<option value="'.$row['term'].'">';
								echo $row['term'];
								echo '</option>';
							}
    echo '</select>';
echo '<input type="submit" name="submit8" value="Set Max Attendance" />';
echo '</form>';	
echo '</div>';
echo '</div>';
echo '</div><br><br>';
echo '<hr />';
}
else{
echo '<center>';
$user=$_SESSION['username'];
$result2 = mysqli_query($db, "SELECT * FROM users2 where username='$user' AND school='".$_SESSION['school']."'");
while($row2 = mysqli_fetch_assoc($result2))
{
	$a = $row2['teacher_id'];
	$pna2[] = $row2['teacher'];
}
$s =  $a;
$pna = current($pna2);	
echo '<div class="success" style="display: none; color: green;" >Your registration data for the chosen year was successfully added/updated. <label id="showtheyear"></label></div>';	
echo '<div class="error" style="display: none; color: red;" >You could NOT be registered for the session beginning <label id="showtheyear2"></label></div>';
echo '</center>';
echo '</br><br>';
echo '<div class="form">';
echo '</br><br>';
echo '<h5>Register for a Given Year</h5>';
echo '<form name="princisystem" id="princisystem" >';
echo '<select style="width: 210px; height: auto; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="year" id="year" required >';
	echo '<option value="none" disabled="disabled" selected>SESSION COMMENCING</option>';
	$result = mysqli_query($db, "SELECT * FROM years");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['year'].'">';
								echo $row['year'];
								echo '</option>';
							}
    echo '</select>';
echo '<input id="princiid" style="display: none;" type="text" name="princiid" value="'.$s.'" required/>';	
echo '<input id="priname" style="display: none;" type="text" name="priname" value="'.$pna.'" required/><br><br>';
echo '<span style="color: red;" >Upload Digital Signature.</span><br>';
echo '<label class="fileContainer">';
echo '<input name="userImage" type="file" id="removepic" class="inputFile" />';
echo '</label>';
echo '<input type="submit" name="ct-submit" value="proceed" />';
echo '</form>';	
echo '</div>';	
echo '</br><br>';	
echo '<hr />';
echo '<div class="success2" style="display: none; color: green;" >Signature Permission Is Set.</div>';	
echo '<div class="error2" style="display: none; color: red;" >Signature Permission Could NOT Be Set<label id="showtheyear2"></label></div>';
echo '<div class="form">';

echo '</br><br>';

echo '<h5>Set Digital Signature Permission.</h5>';
echo '<label id="sigstatus"></label>';
echo '<form name="sigsystem" id="sigsystem" >';
echo '<select style="width: 210px; height: auto; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="years" id="yearsig" required="" >';
echo '<option value="none" disabled="disabled" selected>SESSION COMMENCING</option>';	
	$result = mysqli_query($db, "SELECT * FROM years");
						//echo '<option value="" selected="selected" disabled="disabled">PICK A YEAR</option>';
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['year'].'">';
								echo $row['year'];
								echo '</option>';
							}
    echo '</select>';
echo '<select style="width: 210px; height: auto; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="sig" id="sig" required >';
								echo '<option value="0" selected="selected">NO</option>';
								echo '<option value="1">YES</option>';
    echo '</select>';
echo '<input id="princiid2" style="display: none;" type="text" name="princiid" value="'.$s.'" required/>';	
echo '<input id="priname2" style="display: none;" type="text" name="priname" value="'.$pna.'" required/><br><br>';
echo '<input type="submit" name="ct-submit" value="proceed" />';
echo '</form>';	                             
echo '</div>';	
echo '</center>';
	
}
?>

	<?php
include("footer.php");
	?>	
</body>