<?php 
include("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
<link href="table/css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
<link rel="stylesheet" type="text/css" href="table/css/DT_bootstrap.css">
<script src="table/js/jquery.js" type="text/javascript"></script>
<script src="table/js/bootstrap.js" type="text/javascript"></script>
<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/jquery.dataTables.js"></script>
<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/DT_bootstrap.js"></script>


 <script>
function confirmationDelete(anchor)
{
   var conf = confirm('Are you sure want to delete this record?');
   if(conf)
      window.location=anchor.attr("href");
}
</script> 



 <style>
form {
  background: -webkit-linear-gradient(bottom, #CCCCCC, #EEEEEE 175px);
  background: -moz-linear-gradient(bottom, #CCCCCC, #EEEEEE 175px);
  background: linear-gradient(bottom, #CCCCCC, #EEEEEE 175px);
  margin: auto;
  position: relative;
  width: 80%;
  height: 350px;
  font-family: Tahoma, Geneva, sans-serif;
  font-size: 12px;
  font-style: italic;
  line-height: 24px;
  font-weight: bold;
  color: #09C;
  text-decoration: none;
  border-radius: 10px;
  padding: 10px;
  border: 1px solid #999;
  border: inset 1px solid #333;
  -webkit-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  -moz-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
}


input {
  width: 95%;
  display: block;
  border: 1px solid #999;
  height: 20px;
  -webkit-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  -moz-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
}

select {
  width: 100%;
  display: block;
  border: 1px solid #999;
  height: 30px;
  -webkit-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  -moz-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
}

select#upload {
  width: 140px;
  height: 30px;
  display: block;
}

.button {
  width: 100px;
  position: absolute;
  right: 20px;
  bottom: 20px;
  background: #09C;
  color: #fff;
  font-family: Tahoma, Geneva, sans-serif;
  height: 30px;
  border-radius: 15px;
  border: 1p solid #999;
}

input.button:hover {
  background: #fff;
  color: #09C;
}

select:focus, input:focus {
  border: 1px solid #09C;
}
</style>     
<style>
ul.topnav {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}
ul.topnav li {float: left;}
ul.topnav li a {
    display: inline-block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    transition: 0.3s;
    font-size: 17px;
}
ul.topnav li a:hover {background-color: #555;}
ul.topnav li.icon {display: none;}

@media screen and (max-width:680px) {
  ul.topnav li:not(:first-child) {display: none;}
  ul.topnav li.icon {
    float: right;
    display: inline-block;
  }
}
@media screen and (max-width:680px) {
  ul.topnav.responsive {position: relative;}
  ul.topnav.responsive li.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  ul.topnav.responsive li {
    float: none;
    display: inline;
  }
  ul.topnav.responsive li a {
    display: block;
    text-align: left;
  }
}
</style>

<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>
</head>
<body>
<?php
if($_SESSION['role'] == 'teacher'){
echo '<ul class="topnav" id="myTopnav">';
echo '<li><a href="teacher-student.php">Add scores</a></li>';
echo '<li><a href="update-score.php">Update scores</a></li>';
echo '<li><a href="formclasses.php">Your Classes as Form Tutor</a></li>';
echo '<li><a href="affective.php">Input Ranks (Affective)</a></li>';
echo '<li><a href="logout.php">Logout</a></li>';
echo '<li class="icon">';
echo '<a href="javascript:void(0);" onclick="myFunction()">&#9776;</a>';
echo '</li>';
echo '</ul>';
}
elseif($_SESSION['role'] == 'admin'){
echo '<ul class="topnav" id="myTopnav">';
echo '<li><a href="index.php">Home</a></li>';
echo '<li><a href="adstuadmin.php">Add Student</a></li>';
echo '<li><a href="adminaddformt.php">Add Form Tutor</a></li>';
echo '<li><a href="admgetresult.php">Student\'s Result</a></li>';
echo '<li><a href="admviewtea.php">View Teachers</a></li>';
echo '<li><a href="admviewtutor.php">View Tutors</a></li>';
echo '<li><a href="viewmaxatt.php">View Max Attendance</a></li>';
echo '<li><a href="logout.php">Logout</a></li>';
echo '<li class="icon">';
echo '<a href="javascript:void(0);" onclick="myFunction()">&#9776;</a>';
echo '</li>';
echo '</ul>';
}
else{echo "";}
?>        

<p>Welcome <?php echo $_SESSION['username']; ?>!</p>


<div class="row-fluid" style="width:100%;">
	        <div class="span12">
	            <div class="container" style="width:100%;">				
		<table style="width:100%; float:left;"cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
				
			<thead><tr>
			<th>Photo</th><th>Student</th><th>Sex</th><th>Class</th><th>Year</th><th>Admin No</th><th>Reason for Leaving</th><th>Edit</th><th>Delete</th>
			</thead></tr>
<?php
include "connection.php";

if(isset($_POST['submit8']) || isset($_POST['submitimg'])){
        $student_name = $_POST['student_name'];
        $sex = $_POST['sex'];
		$caa = $_POST['caa'];
		$yoa = $_POST['yoa'];
		$admno = $_POST['admno'];
		$reason = $_POST['reason'];
$result = mysqli_query($db, "SELECT regstu.regstu_id, regstu.student_name, regstu.sex, regstu.caa, regstu.yoa, regstu.admno, regstu.reason, regstu.dob, img.img_id, img.student_name, img.img FROM regstu INNER JOIN img ON regstu.student_name=img.student_name WHERE regstu.caa='$caa' AND regstu.yoa='$yoa'");
while ($row = mysqli_fetch_assoc($result)) {
	echo '<tr>';
echo '<td><a href="updatestudentsbyclassadminimg.php?img_id='.$row['img_id'].'"><img src="'.$row['img'].'" alt="no image" height="60" width="60" /></a></td>';	
echo '<td><input readonly="readonly" type="text" id="student_name" name="student_name" value="'.$row['student_name'].'" /></td>';	
echo '<td><input readonly="readonly" type="text" id="sex" name="sex" value="'.$row['sex'].'" /></td>';
echo '<td><input readonly="readonly" type="text" id="caa" name="caa" value="'.$row['caa'].'" /></td>';
echo '<td><input readonly="readonly" type="text" id="yoa" name="yoa" value="'.$row['yoa'].'" /></td>';
echo '<td><input readonly="readonly" type="text" id="admno" name="admno" value="'.$row['admno'].'" /></td>';
echo '<td><input style="width: 80%;" readonly="readonly" type="text" id="reason" name="reason" value="'.$row['reason'].'" /></td>';
echo '<td><a href="updatestudentsbyclassadmin.php?regstu_id='.$row['regstu_id'].'"><img src="table/edit-icon.png" alt="no image" height="30" width="30" /></a></td>';
echo '<td><a onClick="javascript:confirmationDelete($(this));return false;" href="delstudentadmin.php?regstu_id='.$row['regstu_id'].'"><img src="table/deletee.png" alt="no image" height="30" width="30" /></a></td>';
'</tr>';
}
}
?>
</table>
</div></div></div>
<br>
 </body>
</html>
