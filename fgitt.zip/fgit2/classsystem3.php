<?php
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
	
$teacher_id = $_POST['teacher_id'];
$teacher_name = $_POST['teacher_name'];
$year = $_POST['year'];
$sig = $_POST['sig'];
$sql1=mysqli_query($db,"SELECT * FROM principal WHERE  teacher_id='$teacher_id' AND teacher_name='$teacher_name' AND year='$year' AND school='".$_SESSION["school"]."'");
$sqlcount = mysqli_num_rows($sql1);
if($sqlcount >= 1){
$sql2=mysqli_query($db,"UPDATE principal SET sig='$sig' WHERE year='$year' AND teacher_id='$teacher_id' AND school='".$_SESSION["school"]."'");	
}
if($sql2){
echo 1;
}	
else{
echo 2;
}
?>