<?php 
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
if(isset($_POST['btn-upload'])){
        $teacher_id = $_POST['teacher_id'];
		$teacher_name = $_POST['teacher_name'];
        $class_id = $_POST['class_id'];
		$year_id = $_POST['year_id'];
		$term_id = $_POST['term_id'];
		$subject_id = $_POST['subject_id'];
        $query = ("INSERT into `teachers` (teacher_id, teacher_name, class_id, year_id, term_id, subject_id) VALUES ('$teacher_id', '$teacher_name', '$class_id', '$year_id', '$term_id', '$subject_id')");
        $result = mysqli_query($db,$query);
        if($result){
            echo "<div class='form'><h3>Data was sent successfully.</h3></div>";
			echo '<meta content="2;index.php" http-equiv="refresh" />';
        }
    }
	//include "connection.php";
	$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
							//echo $ctype;

if(isset($_POST['stsubmit'])){	
  $stformt = $_POST['stformt']; 
   $stterm = $_POST['stterm']; 
    $stclass = $_POST['stclass']; 
     $styear = $_POST['styear']; 
     $starms = $_POST['starms'];   
$checkst = mysqli_query($db, "SELECT * FROM subformt where formt='$stformt' AND term='$stterm' AND class='$stclass' AND year='$styear' AND arms='$starms' AND school='".$_SESSION["school"]."'");	
  $checkft = mysqli_query($db, "SELECT * FROM formt where term='$stterm' AND class_name='$stclass' AND year='$styear' AND arms='$starms' AND school='".$_SESSION["school"]."'");
    $checkft2 = mysqli_query($db, "SELECT * FROM formt where teacher_name='$stformt' AND term='$stterm' AND class_name='$stclass' AND year='$styear' AND arms='$starms' AND school='".$_SESSION["school"]."'");
$countst = mysqli_num_rows($checkst);
$countft2 = mysqli_num_rows($checkft2);
if($countst>0 || $countft2>0){
  	while($rowft = mysqli_fetch_assoc($checkft))
							{  
								$teacher_id2[] = $rowft['teacher_id'];
								$teacher_name2[] = $rowft['teacher_name'];
							    $class_name2[] = $rowft['class_name'];
							    $year2[] = $rowft['year'];
							    $term2[] = $rowft['term'];
							    $arms2[] = $rowft['arms'];
							    $school2[] = $rowft['school'];
							}
					$teacher_id	= current($teacher_id2);
					$teacher_name = current($teacher_name2);
					$class_name	= current($class_name2);
					$year	= current($year2);
					$term	= current($term2);
					$arms	= current($arms2);
					$school = current($school2);
if($stformt == $teacher_name)
{
  $msg = "";  
}else
{
 $msg = "<label style='color: red'>NOTE THAT YOU ARE SERVING AS SUBSTITUTE FORM TUTOR FOR <span style='text-decoration: underline;'>".strtoupper($teacher_name)."</span> THIS TERM.</label>";
}
 $msg .= "<form method='POST' action='ins.php' >";
 $msg .= '<input type="text" style="display: none;" name="teacher_id" value="'.$teacher_id.'" />';
$msg .= '<input style="display: none;" type="text" name="formt" value="'.$teacher_name.'" />';
$msg .= '<input style="display: none;" type="text" name="class" value="'.$class_name.'" />';
$msg .= '<input style="display: none;" type="text" name="arms" value="'.$arms.'" />';
$msg .= '<input style="display: none;" type="text" name="year" value="'.$year.'" />';
$msg .= '<input style="display: none;" type="text" name="term" value="'.$term.'" />';
$msg .= '<input style="display: none;" type="text" name="school" value="'.$school.'" />';
$msg .= '<input type="submit" class="submit" name="btn-upload" value="View the students" />';		
$msg .= "</form>";
}
}
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>form tutor</title>
<link rel="stylesheet" href="css/style.css" />
        <link rel="stylesheet" type="text/css" href="table/css/DT_bootstrap.css">

	<script src="table/js/jquery.js" type="text/javascript"></script>
<script src="table/js/bootstrap.js" type="text/javascript"></script>
	
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/jquery.dataTables.js"></script>
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/DT_bootstrap.js"></script>
  
   <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
  $("#stclass option").eq(7).css("display","none");
$("#stsubmit").on("click",function(){
var bb = $("#stclass").find(":selected").text();
var b = null;
if(bb=="Primary 1"){
	b = "Year 1";
}
else if(bb=="Primary 2"){
	b = "Year 2";
}
else if(bb=="Primary 3"){
	b = "Year 3";
}
else if(bb=="Primary 4"){
	b = "Year 4";
}
else if(bb=="Primary 5"){
	b = "Year 5";
}
else if(bb=="Primary 6"){
	b = "Year 6";
}
else if(bb=="JS1"){
	b = "Year 7";
}
else if(bb=="JS2"){
	b = "Year 8";
}
else if(bb=="JS3"){
	b = "Year 9";
}
else if(bb=="SS1"){
	b = "Year 10";
}
else if(bb=="SS2"){
	b = "Year 11";
}
else if(bb=="SS3"){
	b = "Year 12";
}
else{
	b = bb;
}
$("#stclass").find(":selected").val(b);
var c = $("#stclass").find(":selected").val();
//alert(c);
  });     
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>	
 <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
     <style>
        .container li{
         list-style-type: none;  
         float: left;
         margin-right: 5px;
         background-color: grey;
         width: 95px;
        }
        .container li a{
          color: white; 
          display: block;
          text-decoration: none;
        }
        nav ul li ul li{
           float: left;   
        }
    </style>
</head>
<body>
<?php
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");
}
else{header("location: logout.php");}
?>
<br>
<?php
//include "connection.php";
$user=$_SESSION['username'];
$result2 = mysqli_query($db, "SELECT * FROM users2 where username='$user' AND school='".$_SESSION['school']."'");
while($row2 = mysqli_fetch_assoc($result2))
{
	$b[] = $row2['teacher'];
}
$t = current($b);
$resultsubformt = mysqli_query($db, "SELECT * FROM subformt where formt='$t' AND school='".$_SESSION['school']."'");
while($rowsub = mysqli_fetch_assoc($resultsubformt))
{
	$bsubclass[] = $rowsub['class'];
	$bsubarms[] = $rowsub['arms'];
	$bsubyear[] = $rowsub['year'];
	$bsubterm[] = $rowsub['term'];
}
?>
 <br>
<?php
$user = $_SESSION['username'];
$result1 = mysqli_query($db, "SELECT * FROM users2 where username='$user' AND school='".$_SESSION['school']."'");
while ($row1 = mysqli_fetch_assoc($result1)) {
	$valteacher[] = $row1['teacher'];
	$a[] = $row1['teacher_id'];
}
$tn = current($a);
$valteach = current($valteacher);

echo '<center>';
echo '<div class="row-fluid" style="width:100%;">';
echo '<div class="span12">';
echo '<div class="container" style="width:100%;">';


$resulttt = mysqli_query($db, "SELECT * FROM subformt WHERE formt='$valteach' AND school='".$_SESSION['school']."' ORDER BY id ASC");
$rcountsss = mysqli_num_rows($resulttt);
$resultttt = mysqli_query($db, "SELECT * FROM formt WHERE teacher_name='$valteach' AND school='".$_SESSION['school']."' ORDER BY id ASC");
$rcountssss = mysqli_num_rows($resultttt);
if($rcountsss!=0){
    echo '<br><br><br>';
   echo '<form class="form" id="subteachformid" action="" method="post">';
   echo	'<label>';
	echo '<select style="width:210px;" name="stclass" id="stclass" required ><br>';
	$cccc = 0;
	$cccc2 = 0;	
	$result = mysqli_query($db, "SELECT * FROM classes");
						while($row = mysqli_fetch_assoc($result))
							{  
									echo '<option>';
								if($ctype=="Js"){
								if($cccc == 0){	
									$cccc++;
									echo 'SELECT A CLASS';
									continue;
									}		
								if($cccc <= 3){
								echo 'JS'.$cccc;	
								}
								elseif($cccc >= 4 && $cccc <= 6){
									if($cccc == 4){	
									$cccc++;
									echo 'SS'.($cccc2 - 2);	
									continue;
									}
									if($cccc == 5){	
									$cccc++;
									echo 'SS'.($cccc2 - 1);	
									continue;
									}
									if($cccc == 6){	
									$cccc++;
									echo 'SS'.($cccc2 - 0);	
									continue;
									}
								}else{
									break;
								}
								$cccc++;	
								$cccc2++;
									}
								else{	
								if($ctype=="Primary"){
									if($cccc == 0){	
									$cccc++;
									echo 'SELECT A CLASS';
									continue;
									}
								echo 'Primary '.$cccc;
								if($cccc > 5){
									break;
								}
								$cccc++;	
								}
								else{
								echo 'Year '.$cccc;
								if($cccc > 11){
									break;
								}
								$cccc++;	
								}
								}//end of else
								echo '</option>';
							}
    echo '</select>';
   echo	'</label><br>';
   echo '<select style="width:150px;" name="starms" id="starms" required >';
	$resultarm = mysqli_query($db,"SELECT arms FROM school where school='".$_SESSION["school"]."'");
				while($rowarm = mysqli_fetch_assoc($resultarm)){
					$arrr2[] = $rowarm["arms"];
				}
				$a = implode(',',$arrr2);
				$b = explode(',',$a);
				$f = (array_filter($b));

	for($i = 0; $i <= (count($f)-1); $i++){
								echo '<option value="'.$f[$i].'">';
								echo $f[$i];
								echo '</option>';
							}
     echo '</select><br>';
     echo '<select style="width:150px;" name="styear" id="styear" required >';
	echo '<option value="none" disabled="disabled" selected>SESSION COMMENCING</option>';				
	$result = mysqli_query($db, "SELECT year FROM years");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['year'].'">';
								echo $row['year'];
								echo '</option>';
							}
    echo '</select><br>';
	 echo '<select style="width:150px;" name="stterm" id="stterm" required >';
	$result = mysqli_query($db, "SELECT term FROM terms");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['term'].'">';
								echo $row['term'];
								echo '</option>';
							}
    echo '</select><br>';
    echo '<input style="display:none;" type="text" name="stformt" id="stformt" value="'.$valteach.'" />';
   echo '<input id="stsubmit" type="submit" class="stsubmit" name="stsubmit" value="Get Class" />';
   echo '</form><br>';
echo $msg;   
}else{
echo '<table style="width:100%;" cellpadding="1" cellspacing="1" border="1" class="table table-striped table-bordered" id="example">';
echo '<thead><tr style="text-align:left;">';
echo '<th style="display:none;">&nbsp;</th><th style="display:none;">&nbsp;</th><th>Class</th><th>Arm</th><th>Year</th><th>Term</th><th>Tutor</th><th width="80">Action</th><th style="display:none;">&nbsp;</th>';
echo '</thead></tr>';
$counter = 0;
$resultt = mysqli_query($db, "SELECT * FROM formt WHERE teacher_name='$valteach' AND school='".$_SESSION['school']."' ORDER BY id ASC");
$rcounts = mysqli_num_rows($resultt);
while($row = mysqli_fetch_assoc($resultt)){
	$class = $row["class_name"];
if($class=="Year 1"){
	if($ctype=="Js"){
	$cl = "JS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 1";
}
else{
	$cl = "Year 7";
}
}
elseif($class=="Year 2"){
	if($ctype=="Js"){
	$cl = "JS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 2";
}
else{
	$cl = "Year 2";
}
}
elseif($class=="Year 3"){
	if($ctype=="Js"){
	$cl = "JS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 3";
}
else{
	$cl = "Year 3";
}
}
elseif($class=="Year 4"){
	if($ctype=="Js"){
	$cl = "JS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 4";
}
else{
	$cl = "Year 4";
}
}
elseif($class=="Year 5"){
	if($ctype=="Js"){
	$cl = "JS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 5";
}
else{
	$cl = "Year 5";
}
}
elseif($class=="Year 6"){
	if($ctype=="Js"){
	$cl = "JS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 6";
}
else{
	$cl = "Year 6";
}
}
elseif($class=="Year 7"){
	if($ctype=="Js"){
	$cl = "JS1";
}else{
	$cl = "Year 7";
}
}else if($class=="Year 8"){
	if($ctype=="Js"){
	$cl = "JS2";
}else{
	$cl = "Year 8";
}
}else if($class=="Year 9"){
	if($ctype=="Js"){
	$cl = "JS3";
}else{
	$cl = "Year 9";
}
}else if($class=="Year 10"){
	if($ctype=="Js"){
	$cl = "SS1";
}else{
	$cl = "Year 10";
}
}else if($class=="Year 11"){
	if($ctype=="Js"){
	$cl = "SS2";
}else{
	$cl = "Year 11";
}
}else if($class=="Year 12"){
	if($ctype=="Js"){
	$cl = "SS3";
}else{
	$cl = "Year 12";
}
}else{
	$cl = "NOT APPLICABLE";
}

echo '<tr><td style="display:none;">';
echo '<form class="form" id="form_submit_'.$counter.'" action="ins.php" method="post"></td>';
echo '<td style="display:none;"><input type="hidden" name="teacher_id" value="'.$row['teacher_id'].'" /></td>';
//echo '<td><input type="hidden" name="teacher" value="'.$valteach.'" />'.$valteach.'</td>';
echo '<td><input type="hidden" name="class" value="'.$row['class_name'].'" />'.$cl.'</td>';
echo '<td><input type="hidden" name="arms" value="'.$row['arms'].'" />'.$row['arms'].'</td>';
echo '<td><input type="hidden" id="year" name="year" value="'.$row['year'].'" />'.$row['year'].'</td>';
echo '<td><input type="hidden" name="term" value="'.$row['term'].'" />'.$row['term'].'</td>';
echo '<td><input type="hidden" name="formt" value="'.$valteach.'" />'.$valteach.'</td>';
echo '<td width="80"><input id="submit_'.$counter.'" type="submit" class="submit" name="btn-upload" value="View the students" /></td>';
echo '<td style="display:none;"></form></td></tr>';
$counter++;
}
echo '</table>';
}
//print_r($yyyy2);
//$yyyy = current($yyyy2);
//echo $yyyy;
echo '</div></div></div>';
echo '</center>';
?>
<div id="results"></div>
<?php
include("footer.php");
?>
</body>