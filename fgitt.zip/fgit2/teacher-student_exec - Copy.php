<?php
	include("check.php");	
	
	include 'connection.php';
$student_id = $_POST['student_id'];
$student_name = $_POST['student_name'];
$class_name = $_POST['class_name'];
$year = $_POST['year'];
$term = $_POST['term'];
$subject = $_POST['subject'];
$teacher_id = $_POST['teacher_id'];
$score = $_POST['score'];
$ca = $_POST['ca'];	
$exam = $_POST['exam'];	


for ($i = 0; $i <= (count($student_id)-1); $i++){
    $t = mysqli_query($db,"INSERT INTO scores(student_name,class_name,year,term,subject,teacher_id,score,ca,exam) VALUES('$student_name[$i]','$class_name[$i]','$year[$i]','$term[$i]','$subject[$i]','$teacher_id[$i]','$score[$i]','$ca[$i]','$exam[$i]')");
}	

if($t){
	echo "<p align='center'>scores saved successfully</p>";
	echo '<meta content="2;teacher-student.php" http-equiv="refresh" />';
}	
else{
	echo "not saved";
}
	
?>

