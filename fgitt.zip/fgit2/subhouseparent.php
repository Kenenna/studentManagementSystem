<?php 
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
        $teacher_id = $_POST['teacher_id2'];
		$teacher_name = $_POST['teacher_name2'];
		$year = $_POST['year2'];
		$house = $_POST['house2'];  
		$checkteach = mysqli_query($db, "SELECT * FROM subhouseparent where teacher_name='$teacher_name' AND year='$year' AND house='$house' AND school='".$_SESSION["school"]."'");	
		$checkteachcount=mysqli_num_rows($checkteach);
	//	echo $checkteachcount;
	if($checkteachcount > 0){
	    echo "<div class='form'><h5 style='color:red'>".$teacher_name." has already been enrolled as ".$house." House Parent for Session beginning, ".$year."</h5></div>";
	echo '<meta content="2;index2.php" http-equiv="refresh" />';
	}else{
	   	$query = mysqli_query($db,"INSERT into `subhouseparent` (teacher_id, teacher_name, year, house, school) VALUES ('$teacher_id', '$teacher_name', '$year', '$house', '".$_SESSION["school"]."')");
        if($query){
            echo "<div class='form'><h4>House Parent was enrolled successfully.</h4></div>";
		echo '<meta content="2;index2.php" http-equiv="refresh" />';
        } // for if
        else{
             echo "<div class='form'><h4>House Parent was NOT enrolled successfully.</h4></div>";
			echo '<meta content="2;index2.php" http-equiv="refresh" />';
        } //for else for result
	}// for else for insert
?>