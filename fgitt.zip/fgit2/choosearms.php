<?php
	session_start();
	ob_start();
	include("auth.php");
	include("connection.php");
	if($_SESSION["role"] != "admin"){
		header("location: index2.php");
	}else{
	if(isset($_POST['btns-uploads'])){
					$arms1 = ucfirst($_POST['arm1']);
					$arms2 = ucfirst($_POST['arm2']);
					$arms3 = ucfirst($_POST['arm3']);
					$arms4 = ucfirst($_POST['arm4']);
					$arms5 = ucfirst($_POST['arm5']);
					$arms6 = ucfirst($_POST['arm6']);
					$armsarray=array($arms1,$arms2,$arms3,$arms4,$arms5,$arms6);
					$arr = (array_filter($armsarray));
					
$result2 = mysqli_query($db, "SELECT arms FROM arms");
while($row2 = mysqli_fetch_assoc($result2))
{  						
$values2[] = $row2['arms'];
}
$values = $values2;	

 $resulta = mysqli_query($db,"SELECT arms FROM school where school='".$_SESSION["school"]."'");
				while($rowa = mysqli_fetch_assoc($resulta)){
					$arrrr2[] = $rowa["arms"];
				}
				$c = implode(',',$arrrr2);
				$d = explode(',',$c);

		$str=implode(",",$arr);	
		
		
					//if(empty($d)){
					$noarr = array();
					for($i = 0; $i <= (count($arr)-1); $i++){
					if($arr[$i] != ""){
					if (in_array($arr[$i], $values)){
					$noarr[] = array_push($noarr,$arr[$i]);
					}else{
					$t = mysqli_query($db,"INSERT INTO arms(arms) VALUES('$armsarray[$i]')");
					}
					}
					}
					//}
					
					
					$m = mysqli_query($db,"UPDATE school SET arms='$str' WHERE school='".$_SESSION["school"]."'");
					header("location: index2.php");
	} 
	
	if(isset($_POST['btns-uploadsadd'])){
					$arms1 = ucfirst($_POST['arm1']);
					$arms2 = ucfirst($_POST['arm2']);
					$arms3 = ucfirst($_POST['arm3']);
					$arms4 = ucfirst($_POST['arm4']);
					$arms5 = ucfirst($_POST['arm5']);
					$arms6 = ucfirst($_POST['arm6']);
					$armsarray=array($arms1,$arms2,$arms3,$arms4,$arms5,$arms6);
					$arradd = (array_filter($armsarray));		
$result2 = mysqli_query($db, "SELECT * FROM arms");
while($row2 = mysqli_fetch_assoc($result2))
{  						
$values2[] = $row2['arms'];
}
$values = $values2;	
				$resulta = mysqli_query($db,"SELECT arms FROM school where school='".$_SESSION["school"]."'");
				while($rowa = mysqli_fetch_assoc($resulta)){
					$arrrr2[] = $rowa["arms"];
				}
				$c = implode(',',$arrrr2);
				$d = explode(',',$c);
					
					for($i = 0; $i <= (count($arradd)-1); $i++){
					if (!in_array($arradd[$i], $d)){
						$c .= ",".$arradd[$i];
					} // end of if within for loop
						} // end of for loop
	$mm = mysqli_query($db,"UPDATE school SET arms='$c' WHERE school='".$_SESSION["school"]."'");
	if($mm){
					for($i = 0; $i <= (count($arradd)-1); $i++){
					if (!in_array($arradd[$i], $values)){
				$ttt = mysqli_query($db,"INSERT INTO arms(arms) VALUES('$arradd[$i]')");
					} // end of for loop for counting new arms entries
					} // end of if for checking if particular value is in database
		
	} // end of if clause for insert new arms in arms table
	header("location: index2.php");
	} //end of isset btns-uploadsadd
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>General</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="Description" lang="en" content="Choose School">
		<meta name="author" content="School Management System">
		<meta name="robots" content="index, follow">
<style>
	.div1 {
    width: 55%;
    height: 70%;
    background-color: red;
    position: absolute;
    top:0;
    bottom: 0;
    left: 0;
    right: 0;
    margin: auto;
}
.pbutton {
	background-color:#44c767;
	-moz-border-radius:28px;
	-webkit-border-radius:28px;
	border-radius:12px;
	border:1px solid #18ab29;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:15px;
	padding:6px 24px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
	margin: auto;
}
.pbutton:hover {
	background-color:#5cbf2a;
}
.pbutton:active {
	position:relative;
	top:1px;
}
</style>
<script src="table/js/jquery.js" type="text/javascript"></script>
<script>
$(document).ready(function(){
	$( "#clickme" ).click(function() {
  $( "#addarms" ).toggle();
	});
	$( "#idimg" ).click(function() {
  $( "#addarms" ).toggle();
	});	
});
</script>	
</head>
<body style="background-color: #eaf0f2;">
<?php 
if($_POST['school']==""){
	$_SESSION['school'] = $_SESSION['school'];
	}else{
	$_SESSION['school'] = $_POST['school'];
	}
//echo $_SESSION["username"];
echo "<center>";
echo "</center>";
echo '<div class="div1" >';
 $result = mysqli_query($db,"SELECT arms FROM school where school='".$_SESSION["school"]."'");
				while($row = mysqli_fetch_assoc($result)){
					$arrr2[] = $row["arms"];
				}
				$a = implode(',',$arrr2);
				$b = explode(',',$a);
				$f = (array_filter($b));
				echo "<br>";	
				echo "<center>";
				echo '<label style="color: white;" >INPUT/EDIT CLASS ARMS</label>';	
				echo '<div style="color: white;">If any class arm is no longer needed, erase JUST THAT ONE. Erasing all arms removes them from our records.</div>';
				echo "<br>";
				
				if(!empty($f)){
				echo '<form method="POST" action="choosearms.php"" >';	
				for($i = 0; $i <= (count($f)-1); $i++){
					echo '<input type="text" name="arm'.($i+1).'" value="'.$f[$i].'" /><br>';
				}
				echo '<input type="submit" style="background-color: green; color: white;" class="button" name="btns-uploads" value="Proceed" >';
				echo '</form>';	
				echo '<br><button id="clickme" style="color: white; background-color: green;" >ADD MORE ARMS</button><br>';	
				echo '<form method="POST" id="addarms" action="choosearms.php"" style="display: none;" >';	
				echo '<input type="text" name="arm1" placeholder="arm1" ><br>';
				echo '<input type="text" name="arm2" placeholder="arm2" ><br>';
				echo '<input type="text" name="arm3" placeholder="arm3" ><br>';
				echo '<input type="text" name="arm4" placeholder="arm4" ><br>';
				echo '<input type="text" name="arm5" placeholder="arm5" ><br>';
				echo '<input type="text" name="arm6" placeholder="arm6" ><br>';
				echo '<input type="submit" style="background-color: green; color: white;" class="button" name="btns-uploadsadd" value="Proceed" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="x.png" id="idimg" width="20" height="20" style="cursor: pointer;" />';
				echo '</form>';	
				}else{
				echo '<form method="POST" action="choosearms.php"" >';	
				echo '<input type="text" name="arm1" placeholder="arm1" ><br>';
				echo '<input type="text" name="arm2" placeholder="arm2" ><br>';
				echo '<input type="text" name="arm3" placeholder="arm3" ><br>';
				echo '<input type="text" name="arm4" placeholder="arm4" ><br>';
				echo '<input type="text" name="arm5" placeholder="arm5" ><br>';
				echo '<input type="text" name="arm6" placeholder="arm6" ><br>';
				echo '<input type="submit" style="background-color: green; color: white;" class="button" name="btns-uploads" value="Proceed" >';
				echo '</form>';	
				}
				echo "</center>";
echo '</div>';
echo '<div class="div2" ><a class="pbutton" href="logout.php" >Logout</a></div>';
?>
</body>
</html>