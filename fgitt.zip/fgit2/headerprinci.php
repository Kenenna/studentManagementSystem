<?php
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
$user=$_SESSION['username'];
$resultrole2 = mysqli_query($db, "SELECT role, adminlevel, img FROM users2 where username='".$_SESSION['username']."' AND school='".$_SESSION['school']."'");
while($rowrole2 = mysqli_fetch_assoc($resultrole2))
{
	$arole[] = $rowrole2['role'];
	$img[] = $rowrole2['img'];
	$adminlevel2[] = $rowrole2['adminlevel'];
}
$_SESSION['role'] =  current($arole);
$imgg =  current($img);
$_SESSION['adminlevel'] =  current($adminlevel2);
?>

 <nav>
        <div class="menu-toggle">
            <h3>Menu</h3>
            <button type="button" id="menu-btn">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
          <ul id="respMenu" class="ace-responsive-menu" data-menu-style="horizontal">
              <li style="z-index: 1000;">
                <a href='index2.php'>
                    <i class="fa fa-home" aria-hidden="true"></i>
                    <span>Home</span>
                </a>
            </li>
            
            <li style="z-index: 1000;">
                <a href="admgetresult.php">
                    <!--<i class="fa fa-heart" aria-hidden="true"></i>-->
                    <span class="title">Student's Result</span>
                </a>
            </li>
             <li style="z-index: 1000;">
                <a href="javascript:;">
                    <!--<i class="fa fa-cube" aria-hidden="true"></i>-->
                    <span class="title">Views</span>
                </a>
                <!-- Level Two-->
                <ul style="z-index: 1000;">
                    <li style="z-index: 1000;">
                        <a href="admviewtea.php">View Teachers</a>
                    </li>
                    <li style="z-index: 1000;">
                        <a href="admviewtutor.php">View Tutors</a>
                    </li>
                    <li style="z-index: 1000;">
                        <a href="admviewhp.php">View House Parent</a>
                    </li>
                    <li style="z-index: 1000;">
                        <a href="viewmaxatt.php">View Max Attendance</a>
                    </li>
                </ul>
            </li>
            <li style="z-index: 1000;">
                <a href="princicomments.php">
                    <!--<i class="fa fa-heart" aria-hidden="true"></i>-->
                    <span class="title">Principal's/Head-Teacher's Comment</span>
                </a>
            </li>
            <?php 
	        if($_SESSION['adminlevel']==4)
	        {?> 
	             <li style="z-index: 1000;">
                <a href="manageadmins.php">
                    <!--<i class="fa fa-heart" aria-hidden="true"></i>-->
                    <span class="title">Manage Admins</span>
                </a>
            </li>
            <?php
	        }
	        ?>
             <li style="z-index: 1000;" class="last">
                <a href="javascript:;">
                    <!--<i class="fa fa-crop" aria-hidden="true"></i>-->
                    <span class="title">User</span>
                </a>
                <!-- Level Two-->
                <ul>
                        <?php
	  $url = $_SERVER['REQUEST_URI'];
	  if($url == '/index2.php'){
	  echo '<li style="z-index: 1000;"><a href="#" id="imghref">Change Profile Pic</a></li>';
	  }
	   ?>
                    <li style="z-index: 1000;">
                        <a href="newpass.php">
                            <!--<i class="fa fa-graduation-cap" aria-hidden="true"></i>-->
                           Alter Pass						
                        </a>
                    </li>
                    <li style="z-index: 1000;">
                        <a href="chooseschool.php">
                           <!--<i class="fa fa-database" aria-hidden="true"></i>-->
                          School
                        </a>
                    </li>
                     <li style="z-index: 1000;">
                        <a href="logout.php">
                           <!--<i class="fa fa-database" aria-hidden="true"></i>-->
                          Logout
                        </a>
                    </li>
                </ul>
            </li>
            <li class="last" style="float: right;" ><img id="photo" src="<?php echo $imgg ?>" width="60" height="60" /><a style="float: left;" href="index2.php" style="color: gold;" ><?php echo $user; ?></a></li>
        </ul>
    </nav>
    <!-- End of Responsive Menu -->