<?php 
session_start();
include("auth.php");
include ("connection.php");
$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Update Teacher</title>
<link rel="stylesheet" href="css/style.css" />
        <link rel="stylesheet" type="text/css" href="table/css/DT_bootstrap.css">

	<script src="table/js/jquery.js" type="text/javascript"></script>
<script src="table/js/bootstrap.js" type="text/javascript"></script>
	
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/jquery.dataTables.js"></script>
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/DT_bootstrap.js"></script>
   
   <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
   
 /*  $("#menu-btn").on('click', function() {
      var navht = $("#respMenu").height();
       if($('.checkvis').is(':visible')){
       alert("y");
   }else{
      alert("n"); 
   }
   }); */
   
   
  });
 </script>	
<style>
select{
	height: auto;
}
</style>
<style>
form {
  background: -webkit-linear-gradient(bottom, #CCCCCC, #EEEEEE 175px);
  background: -moz-linear-gradient(bottom, #CCCCCC, #EEEEEE 175px);
  background: linear-gradient(bottom, #CCCCCC, #EEEEEE 175px);
  width: 380px;
  height: 370px;
  font-family: Tahoma, Geneva, sans-serif;
  font-size: 16px;
  font-style: italic;
  line-height: 24px;
  font-weight: bold;
  color: #09C;
  text-decoration: none;
  border-radius: 10px;
  padding: 10px;
  border: 1px solid #999;
  border: inset 1px solid #333;
  -webkit-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  -moz-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  margin-top: 40px;
}
@media only screen and (max-width: 600px) {
    form {
         margin-top: 20px;
         height: 800px;
    }
}

input {
  width: 30%;
  display: block;
  border: 1px solid #999;
  height: 15px;
  -webkit-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  -moz-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  text-align: center; 
}

select#upload {
  width: 140px;
  height: 30px;
  display: block;
}

.button {
  width: 200px;
  bottom: 10px;
  top: 180px;
  background: #09C;
  float: center;
  color: #fff;
  font-family: Tahoma, Geneva, sans-serif;
  height: 40px;
  border-radius: 15px;
  border: 1p solid #999;
}

input.button:hover {
  background: #fff;
  color: #09C;
}

select:focus, input:focus {
  border: 1px solid #09C;
}
ul.ace-responsive-menu> li > ul > li {
    background: #fff;   
}
</style> 
 <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
</head>
<body>
<?php
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");	
}
else{ header("location: logout.php");}
?>
<?php

$id = $_GET['id'];
$query1 = mysqli_query($db, "select * from teachers where id=$id");
while ($row1 = mysqli_fetch_array($query1)) {

	$term_id = $row1['term_id'];
	if($term_id == 1){$term = 'First Term';}
	elseif($term_id == 2){$term = 'Second Term';}
	elseif($term_id == 3){$term = 'Third Term';}
	else{'';}
	
	$year_id = $row1['year_id'];
	if($year_id == 1){$year = '2012';}
	elseif($year_id == 2){$year = '2013';}
	elseif($year_id == 3){$year = '2014';}
	elseif($year_id == 4){$year = '2015';}
	elseif($year_id == 5){$year = '2016';}
	elseif($year_id == 6){$year = '2017';}
	elseif($year_id == 7){$year = '2018';}
	elseif($year_id == 8){$year = '2019';}
	elseif($year_id == 9){$year = '2020';}
	elseif($year_id == 10){$year = '2021';}
	elseif($year_id == 11){$year = '2022';}
	elseif($year_id == 12){$year = '2023';}
	elseif($year_id == 13){$year = '2024';}
	elseif($year_id == 14){$year = '2025';}
	elseif($year_id == 15){$year = '2026';}
	elseif($year_id == 16){$year = '2027';}
	elseif($year_id == 17){$year = '2028';}
	elseif($year_id == 18){$year = '2029';}
	elseif($year_id == 19){$year = '2030';}
	elseif($year_id == 20){$year = '2031';}
	elseif($year_id == 21){$year = '2032';}
	elseif($year_id == 22){$year = '2033';}
	elseif($year_id == 23){$year = '2034';}
	elseif($year_id == 24){$year = '2035';}
	elseif($year_id == 25){$year = '2036';}
	elseif($year_id == 26){$year = '2037';}
	elseif($year_id == 27){$year = '2038';}
	elseif($year_id == 28){$year = '2039';}
	elseif($year_id == 29){$year = '2040';}
	elseif($year_id == 30){$year = '2041';}
	elseif($year_id == 31){$year = '2042';}
	elseif($year_id == 32){$year = '2043';}
	elseif($year_id == 33){$year = '2044';}
	elseif($year_id == 34){$year = '2045';}
	elseif($year_id == 35){$year = '2046';}
	else{'';}

echo '<center>';
echo '<br><br><form action="updateteabyadmin_exec.php" method="post" enctype="multipart/form-data">';
echo '<div>';
echo '<h1>Edit Teacher\'s Info :</h1>';
echo '<label>';
echo  '<input id="id" type="hidden" name="id" value="'.$row1['id'].'" />';
echo  '</label>';
 echo '<label>';
echo  '<input id="teacher_name" type="text" name="teacher_name" value="'.$row1['teacher_name'].'" />';
echo '</label>';
  echo '<label>';
echo  '<input id="year" type="text" name="year" value="'.$year.'" />';
echo '</label>';
 echo '<label>';
echo  '<input id="year" type="text" name="term" value="'.$term.'" />';
echo '</label>';
 echo '<label>';
   if($ctype=="Js"){
if($row1['class_name'] == "Year 7"){ $caa2 = "JS1";}
else if($row1['class_name'] == "Year 8"){ $caa2 = "JS2";}
else if($row1['class_name'] == "Year 9"){ $caa2 = "JS3";}
else if($row1['class_name'] == "Year 10"){ $caa2 = "SS1";}
else if($row1['class_name'] == "Year 11"){ $caa2 = "SS2";}
else if($row1['class_name'] == "Year 12"){ $caa2 = "SS3";}
else{}
}elseif($ctype=="Primary"){
if($row1['class_name'] == "Year 1"){ $caa2 = "Primary 1";}
else if($row1['class_name'] == "Year 2"){ $caa2 = "Primary 2";}
else if($row1['class_name'] == "Year 3"){ $caa2 = "Primary 3";}
else if($row1['class_name'] == "Year 4"){ $caa2 = "Primary 4";}
else if($row1['class_name'] == "Year 5"){ $caa2 = "Primary 5";}
else if($row1['class_name'] == "Year 6"){ $caa2 = "Primary 6";}
else{}
}else{
if($row1['class_name'] == "Year 7"){ $caa2 = "Year 7";}	
else if($row1['class_name'] == "Year 8"){ $caa2 = "Year 8";}
else if($row1['class_name'] == "Year 9"){ $caa2 = "Year 9";}
else if($row1['class_name'] == "Year 10"){ $caa2 = "Year 10";}
else if($row1['class_name'] == "Year 11"){ $caa2 = "Year 11";}
else if($row1['class_name'] == "Year 12"){ $caa2 = "Year 12";}
else{}
}
echo  '<input id="class_name2" type="text" name="class_name2" value="'.$caa2.'" />';  
echo  '<input style="display: none;" id="class_name" type="text" name="class_name" value="'.$row1['class_name'].'" />';
echo '</label>';
 echo '<label>';
echo  '<input id="subject" type="text" name="subject" value="'.$row1['subject'].'" /><br>';
echo '<span>Initial Letter of Each Word Should Be Capital.</span>';
echo '</label>';
echo '<label><br>';
 echo   '<input type="submit" class="button" name="btn-upload" value="Submit Form" />';
  echo  '</label>';
echo '</div>';
echo '</form><br>';
}
echo '</center>';
include("footer.php");
?>

</body>
</html>