<?php 
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
if(isset($_POST['btn-upload'])){
        $teacher_id = $_POST['teacher_id'];
		$teacher_name = $_POST['teacher_name'];
        $class_id = $_POST['class_id'];
		$year_id = $_POST['year_id'];
		$term_id = $_POST['term_id'];
		$subject_id = $_POST['subject_id'];
        $query = ("INSERT into `teachers` (teacher_id, teacher_name, class_id, year_id, term_id, subject_id) VALUES ('$teacher_id', '$teacher_name', '$class_id', '$year_id', '$term_id', '$subject_id')");
        $result = mysqli_query($db,$query);
        if($result){
            echo "<div class='form'><h3>Data was sent successfully.</h3></div>";
			echo '<meta content="2;index.php" http-equiv="refresh" />';
        }
    }
	//include "connection.php";
	$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
							//echo $ctype;
?>


<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>principal's comments</title>
<link rel="stylesheet" href="css/style.css" />
 <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">

	<script src="table/js/jquery.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js" type="text/javascript"></script>
   
   <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <style>
select{
	height: auto;
}
nav li ul li{
    z-index: 1000;
    float: left;
}
table{
    width: 100%;
}
table{
    text-align: center;
}
table tr td, table thead th{
    width: 20%;
    text-align: center;
}
@media only screen and (max-width: 600px) {
    table tr td, table thead th{
         margin-top: 30px;
         width: 20%;
         text-align: center;
    }
}
</style>
<script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
   
      $('#example').DataTable( {
        "scrollY":        "550px",
        "scrollCollapse": true,
        "paging":         false
    } ); 
   
 $("[data-j=cn] option").eq(7).css("display","none");  
 $(".submit").on("click",function(){ 
var bb = $("[data-j=cn]").find(":selected").text();
var b = null;
if(bb=="Primary 1"){
	b = "Year 1";
}
else if(bb=="Primary 2"){
	b = "Year 2";
}
else if(bb=="Primary 3"){
	b = "Year 3";
}
else if(bb=="Primary 4"){
	b = "Year 4";
}
else if(bb=="Primary 5"){
	b = "Year 5";
}
else if(bb=="Primary 6"){
	b = "Year 6";
}
else if(bb=="JS1"){
	b = "Year 7";
}
else if(bb=="JS2"){
	b = "Year 8";
}
else if(bb=="JS3"){
	b = "Year 9";
}
else if(bb=="SS1"){
	b = "Year 10";
}
else if(bb=="SS2"){
	b = "Year 11";
}
else if(bb=="SS3"){
	b = "Year 12";
}
else{
	b = bb;
}
$("[data-j=cn]").find(":selected").val(b);
var c = $("[data-j=cn]").find(":selected").val();
});
  });
 </script>	

<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>
 <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
</head>

<body>
<?php
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");
}
elseif($_SESSION['role'] == 'admin'){
echo '<ul class="topnav" id="myTopnav">';
echo '<li><a href="adstuadmin.php">Add Student</a></li>';
echo '<li><a href="adminaddformt.php">Add Form Tutor</a></li>';
echo '<li><a href="admgetresult.php">Student\'s Result</a></li>';
echo '<li><a href="admviewtea.php">View Teachers</a></li>';
echo '<li><a href="admviewtutor.php">View Tutors</a></li>';
echo '<li><a href="viewmaxatt.php">View Max Attendance</a></li>';
echo '<li><a href="logout.php">Logout</a></li>';
echo '<li class="icon">';
echo '<a href="javascript:void(0);" onclick="myFunction()">&#9776;</a>';
echo '</li>';
echo '</ul>';
}
else{echo "";}
?>

<br>

<?php
//include "connection.php";
$user=$_SESSION['username'];
$result2 = mysqli_query($db, "SELECT * FROM users2 where username='$user' AND school='".$_SESSION['school']."'");
while($row2 = mysqli_fetch_assoc($result2))
{
	$a = $row2['teacher_id'];
	$b = $row2['teacher'];
}
$s =  $a;
$t = $b;

//echo $s;
//echo $t;
?>
 
<?php

$user = $_SESSION['username'];
$result1 = mysqli_query($db, "SELECT * FROM users2 where username='$user' AND school='".$_SESSION['school']."'");
while ($row1 = mysqli_fetch_assoc($result1)) {
	$valteacher[] = $row1['teacher'];
	$teacherid[] = $row1['teacher_id'];
}
$valteach = current($valteacher);
$teachid = current($teacherid);

echo '<center>';
echo '<div class="row-fluid" style="width:100%;">';
echo '<div class="span12">';
echo '<div class="container" style="width:100%;">';
echo '<table cellpadding="1" cellspacing="1" border="1" class="table table-striped table-bordered" id="example">';
echo '<thead><tr style="text-align:left;">';
echo '<th style="display:none;">&nbsp;</th><th>Session Commencing</th><th>Class</th><th>Term</th><th>Action</th><th style="display:none;">&nbsp;</th>';
echo '</thead></tr>';
$counter = 0;
$result = mysqli_query($db, "SELECT * FROM principal where teacher_id='$teachid' AND school='".$_SESSION['school']."' ORDER BY year");
while($row = mysqli_fetch_assoc($result)){
echo '<tr><td style="display:none;">';
echo '<form class="form" name="formtocomment" id="form_submit" action="viewprincistudents2.php" method="post" ></td>';
echo '<td><input style="display: none;" type="text" id="year" name="year" value="'.$row['year'].'" />'.$row['year'].'</td>';
$cccc = 0;
$cccc2 = 0;
echo '<td><select data-j="cn" style="width: 150px; height: auto; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 5px; color: red; font-size: 16px;" name="class_name" class="class_name" id="class_namesubmit_'.$counter.'" required="" >';
	$resultcl = mysqli_query($db, "SELECT * FROM classes");
						while($rowcl = mysqli_fetch_assoc($resultcl))
							{ 
							echo '<option>';
								if($ctype=="Js"){
								if($cccc == 0){	
									$cccc++;
									echo 'CLASS';
									continue;
									}		
								if($cccc <= 3){
								echo 'JS'.$cccc;	
								}
								elseif($cccc >= 4 && $cccc <= 6){
									if($cccc == 4){	
									$cccc++;
									echo 'SS'.($cccc2 - 2);	
									continue;
									}
									if($cccc == 5){	
									$cccc++;
									echo 'SS'.($cccc2 - 1);	
									continue;
									}
									if($cccc == 6){	
									$cccc++;
									echo 'SS'.($cccc2 - 0);	
									continue;
									}
								}else{
									break;
								}
								$cccc++;	
								$cccc2++;
									}
								else{	
								if($ctype=="Primary"){
									if($cccc == 0){	
									$cccc++;
									echo 'CLASS';
									continue;
									}
								echo 'Primary '.$cccc;
								if($cccc > 5){
									break;
								}
								$cccc++;	
								}
								else{
								echo 'Year '.($cccc+1);
								if($cccc > 11){
									break;
								}
								$cccc++;	
								}
								}//end of else
								echo '</option>';
							}
echo '</select></td>';
echo '<td><select style="width: 150px; height: auto; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 5px; color: red; font-size: 16px;" name="term" class="term" id="term" required="" >';
	$resulttm = mysqli_query($db, "SELECT * FROM terms");
						echo '<option value="" disabled="disabled" selected="selected" >TERM</option>';	
						while($rowtm = mysqli_fetch_assoc($resulttm))
							{  
								echo '<option value="'.$rowtm['term'].'">';
								echo $rowtm['term'];
								echo '</option>';
							}
echo '</select></td>';
echo '<td width="70"><input id="submit_'.$counter.'" type="submit" class="submit" name="btn-upload" value="Add/Update Comments" /></td>';
echo '<td style="display:none;"></form></td></tr>';
$counter++;
}
echo '</table>';
//print_r($yyyy2);
//$yyyy = current($yyyy2);
echo $yyyy;
echo '</div></div></div>';
echo '</center>';
?>
<div id="results"></div>
<br><br><br><br><br><br><br><br><br><br><br><br><br>
<?php
include("footer.php");
?>
</body>