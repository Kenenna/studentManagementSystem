<?php
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Index</title>
<script>
$(document).ready(function() {	
$("#csy").submit(function(evts) {
	evts.preventDefault();
$.ajax({
type: "POST",
url: "classsystem.php",
data: $("#csy").serialize(),	
success: function(responsecl){
alert(responsecl);
}	
});	
});
});
</script>
</head>
<body>
<?php
echo '<div class="success" style="display: none; color: green;" >Class Naming System is set.</div>';	
echo '<div class="error" style="display: none; color: red;" >Error in setting class naming system!</div>';
echo '<div class="form">';
echo '<h5>SET CLASS NAMING SYSTEM</h5>';
echo '<form id="csy" >';
echo '<select style="width: 210px; border-radius: 2px; height: auto; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="classtype" id="classtype" required >';
$resultct = mysqli_query($db, "SELECT classtype FROM classtype");
						while($rowct = mysqli_fetch_assoc($resultct))
							{  
						if($rowct['classtype']=="Js")
						{ $ct = "JS1 - SS3";}else{$ct = "Year 7 - Year 12";}
								echo '<option value="'.$rowct['classtype'].'">';
								echo $ct;
								echo '</option>';
							}
echo '</select><br>';
echo '<input type="submit" value="set it" />';
echo '</form>';	
echo '</div>';

?>
</body>
</html>
