<?php 
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Get Result</title>
<link rel="stylesheet" href="css/style.css" />
		<!--<link href="table/css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">-->
        <link rel="stylesheet" type="text/css" href="table/css/DT_bootstrap.css">

	<script src="table/js/jquery.js" type="text/javascript"></script>
<script src="table/js/bootstrap.js" type="text/javascript"></script>
	
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/jquery.dataTables.js"></script>
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/DT_bootstrap.js"></script>
     
   <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
if($("[data-j=cnn] option").first().text() == ""){
	$("[data-j=cnn] option").first().text("SELECT A CLASS");
}
$("[data-j=cnn] option").last().css("display", "none");

$("#byarmn").prop("checked", true);
$("#armsbyarms").hide();
$("#byarmy").on("change", function(){
	if(this.checked){
        this.checked=true;
		$("#armsbyarms").show();
	}else{
		$("#armsbyarms").hide();
	}           
});


$("[data-j=cn] option").eq(7).css("display","none");
var byarm = $("#byarm").find(":checked").val();

$("#subform").on("click",function(){
var bb = $("[data-j=cn]").find(":selected").text();
var b = null;
if(bb=="Primary 1"){
	b = "Year 1";
}
else if(bb=="Primary 2"){
	b = "Year 2";
}
else if(bb=="Primary 3"){
	b = "Year 3";
}
else if(bb=="Primary 4"){
	b = "Year 4";
}
else if(bb=="Primary 5"){
	b = "Year 5";
}
else if(bb=="Primary 6"){
	b = "Year 6";
}
else if(bb=="JS1"){
	b = "Year 7";
}
else if(bb=="JS2"){
	b = "Year 8";
}
else if(bb=="JS3"){
	b = "Year 9";
}
else if(bb=="SS1"){
	b = "Year 10";
}
else if(bb=="SS2"){
	b = "Year 11";
}
else if(bb=="SS3"){
	b = "Year 12";
}
else{
	b = bb;
}
$("[data-j=cn]").find(":selected").val(b);
var c = $("[data-j=cn]").find(":selected").val();
alert(c);
 });  
	  
	  
$("#submit4").on("click",function(){	
var bb = $("[data-j=cnn]").find(":selected").text();
var b = null;
if(bb=="Primary 1"){
	b = "Year 1";
}
else if(bb=="Primary 2"){
	b = "Year 2";
}
else if(bb=="Primary 3"){
	b = "Year 3";
}
else if(bb=="Primary 4"){
	b = "Year 4";
}
else if(bb=="Primary 5"){
	b = "Year 5";
}
else if(bb=="Primary 6"){
	b = "Year 6";
}
else if(bb=="JS1"){
	b = "Year 7";
}
else if(bb=="JS2"){
	b = "Year 8";
}
else if(bb=="JS3"){
	b = "Year 9";
}
else if(bb=="SS1"){
	b = "Year 10";
}
else if(bb=="SS2"){
	b = "Year 11";
}
else if(bb=="SS3"){
	b = "Year 12";
}
else{
	b = bb;
}
$("[data-j=cnn]").find(":selected").val(b);
var c = $("[data-j=cnn]").find(":selected").val();
if(c=="Year 1" || c=="Year 2" || c=="Year 3" || c=="Year 4" || c=="Year 5" || c=="Year 6"){
	$("#transcriptform").prop("action","transtea2.php");
}
 });	    
	  
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>
<style>
nav{
z-index: 1000;
}
nav ul li a{
z-index: 1000;
}
nav ul{
z-index: 1000;
}
select{
	height: auto;
}
</style>
 <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
   <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
</head>
<body>
<?php
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
elseif($_SESSION['role'] == 'student'){
include("headerstudent.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");
}
else{ header("location: logout.php");}
?>
<?php
$resultrole2 = mysqli_query($db, "SELECT role, teacher FROM users2 where username='".$_SESSION['username']."' AND school='".$_SESSION["school"]."'");
while($rowrole2 = mysqli_fetch_assoc($resultrole2))
{
	$arole2[] = $rowrole2['role'];
	$astudent[] = $rowrole2['teacher'];
}
$arole =  current($arole2);
$student =  current($astudent);
echo '<br><br>';

echo '<div class="form" style="z-index: -1;">';
echo '<br><br>';
echo '<h5>GET STUDENT\'S SCORES</h5>';
echo '<form name="registration" action="getresultmid.php" method="post">';
if($arole == 'student'){
	echo '<select style="width: 210px; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="student_name" id="student_name" required >';
								echo '<option value="'.$student.'">';
								echo $student;
								echo '</option>';
    echo '</select>';
}else{
	echo '<select style="width: 210px; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="student_name" id="student_name" required >';
	$resultst = mysqli_query($db, "SELECT DISTINCT(student_name) FROM scores WHERE school='".$_SESSION["school"]."' ORDER BY student_name ASC");
	while($rowst = mysqli_fetch_assoc($resultst))
							{  
								echo '<option value="'.$rowst['student_name'].'">';
								echo $rowst['student_name'];
								echo '</option>';
							}
    echo '</select>';
}
//	include "connection.php";
	echo '<select data-j="cn" style="width: 210px; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="class_name" id="class_name" required >';
	include "connection.php";
	$cccc = 0;
	$cccc2 = 0;			
	$result = mysqli_query($db, "SELECT * FROM classes");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option>';
								if($ctype=="Js"){
								if($cccc == 0){	
									$cccc++;
									echo 'SELECT A CLASS';
									continue;
									}		
								if($cccc <= 3){
								echo 'JS'.$cccc;	
								}
								elseif($cccc >= 4 && $cccc <= 6){
									if($cccc == 4){	
									$cccc++;
									echo 'SS'.($cccc2 - 2);	
									continue;
									}
									if($cccc == 5){	
									$cccc++;
									echo 'SS'.($cccc2 - 1);	
									continue;
									}
									if($cccc == 6){	
									$cccc++;
									echo 'SS'.($cccc2 - 0);	
									continue;
									}
								}else{
									break;
								}
								$cccc++;	
								$cccc2++;
									}
								else{	
								if($ctype=="Primary"){
									if($cccc == 0){	
									$cccc++;
									echo 'SELECT A CLASS';
									continue;
									}
								echo 'Primary '.$cccc;
								if($cccc > 5){
									break;
								}
								$cccc++;	
								}
								else{
								echo 'Year '.$cccc;
								if($cccc > 11){
									break;
								}
								$cccc++;	
								}
								}//end of else
								echo '</option>';
							}
    echo '</select>';
	
echo '<br><span style="color: red;" >By Class Arm</span>&nbsp;&nbsp;<input type="radio" name="byarm" value="no" id="byarmn">&nbsp;&nbsp;No || <input type="radio" name="byarm" value="yes" id="byarmy">&nbsp;&nbsp;Yes<br>';
	
	
	echo '<select style="width: 210px; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="arms" id="armsbyarms" >';
	 $resultarm = mysqli_query($db,"SELECT * FROM school where school='".$_SESSION["school"]."'");
				while($row = mysqli_fetch_assoc($resultarm)){
					$arrr2[] = $row["arms"];
				}
				$a = implode(',',$arrr2);
				$b = explode(',',$a);
				$f = (array_filter($b));
				echo '<option disabled="disabled" selected="selected" value="">Pick An Arm</option>';
						for($i=0; $i<=(count($f)-1); $i++)
							{  
								echo '<option value="'.$f[$i].'">';
								echo $f[$i];
								echo '</option>';
							}
    echo '</select>'; 
	echo '<select style="width: 210px; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="year" id="year" required >';
//	include "connection.php";
echo '<option value="none" disabled="disabled" selected>SESSION COMMENCING</option>';
	$result = mysqli_query($db, "SELECT * FROM years");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['year'].'">';
								echo $row['year'];
								echo '</option>';
							}
    echo '</select>';
	echo '<select style="width: 210px; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="term" id="term" required >';
//	include "connection.php";
	$resulttm = mysqli_query($db, "SELECT * FROM terms");
						while($row = mysqli_fetch_assoc($resulttm))
							{  
								echo '<option value="'.$row['term'].'">';
								echo $row['term'];
								echo '</option>';
							}
    echo '</select>';
echo '<input type="submit" name="halftermsub" id="subform" value="Get Result" />';
echo '</form>';
echo '</div>';

echo "<br>";
echo "<hr>";
echo "<br>";

echo '<div class="form">';
echo '<h5>GET STUDENT\'S TRANSCRIPT</h5>';
echo '<form name="registration" id="transcriptform" action="transtea.php" method="post">';
//include "connection.php";
	$resultst = mysqli_query($db, "SELECT DISTINCT(student_name) FROM scores WHERE school='".$_SESSION["school"]."' ORDER BY student_name ASC");
if($arole == 'student'){
	echo '<select style="width: 210px; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="student_name" id="student_name" required >';
								echo '<option value="'.$student.'">';
								echo $student;
								echo '</option>';
    echo '</select>';
}else{
	echo '<select style="width: 210px; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="student_name" id="student_name" required >';
	while($rowst = mysqli_fetch_assoc($resultst))
							{  
								echo '<option value="'.$rowst['student_name'].'">';
								echo $rowst['student_name'];
								echo '</option>';
							}
    echo '</select>';
}
	echo '<select data-j="cnn" style="width: 210px; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="class_name" id="class_name" required >';
//	include "connection.php";
	$cccc = 1;
	$cccc2 = 1;
	$result = mysqli_query($db, "SELECT * FROM classes");
	echo '<option value="" disabled="disabled" selected="selected" >SELECT A CLASS</option>';					
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option>';
								if($ctype=="Js"){	
								if($cccc <= 3){
								echo 'JS'.$cccc;	
								}
								elseif($cccc >= 4 && $cccc <= 6){
								echo 'SS'.($cccc2 - 3);	
								}else{
									break;
								}
								$cccc++;	
								$cccc2++;
									}
								else{	
								if($ctype=="Primary"){	
								echo 'Primary '.$cccc;
								if($cccc > 5){
									break;
								}
								$cccc++;	
								}
								else{
								echo 'Year '.$cccc;
								if($cccc > 11){
									break;
								}
								$cccc++;	
								}
								}//end of else
								echo '</option>';
							}
    echo '</select>';
	echo '<select style="width: 210px; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="year" id="year" required >';
//	include "connection.php";
echo '<option value="none" disabled="disabled" selected>SESSION COMMENCING</option>';
	$result = mysqli_query($db, "SELECT * FROM years");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['year'].'">';
								echo $row['year'];
								echo '</option>';
							}
    echo '</select>';
echo '<input type="text" style="display:none;" name="teagetresultmid" id="teagetresultmid" value="teagetresultmid" />';    
echo '<input type="submit" name="submit4" id="submit4" value="Get Transcript" />';
//echo '<input type="submit" name="submit44" id="submit44" value="Get Transcript" />';
echo '</form>';
echo '<br>';
echo '</div>';
?>
<?php
include("footer.php");
?>
</body>