<?php
session_start();
include "connection.php";
$id = $_POST['id'];
$numr = $_POST['numr'];
$s1 = $_POST['s1'];
$ss1 = $_POST['ss1'];
$s2 = $_POST['s2'];
$ss2 = $_POST['ss2'];
$s3 = $_POST['s3'];
$ss3 = $_POST['ss3'];
$s4 = $_POST['s4'];
$ss4 = $_POST['ss4'];
$s5 = $_POST['s5'];
$ss5 = $_POST['ss5'];
$s6 = $_POST['s6'];
$ss6 = $_POST['ss6'];
$s7 = $_POST['s7'];
$ss7 = $_POST['ss7'];
$s8 = $_POST['s8'];
$ss8 = $_POST['ss8'];
$s9 = $_POST['s9'];
$ss9 = $_POST['ss9'];
$f1 = $_POST['fir'];
$f2 = $_POST['sec'];
$f3 = $_POST['thir'];
$f4 = $_POST['fou'];
$f5 = $_POST['fiv'];
$f6 = $_POST['six'];
$f7 = $_POST['sev'];
$f8 = $_POST['eig'];
$f9 = $_POST['nin'];
$rangeit = $_POST['rangeit'];
$ssd1 = $ss1 - $s1;
$ssd2 = $ss2 - $s2;
$ssd3 = $ss3 - $s3;
$ssd4 = $ss4 - $s4;
$ssd5 = $ss5 - $s5;
$ssd6 = $ss6 - $s6;
$ssd7 = $ss7 - $s7;
$ssd8 = $ss8 - $s8;
$ssd9 = $ss9 - $s9;

if($rangeit=="grange"){
$query 	= mysqli_query($db,"UPDATE gradeband SET grade='$f1' WHERE score>='$s1' AND score<='$ss1'");
$query2 = mysqli_query($db,"UPDATE gradeband SET grade='$f2' WHERE score>='$s2' AND score<='$ss2'");
$query3 = mysqli_query($db,"UPDATE gradeband SET grade='$f3' WHERE score>='$s3' AND score<='$ss3'");
$query4 = mysqli_query($db,"UPDATE gradeband SET grade='$f4' WHERE score>='$s4' AND score<='$ss4'");
$query5 = mysqli_query($db,"UPDATE gradeband SET grade='$f5' WHERE score>='$s5' AND score<='$ss5'");
$query6 = mysqli_query($db,"UPDATE gradeband SET grade='$f6' WHERE score>='$s6' AND score<='$ss6'");
$query7 = mysqli_query($db,"UPDATE gradeband SET grade='$f7' WHERE score>='$s7' AND score<='$ss7'");
$query8 = mysqli_query($db,"UPDATE gradeband SET grade='$f8' WHERE score>='$s8' AND score<='$ss8'");
$query9 = mysqli_query($db,"UPDATE gradeband SET grade='$f9' WHERE score>='$s9' AND score<='$ss9'");
}else{
	$ssdd1 = $ssd1 + 1;
	$ssdd2 = $ssdd1 + $ssd2 + 1;
	$ssdd3 = $ssd1 + $ssd2 + $ssd3 + 3;
	$ssdd4 = $ssd1 + $ssd2 + $ssd3 + $ssd4 + 4;
	$ssdd5 = $ssd1 + $ssd2 + $ssd3 + $ssd4 + $ssd5 + 5;
	$ssdd6 = $ssd1 + $ssd2 + $ssd3 + $ssd4 + $ssd5 + $ssd6 + 6;
	$ssdd7 = $ssd1 + $ssd2 + $ssd3 + $ssd4 + $ssd5 + $ssd6 + $ssd7 + 7;
	$ssdd8 = $ssd1 + $ssd2 + $ssd3 + $ssd4 + $ssd5 + $ssd6 + $ssd7 + $ssd8 + 8;
	$fss3 = "";
	$fss4 = "";
	$fss5 = "";
	$fss6 = "";
	$fss7 = "";
	$fss8 = "";
	$fss9 = "";
	for($i=0; $i<=$ssd1; $i++){
		$fs = 100 - $i;
		$idd = 1+$i;
	$bq = mysqli_query($db,"UPDATE gradeband SET score='$fs', grade='$f1' WHERE id='$idd'");
	}
	
	$thelastiddd = mysqli_query($db,"SELECT id, score FROM gradeband where id='$ssdd1'");
	while($row = mysqli_fetch_assoc($thelastiddd)){
					$idr2 = $row["id"];
					$scr2 = $row["score"];
				}
				$idr = $idr2+1;
				$scr = $scr2-1;
	for($b=0; $b<=($ssd2); $b++){
		$fs2 = $scr-$b;
		$idd2 = $idr+$b;
		$fss2 .= $fs2."-".$idd2."-".$f2."<br>";
	$bbq = mysqli_query($db,"UPDATE gradeband SET score='$fs2', grade='$f2' WHERE id='$idd2'");
	}
	
	$thelastiddd3 = mysqli_query($db,"SELECT id, score FROM gradeband where id='$ssdd2'");
	while($row = mysqli_fetch_assoc($thelastiddd3)){
					$idr33 = $row["id"];
					$scr33 = $row["score"];
				}
				$idr3 = $idr33+1;
				$scr3 = $scr33-1;
	for($c=0; $c<=($ssd3); $c++){
		$fs3 = $scr3-$c;
		$idd3 = $idr3+$c;
		$fss3 .= $fs3."-".$idd3."-".$f3."<br>";
	$ccq = mysqli_query($db,"UPDATE gradeband SET score='$fs3', grade='$f3' WHERE id='$idd3'");
	}
	
	$thelastiddd4 = mysqli_query($db,"SELECT id, score FROM gradeband where id='$ssdd3'");
	while($row = mysqli_fetch_assoc($thelastiddd4)){
					$idr44 = $row["id"];
					$scr44 = $row["score"];
				}
				$idr4 = $idr44+1;
				$scr4 = $scr44-1;
	for($d=0; $d<=($ssd3); $d++){
		$fs4 = $scr4-$d;
		$idd4 = $idr4+$d;
		$fss4 .= $idd4."-".$fs4."-".$f4."<br>";
	$ddq = mysqli_query($db,"UPDATE gradeband SET score='$fs4', grade='$f4' WHERE id='$idd4'");
	}

	$thelastiddd5 = mysqli_query($db,"SELECT id, score FROM gradeband where id='$ssdd4'");
	while($row = mysqli_fetch_assoc($thelastiddd5)){
					$idr55 = $row["id"];
					$scr55 = $row["score"];
				}
				$idr5 = $idr55+1;
				$scr5 = $scr55-1;
	for($e=0; $e<=($ssd4); $e++){
		$fs5 = $scr5-$e;
		$idd5 = $idr5+$e;
		$fss5 .= $idd5."-".$fs5."-".$f5."<br>";
	$eeq = mysqli_query($db,"UPDATE gradeband SET score='$fs5', grade='$f5' WHERE id='$idd5'");
	}
	
	$thelastiddd6 = mysqli_query($db,"SELECT id, score FROM gradeband where id='$ssdd5'");
	while($row = mysqli_fetch_assoc($thelastiddd6)){
					$idr66 = $row["id"];
					$scr66 = $row["score"];
				}
				$idr6 = $idr66+1;
				$scr6 = $scr66-1;
	for($f=0; $f<=($ssd5); $f++){
		$fs6 = $scr6-$f;
		$idd6 = $idr6+$f;
		$fss6 .= $idd6."-".$fs6."-".$f6."<br>";
	$ffq = mysqli_query($db,"UPDATE gradeband SET score='$fs6', grade='$f6' WHERE id='$idd6'");
	}
	
	$thelastiddd7 = mysqli_query($db,"SELECT id, score FROM gradeband where id='$ssdd6'");
	while($row = mysqli_fetch_assoc($thelastiddd7)){
					$idr77 = $row["id"];
					$scr77 = $row["score"];
				}
				$idr7 = $idr77+1;
				$scr7 = $scr77-1;
	for($g=0; $g<=($ssd6); $g++){
		$fs7 = $scr7-$g;
		$idd7 = $idr7+$g;
		$fss7 .= $idd7."-".$fs7."-".$f7."<br>";
	$ggq = mysqli_query($db,"UPDATE gradeband SET score='$fs7', grade='$f7' WHERE id='$idd7'");
	}
	
	$thelastiddd8 = mysqli_query($db,"SELECT id, score FROM gradeband where id='$ssdd7'");
	while($row = mysqli_fetch_assoc($thelastiddd8)){
					$idr88 = $row["id"];
					$scr88 = $row["score"];
				}
				$idr8 = $idr88+1;
				$scr8 = $scr88-1;
	for($h=0; $h<=($ssd7); $h++){
		$fs8 = $scr8-$h;
		$idd8 = $idr8+$h;
		$fss8 .= $idd8."-".$fs8."-".$f8."<br>";
	$hhq = mysqli_query($db,"UPDATE gradeband SET score='$fs8', grade='$f8' WHERE id='$idd8'");
	}

	$thelastiddd9 = mysqli_query($db,"SELECT id, score FROM gradeband where id='$ssdd8'");
	while($row = mysqli_fetch_assoc($thelastiddd9)){
					$idr99 = $row["id"];
					$scr99 = $row["score"];
				}
				$idr9 = $idr99+1;
				$scr9 = $scr99-1;
	for($i=0; $i<=($ssd8); $i++){
		$fs9 = $scr9-$i;
		$idd9 = $idr9+$i;
		$fss9 .= $idd9."-".$fs9."-".$f9."<br>";
	$iiq = mysqli_query($db,"UPDATE gradeband SET score='$fs9', grade='$f9' WHERE id='$idd9'");
	}
}
if($query){
echo 1;
}
else if($eeq){
	echo 2;
	//echo 2;
	//echo $f6;
	//echo $fss9;
	//echo $ssdd6;
	//echo $idr8."-".$scr8."<br>";
}else{
	echo 0;
}
?>