<?php
include "connection.php";
if (isset($_REQUEST['btn-upload'])) {
$id = $_REQUEST['id'];
$student_name = $_REQUEST['student_name'];
$term = $_REQUEST['term'];
$arms = $_REQUEST['arms'];
$query =("UPDATE studentsbyclass SET
student_name='$student_name', term='$term', arms='$arms' WHERE id='$id'");

if (!mysqli_query ($db,$query) )
			{
			echo '<img src="table/492.png" /> &nbsp;! data not updated';
			echo '<meta content="2;formclasses.php" http-equiv="refresh" />';	
			die (mysqli_error());
			}else{
	
		echo '<img src="table/492.png" /> &nbsp;! data updated successfully';
		echo '<meta content="2;formclasses.php" http-equiv="refresh" />';
			}
}
?>