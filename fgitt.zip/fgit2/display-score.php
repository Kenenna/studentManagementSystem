<?php
	include("check.php");	
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Home</title>
<link rel="stylesheet" href="style.css" type="text/css" />

</head>

<body>
<h1 class="hello">Hello, <em><?php echo $login_user;?>!</em></h1>



<form action="" method="post" enctype="multipart/form-data">
<center>
 <div>
   
	<label><select style="width:15%;" name="class" id="class" required ><br>
                   
                    <?php
	include "connection.php";
	$result = mysqli_query($db, "SELECT * FROM classes");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['class_id'].'">';
								echo $row['class_name'];
								echo '</option>';
							}
						?>
      </select>
	  
	  <br><br>
	  <select style="width:15%;" name="year" id="year" required ><br>
                   
                    <?php
	include "connection.php";
	$result = mysqli_query($db, "SELECT * FROM years");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['year_id'].'">';
								echo $row['year'];
								echo '</option>';
							}
						?>
      </select>
	  
	  
	   <br><br>
	  <select style="width:15%;" name="term" id="term" required ><br>
                   
                    <?php
	include "connection.php";
	$result = mysqli_query($db, "SELECT * FROM terms");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['term_id'].'">';
								echo $row['term'];
								echo '</option>';
							}
						?>
      </select>
	   <br><br>
	  <select style="width:15%;" name="subject" id="subject" required ><br>
                   
                    <?php
	include "connection.php";
	$result = mysqli_query($db, "SELECT * FROM subjects");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['subject_id'].'">';
								echo $row['subject'];
								echo '</option>';
							}
						?>
      </select>
	  </label>
	  
  <label><br><br>
      <input type="submit" class="button" name="btn-upload" value="Submit Form" />
    </label>

  </div>
  </center><BR><BR>
</form><br>



<?php
if(isset($_POST['btn-upload'])){
$class = $_POST['class'];
$year = $_POST['year'];
$term = $_POST['term'];
$subject = $_POST['subject'];
$teacher_id = 1;



echo $class;
echo $year;
echo $term;
echo $subject;
echo $teacher_id;



echo '<div class="container">';
'<div class="main">';
//echo '<form method="POST" action="update_score_exec.php" id="myform">';
echo '<center>';
 echo '<div>';
 echo  '<h1>Collect teacher\'s students :</h1>';
   
echo '<label><span>View Scores</span><br><br>';            
	include "connection.php";
	$result = mysqli_query($db, "SELECT * FROM scores where class_id='$class' AND year_id='$year' AND term_id='$term' AND subject_id='$subject' AND teacher_id='1'");
						echo '<form method="POST" name="form" action="update-score.php">';
						echo '<table><tr><td>Students Names</td><td>Scores</td></tr>';
						while($row = mysqli_fetch_assoc($result))
							{  
							 echo '<input type="hidden" name="score_id[]" id="score_id" value="'.$row['score_id'].'">';
							 echo '<tr><td><input type="text" name="score[]" id="score" value="'.$row['score'].'"></td><td><input type="hidden" name="student_id[]" id="student_id" value="'.$row['student_id'].'" /><input type="text" name="student_name[]" id="student_name" value="'.$row['student_name'].'" /></td></tr>';
							 echo '<input type="hidden" name="class_id[]" id="class_id" value="'.$row['class_id'].'">';
							 echo '<input type="hidden" name="year_id[]" id="year_id" value="'.$row['year_id'].'">';
							 echo '<input type="hidden" name="term_id[]" id="term_id" value="'.$row['term_id'].'">';
							 echo '<input type="hidden" name="subject_id[]" id="subject_id" value="'.$row['subject_id'].'">';
							 echo '<input type="hidden" name="teacher_id[]" id="teacher_id" value="'.$row['teacher_id'].'">';
							 //echo '<input type="text" name="score[]" id="score" />';
							//echo  '<br>';
							
							}
		
	
	 echo '</label>';
	  
  echo '<label><br>';
   echo   '<tr><td></td><td><input type="submit" class="submit_button" name="submit" value="Submit Scores" /></td></tr></table>';
  echo '</label></div></center></form></div>';
echo '<div class="space"></div>';
echo '<div id="flash"></div>';
echo '<div id="show"></div></div><br>';
}

?>




<a href="logout.php" style="font-size:18px">Logout?</a>
</body>
</html>