<?php
include("auth.php"); //include auth.php file on all secure pages
?>
<!DOCTYPE html>

<html class="no-js" lang="en">
<head>
<meta name="viewport" content="width=device-width" />
	<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" href="img/season-change.jpg" type="image/x-icon">
		<title>Dispaly Data</title>
	    
		
		<link href="table/css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
        <link rel="stylesheet" type="text/css" href="table/css/DT_bootstrap.css">
        
   <style>
form {
  background: -webkit-linear-gradient(bottom, #CCCCCC, #EEEEEE 175px);
  background: -moz-linear-gradient(bottom, #CCCCCC, #EEEEEE 175px);
  background: linear-gradient(bottom, #CCCCCC, #EEEEEE 175px);
  margin: auto;
  position: relative;
  width: 50%;
  height: 300px;
  font-family: Tahoma, Geneva, sans-serif;
  font-size: 12px;
  font-style: italic;
  line-height: 24px;
  font-weight: bold;
  color: #09C;
  text-decoration: none;
  border-radius: 10px;
  padding: 10px;
  border: 1px solid #999;
  border: inset 1px solid #333;
  -webkit-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  -moz-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
}


input {
  width: 50%;
  display: block;
  border: 1px solid #999;
  height: 20px;
  -webkit-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  -moz-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
}

select#upload {
  width: 140px;
  height: 30px;
  display: block;
}

.button {
  width: 100px;
  position: absolute;
  right: 20px;
  bottom: 20px;
  background: #09C;
  color: #fff;
  font-family: Tahoma, Geneva, sans-serif;
  height: 30px;
  border-radius: 15px;
  border: 1p solid #999;
}

input.button:hover {
  background: #fff;
  color: #09C;
}

select:focus, input:focus {
  border: 1px solid #09C;
}
</style> 
<script src="table/js/jquery.js" type="text/javascript"></script>
	<script src="table/js/bootstrap.js" type="text/javascript"></script>
	
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/jquery.dataTables.js"></script>
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/DT_bootstrap.js"></script>
 
</head>

<body>
<?php
include "connection.php";
$regstu_id = $_GET['regstu_id'];
$query1 = mysqli_query($db, "select * from regstu where regstu_id=$regstu_id");
while ($row1 = mysqli_fetch_array($query1)) {

echo '<center>';
echo '<form action="updatestudentsclassadmin_exec.php" method="post" enctype="multipart/form-data">';
echo '<div>';
echo '<h1>Edit Student\'s Info :</h1>';
echo '<label>';
echo  '<input id="regstu_id" type="hidden" name="regstu_id" value="'.$row1['regstu_id'].'" />';
echo  '</label>';
echo '<label>';
echo  '<input id="student_name" type="text" name="student_name" value="'.$row1['student_name'].'" />';
 echo '</label>';
 echo '<label>';
echo  '<input id="sex" type="text" name="sex" value="'.$row1['sex'].'" />';
echo '</label>';
 echo '<label>';
echo  '<input id="caa" type="text" name="caa" value="'.$row1['caa'].'" />';
echo '</label>';
 echo '<label>';
echo  '<input id="yoa" type="text" name="yoa" value="'.$row1['yoa'].'" />';
echo '</label>';
 echo '<label>';
echo  '<input id="admno" type="text" name="admno" value="'.$row1['admno'].'" />';
echo '</label>';
 echo '<label>';
echo  '<input id="reason" type="text" name="reason" value="'.$row1['reason'].'" />';
echo '</label>';
 echo   '<input type="submit" class="button" name="btn-upload" value="Submit Form" />';
  echo  '</label>';
echo '</div>';
echo '</form><br>';
}
echo '</center>';
?>

</body>
</html>