<?php 
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>House Students</title>
<link rel="stylesheet" href="style.css" type="text/css" />
<script src="table/js/jquery.js" type="text/javascript"></script>
  
  
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>
<script>
		$(document).ready(function() {	
		$("#formid").submit(function( event ) {
			event.preventDefault();	
$.ajax({
type: "POST",
url: "addhpcomment_exec.php",
data: $("#formid").serializeArray(),	
success: function(response){
 if(response==1) { 
		event.preventDefault();
		$(".success").fadeIn();
		setTimeout(function() { $(".success").fadeOut(); }, 2000);
		$("#backtogetclass").fadeIn();	
    } else {
		 $(".error").show();
		setTimeout(function() { $(".error").fadeOut(); }, 2000);
		$("#backtogetclass").fadeIn();
		}
		}
});	
});	 
});
</script>

<style>
	/* info (hed, dek, source, credit) */
.rg-container {
	font-family: 'Lato', Helvetica, Arial, sans-serif;
	font-size: 16px;
	line-height: 1.4;
	margin: 0;
	padding: 1em 0.5em;
	color: #222;
}
.rg-header {
	margin-bottom: 1em;
	text-align: left;
}

.rg-header > * {
	display: block;
}
.rg-hed {
	font-weight: bold;
	font-size: 1.4em;
}
.rg-dek {
	font-size: 1em;
}

.rg-source {
	margin: 0;
	font-size: 0.75em;
	text-align: right;
}
.rg-source .pre-colon {
	text-transform: uppercase;
}

.rg-source .post-colon {
	font-weight: bold;
}

/* table */
table.rg-table {
	width: 100%;
	margin-bottom: 0.5em;
	font-size: 1em;
	border-collapse: collapse;
	border-spacing: 0;
}
table.rg-table tr {
	-moz-box-sizing: border-box;
	box-sizing: border-box;
	margin: 0;
	padding: 0;
	border: 0;
	font-size: 100%;
	font: inherit;
	vertical-align: baseline;
	text-align: left;
	color: #333;
}
table.rg-table thead {
	border-bottom: 3px solid #ddd;
}
table.rg-table tr {
	border-bottom: 1px solid #ddd;
	color: red;
}
table.rg-table tr.highlight {
	background-color: white;
}
table.rg-table.zebra tr:nth-child(even) {
	background-color: #f6f6f6;
}
table.rg-table th {
	font-weight: bold;
	padding: 0.35em;
	font-size: 0.9em;
}
table.rg-table td {
	padding: 0.35em;
	font-size: 0.9em;
}
table.rg-table .highlight td {
	font-weight: bold;
}
table.rg-table th.number, td.number {
	text-align: right;
}

/* media queries */
@media screen and (max-width: 600px) {
.rg-container {
	max-width: 600px;
	margin: 0 auto;
}
table.rg-table {
	width: 100%;
}
table.rg-table tr.hide-mobile, table.rg-table th.hide-mobile, table.rg-table td.hide-mobile {
	display: none;
}
table.rg-table thead {
	display: none;
}
table.rg-table tbody {
	width: 100%;
}
table.rg-table tr, table.rg-table th, table.rg-table td {
	display: block;
	padding: 0;
}
table.rg-table tr {
	border-bottom: none;
	margin: 0 0 1em 0;
	padding: 0.5em;
}
table.rg-table tr.highlight {
	background-color: inherit !important;
}
table.rg-table.zebra tr:nth-child(even) {
	background-color: none;
}
table.rg-table.zebra td:nth-child(even) {
	background-color: #f6f6f6;
}
table.rg-table tr:nth-child(even) {
	background-color: none;
}
table.rg-table td {
	padding: 0.5em 0 0.25em 0;
	border-bottom: 1px dotted #ccc;
	text-align: right;
}
table.rg-table td[data-title]:before {
	content: attr(data-title);
	font-weight: bold;
	display: inline-block;
	content: attr(data-title);
	float: left;
	margin-right: 0.5em;
	font-size: 0.95em;
}
table.rg-table td:last-child {
	padding-right: 0;
	border-bottom: 2px solid #ccc;
}
table.rg-table td:empty {
	display: none;
}
table.rg-table .highlight td {
	background-color: inherit;
	font-weight: normal;
}
}
.pbutton {
	background-color:#44c767;
	-moz-border-radius:28px;
	-webkit-border-radius:28px;
	border-radius:12px;
	border:1px solid #18ab29;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:15px;
	padding:6px 24px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
	margin: auto;
}
.pbutton:hover {
	background-color:#5cbf2a;
}
.pbutton:active {
	position:relative;
	top:1px;
}
</style>
<style>
ul.topnav {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}
ul.topnav li {float: left;}
ul.topnav li a {
    display: inline-block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    transition: 0.3s;
    font-size: 17px;
}
ul.topnav li a:hover {background-color: #555;}
ul.topnav li.icon {display: none;}

@media screen and (max-width:680px) {
  ul.topnav li:not(:first-child) {display: none;}
  ul.topnav li.icon {
    float: right;
    display: inline-block;
  }
}
@media screen and (max-width:680px) {
  ul.topnav.responsive {position: relative;}
  ul.topnav.responsive li.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  ul.topnav.responsive li {
    float: none;
    display: inline;
  }
  ul.topnav.responsive li a {
    display: block;
    text-align: left;
  }
}
#rg{
    text-align: center;
}
</style>

 <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
</head>

<body>
<?php
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'principal'){
echo '<ul class="topnav" id="myTopnav">';
echo '<li><a href="admgetresult.php">Student\'s Result</a></li>';
echo '<li><a href="admviewtea.php">View Teachers</a></li>';
echo '<li><a href="admviewtutor.php">View Tutors</a></li>';
echo '<li><a href="admviewhp.php">View House Parent</a></li>';
echo '<li><a href="viewmaxatt.php">View Max Attendance</a></li>';
echo '<li><a href="newpass.php">Change Pass</a></li>';
if($_SESSION['adminlevel']==4){
echo '<li><a href="manageadmins.php">Admins</a></li>';
}
echo '<li><a href="chooseschool.php">School</a></li>';
echo '<li><a href="princicomments.php">Principal\'s Comments</a></li>';
echo '<li><a href="logout.php">Logout</a></li>';
echo '<li class="icon">';
echo '<a href="javascript:void(0);" onclick="myFunction()">&#9776;</a>';
echo '</li>';
echo '</ul>';
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
else{header("location: logout.php");}
?>
<?php
$user=$_SESSION['username'];
?>

<?php
if(isset($_POST["subbtn-upload"])){
$year = $_POST['subyear'];
$teacher_name = $_POST['subteacher_name'];
$house = $_POST['subhouse'];
$classd = $_POST['subclass_name'];
if($classd=='Primary 1'){
		$class = 'Year 1';
	}
	elseif($classd=='Primary 2'){
		$class = 'Year 2';
	}
	elseif($classd=='Primary 3'){
		$class = 'Year 3';
	}
	elseif($classd=='Primary 4'){
		$class = 'Year 4';
	}
	elseif($classd=='Primary 5'){
		$class = 'Year 5';
	}	
	elseif($classd=='Primary 6'){
		$class = 'Year 6';
	}
	elseif($classd=='JS1'){
		$class = 'Year 7';
	}
	elseif($classd=='JS2'){
		$class = 'Year 8';
	}
	elseif($classd=='JS3'){
		$class = 'Year 9';
	}
	elseif($classd=='SS1'){
		$class = 'Year 10';
	}
	elseif($classd=='SS2'){
		$class = 'Year 11';
	}	
	elseif($classd=='SS3'){
		$class = 'Year 12';
	}		
	else{
		$class = $classd;
	}
//echo $year."-".$teacher_name."-".$house."-".$class;
}else{
$year = $_POST['year'];
$teacher_name = $_POST['teacher_name'];
$house = $_POST['house'];
$classd = $_POST['class_name'];
if($classd=='Primary 1'){
		$class = 'Year 1';
	}
	elseif($classd=='Primary 2'){
		$class = 'Year 2';
	}
	elseif($classd=='Primary 3'){
		$class = 'Year 3';
	}
	elseif($classd=='Primary 4'){
		$class = 'Year 4';
	}
	elseif($classd=='Primary 5'){
		$class = 'Year 5';
	}	
	elseif($classd=='Primary 6'){
		$class = 'Year 6';
	}
	elseif($classd=='JS1'){
		$class = 'Year 7';
	}
	elseif($classd=='JS2'){
		$class = 'Year 8';
	}
	elseif($classd=='JS3'){
		$class = 'Year 9';
	}
	elseif($classd=='SS1'){
		$class = 'Year 10';
	}
	elseif($classd=='SS2'){
		$class = 'Year 11';
	}	
	elseif($classd=='SS3'){
		$class = 'Year 12';
	}		
	else{
		$class = $classd;
	}
}

$checkft = mysqli_query($db, "SELECT DISTINCT(teacher_name) FROM houseparent where year='$year' AND house='$house' AND school='".$_SESSION["school"]."'");	
$checkst = mysqli_query($db, "SELECT DISTINCT(teacher_name) FROM subhouseparent where year='$year' AND house='$house' AND school='".$_SESSION["school"]."'");
	while($rowft = mysqli_fetch_assoc($checkft))
							{  
								$rft2[] = $rowft['teacher_name'];
							}
							$rft = current($rft2);
$checkstcount = mysqli_num_rows($checkst);


$result = mysqli_query($db, "SELECT * FROM studentsbyclass where year='$year' AND class='$class' AND house='$house' AND school='".$_SESSION["school"]."' ORDER BY student_name ASC");
echo "<div class='rg-container'>";
echo "<div class='rg-content'>";

if($rft==$teacher_name){
    echo "<br><br><br><span style='color: red; text-align: center; font-weight: bold;'>House Parent's Comment</span>";
echo "<table class='rg-table zebra' id='rg' summary='Hed'>";
echo "<caption class='rg-header'>";
//echo "<span class='rg-hed'>Hed</span>";
echo "</caption>";
echo "<thead>";
echo "<tr>";
echo "<th class='text' style='display: none;'>id</th>";
echo "<th class='text' >Student Name</th>";
echo "<th class='text' style='display: none;'>House Parent Name</th>";
echo "<th class='text' style='display: none;'>Class</th>";
echo "<th class='text' >Session Commencing</th>";
echo "<th class='text' >Term</th>";
echo "<th class='text' style='display: none;'>House</th>";
echo "<th class='text' >Comment</th>";
echo "</tr>";
echo "</thead>";
echo "<tbody>";
echo '<form id="formid" >';
$counters = 2;
while($rowtid = mysqli_fetch_assoc($result))
{
	if($counters%2==0){
echo "<tr style='color: red;'>";
echo '<td class="text" style="display: none;" data-title="id" ><input name="id[]" value="'.$rowtid['id'].'" /></td>';
echo '<td class="text" data-title="Name"><input type="text" style="display: none;" name="student_name[]" value="'.$rowtid['student_name'].'" />'.$rowtid['student_name'].'</td>';
echo '<td class="text" style="display: none;" data-title="houseparent" ><input name="houseparent" value="'.$teacher_name.'" /></td>';
echo '<td class="text" style="display: none;" data-title="class" ><input name="class" value="'.$rowtid['class'].'" /></td>';
echo '<td class="text" data-title="year" ><input style="display: none;" name="year" value="'.$rowtid['year'].'" />'.$rowtid['year'].'</td>';
echo '<td class="text" data-title="term"  ><input style="display: none;" name="term" value="'.$rowtid['term'].'" />'.$rowtid['term'].'</td>';
echo '<td class="text" style="display: none;" data-title="house" ><input name="house" value="'.$rowtid['house'].'" /></td>';
echo '<td style="height: 70px;" class="text" data-title="hpcomment"  ><textarea style="width: 100%; height: 100%;" name="hpcomment[]" value="'.$rowtid['hpcomment'].'" />'.$rowtid['hpcomment'].'</textarea></td>';
echo "</tr>";
}else{
echo "<tr style='color: blue;'>";
echo '<td class="text" style="display: none;" data-title="id" ><input name="id[]" value="'.$rowtid['id'].'" /></td>';
echo '<td class="text" data-title="Name"><input type="text" style="display: none;" name="student_name[]" value="'.$rowtid['student_name'].'" />'.$rowtid['student_name'].'</td>';
echo '<td class="text" style="display: none;" data-title="houseparent" ><input name="houseparent" value="'.$teacher_name.'" /></td>';
echo '<td class="text" style="display: none;" data-title="class" ><input name="class" value="'.$rowtid['class'].'" /></td>';
echo '<td class="text" data-title="year" ><input style="display: none;" name="year" value="'.$rowtid['year'].'" />'.$rowtid['year'].'</td>';
echo '<td class="text" data-title="term"  ><input style="display: none;" name="term" value="'.$rowtid['term'].'" />'.$rowtid['term'].'</td>';
echo '<td class="text" style="display: none;" data-title="house" ><input name="house" value="'.$rowtid['house'].'" /></td>';
echo '<td style="height: 70px;" class="text" data-title="hpcomment"  ><textarea style="width: 100%; height: 100%;" name="hpcomment[]" value="'.$rowtid['hpcomment'].'" />'.$rowtid['hpcomment'].'</textarea></td>';
echo "</tr>";
}}
echo "<tr class=''>";
echo '<td class="text" data-title="submit" colspan="4"><input style="background-color: green; color: white; width: 100px;" type="submit" name="submit" value="Submit" /></td>';
echo "</tr>";
echo '</form>';
echo "</tbody>";
echo "</table>";
}
elseif($checkstcount>0){
echo "<table class='rg-table zebra' id='rg' summary='Hed'>";
echo "<caption class='rg-header'>";
//echo "<span class='rg-hed'>Hed</span>";
echo "</caption>";
echo "<thead>";
echo "<tr>";
echo "<th class='text' style='display: none;'>id</th>";
echo "<th class='text' >Student Name</th>";
echo "<th class='text' style='display: none;'>House Parent Name</th>";
echo "<th class='text' style='display: none;'>Class</th>";
echo "<th class='text' >Session Commencing</th>";
echo "<th class='text' >Term</th>";
echo "<th class='text' style='display: none;'>House</th>";
echo "<th class='text' >Comment</th>";
echo "</tr>";
echo "</thead>";
echo "<tbody>";
echo '<form id="formid" >';
$counters = 2;
while($rowtid = mysqli_fetch_assoc($result))
{
	if($counters%2==0){
echo "<tr style='color: red;'>";
echo '<td class="text" style="display: none;" data-title="id" ><input name="id[]" value="'.$rowtid['id'].'" /></td>';
echo '<td class="text" data-title="Name"><input type="text" style="display: none;" name="student_name[]" value="'.$rowtid['student_name'].'" />'.$rowtid['student_name'].'</td>';
echo '<td class="text" style="display: none;" data-title="houseparent" ><input name="houseparent" value="'.$teacher_name.'" /></td>';
echo '<td class="text" style="display: none;" data-title="class" ><input name="class" value="'.$rowtid['class'].'" /></td>';
echo '<td class="text" data-title="year" ><input style="display: none;" name="year" value="'.$rowtid['year'].'" />'.$rowtid['year'].'</td>';
echo '<td class="text" data-title="term"  ><input style="display: none;" name="term" value="'.$rowtid['term'].'" />'.$rowtid['term'].'</td>';
echo '<td class="text" style="display: none;" data-title="house" ><input name="house" value="'.$rowtid['house'].'" /></td>';
echo '<td style="height: 70px;" class="text" data-title="hpcomment"  ><textarea style="width: 100%; height: 100%;" name="hpcomment[]" value="'.$rowtid['hpcomment'].'" />'.$rowtid['hpcomment'].'</textarea></td>';
echo "</tr>";
}else{
echo "<tr style='color: blue;'>";
echo '<td class="text" style="display: none;" data-title="id" ><input name="id[]" value="'.$rowtid['id'].'" /></td>';
echo '<td class="text" data-title="Name"><input type="text" style="display: none;" name="student_name[]" value="'.$rowtid['student_name'].'" />'.$rowtid['student_name'].'</td>';
echo '<td class="text" style="display: none;" data-title="houseparent" ><input name="houseparent" value="'.$teacher_name.'" /></td>';
echo '<td class="text" style="display: none;" data-title="class" ><input name="class" value="'.$rowtid['class'].'" /></td>';
echo '<td class="text" data-title="year" ><input style="display: none;" name="year" value="'.$rowtid['year'].'" />'.$rowtid['year'].'</td>';
echo '<td class="text" data-title="term"  ><input style="display: none;" name="term" value="'.$rowtid['term'].'" />'.$rowtid['term'].'</td>';
echo '<td class="text" style="display: none;" data-title="house" ><input name="house" value="'.$rowtid['house'].'" /></td>';
echo '<td style="height: 70px;" class="text" data-title="hpcomment"  ><textarea style="width: 100%; height: 100%;" name="hpcomment[]" value="'.$rowtid['hpcomment'].'" />'.$rowtid['hpcomment'].'</textarea></td>';
echo "</tr>";
}}
echo "<tr class=''>";
echo '<td class="text" data-title="submit" colspan="4"><input style="background-color: green; color: white; width: 100px;" type="submit" name="submit" value="Submit" /></td>';
echo "</tr>";
echo '</form>';
echo "</tbody>";
echo "</table>";
}else{
    echo 'You are not enrolled as '.$house.' house parent for session commencing in '.$year;
    	echo '<meta content="2;housestudents.php" http-equiv="refresh" />';
}

echo '<div class="error" style="display:none; color: red;"><img src="table/del.jpg" width="60" height="60"/>An update error has just occurred.</div><div class="success" style="display:none; color: green;"><img src="table/492.png" width="60" height="60"/> Comments added successfully.</div>';


echo '<a class="pbutton" href="housestudents.php" id="backtogetclass" >Back</a>';
echo "</div>";
echo "</div>";
?>

<?php
include("footer.php");

?>
</body>
</html>