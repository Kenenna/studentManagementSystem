<?php
session_start();
include("auth.php");
include "connection.php";
$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);

require 'class/ChartJS.php';
require 'class/ChartJS_Line.php';
require 'class/ChartJS_Bar.php';
require 'class/ChartJS_Radar.php';
require 'class/ChartJS_PolarArea.php';
require 'class/ChartJS_Pie.php';
require 'class/ChartJS_Doughnut.php';

$su1 = $_POST['arrsubj'];
$su = unserialize(base64_decode($su1));
$cwork1 = $_POST['cwork'];
$cwork = unserialize(base64_decode($cwork1));
$hwork1 = $_POST['hwork'];
$hwork = unserialize(base64_decode($hwork1));
$test1 = $_POST['test'];
$test = unserialize(base64_decode($test1));
$score1 = $_POST['score'];
$score = unserialize(base64_decode($score1));
$ccav1 = $_POST['ccav'];
$ccav = unserialize(base64_decode($ccav1));
$grade1 = $_POST['grade'];
$grade = unserialize(base64_decode($grade1));
$tn1 = $_POST['tn'];
$tn = unserialize(base64_decode($tn1));
$re1 = $_POST['remark'];
$re = unserialize(base64_decode($re1));
$student_name = $_POST['student_name'];
$class_name = $_POST['class_name'];
$year = $_POST['year'];
$term = $_POST['term'];
$arms = $_POST['arms'];
$byarm = $_POST['byarm'];
ChartJS::addDefaultColor(array('fill' => 'purple', 'stroke' => '#e5801d', 'point' => '#e5801d', 'pointStroke' => '#e5801d'));
ChartJS::addDefaultColor(array('fill' => 'green', 'stroke' => '#1c74be', 'point' => '#1c74be', 'pointStroke' => '#1c74be'));
ChartJS::addDefaultColor(array('fill' => 'red', 'stroke' => '#d4291f', 'point' => '#d4291f', 'pointStroke' => '#d4291f'));
ChartJS::addDefaultColor(array('fill' => 'orange', 'stroke' => '#d4222f', 'point' => '#d4222f', 'pointStroke' => '#d4222f'));
ChartJS::addDefaultColor(array('fill' => 'blue', 'stroke' => '#ff0000', 'point' => '#ff0000', 'pointStroke' => '#ff0000'));
ChartJS::addDefaultColor(array('fill' => 'pink', 'stroke' => '#2ecc71', 'point' => '#2ecc71', 'pointStroke' => '#2ecc71'));

$array_labels = $su;
$subjcount = count($su);

//print_r($array_values[1]); // sec eng and sec maths
for($i=0; $i<=(count($cwork)-1); $i++){
	if($cwork[$i]==""){
		$cwork[$i] = 0;
	}
	$ccc[] = $cwork[$i]; //$ccc is for cwork
}
	$cc = $ccc;
for($i=0; $i<=(count($hwork)-1); $i++){
	if($hwork[$i]==""){
		$hwork[$i] = 0;
	}
	$ddd[] = $hwork[$i]; //$ddd is for hwork
}
	$dd = $ddd; 
for($i=0; $i<=(count($test)-1); $i++){
	if($test[$i]==""){
		$test[$i] = 0;
	}
	$eee[] = $test[$i]; //$ddd is for hwork
}
	$ee = $eee; 	
for($i=0; $i<=(count($score)-1); $i++){
	if($score[$i]==""){
		$score[$i] = 0;
	}
	$fff[] = $score[$i];
}
	$ff = $fff;	
for($i=0; $i<=(count($ccav)-1); $i++){
	if($ccav[$i]==""){
		$ccav[$i] = 0;
	}
	$cccav[] = $ccav[$i];
}
	$ccav = $cccav;	
$array_values = array($cc, $dd, $ee, $ff, $ccav);	

$Bar = new ChartJS_Bar('example_bar', 1100, 500);
$Bar->addBars($array_values[0]);
$Bar->addBars($array_values[1]);
$Bar->addBars($array_values[2]);
$Bar->addBars($array_values[3]);
$Bar->addBars($array_values[4]);
$Bar->addLabels($array_labels);

?>
<!DOCTYPE html>
<html>
<head>
    <title>Performance Chart</title>
	<style>
ul.topnav {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}
ul.topnav li {float: left;}
ul.topnav li a {
    display: inline-block;
    color: #f2f2f2;
    text-align: center;
    padding: 12px 14px;
    text-decoration: none;
    transition: 0.3s;
    font-size: 14px;
}
ul.topnav li a:hover {background-color: #555;}
ul.topnav li.icon {display: none;}

@media screen and (max-width:680px) {
  ul.topnav li:not(:first-child) {display: none;}
  ul.topnav li.icon {
    float: right;
    display: inline-block;
  }
}
@media screen and (max-width:680px) {
  ul.topnav.responsive {position: relative;}
  ul.topnav.responsive li.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  ul.topnav.responsive li {
    float: none;
    display: inline;
  }
  ul.topnav.responsive li a {
    display: block;
    text-align: left;
  }
}
</style>
	<style>
.pbutton {
	background-color:#44c767;
	-moz-border-radius:28px;
	-webkit-border-radius:28px;
	border-radius:5px;
	border:1px solid #18ab29;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:15px;
	padding:6px 24px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
	float: left;
}
.pbutton:hover {
	background-color:#5cbf2a;
}
.pbutton:active {
	position:relative;
	top:1px;
}
</style>
  
   <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>
<!--<link rel="stylesheet" href="css/styles.css">-->
  <!--<script src="js/scriptmenu.js"></script>-->
<script src="Chart.js"></script>
<script src="chart.js-php.js"></script>

 <script src="gr2/js/jquery.js"></script>
    <script src="gr2/js/highchart.js"></script>
    <script src="gr2/js/exporting.js"></script>
    <script src="gr2/js/jspdf.js"></script>
    <script src="gr2/js/rgbcolor.js"></script>
    <script src="gr2/js/canvg.js"></script>

 <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
</head>
<body>
<?php
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
elseif($_SESSION['role'] == 'student'){
include("headerstudent.php");
}
else{header("location: logout.php");}
?>
<br>
<div id="printMe"><br>
<h6><table style="width: 50%;">
<tr>
<td colspan="3" style="text-align: center;">
<?php
if($class_name=="Year 1"){
		if($ctype=="Primary"){
		$classs = "Primary 1";
	}else{
		$classs = "Year 1";
}}
if($class_name=="Year 2"){
		if($ctype=="Primary"){
		$classs = "Primary 2";
	}else{
		$classs = "Year 2";
}}
if($class_name=="Year 3"){
		if($ctype=="Primary"){
		$classs = "Primary 3";
	}else{
		$classs = "Year 3";
}}
if($class_name=="Year 4"){
		if($ctype=="Primary"){
		$classs = "Primary 4";
	}else{
		$classs = "Year 4";
}}
if($class_name=="Year 5"){
		if($ctype=="Primary"){
		$classs = "Primary 5";
	}else{
		$classs = "Year 5";
}}
if($class_name=="Year 6"){
		if($ctype=="Primary"){
		$classs = "Primary 6";
	}else{
		$classs = "Year 6";
}}
if($class_name=="Year 7"){
		if($ctype=="Js"){
		$classs = "JS1";
	}else{
		$classs = "Year 7";
}}
if($class_name=="Year 8"){
		if($ctype=="Js"){
		$classs = "JS2";
	}else{
		$classs = "Year 8";
}}
if($class_name=="Year 9"){
		if($ctype=="Js"){
		$classs = "JS3";
	}else{
		$classs = "Year 9";
}}
if($class_name=="Year 10"){
		if($ctype=="Js"){
		$classs = "SS1";
	}else{
		$classs = "Year 10";
}}
if($class_name=="Year 11"){
		if($ctype=="Js"){
		$classs = "SS2";
	}else{
		$classs = "Year 11";
}}
if($class_name=="Year 12"){
		if($ctype=="Js"){
		$classs = "SS3";
	}else{
		$classs = "Year 12";
}}
?>
<?php
$carm = "";
$arms = $_POST['arms'];
$byarm = $_POST['byarm'];
//echo $arms;
if($byarm=="yes"){
$carm .= strtoupper($classs);
$carm .= " ";
$carm .= strtoupper($arms);
}else{
$carm = strtoupper($classs);
}
echo "A CHART OF ".strtoupper($student_name). "'S PERFORMANCE IN ".strtoupper($term)." OF ".strtoupper($year)." IN ".$carm." ACROSS SUBJECTS.";
?>
</td></tr>
<tr>
<td style="background-color: purple; color: white; text-align: center;">Classwork (30)</td><td style="background-color: green; color: white; text-align: center;">Homework (30)</td>
<td style="background-color: red; color: white; text-align: center;">Test (40)</td>
<td style="background-color: orange; color: white; text-align: center;">Total (100)</td>
<td style="background-color: blue; color: white; text-align: center;">Class Av. (100)</td>
</tr></table></h6>
<?php
echo $Bar
?>
<script>
    (function () {
        loadChartJsPhp();
    })();
</script>
</div>

<?php		
$stuname = $student_name;

$subjcount = count($su);
//echo $subjcount;
if($subjcount == 1){
	if($cc[0]==""){
		$cc[0] = 0;
	}
	if($dd[0]==""){
		$dd[0] = 0;
	}
	if($ee[0]==""){
		$av[0] = 0;
	}
	if($ff[0]==""){
		$ff[0] = 0;
	}
	if($ccav[0]==""){
		$ccav[0] = 0;
	}
$sub1 = array($cc[0],$dd[0],$av[0],$ccav[0]);
}elseif($subjcount == 2){
	if($cc[0]==""){
		$cc[0] = 0;
	}
	if($dd[0]==""){
		$dd[0] = 0;
	}
	if($ee[0]==""){
		$ee[0] = 0;
	}
	if($ff[0]==""){
		$ff[0] = 0;
	}
	if($ccav[0]==""){
		$ccav[0] = 0;
	}
	if($cc[1]==""){
		$cc[1] = 0;
	}
	if($dd[1]==""){
		$dd[1] = 0;
	}
	if($ee[1]==""){
		$ee[1] = 0;
	}
	if($ff[1]==""){
		$ff[1] = 0;
	}
	if($ccav[1]==""){
		$ccav[1] = 0;
	}
$sub1 = array($cc[0],$dd[0],$ee[0],$ff[0],$ccav[0]);
$sub2 = array($cc[1],$dd[1],$ee[1],$ff[1],$ccav[1]);
}elseif($subjcount == 3){
	if($cc[0]==""){
		$cc[0] = 0;
	}
	if($dd[0]==""){
		$dd[0] = 0;
	}
	if($ee[0]==""){
		$ee[0] = 0;
	}
	if($ff[0]==""){
		$ff[0] = 0;
	}
	if($ccav[0]==""){
		$ccav[0] = 0;
	}
	if($cc[1]==""){
		$cc[1] = 0;
	}
	if($dd[1]==""){
		$dd[1] = 0;
	}
	if($ee[1]==""){
		$ee[1] = 0;
	}
	if($ff[1]==""){
		$ff[1] = 0;
	}
	if($ccav[1]==""){
		$ccav[1] = 0;
	}
	if($cc[2]==""){
		$cc[2] = 0;
	}
	if($dd[2]==""){
		$dd[2] = 0;
	}
	if($ee[2]==""){
		$ee[2] = 0;
	}
	if($ff[2]==""){
		$ff[2] = 0;
	}
	if($ccav[2]==""){
		$ccav[2] = 0;
	}
$sub1 = array($cc[0],$dd[0],$ee[0],$ff[0],$ccav[0]);
$sub2 = array($cc[1],$dd[1],$ee[1],$ff[1],$ccav[1]);
$sub3 = array($cc[2],$dd[2],$ee[2],$ff[2],$ccav[2]);
}elseif($subjcount == 4){
		if($cc[0]==""){
		$cc[0] = 0;
	}
	if($dd[0]==""){
		$dd[0] = 0;
	}
	if($ee[0]==""){
		$ee[0] = 0;
	}
	if($ff[0]==""){
		$ff[0] = 0;
	}
	if($ccav[0]==""){
		$ccav[0] = 0;
	}
	if($cc[1]==""){
		$cc[1] = 0;
	}
	if($dd[1]==""){
		$dd[1] = 0;
	}
	if($ee[1]==""){
		$ee[1] = 0;
	}
	if($ff[1]==""){
		$ff[1] = 0;
	}
	if($ccav[1]==""){
		$ccav[1] = 0;
	}
	if($cc[2]==""){
		$cc[2] = 0;
	}
	if($dd[2]==""){
		$dd[2] = 0;
	}
	if($ee[2]==""){
		$ee[2] = 0;
	}
	if($ff[2]==""){
		$ff[2] = 0;
	}
	if($ccav[2]==""){
		$ccav[2] = 0;
	}
	if($cc[3]==""){
		$cc[3] = 0;
	}
	if($dd[3]==""){
		$dd[3] = 0;
	}
	if($ee[3]==""){
		$ee[3] = 0;
	}
	if($ff[3]==""){
		$ff[3] = 0;
	}
	if($ccav[3]==""){
		$ccav[3] = 0;
	}
$sub1 = array($cc[0],$dd[0],$ee[0],$ff[0],$ccav[0]);		
$sub2 = array($cc[1],$dd[1],$ee[1],$ff[1],$ccav[1]);
$sub3 = array($cc[2],$dd[2],$ee[2],$ff[2],$ccav[2]);
$sub4 = array($cc[3],$dd[3],$ee[3],$ff[3],$ccav[3]);	
}elseif($subjcount == 5){
		if($cc[0]==""){
		$cc[0] = 0;
	}
	if($dd[0]==""){
		$dd[0] = 0;
	}
	if($ee[0]==""){
		$ee[0] = 0;
	}
	if($ff[0]==""){
		$ff[0] = 0;
	}
	if($ccav[0]==""){
		$ccav[0] = 0;
	}
	if($cc[1]==""){
		$cc[1] = 0;
	}
	if($dd[1]==""){
		$dd[1] = 0;
	}
	if($ee[1]==""){
		$ee[1] = 0;
	}
	if($ff[1]==""){
		$ff[1] = 0;
	}
	if($ccav[1]==""){
		$ccav[1] = 0;
	}
	if($cc[2]==""){
		$cc[2] = 0;
	}
	if($dd[2]==""){
		$dd[2] = 0;
	}
	if($ee[2]==""){
		$ee[2] = 0;
	}
	if($ff[2]==""){
		$ff[2] = 0;
	}
	if($ccav[2]==""){
		$ccav[2] = 0;
	}
	if($cc[3]==""){
		$cc[3] = 0;
	}
	if($dd[3]==""){
		$dd[3] = 0;
	}
	if($ee[3]==""){
		$ee[3] = 0;
	}
	if($ff[3]==""){
		$ff[3] = 0;
	}
	if($ccav[3]==""){
		$ccav[3] = 0;
	}
	if($cc[4]==""){
		$cc[4] = 0;
	}
	if($dd[4]==""){
		$dd[4] = 0;
	}
	if($ee[4]==""){
		$ee[4] = 0;
	}
	if($ff[4]==""){
		$ff[4] = 0;
	}
	if($ccav[4]==""){
		$ccav[4] = 0;
	}
$sub1 = array($cc[0],$dd[0],$ee[0],$ff[0],$ccav[0]);		
$sub2 = array($cc[1],$dd[1],$ee[1],$ff[1],$ccav[1]);
$sub3 = array($cc[2],$dd[2],$ee[2],$ff[2],$ccav[2]);
$sub4 = array($cc[3],$dd[3],$ee[3],$ff[3],$ccav[3]);
$sub5 = array($cc[4],$dd[4],$ee[4],$ff[4],$ccav[4]);
}elseif($subjcount == 6){
		if($cc[0]==""){
		$cc[0] = 0;
	}
	if($dd[0]==""){
		$dd[0] = 0;
	}
	if($ee[0]==""){
		$ee[0] = 0;
	}
	if($ff[0]==""){
		$ff[0] = 0;
	}
	if($ccav[0]==""){
		$ccav[0] = 0;
	}
	if($cc[1]==""){
		$cc[1] = 0;
	}
	if($dd[1]==""){
		$dd[1] = 0;
	}
	if($ee[1]==""){
		$ee[1] = 0;
	}
	if($ff[1]==""){
		$ff[1] = 0;
	}
	if($ccav[1]==""){
		$ccav[1] = 0;
	}
	if($cc[2]==""){
		$cc[2] = 0;
	}
	if($dd[2]==""){
		$dd[2] = 0;
	}
	if($ee[2]==""){
		$ee[2] = 0;
	}
	if($ff[2]==""){
		$ff[2] = 0;
	}
	if($ccav[2]==""){
		$ccav[2] = 0;
	}
	if($cc[3]==""){
		$cc[3] = 0;
	}
	if($dd[3]==""){
		$dd[3] = 0;
	}
	if($ee[3]==""){
		$ee[3] = 0;
	}
	if($ff[3]==""){
		$ff[3] = 0;
	}
	if($ccav[3]==""){
		$ccav[3] = 0;
	}
	if($cc[4]==""){
		$cc[4] = 0;
	}
	if($dd[4]==""){
		$dd[4] = 0;
	}
	if($ee[4]==""){
		$ee[4] = 0;
	}
	if($ff[4]==""){
		$ff[4] = 0;
	}
	if($ccav[4]==""){
		$ccav[4] = 0;
	}
	if($cc[5]==""){
		$cc[5] = 0;
	}
	if($dd[5]==""){
		$dd[5] = 0;
	}
	if($ee[5]==""){
		$ee[5] = 0;
	}
	if($ff[5]==""){
		$ff[5] = 0;
	}
	if($ccav[5]==""){
		$ccav[5] = 0;
	}
$sub1 = array($cc[0],$dd[0],$ee[0],$ff[0],$ccav[0]);		
$sub2 = array($cc[1],$dd[1],$ee[1],$ff[1],$ccav[1]);
$sub3 = array($cc[2],$dd[2],$ee[2],$ff[2],$ccav[2]);
$sub4 = array($cc[3],$dd[3],$ee[3],$ff[3],$ccav[3]);
$sub5 = array($cc[4],$dd[4],$ee[4],$ff[4],$ccav[4]);
$sub6 = array($cc[5],$dd[5],$ee[5],$ff[5],$ccav[5]);
}
elseif($subjcount == 7){
		if($cc[0]==""){
		$cc[0] = 0;
	}
	if($dd[0]==""){
		$dd[0] = 0;
	}
	if($ee[0]==""){
		$ee[0] = 0;
	}
	if($ff[0]==""){
		$ff[0] = 0;
	}
	if($ccav[0]==""){
		$ccav[0] = 0;
	}
	if($cc[1]==""){
		$cc[1] = 0;
	}
	if($dd[1]==""){
		$dd[1] = 0;
	}
	if($ee[1]==""){
		$ee[1] = 0;
	}
	if($ff[1]==""){
		$ff[1] = 0;
	}
	if($ccav[1]==""){
		$ccav[1] = 0;
	}
	if($cc[2]==""){
		$cc[2] = 0;
	}
	if($dd[2]==""){
		$dd[2] = 0;
	}
	if($ee[2]==""){
		$ee[2] = 0;
	}
	if($ff[2]==""){
		$ff[2] = 0;
	}
	if($ccav[2]==""){
		$ccav[2] = 0;
	}
	if($cc[3]==""){
		$cc[3] = 0;
	}
	if($dd[3]==""){
		$dd[3] = 0;
	}
	if($ee[3]==""){
		$ee[3] = 0;
	}
	if($ff[3]==""){
		$ff[3] = 0;
	}
	if($ccav[3]==""){
		$ccav[3] = 0;
	}
	if($cc[4]==""){
		$cc[4] = 0;
	}
	if($dd[4]==""){
		$dd[4] = 0;
	}
	if($ee[4]==""){
		$ee[4] = 0;
	}
	if($ff[4]==""){
		$ff[4] = 0;
	}
	if($ccav[4]==""){
		$ccav[4] = 0;
	}
	if($cc[5]==""){
		$cc[5] = 0;
	}
	if($dd[5]==""){
		$dd[5] = 0;
	}
	if($ee[5]==""){
		$ee[5] = 0;
	}
	if($ff[5]==""){
		$ff[5] = 0;
	}
	if($ccav[5]==""){
		$ccav[5] = 0;
	}
	if($cc[6]==""){
		$cc[6] = 0;
	}
	if($dd[6]==""){
		$dd[6] = 0;
	}
	if($ee[6]==""){
		$ee[6] = 0;
	}
	if($ff[6]==""){
		$ff[6] = 0;
	}
	if($ccav[6]==""){
		$ccav[6] = 0;
	}
$sub1 = array($cc[0],$dd[0],$ee[0],$ff[0],$ccav[0]);		
$sub2 = array($cc[1],$dd[1],$ee[1],$ff[1],$ccav[1]);
$sub3 = array($cc[2],$dd[2],$ee[2],$ff[2],$ccav[2]);
$sub4 = array($cc[3],$dd[3],$ee[3],$ff[3],$ccav[3]);
$sub5 = array($cc[4],$dd[4],$ee[4],$ff[4],$ccav[4]);
$sub6 = array($cc[5],$dd[5],$ee[5],$ff[5],$ccav[5]);
$sub7 = array($cc[6],$dd[6],$ee[6],$ff[6],$ccav[6]);		
}
elseif($subjcount == 8){
		if($cc[0]==""){
		$cc[0] = 0;
	}
	if($dd[0]==""){
		$dd[0] = 0;
	}
	if($ee[0]==""){
		$ee[0] = 0;
	}
	if($ff[0]==""){
		$ff[0] = 0;
	}
	if($ccav[0]==""){
		$ccav[0] = 0;
	}
	if($cc[1]==""){
		$cc[1] = 0;
	}
	if($dd[1]==""){
		$dd[1] = 0;
	}
	if($ee[1]==""){
		$ee[4] = 0;
	}
	if($ff[1]==""){
		$ff[1] = 0;
	}
	if($ccav[1]==""){
		$ccav[1] = 0;
	}
	if($cc[2]==""){
		$cc[2] = 0;
	}
	if($dd[2]==""){
		$dd[2] = 0;
	}
	if($ee[2]==""){
		$ee[2] = 0;
	}
	if($ff[2]==""){
		$ff[2] = 0;
	}
	if($ccav[2]==""){
		$ccav[2] = 0;
	}
	if($cc[3]==""){
		$cc[3] = 0;
	}
	if($dd[3]==""){
		$dd[3] = 0;
	}
	if($ee[3]==""){
		$ee[3] = 0;
	}
	if($ff[3]==""){
		$ff[3] = 0;
	}
	if($ccav[3]==""){
		$ccav[3] = 0;
	}
	if($cc[4]==""){
		$cc[4] = 0;
	}
	if($dd[4]==""){
		$dd[4] = 0;
	}
	if($ee[4]==""){
		$ee[4] = 0;
	}
	if($ff[4]==""){
		$ff[4] = 0;
	}
	if($ccav[4]==""){
		$ccav[4] = 0;
	}
	if($cc[5]==""){
		$cc[5] = 0;
	}
	if($dd[5]==""){
		$dd[5] = 0;
	}
	if($ee[5]==""){
		$ee[5] = 0;
	}
	if($ff[5]==""){
		$ff[5] = 0;
	}
	if($ccav[5]==""){
		$ccav[5] = 0;
	}
	if($cc[6]==""){
		$cc[6] = 0;
	}
	if($dd[6]==""){
		$dd[6] = 0;
	}
	if($ee[6]==""){
		$ee[6] = 0;
	}
	if($ff[6]==""){
		$ff[6] = 0;
	}
	if($ccav[6]==""){
		$ccav[6] = 0;
	}
	if($cc[7]==""){
		$cc[7] = 0;
	}
	if($dd[7]==""){
		$dd[7] = 0;
	}
	if($ee[7]==""){
		$ee[7] = 0;
	}
	if($ff[7]==""){
		$ff[7] = 0;
	}
	if($ccav[7]==""){
		$ccav[7] = 0;
	}
$sub1 = array($cc[0],$dd[0],$ee[0],$ff[0],$ccav[0]);		
$sub2 = array($cc[1],$dd[1],$ee[1],$ff[1],$ccav[1]);
$sub3 = array($cc[2],$dd[2],$ee[2],$ff[2],$ccav[2]);
$sub4 = array($cc[3],$dd[3],$ee[3],$ff[3],$ccav[3]);
$sub5 = array($cc[4],$dd[4],$ee[4],$ff[4],$ccav[4]);
$sub6 = array($cc[5],$dd[5],$ee[5],$ff[5],$ccav[5]);
$sub7 = array($cc[6],$dd[6],$ee[6],$ff[6],$ccav[6]);	
$sub8 = array($cc[7],$dd[7],$ee[7],$ff[7],$ccav[7]);
}
elseif($subjcount == 9){
		if($cc[0]==""){
		$cc[0] = 0;
	}
	if($dd[0]==""){
		$dd[0] = 0;
	}
if($ee[0]==""){
		$ee[0] = 0;
	}
	if($ff[0]==""){
		$ff[0] = 0;
	}
	if($ccav[0]==""){
		$ccav[0] = 0;
	}
	if($cc[1]==""){
		$cc[1] = 0;
	}
	if($dd[1]==""){
		$dd[1] = 0;
	}
	if($ee[1]==""){
		$ee[1] = 0;
	}
	if($ff[1]==""){
		$ff[1] = 0;
	}
	if($ccav[1]==""){
		$ccav[1] = 0;
	}
	if($cc[2]==""){
		$cc[2] = 0;
	}
	if($dd[2]==""){
		$dd[2] = 0;
	}
	if($ee[2]==""){
		$ee[2] = 0;
	}
	if($ff[2]==""){
		$ff[2] = 0;
	}
	if($ccav[2]==""){
		$ccav[2] = 0;
	}
	if($cc[3]==""){
		$cc[3] = 0;
	}
	if($dd[3]==""){
		$dd[3] = 0;
	}
	if($ee[3]==""){
		$ee[3] = 0;
	}
	if($ff[3]==""){
		$ff[3] = 0;
	}
	if($ccav[3]==""){
		$ccav[3] = 0;
	}
	if($cc[4]==""){
		$cc[4] = 0;
	}
	if($dd[4]==""){
		$dd[4] = 0;
	}
	if($ee[4]==""){
		$ee[4] = 0;
	}
	if($ff[4]==""){
		$ff[4] = 0;
	}
	if($ccav[4]==""){
		$ccav[4] = 0;
	}
	if($cc[5]==""){
		$cc[5] = 0;
	}
	if($dd[5]==""){
		$dd[5] = 0;
	}
	if($ee[5]==""){
		$ee[5] = 0;
	}
	if($ff[5]==""){
		$ff[5] = 0;
	}
	if($ccav[5]==""){
		$ccav[5] = 0;
	}
	if($cc[6]==""){
		$cc[6] = 0;
	}
	if($dd[6]==""){
		$dd[6] = 0;
	}
	if($ee[6]==""){
		$ee[6] = 0;
	}
	if($ff[6]==""){
		$ff[6] = 0;
	}
	if($ccav[6]==""){
		$ccav[6] = 0;
	}
	if($cc[7]==""){
		$cc[7] = 0;
	}
	if($dd[7]==""){
		$dd[7] = 0;
	}
	if($ee[7]==""){
		$ee[7] = 0;
	}
	if($ff[7]==""){
		$ff[7] = 0;
	}
	if($ccav[7]==""){
		$ccav[7] = 0;
	}
	if($cc[8]==""){
		$cc[8] = 0;
	}
	if($dd[8]==""){
		$dd[8] = 0;
	}
	if($ee[8]==""){
		$ee[8] = 0;
	}
	if($ff[8]==""){
		$ff[8] = 0;
	}
	if($ccav[8]==""){
		$ccav[8] = 0;
	}
$sub1 = array($cc[0],$dd[0],$ee[0],$ff[0],$ccav[0]);		
$sub2 = array($cc[1],$dd[1],$ee[1],$ff[1],$ccav[1]);
$sub3 = array($cc[2],$dd[2],$ee[2],$ff[2],$ccav[2]);
$sub4 = array($cc[3],$dd[3],$ee[3],$ff[3],$ccav[3]);
$sub5 = array($cc[4],$dd[4],$ee[4],$ff[4],$ccav[4]);
$sub6 = array($cc[5],$dd[5],$ee[5],$ff[5],$ccav[5]);
$sub7 = array($cc[6],$dd[6],$ee[6],$ff[6],$ccav[6]);	
$sub8 = array($cc[7],$dd[7],$ee[7],$ff[7],$ccav[7]);
$sub9 = array($cc[8],$dd[8],$ee[8],$ff[8],$ccav[8]);
}
elseif($subjcount == 10){
		if($cc[0]==""){
		$cc[0] = 0;
	}
	if($dd[0]==""){
		$dd[0] = 0;
	}
	if($ee[0]==""){
		$ee[0] = 0;
	}
	if($ff[0]==""){
		$ff[0] = 0;
	}
	if($ccav[0]==""){
		$ccav[0] = 0;
	}
	if($cc[1]==""){
		$cc[1] = 0;
	}
	if($dd[1]==""){
		$dd[1] = 0;
	}
	if($ee[1]==""){
		$ee[1] = 0;
	}
	if($ff[1]==""){
		$ff[1] = 0;
	}
	if($ccav[1]==""){
		$ccav[1] = 0;
	}
	if($cc[2]==""){
		$cc[2] = 0;
	}
	if($dd[2]==""){
		$dd[2] = 0;
	}
	if($ee[2]==""){
		$ee[2] = 0;
	}
	if($ff[2]==""){
		$ff[2] = 0;
	}
	if($ccav[2]==""){
		$ccav[2] = 0;
	}
	if($cc[3]==""){
		$cc[3] = 0;
	}
	if($dd[3]==""){
		$dd[3] = 0;
	}
	if($ee[3]==""){
		$ee[3] = 0;
	}
	if($ff[3]==""){
		$ff[3] = 0;
	}
	if($ccav[3]==""){
		$ccav[3] = 0;
	}
	if($cc[4]==""){
		$cc[4] = 0;
	}
	if($dd[4]==""){
		$dd[4] = 0;
	}
	if($ee[4]==""){
		$ee[4] = 0;
	}
	if($ff[4]==""){
		$ff[4] = 0;
	}
	if($ccav[4]==""){
		$ccav[4] = 0;
	}
	if($cc[5]==""){
		$cc[5] = 0;
	}
	if($dd[5]==""){
		$dd[5] = 0;
	}
	if($ee[5]==""){
		$ee[5] = 0;
	}
	if($ff[5]==""){
		$ff[5] = 0;
	}
	if($ccav[5]==""){
		$ccav[5] = 0;
	}
	if($cc[6]==""){
		$cc[6] = 0;
	}
	if($dd[6]==""){
		$dd[6] = 0;
	}
	if($ee[6]==""){
		$ee[6] = 0;
	}
	if($ff[6]==""){
		$ff[6] = 0;
	}
	if($ccav[6]==""){
		$ccav[6] = 0;
	}
	if($cc[7]==""){
		$cc[7] = 0;
	}
	if($dd[7]==""){
		$dd[7] = 0;
	}
	if($ee[7]==""){
		$ee[7] = 0;
	}
	if($ff[7]==""){
		$ff[7] = 0;
	}
	if($ccav[7]==""){
		$ccav[7] = 0;
	}
	if($cc[8]==""){
		$cc[8] = 0;
	}
	if($dd[8]==""){
		$dd[8] = 0;
	}
	if($ee[8]==""){
		$ee[8] = 0;
	}
	if($ff[8]==""){
		$ff[8] = 0;
	}
	if($ccav[8]==""){
		$ccav[8] = 0;
	}
	if($cc[9]==""){
		$cc[9] = 0;
	}
	if($dd[9]==""){
		$dd[9] = 0;
	}
	if($ee[9]==""){
		$ee[9] = 0;
	}
	if($ff[9]==""){
		$ff[9] = 0;
	}
	if($ccav[9]==""){
		$ccav[9] = 0;
	}
$sub1 = array($cc[0],$dd[0],$ee[0],$ff[0],$ccav[0]);		
$sub2 = array($cc[1],$dd[1],$ee[1],$ff[1],$ccav[1]);
$sub3 = array($cc[2],$dd[2],$ee[2],$ff[2],$ccav[2]);
$sub4 = array($cc[3],$dd[3],$ee[3],$ff[3],$ccav[3]);
$sub5 = array($cc[4],$dd[4],$ee[4],$ff[4],$ccav[4]);
$sub6 = array($cc[5],$dd[5],$ee[5],$ff[5],$ccav[5]);
$sub7 = array($cc[6],$dd[6],$ee[6],$ff[6],$ccav[6]);	
$sub8 = array($cc[7],$dd[7],$ee[7],$ff[7],$ccav[7]);
$sub9 = array($cc[8],$dd[8],$ee[8],$ff[8],$ccav[8]);
$sub10 = array($cc[9],$dd[9],$ee[9],$ff[8],$ccav[9]);
}
elseif($subjcount == 11){
		if($cc[0]==""){
		$cc[0] = 0;
	}
	if($dd[0]==""){
		$dd[0] = 0;
	}
	if($ee[0]==""){
		$ee[0] = 0;
	}
	if($ff[0]==""){
		$ff[0] = 0;
	}
	if($ccav[0]==""){
		$ccav[0] = 0;
	}
	if($cc[1]==""){
		$cc[1] = 0;
	}
	if($dd[1]==""){
		$dd[1] = 0;
	}
	if($ee[1]==""){
		$ee[1] = 0;
	}
	if($ff[1]==""){
		$ff[1] = 0;
	}
	if($ccav[1]==""){
		$ccav[1] = 0;
	}
	if($cc[2]==""){
		$cc[2] = 0;
	}
	if($dd[2]==""){
		$dd[2] = 0;
	}
	if($ee[2]==""){
		$ee[2] = 0;
	}
	if($ff[2]==""){
		$ff[2] = 0;
	}
	if($ccav[2]==""){
		$ccav[2] = 0;
	}
	if($cc[3]==""){
		$cc[3] = 0;
	}
	if($dd[3]==""){
		$dd[3] = 0;
	}
	if($ee[3]==""){
		$ee[3] = 0;
	}
	if($ff[3]==""){
		$ff[3] = 0;
	}
	if($ccav[3]==""){
		$ccav[3] = 0;
	}
	if($cc[4]==""){
		$cc[4] = 0;
	}
	if($dd[4]==""){
		$dd[4] = 0;
	}
	if($ee[4]==""){
		$ee[4] = 0;
	}
	if($ff[4]==""){
		$ff[4] = 0;
	}
	if($ccav[4]==""){
		$ccav[4] = 0;
	}
	if($cc[5]==""){
		$cc[5] = 0;
	}
	if($dd[5]==""){
		$dd[5] = 0;
	}
	if($ee[5]==""){
		$ee[5] = 0;
	}
	if($ff[5]==""){
		$ff[5] = 0;
	}
	if($ccav[5]==""){
		$ccav[5] = 0;
	}
	if($cc[6]==""){
		$cc[6] = 0;
	}
	if($dd[6]==""){
		$dd[6] = 0;
	}
	if($ee[6]==""){
		$ee[6] = 0;
	}
	if($ff[6]==""){
		$ff[6] = 0;
	}
	if($ccav[6]==""){
		$ccav[6] = 0;
	}
	if($cc[7]==""){
		$cc[7] = 0;
	}
	if($dd[7]==""){
		$dd[7] = 0;
	}
	if($ee[7]==""){
		$ee[7] = 0;
	}
	if($ff[7]==""){
		$ff[7] = 0;
	}
	if($ccav[7]==""){
		$ccav[7] = 0;
	}
	if($cc[8]==""){
		$cc[8] = 0;
	}
	if($dd[8]==""){
		$dd[8] = 0;
	}
	if($ee[8]==""){
		$ee[8] = 0;
	}
	if($ff[8]==""){
		$ff[8] = 0;
	}
	if($ccav[8]==""){
		$ccav[8] = 0;
	}
	if($cc[9]==""){
		$cc[9] = 0;
	}
	if($dd[9]==""){
		$dd[9] = 0;
	}
	if($ee[9]==""){
		$ee[9] = 0;
	}
	if($ff[9]==""){
		$ff[9] = 0;
	}
	if($ccav[9]==""){
		$ccav[9] = 0;
	}
	if($cc[10]==""){
		$cc[10] = 0;
	}
	if($dd[10]==""){
		$dd[10] = 0;
	}
	if($ee[10]==""){
		$ee[10] = 0;
	}
	if($ff[10]==""){
		$ff[10] = 0;
	}
	if($ccav[10]==""){
		$ccav[10] = 0;
	}
$sub1 = array($cc[0],$dd[0],$ee[0],$ff[0],$ccav[0]);		
$sub2 = array($cc[1],$dd[1],$ee[1],$ff[1],$ccav[1]);
$sub3 = array($cc[2],$dd[2],$ee[2],$ff[2],$ccav[2]);
$sub4 = array($cc[3],$dd[3],$ee[3],$ff[3],$ccav[3]);
$sub5 = array($cc[4],$dd[4],$ee[4],$ff[4],$ccav[4]);
$sub6 = array($cc[5],$dd[5],$ee[5],$ff[5],$ccav[5]);
$sub7 = array($cc[6],$dd[6],$ee[6],$ff[6],$ccav[6]);	
$sub8 = array($cc[7],$dd[7],$ee[7],$ff[7],$ccav[7]);
$sub9 = array($cc[8],$dd[8],$ee[8],$ff[8],$ccav[8]);
$sub10 = array($cc[9],$dd[9],$ee[9],$ff[8],$ccav[9]);
$sub11 = array($cc[10],$dd[10],$ee[10],$ff[10],$ccav[10]);
}
elseif($subjcount == 12){
		if($cc[0]==""){
		$cc[0] = 0;
	}
	if($dd[0]==""){
		$dd[0] = 0;
	}
	if($ee[0]==""){
		$ee[0] = 0;
	}
	if($ff[0]==""){
		$ff[0] = 0;
	}
	if($ccav[0]==""){
		$ccav[0] = 0;
	}
	if($cc[1]==""){
		$cc[1] = 0;
	}
	if($dd[1]==""){
		$dd[1] = 0;
	}
	if($ee[1]==""){
		$ee[1] = 0;
	}
	if($ff[1]==""){
		$ff[1] = 0;
	}
	if($ccav[1]==""){
		$ccav[1] = 0;
	}
	if($cc[2]==""){
		$cc[2] = 0;
	}
	if($dd[2]==""){
		$dd[2] = 0;
	}
	if($ee[2]==""){
		$ee[2] = 0;
	}
	if($ff[2]==""){
		$ff[2] = 0;
	}
	if($ccav[2]==""){
		$ccav[2] = 0;
	}
	if($cc[3]==""){
		$cc[3] = 0;
	}
	if($dd[3]==""){
		$dd[3] = 0;
	}
	if($ee[3]==""){
		$ee[3] = 0;
	}
	if($ff[3]==""){
		$ff[3] = 0;
	}
	if($ccav[3]==""){
		$ccav[3] = 0;
	}
	if($cc[4]==""){
		$cc[4] = 0;
	}
	if($dd[4]==""){
		$dd[4] = 0;
	}
	if($ee[4]==""){
		$ee[4] = 0;
	}
	if($ff[4]==""){
		$ff[4] = 0;
	}
	if($ccav[4]==""){
		$ccav[4] = 0;
	}
	if($cc[5]==""){
		$cc[5] = 0;
	}
	if($dd[5]==""){
		$dd[5] = 0;
	}
	if($ee[5]==""){
		$ee[5] = 0;
	}
	if($ff[5]==""){
		$ff[5] = 0;
	}
	if($ccav[5]==""){
		$ccav[5] = 0;
	}
	if($cc[6]==""){
		$cc[6] = 0;
	}
	if($dd[6]==""){
		$dd[6] = 0;
	}
	if($ee[6]==""){
		$ee[6] = 0;
	}
	if($ff[6]==""){
		$ff[6] = 0;
	}
	if($ccav[6]==""){
		$ccav[6] = 0;
	}
	if($cc[7]==""){
		$cc[7] = 0;
	}
	if($dd[7]==""){
		$dd[7] = 0;
	}
	if($ee[7]==""){
		$ee[7] = 0;
	}
	if($ff[7]==""){
		$ff[7] = 0;
	}
	if($ccav[7]==""){
		$ccav[7] = 0;
	}
	if($cc[8]==""){
		$cc[8] = 0;
	}
	if($dd[8]==""){
		$dd[8] = 0;
	}
	if($ee[8]==""){
		$ee[8] = 0;
	}
	if($ff[8]==""){
		$ff[8] = 0;
	}
	if($ccav[8]==""){
		$ccav[8] = 0;
	}
	if($cc[9]==""){
		$cc[9] = 0;
	}
	if($dd[9]==""){
		$dd[9] = 0;
	}
	if($ee[9]==""){
		$ee[9] = 0;
	}
	if($ff[9]==""){
		$ff[9] = 0;
	}
	if($ccav[9]==""){
		$ccav[9] = 0;
	}
	if($cc[10]==""){
		$cc[10] = 0;
	}
	if($dd[10]==""){
		$dd[10] = 0;
	}
	if($ee[10]==""){
		$ee[10] = 0;
	}
	if($ff[10]==""){
		$ff[10] = 0;
	}
	if($ccav[10]==""){
		$ccav[10] = 0;
	}
	if($cc[11]==""){
		$cc[11] = 0;
	}
	if($dd[11]==""){
		$dd[11] = 0;
	}
	if($ee[11]==""){
		$ee[11] = 0;
	}
	if($ff[11]==""){
		$ff[11] = 0;
	}
	if($ccav[11]==""){
		$ccav[11] = 0;
	}
$sub1 = array($cc[0],$dd[0],$ee[0],$ff[0],$ccav[0]);		
$sub2 = array($cc[1],$dd[1],$ee[1],$ff[1],$ccav[1]);
$sub3 = array($cc[2],$dd[2],$ee[2],$ff[2],$ccav[2]);
$sub4 = array($cc[3],$dd[3],$ee[3],$ff[3],$ccav[3]);
$sub5 = array($cc[4],$dd[4],$ee[4],$ff[4],$ccav[4]);
$sub6 = array($cc[5],$dd[5],$ee[5],$ff[5],$ccav[5]);
$sub7 = array($cc[6],$dd[6],$ee[6],$ff[6],$ccav[6]);	
$sub8 = array($cc[7],$dd[7],$ee[7],$ff[7],$ccav[7]);
$sub9 = array($cc[8],$dd[8],$ee[8],$ff[8],$ccav[8]);
$sub10 = array($cc[9],$dd[9],$ee[9],$ff[8],$ccav[9]);
$sub11 = array($cc[10],$dd[10],$ee[10],$ff[10],$ccav[10]);
$sub12 = array($cc[11],$dd[11],$ee[11],$ff[11],$ccav[11]);
}
elseif($subjcount == 13){
	if($cc[0]==""){
		$cc[0] = 0;
	}
	if($dd[0]==""){
		$dd[0] = 0;
	}
	if($ee[0]==""){
		$ee[0] = 0;
	}
	if($ff[0]==""){
		$ff[0] = 0;
	}
	if($ccav[0]==""){
		$ccav[0] = 0;
	}
	if($cc[1]==""){
		$cc[1] = 0;
	}
	if($dd[1]==""){
		$dd[1] = 0;
	}
	if($ee[1]==""){
		$ee[1] = 0;
	}
	if($ff[1]==""){
		$ff[1] = 0;
	}
	if($ccav[1]==""){
		$ccav[1] = 0;
	}
	if($cc[2]==""){
		$cc[2] = 0;
	}
	if($dd[2]==""){
		$dd[2] = 0;
	}
	if($ee[2]==""){
		$ee[2] = 0;
	}
	if($ff[2]==""){
		$ff[2] = 0;
	}
	if($ccav[2]==""){
		$ccav[2] = 0;
	}
	if($cc[3]==""){
		$cc[3] = 0;
	}
	if($dd[3]==""){
		$dd[3] = 0;
	}
	if($ee[3]==""){
		$ee[3] = 0;
	}
	if($ff[3]==""){
		$ff[3] = 0;
	}
	if($ccav[3]==""){
		$ccav[3] = 0;
	}
	if($cc[4]==""){
		$cc[4] = 0;
	}
	if($dd[4]==""){
		$dd[4] = 0;
	}
	if($ee[4]==""){
		$ee[4] = 0;
	}
	if($ff[4]==""){
		$ff[4] = 0;
	}
	if($ccav[4]==""){
		$ccav[4] = 0;
	}
	if($cc[5]==""){
		$cc[5] = 0;
	}
	if($dd[5]==""){
		$dd[5] = 0;
	}
	if($ee[5]==""){
		$ee[5] = 0;
	}
	if($ff[5]==""){
		$ff[5] = 0;
	}
	if($ccav[5]==""){
		$ccav[5] = 0;
	}
	if($cc[6]==""){
		$cc[6] = 0;
	}
	if($dd[6]==""){
		$dd[6] = 0;
	}
	if($ee[6]==""){
		$ee[6] = 0;
	}
	if($ff[6]==""){
		$ff[6] = 0;
	}
	if($ccav[6]==""){
		$ccav[6] = 0;
	}
	if($cc[7]==""){
		$cc[7] = 0;
	}
	if($dd[7]==""){
		$dd[7] = 0;
	}
	if($ee[7]==""){
		$ee[7] = 0;
	}
	if($ff[7]==""){
		$ff[7] = 0;
	}
	if($ccav[7]==""){
		$ccav[7] = 0;
	}
	if($cc[8]==""){
		$cc[8] = 0;
	}
	if($dd[8]==""){
		$dd[8] = 0;
	}
	if($ee[8]==""){
		$ee[8] = 0;
	}
	if($ff[8]==""){
		$ff[8] = 0;
	}
	if($ccav[8]==""){
		$ccav[8] = 0;
	}
	if($cc[9]==""){
		$cc[9] = 0;
	}
	if($dd[9]==""){
		$dd[9] = 0;
	}
	if($ee[9]==""){
		$ee[9] = 0;
	}
	if($ff[9]==""){
		$ff[9] = 0;
	}
	if($ccav[9]==""){
		$ccav[9] = 0;
	}
	if($cc[10]==""){
		$cc[10] = 0;
	}
	if($dd[10]==""){
		$dd[10] = 0;
	}
	if($ee[10]==""){
		$ee[10] = 0;
	}
	if($ff[10]==""){
		$ff[10] = 0;
	}
	if($ccav[10]==""){
		$ccav[10] = 0;
	}
	if($cc[11]==""){
		$cc[11] = 0;
	}
	if($dd[11]==""){
		$dd[11] = 0;
	}
	if($ee[11]==""){
		$ee[11] = 0;
	}
	if($ff[11]==""){
		$ff[11] = 0;
	}
	if($ccav[11]==""){
		$ccav[11] = 0;
	}
	if($cc[12]==""){
		$cc[12] = 0;
	}
	if($dd[12]==""){
		$dd[12] = 0;
	}
	if($ee[12]==""){
		$ee[12] = 0;
	}
	if($ff[12]==""){
		$ff[12] = 0;
	}
	if($ccav[12]==""){
		$ccav[12] = 0;
	}
$sub1 = array($cc[0],$dd[0],$ee[0],$ff[0],$ccav[0]);		
$sub2 = array($cc[1],$dd[1],$ee[1],$ff[1],$ccav[1]);
$sub3 = array($cc[2],$dd[2],$ee[2],$ff[2],$ccav[2]);
$sub4 = array($cc[3],$dd[3],$ee[3],$ff[3],$ccav[3]);
$sub5 = array($cc[4],$dd[4],$ee[4],$ff[4],$ccav[4]);
$sub6 = array($cc[5],$dd[5],$ee[5],$ff[5],$ccav[5]);
$sub7 = array($cc[6],$dd[6],$ee[6],$ff[6],$ccav[6]);	
$sub8 = array($cc[7],$dd[7],$ee[7],$ff[7],$ccav[7]);
$sub9 = array($cc[8],$dd[8],$ee[8],$ff[8],$ccav[8]);
$sub10 = array($cc[9],$dd[9],$ee[9],$ff[8],$ccav[9]);
$sub11 = array($cc[10],$dd[10],$ee[10],$ff[10],$ccav[10]);
$sub12 = array($cc[11],$dd[11],$ee[11],$ff[11],$ccav[11]);	
$sub13 = array($cc[12],$dd[12],$ee[12],$ff[12],$ccav[12]);	
}
else if($subjcount=14){
	if($cc[0]==""){
		$cc[0] = 0;
	}
	if($dd[0]==""){
		$dd[0] = 0;
	}
	if($ee[0]==""){
		$ee[0] = 0;
	}
	if($ff[0]==""){
		$ff[0] = 0;
	}
	if($ccav[0]==""){
		$ccav[0] = 0;
	}
	if($cc[1]==""){
		$cc[1] = 0;
	}
	if($dd[1]==""){
		$dd[1] = 0;
	}
	if($ee[1]==""){
		$ee[1] = 0;
	}
	if($ff[1]==""){
		$ff[1] = 0;
	}
	if($ccav[1]==""){
		$ccav[1] = 0;
	}
	if($cc[2]==""){
		$cc[2] = 0;
	}
	if($dd[2]==""){
		$dd[2] = 0;
	}
	if($ee[2]==""){
		$ee[2] = 0;
	}
	if($ff[2]==""){
		$ff[2] = 0;
	}
	if($ccav[2]==""){
		$ccav[2] = 0;
	}
	if($cc[3]==""){
		$cc[3] = 0;
	}
	if($dd[3]==""){
		$dd[3] = 0;
	}
	if($ee[3]==""){
		$ee[3] = 0;
	}
	if($ff[3]==""){
		$ff[3] = 0;
	}
	if($ccav[3]==""){
		$ccav[3] = 0;
	}
	if($cc[4]==""){
		$cc[4] = 0;
	}
	if($dd[4]==""){
		$dd[4] = 0;
	}
	if($ee[4]==""){
		$ee[4] = 0;
	}
	if($ff[4]==""){
		$ff[4] = 0;
	}
	if($ccav[4]==""){
		$ccav[4] = 0;
	}
	if($cc[5]==""){
		$cc[5] = 0;
	}
	if($dd[5]==""){
		$dd[5] = 0;
	}
	if($ee[5]==""){
		$ee[5] = 0;
	}
	if($ff[5]==""){
		$ff[5] = 0;
	}
	if($ccav[5]==""){
		$ccav[5] = 0;
	}
	if($cc[6]==""){
		$cc[6] = 0;
	}
	if($dd[6]==""){
		$dd[6] = 0;
	}
	if($ee[6]==""){
		$ee[6] = 0;
	}
	if($ff[6]==""){
		$ff[6] = 0;
	}
	if($ccav[6]==""){
		$ccav[6] = 0;
	}
	if($cc[7]==""){
		$cc[7] = 0;
	}
	if($dd[7]==""){
		$dd[7] = 0;
	}
	if($ee[7]==""){
		$ee[7] = 0;
	}
	if($ff[7]==""){
		$ff[7] = 0;
	}
	if($ccav[7]==""){
		$ccav[7] = 0;
	}
	if($cc[8]==""){
		$cc[8] = 0;
	}
	if($dd[8]==""){
		$dd[8] = 0;
	}
	if($ee[8]==""){
		$ee[8] = 0;
	}
	if($ff[8]==""){
		$ff[8] = 0;
	}
	if($ccav[8]==""){
		$ccav[8] = 0;
	}
	if($cc[9]==""){
		$cc[9] = 0;
	}
	if($dd[9]==""){
		$dd[9] = 0;
	}
	if($ee[9]==""){
		$ee[9] = 0;
	}
	if($ff[9]==""){
		$ff[9] = 0;
	}
	if($ccav[9]==""){
		$ccav[9] = 0;
	}
	if($cc[10]==""){
		$cc[10] = 0;
	}
	if($dd[10]==""){
		$dd[10] = 0;
	}
	if($ee[10]==""){
		$ee[10] = 0;
	}
	if($ff[10]==""){
		$ff[10] = 0;
	}
	if($ccav[10]==""){
		$ccav[10] = 0;
	}
	if($cc[11]==""){
		$cc[11] = 0;
	}
	if($dd[11]==""){
		$dd[11] = 0;
	}
	if($ee[11]==""){
		$ee[11] = 0;
	}
	if($ff[11]==""){
		$ff[11] = 0;
	}
	if($ccav[11]==""){
		$ccav[11] = 0;
	}
	if($cc[12]==""){
		$cc[12] = 0;
	}
	if($dd[12]==""){
		$dd[12] = 0;
	}
	if($ee[12]==""){
		$ee[12] = 0;
	}
	if($ff[12]==""){
		$ff[12] = 0;
	}
	if($ccav[12]==""){
		$ccav[12] = 0;
	}
	if($cc[13]==""){
		$cc[13] = 0;
	}
	if($dd[13]==""){
		$dd[13] = 0;
	}
	if($ee[13]==""){
		$ee[13] = 0;
	}
	if($ff[13]==""){
		$ff[13] = 0;
	}
	if($ccav[13]==""){
		$ccav[13] = 0;
	}
$sub1 = array($cc[0],$dd[0],$ee[0],$ff[0],$ccav[0]);		
$sub2 = array($cc[1],$dd[1],$ee[1],$ff[1],$ccav[1]);
$sub3 = array($cc[2],$dd[2],$ee[2],$ff[2],$ccav[2]);
$sub4 = array($cc[3],$dd[3],$ee[3],$ff[3],$ccav[3]);
$sub5 = array($cc[4],$dd[4],$ee[4],$ff[4],$ccav[4]);
$sub6 = array($cc[5],$dd[5],$ee[5],$ff[5],$ccav[5]);
$sub7 = array($cc[6],$dd[6],$ee[6],$ff[6],$ccav[6]);	
$sub8 = array($cc[7],$dd[7],$ee[7],$ff[7],$ccav[7]);
$sub9 = array($cc[8],$dd[8],$ee[8],$ff[8],$ccav[8]);
$sub10 = array($cc[9],$dd[9],$ee[9],$ff[8],$ccav[9]);
$sub11 = array($cc[10],$dd[10],$ee[10],$ff[10],$ccav[10]);
$sub12 = array($cc[11],$dd[11],$ee[11],$ff[11],$ccav[11]);	
$sub13 = array($cc[12],$dd[12],$ee[12],$ff[12],$ccav[12]);	
$sub14 = array($cc[13],$dd[13],$ee[13],$ff[13],$ccav[13]);	
}
else if($subjcount=15){
	if($cc[0]==""){
		$cc[0] = 0;
	}
	if($dd[0]==""){
		$dd[0] = 0;
	}
	if($ee[0]==""){
		$ee[0] = 0;
	}
	if($ff[0]==""){
		$ff[0] = 0;
	}
	if($ccav[0]==""){
		$ccav[0] = 0;
	}
	if($cc[1]==""){
		$cc[1] = 0;
	}
	if($dd[1]==""){
		$dd[1] = 0;
	}
	if($ee[1]==""){
		$ee[1] = 0;
	}
	if($ff[1]==""){
		$ff[1] = 0;
	}
	if($ccav[1]==""){
		$ccav[1] = 0;
	}
	if($cc[2]==""){
		$cc[2] = 0;
	}
	if($dd[2]==""){
		$dd[2] = 0;
	}
	if($ee[2]==""){
		$ee[2] = 0;
	}
	if($ff[2]==""){
		$ff[2] = 0;
	}
	if($ccav[2]==""){
		$ccav[2] = 0;
	}
	if($cc[3]==""){
		$cc[3] = 0;
	}
	if($dd[3]==""){
		$dd[3] = 0;
	}
	if($ee[3]==""){
		$ee[3] = 0;
	}
	if($ff[3]==""){
		$ff[3] = 0;
	}
	if($ccav[3]==""){
		$ccav[3] = 0;
	}
	if($cc[4]==""){
		$cc[4] = 0;
	}
	if($dd[4]==""){
		$dd[4] = 0;
	}
	if($ee[4]==""){
		$ee[4] = 0;
	}
	if($ff[4]==""){
		$ff[4] = 0;
	}
	if($ccav[4]==""){
		$ccav[4] = 0;
	}
	if($cc[5]==""){
		$cc[5] = 0;
	}
	if($dd[5]==""){
		$dd[5] = 0;
	}
	if($ee[5]==""){
		$ee[5] = 0;
	}
	if($ff[5]==""){
		$ff[5] = 0;
	}
	if($ccav[5]==""){
		$ccav[5] = 0;
	}
	if($cc[6]==""){
		$cc[6] = 0;
	}
	if($ee[6]==""){
		$ee[6] = 0;
	}
	if($ff[6]==""){
		$ff[6] = 0;
	}
	if($dd[6]==""){
		$dd[6] = 0;
	}
	if($ccav[6]==""){
		$ccav[6] = 0;
	}
	if($cc[7]==""){
		$cc[7] = 0;
	}
	if($dd[7]==""){
		$dd[7] = 0;
	}
	if($ee[7]==""){
		$ee[7] = 0;
	}
	if($ff[7]==""){
		$ff[7] = 0;
	}
	if($ccav[7]==""){
		$ccav[7] = 0;
	}
	if($cc[8]==""){
		$cc[8] = 0;
	}
	if($dd[8]==""){
		$dd[8] = 0;
	}
	if($ee[8]==""){
		$ee[8] = 0;
	}
	if($ff[8]==""){
		$ff[8] = 0;
	}
	if($ccav[8]==""){
		$ccav[8] = 0;
	}
	if($cc[9]==""){
		$cc[9] = 0;
	}
	if($dd[9]==""){
		$dd[9] = 0;
	}
	if($ee[9]==""){
		$ee[9] = 0;
	}
	if($ff[9]==""){
		$ff[9] = 0;
	}
	if($ccav[9]==""){
		$ccav[9] = 0;
	}
	if($cc[10]==""){
		$cc[10] = 0;
	}
	if($dd[10]==""){
		$dd[10] = 0;
	}
	if($ee[10]==""){
		$ee[10] = 0;
	}
	if($ff[10]==""){
		$ff[10] = 0;
	}
	if($ccav[10]==""){
		$ccav[10] = 0;
	}
	if($cc[11]==""){
		$cc[11] = 0;
	}
	if($dd[11]==""){
		$dd[11] = 0;
	}
	if($ee[11]==""){
		$ee[11] = 0;
	}
	if($ff[11]==""){
		$ff[11] = 0;
	}
	if($ccav[11]==""){
		$ccav[11] = 0;
	}
	if($cc[12]==""){
		$cc[12] = 0;
	}
	if($dd[12]==""){
		$dd[12] = 0;
	}
	if($ee[12]==""){
		$ee[12] = 0;
	}
	if($ff[12]==""){
		$ff[12] = 0;
	}
	if($ccav[12]==""){
		$ccav[12] = 0;
	}
	if($cc[13]==""){
		$cc[13] = 0;
	}
	if($dd[13]==""){
		$dd[13] = 0;
	}
	if($ee[13]==""){
		$ee[13] = 0;
	}
	if($ff[13]==""){
		$ff[13] = 0;
	}
	if($ccav[13]==""){
		$ccav[13] = 0;
	}
	if($cc[14]==""){
		$cc[14] = 0;
	}
	if($dd[14]==""){
		$dd[14] = 0;
	}
	if($ee[14]==""){
		$ee[14] = 0;
	}
	if($ff[14]==""){
		$ff[14] = 0;
	}
	if($ccav[14]==""){
		$ccav[14] = 0;
	}
$sub1 = array($cc[0],$dd[0],$ee[0],$ff[0],$ccav[0]);		
$sub2 = array($cc[1],$dd[1],$ee[1],$ff[1],$ccav[1]);
$sub3 = array($cc[2],$dd[2],$ee[2],$ff[2],$ccav[2]);
$sub4 = array($cc[3],$dd[3],$ee[3],$ff[3],$ccav[3]);
$sub5 = array($cc[4],$dd[4],$ee[4],$ff[4],$ccav[4]);
$sub6 = array($cc[5],$dd[5],$ee[5],$ff[5],$ccav[5]);
$sub7 = array($cc[6],$dd[6],$ee[6],$ff[6],$ccav[6]);	
$sub8 = array($cc[7],$dd[7],$ee[7],$ff[7],$ccav[7]);
$sub9 = array($cc[8],$dd[8],$ee[8],$ff[8],$ccav[8]);
$sub10 = array($cc[9],$dd[9],$ee[9],$ff[8],$ccav[9]);
$sub11 = array($cc[10],$dd[10],$ee[10],$ff[10],$ccav[10]);
$sub12 = array($cc[11],$dd[11],$ee[11],$ff[11],$ccav[11]);	
$sub13 = array($cc[12],$dd[12],$ee[12],$ff[12],$ccav[12]);	
$sub14 = array($cc[13],$dd[13],$ee[13],$ff[13],$ccav[13]);
$sub15 = array($cc[14],$dd[14],$ee[14],$ff[14],$ccav[14]);		
}
else if($subjcount=16){
	if($cc[0]==""){
		$cc[0] = 0;
	}
	if($dd[0]==""){
		$dd[0] = 0;
	}
	if($ee[0]==""){
		$ee[0] = 0;
	}
	if($ff[0]==""){
		$ff[0] = 0;
	}
	if($ccav[0]==""){
		$ccav[0] = 0;
	}
	if($cc[1]==""){
		$cc[1] = 0;
	}
	if($dd[1]==""){
		$dd[1] = 0;
	}
	if($ee[1]==""){
		$ee[1] = 0;
	}
	if($ff[1]==""){
		$ff[1] = 0;
	}
	if($ccav[1]==""){
		$ccav[1] = 0;
	}
	if($cc[2]==""){
		$cc[2] = 0;
	}
	if($dd[2]==""){
		$dd[2] = 0;
	}
	if($ee[2]==""){
		$ee[2] = 0;
	}
	if($ff[2]==""){
		$ff[2] = 0;
	}
	if($ccav[2]==""){
		$ccav[2] = 0;
	}
	if($cc[3]==""){
		$cc[3] = 0;
	}
	if($dd[3]==""){
		$dd[3] = 0;
	}
	if($ee[3]==""){
		$ee[3] = 0;
	}
	if($ff[3]==""){
		$ff[3] = 0;
	}
	if($ccav[3]==""){
		$ccav[3] = 0;
	}
	if($cc[4]==""){
		$cc[4] = 0;
	}
	if($dd[4]==""){
		$dd[4] = 0;
	}
	if($ee[4]==""){
		$ee[4] = 0;
	}
	if($ff[4]==""){
		$ff[4] = 0;
	}
	if($ccav[4]==""){
		$ccav[4] = 0;
	}
	if($cc[5]==""){
		$cc[5] = 0;
	}
	if($dd[5]==""){
		$dd[5] = 0;
	}
	if($ee[5]==""){
		$ee[5] = 0;
	}
	if($ff[5]==""){
		$ff[5] = 0;
	}
	if($ccav[5]==""){
		$ccav[5] = 0;
	}
	if($cc[6]==""){
		$cc[6] = 0;
	}
	if($dd[6]==""){
		$dd[6] = 0;
	}
	if($ee[6]==""){
		$ee[6] = 0;
	}
	if($ff[6]==""){
		$ff[6] = 0;
	}
	if($ccav[6]==""){
		$ccav[6] = 0;
	}
	if($cc[7]==""){
		$cc[7] = 0;
	}
	if($dd[7]==""){
		$dd[7] = 0;
	}
	if($ee[7]==""){
		$ee[7] = 0;
	}
	if($ff[7]==""){
		$ff[7] = 0;
	}
	if($ccav[7]==""){
		$ccav[7] = 0;
	}
	if($cc[8]==""){
		$cc[8] = 0;
	}
	if($dd[8]==""){
		$dd[8] = 0;
	}
	if($ee[8]==""){
		$ee[8] = 0;
	}
	if($ff[8]==""){
		$ff[8] = 0;
	}
	if($ccav[8]==""){
		$ccav[8] = 0;
	}
	if($cc[9]==""){
		$cc[9] = 0;
	}
	if($dd[9]==""){
		$dd[9] = 0;
	}
	if($ee[9]==""){
		$ee[9] = 0;
	}
	if($ff[9]==""){
		$ff[9] = 0;
	}
	if($ccav[9]==""){
		$ccav[9] = 0;
	}
	if($cc[10]==""){
		$cc[10] = 0;
	}
	if($dd[10]==""){
		$dd[10] = 0;
	}
	if($ee[10]==""){
		$ee[10] = 0;
	}
	if($ff[10]==""){
		$ff[10] = 0;
	}
	if($ccav[10]==""){
		$ccav[10] = 0;
	}
	if($cc[11]==""){
		$cc[11] = 0;
	}
	if($dd[11]==""){
		$dd[11] = 0;
	}
	if($ee[11]==""){
		$ee[11] = 0;
	}
	if($ff[11]==""){
		$ff[11] = 0;
	}
	if($ccav[11]==""){
		$ccav[11] = 0;
	}
	if($cc[12]==""){
		$cc[12] = 0;
	}
	if($dd[12]==""){
		$dd[12] = 0;
	}
	if($ee[12]==""){
		$ee[12] = 0;
	}
	if($ff[12]==""){
		$ff[12] = 0;
	}
	if($ccav[12]==""){
		$ccav[12] = 0;
	}
	if($cc[13]==""){
		$cc[13] = 0;
	}
	if($dd[13]==""){
		$dd[13] = 0;
	}
	if($ee[13]==""){
		$ee[13] = 0;
	}
	if($ff[13]==""){
		$ff[13] = 0;
	}
	if($ccav[13]==""){
		$ccav[13] = 0;
	}
	if($cc[14]==""){
		$cc[14] = 0;
	}
	if($dd[14]==""){
		$dd[14] = 0;
	}
	if($ee[14]==""){
		$ee[14] = 0;
	}
	if($ff[14]==""){
		$ff[14] = 0;
	}
	if($ccav[14]==""){
		$ccav[14] = 0;
	}
	if($cc[15]==""){
		$cc[15] = 0;
	}
	if($dd[15]==""){
		$dd[15] = 0;
	}
	if($ee[15]==""){
		$ee[15] = 0;
	}
	if($ff[15]==""){
		$ff[15] = 0;
	}
	if($ccav[15]==""){
		$ccav[15] = 0;
	}
$sub1 = array($cc[0],$dd[0],$ee[0],$ff[0],$ccav[0]);		
$sub2 = array($cc[1],$dd[1],$ee[1],$ff[1],$ccav[1]);
$sub3 = array($cc[2],$dd[2],$ee[2],$ff[2],$ccav[2]);
$sub4 = array($cc[3],$dd[3],$ee[3],$ff[3],$ccav[3]);
$sub5 = array($cc[4],$dd[4],$ee[4],$ff[4],$ccav[4]);
$sub6 = array($cc[5],$dd[5],$ee[5],$ff[5],$ccav[5]);
$sub7 = array($cc[6],$dd[6],$ee[6],$ff[6],$ccav[6]);	
$sub8 = array($cc[7],$dd[7],$ee[7],$ff[7],$ccav[7]);
$sub9 = array($cc[8],$dd[8],$ee[8],$ff[8],$ccav[8]);
$sub10 = array($cc[9],$dd[9],$ee[9],$ff[8],$ccav[9]);
$sub11 = array($cc[10],$dd[10],$ee[10],$ff[10],$ccav[10]);
$sub12 = array($cc[11],$dd[11],$ee[11],$ff[11],$ccav[11]);	
$sub13 = array($cc[12],$dd[12],$ee[12],$ff[12],$ccav[12]);	
$sub14 = array($cc[13],$dd[13],$ee[13],$ff[13],$ccav[13]);
$sub15 = array($cc[14],$dd[14],$ee[14],$ff[14],$ccav[14]);
$sub16 = array($cc[15],$dd[15],$ee[15],$ff[15],$ccav[15]);	
}
else if($subjcount=17){
	if($cc[0]==""){
		$cc[0] = 0;
	}
	if($dd[0]==""){
		$dd[0] = 0;
	}
	if($ee[0]==""){
		$ee[0] = 0;
	}
	if($ff[0]==""){
		$ff[0] = 0;
	}
	if($ccav[0]==""){
		$ccav[0] = 0;
	}
	if($cc[1]==""){
		$cc[1] = 0;
	}
	if($dd[1]==""){
		$dd[1] = 0;
	}
	if($ee[1]==""){
		$ee[1] = 0;
	}
	if($ff[1]==""){
		$ff[1] = 0;
	}
	if($ccav[1]==""){
		$ccav[1] = 0;
	}
	if($cc[2]==""){
		$cc[2] = 0;
	}
	if($dd[2]==""){
		$dd[2] = 0;
	}
	if($ee[2]==""){
		$ee[2] = 0;
	}
	if($ff[2]==""){
		$ff[2] = 0;
	}
	if($ccav[2]==""){
		$ccav[2] = 0;
	}
	if($cc[3]==""){
		$cc[3] = 0;
	}
	if($dd[3]==""){
		$dd[3] = 0;
	}
	if($ee[3]==""){
		$ee[3] = 0;
	}
	if($ff[3]==""){
		$ff[3] = 0;
	}
	if($ccav[3]==""){
		$ccav[3] = 0;
	}
	if($cc[4]==""){
		$cc[4] = 0;
	}
	if($dd[4]==""){
		$dd[4] = 0;
	}
	if($ee[4]==""){
		$ee[4] = 0;
	}
	if($ff[4]==""){
		$ff[4] = 0;
	}
	if($ccav[4]==""){
		$ccav[4] = 0;
	}
	if($cc[5]==""){
		$cc[5] = 0;
	}
	if($dd[5]==""){
		$dd[5] = 0;
	}
	if($ee[5]==""){
		$ee[5] = 0;
	}
	if($ff[5]==""){
		$ff[5] = 0;
	}
	if($ccav[5]==""){
		$ccav[5] = 0;
	}
	if($cc[6]==""){
		$cc[6] = 0;
	}
	if($dd[6]==""){
		$dd[6] = 0;
	}
	if($ee[6]==""){
		$ee[6] = 0;
	}
	if($ff[6]==""){
		$ff[6] = 0;
	}
	if($ccav[6]==""){
		$ccav[6] = 0;
	}
	if($cc[7]==""){
		$cc[7] = 0;
	}
	if($dd[7]==""){
		$dd[7] = 0;
	}
	if($ee[7]==""){
		$ee[7] = 0;
	}
	if($ff[7]==""){
		$ff[7] = 0;
	}
	if($ccav[7]==""){
		$ccav[7] = 0;
	}
	if($cc[8]==""){
		$cc[8] = 0;
	}
	if($dd[8]==""){
		$dd[8] = 0;
	}
	if($ee[8]==""){
		$ee[8] = 0;
	}
	if($ff[8]==""){
		$ff[8] = 0;
	}
	if($ccav[8]==""){
		$ccav[8] = 0;
	}
	if($cc[9]==""){
		$cc[9] = 0;
	}
	if($dd[9]==""){
		$dd[9] = 0;
	}
	if($ee[9]==""){
		$ee[9] = 0;
	}
	if($ff[9]==""){
		$ff[9] = 0;
	}
	if($ccav[9]==""){
		$ccav[9] = 0;
	}
	if($cc[10]==""){
		$cc[10] = 0;
	}
	if($dd[10]==""){
		$dd[10] = 0;
	}
	if($ee[10]==""){
		$ee[10] = 0;
	}
	if($ff[10]==""){
		$ff[10] = 0;
	}
	if($ccav[10]==""){
		$ccav[10] = 0;
	}
	if($cc[11]==""){
		$cc[11] = 0;
	}
	if($dd[11]==""){
		$dd[11] = 0;
	}
	if($ee[11]==""){
		$ee[11] = 0;
	}
	if($ff[11]==""){
		$ff[11] = 0;
	}
	if($ccav[11]==""){
		$ccav[11] = 0;
	}
	if($cc[12]==""){
		$cc[12] = 0;
	}
	if($dd[12]==""){
		$dd[12] = 0;
	}
	if($ee[12]==""){
		$ee[12] = 0;
	}
	if($ff[12]==""){
		$ff[12] = 0;
	}
	if($ccav[12]==""){
		$ccav[12] = 0;
	}
	if($cc[13]==""){
		$cc[13] = 0;
	}
	if($dd[13]==""){
		$dd[13] = 0;
	}
	if($ee[13]==""){
		$ee[13] = 0;
	}
	if($ff[13]==""){
		$ff[13] = 0;
	}
	if($ccav[13]==""){
		$ccav[13] = 0;
	}
	if($cc[14]==""){
		$cc[14] = 0;
	}
	if($dd[14]==""){
		$dd[14] = 0;
	}
	if($ee[14]==""){
		$ee[14] = 0;
	}
	if($ff[14]==""){
		$ff[14] = 0;
	}
	if($ccav[14]==""){
		$ccav[14] = 0;
	}
	if($cc[15]==""){
		$cc[15] = 0;
	}
	if($dd[15]==""){
		$dd[15] = 0;
	}
	if($ee[15]==""){
		$ee[15] = 0;
	}
	if($ff[15]==""){
		$ff[15] = 0;
	}
	if($ccav[15]==""){
		$ccav[15] = 0;
	}
	if($cc[16]==""){
		$cc[16] = 0;
	}
	if($dd[16]==""){
		$dd[16] = 0;
	}
	if($ee[16]==""){
		$ee[16] = 0;
	}
	if($ff[16]==""){
		$ff[16] = 0;
	}
	if($ccav[16]==""){
		$ccav[16] = 0;
	}
$sub1 = array($cc[0],$dd[0],$ee[0],$ff[0],$ccav[0]);		
$sub2 = array($cc[1],$dd[1],$ee[1],$ff[1],$ccav[1]);
$sub3 = array($cc[2],$dd[2],$ee[2],$ff[2],$ccav[2]);
$sub4 = array($cc[3],$dd[3],$ee[3],$ff[3],$ccav[3]);
$sub5 = array($cc[4],$dd[4],$ee[4],$ff[4],$ccav[4]);
$sub6 = array($cc[5],$dd[5],$ee[5],$ff[5],$ccav[5]);
$sub7 = array($cc[6],$dd[6],$ee[6],$ff[6],$ccav[6]);	
$sub8 = array($cc[7],$dd[7],$ee[7],$ff[7],$ccav[7]);
$sub9 = array($cc[8],$dd[8],$ee[8],$ff[8],$ccav[8]);
$sub10 = array($cc[9],$dd[9],$ee[9],$ff[8],$ccav[9]);
$sub11 = array($cc[10],$dd[10],$ee[10],$ff[10],$ccav[10]);
$sub12 = array($cc[11],$dd[11],$ee[11],$ff[11],$ccav[11]);	
$sub13 = array($cc[12],$dd[12],$ee[12],$ff[12],$ccav[12]);	
$sub14 = array($cc[13],$dd[13],$ee[13],$ff[13],$ccav[13]);
$sub15 = array($cc[14],$dd[14],$ee[14],$ff[14],$ccav[14]);
$sub16 = array($cc[15],$dd[15],$ee[15],$ff[15],$ccav[15]);	
$sub17 = array($cc[16],$dd[16],$ee[16],$ff[16],$ccav[16]);		
}
else if($subjcount=18){
	if($cc[0]==""){
		$cc[0] = 0;
	}
	if($dd[0]==""){
		$dd[0] = 0;
	}
	if($ee[0]==""){
		$ee[0] = 0;
	}
	if($ff[0]==""){
		$ff[0] = 0;
	}
	if($ccav[0]==""){
		$ccav[0] = 0;
	}
	if($cc[1]==""){
		$cc[1] = 0;
	}
	if($dd[1]==""){
		$dd[1] = 0;
	}
	if($ee[1]==""){
		$ee[1] = 0;
	}
	if($ff[1]==""){
		$ff[1] = 0;
	}
	if($ccav[1]==""){
		$ccav[1] = 0;
	}
	if($cc[2]==""){
		$cc[2] = 0;
	}
	if($dd[2]==""){
		$dd[2] = 0;
	}
	if($ee[2]==""){
		$ee[2] = 0;
	}
	if($ff[2]==""){
		$ff[2] = 0;
	}
	if($ccav[2]==""){
		$ccav[2] = 0;
	}
	if($cc[3]==""){
		$cc[3] = 0;
	}
	if($dd[3]==""){
		$dd[3] = 0;
	}
	if($ee[3]==""){
		$ee[3] = 0;
	}
	if($ff[3]==""){
		$ff[3] = 0;
	}
	if($ccav[3]==""){
		$ccav[3] = 0;
	}
	if($cc[4]==""){
		$cc[4] = 0;
	}
	if($dd[4]==""){
		$dd[4] = 0;
	}
	if($ee[4]==""){
		$ee[4] = 0;
	}
	if($ff[4]==""){
		$ff[4] = 0;
	}
	if($ccav[4]==""){
		$ccav[4] = 0;
	}
	if($cc[5]==""){
		$cc[5] = 0;
	}
	if($dd[5]==""){
		$dd[5] = 0;
	}
	if($ee[5]==""){
		$ee[5] = 0;
	}
	if($ff[5]==""){
		$ff[5] = 0;
	}
	if($ccav[5]==""){
		$ccav[5] = 0;
	}
	if($cc[6]==""){
		$cc[6] = 0;
	}
	if($dd[6]==""){
		$dd[6] = 0;
	}
	if($ee[6]==""){
		$ee[6] = 0;
	}
	if($ff[6]==""){
		$ff[6] = 0;
	}
	if($ccav[6]==""){
		$ccav[6] = 0;
	}
	if($cc[7]==""){
		$cc[7] = 0;
	}
	if($dd[7]==""){
		$dd[7] = 0;
	}
	if($ee[7]==""){
		$ee[7] = 0;
	}
	if($ff[7]==""){
		$ff[7] = 0;
	}
	if($ccav[7]==""){
		$ccav[7] = 0;
	}
	if($cc[8]==""){
		$cc[8] = 0;
	}
	if($dd[8]==""){
		$dd[8] = 0;
	}
	if($ee[8]==""){
		$ee[8] = 0;
	}
	if($ff[8]==""){
		$ff[8] = 0;
	}
	if($ccav[8]==""){
		$ccav[8] = 0;
	}
	if($cc[9]==""){
		$cc[9] = 0;
	}
	if($dd[9]==""){
		$dd[9] = 0;
	}
	if($ee[9]==""){
		$ee[9] = 0;
	}
	if($ff[9]==""){
		$ff[9] = 0;
	}
	if($ccav[9]==""){
		$ccav[9] = 0;
	}
	if($cc[10]==""){
		$cc[10] = 0;
	}
	if($dd[10]==""){
		$dd[10] = 0;
	}
	if($ee[10]==""){
		$ee[10] = 0;
	}
	if($ff[10]==""){
		$ff[10] = 0;
	}
	if($ccav[10]==""){
		$ccav[10] = 0;
	}
	if($cc[11]==""){
		$cc[11] = 0;
	}
	if($dd[11]==""){
		$dd[11] = 0;
	}
	if($ee[11]==""){
		$ee[11] = 0;
	}
	if($ff[11]==""){
		$ff[11] = 0;
	}
	if($ccav[11]==""){
		$ccav[11] = 0;
	}
	if($cc[12]==""){
		$cc[12] = 0;
	}
	if($dd[12]==""){
		$dd[12] = 0;
	}
	if($ee[12]==""){
		$ee[12] = 0;
	}
	if($ff[12]==""){
		$ff[12] = 0;
	}
	if($ccav[12]==""){
		$ccav[12] = 0;
	}
	if($cc[13]==""){
		$cc[13] = 0;
	}
	if($dd[13]==""){
		$dd[13] = 0;
	}
	if($ee[13]==""){
		$ee[13] = 0;
	}
	if($ff[13]==""){
		$ff[13] = 0;
	}
	if($ccav[13]==""){
		$ccav[13] = 0;
	}
	if($cc[14]==""){
		$cc[14] = 0;
	}
	if($dd[14]==""){
		$dd[14] = 0;
	}
	if($ee[14]==""){
		$ee[14] = 0;
	}
	if($ff[14]==""){
		$ff[14] = 0;
	}
	if($ccav[14]==""){
		$ccav[14] = 0;
	}
	if($cc[15]==""){
		$cc[15] = 0;
	}
	if($dd[15]==""){
		$dd[15] = 0;
	}
	if($ee[15]==""){
		$ee[15] = 0;
	}
	if($ff[15]==""){
		$ff[15] = 0;
	}
	if($ccav[15]==""){
		$ccav[15] = 0;
	}
	if($cc[16]==""){
		$cc[16] = 0;
	}
	if($dd[16]==""){
		$dd[16] = 0;
	}
	if($ee[16]==""){
		$ee[16] = 0;
	}
	if($ff[16]==""){
		$ff[16] = 0;
	}
	if($ccav[16]==""){
		$ccav[16] = 0;
	}
	if($cc[17]==""){
		$cc[17] = 0;
	}
	if($dd[17]==""){
		$dd[17] = 0;
	}
	if($ee[17]==""){
		$ee[17] = 0;
	}
	if($ff[17]==""){
		$ff[17] = 0;
	}
	if($ccav[17]==""){
		$ccav[17] = 0;
	}
$sub1 = array($cc[0],$dd[0],$ee[0],$ff[0],$ccav[0]);		
$sub2 = array($cc[1],$dd[1],$ee[1],$ff[1],$ccav[1]);
$sub3 = array($cc[2],$dd[2],$ee[2],$ff[2],$ccav[2]);
$sub4 = array($cc[3],$dd[3],$ee[3],$ff[3],$ccav[3]);
$sub5 = array($cc[4],$dd[4],$ee[4],$ff[4],$ccav[4]);
$sub6 = array($cc[5],$dd[5],$ee[5],$ff[5],$ccav[5]);
$sub7 = array($cc[6],$dd[6],$ee[6],$ff[6],$ccav[6]);	
$sub8 = array($cc[7],$dd[7],$ee[7],$ff[7],$ccav[7]);
$sub9 = array($cc[8],$dd[8],$ee[8],$ff[8],$ccav[8]);
$sub10 = array($cc[9],$dd[9],$ee[9],$ff[8],$ccav[9]);
$sub11 = array($cc[10],$dd[10],$ee[10],$ff[10],$ccav[10]);
$sub12 = array($cc[11],$dd[11],$ee[11],$ff[11],$ccav[11]);	
$sub13 = array($cc[12],$dd[12],$ee[12],$ff[12],$ccav[12]);	
$sub14 = array($cc[13],$dd[13],$ee[13],$ff[13],$ccav[13]);
$sub15 = array($cc[14],$dd[14],$ee[14],$ff[14],$ccav[14]);
$sub16 = array($cc[15],$dd[15],$ee[15],$ff[15],$ccav[15]);	
$sub17 = array($cc[16],$dd[16],$ee[16],$ff[16],$ccav[16]);
$sub18 = array($cc[17],$dd[17],$ee[17],$ff[17],$ccav[17]);				
}
else{
	if($cc[0]==""){
		$cc[0] = 0;
	}
	if($dd[0]==""){
		$dd[0] = 0;
	}
	if($av[0]==""){
		$av[0] = 0;
	}
	if($ccav[0]==""){
		$ccav[0] = 0;
	}
	if($cc[1]==""){
		$cc[1] = 0;
	}
	if($dd[1]==""){
		$dd[1] = 0;
	}
	if($av[1]==""){
		$av[1] = 0;
	}
	if($ccav[1]==""){
		$ccav[1] = 0;
	}
	if($cc[2]==""){
		$cc[2] = 0;
	}
	if($dd[2]==""){
		$dd[2] = 0;
	}
	if($av[2]==""){
		$av[2] = 0;
	}
	if($ccav[2]==""){
		$ccav[2] = 0;
	}
	if($cc[3]==""){
		$cc[3] = 0;
	}
	if($dd[3]==""){
		$dd[3] = 0;
	}
	if($av[3]==""){
		$av[3] = 0;
	}
	if($ccav[3]==""){
		$ccav[3] = 0;
	}
	if($cc[4]==""){
		$cc[4] = 0;
	}
	if($dd[4]==""){
		$dd[4] = 0;
	}
	if($av[4]==""){
		$av[4] = 0;
	}
	if($ccav[4]==""){
		$ccav[4] = 0;
	}
	if($cc[5]==""){
		$cc[5] = 0;
	}
	if($dd[5]==""){
		$dd[5] = 0;
	}
	if($av[5]==""){
		$av[5] = 0;
	}
	if($ccav[5]==""){
		$ccav[5] = 0;
	}
	if($cc[6]==""){
		$cc[6] = 0;
	}
	if($dd[6]==""){
		$dd[6] = 0;
	}
	if($av[6]==""){
		$av[6] = 0;
	}
	if($ccav[6]==""){
		$ccav[6] = 0;
	}
	if($cc[7]==""){
		$cc[7] = 0;
	}
	if($dd[7]==""){
		$dd[7] = 0;
	}
	if($av[7]==""){
		$av[7] = 0;
	}
	if($ccav[7]==""){
		$ccav[7] = 0;
	}
	if($cc[8]==""){
		$cc[8] = 0;
	}
	if($dd[8]==""){
		$dd[8] = 0;
	}
	if($av[8]==""){
		$av[8] = 0;
	}
	if($ccav[8]==""){
		$ccav[8] = 0;
	}
	if($cc[9]==""){
		$cc[9] = 0;
	}
	if($dd[9]==""){
		$dd[9] = 0;
	}
	if($av[9]==""){
		$av[9] = 0;
	}
	if($ccav[9]==""){
		$ccav[9] = 0;
	}
	if($cc[10]==""){
		$cc[10] = 0;
	}
	if($dd[10]==""){
		$dd[10] = 0;
	}
	if($av[10]==""){
		$av[10] = 0;
	}
	if($ccav[10]==""){
		$ccav[10] = 0;
	}
	if($cc[11]==""){
		$cc[11] = 0;
	}
	if($dd[11]==""){
		$dd[11] = 0;
	}
	if($av[11]==""){
		$av[11] = 0;
	}
	if($ccav[11]==""){
		$ccav[11] = 0;
	}
	if($cc[12]==""){
		$cc[12] = 0;
	}
	if($dd[12]==""){
		$dd[12] = 0;
	}
	if($av[12]==""){
		$av[12] = 0;
	}
	if($ccav[12]==""){
		$ccav[12] = 0;
	}
	if($cc[13]==""){
		$cc[13] = 0;
	}
	if($dd[13]==""){
		$dd[13] = 0;
	}
	if($av[13]==""){
		$av[13] = 0;
	}
	if($ccav[13]==""){
		$ccav[13] = 0;
	}
	if($cc[14]==""){
		$cc[14] = 0;
	}
	if($dd[14]==""){
		$dd[14] = 0;
	}
	if($av[14]==""){
		$av[14] = 0;
	}
	if($ccav[14]==""){
		$ccav[14] = 0;
	}
$sub1 = array($cc[0],$dd[0],$ee[0],$ff[0],$ccav[0]);		
$sub2 = array($cc[1],$dd[1],$ee[1],$ff[1],$ccav[1]);
$sub3 = array($cc[2],$dd[2],$ee[2],$ff[2],$ccav[2]);
$sub4 = array($cc[3],$dd[3],$ee[3],$ff[3],$ccav[3]);
$sub5 = array($cc[4],$dd[4],$ee[4],$ff[4],$ccav[4]);
$sub6 = array($cc[5],$dd[5],$ee[5],$ff[5],$ccav[5]);
$sub7 = array($cc[6],$dd[6],$ee[6],$ff[6],$ccav[6]);	
$sub8 = array($cc[7],$dd[7],$ee[7],$ff[7],$ccav[7]);
$sub9 = array($cc[8],$dd[8],$ee[8],$ff[8],$ccav[8]);
$sub10 = array($cc[9],$dd[9],$ee[9],$ff[8],$ccav[9]);
$sub11 = array($cc[10],$dd[10],$ee[10],$ff[10],$ccav[10]);
$sub12 = array($cc[11],$dd[11],$ee[11],$ff[11],$ccav[11]);	
$sub13 = array($cc[12],$dd[12],$ee[12],$ff[12],$ccav[12]);	
$sub14 = array($cc[13],$dd[13],$ee[13],$ff[13],$ccav[13]);
$sub15 = array($cc[14],$dd[14],$ee[14],$ff[14],$ccav[14]);
$sub16 = array($cc[15],$dd[15],$ee[15],$ff[15],$ccav[15]);	
$sub17 = array($cc[16],$dd[16],$ee[16],$ff[16],$ccav[16]);
$sub18 = array($cc[17],$dd[17],$ee[17],$ff[17],$ccav[17]);	
$sub19 = array($cc[18],$dd[18],$ee[18],$ff[18],$ccav[18]);
}
?>

<br><br>
<div id="chart1" class="myChart" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
<script>
    $(document).ready(function() {
        // create canvas function from highcharts example http://jsfiddle.net/highcharts/PDnmQ/
        (function(H) {
            H.Chart.prototype.createCanvas = function(divId) {
                var svg = this.getSVG(),
                    width = parseInt(svg.match(/width="([0-9]+)"/)[1]),
                    height = parseInt(svg.match(/height="([0-9]+)"/)[1]),
                    canvas = document.createElement('canvas');

                canvas.setAttribute('width', width);
                canvas.setAttribute('height', height);

                if (canvas.getContext && canvas.getContext('2d')) {

                    canvg(canvas, svg);

                    return canvas.toDataURL("image/jpeg");

                } 
                else {
                    alert("Your browser doesn't support this feature, please use a modern browser");
                    return false;
                }

            }
        }(Highcharts));

        $('#export_all').click(function() {
            var doc = new jsPDF();

            // chart height defined here so each chart can be palced
            // in a different position
            var chartHeight = 80;

            // All units are in the set measurement for the document
            // This can be changed to "pt" (points), "mm" (Default), "cm", "in"
            doc.setFontSize(40);
            doc.text(35, 25, "");

            //loop through each chart
            $('.myChart').each(function(index) {
                var imageData = $(this).highcharts().createCanvas();

                // add image to doc, if you have lots of charts,
                // you will need to check if you have gone bigger 
                // than a page and do doc.addPage() before adding 
                // another image.

                /**
                 * addImage(imagedata, type, x, y, width, height)
                 */
                doc.addImage(imageData, 'JPEG', 45, (index * chartHeight) + 40, 120, chartHeight);
            });


            //save with name
            doc.save('scoreschart.pdf');
        });
		
		var classs = <?php echo json_encode($classs); ?>;
		var stuname = <?php echo json_encode($stuname); ?>;
		 var term = <?php echo json_encode($term); ?>;
		 var arms = <?php echo json_encode($arms); ?>;
		var sublabcount = <?php echo json_encode($subjcount); ?>;
		var sublab1 = <?php echo json_encode($su[0]); ?>;
		var sublab2 = <?php echo json_encode($su[1]); ?>;
		var sublab3 = <?php echo json_encode($su[2]); ?>;
		var sublab4 = <?php echo json_encode($su[3]); ?>;	
		var sublab5 = <?php echo json_encode($su[4]); ?>;
		var sublab6 = <?php echo json_encode($su[5]); ?>;
		var sublab7 = <?php echo json_encode($su[6]); ?>;
		var sublab8 = <?php echo json_encode($su[7]); ?>;
		var sublab9 = <?php echo json_encode($su[8]); ?>;	
		var sublab10 = <?php echo json_encode($su[9]); ?>;
		var sublab11 = <?php echo json_encode($su[10]); ?>;	
		var sublab12 = <?php echo json_encode($su[11]); ?>;
		var sublab13 = <?php echo json_encode($su[12]); ?>;
		var sublab14 = <?php echo json_encode($su[13]); ?>;	
		var sublab15 = <?php echo json_encode($su[14]); ?>;
		var sublab16 = <?php echo json_encode($su[15]); ?>;
		var sublab17 = <?php echo json_encode($su[16]); ?>;
		var sublab18 = <?php echo json_encode($su[17]); ?>;
		var sublab19 = <?php echo json_encode($su[18]); ?>;
		
		var s1 = <?php echo json_encode($sub1); ?>;	
		var s2 = <?php echo json_encode($sub2); ?>;	
		var s3 = <?php echo json_encode($sub3); ?>;	
		var s4 = <?php echo json_encode($sub4); ?>;	
		var s5 = <?php echo json_encode($sub5); ?>;	
		var s6 = <?php echo json_encode($sub6); ?>;	
		var s7 = <?php echo json_encode($sub7); ?>;	
		var s8 = <?php echo json_encode($sub8); ?>;	
		var s9 = <?php echo json_encode($sub9); ?>;	
		var s10 = <?php echo json_encode($sub10); ?>;	
		var s11 = <?php echo json_encode($sub11); ?>;	
		var s12 = <?php echo json_encode($sub12); ?>;	
		var s13 = <?php echo json_encode($sub13); ?>;	
		var s14 = <?php echo json_encode($sub14); ?>;	
		var s15 = <?php echo json_encode($sub15); ?>;
		var s16 = <?php echo json_encode($sub16); ?>;	
		var s17 = <?php echo json_encode($sub17); ?>;
		var s18 = <?php echo json_encode($sub18); ?>;
		var s19 = <?php echo json_encode($sub19); ?>;
		
		var arraysubcount2 = JSON.parse(sublabcount);
		var array1 = JSON.parse("[" + s1 + "]");
		var array2 = JSON.parse("[" + s2 + "]");
		var array3 = JSON.parse("[" + s3 + "]");
		var array4 = JSON.parse("[" + s4 + "]");
		var array5 = JSON.parse("[" + s5 + "]");
		var array6 = JSON.parse("[" + s6 + "]");
		var array7 = JSON.parse("[" + s7 + "]");
		var array8 = JSON.parse("[" + s8 + "]");
		var array9 = JSON.parse("[" + s9 + "]");
		var array10 = JSON.parse("[" + s10 + "]");
		var array11 = JSON.parse("[" + s11 + "]");
		var array12 = JSON.parse("[" + s12 + "]");
		var array13 = JSON.parse("[" + s13 + "]");
		var array14 = JSON.parse("[" + s14 + "]");
		var array15 = JSON.parse("[" + s15 + "]");
		var array16 = JSON.parse("[" + s16 + "]");
		var array17 = JSON.parse("[" + s17 + "]");
		var array18 = JSON.parse("[" + s18 + "]");
		var array19 = JSON.parse("[" + s19 + "]");
		if(arraysubcount2 == 1){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }];
		};
		if(arraysubcount2 == 2){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }];
		};
		if(arraysubcount2 == 3){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }];
		};
		if(arraysubcount2 == 4){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }];
		};
		if(arraysubcount2 == 5){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }];
		};
		if(arraysubcount2 == 6){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }];
		};
		if(arraysubcount2 == 7){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }];
		};
		if(arraysubcount2 == 8){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }, {
                name: sublab8,
                data: array8
            }];
		};
		if(arraysubcount2 == 9){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }, {
                name: sublab8,
                data: array8
            }, {
                name: sublab9,
                data: array9
            }];
		};
		if(arraysubcount2 == 10){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }, {
                name: sublab8,
                data: array8
            }, {
                name: sublab9,
                data: array9
            }, {
                name: sublab10,
                data: array10
            }];
		};
		if(arraysubcount2 == 11){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }, {
                name: sublab8,
                data: array8
            }, {
                name: sublab9,
                data: array9
            }, {
                name: sublab10,
                data: array10
            }, {
                name: sublab11,
                data: array11
            }];
		};
		if(arraysubcount2 == 12){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }, {
                name: sublab8,
                data: array8
            }, {
                name: sublab9,
                data: array9
            }, {
                name: sublab10,
                data: array10
            }, {
                name: sublab11,
                data: array11
            }, {
                name: sublab12,
                data: array12
            }];
		};
		if(arraysubcount2 == 13){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }, {
                name: sublab8,
                data: array8
            }, {
                name: sublab9,
                data: array9
            }, {
                name: sublab10,
                data: array10
            }, {
                name: sublab11,
                data: array11
            }, {
                name: sublab12,
                data: array12
            }, {
                name: sublab13,
                data: array13
            }];
		};
		if(arraysubcount2 == 14){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }, {
                name: sublab8,
                data: array8
            }, {
                name: sublab9,
                data: array9
            }, {
                name: sublab10,
                data: array10
            }, {
                name: sublab11,
                data: array11
            }, {
                name: sublab12,
                data: array12
            }, {
                name: sublab13,
                data: array13
            }, {
                name: sublab14,
                data: array14
            }];
		};
		if(arraysubcount2 == 15){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }, {
                name: sublab8,
                data: array8
            }, {
                name: sublab9,
                data: array9
            }, {
                name: sublab10,
                data: array10
            }, {
                name: sublab11,
                data: array11
            }, {
                name: sublab12,
                data: array12
            }, {
                name: sublab13,
                data: array13
            }, {
                name: sublab14,
                data: array14
            }, {
                name: sublab15,
                data: array15
            }];
		};
		if(arraysubcount2 == 16){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }, {
                name: sublab8,
                data: array8
            }, {
                name: sublab9,
                data: array9
            }, {
                name: sublab10,
                data: array10
            }, {
                name: sublab11,
                data: array11
            }, {
                name: sublab12,
                data: array12
            }, {
                name: sublab13,
                data: array13
            }, {
                name: sublab14,
                data: array14
            }, {
                name: sublab15,
                data: array15
            }, {
                name: sublab16,
                data: array16
            }];
		};
		if(arraysubcount2 == 17){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }, {
                name: sublab8,
                data: array8
            }, {
                name: sublab9,
                data: array9
            }, {
                name: sublab10,
                data: array10
            }, {
                name: sublab11,
                data: array11
            }, {
                name: sublab12,
                data: array12
            }, {
                name: sublab13,
                data: array13
            }, {
                name: sublab14,
                data: array14
            }, {
                name: sublab15,
                data: array15
            }, {
                name: sublab16,
                data: array16
            }, {
                name: sublab17,
                data: array17
            }];
		};
		if(arraysubcount2 == 18){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }, {
                name: sublab8,
                data: array8
            }, {
                name: sublab9,
                data: array9
            }, {
                name: sublab10,
                data: array10
            }, {
                name: sublab11,
                data: array11
            }, {
                name: sublab12,
                data: array12
            }, {
                name: sublab13,
                data: array13
            }, {
                name: sublab14,
                data: array14
            }, {
                name: sublab15,
                data: array15
            }, {
                name: sublab16,
                data: array16
            }, {
                name: sublab17,
                data: array17
            }, {
                name: sublab18,
                data: array18
            }];
		};
		if(arraysubcount2 == 19){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }, {
                name: sublab8,
                data: array8
            }, {
                name: sublab9,
                data: array9
            }, {
                name: sublab10,
                data: array10
            }, {
                name: sublab11,
                data: array11
            }, {
                name: sublab12,
                data: array12
            }, {
                name: sublab13,
                data: array13
            }, {
                name: sublab14,
                data: array14
            }, {
                name: sublab15,
                data: array15
            }, {
                name: sublab16,
                data: array16
            }, {
                name: sublab17,
                data: array17
            }, {
                name: sublab18,
                data: array18
            }, {
                name: sublab19,
                data: array19
            }];
		};
        $('#chart1').highcharts({
            navigation: {
                buttonOptions: {
                    enabled: false
                }
            },
colors: [
'#C72D7A', 
'#e7731d',
'#1c74be',
'#d4291f',
'#ff0000',
'#2ecc71',
'indigo', 
'cyan',
'green', 
'yellow', 
'black', 
'orange', 
'pink', 
'brown', 
'grey', 
'violet',
'gold', 
'#DB843D', 
'#92A8CD',
'#CAB14B', 
'#48B8CA', 
'#A47D7C', 
'#B77C7B',
'#B5CA92'
],
plotOptions: 
	{column: {colorByPoint: true}
	},	
            title: {
                text: 'A LINE GRAPH OF '+stuname.toUpperCase()+'\'S MIDTERM PERFORMANCE ACROSS SUBJECTS IN '+classs.toUpperCase()+' '+arms.toUpperCase(),
                x: -20 //center
            },
            subtitle: {
                text: 'IN '+term.toUpperCase(),
                x: -20
            },
            xAxis: {
                categories: ['Classwork (30)', 'Homework (30)', 'Test (40)', 'Total (%)', 'Class Av. (%)'
				]
            },
            yAxis: {
                title: {
                    text: 'Scores'
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                valueSuffix: ''
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle',
                borderWidth: 0
            },
            series: varseries
        });
		
    });
    </script>


<button id="export_all" class="pbutton" >Save as PDF</button>
<form action="getresultmid.php" method="POST">
<?php
echo '<input  style="display: none;" name="student_name" type="text" value="'.$student_name. '">';
echo '<input  style="display: none;"  name="class_name" type="text" value="'.$class_name. '">';
echo '<input   style="display: none;"  name="year" type="text" value="'.$year. '">';
echo '<input  style="display: none;" name="term" type="text" value="'.$term. '">';
echo '<input  style="display: none;" name="sign" type="text" value="'.$sign. '">';
echo '<input  style="display: none;" name="arms" type="text" value="'.$arms. '">';
echo '<input  style="display: none;" name="byarm" type="text" value="'.$byarm. '">';
echo '<input class="pbutton" type="submit" name="halftermsub" value="Back" />';
echo '</form>';	
?>
</form>
<?php
include("footer.php");
?>
</body>
</html>
