<?php 
session_start();
include("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
<link href="table/css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
<script src="table/js/jquery.js" type="text/javascript"></script>
<script src="table/js/bootstrap.js" type="text/javascript"></script>
<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/jquery.dataTables.js"></script>
<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/DT_bootstrap.js"></script>


 <script>
function confirmationDelete(anchor)
{
   var conf = confirm('Are you sure want to delete this record?');
   if(conf)
      window.location=anchor.attr("href");
}
</script> 
<script type="text/javascript">
$(document).ready(function()
{
$(".edit_tr").click(function()
{
var ID=$(this).attr('id');
$("#student_name_"+ID).hide();
$("#sex_"+ID).hide();
$("#student_name_input_"+ID).show();
$("#sex_"+ID).show();
}).change(function()
{
var ID=$(this).attr('id');
var student_name=$("#student_name_input_"+ID).val();
var sex=$("#sex_input_"+ID).val();
var dataString = 'regstu_id='+ ID +'&student_name='+student_name+'&sex='+sex;
$("#student_name_"+ID).html('<img src="load.gif" />');


if(student_name.length && sex.length>0)
{
$.ajax({
type: "POST",
url: "addstudentbyadmin_exec.php",
data: dataString,
cache: false,
success: function(html)
{

$("#student_name_"+ID).html(student_name);
$("#sex_"+ID).html(sex);
}
});
}
else
{
alert('Enter something.');
}

});

$(".editbox").mouseup(function() 
{
return false
});

$(document).mouseup(function()
{
$(".editbox").hide();
$(".text").show();
});

});
</script>


 <style>
.editbox
{
display: none;
}
.edit_tr: hover
{
background: url(edit.png) right no-repeat #80C8E5;
cursor: pointer;
}
td
{
padding: 3px;
}
.editbox
{
font-size:12px;
background-color:#ffffcc;
border:solid 1px #000;
padding:4px;
}
</style>     
   
   <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>
   <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
</head>
<body>
<?php
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
else{header("location: logout.php");}
?>        

<br>
<div class="row-fluid" style="width:100%;">
    <br><br><br>
	        <div class="span12">
	            <div class="container">				
		<table style="float:left;"cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
				
			<thead><tr>
			<th>Photo</th><th>Student</th><th>Sex</th><th>Delete</th>
			</thead></tr>
<?php
include "connection.php";

if(isset($_POST['submit8']) || isset($_POST['submitimg'])){
        $student_name = $_POST['student_name'];
        $sex = $_POST['sex'];
		$caaz = $_POST['caa'];
		$yoa = $_POST['yoa'];
		$admno = $_POST['admno'];
		$reason = $_POST['reason'];
		
		if($caaz=='Primary 1'){
			$caa = 'Year 1';
		}
		elseif($caaz=='Primary 2'){
			$caa = 'Year 2';
		}
		elseif($caaz=='Primary 3'){
			$caa = 'Year 3';
		}
		elseif($caaz=='Primary 4'){
			$caa = 'Year 4';
		}
		elseif($caaz=='Primary 5'){
			$caa = 'Year 5';
		}
		elseif($caaz=='Primary 6'){
			$caa = 'Year 6';
		}
		elseif($caaz=='JS1'){
			$caa = 'Year 7';
		}
		elseif($caaz=='JS2'){
			$caa = 'Year 8';
		}
		elseif($caaz=='JS3'){
			$caa = 'Year 9';
		}
		elseif($caaz=='SS1'){
			$caa = 'Year 10';
		}
		elseif($caaz=='SS2'){
			$caa = 'Year 11';
		}
		elseif($caaz=='SS3'){
			$caa = 'Year 12';
		}
		else{
			$caa = $caaz;
		}
$result = mysqli_query($db, "SELECT regstu.regstu_id, regstu.student_name, regstu.sex, regstu.caa, regstu.yoa, regstu.admno, regstu.reason, regstu.dob, regstu.house, regstu.school, img.img_id, img.student_name, img.img, img.school FROM regstu INNER JOIN img ON regstu.student_name=img.student_name WHERE regstu.caa='$caa' AND regstu.yoa='$yoa' AND regstu.school='".$_SESSION["school"]."'");
while ($row = mysqli_fetch_assoc($result)) {
	$regstu_id = $row['regstu_id'];
	echo '<tr class="edit_tr" id="'.$regstu_id.'">';
echo '<td><a href="updatestudentsbyclassadminimg.php?img_id='.$row['img_id'].'">Click to update image and house which is '.$row['house'].'<br><img src="'.$row['img'].'" alt="no image" height="60" width="60" /></a></td>';	
echo '<td class="edit_td"><span id="student_name_'.$id.'" class="text">'.$row['student_name'].'</span>';
echo '<input type="text" class="editbox" style="display: none;" id="student_name_input_'.$id.'" name="student_name" value="'.$row['student_name'].'" /></td>';	
echo '<td class="edit_td"><span id="sex_'.$id.'" class="text">'.$row['sex'].'</span>';
echo '<input type="text" class="editbox" style="display: none;" id="sex_input_'.$id.'" name="sex" value="'.$row['sex'].'" /></td>';	
echo '<td><a onClick="javascript:confirmationDelete($(this));return false;" href="delstudentadmin.php?regstu_id='.$row['regstu_id'].'"><img src="table/deletee.png" alt="no image" height="30" width="30" /></a></td>';
'</tr>';
}
}
?>
</table>
</div></div></div>
<?php
include("footer.php");
?>
 </body>
</html>
