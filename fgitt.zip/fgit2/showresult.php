<?php
	include("check.php");	
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Home</title>
<link rel="stylesheet" href="style.css" type="text/css" />

</head>

<body>
<h1 class="hello">Hello, <em><?php echo $login_user;?>!</em></h1>



<form action="showresult2.php" method="post" enctype="multipart/form-data">
<center>
 <div>
	<label><select style="width:15%;" name="class_name" id="class" required ><br>
                   
                    <?php
	include "connection.php";
	$result = mysqli_query($db, "SELECT * FROM classes");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['class_name'].'">';
								echo $row['class_name'];
								echo '</option>';
							}
						?>
      </select>
	  
	  <br><br>
	  <select style="width:15%;" name="year" id="year" required ><br>
                   
                    <?php
	include "connection.php";
	$result = mysqli_query($db, "SELECT * FROM years");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['year'].'">';
								echo $row['year'];
								echo '</option>';
							}
						?>
      </select>
	  
	  
	   <br><br>
	  <select style="width:15%;" name="term" id="term" required ><br>
                   
                    <?php
	include "connection.php";
	$result = mysqli_query($db, "SELECT * FROM terms");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['term'].'">';
								echo $row['term'];
								echo '</option>';
							}
						?>
      </select>
	  
	  <br><br>
	  <select style="width:15%;" name="student_name" id="student_name" required ><br>
                   
                    <?php
	include "connection.php";
	$result = mysqli_query($db, "SELECT DISTINCT(student_name) FROM students");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['student_name'].'">';
								echo $row['student_name'];
								echo '</option>';
							}
						?>
      </select>
	  
	  <br><br>
	  </label>
	  
  <label><br><br>
      <input type="submit" class="button" name="btn-upload" value="Submit Form" />
    </label>

  </div>
  </center><BR><BR>
</form><br>


<a href="logout.php" style="font-size:18px">Logout?</a>
</body>
</html>