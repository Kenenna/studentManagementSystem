<?php
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
	
$teacher_id = $_POST['teacher_id'];
$teacher_name = $_POST['teacher_name'];
$year = $_POST['year'];
$sql1=mysqli_query($db,"SELECT * FROM principal WHERE  teacher_id='$teacher_id' AND teacher_name='$teacher_name' AND year='$year' AND school='".$_SESSION["school"]."'");
while($rowsig = mysqli_fetch_assoc($sql1)){
	$sig2[] = $rowsig['sig'];
}
$sig = current($sig2);
if($sql1){
	if($sig == 1){
	echo "YES";
	//echo $teacher_id;
	}else{
	echo "NO";
	//echo $teacher_id;
	} 
}	
else{
	//echo "not updated";
	//echo '<meta content="2;attend.php" http-equiv="refresh" />';
	echo "We could not retrieve the signature permission status.";
}
?>