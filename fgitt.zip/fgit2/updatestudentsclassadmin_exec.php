<?php
include "connection.php";
if (isset($_REQUEST['btn-upload'])) {
$regstu_id = $_REQUEST['regstu_id'];
$student_name = $_REQUEST['student_name'];
$sex = $_REQUEST['sex'];
$caa = $_REQUEST['caa'];
$yoa = $_REQUEST['yoa'];
$admno = $_REQUEST['admno'];
$reason = $_REQUEST['reason'];

$query =("UPDATE regstu SET
student_name='$student_name', sex='$sex', caa='$caa', yoa='$yoa', admno='$admno', reason='$reason' WHERE regstu_id='$regstu_id'");

if (!mysqli_query ($db,$query) )
			{
			echo '<img src="../images/492.png" /> &nbsp;! data not updated';
			echo '<meta content="2;index.php" http-equiv="refresh" />';	
			die (mysqli_error());
			}else{
	
		echo '<img src="../images/492.png" /> &nbsp;! data updated successfully';
		echo '<meta content="2;index.php" http-equiv="refresh" />';
			}
}
?>