<?php
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";

$id = $_POST['id'];	
$student_name = $_POST['student_name'];
$attend = $_POST['attend'];

for ($i = 0; $i <= (count($id)-1); $i++){
$sql1=mysqli_query($db,"UPDATE attend SET attend='$attend[$i]' WHERE id='$id[$i]' AND school='".$_SESSION["school"]."'");
}

if($sql1){
	//echo "Attendance updated successfully";
	//echo '<meta content="2;attend.php" http-equiv="refresh" />';
	echo 1;
}	
else{
	//echo "not updated";
	//echo '<meta content="2;attend.php" http-equiv="refresh" />';
	echo 0;
}
?>