<?php
	session_start();
	include("auth.php"); //include auth.php file on all secure pages
	include "connection.php";
	include("auth.php");
	include('db.php');	
$id = $_POST['id'];	
//$student_name = $_POST['student_name'];
//$class = $_POST['class'];
//$year = $_POST['year'];
//$term = $_POST['term'];
//$house = $_POST['house'];
$hpcomment = $_POST['hpcomment'];

for ($i = 0; $i <= (count($id)-1); $i++){
$sql1=mysqli_query($db,"UPDATE studentsbyclass SET hpcomment='$hpcomment[$i]' WHERE id='$id[$i]' AND school='".$_SESSION["school"]."'");
}
if($sql1){
	//echo "scores updated successfully";
	//echo '<meta content="2;update-score-mid.php" http-equiv="refresh" />';
echo 1;
}	
else{
//echo "not updated";
//echo '<meta content="2;update-score-mid.php" http-equiv="refresh" />';
echo 0;
}
?>