<?php
########## MySql details (Replace with yours) #############
$username = "thetutor_user"; //mysql username
$password = "Uandme_12"; //mysql password
$hostname = "localhost"; //hostname
$databasename = 'thetutor_db'; //databasename

//connect to database
$mysqli = new mysqli($hostname, $username, $password, $databasename);
?>