<?php
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
	
$princiid = $_POST['princiid'];
$priname = $_POST['priname'];
$year = $_POST['year'];

$result = mysqli_query($db, "SELECT * FROM principal where teacher_id='$princiid' AND year='$year' AND school='".$_SESSION["school"]."'");
while($row = mysqli_fetch_assoc($result)){ 
$img2[] = $row['img'];
}
$img = current($img2);
$resultcount = mysqli_num_rows($result);	
	
$sourcePath = $_FILES['userImage']['tmp_name'];
$targetPath = "images/".$_FILES['userImage']['name'];

if(move_uploaded_file($sourcePath,$targetPath)){	
if($resultcount==0){
$sql1=mysqli_query($db,"INSERT into `principal` (teacher_id,teacher_name,year,img,school) VALUES ('$princiid','$priname','$year','$targetPath','".$_SESSION["school"]."')");
}
else{
$sql2=mysqli_query($db,"UPDATE principal SET year='$year', img='$targetPath' WHERE teacher_id='$princiid' AND school='".$_SESSION["school"]."'");	
}
}
else{
if($resultcount==0){
$sql1=mysqli_query($db,"INSERT into `principal` (teacher_id,teacher_name,year,img,school) VALUES ('$princiid','$priname','$year','$targetPath','".$_SESSION["school"]."')");
}
else{
$sql2=mysqli_query($db,"UPDATE principal SET year='$year', img='$img' WHERE teacher_id='$princiid' AND school='".$_SESSION["school"]."'");	
}	
}

if($sql1){
	//echo "Attendance updated successfully";
	//echo '<meta content="2;attend.php" http-equiv="refresh" />';
	echo 1;
}
else if($sql2){
	echo 1;
}	
else{
	//echo "not updated";
	//echo '<meta content="2;attend.php" http-equiv="refresh" />';
	echo 0;
	//echo $year;
}
?>