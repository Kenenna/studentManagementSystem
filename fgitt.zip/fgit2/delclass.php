<?php
include "connection.php";
$id=$_REQUEST['id']; 


$query = "DELETE FROM studentsbyclass WHERE id=".$_GET['id'];

		if (!mysqli_query ($db,$query) )
			{
			echo '<img src="table/del.jpg" /> &nbsp;! data not deleted';
			echo '<meta content="2;formclasses.php" http-equiv="refresh" />';	
			die (mysqli_error());
			}else{
	
		echo '<img src="table/492.png" /> &nbsp;! data deleted successfully';
		echo '<meta content="2;formclasses.php" http-equiv="refresh" />';
			}
?>
