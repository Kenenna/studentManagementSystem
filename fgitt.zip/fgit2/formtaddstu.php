<?php 
include("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Add students by class</title>
<script src="table/js/jquery.js" type="text/javascript"></script>
 <script src="boots.js" type="text/javascript"></script>
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" />

<script type="text/javascript">
$(document).ready(function() {
	$("[name=student_name]").addClass("classs");
	$("[name=year]").addClass("classs");
	$("[name=class]").addClass("classs");
	$("[name=term]").addClass("classs");
	$("[name=formt]").addClass("classs");
	$("[name=arm]").addClass("classs");
	//##### send add record Ajax request to response.php #########
	$("#FormSubmit").click(function (e) {
			e.preventDefault();
			e.stopPropagation();
			if(($("#student_nameText").val()==='') || ($("#yearText").val()===''))
			{
				alert("You need to get class, year and term of student!");
				window.location = "formclasses.php";
				return false;
			}
			
			$("#FormSubmit").hide(); //hide submit button
			$("#LoadingImage").show(); //show loading image
			
		 	var myData = 'student_name_txt='+ $("#student_nameText").val() + '&year_txt='+ $("#yearText").val() + '&class_txt='+ $("#classText").val() + '&term_txt='+ $("#termText").val() + '&formt_txt='+ $("#formtText").val() + '&arm_txt='+ $("#armText").val(); //build a post data structure
			
			jQuery.ajax({
			type: "POST", // HTTP method POST or GET
			url: "response.php", //Where to make Ajax calls
			dataType:"text", // Data type, HTML, json etc.
			data:myData, //Form variables
			success:function(response){
				//response.preventDefault();
				var gg = $("#responds").append(response);
				//$("#responds").append(response);
				$("#student_nameText").val(''); //empty text field on successful
				$("#FormSubmit").show(); //show submit button
				$("#LoadingImage").hide(); //hide loading image
				$("input[name=student_name]").addClass("classs");
				$("input[name=year]").addClass("classs");
				$("input[name=class]").addClass("classs");
				$("input[name=term]").addClass("classs");
				$("input[name=formt]").addClass("classs");
				$("input[name=arm]").addClass("classs");
				$("#responds").load(url + "#responds");
			},
			error:function (xhr, ajaxOptions, thrownError){
				$("#FormSubmit").show(); //show submit button
				$("#LoadingImage").hide(); //hide loading image
				alert(thrownError);
			}
			});
	});

	//##### Send delete Ajax request to response.php #########
	$("body").on("click", "#responds .del_button", function(e) {
		 e.preventDefault();
		 var clickedID = this.id.split('-'); //Split ID string (Split works as PHP explode)
		 var DbNumberID = clickedID[1]; //and get number from array
		 var myData = 'recordToDelete='+ DbNumberID; //build a post data structure
		 
		$('#item_'+DbNumberID).addClass( "sel" ); //change background of this element by adding class
		$(this).hide(); //hide currently clicked delete button
		 
			jQuery.ajax({
			type: "POST", // HTTP method POST or GET
			url: "response.php", //Where to make Ajax calls
			dataType:"text", // Data type, HTML, json etc.
			data:myData, //Form variables
			success:function(response){
				//on success, hide  element user wants to delete.
				$('#item_'+DbNumberID).fadeOut();
			},
			error:function (xhr, ajaxOptions, thrownError){
				//On error, we alert user
				alert(thrownError);
			}
			});
	});
	
	
	//##### Send delete Ajax request to response.php #########
	$("body").on("click", "#responds .up_button", function(e) {
		 e.stopPropagation();
		 e.preventDefault();
		 var clickedID = this.id.split('-'); //Split ID string (Split works as PHP explode)
		 var DbNumberID = clickedID[1]; //and get number from array
		 var c2 = $('#student_name-item_'+DbNumberID).val();
		 var c = c2.toUpperCase()
		 var y = $('#year-item_'+DbNumberID).val();
		 var cl = $('#class-item_'+DbNumberID).val();
		 var t = $('#term-item_'+DbNumberID).val();
		 var f = $('#formt-item_'+DbNumberID).val();
		 var a = $('#arm-item_'+DbNumberID).val();
		 var myDataup = 'recordToUpdate='+ DbNumberID + '&student_name='+ c + '&year='+ y + '&class='+ cl + '&term='+ t + '&formt='+ f + '&arms='+ a; //build a post data structure
		 
		$("[id=img-"+DbNumberID+"]").one("click", function(e){
				$('#student_name-item_'+DbNumberID).toggleClass("clase classs");
				$('#year-item_'+DbNumberID).toggleClass("clase classs");
				$('#class-item_'+DbNumberID).toggleClass("clase classs");
				$('#term-item_'+DbNumberID).toggleClass("clase classs");
				$('#formt-item_'+DbNumberID).toggleClass("clase classs");
				$('#arm-item_'+DbNumberID).toggleClass("clase classs");
			});
			
			jQuery.ajax({
			type: "POST", // HTTP method POST or GET
			url: "response.php", //Where to make Ajax calls
			dataType:"text", // Data type, HTML, json etc.
			data:myDataup, //Form variables
			success:function(response){
				var cc = $('span#spstudent_name-item_'+DbNumberID).html(c);
				var yy = $('span#spyear-item_'+DbNumberID).html(y);
				var clcl = $('span#spclass-item_'+DbNumberID).html(cl);
				var tt = $('span#spterm-item_'+DbNumberID).html(t);
				var ff = $('span#spformt-item_'+DbNumberID).html(f);
				var aa = $('span#sparm-item_'+DbNumberID).html(a);
			},
			error:function (xhr, ajaxOptions, thrownError){
				alert(thrownError);
			}
			});		
	});	
	
	
	
	
	$(".search").keyup(function() { 
var searchid = $(this).val();
var dataString = 'search='+ searchid;
if(searchid!='')
{
    $.ajax({
    type: "POST",
    url: "response.php",
    data: dataString,
    cache: false,
    success: function(html)
    {
    $("#result").html(html).show();
    }
    });
}return false;    
});

jQuery("#result").live("click",function(e){ 
    var $clicked = $(e.target);
    var $name = $clicked.find('.name').html();
    var decoded = $("<div/>").html($name).text();
    $('#searchid').val(decoded);
});
jQuery(document).live("click", function(e) { 
    var $clicked = $(e.target);
    if (! $clicked.hasClass("search")){
    jQuery("#result").fadeOut(); 
    }
});
$('#searchid').click(function(){
    jQuery("#result").fadeIn();
});
	
	
	
	
});
</script>
<link href="css/styleft.css" rel="stylesheet" type="text/css" />	
		<style>
	.classs{
	display: none;
    }
	.clase{
	display: block;
    }
</style>
<style>
ul.topnav {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}
ul.topnav li {float: left;}
ul.topnav li a {
    display: inline-block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    transition: 0.3s;
    font-size: 17px;
}
ul.topnav li a:hover {background-color: #555;}
ul.topnav li.icon {display: none;}

@media screen and (max-width:680px) {
  ul.topnav li:not(:first-child) {display: none;}
  ul.topnav li.icon {
    float: right;
    display: inline-block;
  }
}
@media screen and (max-width:680px) {
  ul.topnav.responsive {position: relative;}
  ul.topnav.responsive li.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  ul.topnav.responsive li {
    float: none;
    display: inline;
  }
  ul.topnav.responsive li a {
    display: block;
    text-align: left;
  }
}
</style>
<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>
</head>
<body>
<?php
if($_SESSION['role'] == 'teacher'){
echo '<ul class="topnav" id="myTopnav">';
echo '<li><a href="index.php">Home</a></li>';
echo '<li><a href="teacher-student-mid.php">Add Midscores</a></li>';
echo '<li><a href="teacher-student.php">Add Scores</a></li>';
echo '<li><a href="update-score-mid.php">Update Midscores</a></li>';
echo '<li><a href="update-score.php">Update Scores</a></li>';
echo '<li><a href="formclasses.php">Form Tutor</a></li>';
echo '<li><a href="affective.php">Input Ranks</a></li>';
echo '<li><a href="teagetresultmid.php">Midterm Result</a></li>';
echo '<li><a href="teagetresult.php">Term Result</a></li>';
echo '<li><a href="attend.php">Attendance</a></li>';
echo '<li><a href="logout.php">Logout</a></li>';
echo '<li class="icon">';
echo '<a href="javascript:void(0);" onclick="myFunction()">&#9776;</a>';
echo '</li>';
echo '</ul>';
}
elseif($_SESSION['role'] == 'admin'){
echo '<ul class="topnav" id="myTopnav">';
echo '<li><a href="adstuadmin.php">Add Student</a></li>';
echo '<li><a href="adminaddformt.php">Add Form Tutor</a></li>';
echo '<li><a href="admgetresult.php">Student\'s Result</a></li>';
echo '<li><a href="admviewtea.php">View Teachers</a></li>';
echo '<li><a href="admviewtutor.php">View Tutors</a></li>';
echo '<li><a href="viewmaxatt.php">View Max Attendance</a></li>';
echo '<li><a href="logout.php">Logout</a></li>';
echo '<li class="icon">';
echo '<a href="javascript:void(0);" onclick="myFunction()">&#9776;</a>';
echo '</li>';
echo '</ul>';
}
else{echo "";}
?>
<br><br>
<div class="content_wrapper" style="width: 100%;">


<ul id="responds" style="width: 100%;">
<?php
//include db configuration file
include_once("config.php");

$ccl = $_POST['class'];
$yr = $_POST['year'];
$te = $_POST['term'];
$fot = $_POST['formt'];
$ar = $_POST['arms'];

echo '<div style="text-align: center; color: red; font-weight: bold; font-size: 18px;">BELOW ARE NAMES OF STUDENTS IN '.strtoupper($ccl).' '.strtoupper($ar).' FOR '.strtoupper($te).' '.$yr.'.</div>';
//MySQL query
$results = $mysqli->query("SELECT id,student_name,year,class,term,formt,arms FROM add_delete_record where class='$ccl' AND year='$yr' AND term='$te' AND formt='$fot' AND arms='$ar'");
//get all records from add_delete_record table
while($row = $results->fetch_assoc())
{
	
  echo '<li class="clas" id="item_'.$row["id"].'" style="width: 100%;">';
  echo '<div class="del_wrapper"><a href="#" class="del_button" id="del-'.$row["id"].'">';
  echo '<img src="images/icon_del.gif" border="0" />';
  echo '</a></div>';
  echo '<div class="up_wrapper"><a href="#" class="up_button" id="up-'.$row["id"].'">';
  echo '<img src="images/ic.png" border="0" class="img" id="img-'.$row["id"].'" />';
  echo '</a></div>';
  echo '<input type="text" name="student_name" id="student_name-item_'.$row["id"].'" value="'.$row["student_name"].'" />';
  echo '<span id="spstudent_name-item_'.$row["id"].'">'.strtoupper($row["student_name"]).'</span> || ';
  echo '<input type="text" name="year" id="year-item_'.$row["id"].'" value="'.$row["year"].'" />';
  echo '<span id="spyear-item_'.$row["id"].'">'.$row["year"].'</span> || ';
  echo '<input type="text" name="class" id="class-item_'.$row["id"].'" value="'.$row["class"].'" />';
  echo '<span id="spclass-item_'.$row["id"].'">'.$row["class"].'</span> || ';
  echo '<input type="text" name="term" id="term-item_'.$row["id"].'" value="'.$row["term"].'" />';
  echo '<span id="spterm-item_'.$row["id"].'">'.$row["term"].'</span> || ';
  echo '<input type="text" name="formt" id="formt-item_'.$row["id"].'" value="'.$row["formt"].'" />';
  echo '<span id="spformt-item_'.$row["id"].'">'.$row["formt"].'</span> || ';
  echo '<input type="text" name="arm" id="arm-item_'.$row["id"].'" value="'.$row["arms"].'" />';
  echo '<span id="sparm-item_'.$row["id"].'">'.$row["arms"].'</span><br>';
  echo '</li>';
}

//close db connection
$mysqli->close();
?>
</ul>




    <div class="form_style" style="width:100%;">
    <textarea name="student_name_txt" id="student_nameText" style="width:400px;" placeholder="Enter Student's Name"></textarea>
	<?php
	//if(isset($_POST['btn-upload'])){
		?>
	<textarea type="text"  style="display: none;" name="year_txt" id="yearText" value="<?php echo $_POST['year']; ?>" style="width:400px;"><?php echo $_POST['year']; ?></textarea>
	<textarea type="text" style="display: none;" name="class_txt" id="classText" value="<?php echo $_POST['class']; ?>" style="width:400px;"><?php echo $_POST['class']; ?></textarea>
	<textarea type="text" style="display: none;" name="term_txt" id="termText" value="<?php echo $_POST['term']; ?>" style="width:400px;"><?php echo $_POST['term']; ?></textarea>
	<textarea type="text" style="display: none;" name="formt_txt" id="formtText" value="<?php echo $_POST['formt']; ?>" style="width:400px;"><?php echo $_POST['formt']; ?></textarea>
	<textarea type="text" style="display: none;" name="arm_txt" id="armText" value="<?php echo $_POST['arms']; ?>" style="width:400px;"><?php echo $_POST['arms']; ?></textarea>
	<?php //} ?>
    <button id="FormSubmit">Add Student</button>
    <img src="images/loading.gif" id="LoadingImage" style="display:none" />
	<br><br>
    </div>
</div>

</body>
</html>
