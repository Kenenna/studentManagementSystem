<?php
include("auth.php"); //include auth.php file on all secure pages
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Get Result</title>
<script type="text/javascript" src="js/jquery-2.1.4.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script>
$(document).ready(function(){
$('#ttable td').each(function () {
  if ($(this).text() == 0 || $(this).text() == '0') {
    $(this).text('-');
  }
});
});
</script>
<script>
function printDiv(eleId){
    var PW = window.open('', '_blank', 'Print content');
 
    //IF YOU HAVE DIV STYLE IN CSS, REMOVE BELOW COMMENT AND ADD CSS ADDRESS
    //PW.document.write('<link rel="stylesheet" type="text/css" href="CSS-FILE-ADDRESS"/>');
 
    PW.document.write(document.getElementById(eleId).innerHTML);
    PW.document.close();
    PW.focus();
    PW.print();
    PW.close();
}
</script>
<style>
.pbutton {
	background-color:#44c767;
	-moz-border-radius:28px;
	-webkit-border-radius:28px;
	border-radius:28px;
	border:1px solid #18ab29;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:15px;
	padding:6px 24px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
	float: left;
}
.pbutton:hover {
	background-color:#5cbf2a;
}
.pbutton:active {
	position:relative;
	top:1px;
}
</style>
<style>
section {
    width: 80%;  
    margin: auto;
    padding: 8px;
}
div#one {
    width: 80%; 
    float: left;
}
div#two {
    margin-left: 1%;  
}

#section3 {
    width: 80%;  
    margin: auto;
    padding: 10px;
}
div#one3 {
    width: 50%; 
    float: left;
}
#heading{
	color: red;
}
</style>
</head>
<body>
<div id="printMe">
<table style="width:90%; border-top:0; border-bottom: 1px solid red; margin:auto; padding:auto;">
<td style="font-size:12px;"><img src="6.png" align="left" height="60" width="100" />CORONA SECONDARY SCHOOL<br>1 YENAGOA STREET,
<br> AGBARA, OGUN<br>TEL: 07060980133; FAX: 557688966858844<span style="float:right;"><?php echo date("jS F, Y"); ?></span></td>
</tr></table>
<?php
if(isset($_POST['submit3']) OR isset($_POST['submittoresult'])){
$term = $_POST['term'];
$year = $_POST['year'];
$class = $_POST['class_name'];
if($term == 'First Term'){
echo '<table style="width:100%; text-align:center; font-weight:bold; font-size:14px;"><tr><td>RESULT SHEET FOR FIRST TERM, '.$year.' SESSION</td></tr>';
echo '</table>';
}
else if($term == 'Second Term'){
echo '<table style="width:100%; text-align:center; font-weight:bold; font-size:14px;"><tr><td>RESULT SHEET FOR SECOND TERM, '.$year.' SESSION</td></tr>';	
echo '</table>';
}
else{
echo '<table style="width:100%; text-align:center; font-weight:bold; font-size:14px;"><tr><td>RESULT SHEET FOR THIRD TERM, '.$year.' SESSION</td></tr>';
echo '</table>';
}}
?>
<table style="width:90%; margin:auto; padding:auto; text-align:center; font-size: 10px;">
<?php 
if(isset($_POST['submit3']) OR isset($_POST['submittoresult'])){
$student_name = $_POST['student_name'];	
$term = $_POST['term'];
$year = $_POST['year'];
$class = $_POST['class_name'];

include "connection.php";	
$student_name = $_POST['student_name'];
$resultpic = mysqli_query($db, "SELECT * FROM img WHERE student_name='$student_name'");
						while($rowpic = mysqli_fetch_assoc($resultpic))
							{
$rpic[] = $rowpic['img'];							
}
$rpic2 = current($rpic);

/** $resultmaxatt = mysqli_query($db, "SELECT * FROM maxattname WHERE year='$year' AND term='$term'");
						while($rowmaxatt = mysqli_fetch_assoc($resultmaxatt))
							{
$rmaxatt[] = $rowmaxatt['maxattname'];							
}
$rmaxatt2 = current($rmaxatt);
**/
$result3 = mysqli_query($db, "SELECT * FROM maxattname WHERE year='$year' AND term='$term'");
while ($row3 = mysqli_fetch_assoc($result3)) {
$termbegin1[] = $row3['termbegin'];	
}
$termbegin = current($termbegin1);
$resultall = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$termbegin') AND ((attend='present') OR (attend='absent')) AND year='$year' AND term='$term'");
$attall = mysqli_num_rows($resultall);
$atall2 = $attall * 2;


$resultsex = mysqli_query($db, "SELECT * FROM regstu WHERE student_name='$student_name'");
						while($rowsex = mysqli_fetch_assoc($resultsex))
							{
$rsex[] = $rowsex['sex'];
$rdob[] = $rowsex['dob'];	
$admno[] = $rowsex['admno'];					
}
$rsex2 = current($rsex);
$rdob2 = current($rdob);
$admno2 = current($admno);


$student_name = $_POST['student_name'];
$resultatt = mysqli_query($db, "SELECT datename FROM attend WHERE student_name='$student_name' AND attend='present' AND class='$class' AND year='$year' AND term='$term'");
$att2 = mysqli_num_rows($resultatt);
$att = $att2 ;		
?>
<tbody style="height: 13px;">
<tr>
<td>Student Name: <?php echo $student_name; ?></td>
<td>Admission No: <?php echo $admno2; ?></td>
<td>Sex: <?php echo $rsex2; ?></td>
<td rowspan="3"><?php echo '<img style="float:right;" src="'.$rpic2.'" height="60" width="80"/>' ?></td>  
</tr>
<tr>
<td>Class: <?php echo $class; ?></td>
<td>Term: <?php echo $term; ?></td>
<td>Year: <?php echo $year; ?></td>  
</tr>
<tr>
<td>No of Times Present: <?php echo $att; ?></td>
<td>No of Times School Open: <?php echo $atall2; ?></td>
<td>Date of Birth: <?php echo date("jS F, Y", strtotime($rdob2)); ?></td>
</tr>
</tbody>
<?php } ?>
</table>

<table id="ttable" style="width:90%; border: 1px solid black; margin:auto; padding:auto; text-align:center; font-size: 10px;" border="1">
<tr><td colspan="11" ><div style="color:red; font-size:12px; text-align:center;">CONGNITIVE ASSESSMENT</div></td></tr>
<?php
	if(isset($_POST['submittoresult'])){
		$su = $_POST['su2'];
		$cc = $_POST['cc2'];
		$dd = $_POST['dd2'];
		$ca = $_POST['ca2'];
		$exam = $_POST['exam2'];
		$tt = $_POST['tt2'];
		$av = $_POST['av2'];
		$ccav = $_POST['ccav2'];
		$grade = $_POST['grade2'];
		$tn = $_POST['tn2'];
		$re = $_POST['re2'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		for ($x = 0; $x <= (count($su)-1); $x++){
echo '<tr><td>'.$su[$x].'</td><td>'.$ca[$x].'</td><td>'.$exam[$x].'</td><td>'.$tt[$x].'</td><td>'.$dd[$x].'</td><td>'.$cc[$x].'</td><td>'.$av[$x].'</td><td id="mytd">'.round($ccav[$x]).'</td><td>'.$grade[$x].'</td><td>'.$tn[$x].'</td><td>'.$re[$x].'</td></tr>';			
		}
echo '</table>';
	}
	else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		
	
	if($term == "Third Term"){	
	$result1 = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='First Term'");
	$sql2 = mysqli_query($db, "SELECT * FROM maxes where subjectname='$subject' AND classname='$class' AND yearname='$year' AND termname='$term' AND teachername='$tna' AND teacheridname='$tid'");
					
						while($row1 = mysqli_fetch_assoc($result1))
							{ 
								$firsubject[] = $row1['subject'];
								$firscore[] = $row1['score'];
							}
							$firsubject11 = $firsubject;
							$firscore11 = $firscore;
							$c = array_combine($firsubject11, $firscore11);
							ksort($c);
							$c = array_values($c);
							
	$result2 = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='Second Term'");
						while($row2 = mysqli_fetch_assoc($result2))
							{ 
								$secsubject[] = $row2['subject'];
								$secscore[] = $row2['score'];
							}
							$secsubject22 = $secsubject;
							$secscore22 = $secscore;
							$d = array_combine($secsubject22, $secscore22);
							ksort($d);
							$d = array_values($d);
				
							
	$result3 = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='Third Term'");
						while($row3 = mysqli_fetch_assoc($result3))
							{ 
								$thirsubject[] = $row3['subject'];
								$thirscore[] = $row3['score'];
							}
							$thirsubject33 = $thirsubject;
							$thirscore33 = $thirscore;
							$t = array_combine($thirsubject33, $thirscore33);
							ksort($t);
							$t = array_values($t);						
							
							$e = array_map(function () {
							return array_sum(func_get_args());
							},$c, $d, $t);
							ksort($e);
		
		
							
	echo '<tr id="heading"><td>SUBJECT</td><td>CA</td><td>EXAM</td><td>THIRD TERM TOTAL</td><td>SECOND TERM TOTAL</td><td>FIRST TERM TOTAL</td><td>AV. OF THREE TERMS</td><td>CLASS AVERAGE</td><td>GRADE</td><td>TEACHER\'S NAME</td><td>REMARK</td></tr>';	
	
	
	$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='$term' ORDER BY subject ASC");
	
	$recav = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Agricultural Science'");
	while($rowcav = mysqli_fetch_assoc($recav))
							{
							$agrcavin[]	= $rowcav['score'];
							}
							//$ag = array_values($agrcav);
							$agrcav = array_filter($agrcavin);
							$agrcav2 = array_sum($agrcav);
	$numbagr = count(array_filter($agrcav));
	$agrcav3 = $agrcav2/$numbagr;
	
	$recav1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Basic Science'");
	while($rowcav1 = mysqli_fetch_assoc($recav1))
							{
							$bascavin[]	= $rowcav1['score'];
							}
							$bascav = array_filter($bascavin);
							$bascav2 = array_sum($bascav);
	$numbbas = count(array_filter($bascav));
	$bascav3 = $bascav2/$numbbas;
	
	$recav2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='English'");
	while($rowcav2 = mysqli_fetch_assoc($recav2))
							{
							$engcavin[]	= $rowcav2['score'];
							}
							$engcav = array_filter($engcavin);
							$engcav2 = array_sum($engcav);
	$numbeng = count(array_filter($engcav));
	$engcav3 = round($engcav2/$numbeng);
	
	$recav3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Business Studies'");
	while($rowcav3 = mysqli_fetch_assoc($recav3))
							{
							$buscavin[]	= $rowcav3['score'];
							}
							$buscav = array_filter($buscavin);
							$buscav2 = array_sum($buscav);
	$numbbus = count(array_filter($buscav));
	$buscav3 = round($buscav2/$numbbus);
	
	$recav4 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Catering'");
	while($rowcav4 = mysqli_fetch_assoc($recav4))
							{
							$catcavin[]	= $rowcav4['score'];
							}
							$catcav = array_filter($catcavin);
							$catcav2 = array_sum($catcav);
	$numbcat = count(array_filter($catcav));
	$catcav3 = $catcav2/$numbcat;
	
	$recav5 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Civic Education'");
	while($rowcav5 = mysqli_fetch_assoc($recav5))
							{
							$civcavin[]	= $rowcav5['score'];
							}
							$civcav = array_filter($civcavin);
							$civcav2 = array_sum($civcav);
	$numbciv = count(array_filter($civcav));
	$civcav3 = $civcav2/$numbciv;
	
	$recav6 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Crk'");
	while($rowcav6 = mysqli_fetch_assoc($recav6))
							{
							$crkcavin[]	= $rowcav6['score'];
							}
							$crkcav = array_filter($crkcavin);
							$crkcav2 = array_sum($crkcav);
	$numbcrk = count(array_filter($crkcav));
	$crkcav3 = $crkcav2/$numbcrk;
	
	$recav7 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Food and Nutrition'");
	while($rowcav7 = mysqli_fetch_assoc($recav7))
							{
							$foocavin[]	= $rowcav7['score'];
							}
							$foocav = array_filter($foocavin);
							$foocav2 = array_sum($foocav);
	$numbfoo = count(array_filter($foocav));
	$foocav3 = $foocav2/$numbfoo;
	
	$recav8 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='French'");
	while($rowcav8 = mysqli_fetch_assoc($recav8))
							{
							$frecavin[]	= $rowcav8['score'];
							}
							$frecav = array_filter($frecavin);
							$frecav2 = array_sum($frecav);
	$numbfre = count(array_filter($frecav));
	$frecav3 = $frecav2/$numbfre;
	
	$recav9 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='ICT'");
	while($rowcav9 = mysqli_fetch_assoc($recav9))
							{
							$ictcavin[]	= $rowcav9['score'];
							}
							$ictcav = array_filter($ictcavin);
							$ictcav2 = array_sum($ictcav);
	$numbict = count(array_filter($ictcav));
	$ictcav3 = $ictcav2/$numbict;
	
	$recav10 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Igbo'");
	while($rowcav10 = mysqli_fetch_assoc($recav10))
							{
							$igbcavin[]	= $rowcav10['score'];
							}
							$igbcav = array_filter($igbcavin);
							$igbcav2 = array_sum($igbcav);
	$numbigb = count(array_filter($igbcav));
	$igbcav3 = $igbcav2/$numbigb;
	
	$recav11 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Mathematics'");
	while($rowcav11 = mysqli_fetch_assoc($recav11))
							{
							$matcavin[]	= $rowcav11['score'];
							}
							$matcav = array_filter($matcavin);
							$matcav2 = array_sum($matcav);
	$numbmat = count(array_filter($matcav));
	$matcav3 = $igbcav2/$numbmat;
	
	$recav12 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Music'");
	while($rowcav12 = mysqli_fetch_assoc($recav12))
							{
							$muscavin[]	= $rowcav12['score'];
							}
							$muscav = array_filter($muscavin);
							$muscav2 = array_sum($muscav);
	$numbmus = count(array_filter($muscav));
	$muscav3 = $muscav2/$numbmus;
	
	$recav13 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='PHE'");
	while($rowcav13 = mysqli_fetch_assoc($recav13))
							{
							$phecavin[]	= $rowcav13['score'];
							}
							$phecav = array_filter($phecavin);
							$phecav2 = array_sum($phecav);
	$numbphe = count(array_filter($phecav));
	$phecav3 = $phecav2/$numbphe;

	$recav14 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Social Studies'");
	while($rowcav14 = mysqli_fetch_assoc($recav14))
							{
							$soccavin[]	= $rowcav14['score'];
							}
							$soccav = array_filter($soccavin);
							$soccav2 = array_sum($soccav);
	$numbsoc = count(array_filter($soccav));
	$soccav3 = $soccav2/$numbsoc;
	
	$recav15 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Biology'");
	while($rowcav15 = mysqli_fetch_assoc($recav15))
							{
							$biocavin[]	= $rowcav15['score'];
							}
							$biocav = array_filter($biocavin);
							$biocav2 = array_sum($biocav);
	$numbbio = count(array_filter($biocav));
	$biocav3 = $biocav2/$numbbio;
	
	$recav16 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Chemistry'");
	while($rowcav16 = mysqli_fetch_assoc($recav16))
							{
							$checavin[]	= $rowcav16['score'];
							}
							$checav = array_filter($checavin);
							$checav2 = array_sum($checav);
	$numbche = count(array_filter($checav));
	$checav3 = $checav2/$numbche;
	
	$recav17 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Economics'");
	while($rowcav17 = mysqli_fetch_assoc($recav17))
							{
							$ecocavin[]	= $rowcav17['score'];
							}
							$ecocav = array_filter($ecocavin);
							$ecocav2 = array_sum($ecocav);
	$numbeco = count(array_filter($ecocav));
	$ecocav3 = $ecocav2/$numbeco;
	
	$recav18 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Government'");
	while($rowcav18 = mysqli_fetch_assoc($recav18))
							{
							$govcavin[]	= $rowcav18['score'];
							}
							$govcav = array_filter($govcavin);
							$govcav2 = array_sum($govcav);
	$numbgov = count(array_filter($govcav));
	$govcav3 = $govcav2/$numbgov;
	
	$recav19 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='VA'");
	while($rowcav19 = mysqli_fetch_assoc($recav19))
							{
							$vacavin[]	= $rowcav19['score'];
							}
							$vacav = array_filter($vacavin);
							$vacav2 = array_sum($vacav);
	$numbva = count(array_filter($vacav));
	$vacav3 = $vacav2/$numbva;
	
	$recav20 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='TD'");
	while($rowcav20 = mysqli_fetch_assoc($recav20))
							{
							$tdcavin[]	= $rowcav20['score'];
							}
							$vacav = array_filter($tdcavin);
							$tdcav2 = array_sum($tdcav);
	$numbtd = count(array_filter($tdcav));
	$tdcav3 = $tdcav2/$numbtd;
	
	$recav21 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Sociology'");
	while($rowcav21 = mysqli_fetch_assoc($recav21))
							{
							$socicavin[]	= $rowcav21['score'];
							}
							$socicav = array_filter($socicavin);
							$socicav2 = array_sum($socicav);
	$numbsoci = count(array_filter($socicav));
	$socicav3 = $socicav2/$numbsoci;
							
	$recav22 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Physics'");
	while($rowcav22 = mysqli_fetch_assoc($recav22))
							{
							$phycavin[]	= $rowcav22['score'];
							}
							$phycav = array_filter($phycavin);
							$phycav2 = array_sum($phycav);
	$numbphy = count(array_filter($phycav));
	$phycav3 = $phycav2/$numbphy;
	
	$recav23 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Marketing'");
	while($rowcav23 = mysqli_fetch_assoc($recav23))
							{
							$marcavin[]	= $rowcav23['score'];
							}
							$marcav = array_filter($marcavin);
							$marcav2 = array_sum($marcav);
	$numbmar = count(array_filter($marcav));
	$marcav3 = $marcav2/$numbmar;
	
	$recav24 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Lit in English'");
	while($rowcav24 = mysqli_fetch_assoc($recav24))
							{
							$litcavin[]	= $rowcav24['score'];
							}
							$litcav = array_filter($litcavin);
							$litcav2 = array_sum($litcav);
	$numblit = count(array_filter($litcav));
	$litcav3 = $litcav2/$numblit;
	
	$counter = 0;
	$counted = 0;
	while($row = mysqli_fetch_assoc($result))
							{								
		$to = Array($c[$counted], $d[$counted], $t[$counted]);
		if(($t[$counted] == 0) AND ($c[$counted] != 0) AND ($d[$counted] != 0)){$avdiv = 2; $t[$counted] = "-";}
		elseif(($t[$counted] == 0) AND ($c[$counted] != 0) AND ($d[$counted] == 0)){$avdiv = 1; $t[$counted] = "-"; $d[$counted] = "-";}
		elseif(($t[$counted] != 0) AND ($c[$counted] != 0) AND ($d[$counted] != 0)){$avdiv = 3;}
		else{$avdiv = 3;}
		$to2 = array_sum($to);
		$av = round($to2/$avdiv);
								//$av = round(($e[$counter++]) / 3);
								$cc = $c[$counted];
								$dd = $d[$counted];
								$tt = $t[$counted];
								if($av >= 80){$grade = "A1"; }
								else if(($av >= 70) AND ($av <= 79)){$grade = "B2";}
								else if(($av >= 65) AND ($av <= 69)){$grade = "B3";}
								else if(($av >= 60) AND ($av <= 64)){$grade = "C4";}
								else if(($av >= 55) AND ($av <= 59)){$grade = "C5";}
								else if(($av >= 50) AND ($av <= 54)){$grade = "C6";}
								else if(($av >= 45) AND ($av <= 49)){$grade = "D7";}
								else if(($av >= 40) AND ($av <= 44)){$grade = "E8";}
								else if(($av <= 39) AND ($av != 0)){$grade = "F9";}
								else if(($av == 0)){$grade = "-";}
								else if(($av == "")){$grade = "-";}
								else {$grade = "NA";}
								
								if($row["subject"] == "Agricultural Science"){$ccav = $agrcav3;}
								elseif($row["subject"] == "Basic Science"){$ccav = $bascav3;}
								elseif($row["subject"] == "English"){$ccav = $engcav3;}
								elseif($row["subject"] == "Business Studies"){$ccav = $buscav3;}
								elseif($row["subject"] == "Catering"){$ccav = $catcav3;}
								elseif($row["subject"] == "Civic Education"){$ccav = $civcav3;}
								elseif($row["subject"] == "Crk"){$ccav = $crkcav3;}
								elseif($row["subject"] == "Food and Nutrition"){$ccav = $foocav3;}
								elseif($row["subject"] == "ICT"){$ccav = $ictcav3;}
								elseif($row["subject"] == "French"){$ccav = $frecav3;}
								elseif($row["subject"] == "Igbo"){$ccav = $igbcav3;}
								elseif($row["subject"] == "Mathematics"){$ccav = $matcav3;}
								elseif($row["subject"] == "Music"){$ccav = $muscav3;}
								elseif($row["subject"] == "PHE"){$ccav = $phecav3;}
								elseif($row["subject"] == "Social Studies"){$ccav = $soccav3;}
								elseif($row["subject"] == "Biology"){$ccav = $biocav3;}
								elseif($row["subject"] == "Chemistry"){$ccav = $checav3;}
								elseif($row["subject"] == "Economics"){$ccav = $ecocav3;}
								elseif($row["subject"] == "Government"){$ccav = $govcav3;}
								elseif($row["subject"] == "VA"){$ccav = $vacav3;}
								elseif($row["subject"] == "TD"){$ccav = $tdcav3;}
								elseif($row["subject"] == "Sociology"){$ccav = $socicav3;}
								elseif($row["subject"] == "Marketing"){$ccav = $marcav3;}
								elseif($row["subject"] == "Physics"){$ccav = $phycav3;}
								elseif($row["subject"] == "Lit in English"){$ccav = $litcav3;}
								elseif($ccav == ""){$ccav = "-";}
								else{$ccav = "-";}
								$su = $row["subject"];
								$tn = $row["teacher_name"];
								$re = $row["remark"];
								$ct = $row["ca"];
								$ex = $row["exam"];
								echo '<tr><td>'.$su.'</td><td>'.$ct.'</td><td>'.$ex.'</td><td>'.$tt.'</td><td>'.$dd.'</td><td>'.$cc.'</td><td>'.$av.'</td><td id="mytd">'.round($ccav).'</td><td>'.$grade.'</td><td>'.$tn.'</td><td>'.$re.'</td></tr>';	
							$counted++;
							$arrsubj2[] = $su;
							$ca2[] = $ct;
							$exam2[] = $ex;
							$fir2[] = $cc;
							$sec2[] = $dd;
							$thir2[] = $tt;
							$av2[] = $av;
							$ccav2[] = round($ccav);
							$grad2[] = $grade;
							$teacher2[] = $tn;
							$remark2[] = $re;
							
							}
							$arrsubj = $arrsubj2;
							$ca = $ca2;
							$exam = $exam2;
							$fir = $fir2;
							$sec = $sec2;
							$thir = $thir2;
							$avv = $av2;
							$ccavv = $ccav2;
							$grad = $grad2;
							$teacher = $teacher2;
							$remark = $remark2;							
	}				
		else{
		echo '<tr id="heading"><td>SUBJECT</td><td>CA</td><td>EXAM</td><td>TOTAL</td><td>GRADE</td><td>TEACHER\'S NAME</td><td>REMARK</td></tr>';	
		$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='$term'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39) AND ($row["score"] != 0)){$grade = "F9";}
								else if(($row["score"] == 0)){$grade = "-";}
								else if(($row["score"] == "")){$grade = "-";}
								else {$grade = "NA";}
								echo '<tr><td>'.$row["subject"].'</td><td>'.$row["ca"].'</td><td>'.$row["exam"].'</td><td>'.$row["score"].'</td><td>'.$grade.'</td><td>'.$row["teacher_name"].'</td><td>'.$row["remark"].'</td></tr>';	
							}		
	}}					
							
?>
</table>
<hr style="width:80%;"/>

<table border="1" style="width:70%; border:1px solid black; margin:auto; padding:auto; text-align: center; font-size: 8px;">
<tr style="color: red;"><td>AFFECTIVE DOMAIN</td><td>RANK</td><td>GRADE</td><td>INTERPRETATION</td></tr>


<?php
if(isset($_POST['submit3']) OR isset($_POST['submittoresult'])){
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		
$resultaff = mysqli_query($db, "SELECT * FROM affective WHERE student_name='$student_name' AND class='$class_name' AND year='$year' AND term='$term'");
						while($rowaff = mysqli_fetch_assoc($resultaff))
							{
if($rowaff["firstname"] >= 5){
	$rank = "A";
	$inter = "Excellent";
}
else if($rowaff["firstname"] == 4){
	$rank = "B";
	$inter = "Very Good";
}
else if($rowaff["firstname"] == 3){
	$rank = "C";
	$inter = "Good";
}
else if($rowaff["firstname"] == 2){
	$rank = "D";
	$inter = "Fair";
}	
else if($rowaff["firstname"] == 1){
	$rank = "E";
	$inter = "Poor";
}
else if($rowaff["firstname"] == 0){
	$rank = "NA";
	$inter = "NA";
}
else{
	$rank = "";
}
if($rowaff["lastname"] >= 5){
	$rank2 = "A";
	$inter2 = "Excellent";
}
else if($rowaff["lastname"] == 4){
	$rank2 = "B";
	$inter2 = "Very Good";
}
else if($rowaff["lastname"] == 3){
	$rank2 = "C";
	$inter2 = "Good";
}
else if($rowaff["lastname"] == 2){
	$rank2 = "D";
	$inter2 = "Fair";
}	
else if($rowaff["lastname"] == 1){
	$rank2 = "E";
	$inter2 = "Poor";
	
}
else if($rowaff["lastname"] == 0){
	$rank2 = "NA";
	$inter2 = "NA";
}
else{
	$rank2 = "";
}
if($rowaff["midname"] >= 5){
	$rank3 = "A";
	$inter3 = "Excellent";
	
}
else if($rowaff["midname"] == 4){
	$rank3 = "B";
	$inter3 = "Very Good";
}
else if($rowaff["midname"] == 3){
	$rank3 = "C";
	$inter3 = "Good";
}
else if($rowaff["midname"] == 2){
	$rank3 = "D";
	$inter3 = "Fair";
}	
else if($rowaff["midname"] == 1){
	$rank3 = "E";
	$inter3 = "Poor";
}
else if($rowaff["midname"] == 0){
	$rank3 = "NA";
	$inter3 = "NA";
}
else{
	$rank3 = "";
}					
echo '<tr ><td>Honesty</td><td>'.$rowaff["firstname"].'</td><td>'.$rank.'</td><td>'.$inter.'</td></tr>';
echo '<tr ><td>Attentiveness</td><td>'.$rowaff["lastname"].'</td><td>'.$rank2.'</td><td>'.$inter2.'</td></tr>';
echo '<tr ><td>Cooperation</td><td>'.$rowaff["midname"].'</td><td>'.$rank3.'</td><td>'.$inter3.'</td></tr>';
}}
?>
<tr style="color: red;"><td>PSYCHOMOTOR DOMAIN</td><td>RANK</td><td>GRADE</td><td>INTERPRETATION</td></tr>
<?php
if(isset($_POST['submit3']) OR isset($_POST['submittoresult'])){
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		
$resultp = mysqli_query($db, "SELECT * FROM affective WHERE student_name='$student_name' AND class='$class_name' AND year='$year' AND term='$term'");
						while($rowp = mysqli_fetch_assoc($resultp))
							{
if($rowp["pfirstname"] >= 5){
	$prank = "A";
	$pinter = "Excellent";
}
else if($rowp["pfirstname"] == 4){
	$prank = "B";
	$pinter = "Very Good";
}
else if($rowp["pfirstname"] == 3){
	$prank = "C";
	$pinter = "Good";
}
else if($rowp["pfirstname"] == 2){
	$prank = "D";
	$pinter = "Fair";
}	
else if($rowp["pfirstname"] == 1){
	$prank = "E";
	$pinter = "Poor";
}
else if($rowp["pfirstname"] == 0){
	$prank = "NA";
	$pinter = "NA";
}
else{
	$prank = "";
}
if($rowp["plastname"] >= 5){
	$prank2 = "A";
	$pinter2 = "Excellent";
}
else if($rowp["plastname"] == 4){
	$prank2 = "B";
	$pinter2 = "Very Good";
}
else if($rowp["plastname"] == 3){
	$prank2 = "C";
	$pinter2 = "Good";
}
else if($rowp["plastname"] == 2){
	$prank2 = "D";
	$pinter2 = "Fair";
}	
else if($rowp["plastname"] == 1){
	$prank2 = "E";
	$pinter2 = "Poor";
	
}
else if($rowp["plastname"] == 0){
	$prank2 = "NA";
	$pinter2 = "NA";
}
else{
	$prank2 = "";
}
if($rowp["pmidname"] >= 5){
	$prank3 = "A";
	$pinter3 = "Excellent";
	
}
else if($rowp["pmidname"] == 4){
	$prank3 = "B";
	$pinter3 = "Very Good";
}
else if($rowp["pmidname"] == 3){
	$prank3 = "C";
	$pinter3 = "Good";
}
else if($rowp["pmidname"] == 2){
	$prank3 = "D";
	$pinter3 = "Fair";
}	
else if($rowp["pmidname"] == 1){
	$prank3 = "E";
	$pinter3 = "Poor";
}
else if($rowp["pmidname"] == 0){
	$prank3 = "NA";
	$pinter3 = "NA";
}
else{
	$prank3 = "";
}					
echo '<tr ><td>Handwriting</td><td>'.$rowp["pfirstname"].'</td><td>'.$prank.'</td><td>'.$pinter.'</td></tr>';
echo '<tr ><td>Painting</td><td>'.$rowp["plastname"].'</td><td>'.$prank2.'</td><td>'.$pinter2.'</td></tr>';
echo '<tr ><td>Athletics</td><td>'.$rowp["pmidname"].'</td><td>'.$prank3.'</td><td>'.$pinter3.'</td></tr>';
}}
?>
</table>
<hr style="width:80%;"/>

<table style="width:80%; margin:auto; padding:auto; font-size: 10px;">
<tr>
<td>Form Teacher's Name: Ade Jones<br>Comment: <span style="text-decoration: underline;">He is a good boy.</span><br>
Signature: A.A</td>
<td style="text-align:right;">House Parent's Name: Mark Luke<br>
Comment: <span style="text-decoration: underline;">He is a good boy.</span><br>
Signature: M.L</td>
</tr>
</table>
</div>
<?php
include "connection.php";
$user=$_SESSION['username'];
$result3 = mysqli_query($db, "SELECT * FROM users2 where username='$user'");
while($rowtid = mysqli_fetch_assoc($result3))
{
$trole[] = $rowtid['role'];
}
$trol = current($trole);
if($trol == 'teacher'){?>
<button class="pbutton" onclick="location.href='teagetresult.php';" style="float: left;">New Request</button>
<?php } ?>
<button class="pbutton" onclick="printDiv('printMe');" style="float: left;">Print</button>
<a class="pbutton" style="float: left;" href="index.php">Index</a>
<?php
if(($term2 == 'Third Term') OR ($term == 'Third Term')){
if (isset($_POST['submittoresult'])){
$arsubj = $_POST['su2'];
$fir2 = $_POST['cc2'];
$sec2 = $_POST['dd2'];
$thir2 = $_POST['tt2'];
$avv = $_POST['av2'];
$ccavv = $_POST['ccav2'];
$grad2 = $_POST['grad2'];
$teacher2 = $_POST['tn2'];
$remark2 = $_POST['re2'];
$student_name2 = $_POST['student_name'];
$class_name2 = $_POST['class_name'];
$year2 = $_POST['year'];
$term2 = $_POST['term'];

$ref = $_SERVER['HTTP_REFERER'];
if($ref == 'chart.js2.php'){
echo '<form action="chart.js2.php" method="POST">';
$i = 0;
foreach($arrsubj as $arsubj)
{
  echo '<input  style="display: none;" name="arsubj[]" value="'. $arsubj. '">';
  $i++;
}
?>
<?php
$i = 0;
foreach($ca as $ca2)
{
  echo '<input  style="display: none;"  name="ca2[]" value="'. $ca2. '">';
  $i++;
}
?>
<?php
$i = 0;
foreach($exam as $exam2)
{
  echo '<input  style="display: none;"  name="exam2[]" value="'. $exam2. '">';
  $i++;
}
?>
<?php
$i = 0;
foreach($fir as $fir2)
{
  echo '<input   name="fir2[]" value="'. $fir2. '">';
  $i++;
}
?>
<?php
$i = 0;
foreach($sec as $sec2)
{
  echo '<input  style="display: none;" name="sec2[]" value="'. $sec2. '">';
  $i++;
}
?>
<?php
$i = 0;
foreach($thir as $thir2)
{
  echo '<input  style="display: none;" name="thir2[]" value="'. $thir2. '">';
  $i++;
}
?>
<?php
$i = 0;
foreach($avv as $avv2)
{
  echo '<input  style="display: none;" name="avv2[]" value="'. $avv2. '">';
  $i++;
}
?>
<?php
$i = 0;
foreach($ccavv as $ccavv2)
{
  echo '<input  style="display: none;" name="ccavv2[]" value="'. $ccavv2. '">';
  $i++;
}
?>
<?php
$i = 0;
foreach($grad as $grad2)
{
  echo '<input  style="display: none;" name="grad2[]" value="'. $grad2. '">';
  $i++;
}
?>
<?php
$i = 0;
foreach($teacher as $teacher2)
{
  echo '<input  style="display: none;" name="teacher2[]" value="'. $teacher2. '">';
  $i++;
}
?>
<?php
$i = 0;
foreach($remark as $remark2)
{
  echo '<input  style="display: none;" name="remark2[]" value="'. $remark2. '">';
  $i++;
}
echo '<input  style="display: none;" name="student_name2" type="text" value="'.$student_name. '">';
echo '<input  style="display: none;" name="class_name2" type="text" value="'.$class_name. '">';
echo '<input  style="display: none;" name="year2" type="text" value="'.$year. '">';
echo '<input  style="display: none;" name="term2" type="text" value="'.$term. '">';
echo '<input class="pbutton" style="float: left; display: none;" type="submit" name="submit" value="View Chart" />';
echo '</form>';
}
}
else

{
echo '<form action="chart.js2.php" method="POST">';
$i = 0;
foreach($arrsubj as $arsubj)
{
  echo '<input  style="display: none;" name="arsubj[]" value="'. $arsubj. '">';
  $i++;
}
?>
<?php
$i = 0;
foreach($ca as $ca2)
{
  echo '<input  style="display: none;"  name="ca2[]" value="'. $ca2. '">';
  $i++;
}
?>
<?php
$i = 0;
foreach($exam as $exam2)
{
  echo '<input  style="display: none;"  name="exam2[]" value="'. $exam2. '">';
  $i++;
}
?>
<?php
$i = 0;
foreach($fir as $fir2)
{
  echo '<input  style="display: none;"  name="fir2[]" value="'. $fir2. '">';
  $i++;
}
?>
<?php
$i = 0;
foreach($sec as $sec2)
{
  echo '<input  style="display: none;" name="sec2[]" value="'. $sec2. '">';
  $i++;
}
?>
<?php
$i = 0;
foreach($thir as $thir2)
{
  echo '<input  style="display: none;" name="thir2[]" value="'. $thir2. '">';
  $i++;
}
?>
<?php
$i = 0;
foreach($avv as $avv2)
{
  echo '<input  style="display: none;" name="avv2[]" value="'. $avv2. '">';
  $i++;
}
?>
<?php
$i = 0;
foreach($ccavv as $ccavv2)
{
  echo '<input  style="display: none;" name="ccavv2[]" value="'. $ccavv2. '">';
  $i++;
}
?>
<?php
$i = 0;
foreach($grad as $grad2)
{
  echo '<input  style="display: none;" name="grad2[]" value="'. $grad2. '">';
  $i++;
}
?>
<?php
$i = 0;
foreach($teacher as $teacher2)
{
  echo '<input  style="display: none;" name="teacher2[]" value="'. $teacher2. '">';
  $i++;
}
?>
<?php
$i = 0;
foreach($remark as $remark2)
{
  echo '<input  style="display: none;" name="remark2[]" value="'. $remark2. '">';
  $i++;
}
echo '<input  style="display: none;" name="student_name2" type="text" value="'.$student_name. '">';
echo '<input  style="display: none;" name="class_name2" type="text" value="'.$class_name. '">';
echo '<input  style="display: none;" name="year2" type="text" value="'.$year. '">';
echo '<input  style="display: none;" name="term2" type="text" value="'.$term. '">';
echo '<input class="pbutton" style="float: left;" type="submit" name="submit" value="View Chart of '.$student_name.'\'s Performance across Subjects" />';
echo '</form>';	



echo '<form action="tochart.php" method="POST">';
echo '<input  style="display: none;" name="student_name" type="text" value="'.$student_name. '">';
echo '<input  style="display: none;" name="class_name" type="text" value="'.$class_name. '">';
echo '<input  style="display: none;" name="year" type="text" value="'.$year. '">';
echo '<input  style="display: none;" name="term" type="text" value="'.$term. '">';
echo '<input class="pbutton" style="float: left;" type="submit" name="submit" value="View Chart of '.$student_name.'\'s Performance in a Subject across Years" />';
echo '</form>';	
}















}
?>
<a class="pbutton" style="float: left;" href="logout.php">Logout</a>
</body>