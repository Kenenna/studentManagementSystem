<?php
include("connection.php");
if($_POST['id'])
{
$id=mysqli_escape_String($_POST['id']);
$student_name=mysqli_escape_String($_POST['student_name']);
$class=mysqli_escape_String($_POST['class']);
$sql = "update studentsbyclass set student_name='$student_name',class='$class' where id='$id'";
mysqli_query($db,$sql);
}
?>