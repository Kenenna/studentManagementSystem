<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
    <title>chart by subject</title>
<script src="http://igniteui.com/js/modernizr.min.js"></script>
<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
<script src="http://code.jquery.com/ui/1.10.3/jquery-ui.min.js"></script>
<script src="http://cdn-na.infragistics.com/igniteui/latest/js/infragistics.core.js"></script>
<script src="http://cdn-na.infragistics.com/igniteui/latest/js/infragistics.lob.js"></script>
<script src="http://cdn-na.infragistics.com/igniteui/latest/js/infragistics.dv.js"></script>
<link href="http://cdn-na.infragistics.com/igniteui/latest/css/themes/infragistics/infragistics.theme.css" rel="stylesheet"></link>
<link href="http://cdn-na.infragistics.com/igniteui/latest/css/structure/infragistics.css" rel="stylesheet"></link>


</head>
<body>
<div>
            <div id="chart"></div>
			<br />
			<input id="exportToPdfBtn" onclick="ExportToPDF()" value="Export to PDF" type="button" />
        </div>
<script>
    $(document).ready(function() {
     $(function () {
            $('#chart').igDataChart(
                {
                    dataSource: [{ "Year": 1995, "Canada": 16.8331, "SaudiArabia": 20.6591, "Russia": 41.4181, "UnitedStates": 0, "China": 33.5387 },
                        { "Year": 1996, "Canada": 17.2262, "SaudiArabia": 20.8153, "Russia": 0, "UnitedStates": 71.1744, "China": 33.5387 },
                        { "Year": 1997, "Canada": 17.4787, "SaudiArabia": 21.2433, "Russia": 41.4181, "UnitedStates": 71.1744, "China": 33.5387 },
                        { "Year": 1998, "Canada": 17.4377, "SaudiArabia": 0, "Russia": 41.4181, "UnitedStates": 71.1744, "China": 33.5387 },
                        { "Year": 1999, "Canada": 0, "SaudiArabia": 0, "Russia": 41.4181, "UnitedStates": 71.1744, "China": 33.5387 },
                        { "Year": 2000, "Canada": 17.4377, "SaudiArabia": 21.4151, "Russia": 41.4181, "UnitedStates": 0, "China": 33.5387 }
                    ],

                    height: '400px',
                    width: '400px',
                    title: 'stacked column chart',
                    titleTextColor: "red",
                    axes: [
                        { type: 'categoryX', name: 'Year', label: 'Year', title: 'Year', gap: 1 },
                        { type: 'numericY', name: 'Volume', title: 'Quadrillion Btu', labelTextColor: 'red' }
                    ], series: [
                        {
                            type: 'stackedColumn',
                            name: 'parent',
                            xAxis: 'Year',
                            yAxis: 'Volume',
                            series: [
                                {
                                    type: 'stackedFragment',
                                    name: 'Canada',
                                    title: 'Canada',
                                    valueMemberPath: 'Canada',
                                    showTooltip: true
                                }, {
                                    type: 'stackedFragment',
                                    name: 'SaudiArabia',
                                    title: 'SaudiArabia',
                                    valueMemberPath: 'SaudiArabia',
                                    showTooltip: true
                                }, {
                                    type: 'stackedFragment',
                                    name: 'Russia',
                                    title: 'Russia',
                                    valueMemberPath: 'Russia',
                                    showTooltip: true
                                }, {
                                    type: 'stackedFragment',
                                    name: 'UnitedStates',
                                    title: 'UnitedStates',
                                    valueMemberPath: 'UnitedStates',
                                    showTooltip: true
                                }, {
                                    type: 'stackedFragment',
                                    name: 'China',
                                    title: 'China',
                                    valueMemberPath: 'China',
                                    showTooltip: true
                                }]
                        }]
                });
        });
		
		function ExportToPDF(){
			var pngImage = $('#chart').igDataChart("exportImage", 2000, 1000);
			createPDF(pngImage);
		};
		
		var createPDF = function(imgData) {
			var doc = new jsPDF();
			doc.setFontSize(40);
			doc.text(35, 25, "Example");
			doc.addImage(imgData, 'JPEG', 15, 40, 180, 180);
			doc.save('Test.pdf');
		}
	 
	 });
	 </script>
</body>
</html>