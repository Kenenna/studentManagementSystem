<?php
	session_start();
	include "connection.php";
	include("auth.php"); 
	include('db.php');
	
	$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Update Scores</title>
<link rel="stylesheet" href="style.css" type="text/css" />
<link rel="stylesheet" href="css/style.css" />
	<script src="table/js/jquery.js" type="text/javascript"></script>
	<script src="datatablejs.js" type="text/javascript"></script>
	<link rel="stylesheet" type="text/css" href="datatablecss.css">
	 <link rel="stylesheet" type="text/css" href="datatablebuttoncss.css">
<script>
	$(document).ready(function() {
    $('#example').DataTable( {
        "paging":   false,
        "ordering": true,
        "info":     false,
		"scrollY":  "1000px",
        "scrollCollapse": true
    } );
	
var tabheight = $('#example').outerHeight();
	var tabheightlast = $('#example tr:first').outerHeight();
	$('.vertclasscont').css("height", tabheight+"px");
	
setInterval(function(){		
var tbh = $("#example").height();
if(tbh <= 152){
$(".vertclasscont").hide();	
}
else if((tbh > 152) && (tbh <= 500)){
$(".vertclasscont").height(tbh);
$(".vertclasscont").show();
$(".vertclass").text("SUBMIT");
}
else if(tbh > 500 && tbh <= 1200){
$(".vertclasscont").height(tbh);
$(".vertclasscont").show();
$(".vertclass").css("margin-top",80+"%");
$(".vertclass").text("SUBMIT UPDATED SCORES || SUBMIT UPDATED SCORES");
}
else if(tbh >= 1200){
$(".vertclasscont").height(tbh);
$(".vertclasscont").show();
$(".vertclass").css("margin-top",80+"%");
$(".vertclass").text("SUBMIT UPDATED SCORES || SUBMIT UPDATED SCORES || SUBMIT UPDATED SCORES  || SUBMIT UPDATED SCORES || SUBMIT UPDATED SCORES");
}

var docHeights = $(window).height();
if(docHeights < 660){
$(".vertclasscont").hide();	
}
}, 2000);	
});
</script>
 
<script>
$(document).ready(function(){
	var inihw = $(".newhwmax").val();
	var inicw = $(".newcwmax").val();
	var initest = $(".newtestmax").val();
	var iniexam = $(".newexammax").val();
	$("#txtFirstName").val(inihw);
	$("#txtFirstName1").val(inicw);
	$("#txtFirstName2").val(initest);
	$("#txtFirstName3").val(iniexam); 
	$("#txtFirstName").css("width","30px");
	$("#txtFirstName1").css("width","30px");
	$("#txtFirstName2").css("width","30px");
	$("#txtFirstName3").css("width","30px");
	$("#txtFirstName").before("<span>HW MAX:</span> ");
	$("#txtFirstName1").before("<span>CW MAX:</span> ");
	$("#txtFirstName2").before("<span>TEST MAX:</span> ");
	$("#txtFirstName3").before(" <span>EXAM MAX:</span> ");
	$("#dosomething").click(function(){	
	var inihw2 = $(".newhwmax").val();
	var inicw2 = $(".newcwmax").val();
	var initest2 = $(".newtestmax").val();
	var iniexam2 = $(".newexammax").val();
	var valueit=$('#txtFirstName').val();
	var valueit1=$('#txtFirstName1').val();	
	var valueit2=$('#txtFirstName2').val();	
	var valueit3=$('#txtFirstName3').val();	
 if(valueit == 0){
	 $(".newhwmax").val(inihw);
				}
 else{
	 $(".newhwmax").val(valueit);
	}				
	if(valueit1 == 0){
	 $(".newcwmax").val(inicw);
				}
 else{
	 $(".newcwmax").val(valueit1);
	}
	if(valueit2 == 0){
	 $(".newtestmax").val(initest);
				}
 else{
	 $(".newtestmax").val(valueit2);
	}
	if(valueit3 == 0){
	 $(".newexammax").val(iniexam);
				}
 else{
	 $(".newexammax").val(valueit3);
	}
	
$("#maxupdated").fadeIn();
		setTimeout(function() { $("#maxupdated").fadeOut(); }, 2000); 
});
});
</script>
<script>
$(document).ready(function() {
$("#class_name option").eq(7).css("display","none");
$("#class_name").on("change",function(){
var bb = $("#class_name").find(":selected").text();
var b = null;
if(bb=="Primary 1"){
	b = "Year 1";
}
else if(bb=="Primary 2"){
	b = "Year 2";
}
else if(bb=="Primary 3"){
	b = "Year 3";
}
else if(bb=="Primary 4"){
	b = "Year 4";
}
else if(bb=="Primary 5"){
	b = "Year 5";
}
else if(bb=="Primary 6"){
	b = "Year 6";
}
else if(bb=="JS1"){
	b = "Year 7";
}
else if(bb=="JS2"){
	b = "Year 8";
}
else if(bb=="JS3"){
	b = "Year 9";
}
else if(bb=="SS1"){
	b = "Year 10";
}
else if(bb=="SS2"){
	b = "Year 11";
}
else if(bb=="SS3"){
	b = "Year 12";
}
else{
	b = bb;
}
$("#class_name").find(":selected").val(b);
var c = $("#class_name").find(":selected").val();
//alert(c);
  }); 
		
	var countabs = $('table#example tr:last').index()+1;
$("#formid").submit(function( event ) {
event.preventDefault();	
$.ajax({
type: "POST",
url: "update_score_exec.php",
data: $("#formid").serializeArray(),	
success: function(response){
var rowed = response.split("|")
		response0 = rowed[0];
		response1 = rowed[1];
		response2 = rowed[2];
		response3 = rowed[3];
		response4 = rowed[4];
		response5 = rowed[5];
		response6 = rowed[6];
		response7 = rowed[7];
		response8 = rowed[8];
		response9 = rowed[9];
		response10 = rowed[10];
		response11 = rowed[11];
	var rowedd0 = response0.split("-");	
	var rowedd1 = response1.split("-");
	var rowedd2 = response2.split("-");
	var rowedd3 = response3.split("-");
	var rowedd4 = response4.split("-");
	var rowedd5 = response5.split("-");
	var rowedd6 = response6.split("-");
	var rowedd7 = response7.split("-");
	var rowedd8 = response8.split("-");
	var rowedd9 = response9.split("-");
	var rowedd10 = response10.split("-");
	var rowedd11 = response11.split("-");

	var countab = $('table#example tr:last').index()+1;
	
   $( ".score" ).each(function( index ){
	    var cc = this.id;
		var c = cc.slice(5);
		if(countabs==countab){
	   $('[id=score'+index+']').text(rowedd1[index]);
	   $('[id=scoresmid'+index+']').text(rowedd2[index]);
	   $('[id=scoresmidraw'+index+']').text(rowedd3[index]);
	   $('[id=caraw'+index+']').text(rowedd4[index]);
	   $('[id=hw'+index+']').text(rowedd5[index]);
	   $('[id=cw'+index+']').text(rowedd6[index]);
	   $('[id=test'+index+']').text(rowedd7[index]);
	   $('[id=ca'+index+']').text(rowedd8[index]);
	   $('[id=exam'+index+']').text(rowedd9[index]);
		}else{
	   $('[id=score'+c+']').text(rowedd1[c]);
	   $('[id=scoresmid'+c+']').text(rowedd2[c]);
	   $('[id=scoresmidraw'+c+']').text(rowedd3[c]);
	   $('[id=caraw'+c+']').text(rowedd4[c]);
	   $('[id=hw'+c+']').text(rowedd5[c]);
	   $('[id=cw'+c+']').text(rowedd6[c]);
	   $('[id=test'+c+']').text(rowedd7[c]);
	   $('[id=ca'+c+']').text(rowedd8[c]);
	   $('[id=exam'+c+']').text(rowedd9[c]);	
		}
	});	
		
 if(response11=="1") { 
		event.preventDefault();
		$(".success").fadeIn();
		setTimeout(function() { $(".success").fadeOut(); }, 2000); 
    } else {
		 $(".error").show();
		setTimeout(function() { $(".error").fadeOut(); }, 2000);
		}
		}
});	
});	 
});
</script>
<script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>



 <!-- jQuery & jQuery UI files (needed)-->
<link rel="stylesheet" href="pop/css/jquery-ui-1.10.3.custom.css">
<script src="pop/js/jquery/jquery-ui-1.10.3.custom.js"></script>

<!-- MultiDialog files (needed) -->
<link rel="stylesheet" href="pop/css/jquery.multiDialog.css">
<script src="pop/js/jquery.ui.dialog.extended-1.0.2.js"></script>
<script src="pop/js/jquery.multiDialog.js"></script>

<!-- MultiDialog files (optional) -->
<script src="res/jquery/js/jquery.ui.draggable.js"></script>

<!-- Demo files (unneeded) -->
<link rel="stylesheet" href="res/jquery/css/jquery.ui.tabs.css">
<link rel="stylesheet" href="res/prism/prism.css"/>
<script src="res/jquery/js/jquery.ui.tabs.js"></script>
<script src="res/SuperThemeSwitcher/jquery.themeswitcher.js"></script>
<script src="res/prism/prism.js" type="text/javascript"></script>
<script>
$(document).ready(function() {
	$("#remarkdiv").hide();
	$("#oldval").hide(); 
	$("#track").hide();
$(".group").click(function(cc){
	cc.preventDefault();
	$("#track").val(chatt);
	var chatt = this.id;
	var chattyy = parseInt(chatt);
	var ss = $('[id='+chatt+']').text();
	var thestname = $('[class='+chatt+']').text();
	$("#formid").hide();
	$("#thestname").text(thestname);
	$("#remarkdivta").val(ss);
	$("#track").val(chatt);
	var countabbssss = $('table#example tr:last').index()+1;
	if(countabbssss!=chattyy){
	$(".ri").css("background-color","green");	
	$(".ri").prop("disabled",false);		
	}
	if((countabbssss-1)==chattyy){
	$(".ri").css("background-color","red");	
	$(".ri").prop("disabled",true);		
	}
	if(chattyy<=0){
	$(".le").prop("disabled", true).css("background-color","red");	
	chatty = 1;
	}
	if(chattyy>=1){
	$(".le").prop("disabled", false).css("background-color","green");	
	}
	$("#remarkdiv").show();
	});
	
	var a = "a";
	var c = "";
	var sss = "";
	var v = "";
	var  f = "";
	var g = "";
	var h = "";
	var t = "";
 $(".ri").click(function(dd){
	dd.preventDefault();
	v = parseInt($("#track").val())
	a = v + 1;
	$("#track").val(a);
	var countabbs = $('table#example tr:last').index()+1;
	//alert(countabbs);
	if(countabbs <= (v+2)){
	$(".ri").prop("disabled", true).css("background-color","red");	
	}
	if(countabbs >= (v+2)){
	$(".le").prop("disabled", false).css("background-color","green");	
	}
	c = $("#remark_"+v).val(); //old
	f = $("#remark_"+a).val(); //new
	$("#oldval").val(f); //tarea as old
	g = $("#remarkdivta").val(); // get old val 
	$("#remarkdivta").val($("#oldval").val()); // get new val 
	$("#remark_"+v).text(g);
	$("#remark_"+v).val(g);
	$("#"+v).text(g);
	var changestu = $("#student_name"+a).text();
	changestu2 = changestu.toUpperCase();
	$("#thestname").text(changestu2);
	var stnam = $("#thestname").text();
	if(stnam == ""){
	$("#remarkdiv").hide();
	$("#formid").show();
	}
 });
 
$(".endit").click(function(dd){
	dd.preventDefault();
	//var countabbssss = $('table#example tr:last').index()+1;
	v = parseInt($("#track").val());
	//var v2 = v+1;
	//if(v!=countabbssss){
	//$(".ri").css("background-color","green");	
	//}
	//alert(countabbssss+"-"+v2);
	$("#track").val(v);
	c = $("#remarkdivta").val();
	$("#remark_"+v).text(c);
	$("#remark_"+v).val(c);
	$("#"+v).text(c);
	$("#remarkdiv").hide();
	$("#formid").show();
 });	
 
 $(".le").click(function(ddf){
	ddf.preventDefault();
		if($(".le").is(":disabled") && $(".ri").is(":disabled")){
	$("#remarkdiv").hide();
	$("#formid").show();
	}
	v = parseInt($("#track").val())
	a = v - 1;
	$("#track").val(a);
	var countabbss = $('table#example tr:last').index()+1;
	if(v==1){
	$(".le").prop("disabled", true).css("background-color","red");
	}
	if(countabbss>v){
	$(".ri").prop("disabled", false).css("background-color","green");	
	}
	c = $("#remark_"+v).val(); //old
	f = $("#remark_"+a).val(); //new
	$("#oldval").val(f); //tarea as old
	g = $("#remarkdivta").val(); // get old val 
	$("#remarkdivta").val($("#oldval").val()); // get new val 
	$("#remark_"+v).text(g);
	$("#remark_"+v).val(g);
	$("#"+v).text(g);
	var changestu = $("#student_name"+a).text();
	changestu2 = changestu.toUpperCase();
	$("#thestname").text(changestu2);
	if(stnam == ""){
	$("#remarkdiv").hide();
	$("#formid").show();
	}
 });
});
	</script>
 <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
<style>
	#thestname {
  text-transform: uppercase;
}
.ri, .le, .endit{
	color: white;
	background-color: green;
	border-radius: 4px;
	padding: 5px;
}
</style>
 <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
   <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
<script>
$(document).ready(function(){
  	 $("#takest").html("Show Students Request Form");
$("#takestu").hide();
 $("#takest").click(function( event ) {
		event.preventDefault();
		var hi = $("#takest").html();
		if(hi == "Show Students Request Form"){	
		$("#takest").html("Hide Students Request Form");
		$("#takestu").show();
		$("#pushit").hide();
		}
		else if(hi == "Hide Students Request Form"){	
		$("#takest").html("Show Students Request Form");
		$("#takestu").hide();
		$("#pushit").show();
		}
	 }); 
});
</script>
</head>

<body>
<?php
echo '<div id="headerit">';
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");
}
elseif($_SESSION['role'] == 'student'){
include("headerstudent.php");
}
else{header("location: logout.php");}
echo '</div>';
?>
<?php
$user = $_SESSION['username'];
?>
<BR><BR><br>


<script>
$(function() {
/*	$( "a.group" ).MultiDialog({
		gallery: {
			enabled: true,
			loop: true
		}
	});
});
*/
</script>
<!-- End demo --> 
<!-- Some hidden inline content -->




<center>
<a style="color: red; font-weight: bold; font-size: 20px; text-decoration: none;" href="#" id="takest"></a><br>
</center>
<center>
<form action="" method="post" class="cls" style="display: none;" id="takestu" enctype="multipart/form-data">
 <div>
 <?php 
include "connection.php";
?> 
	<label><select style="width:15%;" name="class_name" id="class_name" required ><br>
                   
                    <?php
		$cccc = 0;
		$cccc2 = 0;				
	$result = mysqli_query($db, "SELECT class_name FROM classes");
						while($row = mysqli_fetch_assoc($result))
							{ 
								echo '<option>';
								if($ctype=="Js"){
								if($cccc == 0){	
									$cccc++;
									echo 'SELECT A CLASS';
									continue;
									}		
								if($cccc <= 3){
								echo 'JS'.$cccc;	
								}
								elseif($cccc >= 4 && $cccc <= 6){
									if($cccc == 4){	
									$cccc++;
									echo 'SS'.($cccc2 - 2);	
									continue;
									}
									if($cccc == 5){	
									$cccc++;
									echo 'SS'.($cccc2 - 1);	
									continue;
									}
									if($cccc == 6){	
									$cccc++;
									echo 'SS'.($cccc2 - 0);	
									continue;
									}
								}else{
									break;
								}
								$cccc++;	
								$cccc2++;
									}
								else{	
								if($ctype=="Primary"){
									if($cccc == 0){	
									$cccc++;
									echo 'SELECT A CLASS';
									continue;
									}
								echo 'Primary '.$cccc;
								if($cccc > 5){
									break;
								}
								$cccc++;	
								}
								else{
								echo 'Year '.$cccc;
								if($cccc > 11){
									break;
								}
								$cccc++;	
								}
								}//end of else
								echo '</option>';
							}
						?>
      </select>
	   <br>
	  <?php
	  echo '<select style="width: 210px; height: auto; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="arms" id="arms" required >';
	 $result = mysqli_query($db,"SELECT arms FROM school where school='".$_SESSION["school"]."'");
				while($row = mysqli_fetch_assoc($result)){
					$arrr2[] = $row["arms"];
				}
				$a = implode(',',$arrr2);
				$b = explode(',',$a);
				$f = (array_filter($b));
				
						for($i=0; $i<=(count($f)-1); $i++)
							{  
								echo '<option value="'.$f[$i].'">';
								echo $f[$i];
								echo '</option>';
							}
    echo '</select>';
?>	
	  <br>
	  <select style="width:15%;" name="year" id="year" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT year FROM years");
	echo '<option value="none" disabled="disabled" selected>SESSION COMMENCING</option>';
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['year'].'">';
								echo $row['year'];
								echo '</option>';
							}
						?>
      </select>
	  
	  
	   <br>
	  <select style="width:15%;" name="term" id="term" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT term FROM terms");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['term'].'">';
								echo $row['term'];
								echo '</option>';
							}
						?>
      </select>
	   <br>
	  <select style="width:15%;" name="subject" id="subject" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT subject FROM subjects ORDER BY subject");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['subject'].'">';
								echo $row['subject'];
								echo '</option>';
							}
						?>
      </select>
	  
	   <br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT teacher_id FROM users2 where username='$user' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<input style="display:none" type="hidden" name="teacher_id" value="'.$row['teacher_id'].'">';
							}
						?>  
	  
	  </label>
	  
  <label>
      <input type="submit" class="button" name="btn-upload" id="getscoresbutton" value="Get Scores" />
    </label>

  </div>
  </center>
</form><br>


<?php
//if(isset($_POST['btn-upload'])){
	
$user=$_SESSION['username'];
$result3 = mysqli_query($db, "SELECT * FROM users2 where username='$user' AND school='".$_SESSION["school"]."'");
while($rowtid = mysqli_fetch_assoc($result3))
{
	$a = $rowtid['teacher_id'];
}
$tid =  $a;	
		
$classd = $_POST['class_name'];
$year = $_POST['year'];
$term = $_POST['term'];
$subject = $_POST['subject'];
$arms = $_POST['arms'];
$teacher_id = $tid;  

//echo $classd;

if($classd=='Primary 1'){
		$class_name = 'Year 1';
	}
	elseif($classd=='Primary 2'){
		$class_name = 'Year 2';
	}
	elseif($classd=='Primary 3'){
		$class_name = 'Year 3';
	}
	elseif($classd=='Primary 4'){
		$class_name = 'Year 4';
	}
	elseif($classd=='Primary 5'){
		$class_name = 'Year 5';
	}
	elseif($classd=='Primary 6'){
		$class_name = 'Year 6';
	}	
	elseif($classd=='JS1'){
		$class_name = 'Year 7';
	}
	elseif($classd=='JS2'){
		$class_name = 'Year 8';
	}
	elseif($classd=='JS3'){
		$class_name = 'Year 9';
	}
	elseif($classd=='SS1'){
		$class_name = 'Year 10';
	}
	elseif($classd=='SS2'){
		$class_name = 'Year 11';
	}	
	elseif($classd=='SS3'){
		$class_name = 'Year 12';
	}		
	else{
		$class_name = $classd;
	}	
//echo $classd;

$resultcheck2 = mysqli_query($db, "SELECT * FROM scores where arms='$arms' AND class_name='$class_name' AND year='$year' AND term='$term' AND subject='$subject' AND teacher_id='$teacher_id' AND school='".$_SESSION["school"]."' ORDER BY student_name ASC");
$resultcount2 = mysqli_num_rows($resultcheck2);   
if($resultcount2 == 0){
	echo ''; 
}else{
echo '<center>';
echo '<input type="text" placeholder="Max Hw Score" class="txtFirstName" id="txtFirstName">&nbsp;&nbsp;';
echo '<input type="text" placeholder="Max Cw Score" class="txtFirstName1" id="txtFirstName1">&nbsp;&nbsp;';
echo '<input type="text" placeholder="Max Test Score" class="txtFirstName2" id="txtFirstName2">&nbsp;&nbsp;';
echo '<input type="text" placeholder="Max Exam Score" class="txtFirstName3" id="txtFirstName3"><br>';
echo '<button id="dosomething" style="background-color: green; color: white;">Update Max Scores</button>';
echo '<div id="maxupdated" style="background-color: green; color: white; display: none;">Max Scores Updated. Submit Form To Save</div>';
echo '<div style="font-weight: bold; text-decoration: underline;">NOTE THAT MAX CW, HW AND TEST SCORES ARE FOR ONLY THE 2ND HALF OF THE TERM.<br>TO UPDATE MAX SCORES FOR FIRST HALF, <a style="background-color: black; color: white;" href="update-score-mid.php">CLICK HERE.</a></div>';
echo '</center><br>';
}

if($ctype=="Primary"){
	$cl = str_replace("Year","Primary",$classd);
}else{
	$cl = $classd;
}
$resultcheck = mysqli_query($db, "SELECT * FROM scores where arms='$arms' AND class_name='$class_name' AND year='$year' AND term='$term' AND subject='$subject' AND teacher_id='$teacher_id' AND school='".$_SESSION["school"]."' ORDER BY student_name ASC");
$resultcount = mysqli_num_rows($resultcheck);   
if($resultcount == 0){
	echo '<center><span style="color: red; font-size: 16px;">no scores to be updated, given the selected criteria.<br /></span></center>'; 
}else{
echo '<center><span style="color: green; font-size: 16px;">Update the scores of students in your '.$term. ', '.$year.'/'.($year+1).' Session, '.$cl.' '.$arms.', '.$subject.' class.<br /></span></center>';            
	include "connection.php";
	
$resultcheckstu = mysqli_query($db, "SELECT * FROM scores where arms='$arms' AND class_name='$class_name' AND year='$year' AND term='$term' AND subject='$subject' AND teacher_id='$teacher_id' AND school='".$_SESSION["school"]."' ORDER BY student_name ASC");
while($rowmidstu = mysqli_fetch_assoc($resultcheckstu))
{
	$student_na2[] = $rowmidstu['student_name'];
}
$student_na = $student_na2;

$student_nacount = count($student_na);

for($ccount = 0; $ccount<$student_nacount; $ccount++)
{
//include "connection.php";	
$resultmidstt = mysqli_query($db, "SELECT * FROM scoresmid WHERE arms='$arms' AND student_name='$student_na[$ccount]' AND class_name='$class_name' AND year='$year' AND term='$term' AND subject='$subject' AND teacher_id='$teacher_id' AND school='".$_SESSION["school"]."' ORDER BY student_name ASC");	
while($rowmidstt = mysqli_fetch_assoc($resultmidstt))
{ 
 $scor2[] = $rowmidstt['score'];
 $scorraw2[] = $rowmidstt['scoreraw'];
 $hwmaxmid2[] = $rowmidstt['hwmaxname'];
 $cwmaxmid2[] = $rowmidstt['cwmaxname'];
 $testmaxmid2[] = $rowmidstt['testmaxname'];
 break;
}
}
$scor = $scor2;
$scorraw = $scorraw2;
$hwmaxmid = $hwmaxmid2;
$cwmaxmid = $cwmaxmid2;
$testmaxmid = $testmaxmid2;
	$countmid = 0;
?>


<div id="remarkdiv" style="text-align: center; color: green;"><br><br><br>
<span style="background-color: red; color: white;"><span>TEACHER'S REMARK CONCERNING:&nbsp;</span><span id="thestname"></span></span><br>
<textarea style="width: 50%; height: 250px; color: green;" type="text" id="remarkdivta"></textarea>
<input type="text" id="track" />
<input type="text" id="oldval" /><br>
<button class="le" style="float: left; margin-left: 25%;">previous</button>
<button class="endit" style="margin: auto; background-color: black;">close</button>
<button class="ri" style="float: right; margin-right: 25%;">next</button>
</div>
<form class="formid" id="formid">
<?php
echo '<div style="border: 0;">';
echo '<input type="submit" class="submit_button" name="submit" value="Update Scores" />';
echo '<label style="border: 0;">';
echo '<span class="error" style="display:none; color: red;"><img src="table/del.jpg" width="60" height="60"/>An update error has just occurred.</span>';
echo '<span class="success" style="display:none; color: green;"><img src="table/492.png" width="60" height="60"/> Scores updated successfully.</span>';
echo '</label>';
echo '</div>';
?>

<table id="example" class="display" cellspacing="0" width="100%">
        <thead>
            <tr>
<th style="display: none;">Score ID</th>
<th>Students Name</th>
<th>Term Total (%)</th>
<th>Midterm Total (%)</th>
<th>Midterm Total (Raw)</th>
<th style="width: 7px;" >HW (RAW)</th>
<th style="width: 7px;" >CW (RAW)</th>
<th style="width: 7px;" >TEST (RAW)</th>
<th>CA (RAW)</th>
<th style="width: 7px;">EXAM (RAW)</th>
<th>HW (30)</th>
<th>CW (30)</th>
<th>TEST (40)</th>
<th>CA (40)</th>
<th>Exam (60)</th>
<th>Remark</th>
<th style="display: none;">Class</th>
<th style="display: none;">Year</th>
<th style="display: none;" >Arm</th>
<th style="display: none;">Term</th>
<th style="display: none;">Subject</th>
<th style="display: none;">Teacher ID</th>
<th style="display: none;">-</th>
<th style="display: none;">-</th>
<th style="display: none;">-</th>
<th style="display: none;">-</th>
<th style="display: none;">-</th>
<th style="display: none;">-</th>
<th style="display: none;">-</th>
            </tr>
        </thead>
        <tfoot>
            <tr>
<th style="display: none;">Score ID</th>
<th>Students Name</th>
<th>Term Total (%)</th>
<th>Midterm Total (%)</th>
<th>Midterm Total (Raw)</th>
<th style="width: 7px;" >HW (RAW)</th>
<th style="width: 7px;" >CW (RAW)</th>
<th style="width: 7px;" >TEST (RAW)</th>
<th>CA (RAW)</th>
<th style="width: 7px;">EXAM (RAW)</th>
<th>HW (30)</th>
<th>CW (30)</th>
<th>TEST (40)</th>
<th>CA (40)</th>
<th>Exam (60)</th>
<th>Remark</th>
<th style="display: none;">Class</th>
<th style="display: none;">Year</th>
<th style="display: none;" >Arm</th>
<th style="display: none;">Term</th>
<th style="display: none;">Subject</th>
<th style="display: none;">Teacher ID</th>
<th style="display: none;">-</th>
<th style="display: none;">-</th>
<th style="display: none;">-</th>
<th style="display: none;">-</th>
<th style="display: none;">-</th>
<th style="display: none;">-</th>
<th style="display: none;">-</th>
            </tr>
        </tfoot>
        <tbody>
<?php
$countmidupd = 0;
$counters=0;
$countpop=0;	
$upd = mysqli_query($db, "SELECT * FROM scores where arms='$arms' AND class_name='$class_name' AND year='$year' AND term='$term' AND subject='$subject' AND teacher_id='$teacher_id' AND school='".$_SESSION["school"]."' ORDER BY student_name ASC");
					while($rowupd = mysqli_fetch_assoc($upd))
							{  
							if($scor[$countmidupd]!=""){
							$scoreupd2[] = round(((($rowupd['hw']+$rowupd['cw']+$rowupd['test']+$scor[$countmidupd])/200)*40)+$rowupd['exam']);
							$carawupd2[] = round($rowupd['hwraw']+$rowupd['cwraw']+$rowupd['testraw']+$scorraw[$countmidupd]);
							$caallupd2[] = round(((($rowupd['hw']+$rowupd['cw']+$rowupd['test']+$scor[$countmidupd])/200)*40));
							}
							else{
							$scoreupd2[] = round(((($rowupd['hw']+$rowupd['cw']+$rowupd['test'])/100)*40)+$rowupd['exam']);
							$carawupd2[] = round($rowupd['hwraw']+$rowupd['cwraw']+$rowupd['testraw']);	
							$caallupd2[] = round(((($rowupd['hw']+$rowupd['cw']+$rowupd['test'])/100)*40));
							}
							$countmidupd++;
							}
							$scoreupd = $scoreupd2;
							$carawupd = $carawupd2;
							$caallupd = $caallupd2;
	
          $result = mysqli_query($db, "SELECT * FROM scores where arms='$arms' AND class_name='$class_name' AND year='$year' AND term='$term' AND subject='$subject' AND teacher_id='$teacher_id' AND school='".$_SESSION["school"]."' ORDER BY student_name ASC");
					while($row = mysqli_fetch_assoc($result))
							{  
							 echo '<tr>';
							 echo '<td style="display: none;"><input type="text" name="score_id[]" id="score_id" value="'.$row['score_id'].'" readonly="readonly" /></td>';
							 echo '<td><input type="text" style="display: none;" name="student_name[]" id="student_name" value="'.$row['student_name'].'" readonly /><span id="student_name'.$counters.'">'.$row['student_name'].'</span></td>';
							 echo '<td style="text-align: center;"><input style="display: none;" type="text" value="'.$scoreupd[$countmid].'" name="score[]" id="score"/><span id="score'.$counters.'" class="score">'.$scoreupd[$countmid].'</span></td>';
							 echo '<td style="text-align: center;"><input style="display: none;" type="text" value="'.$scor[$countmid].'" name="scoremid[]" id="scoremid" /><span id="scoresmid'.$counters.'">'.$scor[$countmid].'</span></td>';
							 echo '<td style="text-align: center;"><input style="display: none;" type="text" value="'.$scorraw[$countmid].'" name="scoremidraw[]" id="scoremidraw" /><span id="scoresmidraw'.$counters.'">'.$scorraw[$countmid].'<span></td>';  	
							 echo '<td style="text-align: center; width: 7px;"><input style="text-align: center; width: 50%;" type="text" value="'.$row['hwraw'].'" name="hwraw[]" id="hwraw" /></td>';
							 echo '<td style="text-align: center; width: 7px;"><input style="text-align: center; width: 50%;"  type="text" value="'.$row['cwraw'].'" name="cwraw[]" id="cwraw" /></td>';
							 echo '<td style="text-align: center; width: 7px;"><input style="text-align: center; width: 50%;"  type="text" value="'.$row['testraw'].'" name="testraw[]" id="testraw" /></td>';
							 echo '<td style="text-align: center;"><input style="display: none;" type="text" value="'.$carawupd[$countmid].'" name="caraw[]" id="caraw" readonly/><span id="caraw'.$counters.'">'.$carawupd[$countmid].'</span></td>';
							 echo '<td style="text-align: center; width: 7px; "><input style="text-align: center; width: 50%;" type="text"  value="'.$row['examraw'].'" name="examraw[]" id="examraw" /></td>';
							 echo '<td style="text-align: center;"><input style="display: none;" type="text" value="'.$row['hw'].'" name="hw[]" id="hw" readonly/><span id="hw'.$counters.'">'.$row['hw'].'</span></td>';
							 echo '<td style="text-align: center;"><input style="display: none;" type="text" value="'.$row['cw'].'" name="cw[]" id="cw" readonly/><span id="cw'.$counters.'">'.$row['cw'].'</span></td>';
							 echo '<td style="text-align: center;"><input style="display: none;" type="text" value="'.$row['test'].'" name="test[]" id="test" readonly/><span id="test'.$counters.'">'.$row['test'].'</span></td>';
							 echo '<td style="text-align: center;"><input style="display: none;" type="text" value="'.$caallupd[$countmid].'" name="ca[]" id="ca" readonly/><span id="ca'.$counters.'">'.$caallupd[$countmid].'</span></td>';
							 echo '<td style="text-align: center;"><input style="display: none;" type="text"  value="'.$row['exam'].'" name="exam[]" id="exam" readonly/><span id="exam'.$counters.'">'.$row['exam'].'</span></td>';
							 
							  if($row['remark']!=""){
						      $rrm = $row['remark'];
							  }else{
							  $rrm = "------";  
							  }
							 echo '<td class="nc" id="g'.$countmid.'">';
							 echo '<textarea style="display: none;" class="remark" type="text" value="'.$row['remark'].'" name="remark[]" id="remark_'.$countmid.'" >'.$rrm.'</textarea>';
							 echo '<span style="display: none;" class="'.$countmid.'">'.$row['student_name'].'</span>';
							 echo '<span style="cursor: pointer; display: block;" name="'.$row['student_name'].'" class="group" id="'.$countmid.'">'.$rrm.'</span>';
							 echo '</td>';
							 
							 echo '<td style="display: none;"><input type="text" name="class_name[]" id="class_name" value="'.$row['class_name'].'"></td>';
							 echo '<td style="display: none;"><input type="text" name="year[]" id="year" value="'.$row['year'].'"></td>';
							 echo '<td style="display: none;"><input type="text" name="arms[]" id="arms" value="'.$row['arms'].'"></td>';
							 echo '<td style="display: none;"><input type="text" name="term[]" id="term" value="'.$row['term'].'"></td>';
							 echo '<td style="display: none;"><input type="text" name="subject[]" id="subject" value="'.$row['subject'].'"></td>';
							 echo '<td style="display: none;"><input type="text" name="teacher_id[]" id="teacher_id" value="'.$row['teacher_id'].'"></td>';
							 echo '<td style="display: none;"><input style="text-align: center;" class="newhwmax" type="text" name="hwmaxname[]" id="hwmaxname" value="'.$row['hwmaxname'].'" readonly></td>';
							 echo '<td style="display: none;"><input style="text-align: center;" class="newcwmax" type="text" name="cwmaxname[]" id="cwmaxname" value="'.$row['cwmaxname'].'" readonly></td>';
							 echo '<td style="display: none;"><input style="text-align: center;" class="newtestmax" type="text" name="testmaxname[]" id="testmaxname" value="'.$row['testmaxname'].'" readonly></td>';
							 echo '<td style="display: none;"><input style="text-align: center;" class="newexammax" type="text" name="exammaxname[]" id="exammaxname" value="'.$row['exammaxname'].'" readonly></td>';
							 echo '<td style="display: none;"><input style="text-align: center;" class="hwmaxmid" type="text" name="hwmaxmid[]" id="hwmaxmid" value="'.$hwmaxmid[$countmid].'" readonly></td>';
							 echo '<td style="display: none;"><input style="text-align: center;" class="cwmaxmid" type="text" name="cwmaxmid[]" id="cwmaxmid" value="'.$cwmaxmid[$countmid].'" readonly></td>';
							 echo '<td style="display: none;"><input  style="text-align: center;" class="testmaxmid" type="text" name="testmaxmid[]" id="testmaxmid" value="'.$testmaxmid[$countmid].'" readonly></td>';
							 echo '</tr>';
							$countmid++;
							$counters++;
							$countpop++;
							}
		?>				
        </tbody>
    </table>
<div style="border: 0;">
<input type="submit" class="submit_button" name="submit" value="Update Scores" />
<label style="border: 0;">
<span class="error" style="display:none; color: red;"><img src="table/del.jpg" width="60" height="60"/>An update error has just occurred.</span>
<span class="success" style="display:none; color: green;"><img src="table/492.png" width="60" height="60"/> Scores updated successfully.</span>
</label>
</div>
</form>	
<?php
}
?>		
<br>
</div><div id="pushit"><div id="pushit2">&nbsp;</div><br><br><br><br><br><br><br><br><br><br></div>
<?php
include("footer.php");
?>
</body>
</html>