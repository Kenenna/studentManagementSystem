<?php
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
if (isset($_REQUEST['btn-upload'])) {
$id = $_REQUEST['id'];
$teacher_id = $_REQUEST['teacher_id'];
$teacher_name = $_REQUEST['teacher_name'];
$class_name2 = $_REQUEST['class_name2'];
$year = $_REQUEST['year'];
$term = $_REQUEST['term'];
$arms = $_REQUEST['arms'];

$b = "";
if($class_name2=="Primary 1"){
	$class_name = "Year 1";
}
else if($class_name2=="Primary 2"){
	$class_name = "Year 2";
}
else if($class_name2=="Primary 3"){
	$class_name = "Year 3";
}
else if($class_name2=="Primary 4"){
	$class_name = "Year 4";
}
else if($class_name2=="Primary 5"){
	$class_name = "Year 5";
}
else if($class_name2=="Primary 6"){
	$class_name = "Year 6";
}
else if($class_name2=="JS1"){
	$class_name = "Year 7";
}
else if($class_name2=="JS2"){
	$class_name = "Year 8";
}
else if($class_name2=="JS3"){
	$class_name = "Year 9";
}
else if($class_name2=="SS1"){
	$class_name = "Year 10";
}
else if($class_name2=="SS2"){
	$class_name = "Year 11";
}
else if($class_name2=="SS3"){
	$class_name = "Year 12";
}
else{
	$class_name = $class_name2;
}

$checktea = mysqli_query($db, "SELECT * FROM formt where teacher_id='$teacher_id' AND teacher_name='$teacher_name' AND year='$year' AND term='$term' AND class_name='$class_name' AND arms='$arms' AND school='".$_SESSION["school"]."'");
  $counttea = mysqli_num_rows($checktea);
  if($counttea < 1){ 
$query =("UPDATE formt SET year='$year', term='$term', class_name='$class_name', arms='$arms', school='".$_SESSION["school"]."' WHERE id='$id'");

if (!mysqli_query ($db,$query) )
			{
			echo '<img src="../images/492.png" /> &nbsp;! data not updated';
			echo '<meta content="2;admviewtutor.php" http-equiv="refresh" />';	
			die (mysqli_error());
			}else{
		echo '<img src="../images/492.png" /> &nbsp;! data updated successfully';
		echo '<meta content="2;admviewtutor.php" http-equiv="refresh" />';
			}
  }else{
	echo "<center><div class='form'><h5 style='color: red;'>A teacher with the given name teaching the given class for that term and year already exists.</h5></div></center>";
	echo '<meta content="2;admviewtutor.php" http-equiv="refresh" />';
  }
}
?>