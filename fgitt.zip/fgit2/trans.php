<!DOCTYPE html>
<html>
<head>
<meta ="charset=UTF-8" />
<title>Untitled Document</title>
<style>
#mainone {
  margin: auto;  
  position: absolute;
  left:0;
  right: 0;
  top: 0;
  bottom: 0;
} 
table, th, td {
    border: 1px solid black;
	margin: 0 auto;  
}
table, th, td {
    font-size: 12px;
}
table {
	width: 50%;
}
td {
	width: 3%;
}
.intable {
	color:red;
	font-weight: bold;
}
</style>
</head>
<body>
<div id="mainone">
<?php
		$student_name = $_POST['student_name'];
echo '<div style="text-align: center; font-size: 16px; color: red;">'.strtoupper($student_name).'\'S ACADEMIC RECORD</div>';
?>
<?php
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
echo '<div style="float:left; height:auto; margin:1px;">';
echo '<table>';
echo '<tr>';
echo '<th colspan="3">';

		include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year;
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		echo $y;
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		echo $y;
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		echo $y;
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		echo $y;
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		echo $y;
		}
		else{
			$y = 'Year 12';
		echo $y;
		}
	
	echo '</th>';
	echo '</tr>';

echo '<tr>';
echo '<td><table style="width:100%;">';
echo '<tr><th colspan="3">1st Term</th></tr>';
echo '<tr class="intable"><td>SUBJECT</td><td>SCORE</td><td>GRADE</td></tr>';
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' ORDER BY subject ASC");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
								echo '<tr><td>'.$row["subject"].'</td><td>'.$row["score"].'</td><td>'.$grade.'</td></tr>';	
							}	
echo '</table></td>';
echo '<td><table style="width:100%;">';
echo '<tr><th colspan="3">2nd Term</th></tr>';

include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year;
		//echo $year2;
		//$term = $_POST['term'];
	echo '<tr class="intable"><td>SUBJECT</td><td>SCORE</td><td>GRADE</td></tr>';	
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' ORDER BY subject ASC");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
								echo '<tr><td>'.$row["subject"].'</td><td>'.$row["score"].'</td><td>'.$grade.'</td></tr>';	
							}	
echo '</table></td>';
echo '<td><table style="width:100%;">';
echo '<tr><th colspan="3">3rd Term</th></tr>';

include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year;
		//echo $year2;
		//$term = $_POST['term'];
	echo '<tr class="intable"><td>SUBJECT</td><td>SCORE</td><td>GRADE</td></tr>';	
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' ORDER BY subject ASC");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
								echo '<tr><td>'.$row["subject"].'</td><td>'.$row["score"].'</td><td>'.$grade.'</td></tr>';	
							}	
echo '</table></td>';
echo '</tr>';
echo '</table>';
echo '</div>';
}
?>

<?php
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
echo '<div style="float:left; height:auto; margin:1px;">';
echo '<table>';
echo '<tr>';
echo '<th colspan="3">';

	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		echo $y;
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		echo $y;
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		echo $y;
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		echo $y;
		}
		else{
			$y = 'Year 12';
		echo $y;
		}
	
	echo '</th>';
	echo '</tr>';

echo '<tr>';
echo '<td><table style="width:100%;">';
echo '<tr><th colspan="3">1st Term</th></tr>';
echo '<tr class="intable"><td>SUBJECT</td><td>SCORE</td><td>GRADE</td></tr>';
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' ORDER BY subject ASC");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
								echo '<tr><td>'.$row["subject"].'</td><td>'.$row["score"].'</td><td>'.$grade.'</td></tr>';	
							}	
echo '</table></td>';
echo '<td><table style="width:100%;">';
echo '<tr><th colspan="3">2nd Term</th></tr>';

include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		//echo $year2;
		//$term = $_POST['term'];
	echo '<tr class="intable"><td>SUBJECT</td><td>SCORE</td><td>GRADE</td></tr>';	
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' ORDER BY subject ASC");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
								echo '<tr><td>'.$row["subject"].'</td><td>'.$row["score"].'</td><td>'.$grade.'</td></tr>';	
							}	
echo '</table></td>';
echo '<td><table style="width:100%;">';
echo '<tr><th colspan="3">3rd Term</th></tr>';

include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		//echo $year2;
		//$term = $_POST['term'];
	echo '<tr class="intable"><td>SUBJECT</td><td>SCORE</td><td>GRADE</td></tr>';	
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' ORDER BY subject ASC");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
								echo '<tr><td>'.$row["subject"].'</td><td>'.$row["score"].'</td><td>'.$grade.'</td></tr>';	
							}	
echo '</table></td>';
echo '</tr>';
echo '</table>';
echo '</div>';
}
?>

<?php
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
echo '<div style="float:left; height:auto; margin:1px;">';
echo '<table>';
echo '<tr>';
echo '<th colspan="3">';

include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		echo $y;
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		echo $y;
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		echo $y;
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		echo $y;
		}
		else{
			$y = 'NA';
		echo $y;
		}
	
	echo '</th>';
	echo '</tr>';

echo '<tr>';
echo '<td><table style="width:100%;">';
echo '<tr><th colspan="3">1st Term</th></tr>';
echo '<tr class="intable"><td>SUBJECT</td><td>SCORE</td><td>GRADE</td></tr>';
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' ORDER BY subject ASC");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
								echo '<tr><td>'.$row["subject"].'</td><td>'.$row["score"].'</td><td>'.$grade.'</td></tr>';	
							}	
echo '</table></td>';
echo '<td><table style="width:100%;">';
echo '<tr><th colspan="3">2nd Term</th></tr>';

include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		//echo $year2;
		//$term = $_POST['term'];
	echo '<tr class="intable"><td>SUBJECT</td><td>SCORE</td><td>GRADE</td></tr>';	
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' ORDER BY subject ASC");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
								echo '<tr><td>'.$row["subject"].'</td><td>'.$row["score"].'</td><td>'.$grade.'</td></tr>';	
							}	
echo '</table></td>';
echo '<td><table style="width:100%;">';
echo '<tr><th colspan="3">3rd Term</th></tr>';

include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		//echo $year2;
		//$term = $_POST['term'];
	echo '<tr class="intable"><td>SUBJECT</td><td>SCORE</td><td>GRADE</td></tr>';	
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' ORDER BY subject ASC");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
								echo '<tr><td>'.$row["subject"].'</td><td>'.$row["score"].'</td><td>'.$grade.'</td></tr>';	
							}	
echo '</table></td>';
echo '</tr>';
echo '</table>';
echo '</div>';
}
?>

<?php
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
echo '<div style="float:left; height:auto; margin:1px;">';
echo '<table>';
echo '<tr>';
echo '<th colspan="3">';
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		echo $y;
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		echo $y;
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		echo $y;
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 13';
		echo $y;
		}
		else if($class_name == 'Year 11'){
		$y = 'NA';
		echo $y;
		}
		else{
			$y = 'NA';
		echo $y;
		}
	
	echo '</th>';
	echo '</tr>';

echo '<tr>';
echo '<td><table style="width:100%;">';
echo '<tr><th colspan="3">1st Term</th></tr>';
echo '<tr class="intable"><td>SUBJECT</td><td>SCORE</td><td>GRADE</td></tr>';
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' ORDER BY subject ASC");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
								echo '<tr><td>'.$row["subject"].'</td><td>'.$row["score"].'</td><td>'.$grade.'</td></tr>';	
							}	
echo '</table></td>';
echo '<td><table style="width:100%;">';
echo '<tr><th colspan="3">2nd Term</th></tr>';

include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		//echo $year2;
		//$term = $_POST['term'];
	echo '<tr class="intable"><td>SUBJECT</td><td>SCORE</td><td>GRADE</td></tr>';	
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' ORDER BY subject ASC");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
								echo '<tr><td>'.$row["subject"].'</td><td>'.$row["score"].'</td><td>'.$grade.'</td></tr>';	
							}	

echo '</table></td>';
echo '<td><table style="width:100%;">';
echo '<tr><th colspan="3">3rd Term</th></tr>';

include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		//echo $year2;
		//$term = $_POST['term'];
	echo '<tr class="intable"><td>SUBJECT</td><td>SCORE</td><td>GRADE</td></tr>';	
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' ORDER BY subject ASC");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
								echo '<tr><td>'.$row["subject"].'</td><td>'.$row["score"].'</td><td>'.$grade.'</td></tr>';	
							}	
echo '</table></td>';
echo '</tr>';
echo '</table>';
echo '</div>';
}
?>

<?php
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
echo '<div style="float:left; height:auto; margin:1px;">';
echo '<table>';
echo '<tr>';
echo '<th colspan="3">';
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		echo $y;
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		echo $y;
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 13';
		echo $y;
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 14';
		echo $y;
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 15';
		echo $y;
		}
		else{
			$y = 'NA';
		echo $y;
		}
	
	echo '</th>';
	echo '</tr>';

echo '<tr>';
echo '<td><table style="width:100%;">';
echo '<tr><th colspan="3">1st Term</th></tr>';
echo '<tr class="intable"><td>SUBJECT</td><td>SCORE</td><td>GRADE</td></tr>';
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' ORDER BY subject ASC");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
								echo '<tr><td>'.$row["subject"].'</td><td>'.$row["score"].'</td><td>'.$grade.'</td></tr>';	
							}	
echo '</table></td>';
echo '<td><table style="width:100%;">';
echo '<tr><th colspan="3">2nd Term</th></tr>';

include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		//echo $year2;
		//$term = $_POST['term'];
	echo '<tr class="intable"><td>SUBJECT</td><td>SCORE</td><td>GRADE</td></tr>';	
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' ORDER BY subject ASC");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
								echo '<tr><td>'.$row["subject"].'</td><td>'.$row["score"].'</td><td>'.$grade.'</td></tr>';	
							}	

echo '</table></td>';
echo '<td><table style="width:100%;">';
echo '<tr><th colspan="3">3rd Term</th></tr>';

include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		//echo $year2;
		//$term = $_POST['term'];
	echo '<tr class="intable"><td>SUBJECT</td><td>SCORE</td><td>GRADE</td></tr>';	
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' ORDER BY subject ASC");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
								echo '<tr><td>'.$row["subject"].'</td><td>'.$row["score"].'</td><td>'.$grade.'</td></tr>';	
							}	
echo '</table></td>';
echo '</tr>';
echo '</table>';
echo '</div>';
}
?>


<?php
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
echo '<div style="float:left; height:auto; margin:1px;">';
echo '<table>';
echo '<tr>';
echo '<th colspan="3">';
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		echo $y;
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 13';
		echo $y;
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 14';
		echo $y;
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 15';
		echo $y;
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 16';
		echo $y;
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 17';
		echo $y;
		}
		else{
			$y = 'NA';
		echo $y;
		}
	
	echo '</th>';
	echo '</tr>';

echo '<tr>';
echo '<td><table style="width:100%;">';
echo '<tr><th colspan="3">1st Term</th></tr>';
echo '<tr class="intable"><td>SUBJECT</td><td>SCORE</td><td>GRADE</td></tr>';
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' ORDER BY subject ASC");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
								echo '<tr><td>'.$row["subject"].'</td><td>'.$row["score"].'</td><td>'.$grade.'</td></tr>';	
							}	
echo '</table></td>';
echo '<td><table style="width:100%;">';
echo '<tr><th colspan="3">2nd Term</th></tr>';
echo '<tr class="intable"><td>SUBJECT</td><td>SCORE</td><td>GRADE</td></tr>';
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		//echo $year2;
		//$term = $_POST['term'];
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' ORDER BY subject ASC");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
								echo '<tr><td>'.$row["subject"].'</td><td>'.$row["score"].'</td><td>'.$grade.'</td></tr>';	
							}	

echo '</table></td>';
echo '<td><table style="width:100%;">';
echo '<tr><th colspan="3">3rd Term</th></tr>';

include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		//echo $year2;
		//$term = $_POST['term'];
	echo '<tr class="intable"><td>SUBJECT</td><td>SCORE</td><td>GRADE</td></tr>';	
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' ORDER BY subject ASC");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
								echo '<tr><td>'.$row["subject"].'</td><td>'.$row["score"].'</td><td>'.$grade.'</td></tr>';	
							}	
echo '</table></td>';
echo '</tr>';
echo '</table>';
echo '</div>';
}
?>




</div>

</body>
</html>