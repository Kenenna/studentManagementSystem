<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start(); // this MUST be called prior to any output including whitespaces and line breaks!

$GLOBALS['DEBUG_MODE'] = 1;
// CHANGE TO 0 TO TURN OFF DEBUG MODE
// IN DEBUG MODE, ONLY THE CAPTCHA CODE IS VALIDATED, AND NO EMAIL IS SENT

$GLOBALS['ct_recipient']   = 'YOU@EXAMPLE.COM'; // Change to your email address!  Make sure DEBUG_MODE above is 0 for mail to send!
$GLOBALS['ct_msg_subject'] = 'Securimage Test Contact Form';

$GLOBALS['errmsg'] = " ";

process_si_contact_form(); // Process the form, if it was submitted
if (isset($_SESSION['ctform']['error']) &&  $_SESSION['ctform']['error'] == true): /* The last form submission had 1 or more errors */ ?>
<div class="error">There was a problem with your submission.  Errors are displayed below.</div><br>
<?php elseif (isset($_SESSION['ctform']['success']) && $_SESSION['ctform']['success'] == true): /* form was processed successfully */ ?>
<div class="success">The captcha was correct!</div><br />
<?php endif; ?>

<?php
function process_si_contact_form()
{
  $_SESSION['ctform'] = array(); // re-initialize the form session data

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  	// if the form has been submitted

    foreach($_POST as $key => $value) {
      if (!is_array($key)) {
      	// sanitize the input data
        if ($key != 'ct_message') $value = strip_tags($value);
        $_POST[$key] = htmlspecialchars(stripslashes(trim($value)));
      }
    }
    $captcha = @$_POST['ct_captcha']; // the user's entry for the captcha code
    $errors = array();  // initialize empty error array

    if (isset($GLOBALS['DEBUG_MODE']) && $GLOBALS['DEBUG_MODE'] == false) {
      // only check for errors if the form is not in debug mode
    }

    // Only try to validate the captcha if the form has no errors
    // This is especially important for ajax calls
    if (sizeof($errors) == 0) {
      require_once dirname(__FILE__) . '/securimage.php';
      $securimage = new Securimage();
      if ($securimage->check($captcha) == false) {
        $errors['captcha_error'] = 'Incorrect security code entered<br />';
      }
    }

    if (sizeof($errors) == 0) {
include("connection.php");
//This code runs if the form has been submitted
if (isset($_POST['submit']))
{
	$email = $_POST['remail'];
  // checks if the username is in use
$check = mysqli_query($db,"SELECT username FROM users2 WHERE email = '$email'")or die(mysqli_error());
$check2 = mysqli_num_rows($check);

// check for valid email address
$email = $_POST['remail'];
$pattern = "/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,})$/";
if (!preg_match($pattern, trim($email))) {
  $GLOBALS['errmsg'] = 'Please enter a valid email address';
}

//if the name exists it gives an error
if ($check2 == 0) {
$GLOBALS['errmsg'] = 'Sorry, we cannot find your account details please try another email address.';
}
// if no errors then carry on
if ($check2!=0) {
$query = mysqli_query($db,"SELECT username FROM users2 WHERE email = '$email' ")or die (mysqli_error());
$r = mysqli_fetch_object($query);
$password = substr(md5(uniqid(rand(),1)),3,10);
$pass = md5($password); //encrypted version for database entry

$to = "$email";
$subject = "Account Details Recovery";
$body = "Hi $r->username, nn you or someone else have requested your account details. nn Here is your account information please keep this as you may need this at a later stage. nnYour username is $r->username nn your password is $password nn Your password has been reset please login and change your password to something more rememberable.nn Regards, Admin at the tutoraid.com.ng";
$additionalheaders = "From: <admin@thetutoraid.com.ng>";
$additionalheaders .= "Reply-To: noprely@thetutoraid.com.ng";
mail($to, $subject, $body, $additionalheaders);

$sql = mysqli_query($db,"UPDATE users2 SET password='$pass' WHERE email = '$email'")or die (mysqli_error());
//$rsent = true;
//$rows = mysqli_num_rows($sql);
if($sql){
 $GLOBALS['errmsg'] = "sent!";
}else{
$GLOBALS['errmsg'] = "password not updated!".$rows; 
}
}// close errors
}// close if form sent

//show any errors
// close if empty errors
    } else {
      foreach($errors as $key => $error) {
      	// set up error messages to display with each field
        $_SESSION['ctform'][$key] = "<span class=\"error\">$error</span>";
      }
      $_SESSION['ctform']['error'] = false; // set error floag
    }
  } // POST
}
//$_SESSION['ctform']['success'] = false; // clear success value after running


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Reset Pass</title>
<link rel="stylesheet" href="securimage.css" media="screen">   
<style>
ul.topnav {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}
ul.topnav li {float: left;}
ul.topnav li a {
    display: inline-block;
    color: #f2f2f2;
    text-align: center;
    padding: 12px 14px;
    text-decoration: none;
    transition: 0.3s;
    font-size: 14px;
}
ul.topnav li a:hover {background-color: #555;}
ul.topnav li.icon {display: none;}

@media screen and (max-width:680px) {
  ul.topnav li:not(:first-child) {display: none;}
  ul.topnav li.icon {
    float: right;
    display: inline-block;
  }
}
@media screen and (max-width:680px) {
  ul.topnav.responsive {position: relative;}
  ul.topnav.responsive li.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  ul.topnav.responsive li {
    float: none;
    display: inline;
  }
  ul.topnav.responsive li a {
    display: block;
    text-align: left;
  }
}
.pbutton {
	background-color:#44c767;
	border:1px solid #18ab29;
	display:inline-block;
	color:#ffffff;
	font-family:Arial;
	font-size:15px;
	padding:6px 24px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
}
</style>
  <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>
 <style>
 .center-div
{
     margin: 0 auto;
     width: 265px; 
}
</style>
<style>
ul.topnav {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}
ul.topnav li {float: left;}
ul.topnav li a {
    display: inline-block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    transition: 0.3s;
    font-size: 17px;
}
ul.topnav li a:hover {background-color: #555;}
ul.topnav li.icon {display: none;}

@media screen and (max-width:680px) {
  ul.topnav li:not(:first-child) {display: none;}
  ul.topnav li.icon {
    float: right;
    display: inline-block;
  }
}
@media screen and (max-width:680px) {
  ul.topnav.responsive {position: relative;}
  ul.topnav.responsive li.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  ul.topnav.responsive li {
    float: none;
    display: inline;
  }
  ul.topnav.responsive li a {
    display: block;
    text-align: left;
  }
}
</style>
<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>
</head>

<body>
 <ul class="topnav" id="myTopnav">
 <li><a href="index.php">Log In</a></li>    
<li><a href="Registration.php">Sign Up</a></li>
<li class="icon">
<a href="javascript:void(0);" onclick="myFunction()">&#9776;</a>
</li>
</ul> 
<br>
<center>
<?php
echo $errmsg; 
	?>
</center>	
<center>
    <div class="center-div">
<form action="<?php echo htmlspecialchars($_SERVER['REQUEST_URI'] . $_SERVER['QUERY_STRING']) ?>" method="post">
    <input type="hidden" name="do" value="contact">
<p><input type="text" name="remail" placeholder="Enter Email" style="width: 265px;" maxlength="200"><br>
<div>
    <?php
      // show captcha HTML using Securimage::getCaptchaHtml()
      require_once 'securimage.php';
      $options = array();
      $options['input_name'] = 'ct_captcha'; // change name of input element for form post
      $options['disable_flash_fallback'] = false; // allow flash fallback

      if (!empty($_SESSION['ctform']['captcha_error'])) {
        // error html to show in captcha output
        $options['error_html'] = '<div style="color: red;">'.$_SESSION['ctform']['captcha_error'].'</div><br>';
      }

      echo "<br><div id='captcha_container_1'>\n";
      echo Securimage::getCaptchaHtml($options);
      echo "\n</div>\n";
    ?>
  </div>
<br><input type="submit" name="submit" class="pbutton" value="Get New Password"></p>
</form>
</div>
</center>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<?php
include("footer.php");
?>
</body>
</html>