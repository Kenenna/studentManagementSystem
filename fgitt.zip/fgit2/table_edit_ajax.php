<?php
session_start();
include("auth.php");
include("db.php");
if($_POST['id'])
{
$id=mysql_escape_String($_POST['id']);
$firstname=mysql_escape_String($_POST['firstname']);
$lastname=mysql_escape_String($_POST['lastname']);
$midname=mysql_escape_String($_POST['midname']);
$pfirstname=mysql_escape_String($_POST['pfirstname']);
$plastname=mysql_escape_String($_POST['plastname']);
$pmidname=mysql_escape_String($_POST['pmidname']);
$sql = "update affective set firstname='$firstname',lastname='$lastname',midname='$midname',pfirstname='$pfirstname',plastname='$plastname',pmidname='$pmidname' where id='$id' AND school='".$_SESSION["school"]."'";
mysql_query($sql);
}
?>