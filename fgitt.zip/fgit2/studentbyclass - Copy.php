<?php
include "connection.php";

$student_name = $_POST['student_name'];
$teacher_id = $_POST['teacher_id'];
$class = $_POST['class'];
$year = $_POST['year'];
$term = $_POST['term'];
$subject = $_POST['subject'];









for ($i = 0; $i <= (count($student_name)-1); $i++){
    $t = mysqli_query($db,"INSERT INTO students(student_name, teacher_id, class_name, year, term, subject) VALUES('$student_name[$i]','$teacher_id','$class', '$year', '$term', '$subject')");
}	

if($t){
	echo "scores saved successfully";
	//echo '<meta content="2;subjstudents.php" http-equiv="refresh" />';
}	
else{
	echo "not saved";
}
	
?>

<?php
// close connection
mysql_close();
?>