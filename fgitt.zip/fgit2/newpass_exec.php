<?php
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
$username = $_POST["username"];
$password = $_POST["password"];
$oldpassword = $_POST["oldp"];
$rpass = mysqli_query($db, "SELECT * FROM users2 where username='$username' AND school='".$_SESSION["school"]."'");
while($rowpass2 = mysqli_fetch_assoc($rpass))
{
	$psw2[] = $rowpass2['password'];
}
$psw = current($psw2);
$pass = md5($oldpassword);
$passnew = md5($password);
if($pass==$psw){
	$sql = mysqli_query($db, "UPDATE users2 SET password='$passnew' WHERE username='$username' AND school='".$_SESSION["school"]."'");
	echo 1;
}else{
	echo 0;
}
//if($sql){
//	echo 1;
//}
//else{
//	echo 0;
//}
?>