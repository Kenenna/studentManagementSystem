<?php
	session_start();
	include("auth.php");
	include("connection.php");	
echo '<div class="div1" >';
 $result = mysqli_query($db,"SELECT * FROM users2 where username='".$_SESSION["username"]."'");
				while($row = mysqli_fetch_assoc($result)){
				echo '<form method="POST" action="choosearms.php" style="width: 298px; margin-bottom: 0.5em;" >';	
				echo '<input style="display: none;" type="text" name="school" value="'.$row['school'].'" >';
				echo '<input type="submit" style="background-color: green; color: white; width: 100%;" class="button" name="btns-upload" value="'.$row['school'].'" >';
				echo '</form><br><br>';	
				}
				
echo '</div>';
echo '<a href="logout.php" class="pbutton" >Logout</a>';
?>
<!DOCTYPE html>
<html lang="en">
<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Choose School</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="Description" lang="en" content="Choose School">
		<meta name="author" content="School Management System">
		<meta name="robots" content="index, follow">
<style>
	.div1 {
    width: 700px;
    height: 50%;
    background-color: red;
    position: absolute;
    top: 15px;
    bottom: 0;
    left: 0;
    right: 0;
    margin: auto;
}
.pbutton {
	background-color:#44c767;
	-moz-border-radius:28px;
	-webkit-border-radius:28px;
	border-radius:12px;
	border:1px solid #18ab29;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:15px;
	padding:6px 24px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
	margin-bottom: 2px;
}
.pbutton:hover {
	background-color:#5cbf2a;
}
.pbutton:active {
	position:relative;
	top:1px;
}
@media only screen and (max-width: 600px) {
    .pbutton {
        margin-bottom: 100px;
    }
    	.div1 {
    width: 300px;
    	}
</style>		
</head>
<body style="background-color: #eaf0f2;">
</body>
</html>