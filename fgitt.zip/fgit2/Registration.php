<?php
	session_start();
require_once('db.php');
?>
<!DOCTYPE html>
<html>
<head>
<link href="table/css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
<link rel="stylesheet" type="text/css" href="table/css/DT_bootstrap.css">
<script src="table/js/jquery.js" type="text/javascript"></script>
<script src="table/js/bootstrap.js" type="text/javascript"></script>
<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/jquery.dataTables.js"></script>
<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/DT_bootstrap.js"></script>
 <link rel="stylesheet" href="css/style.css" /> 
   <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>
<style>
ul.topnav {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}
ul.topnav li {float: left;}
ul.topnav li a {
    display: inline-block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    transition: 0.3s;
    font-size: 17px;
}
ul.topnav li a:hover {background-color: #555;}
ul.topnav li.icon {display: none;}

@media screen and (max-width:680px) {
  ul.topnav li:not(:first-child) {display: none;}
  ul.topnav li.icon {
    float: right;
    display: inline-block;
  }
}
@media screen and (max-width:680px) {
  ul.topnav.responsive {position: relative;}
  ul.topnav.responsive li.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  ul.topnav.responsive li {
    float: none;
    display: inline;
  }
  ul.topnav.responsive li a {
    display: block;
    text-align: left;
  }
}
</style>

<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>
<script type='text/javascript'>
function refreshCaptcha(){
	var img = document.images['captchaimg'];
	img.src = img.src.substring(0,img.src.lastIndexOf("?"))+"?rand="+Math.random()*1000;
}
</script>
</head>
<body>
<?php
echo '<ul class="topnav" id="myTopnav">';
echo '<li><a href="index.php">Login</a></li>';
echo '<li class="icon">';
echo '<a href="javascript:void(0);" onclick="myFunction()">&#9776;</a>';
echo '</li>';
echo '</ul>';
?>   
<?php
if(isset($_POST['submit'])){
	if(empty($_SESSION['captcha_code'] ) || strcasecmp($_SESSION['captcha_code'], $_POST['captcha_code']) != 0){  
    $msg="<span style='color:red'>The Validation code does not match!</span>";
    }
    else
    {
		$role = $_POST['role'];
        $teacher = $_POST['teacher'];
		 $school = $_POST['school'];
		$username = $_POST['username'];
		$email = $_POST['email'];
        $password = $_POST['password'];
		$username = stripslashes($username);
		$username = mysql_real_escape_string($username);
		$email = stripslashes($email);
		$email = mysql_real_escape_string($email);
		$school = stripslashes($school);
		$school = mysql_real_escape_string($school);
		$password = stripslashes($password);
		$password = mysql_real_escape_string($password);
		$trn_date = date("Y-m-d H:i:s");
		
		$resultcheck = mysql_query("SELECT * FROM users2 WHERE username='$username' AND school='$school'");
		$resultcount = mysql_num_rows($resultcheck);
		
		if($resultcount < 1){
        $query = "INSERT into `users2` (role, teacher, username, password, email, trn_date, school) VALUES('$role', '$teacher', '$username', '".md5($password)."', '$email', '$trn_date', '$school')";
        $result = mysql_query($query);
		}
		else{
			echo "Username for the school has already been taken";
		}
	}
}
	
        if($result){
            echo "<div class='form'><h3>You are registered successfully.</h3></div>";
        }
?>
<div class="form">
<h3>Registration</h3>
<?php
if(isset($_POST['submit'])){
echo $msg;
}
?>
<form name="registration" action="" method="post">
<select type="text" name="role"  required="" style="height: auto;" />
<option value="" disabled="disabled" selected="selected" >Pick A Role</option>
<option value="student" >student</option>
<option value="teacher" >teacher</option>
<option value="admin" >admin</option>
<option value="principal" >principal/head teacher</option>
</select><br>
<input type="text" name="teacher" placeholder="Your Name" required />
 <select name="school" id="school" required="" style="height: auto;" ><br>     
                    <?php
	$result = mysql_query("SELECT * FROM school");
	echo '<option value="" disabled="disabled" selected="selected" >Pick A School</option>';
	while($row = mysql_fetch_assoc($result))
							{  
								echo '<option value="'.$row['school'].'">';
								echo $row['school'];
								echo '</option>';
							}
						?>
      </select>
<input type="text" name="username" placeholder="Username" required />
<input type="email" name="email" placeholder="Email" />
<input type="password" name="password" placeholder="Password" required />
 <div><img src="captcha.php?rand=<?php echo rand();?>" id='captchaimg'><br>
        <label for='message'>Enter the code above below :</label>
        <input id="captcha_code" name="captcha_code" type="text">
        <br>
        Can't read the image? click <a href='javascript: refreshCaptcha();'>here</a> to refresh.</div>
<input type="submit" name="submit" value="Register" />
</form>
</div>
<?php
include("footer.php");
?>
</body>
</html>
