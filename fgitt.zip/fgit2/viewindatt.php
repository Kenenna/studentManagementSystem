<?php
	session_start();
	include ("connection.php");
	include("auth.php"); 
	include('db.php');
	$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Individual Attendance</title>
<style>
.myButton {
	background-color:#44c767;
	-moz-border-radius:28px;
	-webkit-border-radius:28px;
	border-radius:2px;
	border:1px solid #18ab29;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:17px;
	padding:6px 24px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
}
.myButton:hover {
	background-color:#5cbf2a;
}
.myButton:active {
	position:relative;
	top:1px;
}
</style>
<style>
ul.topnav {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}
ul.topnav li {float: left;}
ul.topnav li a {
    display: inline-block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    transition: 0.3s;
    font-size: 17px;
}
ul.topnav li a:hover {background-color: #555;}
ul.topnav li.icon {display: none;}

@media screen and (max-width:680px) {
  ul.topnav li:not(:first-child) {display: none;}
  ul.topnav li.icon {
    float: right;
    display: inline-block;
  }
}
@media screen and (max-width:680px) {
  ul.topnav.responsive {position: relative;}
  ul.topnav.responsive li.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  ul.topnav.responsive li {
    float: none;
    display: inline;
  }
  ul.topnav.responsive li a {
    display: block;
    text-align: left;
  }
}
</style>

  
   <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>
<script src="table/js/jquery.js" type="text/javascript"></script>
<script>
$(document).ready(function() {	
$("#indattpdf").submit(function( evt ) {
			evt.preventDefault();
var countlist = $("#resultlist li").length;	
if(countlist > 0){
$(".liresultlist").fadeOut(500); 	
}		
$.ajax({
type: "POST",
url: "pdf4/examples/viewindattpdf.php",
cache: false,
data: $("#indattpdf").serializeArray(),
beforeSend: function(){
	$("#loadit").addClass("loader");
	$("#loadit").after("<label id='forremoval' style='color: red;' >We are preparing your download. Please wait...</label>");
	$('#attpdfsubmit').attr( 'onClick', 'return false' );
	},
success: function(response){
$("#resultlist").append("<li class='liresultlist'><a class='myButton' style='margin: auto; text-align: id='forresult' center;' href='pdf4/examples/"+response+"' download>download attendance record</a></li>");	
},
complete: function(){
$("#loadit").removeClass("loader");	
$("#forremoval").remove();
$('#attpdfsubmit').attr( 'onClick', 'return true' );
}
});			
});
});
</script>

<style>
table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    border: 1px solid #ddd;
}

th, td {
    border: none;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>

<style>
.loader {
  border: 8px solid #f3f3f3;
  border-radius: 50%;
  border-top: 8px solid blue;
  border-right: 8px solid green;
  border-bottom: 8px solid red;
  width: 20px;
  height: 20px;
  -webkit-animation: spin 2s linear infinite;
  animation: spin 2s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.dnone{
	display: none;
}
</style>
 <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>

</head>

<body>
<?php
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
else{header("location: logout.php");}
?>
<?php
$class = $_POST['class'];
$arms = $_POST['arms'];
$year = $_POST['year'];
$term = $_POST['term'];
$student_name = $_POST['student_name'];
$formt = $_POST['formt'];

$result3 = mysqli_query($db, "SELECT * FROM maxattname WHERE year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($row3 = mysqli_fetch_assoc($result3)) {
$termbegin1[] = $row3['termbegin'];	
}
$termbegin = current($termbegin1);

$result2 = mysqli_query($db, "SELECT * FROM attend where student_name='$student_name' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$result = mysqli_query($db, "SELECT DISTINCT(student_name) FROM attend where student_name='$student_name' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");

$result5 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$termbegin') AND (datename <= DATE_ADD( '$termbegin', INTERVAL 4 DAY )) AND student_name='$student_name' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$redate = mysqli_num_rows($result5);
$result6 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$termbegin') AND (datename <= DATE_ADD( '$termbegin', INTERVAL 4 DAY )) AND (attend='present' OR schoolopen='yes') AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att1 = (mysqli_num_rows($result6) * 2);
$result6a = mysqli_query($db, "SELECT * FROM attend where (datename >= '$termbegin') AND (datename <= DATE_ADD( '$termbegin', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND attend='midterm' AND school='".$_SESSION["school"]."'");
$chmida = mysqli_num_rows($result6a);

$tb = (round(abs(strtotime($termbegin) + 604800)));
$tb1 = date("Y-m-d", $tb);
$result7 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 4 DAY )) AND student_name='$student_name' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$redate7 = mysqli_num_rows($result7);
$result8 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 4 DAY )) AND (attend='present' OR schoolopen='yes') AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att2 = (mysqli_num_rows($result8) * 2);
$result6b = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND attend='midterm' AND school='".$_SESSION["school"]."'");
$chmidb = mysqli_num_rows($result6b);

$tb2 = (round(abs(strtotime($tb1) + 604800)));
$tb3 = date("Y-m-d", $tb2);
$result9 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb3') AND (datename <= DATE_ADD( '$tb3', INTERVAL 4 DAY )) AND student_name='$student_name' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$redate9 = mysqli_num_rows($result9);
$result10 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb3') AND (datename <= DATE_ADD( '$tb3', INTERVAL 4 DAY )) AND (attend='present' OR schoolopen='yes') AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att3 = (mysqli_num_rows($result10) * 2);
$result6c = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb3') AND (datename <= DATE_ADD( '$tb3', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND attend='midterm' AND school='".$_SESSION["school"]."'");
$chmidc = mysqli_num_rows($result6c);

$tb4 = (round(abs(strtotime($tb3) + 604800)));
$tb5 = date("Y-m-d", $tb4);
$result11 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb5') AND (datename <= DATE_ADD( '$tb5', INTERVAL 4 DAY )) AND student_name='$student_name' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$redate11 = mysqli_num_rows($result11);
$result12 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb5') AND (datename <= DATE_ADD( '$tb5', INTERVAL 4 DAY )) AND (attend='present' OR schoolopen='yes') AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att4 = (mysqli_num_rows($result12) * 2);
$result6d = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb5') AND (datename <= DATE_ADD( '$tb5', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND attend='midterm' AND school='".$_SESSION["school"]."'");
$chmidd = mysqli_num_rows($result6d);

$tb6 = (round(abs(strtotime($tb5) + 604800)));
$tb7 = date("Y-m-d", $tb6);
$result13 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb7') AND (datename <= DATE_ADD( '$tb7', INTERVAL 4 DAY )) AND student_name='$student_name' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$redate13 = mysqli_num_rows($result13);
$result14 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb7') AND (datename <= DATE_ADD( '$tb7', INTERVAL 4 DAY )) AND (attend='present' OR schoolopen='yes') AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att5 = (mysqli_num_rows($result14) * 2);
$result6e = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb7') AND (datename <= DATE_ADD( '$tb7', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND attend='midterm' AND school='".$_SESSION["school"]."'");
$chmide = mysqli_num_rows($result6e);
//echo $midtermopen;

$tb8 = (round(abs(strtotime($tb7) + 604800)));
$tb9 = date("Y-m-d", $tb8);
$result15 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb9') AND (datename <= DATE_ADD( '$tb9', INTERVAL 4 DAY )) AND student_name='$student_name' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$redate15 = mysqli_num_rows($result15);
$result16 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb9') AND (datename <= DATE_ADD( '$tb9', INTERVAL 4 DAY )) AND (attend='present' OR schoolopen='yes') AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att6 = (mysqli_num_rows($result16) * 2);
$result6f = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb9') AND (datename <= DATE_ADD( '$tb9', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND attend='midterm' AND school='".$_SESSION["school"]."'");
$chmidf = mysqli_num_rows($result6f);

$tb10 = (round(abs(strtotime($tb9) + 604800)));
$tb11 = date("Y-m-d", $tb10);
$result17 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb11') AND (datename <= DATE_ADD( '$tb11', INTERVAL 4 DAY )) AND student_name='$student_name' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$redate17 = mysqli_num_rows($result17);
$result18 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb11') AND (datename <= DATE_ADD( '$tb11', INTERVAL 4 DAY )) AND (attend='present' OR schoolopen='yes') AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att7 = (mysqli_num_rows($result18) * 2);
$result6g = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb11') AND (datename <= DATE_ADD( '$tb11', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND attend='midterm' AND school='".$_SESSION["school"]."'");
$chmidg = mysqli_num_rows($result6g);

$tb12 = (round(abs(strtotime($tb11) + 604800)));
$tb13 = date("Y-m-d", $tb12);
$result19 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb13') AND (datename <= DATE_ADD( '$tb13', INTERVAL 4 DAY )) AND student_name='$student_name' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$redate19 = mysqli_num_rows($result19);
$result20 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb13') AND (datename <= DATE_ADD( '$tb13', INTERVAL 4 DAY )) AND (attend='present' OR schoolopen='yes') AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att8 = (mysqli_num_rows($result20) * 2);
$result6h = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb13') AND (datename <= DATE_ADD( '$tb13', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND attend='midterm' AND school='".$_SESSION["school"]."'");
$chmidh = mysqli_num_rows($result6h);

$tb14 = (round(abs(strtotime($tb13) + 604800)));
$tb15 = date("Y-m-d", $tb14);
$result21 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb15') AND (datename <= DATE_ADD( '$tb15', INTERVAL 4 DAY )) AND student_name='$student_name' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$redate21 = mysqli_num_rows($result21);
$result22 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb15') AND (datename <= DATE_ADD( '$tb15', INTERVAL 4 DAY )) AND (attend='present' OR schoolopen='yes') AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att9 = (mysqli_num_rows($result22) * 2);
$result6i = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb15') AND (datename <= DATE_ADD( '$tb15', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND attend='midterm' AND school='".$_SESSION["school"]."'");
$chmidi = mysqli_num_rows($result6i);

$tb16 = (round(abs(strtotime($tb15) + 604800)));
$tb17 = date("Y-m-d", $tb16);
$result23 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb17') AND (datename <= DATE_ADD( '$tb17', INTERVAL 4 DAY )) AND student_name='$student_name' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$redate23 = mysqli_num_rows($result23);
$result24 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb17') AND (datename <= DATE_ADD( '$tb17', INTERVAL 4 DAY )) AND (attend='present' OR schoolopen='yes') AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att10 = (mysqli_num_rows($result24) * 2);
$result6j = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb15') AND (datename <= DATE_ADD( '$tb15', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND attend='midterm' AND school='".$_SESSION["school"]."'");
$chmidj = mysqli_num_rows($result6j);

$tb18 = (round(abs(strtotime($tb17) + 604800)));
$tb19 = date("Y-m-d", $tb18);
$result25 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb19') AND (datename <= DATE_ADD( '$tb19', INTERVAL 4 DAY )) AND student_name='$student_name' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$redate25 = mysqli_num_rows($result25);
$result26 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb19') AND (datename <= DATE_ADD( '$tb19', INTERVAL 4 DAY )) AND (attend='present' OR schoolopen='yes') AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att11 = (mysqli_num_rows($result26) * 2);
$result6k = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb19') AND (datename <= DATE_ADD( '$tb19', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND attend='midterm' AND school='".$_SESSION["school"]."'");
$chmidk = mysqli_num_rows($result6k);


$tb20 = (round(abs(strtotime($tb19) + 604800)));
$tb21 = date("Y-m-d", $tb20);
$result27 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb21') AND (datename <= DATE_ADD( '$tb21', INTERVAL 4 DAY )) AND student_name='$student_name' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$redate27 = mysqli_num_rows($result27);
$result28 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb21') AND (datename <= DATE_ADD( '$tb21', INTERVAL 4 DAY )) AND (attend='present' OR schoolopen='yes') AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att12 = (mysqli_num_rows($result28) * 2);
$result6l = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb21') AND (datename <= DATE_ADD( '$tb21', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND attend='midterm' AND school='".$_SESSION["school"]."'");
$chmidl = mysqli_num_rows($result6l);

$tb22 = (round(abs(strtotime($tb21) + 604800)));
$tb23 = date("Y-m-d", $tb22);
$result29 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb23') AND (datename <= DATE_ADD( '$tb23', INTERVAL 4 DAY )) AND student_name='$student_name' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$redate29 = mysqli_num_rows($result29);
$result30 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb23') AND (datename <= DATE_ADD( '$tb23', INTERVAL 4 DAY )) AND (attend='present' OR schoolopen='yes') AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att13 = (mysqli_num_rows($result30) * 2);
$result6m = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb23') AND (datename <= DATE_ADD( '$tb23', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND attend='midterm' AND school='".$_SESSION["school"]."'");
$chmidm = mysqli_num_rows($result6m);


$tb24 = (round(abs(strtotime($tb23) + 604800)));
$tb25 = date("Y-m-d", $tb24);
$result31 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb25') AND (datename <= DATE_ADD( '$tb25', INTERVAL 4 DAY )) AND student_name='$student_name' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$redate31 = mysqli_num_rows($result31);
$result32 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb25') AND (datename <= DATE_ADD( '$tb25', INTERVAL 4 DAY )) AND (attend='present' OR schoolopen='yes') AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att14 = (mysqli_num_rows($result32) * 2);
$result6n = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb25') AND (datename <= DATE_ADD( '$tb25', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND attend='midterm' AND school='".$_SESSION["school"]."'");
$chmidn = mysqli_num_rows($result6n);



$redatetotal = $redate + $redate7 + $redate9 + $redate11 + $redate13 + $redate15  + $redate17 + $redate19 + $redate21  + $redate23 + $redate25 + $redate27 + $redate29  + $redate31;
$atttotal = $att1 + $att2 + $att3 + $att4 + $att5 + $att6 + $att7 + $att8 + $att9 + $att10 + $att11 + $att12 + $att13 + $att14;

$resultcount = mysqli_num_rows($result2);

echo "<br><br><br>";
if($class=="Year 1"){
	if($ctype=="Js"){
	$cl = "JS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 1";
}else{
	$cl = "Year 1";
}
}
elseif($class=="Year 2"){
	if($ctype=="Js"){
	$cl = "JS2";
}elseif($ctype=="Primary"){
	$cl = "Primary 2";
}else{
	$cl = "Year 2";
}
}
elseif($class=="Year 3"){
	if($ctype=="Js"){
	$cl = "JS3";
}elseif($ctype=="Primary"){
	$cl = "Primary 3";
}else{
	$cl = "Year 3";
}
}
elseif($class=="Year 4"){
	if($ctype=="Js"){
	$cl = "SS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 4";
}else{
	$cl = "Year 4";
}
}
elseif($class=="Year 5"){
	if($ctype=="Js"){
	$cl = "SS2";
}elseif($ctype=="Primary"){
	$cl = "Primary 5";
}else{
	$cl = "Year 5";
}
}
elseif($class=="Year 6"){
	if($ctype=="Js"){
	$cl = "SS3";
}elseif($ctype=="Primary"){
	$cl = "Primary 6";
}else{
	$cl = "Year 6";
}
}
elseif($class=="Year 7"){
	if($ctype=="Js"){
	$cl = "JS1";
}else{
	$cl = "Year 7";
}
}
else if($class=="Year 8"){
	if($ctype=="Js"){
	$cl = "JS2";
}else{
	$cl = "Year 8";
}
}else if($class=="Year 9"){
	if($ctype=="Js"){
	$cl = "JS3";
}else{
	$cl = "Year 9";
}
}else if($class=="Year 10"){
	if($ctype=="Js"){
	$cl = "SS1";
}else{
	$cl = "Year 10";
}
}else if($class=="Year 11"){
	if($ctype=="Js"){
	$cl = "SS2";
}else{
	$cl = "Year 11";
}
}else if($class=="Year 12"){
	if($ctype=="Js"){
	$cl = "SS3";
}else{
	$cl = "Year 12";
}
}else{
	$cl = "NOT APPLICABLE";
}

if(!isset($_POST['submit'])){
echo '<div style="width:100%; text-align:center; color: red;">NUMBER OF TIMES IN '.strtoupper($term).', '.$year.'/'.($year+1).' SESSION, '.strtoupper($student_name).' OF '.strtoupper($cl).' '.strtoupper($arms).' WAS PRESENT PER WEEK</div>';
echo '<table table style="width:100%;" cellpadding="1" cellspacing="1" border="1" class="table table-striped table-bordered" id="example">';
echo '<thead><tr><th style="text-align:center;"> Attendance Data for '.$student_name.'</th><th style="text-align:center;">Times Present in Week</th><th style="text-align:center;">Times Sch. Open in Week</th></tr></thead>';
while ($row = mysqli_fetch_assoc($result)) {
echo '<tr>';
echo '<td style="text-align:center;">Week 1</td>';
if($chmida > 0){
	echo '<td style="text-align:center;">MIDTERM</td>';
	echo '<td style="text-align:center;">'.$att1.'</td>';
}
else{
echo '<td style="text-align:center;">'.$redate.'</td>';
echo '<td style="text-align:center;">'.$att1.'</td>';
}
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;">Week 2</td>';
if($chmidb > 0){
	echo '<td style="text-align:center;">MIDTERM</td>';
	echo '<td style="text-align:center;">'.$att2.'</td>';
}
else{
echo '<td style="text-align:center;">'.$redate7.'</td>';
echo '<td style="text-align:center;">'.$att2.'</td>';
}
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;">Week 3</td>';
if($chmidc > 0){
	echo '<td style="text-align:center;">MIDTERM</td>';
	echo '<td style="text-align:center;">'.$att3.'</td>';
}
else{
echo '<td style="text-align:center;">'.$redate9.'</td>';
echo '<td style="text-align:center;">'.$att3.'</td>';
}
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;">Week 4</td>';
if($chmidd > 0){
	echo '<td style="text-align:center;">MIDTERM</td>';
	echo '<td style="text-align:center;">'.$att4.'</td>';
}
else{
echo '<td style="text-align:center;">'.$redate11.'</td>';
echo '<td style="text-align:center;">'.$att4.'</td>';
}
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;">Week 5</td>';
if($chmide > 0){
	echo '<td style="text-align:center;">MIDTERM</td>';
	echo '<td style="text-align:center;">'.$att5.'</td>';
}
else{
echo '<td style="text-align:center;">'.$redate13.'</td>';
echo '<td style="text-align:center;">'.$att5.'</td>';
}
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;">Week 6</td>';
if($chmidf > 0){
	echo '<td style="text-align:center;">MIDTERM</td>';
	echo '<td style="text-align:center;">'.$att6.'</td>';
}
else{
echo '<td style="text-align:center;">'.$redate15.'</td>';
echo '<td style="text-align:center;">'.$att6.'</td>';
}
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;">Week 7</td>';
if($chmidg > 0){
	echo '<td style="text-align:center;">MIDTERM</td>';
	echo '<td style="text-align:center;">'.$att7.'</td>';
}
else{
	echo '<td style="text-align:center;">'.$redate17.'</td>';
	echo '<td style="text-align:center;">'.$att7.'</td>';
}
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;">Week 8</td>';
if($chmidh > 0){
	echo '<td style="text-align:center;">MIDTERM</td>';
	echo '<td style="text-align:center;">'.$att8.'</td>';
}
else{
echo '<td style="text-align:center;">'.$redate19.'</td>';
echo '<td style="text-align:center;">'.$att8.'</td>';
}
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;">Week 9</td>';
if($chmidi > 0){
	echo '<td style="text-align:center;">MIDTERM</td>';
	echo '<td style="text-align:center;">'.$att9.'</td>';
}
else{
echo '<td style="text-align:center;">'.$redate21.'</td>';
echo '<td style="text-align:center;">'.$att9.'</td>';
}
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;">Week 10</td>';
if($chmidj > 0){
	echo '<td style="text-align:center;">MIDTERM</td>';
	echo '<td style="text-align:center;">'.$att10.'</td>';
}
else{
echo '<td style="text-align:center;">'.$redate23.'</td>';
echo '<td style="text-align:center;">'.$att10.'</td>';
}
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;">Week 11</td>';
if($chmidk > 0){
	echo '<td style="text-align:center;">MIDTERM</td>';
	echo '<td style="text-align:center;">'.$att11.'</td>';
}
else{
echo '<td style="text-align:center;">'.$redate25.'</td>';
echo '<td style="text-align:center;">'.$att11.'</td>';
}
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;">Week 12</td>';
if($chmidl > 0){
	echo '<td style="text-align:center;">MIDTERM</td>';
	echo '<td style="text-align:center;">'.$att12.'</td>';
}
else{
echo '<td style="text-align:center;">'.$redate27.'</td>';
echo '<td style="text-align:center;">'.$att12.'</td>';
}
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;">Week 13</td>';
if($chmidm > 0){
	echo '<td style="text-align:center;">MIDTERM</td>';
	echo '<td style="text-align:center;">'.$att13.'</td>';
}
else{
echo '<td style="text-align:center;">'.$redate29.'</td>';
echo '<td style="text-align:center;">'.$att13.'</td>';
}
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;">Week 14</td>';
if($chmidn > 0){
	echo '<td style="text-align:center;">MIDTERM</td>';
	echo '<td style="text-align:center;">'.$att14.'</td>';
}
else{
echo '<td style="text-align:center;">'.$redate31.'</td>';
echo '<td style="text-align:center;">'.$att14.'</td>';
}
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;">TOTAL</td>';
echo '<td style="text-align:center;">'.$redatetotal.'</td>';
echo '<td style="text-align:center;">'.$atttotal.'</td>';
echo '</tr>';
}
echo '</table>';
}

else{
echo '<div style="width:100%; text-align:center; color: red;">NUMBER OF TIMES IN '.strtoupper($term).', '.$year.' '.strtoupper($student_name).' OF '.strtoupper($cl).' '.strtoupper($arms).' WAS PRESENT PER WEEK</div>';
$student_name= $_POST['student_name'];		
$redate = $_POST['redate'];	
$redate7 = $_POST['redate7'];	
$redate9 = $_POST['redate9'];
$redate11 = $_POST['redate11'];
$redate13 = $_POST['redate13'];	
$redate15 = $_POST['redate15'];	
$redate17 = $_POST['redate17'];
$redate19 = $_POST['redate19'];
$redate21 = $_POST['redate21'];	
$redate23 = $_POST['redate23'];
$redate25 = $_POST['redate25'];	
$redate27 = $_POST['redate27'];	
$redate29 = $_POST['redate29'];
$redate31 = $_POST['redate31'];	

$att1 =	$_POST["att1"];
$att2 =	$_POST["att2"];
$att3 =	$_POST["att3"];
$att4 =	$_POST["att4"];
$att5 =	$_POST["att5"];
$att6 =	$_POST["att6"];
$att7 =	$_POST["att7"];
$att8 =	$_POST["att8"];
$att9 =	$_POST["att9"];
$att10 = $_POST["att10"];
$att11 = $_POST["att11"];
$att12 = $_POST["att12"];
$att13 = $_POST["att13"];
$att14 = $_POST["att14"];

$chmida =	$_POST["chmida"];
$chmidb =	$_POST["chmidb"];
$chmidc =	$_POST["chmidc"];
$chmidd =	$_POST["chmidd"];
$chmide =	$_POST["chmide"];
$chmidf =	$_POST["chmidf"];
$chmidg =	$_POST["chmidg"];
$chmidh =	$_POST["chmidh"];
$chmidi =	$_POST["chmidi"];
$chmidj =	$_POST["chmidj"];
$chmidk =	$_POST["chmidk"];
$chmidl =	$_POST["chmidl"];
$chmidm =	$_POST["chmidm"];
$chmidn =	$_POST["chmidn"];

echo '<table table style="width:100%;" cellpadding="1" cellspacing="1" border="1" class="table table-striped table-bordered" id="example">';
echo '<thead><tr><th style="text-align:center;"> Attendance Data for '.$student_name.'</th><th style="text-align:center;">Times Present in Week</th><th style="text-align:center;">Times Sch. Open in Week</th></tr></thead>';
echo '<tr>';
echo '<td style="text-align:center;">Week 1</td>';
if($chmida > 0){
	echo '<td style="text-align:center;">MIDTERM</td>';
	echo '<td style="text-align:center;">'.$att1.'</td>';
}
else{
echo '<td style="text-align:center;">'.$redate.'</td>';
echo '<td style="text-align:center;">'.$att1.'</td>';
}
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;">Week 2</td>';
if($chmidb > 0){
	echo '<td style="text-align:center;">MIDTERM</td>';
	echo '<td style="text-align:center;">'.$att2.'</td>';
}
else{
echo '<td style="text-align:center;">'.$redate7.'</td>';
echo '<td style="text-align:center;">'.$att2.'</td>';
}
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;">Week 3</td>';
if($chmidc > 0){
	echo '<td style="text-align:center;">MIDTERM</td>';
	echo '<td style="text-align:center;">'.$att3.'</td>';
}
else{
echo '<td style="text-align:center;">'.$redate9.'</td>';
echo '<td style="text-align:center;">'.$att3.'</td>';
}
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;">Week 4</td>';
if($chmidd > 0){
	echo '<td style="text-align:center;">MIDTERM</td>';
	echo '<td style="text-align:center;">'.$att4.'</td>';
}
else{
echo '<td style="text-align:center;">'.$redate11.'</td>';
echo '<td style="text-align:center;">'.$att4.'</td>';
}
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;">Week 5</td>';
if($chmide > 0){
	echo '<td style="text-align:center;">MIDTERM</td>';
	echo '<td style="text-align:center;">'.$att5.'</td>';
}
else{
echo '<td style="text-align:center;">'.$redate13.'</td>';
echo '<td style="text-align:center;">'.$att5.'</td>';
}
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;">Week 6</td>';
if($chmidf > 0){
	echo '<td style="text-align:center;">MIDTERM</td>';
	echo '<td style="text-align:center;">'.$att6.'</td>';
}
else{
echo '<td style="text-align:center;">'.$redate15.'</td>';
echo '<td style="text-align:center;">'.$att6.'</td>';
}
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;">Week 7</td>';
if($chmidg > 0){
	echo '<td style="text-align:center;">MIDTERM</td>';
	echo '<td style="text-align:center;">'.$att7.'</td>';
}
else{
	echo '<td style="text-align:center;">'.$redate17.'</td>';
	echo '<td style="text-align:center;">'.$att7.'</td>';
}
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;">Week 8</td>';
if($chmidh > 0){
	echo '<td style="text-align:center;">MIDTERM</td>';
	echo '<td style="text-align:center;">'.$att8.'</td>';
}
else{
echo '<td style="text-align:center;">'.$redate19.'</td>';
echo '<td style="text-align:center;">'.$att8.'</td>';
}
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;">Week 9</td>';
if($chmidi > 0){
	echo '<td style="text-align:center;">MIDTERM</td>';
	echo '<td style="text-align:center;">'.$att9.'</td>';
}
else{
echo '<td style="text-align:center;">'.$redate21.'</td>';
echo '<td style="text-align:center;">'.$att9.'</td>';
}
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;">Week 10</td>';
if($chmidj > 0){
	echo '<td style="text-align:center;">MIDTERM</td>';
	echo '<td style="text-align:center;">'.$att10.'</td>';
}
else{
echo '<td style="text-align:center;">'.$redate23.'</td>';
echo '<td style="text-align:center;">'.$att10.'</td>';
}
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;">Week 11</td>';
if($chmidk > 0){
	echo '<td style="text-align:center;">MIDTERM</td>';
	echo '<td style="text-align:center;">'.$att1.'</td>';
}
else{
echo '<td style="text-align:center;">'.$redate25.'</td>';
echo '<td style="text-align:center;">'.$att11.'</td>';
}
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;">Week 12</td>';
if($chmidl > 0){
	echo '<td style="text-align:center;">MIDTERM</td>';
	echo '<td style="text-align:center;">'.$att12.'</td>';
}
else{
echo '<td style="text-align:center;">'.$redate27.'</td>';
echo '<td style="text-align:center;">'.$att12.'</td>';
}
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;">Week 13</td>';
if($chmidm > 0){
	echo '<td style="text-align:center;">MIDTERM</td>';
	echo '<td style="text-align:center;">'.$att13.'</td>';
}
else{
echo '<td style="text-align:center;">'.$redate29.'</td>';
echo '<td style="text-align:center;">'.$att13.'</td>';
}
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;">Week 14</td>';
if($chmidn > 0){
	echo '<td style="text-align:center;">MIDTERM</td>';
	echo '<td style="text-align:center;">'.$att14.'</td>';
}
else{
echo '<td style="text-align:center;">'.$redate31.'</td>';
echo '<td style="text-align:center;">'.$att14.'</td>';
}
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;">TOTAL</td>';
echo '<td style="text-align:center;">'.$redatetotal.'</td>';
echo '<td style="text-align:center;">'.$atttotal.'</td>';
echo '</tr>';
echo '</table>';
}
echo '</center>';
?>
<br>
<center>
<div id="loadit"></div>	
</center>
<div id="afterthis" style="float: left;"><ul id="resultlist" style="list-style-type: none;" ></ul></div>

<form  style="margin: auto; float: left;" action="chart.js.php" method="POST">
<input style="display: none;" type="text" name="student_name" value="<?php echo $student_name; ?>" />
<input style="display: none;" type="text" name="redate" value="<?php echo $redate; ?>" />
<input style="display: none;" type="text" name="att1" value="<?php echo $att1; ?>" />
<input style="display: none;" type="text" name="chmida" value="<?php echo $chmida; ?>" />
<input style="display: none;" type="text" name="redate7" value="<?php echo $redate7; ?>" />
<input style="display: none;" type="text" name="att2" value="<?php echo $att2; ?>" />
<input style="display: none;" type="text" name="chmidb" value="<?php echo $chmidb; ?>" />
<input style="display: none;" type="text" name="redate9" value="<?php echo $redate9; ?>" />
<input style="display: none;" type="text" name="att3" value="<?php echo $att3; ?>" />
<input style="display: none;" type="text" name="chmidc" value="<?php echo $chmidc; ?>" />
<input style="display: none;" type="text" name="redate11" value="<?php echo $redate11; ?>" />
<input style="display: none;" type="text" name="att4" value="<?php echo $att4; ?>" />
<input style="display: none;" type="text" name="chmidd" value="<?php echo $chmidd; ?>" />
<input style="display: none;" type="text" name="redate13" value="<?php echo $redate13; ?>" />
<input style="display: none;" type="text" name="att5" value="<?php echo $att5; ?>" />
<input style="display: none;" type="text" name="chmide" value="<?php echo $chmide; ?>" />
<input style="display: none;" type="text" name="redate15" value="<?php echo $redate15; ?>" />
<input style="display: none;" type="text" name="att6" value="<?php echo $att6; ?>" />
<input style="display: none;" type="text" name="chmidf" value="<?php echo $chmidf; ?>" />
<input style="display: none;" type="text" name="redate17" value="<?php echo $redate17; ?>" />
<input style="display: none;" type="text" name="att7" value="<?php echo $att7; ?>" />
<input style="display: none;" type="text" name="chmidg" value="<?php echo $chmidg; ?>" />
<input style="display: none;" type="text" name="redate19" value="<?php echo $redate19; ?>" />
<input style="display: none;" type="text" name="att8" value="<?php echo $att8; ?>" />
<input style="display: none;" type="text" name="chmidh" value="<?php echo $chmidh; ?>" />
<input style="display: none;" type="text" name="redate21" value="<?php echo $redate21; ?>" />
<input style="display: none;" type="text" name="att9" value="<?php echo $att9; ?>" />
<input style="display: none;" type="text" name="chmidi" value="<?php echo $chmidi; ?>" />
<input style="display: none;" type="text" name="redate23" value="<?php echo $redate23; ?>" />
<input style="display: none;" type="text" name="att10" value="<?php echo $att10; ?>" />
<input style="display: none;" type="text" name="chmidj" value="<?php echo $chmidj; ?>" />
<input style="display: none;" type="text" name="redate25" value="<?php echo $redate25; ?>" />
<input style="display: none;" type="text" name="att11" value="<?php echo $att11; ?>" />
<input style="display: none;" type="text" name="chmidk" value="<?php echo $chmidk; ?>" />
<input style="display: none;" type="text" name="redate27" value="<?php echo $redate27; ?>" />
<input style="display: none;" type="text" name="att12" value="<?php echo $att12; ?>" />
<input style="display: none;" type="text" name="chmidl" value="<?php echo $chmidl; ?>" />
<input style="display: none;" type="text" name="redate29" value="<?php echo $redate29; ?>" />
<input style="display: none;" type="text" name="att13" value="<?php echo $att13; ?>" />
<input style="display: none;" type="text" name="chmidm" value="<?php echo $chmidm; ?>" />
<input style="display: none;" type="text" name="redate31" value="<?php echo $redate31; ?>" />
<input style="display: none;" type="text" name="att14" value="<?php echo $att14; ?>" />
<input style="display: none;" type="text" name="chmidn" value="<?php echo $chmidn; ?>" />
<input style="display: none;" type="text" name="redatetotal" value="<?php echo $redatetotal; ?>" />
<input style="display: none;" type="text" name="atttotal" value="<?php echo $atttotal; ?>" />
<input  style="display: none;" type="text" name="class" value="<?php echo $class; ?>" />
<input  style="display: none;" type="text" name="arms" value="<?php echo $arms; ?>" />
<input  style="display: none;" type="text" name="year" value="<?php echo $year; ?>" />
<input  style="display: none;" type="text" name="term" value="<?php echo $term; ?>" />
<input  style="display: none;" type="text" name="formt" value="<?php echo $formt; ?>" />
<input  style="display: none;" type="text" name="termbegin" value="<?php echo $termbegin; ?>" />
<input class="myButton" type="submit" name="submit" value="Chart View" />
</form>

<?php
echo '<form id="indattpdf">';
echo '<input   style="display: none;" name="student_name2[]" type="text" value="'.$student_name. '">';
echo '<input   style="display: none;"name="class2[]" type="text" value="'.$class. '">';
echo '<input   style="display: none;" name="year2[]" type="text" value="'.$year. '">';
echo '<input   style="display: none;" name="term2[]" type="text" value="'.$term. '">';
echo '<input   style="display: none;" name="arm2[]" type="text" value="'.$arms. '">';
echo '<input   style="display: none;" name="formt2[]" type="text" value="'.$formt. '">';
echo '<input   style="display: none;" name="chmida2[]" type="text" value="'.$chmida. '">';
echo '<input   style="display: none;" name="chmidb2[]" type="text" value="'.$chmidb. '">';
echo '<input   style="display: none;" name="chmidc2[]" type="text" value="'.$chmidc. '">';
echo '<input   style="display: none;" name="chmidd2[]" type="text" value="'.$chmidd. '">';
echo '<input   style="display: none;" name="chmide2[]" type="text" value="'.$chmide. '">';
echo '<input   style="display: none;" name="chmidf2[]" type="text" value="'.$chmidf. '">';
echo '<input   style="display: none;" name="chmidg2[]" type="text" value="'.$chmidg. '">';
echo '<input   style="display: none;" name="chmidh2[]" type="text" value="'.$chmidh. '">';
echo '<input   style="display: none;" name="chmidi2[]" type="text" value="'.$chmidi. '">';
echo '<input   style="display: none;" name="chmidj2[]" type="text" value="'.$chmidj. '">';
echo '<input   style="display: none;" name="chmidk2[]" type="text" value="'.$chmidk. '">';
echo '<input   style="display: none;" name="chmidl2[]" type="text" value="'.$chmidl. '">';
echo '<input   style="display: none;" name="chmidm2[]" type="text" value="'.$chmidm. '">';
echo '<input   style="display: none;" name="chmidn2[]" type="text" value="'.$chmidn. '">';
echo '<input   style="display: none;" name="chmido2[]" type="text" value="'.$chmido. '">';
echo '<input   style="display: none;" name="att1_2[]" type="text" value="'.$att1. '">';
echo '<input   style="display: none;" name="att2_2[]" type="text" value="'.$att2. '">';
echo '<input   style="display: none;" name="att3_2[]" type="text" value="'.$att3. '">';
echo '<input   style="display: none;" name="att4_2[]" type="text" value="'.$att4. '">';
echo '<input   style="display: none;" name="att5_2[]" type="text" value="'.$att5. '">';
echo '<input   style="display: none;" name="att6_2[]" type="text" value="'.$att6. '">';
echo '<input   style="display: none;" name="att7_2[]" type="text" value="'.$att7. '">';
echo '<input   style="display: none;" name="att8_2[]" type="text" value="'.$att8. '">';
echo '<input   style="display: none;" name="att9_2[]" type="text" value="'.$att9. '">';
echo '<input   style="display: none;" name="att10_2[]" type="text" value="'.$att10. '">';
echo '<input   style="display: none;" name="att11_2[]" type="text" value="'.$att11. '">';
echo '<input   style="display: none;" name="att12_2[]" type="text" value="'.$att12. '">';
echo '<input   style="display: none;" name="att13_2[]" type="text" value="'.$att13. '">';
echo '<input   style="display: none;" name="att14_2[]" type="text" value="'.$att14. '">';
echo '<input   style="display: none;" name="att14_2[]" type="text" value="'.$att15. '">';
echo '<input   style="display: none;" name="atttotal2[]" type="text" value="'.$atttotal. '">';
echo '<input   style="display: none;" name="redate_2[]" type="text" value="'.$redate. '">';
echo '<input   style="display: none;" name="redate7_2[]" type="text" value="'.$redate7. '">';
echo '<input   style="display: none;" name="redate9_2[]" type="text" value="'.$redate9. '">';
echo '<input   style="display: none;" name="redate11_2[]" type="text" value="'.$redate11. '">';
echo '<input   style="display: none;" name="redate13_2[]" type="text" value="'.$redate13. '">';
echo '<input   style="display: none;" name="redate15_2[]" type="text" value="'.$redate15. '">';
echo '<input   style="display: none;" name="redate17_2[]" type="text" value="'.$redate17. '">';
echo '<input   style="display: none;" name="redate19_2[]" type="text" value="'.$redate19. '">';
echo '<input   style="display: none;" name="redate21_2[]" type="text" value="'.$redate21. '">';
echo '<input   style="display: none;" name="redate23_2[]" type="text" value="'.$redate23. '">';
echo '<input   style="display: none;" name="redate25_2[]" type="text" value="'.$redate25. '">';
echo '<input   style="display: none;" name="redate27_2[]" type="text" value="'.$redate27. '">';
echo '<input   style="display: none;" name="redate29_2[]" type="text" value="'.$redate29. '">';
echo '<input   style="display: none;" name="redate31_2[]" type="text" value="'.$redate31. '">';
echo '<input   style="display: none;" name="redate33_2[]" type="text" value="'.$redate33. '">';
echo '<input   style="display: none;" name="redatetotal_2[]" type="text" value="'.$redatetotal. '">';
echo '<input   style="display: none;" type="text" name="termbegin2[]" value="'.$termbegin.'" />';
echo '<input class="myButton" style="float: left;" type="submit" name="submit" id="attpdfsubmit" value="Make Downloadable" />';
echo '</form>';	
?>
<form style="margin: auto; float: left;" action="upatt.php" method="POST">
<input style="display: none;" type="text" name="class" value="<?php echo $class; ?>" />
<input  style="display: none;" type="text" name="arms" value="<?php echo $arms; ?>" />
<input  style="display: none;" type="text" name="year" value="<?php echo $year; ?>" />
<input  style="display: none;" type="text" name="term" value="<?php echo $term; ?>" />
<input  style="display: none;" type="text" name="formt" value="<?php echo $formt; ?>" />
<input  style="display: none;" type="text" name="termbegin" value="<?php echo $termbegin; ?>" />
<input class="myButton" type="submit" name="submit" value="Back" />
</form>
<?php
include("footer.php");
?>
</body>
</html>