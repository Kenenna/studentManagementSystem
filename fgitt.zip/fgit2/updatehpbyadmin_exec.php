<?php
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
if (isset($_REQUEST['btn-upload'])) {
$id = $_REQUEST['id'];
$teacher_id = $_REQUEST['teacher_id'];
$teacher_name = $_REQUEST['teacher_name'];
$year = $_REQUEST['year'];
$house = $_REQUEST['house'];
$checktea = mysqli_query($db, "SELECT * FROM houseparent where teacher_id='$teacher_id' AND teacher_name='$teacher_name' AND year='$year' AND house='$house' AND school='".$_SESSION["school"]."'");
  $counttea = mysqli_num_rows($checktea);
  if($counttea < 1){ 
$query =("UPDATE houseparent SET year='$year', house='$house', school='".$_SESSION["school"]."' WHERE id='$id'");

if (!mysqli_query ($db,$query) )
			{
			echo '<img src="../images/492.png" /> &nbsp;! data not updated';
			echo '<meta content="2;admviewhp.php" http-equiv="refresh" />';	
			die (mysqli_error());
			}else{
		echo '<img src="../images/492.png" /> &nbsp;! data updated successfully';
		echo '<meta content="2;admviewhp.php" http-equiv="refresh" />';
			}
  }else{
	echo "<center><div class='form'><h5 style='color: red;'>A house parent with the given name for that year already exists.</h5></div></center>";
	echo '<meta content="2;admviewhp.php" http-equiv="refresh" />';
  }
}
?>