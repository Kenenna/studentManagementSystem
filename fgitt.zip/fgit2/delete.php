<?php
include('database.php');
include("function.php");

 $sql = "SELECT * FROM studentsbyclass WHERE id = :id";
 $statement = $connection->prepare($sql);
 $id = $_POST["user_id"];
 $statement->bindValue(':id', $id);
$statement->execute();
$r = $statement->fetch(PDO::FETCH_ASSOC);
if($r===false){
	
}else{
$ry = $r["year"];
$cy = $r["class"];
$ty = $r["term"];
$ay = $r["arms"];
$fy = $r["formt"];
}


if(($ry == $_POST["year_user_id"]) && ($cy == $_POST["class_user_id"]) && ($ty == $_POST["term_user_id"]) && ($ay == $_POST["arms_user_id"]) && ($fy == $_POST["formt_user_id"])){
	$user_id = $_POST['user_id'];
	 $image = get_image_name($_POST["user_id"]);
if($image != '')
 {
 unlink("upload/" . $image);
 }
 $statement = $connection->prepare(
 "DELETE FROM studentsbyclass WHERE id = :id"
 );
 $result = $statement->execute(
 array(
  ':id' => $_POST["user_id"]
  )
);
echo "record deleted";
}
else{
	echo "You selected students in ".$_POST["class_user_id"].$_POST["arms_user_id"]." in ".$_POST["term_user_id"]." of ".$_POST["year_user_id"]." with ".$_POST["formt_user_id"]." as form tutor. You can therefore delete profile of only students meeting those criteria.";
}


/*if(isset($_POST["user_id"]))
{
 $image = get_image_name($_POST["user_id"]);
if($image != '')
 {
 unlink("upload/" . $image);
 }
 $statement = $connection->prepare(
 "DELETE FROM studentsbyclass WHERE id = :id"
 );
 $result = $statement->execute(
 array(
  ':id' => $_POST["user_id"]
  )
);
 
 echo $yy;
if(!empty($result))
 {
	echo $r["year"]; 
  echo 'Data Successfully Deleted';
}
} */
?>