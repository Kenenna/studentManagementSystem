<?php
$student_name = $_POST['student_name2'];
$su = $_POST['arsubj'];
foreach($su as $a){
	echo $a.",";
}
?>