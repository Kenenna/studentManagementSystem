<?php
session_start();
include("auth.php");
include('db.php');
include("connection.php");
$resultsch = mysqli_query($db,"SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Edit Teacher Questions</title>
  
 	<link rel="stylesheet" href="css/style.css" />
		<link rel="stylesheet" href="css/styles.css">
		<link rel="stylesheet" href="css/demo.css">
		<link rel="stylesheet" href="css/footer-distributed.css">
  <script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>
<style>
.pbutton {
	background-color:#44c767;
	-moz-border-radius:28px;
	-webkit-border-radius:28px;
	border-radius:2px;
	border:1px solid #18ab29;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:15px;
	padding:6px 12px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
	margin: auto;
}
.pbutton:hover {
	background-color:#5cbf2a;
}
.pbutton:active {
	position:relative;
	top:1px;
}
</style>
<link rel="stylesheet" href="css/styles.css">

<style>
.custom-file-input {
	display: inline-block;
	position: relative;
	color: #533e00;
}
.custom-file-input input {
	visibility: hidden;
	width: 180px
}
.custom-file-input:before {
	content: 'Choose File';
	display: block;
	background: -webkit-linear-gradient( -180deg, #ffdc73, #febf01);
	background: -o-linear-gradient( -180deg, #ffdc73, #febf01);
	background: -moz-linear-gradient( -180deg, #ffdc73, #febf01);
	background: linear-gradient( -180deg, #ffdc73, #febf01);
	border: 3px solid #dca602;
	border-radius: 10px;
	padding: 5px 0px;
	outline: none;
	white-space: nowrap;
	cursor: pointer;
	text-shadow: 1px 1px rgba(255,255,255,0.7);
	font-weight: bold;
	text-align: center;
	font-size: 10pt;
	position: absolute;
	left: 0;
	right: 0;
}
.custom-file-input:hover:before {
	border-color: #febf01;
}
.custom-file-input:active:before {
	background: #febf01;
}
.file-blue:before {
	content: 'Pick Image as Question';
	background: -webkit-linear-gradient( -180deg, #99dff5, #02b0e6);
	background: -o-linear-gradient( -180deg, #99dff5, #02b0e6);
	background: -moz-linear-gradient( -180deg, #99dff5, #02b0e6);
	background: linear-gradient( -180deg, #99dff5, #02b0e6);
	border-color: #57cff4;
	color: #FFF;
	text-shadow: 1px 1px rgba(000,000,000,0.5);
}
.file-blue:hover:before {
	border-color: #02b0e6;
}
.file-blue:active:before {
	background: #02b0e6;
}

</style>
<script type="text/javascript" src="edittablejs.js"></script>

<script type="text/javascript">
$(document).ready(function(){
$(".closebut").click(function(cc){
	cc.preventDefault();
$(".formImg").fadeOut(2000);	
});

});
</script>


<script>
$(document).ready(function(){
	var shuff = $('#shu').text();
	if(shuff == 0){
		$('#shuffle_questions').text("Shuffle Questions");
	}else{
		$('#shuffle_questions').text("Unshuffle Questions");
	}
	$("#shuffle_questions").click(function() {
if(shuff == 0){
		shuff = 1;
	}else{
		shuff = 0;
	}	
	//alert(shuff);
var shuffteaid = $('#shuffteaid').text();
var shuffteaname = $('#shuffteaname').text();
var shuffclass = $('#shuffclass').text();
var shuffyear = $('#shuffyear').text();
var shuffterm = $('#shuffterm').text();
var shuffsubject = $('#shuffsubject').text();
var shuffarm = $('#shuffarm').text();
var shuffquiz_name = $('#shuffquiz_name').text();
var shuffschool = $('#shuffschool').text();
var values = {
 'shuffle_questions': shuff,
 'teacher_id': shuffteaid,
 'teacher_name': shuffteaname,
 'classs': shuffclass, 
 'year': shuffyear,
 'term': shuffterm,
 'arm': shuffarm,
 'subject': shuffsubject,
 'quiz_name': shuffquiz_name,
 'school': shuffschool
    };		
$.ajax({
type: "POST",
url: "shuffle_exec.php",
cache: false,
data: values, 
success: function(responseshuff){
	if(responseshuff == 0){
		$('#shuffle_questions').text("Shuffle Questions");
	}else{
		$('#shuffle_questions').text("Unshuffle Questions");
	}
}
});	
});	
});
</script>


<script type="text/javascript">
$(document).ready(function(){
$('#formtime').hide();
$('#formshow').click(function(){
	if($('.formshow').html()=='show time update form'){
	$('#formtime').fadeIn(2000);
	$('.formshow').html('hide time update form');
	}else{
	$('#formtime').fadeOut(2000);
	$('.formshow').html('show time update form');	
	}
});	
		
 $("#formtime").submit(function(ev){
	ev.preventDefault();
	var dataSt = new FormData(this);
        $.ajax({
            type:'POST',
            url:'insert_ques.php',
            data: dataSt,
			cache: false,
			contentType: false,
			processData: false,
            success:function(responset){
				if(responset=="Could NOT Update"){
					alert(responset);
				}else{
			var rowed = responset.split("|");
			$("#sst").html(rowed[0]);
			$("#eet").html(rowed[1]);
			$("#ddu").val(rowed[2]);
				}
			}
});
 });
});
</script>


<script type="text/javascript">
$(document).ready(function()
{
$(".edit_tr").click(function()
{
var ID=$(this).attr('id');
var ggg = $("#question_name_input_"+ID).val();	
var aa = $("#question_name_input_"+ID).val().slice(-3);
if((aa=='JPG') || (aa=='jpg')){
$(".formImg").fadeIn(2000);
$("#question_name_"+ID).show();
$("#question_name_input_"+ID).hide();
$(".formImg").attr("id", "formImg_"+ID);
$(".userId").attr("value", ID);
$(".userId").attr("name", "userId");
$(".userImg").attr("name", "userImg");
$("#formImg_"+ID).submit(function(ev){
	ev.preventDefault();
	var dataSt = new FormData(this);
        $.ajax({
            type:'POST',
            url:'singleQuesImg.php',
            data: dataSt,
			cache: false,
			contentType: false,
			processData: false,
            success:function(ress){
		$('#photo_'+ID).attr("src", "quiz/"+ress); 
            }
			});
			});	
}else{
$("#question_name_"+ID).hide();
$("#question_name_input_"+ID).show();
}
$("#answer1_"+ID).hide();
$("#answer1_input_"+ID).show();
$("#answer2_"+ID).hide();
$("#answer2_input_"+ID).show();
$("#answer3_"+ID).hide();
$("#answer3_input_"+ID).show();
$("#answer4_"+ID).hide();
$("#answer4_input_"+ID).show();
$("#ans_"+ID).hide();
$("#ans_input_"+ID).show();
$("#section_ref_"+ID).hide();
$("#section_ref_input_"+ID).show();
}).change(function()
{
var ID=$(this).attr('id');
var question_name=$("#question_name_input_"+ID).val();
var answer1=$("#answer1_input_"+ID).val();
var answer2=$("#answer2_input_"+ID).val();
var answer3=$("#answer3_input_"+ID).val();
var answer4=$("#answer4_input_"+ID).val();
var ans=$("#ans_input_"+ID).val();
var section_ref=$("#section_ref_input_"+ID).val();
//var dataString = new FormData(this);
var dataString = 'id='+ ID +'&question_name='+question_name +'&answer1='+answer1 +'&answer2='+answer2 +'&answer3='+answer3 +'&answer4='+answer4 +'&ans='+ans +'&section_ref='+section_ref;
$("#section_ref_"+ID).html('<img src="load.gif" />');

if(ans.length>0)
{
$.ajax({
type: "POST",
url: "teaquizview_exec.php",
data: dataString,
cache: false,
success: function(html)
{
	alert(question_name);
var bb = $("#question_name_input_"+ID).val().slice(-3);	
	if((bb=='JPG') || (bb=='jpg')){
$("#question_name_"+ID).html('<img id="photo_"'+ID+'" src="quiz/'+question_name+'" width="90" height="80" />');
	}else{
$("#question_name_"+ID).html(question_name);		
	}
$("#answer1_"+ID).html(answer1);
$("#answer2_"+ID).html(answer2);
$("#answer3_"+ID).html(answer3);
$("#answer4_"+ID).html(answer4);
$("#ans_"+ID).html(ans);
$("#section_ref_"+ID).html(section_ref);
}
});
}
else
{
alert('Enter something.');
}

});

$(".editbox").mouseup(function() 
{
return false
});

$(document).mouseup(function()
{
$(".editbox").hide();
$(".text").show();
});
});
</script>

<link href="quiz/dttable/dttablemaxcss.css" rel="stylesheet" type="text/css" media="screen">
        <link rel="stylesheet" type="text/css" href="quiz/dttable/dttablemaxcss2.css">
		 <link rel="stylesheet" type="text/css" href="quiz/dttable/dttablemaxcss3.css">	
	<script src="quiz/dttable/dttablejquery.js" type="text/javascript"></script>
	<script src="quiz/dttable/dttablejquery2.js" type="text/javascript"></script>	
	<script src="quiz/dttable/dttablejquery3.js" type="text/javascript" type="text/javascript"></script>
	<script type="text/javascript" charset="utf-8" language="javascript" src="quiz/dttable/dttablejquery4.js"></script>
	<script type="text/javascript" charset="utf-8" language="javascript" src="quiz/dttable/dttablejquery5.js"></script>
<style>
.myButton {
	background-color:#44c767;
	-moz-border-radius:8px;
	-webkit-border-radius:8px;
	border-radius:8px;
	border:1px solid #18ab29;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:15px;
	padding:6px 24px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
	margin-left: -2px;
}
.myButton:hover {
	background-color:#5cbf2a;
}
.closebut {
	background-color:#44c767;
	-moz-border-radius:8px;
	-webkit-border-radius:8px;
	border-radius:8px;
	border:1px solid #18ab29;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:15px;
	padding:6px 24px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
}
.closebut:hover {
	background-color:#5cbf2a;
}
</style>
<style>
body
{
font-family:Arial, Helvetica, sans-serif;
font-size:14px;
}
.editbox
{
display:none
}
td
{
padding:2px;
height:60px;
vertical-align: top;
text-align: left;
}
.editbox
{
font-size:14px;
width:100%;
background-color:#ffffcc;
border:solid 1px #000;
padding: 0;
vertical-align: top;
text-align: left;
}
.editbox{
	height:100%;
}
.edit_tr:hover
{
background:url(edit.png) right no-repeat #80C8E5;
cursor:pointer;
}
th
{
font-weight:bold;
text-align:left;
padding:4px;
}
.head
{
background-color:#333;
color:#FFFFFF
}
</style>
<script src="quiz/js/jquery_timepicker.js"></script>
   <link rel="stylesheet" type="text/css" href="quiz/css/jquery_timepicker.css" />

    <script src="quiz/js/jquery_datepicker.js"></script>
    <link rel="stylesheet" type="text/css" href="quiz/css/jquery_datepicker.css" />

    <script src="quiz/lib/pikaday.js"></script>
    <link rel="stylesheet" type="text/css" href="quiz/lib/pikaday.css" />

    <script src="quiz/lib/jquery.ptTimeSelect.js"></script>
    <link rel="stylesheet" type="text/css" href="quiz/lib/jquery.ptTimeSelect.css" />
  
    <script src="quiz/dist/datepair.js"></script>
    <script src="quiz/dist/jquery.datepair.js"></script>
<script src="js/scriptmenu.js"></script>
</head>

<body>
<?php
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'admin'){
echo '<ul class="topnav" id="myTopnav">';
echo '<li><a href="adstuadmin.php">Add Student</a></li>';
echo '<li><a href="adminaddformt.php">Add Form Tutor</a></li>';
echo '<li><a href="admgetresult.php">Student\'s Result</a></li>';
echo '<li><a href="admviewtea.php">View Teachers</a></li>';
echo '<li><a href="admviewtutor.php">View Tutors</a></li>';
echo '<li><a href="viewmaxatt.php">View Max Attendance</a></li>';
echo '<li><a href="logout.php">Logout</a></li>';
echo '<li class="icon">';
echo '<a href="javascript:void(0);" onclick="myFunction()">&#9776;</a>';
echo '</li>';
echo '</ul>';
}
else{echo "";}
?>
<br>
<center><br>
<div style="margin:0 auto; padding:10px; background-color:#fff; height: auto; width: 100%;">
<div style="width: 100%;">QUIZ ITEMS
<?php
        $teacher_id = $_POST['teacher_id'];
		$teacher = $_POST['teacher_name'];
        $class = $_POST['class'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		$subject = $_POST['subject'];
		$arm = $_POST['arm'];
		$quiz_name = $_POST['quiz_name'];
		$school = $_POST['school'];
		echo '<br>';
		
if($ctype=="Js"){
$checkclass2 = mysqli_query($db, "SELECT * FROM classes where class_name='$class'");
while($rowcla2 = mysqli_fetch_assoc($checkclass2)){
$cll4[] = $rowcla2['class_name2'];
}
$cl = current($cll4);
}else{
$cl = $_POST['class_name'];	
}
?>
<br><span style="color: red;">
<?php echo "QUIZ NAMED ".strtoupper($quiz_name)." FOR STUDENTS IN ".strtoupper($class)." ".strtoupper($arm)." THIS ".strtoupper($term)." OF ".$year."/".($year+1)." SESSION, IN ".strtoupper($subject); ?></span></div>
<span>Click on a rectangle to modify question. If the question is an image, click on the image for an update-image button.</span>
<br><br>

<form style="display: none;" class="formImg">
<input type="text"  style="display: none;" class="userId" id="userId" />
<label  class="custom-file-input file-blue">
<input type="file" class="userImg" id="userImg" />
</label><br>
<input type="submit" class="myButton" value="post question" id="subImg_<?php echo $id; ?>" />
<button class="closebut">close</button><br><br>
</form>	

<br>
<form method="POST" action="quiz/teacher_quiz2.php" >
<input style="display: none;" type="text" name="teacher" value="<?php echo $teacher; ?>" />
<input style="display: none;" type="text" name="teacher_id" value="<?php echo $teacher_id; ?>" />
<input style="display: none;" type="text" name="class" value="<?php echo $class; ?>" />
<input style="display: none;" type="text" name="year" value="<?php echo $year; ?>" />
<input style="display: none;" type="text" name="term" value="<?php echo $term; ?>" />
<input style="display: none;" type="text" name="arms" value="<?php echo $arm; ?>" />
<input style="display: none;" type="text" name="subject" value="<?php echo $subject; ?>" />
<input type="submit" class="pbutton" name="btn-upload" value="back" />
</form>
<br>
<?php
$sql4 = mysqli_query($db,"SELECT id, question_name, answer1, answer2, answer3, answer4, ans, section_ref, quiz_name, start_time, end_time, duration FROM teacher_quiz where class='$class' AND year='$year' AND term='$term' AND teacher_name='$teacher' AND arm='$arm' AND school='$school' AND quiz_name='$quiz_name' ORDER BY id ASC");
while($rowss=mysqli_fetch_array($sql4))
{
$start_time2[] = $rowss['start_time'];
$end_time2[] = $rowss['end_time'];
$duration2[] = $rowss['duration'];
$id[] = $rowss['id'];
$question_name[] = $rowss['question_name'];
$answer1[] = $rowss['answer1'];
$answer2[] = $rowss['answer2'];
$answer3[] = $rowss['answer3'];
$answer4[] = $rowss['answer4'];
$ans[] = $rowss['ans'];
$section_ref[] = $rowss['section_ref'];	
}
$start_time = current($start_time2);
$end_time = current($end_time2);
$duration = current($duration2);


$shuff_ques = mysqli_query($db,"SELECT id, shuffle_questions FROM teacher_quiz_shuffle WHERE class='$class' AND year='$year' AND term='$term' AND teacher_name='$teacher' AND arm='$arm' AND school='$school' AND quiz_name='$quiz_name' ORDER BY id ASC");
while($rowshuff=mysqli_fetch_array($shuff_ques))
{
$shuffle_status2[] = $rowshuff['shuffle_questions'];
$idshuff2[] = $rowshuff['id'];
}
$shuffle_status = current($shuffle_status2);
echo "<div style='display: none;' id='shuffid'>".$shuffle_status."</div>";
echo "<div style='display: none;' id='shuffteaid'>".$teacher_id."</div>";
echo "<div style='display: none;' id='shuffteaname'>".$teacher."</div>";
echo "<div style='display: none;' id='shuffclass'>".$class."</div>";
echo "<div style='display: none;' id='shuffyear'>".$year."</div>";
echo "<div style='display: none;' id='shuffterm'>".$term."</div>";
echo "<div style='display: none;' id='shuffsubject'>".$subject."</div>";		
echo "<div style='display: none;' id='shuffarm'>".$arm."</div>";
echo "<div style='display: none;' id='shuffquiz_name'>".$quiz_name."</div>";
echo "<div style='display: none;' id='shuffschool'>".$school."</div>";		
?>
Quiz Opens: <span id="sst" style="color:red;"><?php echo date("d/m/Y H:i:s", strtotime($start_time)); ?></span> || 
Quiz Closes: <span id="eet" style="color:red;"><?php echo date("d/m/Y H:i:s", strtotime($end_time)); ?></span><br>
<button class="formshow" id="formshow" style="background-color: green; color: white;">show time update form</button>
<?php
echo "<div style='display: none;' id='shu'>".$shuffle_status."</div>";
?>
<button class="shuffle_questions" id="shuffle_questions" style="background-color: green; color: white;"></button>






<form id="formtime" >
<input style="display: none;" type="text" name="teacher" value="<?php echo $teacher; ?>" />
<input style="display: none;" type="text" name="teacher_id" value="<?php echo $teacher_id; ?>" />
<input style="display: none;" type="text" name="class" value="<?php echo $class; ?>" />
<input style="display: none;" type="text" name="year" value="<?php echo $year; ?>" />
<input style="display: none;" type="text" name="term" value="<?php echo $term; ?>" />
<input style="display: none;" type="text" name="arm" value="<?php echo $arm; ?>" />
<input style="display: none;" type="text" name="school" value="<?php echo $school; ?>" />
<input style="display: none;" type="text" name="subject" value="<?php echo $subject; ?>" />
<input style="display: none;" type="text" name="quiz_name" value="<?php echo $quiz_name; ?>" />
Duration in Minutes: <input type="text" name="duration" id="ddu" value="<?php echo $duration; ?>" />
<p id="basicExample">
                    <input type="text" class="date start" name="startd" id="sd" placeholder="Start Date" />
                    <input type="text" class="time start" name="startt" id="st" placeholder="Start Time"/> <br>to<br>
                    <input type="text" class="time end" name="endt" id="et" placeholder="End Time" />
                    <input type="text" class="date end" name="endd" id="ed" placeholder="End Date" />
</p>
<input type="submit" class="pbutton" name="btn-upload" value="Modify" />
</form>
<script>
                $('#basicExample .time').timepicker({
                    'showDuration': true,
                    'timeFormat': 'g:ia'
                });

                $('#basicExample .date').datepicker({
                    'format': 'm/d/yyyy',
                    'autoclose': true
                });

                var basicExampleEl = document.getElementById('basicExample');
                var datepair = new Datepair(basicExampleEl);
  </script>
 <script type="text/javascript">
$(document).ready(function(){
$("#ed").change(function(){
	$("#ed").val(0);
});
$("#sd").change(function(){
	$("#sd").val(0);
});
});
</script> 
<br>
<table style="width: 80%;">
<tr class="head">
<th>Question</th><th>Option A</th><th>Option B</th><th>Option C</th><th>Option D</th><th>Correct Answer</th><th>Section Ref.</th>
</tr>
<?php	
$i=1;
for($y=0; $y<=(count($id)-1); $y++)
//while($rows=mysqli_fetch_array($sql4))
{
if($i%2)
{
?>
<tr id="<?php echo $id[$y]; ?>" class="edit_tr">
<?php } else { ?>
<tr id="<?php echo $id[$y]; ?>" bgcolor="#f2f2f2" class="edit_tr">
<?php } ?>
<td width="10%" class="edit_td">
<?php
if((substr($question_name[$y],-3)=="jpg") || (substr($question_name[$y],-3)=="JPG")) {
?>
<span id="question_name_<?php echo $id[$y]; ?>" class="text"><img id="photo_<?php echo $id[$y]; ?>" src="<?php echo 'quiz/'.$question_name[$y] ?>" height="80" width="80" />
</span>
<input type="text" value="<?php echo $question_name[$y]; ?>" class="editbox" id="question_name_input_<?php echo $id[$y]; ?>" />
<?php }else{
?>
<span id="question_name_<?php echo $id[$y]; ?>" class="text"><?php echo $question_name[$y]; ?></span>
<input type="text" value="<?php echo $question_name[$y]; ?>" class="editbox" id="question_name_input_<?php echo $id[$y]; ?>" />
<?php } ?>
</td>
<td width="10%" class="edit_td">
<span id="answer1_<?php echo $id[$y]; ?>" class="text"><?php echo $answer1[$y]; ?></span>
<textarea type="text" value="<?php echo $answer1[$y]; ?>" style="" class="editbox" id="answer1_input_<?php echo $id[$y]; ?>" /><?php echo $answer1[$y]; ?></textarea>
</td>
<td width="10%" class="edit_td">
<span id="answer2_<?php echo $id[$y]; ?>" class="text"><?php echo $answer2[$y]; ?></span>
<textarea type="text" value="<?php echo $answer2[$y]; ?>" style="" class="editbox" id="answer2_input_<?php echo $id[$y]; ?>" /><?php echo $answer2[$y]; ?></textarea>
</td>
<td width="10%" class="edit_td">
<span id="answer3_<?php echo $id[$y]; ?>" class="text"><?php echo $answer3[$y]; ?></span>
<textarea type="text" value="<?php echo $answer3[$y]; ?>" style="" class="editbox" id="answer3_input_<?php echo $id[$y]; ?>" /><?php echo $answer3[$y]; ?></textarea>
</td>
<td width="10%" class="edit_td">
<span id="answer4_<?php echo $id[$y]; ?>" class="text"><?php echo $answer4[$y]; ?></span>
<textarea type="text" value="<?php echo $answer4[$y]; ?>" style="" class="editbox" id="answer4_input_<?php echo $id[$y]; ?>" /><?php echo $answer4[$y]; ?></textarea>
</td>
<td width="10%" class="edit_td">
<span id="ans_<?php echo $id[$y]; ?>" class="text"><?php echo $ans[$y]; ?></span>
<textarea type="text" value="<?php echo $ans[$y]; ?>" style="" class="editbox" id="ans_input_<?php echo $id[$y]; ?>" /><?php echo $ans[$y]; ?></textarea>
</td>
<td width="10%" class="edit_td">
<span id="section_ref_<?php echo $id[$y]; ?>" class="text"><?php echo $section_ref[$y]; ?></span>
<textarea type="text" value="<?php echo $section_ref[$y]; ?>" style="" class="editbox" id="section_ref_input_<?php echo $id[$y]; ?>" /><?php echo $section_ref[$y]; ?></textarea>
</td>
</tr>
<?php
$i++;
}
?>
</table>
<br>
<form method="POST" action="quiz/teacher_quiz2.php" >
<input style="display: none;" type="text" name="teacher" value="<?php echo $teacher; ?>" />
<input style="display: none;" type="text" name="teacher_id" value="<?php echo $teacher_id; ?>" />
<input style="display: none;" type="text" name="class" value="<?php echo $class; ?>" />
<input style="display: none;" type="text" name="year" value="<?php echo $year; ?>" />
<input style="display: none;" type="text" name="term" value="<?php echo $term; ?>" />
<input style="display: none;" type="text" name="arms" value="<?php echo $arm; ?>" />
<input style="display: none;" type="text" name="subject" value="<?php echo $subject; ?>" />
<input type="submit" class="pbutton" name="btn-upload" value="back" />
</form>
</center>	
<br><br><br>
<?php
include("footer.php");
?>
</body>
</html>
