<?php
include("auth.php");
include('db.php');


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Update Domains</title>
<style>
ul.topnav {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}
ul.topnav li {float: left;}
ul.topnav li a {
    display: inline-block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    transition: 0.3s;
    font-size: 17px;
}
ul.topnav li a:hover {background-color: #555;}
ul.topnav li.icon {display: none;}

@media screen and (max-width:680px) {
  ul.topnav li:not(:first-child) {display: none;}
  ul.topnav li.icon {
    float: right;
    display: inline-block;
  }
}
@media screen and (max-width:680px) {
  ul.topnav.responsive {position: relative;}
  ul.topnav.responsive li.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  ul.topnav.responsive li {
    float: none;
    display: inline;
  }
  ul.topnav.responsive li a {
    display: block;
    text-align: left;
  }
}
</style>

<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>

<script type="text/javascript" src="http://ajax.googleapis.com/
ajax/libs/jquery/1.5/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function()
{
$(".edit_tr").click(function()
{
var ID=$(this).attr('id');
$("#first_"+ID).hide();
$("#last_"+ID).hide();
$("#mid_"+ID).hide();
$("#pfirst_"+ID).hide();
$("#plast_"+ID).hide();
$("#pmid_"+ID).hide();
$("#first_input_"+ID).show();
$("#last_input_"+ID).show();
$("#mid_input_"+ID).show();
$("#pfirst_input_"+ID).show();
$("#plast_input_"+ID).show();
$("#pmid_input_"+ID).show();
}).change(function()
{
var ID=$(this).attr('id');
var first=$("#first_input_"+ID).val();
var last=$("#last_input_"+ID).val();
var mid=$("#mid_input_"+ID).val();
var pfirst=$("#pfirst_input_"+ID).val();
var plast=$("#plast_input_"+ID).val();
var pmid=$("#pmid_input_"+ID).val();
var dataString = 'id='+ ID +'&firstname='+first+'&lastname='+last+'&midname='+mid+'&pfirstname='+pfirst+'&plastname='+plast+'&pmidname='+pmid;
$("#first_"+ID).html('<img src="load.gif" />');


if(first.length && last.length>0)
{
$.ajax({
type: "POST",
url: "table_edit_ajax.php",
data: dataString,
cache: false,
success: function(html)
{

$("#first_"+ID).html(first);
$("#last_"+ID).html(last);
$("#mid_"+ID).html(mid);
$("#pfirst_"+ID).html(pfirst);
$("#plast_"+ID).html(plast);
$("#pmid_"+ID).html(pmid);
}
});
}
else
{
alert('Enter something.');
}

});

$(".editbox").mouseup(function() 
{
return false
});

$(document).mouseup(function()
{
$(".editbox").hide();
$(".text").show();
});
});
</script>
<style>
body
{
font-family:Arial, Helvetica, sans-serif;
font-size:14px;
}
.editbox
{
display:none
}
td
{
padding:7px;
}
.editbox
{
font-size:14px;
width:80px;
background-color:#ffffcc;

border:solid 1px #000;
padding:4px;
}
.edit_tr:hover
{
background:url(edit.png) right no-repeat #80C8E5;
cursor:pointer;
}
th
{
font-weight:bold;
text-align:left;
padding:4px;
}
.head
{
background-color:#333;
color:#FFFFFF
}
</style>

</head>

<body>
<ul class="topnav" id="myTopnav">
  <li><a href="index.php">Classes You Teach</a></li>
  <li><a href="teacher-student.php">Add scores</a></li>
  <li><a href="update-score.php">Update scores</a></li>
  <li><a href="#contact"><a href="formclasses.php">Your Classes as Form Tutor</a></a></li>
  <li><a href="logout.php">Logout</a></li>
  <li class="icon">
    <a href="javascript:void(0);" onclick="myFunction()">&#9776;</a>
  </li>
</ul>
<br>
<center>
<?php
if(isset($_POST['btn-upload'])){
        $teacher_id = $_POST['teacher_id'];
		$teacher = $_POST['teacher'];
        $class = $_POST['class'];
		$year = $_POST['year'];
		$term = $_POST['term'];
echo "<br><div style='width: 100%; color: red; font-size: 16px;'>Data on ".$class." students, ".$term." of ".$year."</div>";
}		
?>
<div style="margin:0 auto; padding:10px; background-color:#fff; height: auto; width: 100%;">
<div style="width: 100%;">AFFECTIVE AND PSYCHOMOTOR DOMAINS</div>
<br><br>
<table style="width: 70%;">
<tr class="head">
<th>Student's Name</th><th>Honesty</th><th>Attentiveness</th><th>Cooperation</th><th>Handwriting</th><th>Painting</th><th>Athletics</th>
</tr>
<?php
include "db.php";
$user = $_SESSION['username'];
$result1 = mysql_query("SELECT * FROM users2 where username='$user'");
while ($row1 = mysql_fetch_assoc($result1)) {
	$valteacher[] = $row1['teacher'];
}
$valteach = current($valteacher);

if(isset($_POST['btn-upload'])){
        $teacher_id = $_POST['teacher_id'];
		$teacher = $_POST['teacher'];
        $class = $_POST['class'];
		$year = $_POST['year'];
		$term = $_POST['term'];

$sql = mysql_query("SELECT * FROM affective where class='$class' AND year='$year' AND term='$term' AND formt='$valteach' ORDER BY student_name");
//$sql=mysql_query("select * from affective");
$i=1;
while($row=mysql_fetch_array($sql))
{
$id=$row['id'];
$firstname=$row['firstname'];
$lastname=$row['lastname'];
$midname=$row['midname'];
$pfirstname=$row['pfirstname'];
$plastname=$row['plastname'];
$pmidname=$row['pmidname'];
$stuname=$row['student_name'];
if($i%2)
{
?>
<tr id="<?php echo $id; ?>" class="edit_tr">
<?php } else { ?>
<tr id="<?php echo $id; ?>" bgcolor="#f2f2f2" class="edit_tr">
<?php } ?>
<td width="10%" class="edit_td">
<span id="stu_<?php echo $id; ?>" class="text"><?php echo $stuname; ?></span>
<input type="text" value="<?php echo $stuname; ?>" class="editbox" id="stu_input_<?php echo $id; ?>" />
</td>
<td width="10%" class="edit_td">
<span id="first_<?php echo $id; ?>" class="text"><?php echo $firstname; ?></span>
<input type="text" value="<?php echo $firstname; ?>" class="editbox" id="first_input_<?php echo $id; ?>" />
</td>
<td width="10%" class="edit_td">
<span id="last_<?php echo $id; ?>" class="text"><?php echo $lastname; ?></span> 
<input type="text" value="<?php echo $lastname; ?>"  class="editbox" id="last_input_<?php echo $id; ?>"/>
</td>
<td width="10%" class="edit_td">
<span id="mid_<?php echo $id; ?>" class="text"><?php echo $midname; ?></span> 
<input type="text" value="<?php echo $midname; ?>"  class="editbox" id="mid_input_<?php echo $id; ?>"/>
</td>
<td width="10%" class="edit_td">
<span id="pfirst_<?php echo $id; ?>" class="text"><?php echo $pfirstname; ?></span> 
<input type="text" value="<?php echo $pfirstname; ?>"  class="editbox" id="pfirst_input_<?php echo $id; ?>"/>
</td>
<td width="10%" class="edit_td">
<span id="plast_<?php echo $id; ?>" class="text"><?php echo $plastname; ?></span> 
<input type="text" value="<?php echo $plastname; ?>"  class="editbox" id="plast_input_<?php echo $id; ?>"/>
</td>
<td width="10%" class="edit_td">
<span id="pmid_<?php echo $id; ?>" class="text"><?php echo $pmidname; ?></span> 
<input type="text" value="<?php echo $pmidname; ?>"  class="editbox" id="pmid_input_<?php echo $id; ?>"/>
</td>
</tr>

<?php
$i++;
}}
?>
</table>
</center>
<br>
</div>
</body>
</html>
