<?php
$absents = "11/09 (M), 11/09 (A), 12/09 (M), 13/09 (A),";
$abb = explode(",",$absents);
print_r($abb);
$abbb = array_slice($abb, 0, (count($abb)-1));
$abbbb = implode(",",$abbb);
echo $abbbb;
?>