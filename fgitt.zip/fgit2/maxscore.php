<?php
session_start();
include("auth.php"); //include auth.php file on all secure pages
require_once("connection.php");
$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Max Score</title>
<link rel="stylesheet" href="css/style.css" />
<link href="table/css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
<link rel="stylesheet" type="text/css" href="table/css/DT_bootstrap.css">
<script src="table/js/bootstrap.js" type="text/javascript"></script>
<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/jquery.dataTables.js"></script>
<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/DT_bootstrap.js"></script>
<script src="table/js/jquery.js" type="text/javascript"></script>
<script>
function printDiv(eleId){
    var PW = window.open('', '_blank', 'Print content');
    PW.document.write(document.getElementById(eleId).innerHTML);
    PW.document.close();
    PW.focus();
    PW.print();
    PW.close();
}
</script>

  
   <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>
<script>
$(document).ready(function() {	
$("#mxscores").submit(function( evx ) {
			evx.preventDefault();
var countlist = $("#resultlist li").length;	
if(countlist > 0){
$(".liresultlist").fadeOut(500); 	
}		
$.ajax({
type: "POST",
url: "pdf4/examples/maxscorespdf.php",
cache: false,
data: $("#mxscores").serializeArray(), 
beforeSend: function(){
	$("#loadit").addClass("loader");
	$("#loadit").after("<label id='forremoval' style='color: red;' >We are preparing your download. Please wait...</label>");
	$('#attpdfsubmit').attr( 'onClick', 'return false' );
	},
success: function(response){
$("#resultlist").append("<li class='liresultlist'><a class='pbutton2' style='margin: auto; text-align: id='forresult' center;' href='pdf4/examples/maxscores/"+response+"' download>download ranking</a></li>");	
},
complete: function(){
$("#loadit").removeClass("loader");	
$("#forremoval").remove();
$('#attpdfsubmit').attr( 'onClick', 'return true' );
}
});			
});
});
</script>
<style>
.loader {
  border: 8px solid #f3f3f3;
  border-radius: 50%;
  border-top: 8px solid blue;
  border-right: 8px solid green;
  border-bottom: 8px solid red;
  width: 20px;
  height: 20px;
  -webkit-animation: spin 2s linear infinite;
  animation: spin 2s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.dnone{
	display: none;
}
</style>
<style>
.pbutton {
	background-color:#44c767;
	-moz-border-radius:28px;
	-webkit-border-radius:28px;
	border-radius:2px;
	border:1px solid #18ab29;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:15px;
	padding:6px 12px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
	float: left;
	margin: 0;
}
.pbutton:hover {
	background-color:#5cbf2a;
}
.pbutton:active {
	position:relative;
	top:1px;
}
.pbutton2 {
	background-color:#44c767;
	-moz-border-radius:2px;
	-webkit-border-radius:28px;
	border-radius:28px;
	border:1px solid #18ab29;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:15px;
	padding:6px 24px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
}
.pbutton2:hover {
	background-color:#5cbf2a;
}
.pbutton2:active {
	position:relative;
	top:1px;
}
</style>
 <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
</head>
<body>
<?php
$resultrole2 = mysqli_query($db, "SELECT role FROM users2 where username='".$_SESSION['username']."'");
while($rowrole2 = mysqli_fetch_assoc($resultrole2))
{
	$arole[] = $rowrole2['role'];
}
$_SESSION['role'] =  current($arole);

if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");
}
elseif($_SESSION['role'] == 'student'){
include("headerstudent.php");
}
else{ header("location: logout.php");}
?>
<br><br>
<div id="printMe">
<?php
$maxscoresEng22 = $_POST["maxscoresEng2"];
$maxscoresMat22 = $_POST["maxscoresMat2"];
$maxscoresFre22 = $_POST["maxscoresFre2"];
$maxscoresAgr22 = $_POST["maxscoresAgr2"];
$maxscoresBio22 = $_POST["maxscoresBio2"];
$maxscoresEco22 = $_POST["maxscoresEco2"];
$maxscoresChe22 = $_POST["maxscoresChe2"];
$maxscoresBas22 = $_POST["maxscoresBas2"];
$maxscoresBus22 = $_POST["maxscoresBus2"];
$maxscoresCat22 = $_POST["maxscoresCat2"];
$maxscoresCiv22 = $_POST["maxscoresCiv2"];
$maxscoresCre22 = $_POST["maxscoresCre2"];
$maxscoresCrk22 = $_POST["maxscoresCrk2"];
$maxscoresFoo22 = $_POST["maxscoresFoo2"];
$maxscoresMus22 = $_POST["maxscoresMus2"];
$maxscoresGov22 = $_POST["maxscoresGov2"];
$maxscoresIct22 = $_POST["maxscoresIct2"];
$maxscoresIgb22 = $_POST["maxscoresIgb2"];
$maxscoresLit22 = $_POST["maxscoresLit2"];
$maxscoresMar22 = $_POST["maxscoresMar2"];
$maxscoresPhe22 = $_POST["maxscoresPhe2"];
$maxscoresPhy22 = $_POST["maxscoresPhy2"];
$maxscoresSoc22 = $_POST["maxscoresSoc2"];
$maxscoresSocio22 = $_POST["maxscoresSocio2"];
$maxscoresTd22 = $_POST["maxscoresTd2"];
$maxscoresVa22 = $_POST["maxscoresVa2"];
$maxscoresYor22 = $_POST["maxscoresYor2"];
$maxscoresGeo22 = $_POST["maxscoresGeo2"];
$maxscoresHis22 = $_POST["maxscoresHis2"];
$maxscoresCom22 = $_POST["maxscoresCom2"];
$maxscoresFin22 = $_POST["maxscoresFin2"];
$maxscoresFur22 = $_POST["maxscoresFur2"];
$maxscoresGer22 = $_POST["maxscoresGer2"];
$maxscoresHau22 = $_POST["maxscoresHau2"];
$maxscoresHea22 = $_POST["maxscoresHea2"];
$maxscoresIsl22 = $_POST["maxscoresIsl2"];
$maxscoresAra22 = $_POST["maxscoresAra2"];
$maxscoresHw22 = $_POST["maxscoresHw2"];
$maxscoresQr22 = $_POST["maxscoresQr2"];
$maxscoresVr22 = $_POST["maxscoresVr2"];
$maxscoresVap22 = $_POST["maxscoresVap2"];
$maxscoresPho22 = $_POST["maxscoresPho2"];
$maxscoresIrs22 = $_POST["maxscoresIrs2"];
$subject = $_POST["subject"];
$student_name = $_POST["student_name2"];
$class = $_POST["class2"];
$year = $_POST["year2"];
$term = $_POST["term2"];
$arms = $_POST["arms"];
$sig = $_POST["sig"];
/*if($ctype=="Js"){
$checkclass = mysqli_query($db, "SELECT * FROM classes where class_name='$class'");
while($rowcla = mysqli_fetch_assoc($checkclass)){
$cll2[] = $rowcla['class_name2'];
}
$classs = current($cll2);
}else{
$classs = $_POST['class_name'];	
}*/
if($class=="Year 1"){
	if($ctype=="Js"){
	$cl = "JS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 1";
}else{
	$cl = "Year 1";
}
}
elseif($class=="Year 2"){
	if($ctype=="Js"){
	$cl = "JS2";
}elseif($ctype=="Primary"){
	$cl = "Primary 2";
}else{
	$cl = "Year 2";
}
}
elseif($class=="Year 3"){
	if($ctype=="Js"){
	$cl = "JS3";
}elseif($ctype=="Primary"){
	$cl = "Primary 3";
}else{
	$cl = "Year 3";
}
}
elseif($class=="Year 4"){
	if($ctype=="Js"){
	$cl = "SS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 4";
}else{
	$cl = "Year 4";
}
}
elseif($class=="Year 5"){
	if($ctype=="Js"){
	$cl = "SS2";
}elseif($ctype=="Primary"){
	$cl = "Primary 5";
}else{
	$cl = "Year 5";
}
}
elseif($class=="Year 6"){
	if($ctype=="Js"){
	$cl = "SS3";
}elseif($ctype=="Primary"){
	$cl = "Primary 6";
}else{
	$cl = "Year 6";
}
}
elseif($class=="Year 7"){
	if($ctype=="Js"){
	$cl = "JS1";
}else{
	$cl = "Year 7";
}
}
else if($class=="Year 8"){
	if($ctype=="Js"){
	$cl = "JS2";
}else{
	$cl = "Year 8";
}
}else if($class=="Year 9"){
	if($ctype=="Js"){
	$cl = "JS3";
}else{
	$cl = "Year 9";
}
}else if($class=="Year 10"){
	if($ctype=="Js"){
	$cl = "SS1";
}else{
	$cl = "Year 10";
}
}else if($class=="Year 11"){
	if($ctype=="Js"){
	$cl = "SS2";
}else{
	$cl = "Year 11";
}
}else if($class=="Year 12"){
	if($ctype=="Js"){
	$cl = "SS3";
}else{
	$cl = "Year 12";
}
}else{
	$cl = "NOT APPLICABLE";
}

if($subject == 'English'){
	$maxscores22 = $maxscoresEng22;
}
else if($subject == 'Mathematics'){
	$maxscores22 = $maxscoresMat22;
}
else if($subject == 'French'){
	$maxscores22 = $maxscoresFre22;
}
else if($subject == 'Agricultural Science'){
	$maxscores22 = $maxscoresAgr22;
}
else if($subject == 'Biology'){
	$maxscores22 = $maxscoresBio22;
}
else if($subject == 'Economics'){
	$maxscores22 = $maxscoresEco22;
}
else if($subject == 'Chemistry'){
	$maxscores22 = $maxscoresChe22;
}
else if($subject == 'Basic Science'){
	$maxscores22 = $maxscoresBas22;
}
else if($subject == 'Business Studies'){
	$maxscores22 = $maxscoresBus22;
}
else if($subject == 'Catering'){
	$maxscores22 = $maxscoresCat22;
}
else if($subject == 'Civic Education'){
	$maxscores22 = $maxscoresCiv22;
}
else if($subject == 'CRK'){
	$maxscores22 = $maxscoresCrk22;
}
else if($subject == 'Food and Nutrition'){
	$maxscores22 = $maxscoresFoo22;
}
else if($subject == 'Music'){
	$maxscores22 = $maxscoresMus22;
}
else if($subject == 'Government'){
	$maxscores22 = $maxscoresGov22;
}
else if($subject == 'ICT'){
	$maxscores22 = $maxscoresIct22;
}
else if($subject == 'Igbo'){
	$maxscores22 = $maxscoresIgb22;
}
else if($subject == 'Literature in English'){
	$maxscores22 = $maxscoresLit22;
}
else if($subject == 'Marketing'){
	$maxscores22 = $maxscoresMar22;
}
else if($subject == 'PHE'){
	$maxscores22 = $maxscoresPhe22;
}
else if($subject == 'Physics'){
	$maxscores22 = $maxscoresPhy22;
}
else if($subject == 'Social Studies'){
	$maxscores22 = $maxscoresSoc22;
}
else if($subject == 'Sociology'){
	$maxscores22 = $maxscoresSocio22;
}
else if($subject == 'TD'){
	$maxscores22 = $maxscoresTd22;
}
else if($subject == 'VA'){
	$maxscores22 = $maxscoresVa22;
}
else if($subject == 'Vocational Aptitude'){
	$maxscores22 = $maxscoresVap22;
}
else if($subject == 'Yoruba'){
	$maxscores22 = $maxscoresYor22;
}
else if($subject == 'Geography'){
	$maxscores22 = $maxscoresGeo22;
}
else if($subject == 'History'){
	$maxscores22 = $maxscoresHis22;
}
else if($subject == 'Commerce'){
	$maxscores22 = $maxscoresCom22;
}
else if($subject == 'Financial Accounting'){
	$maxscores22 = $maxscoresFin22;
}
else if($subject == 'Creative and Cultural Arts'){
	$maxscores22 = $maxscoresCre22;
}
else if($subject == 'Further Mathematics'){
	$maxscores22 = $maxscoresFur22;
}
else if($subject == 'German'){
	$maxscores22 = $maxscoresGer22;
}
else if($subject == 'Hausa'){
	$maxscores22 = $maxscoresHau22;
}
else if($subject == 'Health Science'){
	$maxscores22 = $maxscoresHea22;
}
else if($subject == 'Islamic Religious Studies'){
	$maxscores22 = $maxscoresIrs22;
}
else if($subject == 'Arabic'){
	$maxscores22 = $maxscoresAra22;
}
else if($subject == 'Quantitative Reasoning'){
	$maxscores22 = $maxscoresQr22;
}
else if($subject == 'Verbal Reasoning'){
	$maxscores22 = $maxscoresVr22;
}
else if($subject == 'Handwriting'){
	$maxscores22 = $maxscoresHw22;
}
else if($subject == 'Phonics'){
	$maxscores22 = $maxscoresPho22;
}
else{
	echo "Data not available";
}
foreach($maxscores22 as $values)
{
 list($a, $b) = explode("-", $values);
	 $a2pdf[] = $a;
	 $b2pdf[] = $b;
}
$comb = array_combine($a2pdf, $b2pdf);
arsort($comb);
$akey = array_keys($comb);
$aval = array_values($comb);

echo '<div class="row-fluid" style="width:100%;">';
echo '<div class="span12">';
echo '<div class="container" style="width:100%;">';
echo '<table style="width:100%;" cellpadding="1" cellspacing="1" border="1" class="table table-striped table-bordered" id="example">';
echo '<thead><tr style="text-align:center;">';
if($arms==""){
echo '<th colspan="3" style="text-align:center;">PERFORMANCE RANKING OF STUDENTS IN '.strtoupper($subject).' IN '.strtoupper($cl).', '.$year.'/'.($year+1).' SESSION</th></thead></tr>';
}else{
echo '<th colspan="3" style="text-align:center;">PERFORMANCE RANKING OF STUDENTS IN '.strtoupper($subject).' IN '.strtoupper($cl).' '.strtoupper($arms).', '.$year.'/'.($year+1).' SESSION</th></thead></tr>';
}
echo '<tr style="text-align:center;"><td>STUDENT</td><td>SCORE</td><td>POSITION</td></tr>';
$counter = 1;
$v = 0;
for($i=0; $i<=(count($aval)-1); $i++){
	if($v==$aval[$i])
	{
	   $counter--;
	}
if($counter == 1){
	$attach = "st";
}else if($counter == 2){
	$attach = "nd";
}
else if($counter == 3){
$attach = "rd";
}	
else{
$attach = "th";	
}
if($_SESSION['role'] == 'student'){
if($akey[$i] != $student_name){
echo '<tr><td>*******</td><td>'.$aval[$i].'</td><td>'.$counter.$attach.'</td></tr>';
}else{
echo '<tr><td style="color: red;" >'.strtoupper($akey[$i]).'</td><td>'.$aval[$i].'</td><td>'.$counter.$attach.'</td></tr>';	
}
$countin[] = $counter.$attach;
$v = $aval[$i];
$counter++;
}else
{
if($akey[$i] != $student_name){
echo '<tr><td>'.$akey[$i].'</td><td>'.$aval[$i].'</td><td>'.$counter.$attach.'</td></tr>';
}else{
echo '<tr><td style="color: red;" >'.strtoupper($akey[$i]).'</td><td>'.$aval[$i].'</td><td>'.$counter.$attach.'</td></tr>';	
}
$countin[] = $counter.$attach;
$v = $aval[$i];
$counter++;	
}


}
echo "</table>";

?>
</div>
<center>
<button class="pbutton" onclick="printDiv('printMe');">Print</button>
<?php
echo '<form name="maxform" id="mxform" action="getresult.php" method="post">';
echo '<input style="display: none;" name="student_name" type="text" value="'.$student_name. '">';
echo '<input style="display: none;" name="class_name" type="text" value="'.$class. '">';
echo '<input  style="display: none;" name="year" type="text" value="'.$year. '">';
echo '<input  style="display: none;" name="term" type="text" value="'.$term. '">';
echo '<input  style="display: none;" name="checker" type="text" value="yes">';
echo '<input  style="display: none;" name="arms" type="text" value="'.$arms. '">';
echo '<input  style="display: none;" name="sig" type="text" value="'.$sig. '">';
echo '<input type="submit" name="submit3" style="margin-top: -5px;" class="pbutton" value="Back to Result" />';
echo '</form>';

echo '<form id="mxscores">';
foreach($akey as $aloop)
{
  echo '<input style="display: none;" type="text" name="aloop[]" value="'. $aloop. '">';
}
foreach($aval as $bloop)
{
  echo '<input style="display: none;" type="text" name="bloop[]" value="'. $bloop. '">';
}
foreach($countin as $countloop)
{
  echo '<input style="display: none;" type="text" name="countloop[]" value="'. $countloop. '">';
}
echo '<input style="display: none;" name="student_name[]" type="text" value="'.$student_name. '">';
echo '<input style="display: none;" name="class[]" type="text" value="'.$class. '">';
echo '<input  style="display: none;" name="year[]" type="text" value="'.$year. '">';
echo '<input  style="display: none;" name="term[]" type="text" value="'.$term. '">';
echo '<input  style="display: none;" name="subject[]" type="text" value="'.$subject. '">';
echo '<input type="submit" name="submit" class="pbutton" style="margin-top: -5px;" value="Make Downloadable" />';
echo '</form>';
?>
<center>
<div id="loadit"></div>	
<div id="afterthis"><ul id="resultlist" style="list-style-type: none;" ></ul></div>
</center>
<br><br><br>
<?php
include("footer.php");
?>
</body>