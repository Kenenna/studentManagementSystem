<?php
include("auth.php"); //include auth.php file on all secure pages
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Get Transcript</title>
<script type="text/javascript" src="js/jquery-2.1.4.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script>
$(document).ready(function(){
	$( "tr:even" ).css( "background-color", "grey" );
	$( "tr:odd" ).css( "background-color", "red" );
	$( "tr:even" ).css( "color", "white" );
	$( "td:empty" ).text( "-" );
});
</script>

<script>
function printDiv(eleId){
    var PW = window.open('', '_blank', 'Print content');
 
    //IF YOU HAVE DIV STYLE IN CSS, REMOVE BELOW COMMENT AND ADD CSS ADDRESS
    //PW.document.write('<link rel="stylesheet" type="text/css" href="CSS-FILE-ADDRESS"/>');
 
    PW.document.write(document.getElementById(eleId).innerHTML);
    PW.document.close();
    PW.focus();
    PW.print();
    PW.close();
}
</script>

</head>
<body>
<?php
$class_name = $_POST['class_name'];
$year = $_POST['year'];
include "connection.php";
$user1 = $_SESSION['username'];
$resultreguser = mysqli_query($db, "SELECT * FROM users2 WHERE username='$user1'");
while($resultreguser2 = mysqli_fetch_assoc($resultreguser)){ 
$st_name[] = $resultreguser2['teacher'];
}
$student_name2 = current($st_name);
$resultreg = mysqli_query($db, "SELECT * FROM regstu WHERE caa='$class_name' AND yoa='$year' AND student_name='$student_name2'");
$regcount = mysqli_num_rows($resultreg);
if($regcount != 1){
	echo "<div style='color:red; width:100%; text-align: center;'>YOUR YEAR OF ADMISSION OR CLASS AT ADMISSION IS INCORRECT</div>";
	}
else{
    while($resultreg2 = mysqli_fetch_assoc($resultreg)){ 			
$stu_name[] = $resultreg2['student_name'];
$sex[] = $resultreg2['sex'];
$caa[] = $resultreg2['caa'];
$yoa[] = $resultreg2['yoa'];
$admno[] = $resultreg2['admno'];
$reason[] = $resultreg2['reason'];
}
$stu_name2 = current($stu_name);
$sex2 = current($sex);	
$caa2 = current($caa);
$yoa2 = current($yoa);
$admno2 = current($admno);
$reason2 = current($reason);

$year1 = $_POST['year'];
$year2 = $year1 + 1;
$year3 = $year1 + 2;
$year4 = $year1 + 3;
$year5 = $year1 + 4;
$year6 = $year1 + 5;
include "connection.php";
$resultgrad = mysqli_query($db, "SELECT * FROM studentsbyclass WHERE student_name='$stu_name2' AND (year='$year1' OR year='$year2' OR year='$year3' OR year='$year4' OR year='$year5' OR year='$year6') AND (term='First Term' OR term='Second Term' OR term='Third Term')");
while($rowgrad = mysqli_fetch_assoc($resultgrad))
							{ 			
$yeargrad[] = $rowgrad['year'];
}
$yeargrad2 = $yeargrad;
$maxgrad = max($yeargrad2);

$resultclass = mysqli_query($db, "SELECT * FROM studentsbyclass WHERE student_name='$stu_name2' AND year='$maxgrad' AND (term='First Term' OR term='Second Term' OR term='Third Term')");
while($rowclass = mysqli_fetch_assoc($resultclass))
							{ 			
$classgrad[] = $rowclass['class'];
}
$classgrad2 = current($classgrad);
?>
<button onclick="printDiv('printMe');">Print DIV</button>
<div id="printMe">
<table style="width: 100%;">
<tbody style="width: 100%;">
<tr style="width: 100%;">
<td style="width: 6%;"><img src="images/6.png" align="left" height="70" width="90" /></td>
<td style="text-align: left; width: 78%;" colspan="2">
<span style="font-size: 12pt;">CORONA SCHOOLS TRUST</span><br><span style="font-size: 10pt;">CORONA SECONDARY SCHOOL</span><br>
<span style="font-size: 9pt;">Yenagoa Road, Agbara Estate, Ogun State, Nigeria</span><br>
<span style="font-size: 8pt;">Email: info@coronaschools.org</span></span><br>
<span style="font-size: 8pt;"><span>Website: www.coronaschools.org</span></span><br>
</td>
<td style="width: 6%;">
<?php
include "connection.php";	
$student_name = $_POST['student_name'];
$resultpic = mysqli_query($db, "SELECT * FROM img WHERE student_name='$student_name'");
						while($rowpic = mysqli_fetch_assoc($resultpic))
							{ 			
echo '<img style="float:right;" src="'.$rowpic['img'].'" height="80" width="100"/>';
}
?>
</td>
</tr>
<tr style="width: 100%;">
<td colspan="2" style="font-size: 11px; width: 50%;">NAME: <?php echo strtoupper($stu_name2); ?></td>
<td colspan="2" style="text-align: right; font-size: 10px; width: 50%;">YEAR OF ENTRY: <?php echo strtoupper($yoa2); ?> &nbsp;&nbsp;/&nbsp;&nbsp; YEAR OF LEAVING: <?php echo $maxgrad ?></td>
</tr>
<tr style="width: 100%;">
<td colspan="2" style="font-size: 10px; width: 50%;">SEX: <?php echo strtoupper($sex2); ?></td>
<td colspan="2" style="text-align: right; font-size: 10px; width: 50%;">REASON FOR LEAVING: <?php echo strtoupper($reason2); ?></td>
</tr>
<tr style="width: 100%;">
<td colspan="2" style="font-size: 10px; width: 50%;">CLASS: <?php echo strtoupper($caa2); ?> - <?php echo strtoupper($classgrad2); ?></td>
<td colspan="2" style="text-align: right; font-size: 10px; width: 50%;">ADMISSION NO: <?php echo $admno2; ?></td>
</tr>
</tbody>
</table>
<table style="height: auto; width: 100%; text-align: center;">
<tr><td><span style="font-size: 12pt;">TRANSCRIPT</span></td></tr>
</table>


<table id="tb1" style="font-size: 11px; width: 100%; text-align: center;" border="1">
<tbody>
<tr style="height: 2px;">
<td rowspan="3">SUBJECT</td>
<?php
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NOT APPLICABLE';
		}
	?>
<td  colspan="6"><?php echo $y; ?></td>
<?php } ?>

<?php
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NOT APPLICABLE';
		}
	?>
<td colspan="6"><?php echo $y; ?></td>
	<?php } ?>
	
	
<?php
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NOT APPLICABLE';
		}
	?>
<td colspan="6"><?php echo $y; ?></td>
	<?php } ?>
	
<?php
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NOT APPLICABLE';
		}
	?>
<td colspan="6"><?php echo $y; ?></td>
	<?php } ?>
	
<?php
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NOT APPLICABLE';
		}
	?>
<td colspan="6"><?php echo $y; ?></td>
	<?php } ?>
	
<?php
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
	?>
<td colspan="6"><?php echo $y; ?></td>
	<?php } ?>
</tr>
<tr style="height: 13px;">
<td colspan="2">1st Term</td>
<td colspan="2">2nd Term</td>
<td colspan="2">3rd Term</td>

<td  colspan="2">1st Term</td>
<td  colspan="2">2nd Term</td>
<td colspan="2">3rd Term</td>

<td  colspan="2">1st Term</td>
<td  colspan="2">2nd Term</td>
<td colspan="2">3rd Term</td>

<td  colspan="2">1st Term</td>
<td  colspan="2">2nd Term</td>
<td colspan="2">3rd Term</td>

<td  colspan="2">1st Term</td>
<td  colspan="2">2nd Term</td>
<td colspan="2">3rd Term</td>

<td  colspan="2">1st Term</td>
<td  colspan="2">2nd Term</td>
<td colspan="2">3rd Term</td>
</tr>
<tr style="height: 13px;">
<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>

<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>

<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>

<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>

<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>

<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>
<td>Score</td>
<td>Grade</td>
</tr>






<tr style="height: 13px;">
<td>ENGLISH</td>
<?php
//YEAR 7 DATA FIRST TERM FOR ENGLISH
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$engscore71[] = $row['score'];	
						}
$engsc71 = current($engscore71);					
?>
<td><?php echo $engsc71;  ?></td>
<td><?php if($engsc71 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>

<?php
//YEAR 7 DATA SECOND TERM FOR ENGLISH
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
	$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}	
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$engscore72[] = $row['score'];	
						}
$engsc72 = current($engscore72);						
?>
<td><?php echo $engsc72;  ?></td>
<td><?php if($engsc72 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>


<?php
//YEAR 7 DATA THIRD TERM FOR ENGLISH
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
if($class_name == 'Year 12'){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NOT APPLICABLE';
		}	
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$engscore73[] = $row['score'];	
						}
$engsc73 = current($engscore73);						
?>
<td><?php echo $engsc73;  ?></td>
<td><?php if($engsc73 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 8 DATA FIRST TERM FOR ENGLISH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$engscore81[] = $row['score'];	
						}
$engsc81 = current($engscore81);						
?>
<td><?php echo $engsc81;  ?></td>
<td><?php if($engsc81 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>


<?php
// YEAR 8 DATA SECOND TERM FOR ENGLISH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$engscore82[] = $row['score'];	
						}
$engsc82 = current($engscore82);						
?>
<td><?php echo $engsc82;  ?></td>
<td><?php if($engsc82 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 8 DATA THIRD TERM FOR ENGLISH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$engscore83[] = $row['score'];	
						}
$engsc83 = current($engscore83);						
?>
<td><?php echo $engsc83;  ?></td>
<td><?php if($engsc83 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>


<?php
// YEAR 9 DATA FIRST TERM FOR ENGLISH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$engscore91[] = $row['score'];	
						}
$engsc91 = current($engscore91);						
?>
<td><?php echo $engsc91;  ?></td>
<td><?php if($engsc91 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>


<?php
// YEAR 9 DATA SECOND TERM FOR ENGLISH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$engscore92[] = $row['score'];	
						}
$engsc92 = current($engscore92);						
?>
<td><?php echo $engsc92;  ?></td>
<td><?php if($engsc92 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 9 DATA THIRD TERM FOR ENGLISH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$engscore93[] = $row['score'];	
						}
$engsc93 = current($engscore93);						
?>
<td><?php echo $engsc93;  ?></td>
<td><?php if($engsc93 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 10 DATA FIRST TERM FOR ENGLISH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$engscore101[] = $row['score'];	
						}
$engsc101 = current($engscore101);						
?>
<td><?php echo $engsc101;  ?></td>
<td><?php if($engsc101 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>


<?php
// YEAR 10 DATA SECOND TERM FOR ENGLISH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$engscore102[] = $row['score'];	
						}
$engsc102 = current($engscore102);						
?>
<td><?php echo $engsc102;  ?></td>
<td><?php if($engsc102 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 10 DATA THIRD TERM FOR ENGLISH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$engscore103[] = $row['score'];	
						}
$engsc103 = current($engscore103);						
?>
<td><?php echo $engsc103;  ?></td>
<td><?php if($engsc103 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>





<?php
// YEAR 11 DATA FIRST TERM FOR ENGLISH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$engscore111[] = $row['score'];	
						}
$engsc111 = current($engscore111);						
?>
<td><?php echo $engsc111;  ?></td>
<td><?php if($engsc111 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>


<?php
// YEAR 11 DATA SECOND TERM FOR ENGLISH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$engscore112[] = $row['score'];	
						}
$engsc112 = current($engscore112);						
?>
<td><?php echo $engsc112;  ?></td>
<td><?php if($engsc112 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 10 DATA THIRD TERM FOR ENGLISH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NOT APPLICABLE';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$engscore113[] = $row['score'];	
						}
$engsc113 = current($engscore113);						
?>
<td><?php echo $engsc113;  ?></td>
<td><?php if($engsc113 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>




<?php
// YEAR 12 DATA FIRST TERM FOR ENGLISH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$engscore121[] = $row['score'];	
						}
$engsc121 = current($engscore121);						
?>
<td><?php echo $engsc121;  ?></td>
<td><?php if($engsc121 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>


<?php
// YEAR 12 DATA SECOND TERM FOR ENGLISH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$engscore122[] = $row['score'];	
						}
$engsc122 = current($engscore122);						
?>
<td><?php echo $engsc122;  ?></td>
<td><?php if($engsc122 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 12 DATA THIRD TERM FOR ENGLISH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='English'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else if($y == 'NOT APPLICABLE'){$grade = "NA";}
								else {$grade = "NA";}
						$engscore123[] = $row['score'];	
						}
$engsc123 = current($engscore123);				
?>
<td><?php echo $engsc123;  ?></td>
<td><?php if($engsc123 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>
</tr>










<tr style="height: 13px;">
<td>MATHEMATICS</td>
<?php
//YEAR 7 DATA FIRST TERM FOR MATHEMATICS
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$score71[] = $row['score'];						
						}
$sc71 = current($score71);					
?>
<td><?php echo $sc71;  ?></td>
<td><?php if($sc71 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>

<?php
//YEAR 7 DATA SECOND TERM FOR MATHEMATICS
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
	$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}	
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$score72[] = $row['score'];	
						}
$sc72 = current($score72);						
?>
<td><?php echo $sc72;  ?></td>
<td><?php if($sc72 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>


<?php
//YEAR 7 DATA THIRD TERM FOR MATHEMATICS
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
if($class_name == 'Year 12'){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NOT APPLICABLE';
		}	
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$score73[] = $row['score'];	
						}
$sc73 = current($score73);						
?>
<td><?php echo $sc73;  ?></td>
<td><?php if($sc73 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 8 DATA FIRST TERM FOR MATHEMATICS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$score81[] = $row['score'];	
						}
$sc81 = current($score81);						
?>
<td><?php echo $sc81;  ?></td>
<td><?php if($sc81 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>


<?php
// YEAR 8 DATA SECOND TERM FOR MATHEMATICS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$score82[] = $row['score'];	
						}
$sc82 = current($score82);						
?>
<td><?php echo $sc82;  ?></td>
<td><?php if($sc82 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 8 DATA THIRD TERM FOR MATHEMATICS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$score83[] = $row['score'];	
						}
$sc83 = current($score83);						
?>
<td><?php echo $sc83;  ?></td>
<td><?php if($sc83 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>


<?php
// YEAR 9 DATA FIRST TERM FOR MATHEMATICS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$score91[] = $row['score'];	
						}
$sc91 = current($score91);						
?>
<td><?php echo $sc91;  ?></td>
<td><?php if($sc91 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>


<?php
// YEAR 9 DATA SECOND TERM FOR MATHEMATICS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$score92[] = $row['score'];	
						}
$sc92 = current($score92);						
?>
<td><?php echo $sc92;  ?></td>
<td><?php if($sc92 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 9 DATA THIRD TERM FOR MATHEMATICS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$score93[] = $row['score'];	
						}
$sc93 = current($score93);						
?>
<td><?php echo $sc93;  ?></td>
<td><?php if($sc93 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 10 DATA FIRST TERM FOR MATHEMATICS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$score101[] = $row['score'];	
						}
$sc101 = current($score101);						
?>
<td><?php echo $sc101;  ?></td>
<td><?php if($sc101 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>


<?php
// YEAR 10 DATA SECOND TERM FOR MATHEMATICS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$score102[] = $row['score'];	
						}
$sc102 = current($score102);						
?>
<td><?php echo $sc102;  ?></td>
<td><?php if($sc102 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 10 DATA THIRD TERM FOR MATHEMATICS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$score103[] = $row['score'];	
						}
$sc103 = current($score103);						
?>
<td><?php echo $sc103;  ?></td>
<td><?php if($sc103 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>





<?php
// YEAR 11 DATA FIRST TERM FOR MATHEMATICS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$score111[] = $row['score'];	
						}
$sc111 = current($score111);						
?>
<td><?php echo $sc111;  ?></td>
<td><?php if($sc111 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>


<?php
// YEAR 11 DATA SECOND TERM FOR MATHEMATICS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$score112[] = $row['score'];	
						}
$sc112 = current($score112);						
?>
<td><?php echo $sc112;  ?></td>
<td><?php if($sc112 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 11 DATA THIRD TERM FOR MATHEMATICS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NOT APPLICABLE';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$score113[] = $row['score'];	
						}
$sc113 = current($score113);						
?>
<td><?php echo $sc113;  ?></td>
<td><?php if($sc113 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>




<?php
// YEAR 12 DATA FIRST TERM FOR MATHEMATICS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$score121[] = $row['score'];	
						}
$sc121 = current($score121);						
?>
<td><?php echo $sc121;  ?></td>
<td><?php if($sc121 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>


<?php
// YEAR 12 DATA SECOND TERM FOR MATHEMATICS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$score122[] = $row['score'];	
						}
$sc122 = current($score122);						
?>
<td><?php echo $sc122;  ?></td>
<td><?php if($sc122 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 12 DATA THIRD TERM FOR MATHEMATICS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Mathematics'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else if($y == 'NOT APPLICABLE'){$grade = "NA";}
								else {$grade = "NA";}
						$score123[] = $row['score'];	
						}
$sc123 = current($score123);				
?>
<td><?php echo $sc123;  ?></td>
<td><?php if($sc123 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>
</tr>




<tr style="height: 13px;">
<td>AGRIC. SC.</td>
<?php
//YEAR 7 DATA FIRST TERM FOR AGRIC
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='agricultural science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$agrscore71[] = $row['score'];	
						}
$agrsc71 = current($agrscore71);					
?>
<td><?php echo $agrsc71;  ?></td>
<td><?php if($agrsc71 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>

<?php
//YEAR 7 DATA SECOND TERM FOR AGRIC
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
	$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}	
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$agrscore72[] = $row['score'];	
						}
$agrsc72 = current($agrscore72);						
?>
<td><?php echo $agrsc72;  ?></td>
<td><?php if($agrsc72 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>


<?php
//YEAR 7 DATA THIRD TERM FOR AGRIC
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
if($class_name == 'Year 12'){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NOT APPLICABLE';
		}	
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$agrscore73[] = $row['score'];	
						}
$agrsc73 = current($agrscore73);						
?>
<td><?php echo $agrsc73;  ?></td>
<td><?php if($agrsc73 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 8 DATA FIRST TERM FOR AGRIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$frescore81[] = $row['score'];	
						}
$fresc81 = current($frescore81);						
?>
<td><?php echo $fresc81;  ?></td>
<td><?php if($fresc81 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>


<?php
// YEAR 8 DATA SECOND TERM FOR AGRIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$agrscore82[] = $row['score'];	
						}
$agrsc82 = current($agrscore82);						
?>
<td><?php echo $agrsc82;  ?></td>
<td><?php if($agrsc82 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 8 DATA THIRD TERM FOR AGRIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$agrscore83[] = $row['score'];	
						}
$agrsc83 = current($agrscore83);						
?>
<td><?php echo $agrsc83;  ?></td>
<td><?php if($agrsc83 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>


<?php
// YEAR 9 DATA FIRST TERM FOR AGRIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$agrscore91[] = $row['score'];	
						}
$agrsc91 = current($agrscore91);						
?>
<td><?php echo $agrsc91;  ?></td>
<td><?php if($agrsc91 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>


<?php
// YEAR 9 DATA SECOND TERM FOR AGRIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$agrscore92[] = $row['score'];	
						}
$agrsc92 = current($agrscore92);						
?>
<td><?php echo $agrsc92;  ?></td>
<td><?php if($agrsc92 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 9 DATA THIRD TERM FOR AGRIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$agrscore93[] = $row['score'];	
						}
$agrsc93 = current($agrscore93);						
?>
<td><?php echo $agrsc93;  ?></td>
<td><?php if($agrsc93 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 10 DATA FIRST TERM FOR AGRIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$agrscore101[] = $row['score'];	
						}
$agrsc101 = current($agrscore101);						
?>
<td><?php echo $agrsc101;  ?></td>
<td><?php if($agrsc101 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>


<?php
// YEAR 10 DATA SECOND TERM FOR AGRIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$agrscore102[] = $row['score'];	
						}
$agrsc102 = current($agrscore102);						
?>
<td><?php echo $agrsc102;  ?></td>
<td><?php if($agrsc102 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 10 DATA THIRD TERM FOR AGRIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$agrscore103[] = $row['score'];	
						}
$agrsc103 = current($agrscore103);						
?>
<td><?php echo $agrsc103;  ?></td>
<td><?php if($agrsc103 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 11 DATA FIRST TERM FOR AGRIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$agrscore111[] = $row['score'];	
						}
$agrsc111 = current($agrscore111);						
?>
<td><?php echo $agrsc111;  ?></td>
<td><?php if($agrsc111 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>


<?php
// YEAR 11 DATA SECOND TERM FOR AGRIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$agrscore112[] = $row['score'];	
						}
$agrsc112 = current($agrscore112);						
?>
<td><?php echo $agrsc112;  ?></td>
<td><?php if($agrsc112 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 10 DATA THIRD TERM FOR AGRIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NOT APPLICABLE';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$agrscore113[] = $row['score'];	
						}
$agrsc113 = current($agrscore113);						
?>
<td><?php echo $agrsc113;  ?></td>
<td><?php if($agrsc113 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>




<?php
// YEAR 12 DATA FIRST TERM FOR FRENCH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$agrscore121[] = $row['score'];	
						}
$agrsc121 = current($agrscore121);						
?>
<td><?php echo $agrsc121;  ?></td>
<td><?php if($agrsc121 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>


<?php
// YEAR 12 DATA SECOND TERM FOR AGRIC
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$agrscore122[] = $row['score'];	
						}
$agrsc122 = current($agrscore122);						
?>
<td><?php echo $agrsc122;  ?></td>
<td><?php if($agrsc122 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 12 DATA THIRD TERM FOR FRENCH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Agricultural Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else if($y == 'NOT APPLICABLE'){$grade = "NA";}
								else {$grade = "NA";}
						$agrscore123[] = $row['score'];	
						}
$agrsc123 = current($agrscore123);				
?>
<td><?php echo $agrsc123;  ?></td>
<td><?php if($agrsc123 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>
</tr>



<tr style="height: 13px;">
<td>BASIC SCIENCE</td>
<?php
//YEAR 7 DATA FIRST TERM FOR BASIC SCIENCE
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='Basic Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$basscore71[] = $row['score'];						
						}
$bassc71 = current($basscore71);					
?>
<td><?php echo $bassc71;  ?></td>
<td><?php if($bassc71 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>

<?php
//YEAR 7 DATA SECOND TERM FOR BASIC SCIENCE
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
	$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}	
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='Basic Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$basscore72[] = $row['score'];	
						}
$bassc72 = current($basscore72);						
?>
<td><?php echo $bassc72;  ?></td>
<td><?php if($bassc72 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>


<?php
//YEAR 7 DATA THIRD TERM FOR BASIC SCIENCE
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
if($class_name == 'Year 12'){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NOT APPLICABLE';
		}	
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='Basic Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$basscore73[] = $row['score'];	
						}
$bassc73 = current($basscore73);						
?>
<td><?php echo $bassc73;  ?></td>
<td><?php if($bassc73 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 8 DATA FIRST TERM FOR BASIC SCIENCE
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Basic Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$basscore81[] = $row['score'];	
						}
$bassc81 = current($basscore81);						
?>
<td><?php echo $bassc81;  ?></td>
<td><?php if($bassc81 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>


<?php
// YEAR 8 DATA SECOND TERM FOR BASIC SCIENCE
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Basic Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$basscore82[] = $row['score'];	
						}
$bassc82 = current($basscore82);						
?>
<td><?php echo $bassc82;  ?></td>
<td><?php if($bassc82 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 8 DATA THIRD TERM FOR BASIC SCIENCE
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Basic Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$basscore83[] = $row['score'];	
						}
$bassc83 = current($basscore83);						
?>
<td><?php echo $bassc83;  ?></td>
<td><?php if($bassc83 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>


<?php
// YEAR 9 DATA FIRST TERM FOR BASIC SCIENCE
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Basic Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$basscore91[] = $row['score'];	
						}
$bassc91 = current($basscore91);						
?>
<td><?php echo $bassc91;  ?></td>
<td><?php if($bassc91 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>


<?php
// YEAR 9 DATA SECOND TERM FOR BASIC SCIENCE
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Basic Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$basscore92[] = $row['score'];	
						}
$bassc92 = current($basscore92);						
?>
<td><?php echo $bassc92;  ?></td>
<td><?php if($bassc92 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 9 DATA THIRD TERM FOR BASIC SCIENCE
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Basic Science'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$basscore93[] = $row['score'];	
						}
$bassc93 = current($basscore93);						
?>
<td><?php echo $bassc93;  ?></td>
<td><?php if($bassc93 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
</tr>


<tr style="height: 13px;">
<td>BIOLOGY</td>
<?php
//YEAR 7 DATA FIRST TERM FOR MATHEMATICS
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='Biology'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$bioscore71[] = $row['score'];						
						}
$biosc71 = current($bioscore71);					
?>
<td><?php echo $biosc71;  ?></td>
<td><?php if($biosc71 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>

<?php
//YEAR 7 DATA SECOND TERM FOR BIOLOGY
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
	$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}	
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='Biology'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$bioscore72[] = $row['score'];	
						}
$biosc72 = current($bioscore72);						
?>
<td><?php echo $biosc72;  ?></td>
<td><?php if($biosc72 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>


<?php
//YEAR 7 DATA THIRD TERM FOR BIOLOGY
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
if($class_name == 'Year 12'){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NOT APPLICABLE';
		}	
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='Biology'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$bioscore73[] = $row['score'];	
						}
$biosc73 = current($bioscore73);						
?>
<td><?php echo $biosc73;  ?></td>
<td><?php if($biosc73 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 8 DATA FIRST TERM FOR BIOLOGY
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Biology'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$bioscore81[] = $row['score'];	
						}
$biosc81 = current($bioscore81);						
?>
<td><?php echo $biosc81;  ?></td>
<td><?php if($biosc81 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>


<?php
// YEAR 8 DATA SECOND TERM FOR BIOLOGY
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Biology'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$bioscore82[] = $row['score'];	
						}
$biosc82 = current($bioscore82);						
?>
<td><?php echo $biosc82;  ?></td>
<td><?php if($biosc82 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 8 DATA THIRD TERM FOR BIOLOGY
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Biology'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$bioscore83[] = $row['score'];	
						}
$biosc83 = current($bioscore83);						
?>
<td><?php echo $biosc83;  ?></td>
<td><?php if($biosc83 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>

<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>

<?php
// YEAR 10 DATA FIRST TERM FOR BIOLOGY
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Biology'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$bioscore101[] = $row['score'];	
						}
$biosc101 = current($bioscore101);						
?>
<td><?php echo $biosc101;  ?></td>
<td><?php if($biosc101 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>


<?php
// YEAR 10 DATA SECOND TERM FOR BIOLOGY
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Biology'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$bioscore102[] = $row['score'];	
						}
$biosc102 = current($bioscore102);						
?>
<td><?php echo $biosc102;  ?></td>
<td><?php if($biosc102 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 10 DATA THIRD TERM FOR BIOLOGY
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Biology'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$bioscore103[] = $row['score'];	
						}
$biosc103 = current($bioscore103);						
?>
<td><?php echo $biosc103;  ?></td>
<td><?php if($biosc103 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>





<?php
// YEAR 11 DATA FIRST TERM FOR BIOLOGY
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Biology'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$bioscore111[] = $row['score'];	
						}
$biosc111 = current($bioscore111);						
?>
<td><?php echo $biosc111;  ?></td>
<td><?php if($biosc111 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>


<?php
// YEAR 11 DATA SECOND TERM FOR BIOLOGY
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Biology'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$bioscore112[] = $row['score'];	
						}
$biosc112 = current($bioscore112);						
?>
<td><?php echo $biosc112;  ?></td>
<td><?php if($biosc112 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 11 DATA THIRD TERM FOR BIOLOGY
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NOT APPLICABLE';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Biology'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$bioscore113[] = $row['score'];	
						}
$biosc113 = current($bioscore113);						
?>
<td><?php echo $biosc113;  ?></td>
<td><?php if($biosc113 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>




<?php
// YEAR 12 DATA FIRST TERM FOR BIOLOGY
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Biology'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$bioscore121[] = $row['score'];	
						}
$biosc121 = current($bioscore121);						
?>
<td><?php echo $biosc121;  ?></td>
<td><?php if($biosc121 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>


<?php
// YEAR 12 DATA SECOND TERM FOR BIOLOGY
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Biology'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}
						$bioscore122[] = $row['score'];	
						}
$biosc122 = current($bioscore122);						
?>
<td><?php echo $biosc122;  ?></td>
<td><?php if($biosc122 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>



<?php
// YEAR 12 DATA THIRD TERM FOR BIOLOGY
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Biology'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else if($y == 'NOT APPLICABLE'){$grade = "NA";}
								else {$grade = "NA";}
						$bioscore123[] = $row['score'];	
						}
$biosc123 = current($bioscore123);				
?>
<td><?php echo $biosc123;  ?></td>
<td><?php if($biosc123 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>
</tr>



<tr style="height: 13px;">
<td>BIZ. STUDIES</td>
<?php
//YEAR 7 DATA FIRST TERM FOR BIZ STUDIES
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='Business Studies'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$busscore71[] = $row['score'];	
						}
$bussc71 = current($busscore71);					
?>
<td><?php echo $bussc71;  ?></td>
<td><?php if($bussc71 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>
<?php
//YEAR 7 DATA SECOND TERM FOR BIZ
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='Business Studies'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$busscore72[] = $row['score'];	
						}
$bussc72 = current($busscore72);					
?>
<td><?php echo $bussc72;  ?></td>
<td><?php if($bussc72 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>
<?php
//YEAR 7 DATA THIRD TERM FOR BIZ
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='Business Studies'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$busscore73[] = $row['score'];	
						}
$bussc73 = current($busscore73);					
?>
<td><?php echo $bussc73;  ?></td>
<td><?php if($bussc73 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>
<?php
// YEAR 8 DATA FIRST TERM FOR BIZ
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Business Studies'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$busscore81[] = $row['score'];	
						}
$bussc81 = current($busscore81);						
?>
<td><?php echo $bussc81;  ?></td>
<td><?php if($bussc81 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>
<?php
// YEAR 8 DATA SECOND TERM FOR BIZ
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Business Studies'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$busscore82[] = $row['score'];	
						}
$bussc82 = current($busscore82);						
?>
<td><?php echo $bussc82;  ?></td>
<td><?php if($bussc82 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>
<?php
// YEAR 8 DATA THIRD TERM FOR BIZ
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
	include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Business Studies'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$busscore83[] = $row['score'];	
						}
$bussc83 = current($busscore83);						
?>
<td><?php echo $bussc83;  ?></td>
<td><?php if($bussc83 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>
<?php
// YEAR 9 DATA FIRST TERM FOR BIZ
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Business Studies'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$busscore91[] = $row['score'];	
						}
$bussc91 = current($busscore91);						
?>
<td><?php echo $bussc91;  ?></td>
<td><?php if($bussc91 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>
<?php
// YEAR 9 DATA SECOND TERM FOR BIZ
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Business Studies'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$busscore92[] = $row['score'];	
						}
$bussc92 = current($busscore92);						
?>
<td><?php echo $bussc92;  ?></td>
<td><?php if($bussc92 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>
<?php
// YEAR 9 DATA THIRD TERM FOR BIZ
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Business Studies'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$busscore93[] = $row['score'];	
						}
$bussc93 = current($busscore93);						
?>
<td><?php echo $bussc93;  ?></td>
<td><?php if($bussc93 != ""){echo $grade;}else{echo "-";} ?></td>
<?php } ?>

<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
</tr>


<tr style="height: 13px;">
<td>CATERING</td>
<?php
include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
//YEAR 7 DATA FOR CATERING
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$fcatscore71[] = $row['score'];						
						}
$ffcatscore71 = current($fcatscore71);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$scatscore71[] = $row['score'];						
						}
$sscatscore71 = current($scatscore71);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$grade = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$grade = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$grade = "P";}
								else if(($row["score"] <= 49)){$grade = "F";}
								else {$grade = "NA";}
						$tcatscore71[] = $row['score'];						
}
$ttcatscore71 = current($tcatscore71);
}
// YEAR 8 DATA FOR CATERING
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecat81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecat81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecat81 = "P";}
								else if(($row["score"] <= 49)){$gradecat81 = "F";}
								else {$gradecat81 = "NA";}
						$fcatscore81[] = $row['score'];						
						}
$ffcatscore81 = current($fcatscore81);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecat82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecat82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecat82 = "P";}
								else if(($row["score"] <= 49)){$gradecat82 = "F";}
								else {$gradecat82 = "NA";}
						$scatscore81[] = $row['score'];						
						}
$sscatscore81 = current($scatscore81);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecat83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecat83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecat83 = "P";}
								else if(($row["score"] <= 49)){$gradecat83 = "F";}
								else {$gradecat83 = "NA";}
						$tcatscore81[] = $row['score'];						
}
$ttcatscore81 = current($tcatscore81);				
}

// YEAR 9 DATA FOR CATERING
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecat91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecat91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecat91 = "P";}
								else if(($row["score"] <= 49)){$gradecat91 = "F";}
								else {$gradecat91 = "NA";}
						$fcatscore91[] = $row['score'];						
						}
$ffcatscore91 = current($fcatscore91);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecat92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecat92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecat92 = "P";}
								else if(($row["score"] <= 49)){$gradecat92 = "F";}
								else {$gradecat92 = "NA";}
						$scatscore91[] = $row['score'];						
						}
$sscatscore91 = current($scatscore91);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecat93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecat93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecat93 = "P";}
								else if(($row["score"] <= 49)){$gradecat93 = "F";}
								else {$gradecat93 = "NA";}
						$tcatscore91[] = $row['score'];						
}
$ttcatscore91 = current($tcatscore91);				
}	

// YEAR 10 DATA FOR CATERING
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradecat101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecat101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecat101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecat101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecat101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecat101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecat101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecat101 = "E8";}
								else if(($row["score"] <= 39)){$gradecat101 = "F9";}
								else {$gradecat101 = "NA";}
						$fcatscore101[] = $row['score'];						
						}
$ffcatscore101 = current($fcatscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecat102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecat102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecat102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecat102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecat102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecat102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecat102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecat102 = "E8";}
								else if(($row["score"] <= 39)){$gradecat102 = "F9";}
								else {$gradecat102 = "NA";}
						$scatscore101[] = $row['score'];						
						}
$sscatscore101 = current($scatscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecat103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecat103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecat103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecat103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecat103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecat103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecat103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecat103 = "E8";}
								else if(($row["score"] <= 39)){$gradecat103 = "F9";}
								else {$gradecat103 = "NA";}
						$tcatscore101[] = $row['score'];						
}
$ttcatscore101 = current($tcatscore101);				
}

// YEAR 11 DATA FOR CATERING
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradecat111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecat111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecat111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecat111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecat111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecat111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecat111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecat111 = "E8";}
								else if(($row["score"] <= 39)){$gradecat111 = "F9";}
								else {$gradecat111 = "NA";}
						$fcatscore111[] = $row['score'];						
						}
$ffcatscore111 = current($fcatscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecat112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecat112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecat112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecat112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecat112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecat112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecat112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecat112 = "E8";}
								else if(($row["score"] <= 39)){$gradecat112 = "F9";}
								else {$gradecat112 = "NA";}
						$scatscore111[] = $row['score'];						
						}
$sscatscore111 = current($scatscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecat113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecat113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecat113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecat113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecat113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecat113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecat113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecat113 = "E8";}
								else if(($row["score"] <= 39)){$gradecat113 = "F9";}
								else {$gradecat113 = "NA";}
						$tcatscore111[] = $row['score'];						
}
$ttcatscore111 = current($tcatscore111);				
}

// YEAR 12 DATA FOR CATERING
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradecat121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecat121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecat121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecat121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecat121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecat121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecat121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecat121 = "E8";}
								else if(($row["score"] <= 39)){$gradecat121 = "F9";}
								else {$gradecat121 = "NA";}
						$fcatscore121[] = $row['score'];						
						}
$ffcatscore121 = current($fcatscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecat122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecat122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecat122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecat122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecat122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecat122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecat122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecat122 = "E8";}
								else if(($row["score"] <= 39)){$gradecat122 = "F9";}
								else {$gradecat122 = "NA";}
						$scatscore121[] = $row['score'];						
						}
$sscatscore121 = current($scatscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Catering'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecat123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecat123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecat123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecat123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecat123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecat123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecat123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecat123 = "E8";}
								else if(($row["score"] <= 39)){$gradecat123 = "F9";}
								else {$gradecat123 = "NA";}
						$tcatscore121[] = $row['score'];						
}
$ttcatscore121 = current($tcatscore121);				
}					
?>
<td><?php echo $ffcatscore71;  ?></td>
<td><?php if($ffcatscore71 != ""){echo $grade;}else{echo "-";} ?></td>
<td><?php echo $sscatscore71;  ?></td>
<td><?php if($sscatscore71 != ""){echo $grade;}else{echo "-";} ?></td>
<td><?php echo $ttcatscore71;  ?></td>
<td><?php if($ttcatscore71 != ""){echo $grade;}else{echo "-";} ?></td>
<td><?php echo $ffcatscore81;  ?></td>
<td><?php if($ffcatscore81 != ""){echo $gradecat81;}else{echo "-";} ?></td>
<td><?php echo $sscatscore81;  ?></td>
<td><?php if($sscatscore81 != ""){echo $gradecat82;}else{echo "-";} ?></td>
<td><?php echo $ttcatscore81;  ?></td>
<td><?php if($ttcatscore81 != ""){echo $gradecat83;}else{echo "-";} ?></td>
<td><?php echo $ffcatscore91;  ?></td>
<td><?php if($ffcatscore91 != ""){echo $gradecat91;}else{echo "-";} ?></td>
<td><?php echo $sscatscore91;  ?></td>
<td><?php if($sscatscore91 != ""){echo $gradecat92;}else{echo "-";} ?></td>
<td><?php echo $ttcatscore91;  ?></td>
<td><?php if($ttcatscore91 != ""){echo $gradecat93;}else{echo "-";} ?></td>
<td><?php echo $ffcatscore101;  ?></td>
<td><?php if($ffcatscore101 != ""){echo $gradecat101;}else{echo "-";} ?></td>
<td><?php echo $sscatscore101;  ?></td>
<td><?php if($sscatscore101 != ""){echo $gradecat102;}else{echo "-";} ?></td>
<td><?php echo $ttcatscore101;  ?></td>
<td><?php if($ttcatscore101 != ""){echo $gradecat103;}else{echo "-";} ?></td>
<td><?php echo $ffcatscore111;  ?></td>
<td><?php if($ffcatscore111 != ""){echo $gradecat111;}else{echo "-";} ?></td>
<td><?php echo $sscatscore111;  ?></td>
<td><?php if($sscatscore111 != ""){echo $gradecat112;}else{echo "-";} ?></td>
<td><?php echo $ttcatscore111;  ?></td>
<td><?php if($ttcatscore111 != ""){echo $gradecat113;}else{echo "-";} ?></td>
<td><?php echo $ffcatscore121;  ?></td>
<td><?php if($ffcatscore121 != ""){echo $gradecat121;}else{echo "-";} ?></td>
<td><?php echo $sscatscore121;  ?></td>
<td><?php if($sscatscore121 != ""){echo $gradecat122;}else{echo "-";} ?></td>
<td><?php echo $ttcatscore121;  ?></td>
<td><?php if($ttcatscore121 != ""){echo $gradecat123;}else{echo "-";} ?></td>
</tr>







<tr style="height: 13px;">
<td>CHEMISTRY</td>
<?php
include "connection.php";
// YEAR 10 DATA FOR CHEM
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Chemistry'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeche101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeche101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeche101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeche101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeche101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeche101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeche101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeche101 = "E8";}
								else if(($row["score"] <= 39)){$gradeche101 = "F9";}
								else {$gradeche101 = "NA";}
						$fchescore101[] = $row['score'];						
						}
$ffchescore101 = current($fchescore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Chemistry'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$gradeche102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeche102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeche102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeche102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeche102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeche102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeche102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeche102 = "E8";}
								else if(($row["score"] <= 39)){$gradeche101 = "F9";}
								else {$gradeche102 = "NA";}
						$schescore101[] = $row['score'];						
						}
$sschescore101 = current($schescore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Chemistry'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeche103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeche103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeche103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeche103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeche103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeche103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeche103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeche103 = "E8";}
								else if(($row["score"] <= 39)){$gradeche103 = "F9";}
								else {$gradeche103 = "NA";}
						$tchescore101[] = $row['score'];						
}
$ttchescore101 = current($tchescore101);				
}

// YEAR 11 DATA FOR CHEMISTRY
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Chemistry'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeche111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeche111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeche111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeche111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeche111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeche111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeche111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeche111 = "E8";}
								else if(($row["score"] <= 39)){$gradeche111 = "F9";}
								else {$gradeche111 = "NA";}
						$fchescore111[] = $row['score'];						
						}
$ffchescore111 = current($fchescore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Chemistry'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeche112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeche112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeche112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeche112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeche112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeche112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeche112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeche112 = "E8";}
								else if(($row["score"] <= 39)){$gradeche112 = "F9";}
								else {$gradeche112 = "NA";}
						$schescore111[] = $row['score'];						
						}
$sschescore111 = current($schescore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Chemistry'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeche113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeche113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeche113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeche113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeche113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeche113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeche113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeche113 = "E8";}
								else if(($row["score"] <= 39)){$gradeche113 = "F9";}
								else {$gradeche113 = "NA";}
						$tchescore111[] = $row['score'];						
}
$ttchescore111 = current($tchescore111);				
}

// YEAR 12 DATA FOR CHEMISTRY
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Chemistry'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradecat121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeche121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeche121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeche121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeche121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeche121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeche121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeche121 = "E8";}
								else if(($row["score"] <= 39)){$gradeche121 = "F9";}
								else {$gradeche121 = "NA";}
						$fchescore121[] = $row['score'];						
						}
$ffchescore121 = current($fchescore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Chemistry'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeche122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeche122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeche122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeche122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeche122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeche122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeche122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeche122 = "E8";}
								else if(($row["score"] <= 39)){$gradeche122 = "F9";}
								else {$gradeche122 = "NA";}
						$schescore121[] = $row['score'];						
						}
$sschescore121 = current($schescore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Chemistry'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeche123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeche123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeche123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeche123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeche123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeche123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeche123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeche123 = "E8";}
								else if(($row["score"] <= 39)){$gradeche123 = "F9";}
								else {$gradeche123 = "NA";}
						$tchescore121[] = $row['score'];						
}
$ttchescore121 = current($tchescore121);				
}					
?>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td><?php echo $ffchescore101;  ?></td>
<td><?php if($ffchescore101 != ""){echo $gradeche101;}else{echo "-";} ?></td>
<td><?php echo $sschescore101;  ?></td>
<td><?php if($sschescore101 != ""){echo $gradeche102;}else{echo "-";} ?></td>
<td><?php echo $ttchescore101;  ?></td>
<td><?php if($ttchescore101 != ""){echo $gradeche103;}else{echo "-";} ?></td>
<td><?php echo $ffchescore111;  ?></td>
<td><?php if($ffchescore111 != ""){echo $gradeche111;}else{echo "-";} ?></td>
<td><?php echo $sschescore111;  ?></td>
<td><?php if($sschescore111 != ""){echo $gradeche112;}else{echo "-";} ?></td>
<td><?php echo $ttchescore111;  ?></td>
<td><?php if($ttchescore111 != ""){echo $gradeche113;}else{echo "-";} ?></td>
<td><?php echo $ffchescore121;  ?></td>
<td><?php if($ffchescore121 != ""){echo $gradeche121;}else{echo "-";} ?></td>
<td><?php echo $sschescore121;  ?></td>
<td><?php if($sschescore121 != ""){echo $gradeche122;}else{echo "-";} ?></td>
<td><?php echo $ttchescore121;  ?></td>
<td><?php if($ttchescore121 != ""){echo $gradeche123;}else{echo "-";} ?></td>
</tr>



<tr style="height: 13px;">
<td>CIVIC EDU</td>
<?php
include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
//YEAR 7 DATA FOR CIVIC EDU
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeciv71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeciv71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeciv71 = "P";}
								else if(($row["score"] <= 49)){$gradeciv71 = "F";}
								else {$gradeciv71 = "NA";}
						$fcivscore71[] = $row['score'];						
						}
$ffcivscore71 = current($fcivscore71);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeciv72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeciv72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeciv72 = "P";}
								else if(($row["score"] <= 49)){$gradeciv72 = "F";}
								else {$gradeciv72 = "NA";}
						$scivscore72[] = $row['score'];						
						}
$sscivscore72 = current($scivscore72);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeciv73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeciv73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeciv73 = "P";}
								else if(($row["score"] <= 49)){$gradeciv73 = "F";}
								else {$gradeciv73 = "NA";}
						$tcivscore73[] = $row['score'];						
}
$ttcivscore73 = current($tcivscore73);
}
// YEAR 8 DATA FOR CIVIC EDU
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeciv81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeciv81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeciv81 = "P";}
								else if(($row["score"] <= 49)){$gradeciv81 = "F";}
								else {$gradeciv81 = "NA";}
						$fcivscore81[] = $row['score'];						
						}
$ffcivscore81 = current($fcivscore81);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeciv82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeciv82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeciv82 = "P";}
								else if(($row["score"] <= 49)){$gradeciv82 = "F";}
								else {$gradeciv82 = "NA";}
						$scivscore82[] = $row['score'];						
						}
$sscivscore82 = current($scivscore82);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeciv83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeciv83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeciv83 = "P";}
								else if(($row["score"] <= 49)){$gradeciv83 = "F";}
								else {$gradeciv83 = "NA";}
						$tcivscore83[] = $row['score'];						
}
$ttcivscore83 = current($tcivscore83);				
}

// YEAR 9 DATA FOR CIVIC EDU
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeciv91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeciv91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeciv91 = "P";}
								else if(($row["score"] <= 49)){$gradeciv91 = "F";}
								else {$gradeciv91 = "NA";}
						$fcivscore91[] = $row['score'];						
						}
$ffcivscore91 = current($fcivscore91);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeciv92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeciv92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeciv92 = "P";}
								else if(($row["score"] <= 49)){$gradeciv92 = "F";}
								else {$gradeciv92 = "NA";}
						$scivscore92[] = $row['score'];						
						}
$sscivscore92 = current($scivscore92);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeciv93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeciv93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeciv93 = "P";}
								else if(($row["score"] <= 49)){$gradeciv93 = "F";}
								else {$gradeciv93 = "NA";}
						$tcivscore93[] = $row['score'];						
}
$ttcivscore93 = current($tcivscore93);				
}	

// YEAR 10 DATA FOR CIVIC EDU
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeciv101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeciv101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeciv101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeciv101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeciv101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeciv101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeciv101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeciv101 = "E8";}
								else if(($row["score"] <= 39)){$gradeciv101 = "F9";}
								else {$gradeciv101 = "NA";}
						$fcivscore101[] = $row['score'];						
						}
$ffcivscore101 = current($fcivscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeciv102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeciv102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeciv102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeciv102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeciv102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeciv102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeciv102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeciv102 = "E8";}
								else if(($row["score"] <= 39)){$gradecat102 = "F9";}
								else {$gradeciv102 = "NA";}
						$scivscore102[] = $row['score'];						
						}
$sscivscore102 = current($scivscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeciv103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeciv103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeciv103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeciv103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeciv103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeciv103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeciv103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeciv103 = "E8";}
								else if(($row["score"] <= 39)){$gradecat102 = "F9";}
								else {$gradeciv103 = "NA";}
						$tcivscore103[] = $row['score'];						
}
$ttcivscore103 = current($tcivscore103);				
}

// YEAR 11 DATA FOR CIVIC EDU
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeciv111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeciv111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeciv111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeciv111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeciv111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeciv111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeciv111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeciv111 = "E8";}
								else if(($row["score"] <= 39)){$gradeciv111 = "F9";}
								else {$gradeciv111 = "NA";}
						$fcivscore111[] = $row['score'];						
						}
$ffcivscore111 = current($fcivscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$gradecat112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeciv112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeciv112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeciv112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeciv112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeciv112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeciv112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeciv112 = "E8";}
								else if(($row["score"] <= 39)){$gradeciv112 = "F9";}
								else {$gradeciv112 = "NA";}
						$scivscore112[] = $row['score'];						
						}
$sscivscore112 = current($scivscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$gradecat111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeciv113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeciv113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeciv113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeciv113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeciv113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeciv113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeciv113 = "E8";}
								else if(($row["score"] <= 39)){$gradeciv113 = "F9";}
								else {$gradeciv113 = "NA";}
						$tcivscore113[] = $row['score'];						
}
$ttcivscore113 = current($tcivscore113);				
}

// YEAR 12 DATA FOR CIVIC EDU
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeciv121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeciv121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeciv121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeciv121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeciv121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeciv121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeciv121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeciv121 = "E8";}
								else if(($row["score"] <= 39)){$gradeciv121 = "F9";}
								else {$gradeciv121 = "NA";}
						$fcivscore121[] = $row['score'];						
						}
$ffcivscore121 = current($fcivscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecat122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeciv122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeciv122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeciv122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeciv122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeciv122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeciv122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeciv122 = "E8";}
								else if(($row["score"] <= 39)){$gradeciv122 = "F9";}
								else {$gradeciv122 = "NA";}
						$scivscore122[] = $row['score'];						
						}
$sscivscore122 = current($scivscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Civic Education'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecat123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeciv123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeciv123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeciv123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeciv123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeciv123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeciv123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeciv123 = "E8";}
								else if(($row["score"] <= 39)){$gradeciv123 = "F9";}
								else {$gradeciv123 = "NA";}
						$tcivscore123[] = $row['score'];						
}
$ttcivscore123 = current($tcivscore123);				
}					
?>
<td><?php echo $ffcivscore71;  ?></td>
<td><?php if($ffcivscore71 != ""){echo $gradeciv71;}else{echo "-";} ?></td>
<td><?php echo $sscivscore72;  ?></td>
<td><?php if($sscivscore72 != ""){echo $gradeciv72;}else{echo "-";} ?></td>
<td><?php echo $ttcivscore73;  ?></td>
<td><?php if($ttcivscore73 != ""){echo $gradeciv73;}else{echo "-";} ?></td>
<td><?php echo $ffcivscore81;  ?></td>
<td><?php if($ffcivscore81 != ""){echo $gradeciv81;}else{echo "-";} ?></td>
<td><?php echo $sscivscore82;  ?></td>
<td><?php if($sscivscore82 != ""){echo $gradeciv82;}else{echo "-";} ?></td>
<td><?php echo $ttcivscore83;  ?></td>
<td><?php if($ttcivscore83 != ""){echo $gradeciv83;}else{echo "-";} ?></td>
<td><?php echo $ffcivscore91;  ?></td>
<td><?php if($ffcivscore91 != ""){echo $gradeciv91;}else{echo "-";} ?></td>
<td><?php echo $sscivscore92;  ?></td>
<td><?php if($sscivscore92 != ""){echo $gradeciv92;}else{echo "-";} ?></td>
<td><?php echo $ttcivscore93;  ?></td>
<td><?php if($ttcivscore93 != ""){echo $gradeciv93;}else{echo "-";} ?></td>
<td><?php echo $ffcivscore101;  ?></td>
<td><?php if($ffcivscore101 != ""){echo $gradeciv101;}else{echo "-";} ?></td>
<td><?php echo $sscivscore102;  ?></td>
<td><?php if($sscivscore102 != ""){echo $gradeciv102;}else{echo "-";} ?></td>
<td><?php echo $ttcivscore103;  ?></td>
<td><?php if($ttcivscore103 != ""){echo $gradeciv103;}else{echo "-";} ?></td>
<td><?php echo $ffcivscore111;  ?></td>
<td><?php if($ffcivscore111 != ""){echo $gradeciv111;}else{echo "-";} ?></td>
<td><?php echo $sscivscore112;  ?></td>
<td><?php if($sscivscore112 != ""){echo $gradeciv112;}else{echo "-";} ?></td>
<td><?php echo $ttcivscore113;  ?></td>
<td><?php if($ttcivscore113 != ""){echo $gradeciv113;}else{echo "-";} ?></td>
<td><?php echo $ffcivscore121;  ?></td>
<td><?php if($ffcivscore121 != ""){echo $gradeciv121;}else{echo "-";} ?></td>
<td><?php echo $sscivscore122;  ?></td>
<td><?php if($sscivscore122 != ""){echo $gradeciv122;}else{echo "-";} ?></td>
<td><?php echo $ttcivscore123;  ?></td>
<td><?php if($ttcivscore123 != ""){echo $gradeciv123;}else{echo "-";} ?></td>
</tr>





<tr style="height: 13px;">
<td>CRK</td>
<?php
include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
//YEAR 7 DATA FOR CRK
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecrk71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecrk71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecrk71 = "P";}
								else if(($row["score"] <= 49)){$gradecrk71 = "F";}
								else {$gradecrk71 = "NA";}
						$fcrkscore71[] = $row['score'];						
						}
$ffcrkscore71 = current($fcrkscore71);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecrk72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecrk72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecrk72 = "P";}
								else if(($row["score"] <= 49)){$gradecrk72 = "F";}
								else {$gradecrk72 = "NA";}
						$scrkscore72[] = $row['score'];						
						}
$sscrkscore72 = current($scrkscore72);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecrk73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecrk73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecrk73 = "P";}
								else if(($row["score"] <= 49)){$gradecrk73 = "F";}
								else {$gradecrk73 = "NA";}
						$tcrkscore73[] = $row['score'];						
}
$ttcrkscore73 = current($tcrkscore73);
}
// YEAR 8 DATA FOR CRK
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecrk81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecrk81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecrk81 = "P";}
								else if(($row["score"] <= 49)){$gradecrk81 = "F";}
								else {$gradecrk81 = "NA";}
						$fcrkscore81[] = $row['score'];						
						}
$ffcrkscore81 = current($fcrkscore81);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecrk82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecrk82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecrk82 = "P";}
								else if(($row["score"] <= 49)){$gradecrk82 = "F";}
								else {$gradecrk82 = "NA";}
						$scrkscore82[] = $row['score'];						
						}
$sscrkscore82 = current($scrkscore82);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecrk83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecrk83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecrk83 = "P";}
								else if(($row["score"] <= 49)){$gradecrk83 = "F";}
								else {$gradecrk83 = "NA";}
						$tcrkscore83[] = $row['score'];						
}
$ttcrkscore83 = current($tcrkscore83);				
}

// YEAR 9 DATA FOR CRK
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecrk91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecrk91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecrk91 = "P";}
								else if(($row["score"] <= 49)){$gradecrk91 = "F";}
								else {$gradecrk91 = "NA";}
						$fcrkscore91[] = $row['score'];						
						}
$ffcrkscore91 = current($fcrkscore91);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecrk92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecrk92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecrk92 = "P";}
								else if(($row["score"] <= 49)){$gradecrk92 = "F";}
								else {$gradecrk92 = "NA";}
						$scrkscore92[] = $row['score'];						
						}
$sscrkscore92 = current($scrkscore92);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradecrk93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradecrk93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradecrk93 = "P";}
								else if(($row["score"] <= 49)){$gradecrk93 = "F";}
								else {$gradecrk93 = "NA";}
						$tcrkscore93[] = $row['score'];						
}
$ttcrkscore93 = current($tcrkscore93);				
}	

// YEAR 10 DATA FOR CRK
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradecrk101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecrk101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecrk101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecrk101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecrk101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecrk101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecrk101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecrk101 = "E8";}
								else if(($row["score"] <= 39)){$gradecrk101 = "F9";}
								else {$gradecrk101 = "NA";}
						$fcrkscore101[] = $row['score'];						
						}
$ffcrkscore101 = current($fcrkscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecrk102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecrk102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecrk102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecrk102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecrk102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecrk102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecrk102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecrk102 = "E8";}
								else if(($row["score"] <= 39)){$gradecrk102 = "F9";}
								else {$gradecrk102 = "NA";}
						$scrkscore102[] = $row['score'];						
						}
$sscrkscore102 = current($scrkscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecrk103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecrk103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecrk103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecrk103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecrk103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecrk103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecrk103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecrk103 = "E8";}
								else if(($row["score"] <= 39)){$gradecrk103 = "F9";}
								else {$gradecrk103 = "NA";}
						$tcrkscore103[] = $row['score'];						
}
$ttcrkscore103 = current($tcrkscore103);				
}

// YEAR 11 DATA FOR CRK
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradecrk111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecrk111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecrk111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecrk111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecrk111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecrk111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecrk111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecrk111 = "E8";}
								else if(($row["score"] <= 39)){$gradecrk111 = "F9";}
								else {$gradecrk111 = "NA";}
						$fcrkscore111[] = $row['score'];						
						}
$ffcrkscore111 = current($fcrkscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecrk112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecrk112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecrk112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecrk112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecrk112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecrk112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecrk112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecrk112 = "E8";}
								else if(($row["score"] <= 39)){$gradecrk112 = "F9";}
								else {$gradecrk112 = "NA";}
						$scrkscore112[] = $row['score'];						
						}
$sscrkscore112 = current($scrkscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$gradecrk113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecrk113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecrk113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecrk113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecrk113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecrk113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecrk113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecrk113 = "E8";}
								else if(($row["score"] <= 39)){$gradecrk113 = "F9";}
								else {$gradecrk113 = "NA";}
						$tcrkscore113[] = $row['score'];						
}
$ttcrkscore113 = current($tcrkscore113);				
}

// YEAR 12 DATA FOR CRK
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradecrk121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecrk121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecrk121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecrk121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecrk121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecrk121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecrk121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecrk121 = "E8";}
								else if(($row["score"] <= 39)){$gradecrk121 = "F9";}
								else {$gradecrk121 = "NA";}
						$fcrkscore121[] = $row['score'];						
						}
$ffcrkscore121 = current($fcrkscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecrk122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecrk122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecrk122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecrk122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecrk122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecrk122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecrk122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecrk122 = "E8";}
								else if(($row["score"] <= 39)){$gradecrk122 = "F9";}
								else {$gradecrk122 = "NA";}
						$scrkscore122[] = $row['score'];						
						}
$sscrkscore122 = current($scrkscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='CRK'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradecrk123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradecrk123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradecrk123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradecrk123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradecrk123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradecrk123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradecrk123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradecrk123 = "E8";}
								else if(($row["score"] <= 39)){$gradecrk123 = "F9";}
								else {$gradecrk123 = "NA";}
						$tcrkscore123[] = $row['score'];						
}
$ttcrkscore123 = current($tcrkscore123);				
}					
?>
<td><?php echo $ffcrkscore71;  ?></td>
<td><?php if($ffcrkscore71 != ""){echo $gradecrk71;}else{echo "-";} ?></td>
<td><?php echo $sscrkscore72;  ?></td>
<td><?php if($sscrkscore72 != ""){echo $gradecrk72;}else{echo "-";} ?></td>
<td><?php echo $ttcrkscore73;  ?></td>
<td><?php if($ttcrkscore73 != ""){echo $gradecrk73;}else{echo "-";} ?></td>
<td><?php echo $ffcrkscore81;  ?></td>
<td><?php if($ffcrkscore81 != ""){echo $gradecrk81;}else{echo "-";} ?></td>
<td><?php echo $sscrkscore82;  ?></td>
<td><?php if($sscrkscore82 != ""){echo $gradecrk82;}else{echo "-";} ?></td>
<td><?php echo $ttcrkscore83;  ?></td>
<td><?php if($ttcrkscore83 != ""){echo $gradecrk83;}else{echo "-";} ?></td>
<td><?php echo $ffcrkscore91;  ?></td>
<td><?php if($ffcrkscore91 != ""){echo $gradecrk91;}else{echo "-";} ?></td>
<td><?php echo $sscrkscore92;  ?></td>
<td><?php if($sscrkscore92 != ""){echo $gradecrk92;}else{echo "-";} ?></td>
<td><?php echo $ttcrkscore93;  ?></td>
<td><?php if($ttcrkscore93 != ""){echo $gradecrk93;}else{echo "-";} ?></td>
<td><?php echo $ffcrkscore101;  ?></td>
<td><?php if($ffcrkscore101 != ""){echo $gradecrk101;}else{echo "-";} ?></td>
<td><?php echo $sscrkscore102;  ?></td>
<td><?php if($sscrkscore102 != ""){echo $gradecrk102;}else{echo "-";} ?></td>
<td><?php echo $ttcrkscore103;  ?></td>
<td><?php if($ttcrkscore103 != ""){echo $gradecrk103;}else{echo "-";} ?></td>
<td><?php echo $ffcrkscore111;  ?></td>
<td><?php if($ffcrkscore111 != ""){echo $gradecrk111;}else{echo "-";} ?></td>
<td><?php echo $sscrkscore112;  ?></td>
<td><?php if($sscrkscore112 != ""){echo $gradecrk112;}else{echo "-";} ?></td>
<td><?php echo $ttcrkscore113;  ?></td>
<td><?php if($ttcrkscore113 != ""){echo $gradecrk113;}else{echo "-";} ?></td>
<td><?php echo $ffcrkscore121;  ?></td>
<td><?php if($ffcrkscore121 != ""){echo $gradecrk121;}else{echo "-";} ?></td>
<td><?php echo $sscrkscore122;  ?></td>
<td><?php if($sscrkscore122 != ""){echo $gradecrk122;}else{echo "-";} ?></td>
<td><?php echo $ttcrkscore123;  ?></td>
<td><?php if($ttcrkscore123 != ""){echo $gradecrk123;}else{echo "-";} ?></td>
</tr>




<tr style="height: 13px;">
<td>ECONOMICS</td>
<?php
include "connection.php";
// YEAR 10 DATA FOR ECONOMICS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Economics'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeeco101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeco101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeco101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeco101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeco101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeco101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeco101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeco101 = "E8";}
								else if(($row["score"] <= 39)){$gradeeco101 = "F9";}
								else {$gradeeco101 = "NA";}
						$fecoscore101[] = $row['score'];						
						}
$ffecoscore101 = current($fecoscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Economics'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$gradeeco102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeco102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeco102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeco102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeco102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeco102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeco102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeco102 = "E8";}
								else if(($row["score"] <= 39)){$gradeeco102 = "F9";}
								else {$gradeeco102 = "NA";}
						$secoscore102[] = $row['score'];						
						}
$ssecoscore102 = current($secoscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Economics'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$gradeeco103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeco103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeco103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeco103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeco103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeco103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeco103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeco103 = "E8";}
								else if(($row["score"] <= 39)){$gradeeco103 = "F9";}
								else {$gradeeco103 = "NA";}
						$tecoscore103[] = $row['score'];						
}
$ttecoscore103 = current($tecoscore103);				
}

// YEAR 11 DATA FOR ECONOMICS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Economics'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeeco111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeco111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeco111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeco111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeco111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeco111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeco111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeco111 = "E8";}
								else if(($row["score"] <= 39)){$gradeeco111 = "F9";}
								else {$gradeeco111 = "NA";}
						$fecoscore111[] = $row['score'];						
						}
$ffecoscore111 = current($fecoscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Economics'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeeco112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeco112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeco112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeco112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeco112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeco112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeco112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeco112 = "E8";}
								else if(($row["score"] <= 39)){$gradeeco112 = "F9";}
								else {$gradeeco112 = "NA";}
						$secoscore112[] = $row['score'];					
						}
$ssecoscore112 = current($secoscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Economics'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$gradeeco113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeco113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeco113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeco113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeco113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeco113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeco113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeco113 = "E8";}
								else if(($row["score"] <= 39)){$gradeeco113 = "F9";}
								else {$gradeeco113 = "NA";}
						$tecoscore113[] = $row['score'];				
}
$ttecoscore113 = current($tecoscore113);				
}

// YEAR 12 DATA FOR ECONOMICS
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Economics'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeeco121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeco121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeco121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeco121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeco121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeco121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeco121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeco121 = "E8";}
								else if(($row["score"] <= 39)){$gradeeco121 = "F9";}
								else {$gradeeco121 = "NA";}
						$fecoscore121[] = $row['score'];						
						}
$ffecoscore121 = current($fecoscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Economics'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeeco122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeco122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeco122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeco122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeco122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeco122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeco122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeco122 = "E8";}
								else if(($row["score"] <= 39)){$gradeeco122 = "F9";}
								else {$gradeeco122 = "NA";}
						$secoscore122[] = $row['score'];						
						}
$ssecoscore122 = current($secoscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Economics'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeeco123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeeco123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeeco123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeeco123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeeco123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeeco123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeeco123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeeco123 = "E8";}
								else if(($row["score"] <= 39)){$gradeeco123 = "F9";}
								else {$gradeeco123 = "NA";}
						$tecoscore123[] = $row['score'];						
						}
$ttecoscore123 = current($tecoscore123);			
}					
?>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td><?php echo $ffecoscore101;  ?></td>
<td><?php if($ffecoscore101 != ""){echo $gradeeco101;}else{echo "-";} ?></td>
<td><?php echo $ssecoscore102;  ?></td>
<td><?php if($ssecoscore102 != ""){echo $gradeeco102;}else{echo "-";} ?></td>
<td><?php echo $ttecoscore103;  ?></td>
<td><?php if($ttecoscore103 != ""){echo $gradeeco103;}else{echo "-";} ?></td>
<td><?php echo $ffecoscore111;  ?></td>
<td><?php if($ffecoscore111 != ""){echo $gradeeco111;}else{echo "-";} ?></td>
<td><?php echo $ssecoscore112;  ?></td>
<td><?php if($ssecoscore112 != ""){echo $gradeeco112;}else{echo "-";} ?></td>
<td><?php echo $ttecoscore113;  ?></td>
<td><?php if($ttecoscore113 != ""){echo $gradeeco113;}else{echo "-";} ?></td>
<td><?php echo $ffecoscore121;  ?></td>
<td><?php if($ffecoscore121 != ""){echo $gradeeco121;}else{echo "-";} ?></td>
<td><?php echo $ssecoscore122;  ?></td>
<td><?php if($ssecoscore122 != ""){echo $gradeeco122;}else{echo "-";} ?></td>
<td><?php echo $ttecoscore123;  ?></td>
<td><?php if($ttecoscore123 != ""){echo $gradeeco123;}else{echo "-";} ?></td>
</tr>






<tr style="height: 13px;">
<td>FOOD & NUT.</td>
<?php
include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
//YEAR 7 DATA FOR FN
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefoo71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefoo71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefoo71 = "P";}
								else if(($row["score"] <= 49)){$gradefoo71 = "F";}
								else {$gradefoo71 = "NA";}
						$ffooscore71[] = $row['score'];						
						}
$fffooscore71 = current($ffooscore71);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefoo72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefoo72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefoo72 = "P";}
								else if(($row["score"] <= 49)){$gradefoo72 = "F";}
								else {$gradefoo72 = "NA";}
						$sfooscore72[] = $row['score'];						
						}
$ssfooscore72 = current($sfooscore72);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefoo73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefoo73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefoo73 = "P";}
								else if(($row["score"] <= 49)){$gradefoo73 = "F";}
								else {$gradefoo73 = "NA";}
						$tfooscore73[] = $row['score'];						
						}
$ttfooscore73 = current($tfooscore73);
}
// YEAR 8 DATA FOR F&N
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefoo81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefoo81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefoo81 = "P";}
								else if(($row["score"] <= 49)){$gradefoo81 = "F";}
								else {$gradefoo81 = "NA";}
						$ffooscore81[] = $row['score'];						
						}
$fffooscore81 = current($ffooscore81);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefoo82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefoo82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefoo82 = "P";}
								else if(($row["score"] <= 49)){$gradefoo82 = "F";}
								else {$gradefoo82 = "NA";}
						$sfooscore82[] = $row['score'];						
						}
$ssfooscore82 = current($sfooscore82);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefoo83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefoo83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefoo83 = "P";}
								else if(($row["score"] <= 49)){$gradefoo83 = "F";}
								else {$gradefoo83 = "NA";}
						$tfooscore83[] = $row['score'];						
						}
$ttfooscore83 = current($tfooscore83);

// YEAR 9 DATA FOR F&N
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefoo91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefoo91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefoo91 = "P";}
								else if(($row["score"] <= 49)){$gradefoo91 = "F";}
								else {$gradefoo91 = "NA";}
						$ffooscore91[] = $row['score'];						
						}
$fffooscore91 = current($ffooscore91);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefoo92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefoo92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefoo92 = "P";}
								else if(($row["score"] <= 49)){$gradefoo92 = "F";}
								else {$gradefoo92 = "NA";}
						$sfooscore92[] = $row['score'];						
						}
$ssfooscore92 = current($sfooscore92);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefoo93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefoo93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefoo93 = "P";}
								else if(($row["score"] <= 49)){$gradefoo93 = "F";}
								else {$gradefoo93 = "NA";}
						$tfooscore93[] = $row['score'];						
						}
$ttfooscore93 = current($tfooscore93);				
}	

// YEAR 10 DATA FOR F&N
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradefoo101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefoo101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefoo101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefoo101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefoo101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefoo101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefoo101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefoo101 = "E8";}
								else if(($row["score"] <= 39)){$gradefoo101 = "F9";}
								else {$gradefoo101 = "NA";}
						$ffooscore101[] = $row['score'];						
						}
$fffooscore101 = current($ffooscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradefoo102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefoo102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefoo102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefoo102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefoo102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefoo102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefoo102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefoo102 = "E8";}
								else if(($row["score"] <= 39)){$gradefoo102 = "F9";}
								else {$gradefoo102 = "NA";}
						$sfooscore102[] = $row['score'];						
						}
$ssfooscore102 = current($sfooscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradefoo103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefoo103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefoo103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefoo103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefoo103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefoo103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefoo103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefoo103 = "E8";}
								else if(($row["score"] <= 39)){$gradefoo103 = "F9";}
								else {$gradefoo103 = "NA";}
						$tfooscore103[] = $row['score'];						
						}
$ttfooscore103 = current($tfooscore103);		
}

// YEAR 11 DATA FOR CRK
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradefoo111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefoo111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefoo111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefoo111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefoo111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefoo111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefoo111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefoo111 = "E8";}
								else if(($row["score"] <= 39)){$gradefoo111 = "F9";}
								else {$gradefoo111 = "NA";}
						$ffooscore111[] = $row['score'];						
						}
$fffooscore111 = current($ffooscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradefoo112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefoo112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefoo112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefoo112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefoo112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefoo112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefoo112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefoo112 = "E8";}
								else if(($row["score"] <= 39)){$gradefoo112 = "F9";}
								else {$gradefoo112 = "NA";}
						$sfooscore112[] = $row['score'];						
						}
$ssfooscore112 = current($sfooscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradefoo113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefoo113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefoo113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefoo113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefoo113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefoo113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefoo113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefoo113 = "E8";}
								else if(($row["score"] <= 39)){$gradefoo113 = "F9";}
								else {$gradefoo113 = "NA";}
						$tfooscore113[] = $row['score'];						
						}
$ttfooscore113 = current($tfooscore113);				
}

// YEAR 12 DATA FOR FN
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradefoo121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefoo121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefoo121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefoo121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefoo121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefoo121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefoo121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefoo121 = "E8";}
								else if(($row["score"] <= 39)){$gradefoo121 = "F9";}
								else {$gradefoo121 = "NA";}
						$ffooscore121[] = $row['score'];						
						}
$fffooscore121 = current($ffooscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradefoo122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefoo122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefoo122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefoo122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefoo122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefoo122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefoo122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefoo122 = "E8";}
								else if(($row["score"] <= 39)){$gradefoo122 = "F9";}
								else {$gradefoo122 = "NA";}
						$sfooscore122[] = $row['score'];						
						}
$ssfooscore122 = current($sfooscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Food and Nutrition'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradefoo123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefoo123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefoo123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefoo123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefoo123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefoo123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefoo123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefoo123 = "E8";}
								else if(($row["score"] <= 39)){$gradefoo123 = "F9";}
								else {$gradefoo123 = "NA";}
						$tfooscore123[] = $row['score'];						
						}
$ttfooscore123 = current($tfooscore123);			
}
}					
?>
<td><?php echo $fffooscore71;  ?></td>
<td><?php if($fffooscore71 != ""){echo $gradefoo71;}else{echo "-";} ?></td>
<td><?php echo $ssfooscore72;  ?></td>
<td><?php if($ssfooscore72 != ""){echo $gradefoo72;}else{echo "-";} ?></td>
<td><?php echo $ttfooscore73;  ?></td>
<td><?php if($ttfooscore73 != ""){echo $gradefoo73;}else{echo "-";} ?></td>
<td><?php echo $fffooscore81;  ?></td>
<td><?php if($fffooscore81 != ""){echo $gradefoo81;}else{echo "-";} ?></td>
<td><?php echo $ssfooscore82;  ?></td>
<td><?php if($ssfooscore82 != ""){echo $gradefoo82;}else{echo "-";} ?></td>
<td><?php echo $ttfooscore83;  ?></td>
<td><?php if($ttfooscore83 != ""){echo $gradefoo83;}else{echo "-";} ?></td>
<td><?php echo $fffooscore91;  ?></td>
<td><?php if($fffooscore91 != ""){echo $gradefoo91;}else{echo "-";} ?></td>
<td><?php echo $ssfooscore92;  ?></td>
<td><?php if($ssfooscore92 != ""){echo $gradefoo92;}else{echo "-";} ?></td>
<td><?php echo $ttfooscore93;  ?></td>
<td><?php if($ttfooscore93 != ""){echo $gradefoo93;}else{echo "-";} ?></td>
<td><?php echo $fffooscore101;  ?></td>
<td><?php if($fffooscore101 != ""){echo $gradefoo101;}else{echo "-";} ?></td>
<td><?php echo $ssfooscore102;  ?></td>
<td><?php if($ssfooscore102 != ""){echo $gradefoo102;}else{echo "-";} ?></td>
<td><?php echo $ttfooscore103;  ?></td>
<td><?php if($ttfooscore103 != ""){echo $gradefoo103;}else{echo "-";} ?></td>
<td><?php echo $fffooscore111;  ?></td>
<td><?php if($fffooscore111 != ""){echo $gradefoo111;}else{echo "-";} ?></td>
<td><?php echo $ssfooscore112;  ?></td>
<td><?php if($ssfooscore112 != ""){echo $gradefoo112;}else{echo "-";} ?></td>
<td><?php echo $ttfooscore113;  ?></td>
<td><?php if($ttfooscore113 != ""){echo $gradefoo113;}else{echo "-";} ?></td>
<td><?php echo $fffooscore121;  ?></td>
<td><?php if($fffooscore121 != ""){echo $gradefoo121;}else{echo "-";} ?></td>
<td><?php echo $ssfooscore122;  ?></td>
<td><?php if($ssfooscore122 != ""){echo $gradefoo122;}else{echo "-";} ?></td>
<td><?php echo $ttfooscore123;  ?></td>
<td><?php if($ttfooscore123 != ""){echo $gradefoo123;}else{echo "-";} ?></td>
</tr>




<tr style="height: 13px;">
<td>FRENCH.</td>
<?php
include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
//YEAR 7 DATA FOR FRENCH
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefre71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefre71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefre71 = "P";}
								else if(($row["score"] <= 49)){$gradefre71 = "F";}
								else {$gradefre71 = "NA";}
						$ffrescore71[] = $row['score'];						
						}
$fffrescore71 = current($ffrescore71);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefre72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefre72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefre72 = "P";}
								else if(($row["score"] <= 49)){$gradefre72 = "F";}
								else {$gradefre72 = "NA";}
						$sfrescore72[] = $row['score'];						
						}
$ssfrescore72 = current($sfrescore72);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefre73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefre73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefre73 = "P";}
								else if(($row["score"] <= 49)){$gradefre73 = "F";}
								else {$gradefre73 = "NA";}
						$tfrescore73[] = $row['score'];						
						}
$ttfrescore73 = current($tfrescore73);
}
// YEAR 8 DATA FOR FRENCH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefre81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefre81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefre81 = "P";}
								else if(($row["score"] <= 49)){$gradefre81 = "F";}
								else {$gradefre81 = "NA";}
						$ffrescore81[] = $row['score'];						
						}
$fffrescore81 = current($ffrescore81);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefre82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefre82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefre82 = "P";}
								else if(($row["score"] <= 49)){$gradefre82 = "F";}
								else {$gradefre82 = "NA";}
						$sfrescore82[] = $row['score'];						
						}
$ssfrescore82 = current($sfrescore82);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefre83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefre83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefre83 = "P";}
								else if(($row["score"] <= 49)){$gradefre83 = "F";}
								else {$gradefre83 = "NA";}
						$tfrescore83[] = $row['score'];						
						}
$ttfrescore83 = current($tfrescore83);

// YEAR 9 DATA FOR FRENCH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefre91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefre91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefre91 = "P";}
								else if(($row["score"] <= 49)){$gradefre91 = "F";}
								else {$gradefre91 = "NA";}
						$ffrescore91[] = $row['score'];						
						}
$fffrescore91 = current($ffrescore91);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefre92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefre92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefre92 = "P";}
								else if(($row["score"] <= 49)){$gradefre92 = "F";}
								else {$gradefoo92 = "NA";}
						$sfrescore92[] = $row['score'];						
						}
$ssfrescore92 = current($sfrescore92);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradefre93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradefre93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradefre93 = "P";}
								else if(($row["score"] <= 49)){$gradefre93 = "F";}
								else {$gradefre93 = "NA";}
						$tfrescore93[] = $row['score'];						
						}
$ttfrescore93 = current($tfrescore93);				
}	

// YEAR 10 DATA FOR FRENCH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradefre101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefre101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefre101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefre101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefre101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefre101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefre101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefre101 = "E8";}
								else if(($row["score"] <= 39)){$gradefre101 = "F9";}
								else {$gradefre101 = "NA";}
						$ffrescore101[] = $row['score'];						
						}
$fffrescore101 = current($ffrescore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradefre102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefre102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefre102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefre102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefre102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefre102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefre102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefre102 = "E8";}
								else if(($row["score"] <= 39)){$gradefre102 = "F9";}
								else {$gradefre102 = "NA";}
						$sfrescore102[] = $row['score'];						
						}
$ssfrescore102 = current($sfrescore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradefre103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefre103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefre103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefre103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefre103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefre103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefre103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefre103 = "E8";}
								else if(($row["score"] <= 39)){$gradefre103 = "F9";}
								else {$gradefre103 = "NA";}
						$tfrescore103[] = $row['score'];						
						}
$ttfrescore103 = current($tfrescore103);		
}

// YEAR 11 DATA FOR FRENCH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradefre111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefre111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefre111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefre111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefre111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefre111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefre111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefre111 = "E8";}
								else if(($row["score"] <= 39)){$gradefre111 = "F9";}
								else {$gradefre111 = "NA";}
						$ffrescore111[] = $row['score'];						
						}
$fffrescore111 = current($ffrescore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradefre112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefre112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefre112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefre112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefre112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefre112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefre112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefre112 = "E8";}
								else if(($row["score"] <= 39)){$gradefre112 = "F9";}
								else {$gradefre112 = "NA";}
						$sfrescore112[] = $row['score'];						
						}
$ssfrescore112 = current($sfrescore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradefre113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefre113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefre113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefre113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefre113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefre113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefre113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefre113 = "E8";}
								else if(($row["score"] <= 39)){$gradefre113 = "F9";}
								else {$gradefre113 = "NA";}
						$tfrescore113[] = $row['score'];						
						}
$ttfrescore113 = current($tfrescore113);				
}

// YEAR 12 DATA FOR FRENCH
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradefre121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefre121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefre121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefre121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefre121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefre121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefre121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefre121 = "E8";}
								else if(($row["score"] <= 39)){$gradefre121 = "F9";}
								else {$gradefre121 = "NA";}
						$ffrescore121[] = $row['score'];						
						}
$fffrescore121 = current($ffrescore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradefre122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefre122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefre122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefre122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefre122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefre122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefre122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefre122 = "E8";}
								else if(($row["score"] <= 39)){$gradefre122 = "F9";}
								else {$gradefre122 = "NA";}
						$sfrescore122[] = $row['score'];						
						}
$ssfrescore122 = current($sfrescore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='French'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradefre123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradefre123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradefre123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradefre123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradefre123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradefre123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradefre123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradefre123 = "E8";}
								else if(($row["score"] <= 39)){$gradefre123 = "F9";}
								else {$gradefre123 = "NA";}
						$tfrescore123[] = $row['score'];						
						}
$ttfrescore123 = current($tfrescore123);			
}
}					
?>
<td><?php echo $fffrescore71;  ?></td>
<td><?php if($fffrescore71 != ""){echo $gradefre71;}else{echo "-";} ?></td>
<td><?php echo $ssfrescore72;  ?></td>
<td><?php if($ssfrescore72 != ""){echo $gradefre72;}else{echo "-";} ?></td>
<td><?php echo $ttfrescore73;  ?></td>
<td><?php if($ttfrescore73 != ""){echo $gradefre73;}else{echo "-";} ?></td>
<td><?php echo $fffrescore81;  ?></td>
<td><?php if($fffrescore81 != ""){echo $gradefre81;}else{echo "-";} ?></td>
<td><?php echo $ssfrescore82;  ?></td>
<td><?php if($ssfrescore82 != ""){echo $gradefre82;}else{echo "-";} ?></td>
<td><?php echo $ttfrescore83;  ?></td>
<td><?php if($ttfrescore83 != ""){echo $gradefre83;}else{echo "-";} ?></td>
<td><?php echo $fffrescore91;  ?></td>
<td><?php if($fffrescore91 != ""){echo $gradefre91;}else{echo "-";} ?></td>
<td><?php echo $ssfrescore92;  ?></td>
<td><?php if($ssfrescore92 != ""){echo $gradefre92;}else{echo "-";} ?></td>
<td><?php echo $ttfrescore93;  ?></td>
<td><?php if($ttfrescore93 != ""){echo $gradefre93;}else{echo "-";} ?></td>
<td><?php echo $fffrescore101;  ?></td>
<td><?php if($fffrescore101 != ""){echo $gradefre101;}else{echo "-";} ?></td>
<td><?php echo $ssfrescore102;  ?></td>
<td><?php if($ssfrescore102 != ""){echo $gradefre102;}else{echo "-";} ?></td>
<td><?php echo $ttfrescore103;  ?></td>
<td><?php if($ttfrescore103 != ""){echo $gradefre103;}else{echo "-";} ?></td>
<td><?php echo $fffrescore111;  ?></td>
<td><?php if($fffrescore111 != ""){echo $gradefre111;}else{echo "-";} ?></td>
<td><?php echo $ssfrescore112;  ?></td>
<td><?php if($ssfrescore112 != ""){echo $gradefre112;}else{echo "-";} ?></td>
<td><?php echo $ttfrescore113;  ?></td>
<td><?php if($ttfrescore113 != ""){echo $gradefre113;}else{echo "-";} ?></td>
<td><?php echo $fffrescore121;  ?></td>
<td><?php if($fffrescore121 != ""){echo $gradefre121;}else{echo "-";} ?></td>
<td><?php echo $ssfrescore122;  ?></td>
<td><?php if($ssfrescore122 != ""){echo $gradefre122;}else{echo "-";} ?></td>
<td><?php echo $ttfrescore123;  ?></td>
<td><?php if($ttfrescore123 != ""){echo $gradefre123;}else{echo "-";} ?></td>
</tr>




<tr style="height: 13px;">
<td>GOVERNMENT.</td>
<?php
include "connection.php";	
// YEAR 10 DATA FOR GOVT
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Government'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradegov101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradegov101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradegov101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradegov101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradegov101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradegov101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradegov101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradegov101 = "E8";}
								else if(($row["score"] <= 39)){$gradegov101 = "F9";}
								else {$gradegov101 = "NA";}
						$fgovscore101[] = $row['score'];						
						}
$ffgovscore101 = current($fgovscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Government'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradegov102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradegov102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradegov102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradegov102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradegov102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradegov102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradegov102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradegov102 = "E8";}
								else if(($row["score"] <= 39)){$gradegov102 = "F9";}
								else {$gradegov102 = "NA";}
						$sgovscore102[] = $row['score'];						
						}
$ssgovscore102 = current($sgovscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Government'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradegov103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradegov103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradegov103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradegov103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradegov103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradegov103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradegov103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradegov103 = "E8";}
								else if(($row["score"] <= 39)){$gradegov103 = "F9";}
								else {$gradegov103 = "NA";}
						$tgovscore103[] = $row['score'];						
						}
$ttgovscore103 = current($tgovscore103);		
}

// YEAR 11 DATA FOR GOVT
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Government'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradegov111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradegov111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradegov111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradegov111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradegov111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradegov111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradegov111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradegov111 = "E8";}
								else if(($row["score"] <= 39)){$gradegov111 = "F9";}
								else {$gradegov111 = "NA";}
						$fgovscore111[] = $row['score'];						
						}
$ffgovscore111 = current($fgovscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Government'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradegov112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradegov112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradegov112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradegov112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradegov112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradegov112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradegov112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradegov112 = "E8";}
								else if(($row["score"] <= 39)){$gradegov112 = "F9";}
								else {$gradegov112 = "NA";}
						$sgovscore112[] = $row['score'];						
						}
$ssgovscore112 = current($sgovscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Government'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradegov113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradegov113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradegov113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradegov113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradegov113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradegov113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradegov113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradegov113 = "E8";}
								else if(($row["score"] <= 39)){$gradegov113 = "F9";}
								else {$gradegov113 = "NA";}
						$tgovscore113[] = $row['score'];						
						}
$ttgovscore113 = current($tgovscore113);				
}

// YEAR 12 DATA FOR GOVT
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Government'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradegov121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradegov121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradegov121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradegov121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradegov121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradegov121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradegov121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradegov121 = "E8";}
								else if(($row["score"] <= 39)){$gradegov121 = "F9";}
								else {$gradegov121 = "NA";}
						$fgovscore121[] = $row['score'];						
						}
$ffgovscore121 = current($fgovscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Government'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradegov122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradegov122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradegov122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradegov122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradegov122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradegov122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradegov122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradegov122 = "E8";}
								else if(($row["score"] <= 39)){$gradegov122 = "F9";}
								else {$gradegov122 = "NA";}
						$sgovscore122[] = $row['score'];						
						}
$ssgovscore122 = current($sgovscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Government'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradegov123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradegov123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradegov123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradegov123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradegov123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradegov123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradegov123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradegov123 = "E8";}
								else if(($row["score"] <= 39)){$gradegov123 = "F9";}
								else {$gradegov123 = "NA";}
						$tgovscore123[] = $row['score'];						
						}
$ttgovscore123 = current($tgovscore123);			
}					
?>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td>-</td>
<td><?php echo $ffgovscore101;  ?></td>
<td><?php if($ffgovscore101 != ""){echo $gradegov101;}else{echo "-";} ?></td>
<td><?php echo $ssgovscore102;  ?></td>
<td><?php if($ssgovscore102 != ""){echo $gradegov102;}else{echo "-";} ?></td>
<td><?php echo $ttgovscore103;  ?></td>
<td><?php if($ttgovscore103 != ""){echo $gradegov103;}else{echo "-";} ?></td>
<td><?php echo $ffgovscore111;  ?></td>
<td><?php if($ffgovscore111 != ""){echo $gradegov111;}else{echo "-";} ?></td>
<td><?php echo $ssgovscore112;  ?></td>
<td><?php if($ssgovscore112 != ""){echo $gradegov112;}else{echo "-";} ?></td>
<td><?php echo $ttgovscore113;  ?></td>
<td><?php if($ttgovscore113 != ""){echo $gradegov113;}else{echo "-";} ?></td>
<td><?php echo $ffgovscore121;  ?></td>
<td><?php if($ffgovscore121 != ""){echo $gradegov121;}else{echo "-";} ?></td>
<td><?php echo $ssgovscore122;  ?></td>
<td><?php if($ssgovscore122 != ""){echo $gradegov122;}else{echo "-";} ?></td>
<td><?php echo $ttgovscore123;  ?></td>
<td><?php if($ttgovscore123 != ""){echo $gradegov123;}else{echo "-";} ?></td>
</tr>


<tr style="height: 13px;">
<td>ICT</td>
<?php
include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
//YEAR 7 DATA FOR ICT
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeict71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeict71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeict71 = "P";}
								else if(($row["score"] <= 49)){$gradeict71 = "F";}
								else {$gradeict71 = "NA";}
						$fictscore71[] = $row['score'];						
						}
$ffictscore71 = current($fictscore71);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeict72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeict72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeict72 = "P";}
								else if(($row["score"] <= 49)){$gradeict72 = "F";}
								else {$gradeict72 = "NA";}
						$sictscore72[] = $row['score'];						
						}
$ssictscore72 = current($sictscore72);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeict73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeict73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeict73 = "P";}
								else if(($row["score"] <= 49)){$gradeict73 = "F";}
								else {$gradeict73 = "NA";}
						$tictscore73[] = $row['score'];						
						}
$ttictscore73 = current($tictscore73);
}
// YEAR 8 DATA FOR ICT
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeict81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeict81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeict81 = "P";}
								else if(($row["score"] <= 49)){$gradeict81 = "F";}
								else {$gradeict81 = "NA";}
						$fictscore81[] = $row['score'];						
						}
$ffictscore81 = current($fictscore81);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeict82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeict82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeict82 = "P";}
								else if(($row["score"] <= 49)){$gradeict82 = "F";}
								else {$gradeict82 = "NA";}
						$sictscore82[] = $row['score'];						
						}
$ssictscore82 = current($sictscore82);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeict83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeict83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeict83 = "P";}
								else if(($row["score"] <= 49)){$gradeict83 = "F";}
								else {$gradeict83 = "NA";}
						$tictscore83[] = $row['score'];						
						}
$ttictscore83 = current($tictscore83);

// YEAR 9 DATA FOR ICT
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeict91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeict91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeict91 = "P";}
								else if(($row["score"] <= 49)){$gradeict91 = "F";}
								else {$gradeict91 = "NA";}
						$fictscore91[] = $row['score'];						
						}
$ffictscore91 = current($fictscore91);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeict92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeict92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeict92 = "P";}
								else if(($row["score"] <= 49)){$gradeict92 = "F";}
								else {$gradeict92 = "NA";}
						$sictscore92[] = $row['score'];						
						}
$ssictscore92 = current($sictscore92);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeict93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeict93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeict93 = "P";}
								else if(($row["score"] <= 49)){$gradeict93 = "F";}
								else {$gradeict93 = "NA";}
						$tictscore93[] = $row['score'];						
						}
$ttictscore93 = current($tictscore93);	
}	

// YEAR 10 DATA FOR ICT
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeict101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeict101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeict101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeict101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeict101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeict101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeict101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeict101 = "E8";}
								else if(($row["score"] <= 39)){$gradeict101 = "F9";}
								else {$gradeict101 = "NA";}
						$fictscore101[] = $row['score'];						
						}
$ffictscore101 = current($fictscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeict102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeict102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeict102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeict102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeict102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeict102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeict102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeict102 = "E8";}
								else if(($row["score"] <= 39)){$gradeict102 = "F9";}
								else {$gradeict102 = "NA";}
						$sictscore102[] = $row['score'];						
						}
$ssictscore102 = current($sictscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeict103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeict103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeict103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeict103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeict103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeict103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeict103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeict103 = "E8";}
								else if(($row["score"] <= 39)){$gradeict103 = "F9";}
								else {$gradeict103 = "NA";}
						$tictscore103[] = $row['score'];						
						}
$ttictscore103 = current($tictscore103);	
}

// YEAR 11 DATA FOR ICT
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeict111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeict111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeict111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeict111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeict111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeict111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeict111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeict111 = "E8";}
								else if(($row["score"] <= 39)){$gradeict111 = "F9";}
								else {$gradeict111 = "NA";}
						$fictscore111[] = $row['score'];						
						}
$ffictscore111 = current($fictscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$gradeict112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeict112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeict112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeict112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeict112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeict112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeict112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeict112 = "E8";}
								else if(($row["score"] <= 39)){$gradeict112 = "F9";}
								else {$gradeict112 = "NA";}
						$sictscore112[] = $row['score'];						
						}
$ssictscore112 = current($sictscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeict113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeict113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeict113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeict113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeict113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeict113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeict113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeict113 = "E8";}
								else if(($row["score"] <= 39)){$gradeict113 = "F9";}
								else {$gradeict113 = "NA";}
						$tictscore113[] = $row['score'];						
						}
$ttictscore113 = current($tictscore113);				
}

// YEAR 12 DATA FOR ICT
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeict121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeict121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeict121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeict121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeict121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeict121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeict121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeict121 = "E8";}
								else if(($row["score"] <= 39)){$gradeict121 = "F9";}
								else {$gradeict121 = "NA";}
						$fictscore121[] = $row['score'];						
						}
$ffictscore121 = current($fictscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeict122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeict122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeict122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeict122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeict122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeict122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeict122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeict122 = "E8";}
								else if(($row["score"] <= 39)){$gradeict122 = "F9";}
								else {$gradeict122 = "NA";}
						$sictscore122[] = $row['score'];						
						}
$ssictscore122 = current($sictscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='ICT'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeict123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeict123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeict123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeict123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeict123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeict123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeict123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeict123 = "E8";}
								else if(($row["score"] <= 39)){$gradeict123 = "F9";}
								else {$gradeict123 = "NA";}
						$tictscore123[] = $row['score'];						
						}
$ttictscore123 = current($tictscore123);		
}
}					
?>
<td><?php echo $ffictscore71;  ?></td>
<td><?php if($ffictscore71 != ""){echo $gradeict71;}else{echo "-";} ?></td>
<td><?php echo $ssictscore72;  ?></td>
<td><?php if($ssictscore72 != ""){echo $gradeict72;}else{echo "-";} ?></td>
<td><?php echo $ttictscore73;  ?></td>
<td><?php if($ttictscore73 != ""){echo $gradeict73;}else{echo "-";} ?></td>
<td><?php echo $ffictscore81;  ?></td>
<td><?php if($ffictscore81 != ""){echo $gradeict81;}else{echo "-";} ?></td>
<td><?php echo $ssictscore82;  ?></td>
<td><?php if($ssictscore82 != ""){echo $gradeict82;}else{echo "-";} ?></td>
<td><?php echo $ttictscore83;  ?></td>
<td><?php if($ttictscore83 != ""){echo $gradeict83;}else{echo "-";} ?></td>
<td><?php echo $ffictscore91;  ?></td>
<td><?php if($ffictscore91 != ""){echo $gradeict91;}else{echo "-";} ?></td>
<td><?php echo $ssictscore92;  ?></td>
<td><?php if($ssictscore92 != ""){echo $gradeict92;}else{echo "-";} ?></td>
<td><?php echo $ttictscore93;  ?></td>
<td><?php if($ttictscore93 != ""){echo $gradeict93;}else{echo "-";} ?></td>
<td><?php echo $ffictscore101;  ?></td>
<td><?php if($ffictscore101 != ""){echo $gradeict101;}else{echo "-";} ?></td>
<td><?php echo $ssictscore102;  ?></td>
<td><?php if($ssictscore102 != ""){echo $gradeict102;}else{echo "-";} ?></td>
<td><?php echo $ttictscore103;  ?></td>
<td><?php if($ttictscore103 != ""){echo $gradeict103;}else{echo "-";} ?></td>
<td><?php echo $ffictscore111;  ?></td>
<td><?php if($ffictscore111 != ""){echo $gradeict111;}else{echo "-";} ?></td>
<td><?php echo $ssictscore112;  ?></td>
<td><?php if($ssictscore112 != ""){echo $gradeict112;}else{echo "-";} ?></td>
<td><?php echo $ttictscore113;  ?></td>
<td><?php if($ttictscore113 != ""){echo $gradeict113;}else{echo "-";} ?></td>
<td><?php echo $ffictscore121;  ?></td>
<td><?php if($ffictscore121 != ""){echo $gradeict121;}else{echo "-";} ?></td>
<td><?php echo $ssictscore122;  ?></td>
<td><?php if($ssictscore122 != ""){echo $gradeict122;}else{echo "-";} ?></td>
<td><?php echo $ttictscore123;  ?></td>
<td><?php if($ttictscore123 != ""){echo $gradeict123;}else{echo "-";} ?></td>
</tr>




<tr style="height: 13px;">
<td>IGBO</td>
<?php
include "connection.php";
$class_name = $_POST['class_name'];
if($class_name == 'Year 12'){
echo "";
}
else{
//YEAR 7 DATA FOR IGBO
$class_name = $_POST['class_name'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		if($class_name == 'Year 7'){
		$y = 'Year 7';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 12'){
		$y = 'Year 12';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='First Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeigb71 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeigb71 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeigb71 = "P";}
								else if(($row["score"] <= 49)){$gradeigb71 = "F";}
								else {$gradeigb71 = "NA";}
						$figbscore71[] = $row['score'];						
						}
$ffigbscore71 = current($figbscore71);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Second Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeigb72 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeigb72 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeigb72 = "P";}
								else if(($row["score"] <= 49)){$gradeigb72 = "F";}
								else {$gradeigb72 = "NA";}
						$sigbscore72[] = $row['score'];						
						}
$ssigbscore72 = current($sigbscore72);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year' AND term='Third Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeigb73 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeigb73 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeigb73 = "P";}
								else if(($row["score"] <= 49)){$gradeigb73 = "F";}
								else {$gradeigb73 = "NA";}
						$tigbscore73[] = $row['score'];						
						}
$ttigbscore73 = current($tigbscore73);
}
// YEAR 8 DATA FOR IGBO
$class_name = $_POST['class_name'];
if(($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 1;
		if($class_name == 'Year 7'){
		$y = 'Year 8';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 11'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeigb81 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeigb81 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeigb81 = "P";}
								else if(($row["score"] <= 49)){$gradeigb81 = "F";}
								else {$gradeigb81 = "NA";}
						$figbscore81[] = $row['score'];						
						}
$ffigbscore81 = current($figbscore81);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeigb82 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeigb82 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeigb82 = "P";}
								else if(($row["score"] <= 49)){$gradeigb82 = "F";}
								else {$gradeigb82 = "NA";}
						$sigbscore82[] = $row['score'];						
						}
$ssigbscore82 = current($sigbscore82);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeigb83 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeigb83 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeigb83 = "P";}
								else if(($row["score"] <= 49)){$gradeigb83 = "F";}
								else {$gradeigb83 = "NA";}
						$tigbscore83[] = $row['score'];						
						}
$ttigbscore83 = current($tigbscore83);

// YEAR 9 DATA FOR IGBO
$class_name = $_POST['class_name'];
if(($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 2;
		if($class_name == 'Year 7'){
		$y = 'Year 9';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 10'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeigb91 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeigb91 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeigb91 = "P";}
								else if(($row["score"] <= 49)){$gradeigb91 = "F";}
								else {$gradeigb91 = "NA";}
						$figbscore91[] = $row['score'];						
						}
$ffigbscore91 = current($figbscore91);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeigb92 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeigb92 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeigb92 = "P";}
								else if(($row["score"] <= 49)){$gradeigb92 = "F";}
								else {$gradeigb92 = "NA";}
						$sigbscore92[] = $row['score'];						
						}
$ssigbscore92 = current($sigbscore92);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 70){$gradeigb93 = "A"; }
								else if(($row["score"] >= 60) AND ($row["score"] <= 69)){$gradeigb93 = "C";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 59)){$gradeigb93 = "P";}
								else if(($row["score"] <= 49)){$gradeigb93 = "F";}
								else {$gradeigb93 = "NA";}
						$tigbscore93[] = $row['score'];						
						}
$ttigbscore93 = current($tigbscore93);
}	

// YEAR 10 DATA FOR IGBO
$class_name = $_POST['class_name'];
if(($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 3;
		if($class_name == 'Year 7'){
		$y = 'Year 10';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 9'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeigb101 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeigb101 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeigb101 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeigb101 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeigb101 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeigb101 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeigb101 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeigb101 = "E8";}
								else if(($row["score"] <= 39)){$gradeigb101 = "F9";}
								else {$gradeigb101 = "NA";}
						$figbscore101[] = $row['score'];						
						}
$ffigbscore101 = current($figbscore101);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeigb102 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeigb102 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeigb102 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeigb102 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeigb102 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeigb102 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeigb102 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeigb102 = "E8";}
								else if(($row["score"] <= 39)){$gradeigb102 = "F9";}
								else {$gradeigb102 = "NA";}
						$sigbscore102[] = $row['score'];						
						}
$ssigbscore102 = current($sigbscore102);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeigb103 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeigb103 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeigb103 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeigb103 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeigb103 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeigb103 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeigb103 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeigb103 = "E8";}
								else if(($row["score"] <= 39)){$gradeigb103 = "F9";}
								else {$gradeigb103 = "NA";}
						$tigbscore103[] = $row['score'];						
						}
$ttigbscore103 = current($tigbscore103);	
}

// YEAR 11 DATA FOR IGBO
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 4;
		if($class_name == 'Year 7'){
		$y = 'Year 11';
		}
		else if($class_name == 'Year 8'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeigb111 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeigb111 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeigb111 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeigb111 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeigb111 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeigb111 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeigb111 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeigb111 = "E8";}
								else if(($row["score"] <= 39)){$gradeigb111 = "F9";}
								else {$gradeigb111 = "NA";}
						$figbscore111[] = $row['score'];						
						}
$ffigbscore111 = current($figbscore111);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
											if($row["score"] >= 80){$gradeigb112 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeigb112 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeigb112 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeigb112 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeigb112 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeigb112 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeigb112 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeigb112 = "E8";}
								else if(($row["score"] <= 39)){$gradeigb112 = "F9";}
								else {$gradeigb112 = "NA";}
						$sigbscore112[] = $row['score'];						
						}
$ssigbscore112 = current($sigbscore112);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeigb113 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeigb113 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeigb113 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeigb113 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeigb113 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeigb113 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeigb113 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeigb113 = "E8";}
								else if(($row["score"] <= 39)){$gradeigb113 = "F9";}
								else {$gradeigb113 = "NA";}
						$tigbscore113[] = $row['score'];						
						}
$ttigbscore113 = current($tigbscore113);				
}

// YEAR 12 DATA FOR IGBO
$class_name = $_POST['class_name'];
if(($class_name == 'Year 8') OR ($class_name == 'Year 9') OR ($class_name == 'Year 10') OR ($class_name == 'Year 11') OR ($class_name == 'Year 12')){
echo "";
}
else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$year2 = $year + 5;
		if($class_name == 'Year 7'){
		$y = 'Year 12';
		}
		else if($class_name == 'Year 8'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 9'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 10'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 11'){
		$y = 'NOT APPLICABLE';
		}
		else if($class_name == 'Year 12'){
		$y = 'NOT APPLICABLE';
		}
		else{
			$y = 'NA';
		}
$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='First Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeigb121 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeigb121 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeigb121 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeigb121 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeigb121 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeigb121 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeigb121 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeigb121 = "E8";}
								else if(($row["score"] <= 39)){$gradeigb121 = "F9";}
								else {$gradeigb121 = "NA";}
						$figbscore121[] = $row['score'];						
						}
$ffigbscore121 = current($figbscore121);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Second Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
									if($row["score"] >= 80){$gradeigb122 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeigb122 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeigb122 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeigb122 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeigb122 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeigb122 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeigb122 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeigb122 = "E8";}
								else if(($row["score"] <= 39)){$gradeigb122 = "F9";}
								else {$gradeigb122 = "NA";}
						$sigbscore122[] = $row['score'];						
						}
$ssigbscore122 = current($sigbscore122);

$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$y' AND year='$year2' AND term='Third Term' AND subject='Igbo'");
						while($row = mysqli_fetch_assoc($result))
							{  
										if($row["score"] >= 80){$gradeigb123 = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$gradeigb123 = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$gradeigb123 = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$gradeigb123 = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$gradeigb123 = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$gradeigb123 = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$gradeigb123 = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$gradeigb123 = "E8";}
								else if(($row["score"] <= 39)){$gradeigb123 = "F9";}
								else {$gradeigb123 = "NA";}
						$tigbscore123[] = $row['score'];						
						}
$ttigbscore123 = current($tigbscore123);
}
}					
?>
<td><?php echo $ffigbscore71;  ?></td>
<td><?php if($ffigbscore71 != ""){echo $gradeigb71;}else{echo "-";} ?></td>
<td><?php echo $ssigbscore72;  ?></td>
<td><?php if($ssigbscore72 != ""){echo $gradeigb72;}else{echo "-";} ?></td>
<td><?php echo $ttigbscore73;  ?></td>
<td><?php if($ttigbscore73 != ""){echo $gradeigb73;}else{echo "-";} ?></td>
<td><?php echo $ffigbscore81;  ?></td>
<td><?php if($ffigbscore81 != ""){echo $gradeigb81;}else{echo "-";} ?></td>
<td><?php echo $ssigbscore82;  ?></td>
<td><?php if($ssigbscore82 != ""){echo $gradeigb82;}else{echo "-";} ?></td>
<td><?php echo $ttigbscore83;  ?></td>
<td><?php if($ttigbscore83 != ""){echo $gradeigb83;}else{echo "-";} ?></td>
<td><?php echo $ffigbscore91;  ?></td>
<td><?php if($ffigbscore91 != ""){echo $gradeigb91;}else{echo "-";} ?></td>
<td><?php echo $ssigbscore92;  ?></td>
<td><?php if($ssigbscore92 != ""){echo $gradeigb92;}else{echo "-";} ?></td>
<td><?php echo $ttigbscore93;  ?></td>
<td><?php if($ttigbscore93 != ""){echo $gradeigb93;}else{echo "-";} ?></td>
<td><?php echo $ffigbscore101;  ?></td>
<td><?php if($ffigbscore101 != ""){echo $gradeigb101;}else{echo "-";} ?></td>
<td><?php echo $ssigbscore102;  ?></td>
<td><?php if($ssigbscore102 != ""){echo $gradeigb102;}else{echo "-";} ?></td>
<td><?php echo $ttigbscore103;  ?></td>
<td><?php if($ttigbscore103 != ""){echo $gradeigb103;}else{echo "-";} ?></td>
<td><?php echo $ffigbscore111;  ?></td>
<td><?php if($ffigbscore111 != ""){echo $gradeigb111;}else{echo "-";} ?></td>
<td><?php echo $ssigbscore112;  ?></td>
<td><?php if($ssigbscore112 != ""){echo $gradeigb112;}else{echo "-";} ?></td>
<td><?php echo $ttigbscore113;  ?></td>
<td><?php if($ttigbscore113 != ""){echo $gradeigb113;}else{echo "-";} ?></td>
<td><?php echo $ffigbscore121;  ?></td>
<td><?php if($ffigbscore121 != ""){echo $gradeigb121;}else{echo "-";} ?></td>
<td><?php echo $ssigbscore122;  ?></td>
<td><?php if($ssigbscore122 != ""){echo $gradeigb122;}else{echo "-";} ?></td>
<td><?php echo $ttigbscore123;  ?></td>
<td><?php if($ttigbscore123 != ""){echo $gradeigb123;}else{echo "-";} ?></td>
</tr>



<tr style="height: 13px;">
<td>LIT. IN ENGLISH</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
</tr>




<tr style="height: 13px;">
<td>MARKETING</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
</tr>




<tr style="height: 13px;">
<td>MUSIC</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
</tr>




<tr style="height: 13px;">
<td>PHE</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
</tr>



<tr style="height: 13px;">
<td>PHYSICS</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
</tr>



<tr style="height: 13px;">
<td>SOCIOLOGY</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
</tr>






<tr style="height: 13px;">
<td>TD</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
</tr>





<tr style="height: 13px;">
<td>VISUAL ART</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
</tr>

</tbody>
</table>

<table style="width: 100%; text-align: center; font-size: 8pt;">
<tbody>
<tr>
<td colspan="7"><label style="margin-left:40%;">DESCRIPTION OF GRADES</label></td>
</tr>
<tr>
<td style="vertical-align: bottom;" rowspan="10">
<hr style="width:40%;" />
<br><label>&nbsp;ADEYOYIN ADESINA&nbsp;</label><br />PRINCIPAL</td>
<td colspan="2">IGCSE</td>
<td colspan="2">WASSCE</td>
<td colspan="2">BECE</td>
</tr>
<tr style="height: 10px;">
<td>&nbsp;90 - 100</td>
<td>&nbsp;A*</td>
<td>&nbsp;75 - 100</td>
<td>&nbsp;A1</td>
<td>&nbsp;70 - 100</td>
<td>&nbsp;A</td>
</tr>
<tr style="height: 13px;">
<td>&nbsp;80 - 89</td>
<td>&nbsp;A</td>
<td>&nbsp;70 - 74</td>
<td>&nbsp;B2</td>
<td>&nbsp;60 - 69</td>
<td>&nbsp;C</td>
</tr>
<tr style="height: 13px;">
<td>&nbsp;70 - 79</td>
<td>&nbsp;B</td>
<td>&nbsp;65 - 69</td>
<td>&nbsp;B3</td>
<td>&nbsp;50 - 59&nbsp;</td>
<td>&nbsp;P</td>
</tr>
<tr style="height: 13px;">
<td>&nbsp;60 - 69</td>
<td>&nbsp;C</td>
<td>&nbsp;60 - 64</td>
<td>&nbsp;C4</td>
<td>&nbsp;0 - 49</td>
<td>&nbsp;F</td>
</tr>
<tr style="height: 13px;">
<td>&nbsp;50 - 59</td>
<td>&nbsp;D</td>
<td>&nbsp;55 - 59</td>
<td>&nbsp;C5</td>
<td>&nbsp;-</td>
<td>&nbsp;-</td>
</tr>
<tr style="height: 13px;">
<td>&nbsp;40 - 49</td>
<td>&nbsp;E</td>
<td>&nbsp;50 - 54</td>
<td>&nbsp;C6</td>
<td>&nbsp;-</td>
<td>&nbsp;-</td>
</tr>
<tr style="height: 13px;">
<td>&nbsp;30 - 39</td>
<td>&nbsp;F</td>
<td>&nbsp;45 - 49</td>
<td>&nbsp;D7</td>
<td>&nbsp;-</td>
<td>&nbsp;-</td>
</tr>
<tr style="height: 13px;">
<td>&nbsp;20 - 29</td>
<td>&nbsp;G</td>
<td>&nbsp;40 - 44</td>
<td>&nbsp;E8</td>
<td>&nbsp;-</td>
<td>&nbsp;-</td>
</tr>
<tr style="height: 13px;">
<td>0 - 19</td>
<td>U</td>
<td>0 - 39</td>
<td>F9</td>
<td>-</td>
<td>-</td>
</tr>
</tbody>
</table>
</div>
<?php } ?>
</body>