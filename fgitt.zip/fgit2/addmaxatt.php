<?php 
session_start();
include("auth.php"); //include auth.php file on all secure pages

if(isset($_POST['submit8'])){
include "connection.php";
		$maxattname = $_POST['maxattname'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		$termbegin = $_POST['termbegin'];
		$midtermday = $_POST['midtermday'];
	$checkteach2 = mysqli_query($db, "SELECT * FROM maxattname where term='$term' AND year='$year' AND school='".$_SESSION['school']."'");
	$countteach2 = mysqli_num_rows($checkteach2);
	
	if($countteach2 < 1){
		
		
	$query = ("INSERT into maxattname(maxattname, year, term, termbegin, midtermday, school) VALUES ('$maxattname', '$year', '$term', '$termbegin', '$midtermday', '".$_SESSION['school']."')");
        $result = mysqli_query($db,$query);
        if($result){
            echo "<div style='text-align: center; color: red;'><h3>Number of times school opened was saved successfully.</h3></div>";
			echo '<meta content="2;index.php" http-equiv="refresh" />';
	}else{
			echo "<div style='text-align: center; color: red;'><h3>Data not stored.</h3></div>";
			echo '<meta content="2;index.php" http-equiv="refresh" />';
	}}
		else{
			 echo "<div class='form' style='text-align: center; color: red;'><h3>Number of times school opened for the given year and term already exists.</h3></div>";
			echo '<meta content="2;index.php" http-equiv="refresh" />';
		}




}
?>
