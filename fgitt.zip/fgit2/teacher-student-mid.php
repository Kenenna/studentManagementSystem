<?php
	session_start();
	include "connection.php";
	include("auth.php"); 
	include('db.php');
	
	$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Insert Mid Scores</title>
<link rel="stylesheet" href="style.css" type="text/css" />
<link rel="stylesheet" href="css/style.css" />
	<script src="table/js/jquery.js" type="text/javascript"></script>
	<script src="datatablejs.js" type="text/javascript"></script>
	<link rel="stylesheet" type="text/css" href="datatablecss.css">
	 <link rel="stylesheet" type="text/css" href="datatablebuttoncss.css">
<script>
	$(document).ready(function() {
    $('#example').DataTable( {
        "paging":   false,
        "ordering": true,
        "info":     false,
		"scrollY":  "1000px",
        "scrollCollapse": true
    } );
} );
</script>
<script>
$(document).ready(function(){
	var aa = $(".clas").html();
	if(aa!=""){
		$(".form").fadeOut();
		$("#carry").click(function(){
		$(".form").fadeIn();
			$("#carry").fadeOut();
		});
	}
	$( ".tdinput" ).prop( "disabled", true );
	$("td.mxname").click(function(){
	if((!$(".camax").length) || (!$(".exammax").length) || (!$(".testmax").length)){	
		alert("You must first input max scores");
		$("#txtFirstName").focus();
	}
		});
	
	var valueit = $("#txtFirstName").val();
	var valueit1 = $("#txtFirstName1").val();
	var valueit2 = $("#txtFirstName2").val();
	$('#resetmaxes').hide();
	
	if((valueit!="") && (valueit1!="")){
		$("#txtFirstName").replaceWith('<input type="text" class="txtFirstName" id="txtFirstName" value="'+valueit+'" readonly />');
		$("#txtFirstName1").replaceWith('<input type="text" class="txtFirstName1" id="txtFirstName1" value="'+valueit1+'" readonly />');
		$("#txtFirstName2").replaceWith('<input type="text" class="txtFirstName2" id="txtFirstName2" value="'+valueit2+'" readonly />');
	}
	if((valueit!="") && (valueit1!="")){
		$( "#dosomething" ).prop( "disabled", true );
		$( ".tdinput" ).prop( "disabled", false );
		$( ".submit_button" ).prop( "disabled", false );
	}
	
	$("#dosomething").click(function(){	
	var valit = $("#txtFirstName").val();
	var valit1 = $("#txtFirstName1").val();
	var valit2 = $("#txtFirstName2").val();
	if(valit==""){
		alert("You must enter max score for homework.");
	}else if($.isNumeric(valit)==false){
		alert("You must enter only digits.");
	}else if(valit1==""){
		alert("You must enter max score for classwork.");
	}else if($.isNumeric(valit1)==false){
		alert("You must enter only digits.");
	}else if(valit2==""){
		alert("You must enter max score for test.");
	}else if($.isNumeric(valit2)==false){
		alert("You must enter only digits.");
	}else{
	$(".addafter2").after('<th class="newadded" style="text-align: center; width: 6%;">Hw Max</th>');
	$(".newadded").after('<th class="newaddednext" style="text-align: center; width: 6%;">Cw Max</th>');
	$(".newaddednext").after('<th class="newaddedtest" style="text-align: center; width: 6%;">Test Max</th>');
	$(".newadded").eq(1).fadeOut();
	$(".newadded").eq(2).fadeOut();
	$(".newaddedtest").eq(1).fadeOut();
	$(".newaddedtest").eq(2).fadeOut();
	$(".newaddednext").eq(1).fadeOut();
	$(".newaddednext").eq(2).fadeOut();
	$(".addafter").after('<td class="addafter1" style="text-align: center; width: 6%;" ><input style="text-align: center; width: 80%;" class="camax" type="text"  name="hwmax[]" id="hwmax" readonly/></td>');
	$(".addafter1").after('<td class="adafter2" style="text-align: center; width: 6%;"><input style="text-align: center; width: 80%;" class="exammax" type="text"  name="cwmax[]" id="cwmax" readonly/></td>');
	$(".adafter2").after('<td style="text-align: center; width: 6%;" ><input class="testmax" style="text-align: center; width: 80%;" type="text"  name="testmax[]" id="testmax" readonly/></td>');
	$(".camax").val(valit);
	$(".exammax").val(valit1);
	$(".testmax").val(valit2);
	$( "#txtFirstNameall" ).fadeOut( 2000, function() {
    $('#txtFirstNameall').hide();
    });
	$( "#resetmaxes" ).show();
	$( ".tdinput" ).prop( "disabled", false );
	}
});

	$("#resetmaxes").click(function(){	
	location.reload(true);
	});
});
</script>

<script>
		$(document).ready(function() {	
		
 var gggg = $("#classs option").length;	
if(gggg==8){
$("#classs option").eq(7).css("display","none");
}
 $("#sbutt").on("click",function(){
var b = $("#classs").find(":selected").text();
$("#classs").find(":selected").val(b);
var c = $("#classs").find(":selected").val();
//($.trim(c).length);
  }); 		
		
$("#takest").html("Show Students Request Form");
$("#takestu").hide();
 $("#takest").click(function( event ) {
		event.preventDefault();
		var hi = $("#takest").html();
		if(hi == "Show Students Request Form"){	
		//$("#pushdown").after("<div>&nbsp;</div><br><br><br><br><br>");
		$("#takest").html("Hide Students Request Form");
		$("#takestu").show();
		$("#pushit").hide();
		}
		else if(hi == "Hide Students Request Form"){	
		//$("#pushdown").after("<div>&nbsp;</div><br><br><br><br><br>");
		$("#takest").html("Show Students Request Form");
		$("#takestu").hide();
		$("#pushit").show();
		}
	 });		
		
		$("#formid").submit(function( eventtt ) {
			eventtt.preventDefault();	
$.ajax({
type: "POST",
url: "teacher-student_mid_exec.php",
data: $("#formid").serializeArray(),	
success: function(response){
 if(response==1) { 
		$("#submm").remove();
		$("#getprogress").html('<div><a href="teacher-student.php" style="float: left; font-weight: bold; text-transform: uppercase;" >Add Term Scores</a><a href="update-score-mid.php" style="float: right; font-weight: bold; text-transform: uppercase;">Update Mid Scores</a></div>');
		$(".success").fadeIn();
		setTimeout(function() { $(".success").fadeOut(); }, 2000); 
    } else {
		 $(".error").show();
		setTimeout(function() { $(".error").fadeOut(); }, 2000);
		}
		}
});	
});	 
});
</script>
<style>
.submit_button {
	background-color:#44c767;
	-moz-border-radius:28px;
	-webkit-border-radius:28px;
	border-radius:28px;
	border:1px solid #18ab29;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:15px;
	padding:6px 24px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
}
.submit_button:hover {
	background-color:#5cbf2a;
}
.submit_button:active {
	position:relative;
	top:1px;
}
</style>
  <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
<script>
$(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
});
 </script>
 
 <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
   <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
  <!--<link rel="stylesheet" href="css/styles.css">-->
 
</head>

<body>
<?php
echo '<div id="headerit">';
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");
}
elseif($_SESSION['role'] == 'student'){
include("headerstudent.php");
}
else{header("location: logout.php");}
echo '</div>';
?>
<?php
$user = $_SESSION['username'];
include "connection.php";
?>
<br><br>
<center>
<a style="color: red; font-weight: bold; font-size: 20px; text-decoration: none;" href="#" id="takest"></a><br>
</center>
<br>
<form action="" method="post" id="takestu" class="form" enctype="multipart/form-data">
<center>
 <div>
   
	<label><select style="width:210px;" name="class" id="classs" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM classes");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option>';
								if($ctype=="Js"){
								if($cccc == 0){	
									$cccc++;
									echo 'SELECT A CLASS';
									continue;
									}		
								if($cccc <= 3){
								echo 'JS'.$cccc;	
								}
								elseif($cccc >= 4 && $cccc <= 6){
									if($cccc == 4){	
									$cccc++;
									echo 'SS'.($cccc2 - 2);	
									continue;
									}
									if($cccc == 5){	
									$cccc++;
									echo 'SS'.($cccc2 - 1);	
									continue;
									}
									if($cccc == 6){	
									$cccc++;
									echo 'SS'.($cccc2 - 0);	
									continue;
									}
								}else{
									break;
								}
								$cccc++;	
								$cccc2++;
									}
								else{	
								if($ctype=="Primary"){
									if($cccc == 0){	
									$cccc++;
									echo 'SELECT A CLASS';
									continue;
									}
								echo 'Primary '.$cccc;
								if($cccc > 5){
									break;
								}
								$cccc++;	
								}
								else{
								echo 'Year '.$cccc;
								if($cccc > 11){
									break;
								}
								$cccc++;	
								}
								}//end of else
								echo '</option>';
							}
						?>
      </select>
	  <br>
	  <?php
	  echo '<select style="width: 210px; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="arms" id="arms" required >';
	 $result = mysqli_query($db,"SELECT * FROM school where school='".$_SESSION["school"]."'");
				while($row = mysqli_fetch_assoc($result)){
					$arrr2[] = $row["arms"];
				}
				$a = implode(',',$arrr2);
				$b = explode(',',$a);
				$f = (array_filter($b));
				
						for($i=0; $i<=(count($f)-1); $i++)
							{  
								echo '<option value="'.$f[$i].'">';
								echo $f[$i];
								echo '</option>';
							}
    echo '</select>';
?>	
	  <br>
	  <span style="color: red;">session commencement</span>
	  <select style="width:210px;" name="year" id="year" required ><br>    
                    <?php
	$result = mysqli_query($db, "SELECT * FROM years");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['year'].'">';
								echo $row['year'];
								echo '</option>';
							}
						?>
      </select>
	  
	  
	   <br>
	  <select style="width:210px;" name="term" id="term" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT term FROM terms");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['term'].'">';
								echo $row['term'];
								echo '</option>';
							}
						?>
      </select>
	   <br>
	  <select style="width:210px;" name="subject" id="subject" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT subject FROM subjects ORDER BY subject");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['subject'].'">';
								echo $row['subject'];
								echo '</option>';
							}
						?>
      </select>
	  </label>
	  
  <label><br><br>
      <input type="submit" class="submit_button" style="background-color: green; color: white;" id="sbutt" name="btn-upload" value="Submit Form" />
    </label>

  </div>
  
</form>
</center>
<center>
<?php
if(isset($_POST['btn-upload'])){
echo "<p class='clas' style='display: none;'>testing</p>";
$classd = trim($_POST['class']);
$year = $_POST['year'];
$term = $_POST['term'];
$subject = $_POST['subject'];
$arms = $_POST['arms'];

if($classd=='Primary 1'){
		$class = 'Year 1';
	}
	elseif($classd=='Primary 2'){
		$class = 'Year 2';
	}
	elseif($classd=='Primary 3'){
		$class = 'Year 3';
	}
	elseif($classd=='Primary 4'){
		$class = 'Year 4';
	}
	elseif($classd=='Primary 5'){
		$class = 'Year 5';
	}
	elseif($classd=='Primary 6'){
		$class = 'Year 6';
	}		
	elseif($classd=='JS1'){
		$class = 'Year 7';
	}
	elseif($classd=='JS2'){
		$class = 'Year 8';
	}
	elseif($classd=='JS3'){
		$class = 'Year 9';
	}
	elseif($classd=='SS1'){
		$class = 'Year 10';
	}
	elseif($classd=='SS2'){
		$class = 'Year 11';
	}	
	elseif($classd=='SS3'){
		$class = 'Year 12';
	}		
	else{
		$class = $classd;
	}
	
$user=$_SESSION['username'];
$result3 = mysqli_query($db, "SELECT * FROM users2 where username='$user' AND school='".$_SESSION["school"]."'");
while($rowtid = mysqli_fetch_assoc($result3))
{
	$a = $rowtid['teacher_id'];
	$tname = $rowtid['teacher'];
}
$tid =  $a;
$tna = $tname;

//echo $tid;
//echo $tna;

$result = mysqli_query($db, "SELECT * FROM students where arms='$arms' AND class_name='$class' AND year='$year' AND term='$term' AND subject='$subject' AND teacher_id='$tid' AND school='".$_SESSION["school"]."'");
$result2 = mysqli_query($db, "SELECT * FROM scoresmid where arms='$arms' AND class_name='$class' AND year='$year' AND term='$term' AND subject='$subject' AND teacher_id='$tid' AND school='".$_SESSION["school"]."'");

while($row2 = mysqli_fetch_assoc($result2))
{  						
$values2[] = $row2['student_name'];
$values2subject[] = $row2['subject']; //for the scores table
}
$values22 =($values2);
$valsubject = ($values2subject);
$vtu = count($values22);
while($row = mysqli_fetch_assoc($result))
{  						
$values[] = $row['student_name']; 
$valuessubject[] = $row['subject']; 
$valuesclass[] = $row['class_name']; 
$valuesyear[] = $row['year']; 
$valuesterm[] = $row['term'];
$valuesarms[] = $row['arms']; 
}
$vtuu = count($values); // students
$vallue = $values;
current($valuessubject);

$b = current($valuessubject);
if($b == 'CRK'){
$b = "Crk";
}
current($valuesclass);
current($valuesyear);
current($valuesterm);
current($valuesarms);

$r = array_diff($vallue, $values22); 
$vtuuu = $vtuu - $vtu;
if($vtuuu < 1){
	echo "<span style='color:red; font-size:16px; text-decoration: underline;'>Either you have no students currently enrolled, or you have already inputed the scores for the students enrolled in your class under the selected criteria!</span><br>";
}else if($vtu == 0){
$resultmaxes = mysqli_query($db, "SELECT DISTINCT hwmaxname, cwmaxname, testmaxname FROM scoresmid WHERE subject='$subject' AND arms='$arms' AND teacher_name='$tna' AND class_name='$class' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$countresultmaxes = mysqli_num_rows($resultmaxes);
if($countresultmaxes<1){
echo '<div id="txtFirstNameall">';
echo '<input type="text" class="txtFirstName" placeholder="HOMEWORK MAX SCORES" id="txtFirstName" required /><br><br>';
echo '<input type="text" class="txtFirstName1" placeholder="CLASSWORK MAX SCORES" id="txtFirstName1" required /> <br><br>';
echo '<input type="text" class="txtFirstName2" placeholder="TEST MAX SCORES" id="txtFirstName2" required /> <br><br>';
echo '<button class="submit_button" style="background-color: green; color: white;" id="dosomething">Set Max Scores</button><br><br>';
echo '</div>';
echo '<button class="submit_button" style="background-color: green; color: white;" id="resetmaxes">Reset Max Scores</button>';
echo '<br>';
}
$values22[] = "nothingham";
$r = array_diff($vallue, $values22); 
echo '<span>Input Max Scores Obtainable.</span>';
echo '<br>';
echo '<form class="formid" id="formid">';
echo '<table id="example" class="display" cellspacing="0" width="100%">';
echo '<thead>';
echo '<tr>';
echo '<th>Student</th>';
echo '<th style="display: none;" >Total</th>';
echo '<th style="width: 7px;">Homework</th>';
echo '<th style="width: 7px;">Classwork</th>';
echo '<th style="width: 7px;">Test</th>';
echo '<th  style="display: none;">-</th>';
echo '<th>Remark</th>';
echo '<th  style="display: none;">-</th>';
echo '<th  style="display: none;">-</th>';
echo '<th  style="display: none;">-</th>';
echo '<th  style="display: none;">-</th>';
echo '<th  style="display: none;">-</th>';
echo '<th class="addafter2" style="display: none;">Subject</th>';
echo '</tr>';
echo '</thead>';
echo '<tfoot>';
echo '<tr>';
echo '<th>Student</th>';
echo '<th style="display: none;" >Total</th>';
echo '<th style="width: 7px;">Homework</th>';
echo '<th style="width: 7px;">Classwork</th>';
echo '<th style="width: 7px;">Test</th>';
echo '<th  style="display: none;">-</th>';
echo '<th>Remark</th>';
echo '<th  style="display: none;">-</th>';
echo '<th  style="display: none;">-</th>';
echo '<th  style="display: none;">-</th>';
echo '<th  style="display: none;">-</th>';
echo '<th  style="display: none;">-</th>';
echo '<th class="addafter2" style="display: none;">Subject</th>';
echo '</tr>';
echo '</tfoot>';
echo '<tbody>';
foreach ($r as $key => $r['student_name']) {
echo '<tr>';
echo '<td class="suname" style="text-align: center;"><input style="display: none;" class="tdinput" type="hidden" name="student_name[]" value="'.$r['student_name'].'" />'.$r['student_name'].'</td>';
echo '<td style="display: none;"><input style="text-align: center;" class="tdinput" type="text" placeholder="Total" name="score[]" id="score" /></td>'; 
echo '<td style="text-align: center; width: 8px;" class="mxname"><input class="tdinput" style="text-align: center; width: 90%;" type="text" placeholder="Homework" name="hw[]" id="hw" /></td>';
echo '<td style="text-align: center; width: 8px;" class="mxname"><input class="tdinput" style="text-align: center; width: 90%;" type="text" placeholder="Classwork" name="cw[]" id="cw" /></td>';
echo '<td style="text-align: center; width: 8px;" class="mxname"><input class="tdinput" style="text-align: center; width: 90%;" type="text" placeholder="Test" name="test[]" id="test" /></td>';
echo '<td style="display: none;"><input class="tdinput" type="text"  name="teacher_id[]" id="teacher_id" value="'.$tid.'" /></td>';
echo '<td class="mxname" style="width: 350px; height: 120px;" ><textarea style="width: 100%; height: 100%; margin-top: 2%;" class="tdinput" type="text"  name="remark[]" id="remark" placeholder="Remark" /></textarea></td>';
echo '<td style="display: none;"><input class="tdinput" type="text"  name="teacher[]" id="teacher" value="'.$tna.'" />';
echo '<td style="display: none;"><input class="tdinput" type="text"  name="class_name[]" id="class_name" value="'.current($valuesclass).'" /></td>';
echo '<td style="display: none;"><input class="tdinput" type="text"  name="year[]" id="year" value="'.current($valuesyear).'" /></td>';
echo '<td style="display: none;"><input class="tdinput" type="text"  name="arms[]" id="arms" value="'.current($valuesarms).'" /></td>';
echo '<td style="display: none;"><input class="tdinput" type="text"  name="term[]" id="term" value="'.current($valuesterm).'" /></td>';
echo '<td class="addafter" style="display: none;"><input type="text"  name="subject[]" id="subject" value="'.$b.'" /></td>';
echo '</tr>';
}
echo '</tbody>';
echo '</table>';	
echo '<div style="border: 0;">';
echo '<input type="submit" class="submit_button" name="submit" value="Submit Scores" id="submm" />';
echo '<label style="border: 0;">';
echo '<span class="error" style="display:none; color: red;"><img src="table/del.jpg" width="60" height="60"/>A submission error has just occurred.</span>';
echo '<span class="success" style="display:none; color: green;"><img src="table/492.png" width="60" height="60"/> Scores submitted successfully.</span>';
echo '</label>';
echo '</div>';
echo '</form>';		
}
else{
echo '<center>';
echo '<span style="color: green; font-size: 16px;">Add Scores of '.$b.' Students in '.$classd.' for '.current($valuesterm).', '.current($valuesyear).'</span><br />';	

$resultmaxes2 = mysqli_query($db, "SELECT DISTINCT hwmaxname, cwmaxname, testmaxname FROM scoresmid WHERE subject='$subject' AND arms='$arms' AND teacher_name='$tna' AND class_name='$class' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$countresultmaxes2 = mysqli_num_rows($resultmaxes2);
if($countresultmaxes2==1){
	while($rowmaxes2 = mysqli_fetch_assoc($resultmaxes2)){
echo '<div id="txtFirstNameall">';
echo '<span>Homework Max.:&nbsp;</span><input style="width: 50px;" type="text" class="txtFirstName" id="txtFirstName" value="'.$rowmaxes2['hwmaxname'].'" required />&nbsp;&nbsp;&nbsp;';
echo '<span>Classwork Max.:&nbsp;</span><input style="width: 50px;" type="text" class="txtFirstName1" id="txtFirstName1" value="'.$rowmaxes2['cwmaxname'].'" required="required" />&nbsp;&nbsp;&nbsp;';
echo '<span>Test Max.:&nbsp;</span><input style="width: 50px;" type="text" class="txtFirstName2" id="txtFirstName2" value="'.$rowmaxes2['testmaxname'].'" required="required" /> <br><br>';
echo '<button class="submit_button" style="background-color: green; color: white;" id="dosomething">Set Max Scores</button>';
echo '</div>';
echo '<div style="color: red;" id="resetmaxes">Go to update to reset max scores.</div>';
echo '<br>';
}}
echo '<form class="formid" id="formid">';
echo '<table id="example" class="display" cellspacing="0" width="100%">';
echo '<thead>';
echo '<tr>';
echo '<th>Student</th>';
echo '<th style="display: none;" >Total</th>';
echo '<th style="width: 7px;">Homework</th>';
echo '<th style="width: 7px;">Classwork</th>';
echo '<th style="width: 7px;">Test</th>';
echo '<th  style="display: none;">-</th>';
echo '<th>Remark</th>';
echo '<th  style="display: none;">-</th>';
echo '<th  style="display: none;">-</th>';
echo '<th  style="display: none;">-</th>';
echo '<th  style="display: none;">-</th>';
echo '<th  style="display: none;">-</th>';
echo '<th class="addafter2" style="display: none;">Subject</th>';
echo '</tr>';
echo '</thead>';
echo '<tfoot>';
echo '<tr>';
echo '<th>Student</th>';
echo '<th style="display: none;" >Total</th>';
echo '<th style="width: 7px;">Homework</th>';
echo '<th style="width: 7px;">Classwork</th>';
echo '<th style="width: 7px;">Test</th>';
echo '<th  style="display: none;">-</th>';
echo '<th>Remark</th>';
echo '<th  style="display: none;">-</th>';
echo '<th  style="display: none;">-</th>';
echo '<th  style="display: none;">-</th>';
echo '<th  style="display: none;">-</th>';
echo '<th  style="display: none;">-</th>';
echo '<th class="addafter2" style="display: none;">Subject</th>';
echo '</tr>';
echo '</tfoot>';
echo '<tbody>';
foreach ($r as $key => $r['student_name']) {
echo '<tr>';
echo '<td class="suname" style="text-align: center; width: 15%;"><input style="display: none;" class="tdinput" type="hidden" name="student_name[]" value="'.$r['student_name'].'" />'.$r['student_name'].'</td>';
echo '<td style="display: none;"><input style="text-align: center;" class="tdinput" type="text" placeholder="Total" name="score[]" id="score" /></td>'; 
echo '<td style="text-align: center; width: 10%;" class="mxname"><input class="tdinput" style="text-align: center; width: 90%;" type="text" placeholder="Homework" name="hw[]" id="hw" /></td>';
echo '<td style="text-align: center; width: 10%;" class="mxname"><input class="tdinput" style="text-align: center; width: 90%;" type="text" placeholder="Classwork" name="cw[]" id="cw" /></td>';
echo '<td style="text-align: center; width: 10%;" class="mxname"><input class="tdinput" style="text-align: center; width: 90%;" type="text" placeholder="Test" name="test[]" id="test" /></td>';
echo '<td style="display: none;"><input class="tdinput" type="text"  name="teacher_id[]" id="teacher_id" value="'.$tid.'" /></td>';
echo '<td class="mxname" style="width: 350px; height: 120px;"><textarea style="width: 100%; height: 100%; margin-top: 2%;"  class="tdinput" type="text"  name="remark[]" id="remark" placeholder="Remark" /></textarea></td>';
echo '<td style="display: none;"><input class="tdinput" type="text"  name="teacher[]" id="teacher" value="'.$tna.'" />';
echo '<td style="display: none;"><input class="tdinput" type="text"  name="class_name[]" id="class_name" value="'.current($valuesclass).'" /></td>';
echo '<td style="display: none;"><input class="tdinput" type="text"  name="year[]" id="year" value="'.current($valuesyear).'" /></td>';
echo '<td style="display: none;"><input class="tdinput" type="text"  name="arms[]" id="arms" value="'.current($valuesarms).'" /></td>';
echo '<td style="display: none;"><input class="tdinput" type="text"  name="term[]" id="term" value="'.current($valuesterm).'" /></td>';
echo '<td class="addafter" style="display: none;"><input type="text"  name="subject[]" id="subject" value="'.$b.'" /></td>';
echo '</tr>';
}
echo '</tbody>';
echo '</table>';	
echo '<div style="border: 0;">';
echo '<input type="submit" class="submit_button" name="submit" value="Submit Scores" id="submm" />';
echo '<div id="getprogress"></div>';
echo '<label style="border: 0;">';
echo '<span class="error" style="display:none; color: red;"><img src="table/del.jpg" width="60" height="60"/>A submission error has just occurred.</span>';
echo '<span class="success" style="display:none; color: green;"><img src="table/492.png" width="60" height="60"/> Scores submitted successfully.</span>';
echo '</label>';
echo '</div>';
echo '</form>';	
}
echo '</center>';
}
?>
<?php
include("footer.php");
?>
</body>
</html>