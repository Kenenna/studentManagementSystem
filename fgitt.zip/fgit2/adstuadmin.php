<?php 
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Add students</title>
<link rel="stylesheet" href="style.css" type="text/css" />
<link rel="stylesheet" href="css/style.css" />
	<script src="table/js/jquery.js" type="text/javascript"></script>
		<script src="datatablejs.js" type="text/javascript"></script>
	<link rel="stylesheet" type="text/css" href="datatablecss.css">
	 <link rel="stylesheet" type="text/css" href="datatablebuttoncss.css">
    <script type="text/javascript">
    $(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
		paging: false,
		scrollY: '550px',
        scrollCollapse: true,
        buttons: [
        {
            extend: 'colvis',
            columns: ':gt(1)'
        }
    ]
    });
	
$(".spanclass").click(function(){
var forthisform2 = this.id;
var forthisform = forthisform2.substr(12, forthisform2.length);
var showed = $("[id=checkspan"+forthisform+"]").attr("class");
if(showed == 0){
$("[id=form"+forthisform+"]").show(1000);
$("[id=checkspan"+forthisform+"]").attr("class","1");
$("[id=hideshowspan"+forthisform+"]").css("color","green").css("font-size", "16px");
showed = 1;
}else{
$("[id=form"+forthisform+"]").hide(1000);
$("[id=checkspan"+forthisform+"]").attr("class","0");
$("[id=hideshowspan"+forthisform+"]").css("color","red").css("font-size", "14px").css("font-weight", "bold");
showed = 0;	
}
});
	
$(".submit_button").click(function(){	
var forthisformsub2 = this.id;
var forthisformsub = forthisformsub2.substr(12, forthisformsub2.length);
$("[id=form"+forthisformsub+"]").submit(function(evy){
	evy.preventDefault();
	
	var caatext = $("[id=caa2_in_"+forthisformsub+"]").find(":selected").text();
	var caaval = caatext;
	
	var stnval = $("[id=student_name2_in_"+forthisformsub+"]").val();
	var sexval = $("[id=sex2_in_"+forthisformsub+"]").val();
	//var caaval = $("[id=caa2_in_"+forthisformsub+"]").val();
	var yoaval = $("[id=yoa2_in_"+forthisformsub+"]").val();
	var admnoval = $("[id=admno2_in_"+forthisformsub+"]").val();
	var reasonval = $("[id=reason2_in_"+forthisformsub+"]").val();
	var dobval = $("[id=dob2_in_"+forthisformsub+"]").val();
	var houseval = $("[id=house2_in_"+forthisformsub+"]").val();
	var dataStr = "student_name="+stnval+"&sex="+sexval+"&caa="+caaval+"&yoa="+yoaval+"&admno="+admnoval+"&reason="+reasonval+"&dob="+dobval+"&house="+houseval;
	//alert(dataStr);
$.ajax({
type: "POST",
url: "addstudentbyadmin_exec.php",
data: dataStr,
success: function(response){
 if(response==1) { 
		$(".success").fadeIn();
		setTimeout(function() { $(".success").fadeOut(); }, 3000); 
		
    } else {
		 $(".error").show();
		setTimeout(function() { $(".error").fadeOut(); }, 3000);
		}
		}
});	
});
});
	
});
    </script>
 <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
<style>
body{
	font-family: arial, sans-serif;
}
	li{
		list-style-type: none;
	}
	.clas{
	display: none;
    }
	.clase{
	display: block;
    }
	.spanclass{
	cursor: pointer;
	text-transform: uppercase;
	color: red;
	font-weight: bold;
	font-size: 14px;
	}
	.formclass{
	display: none;
	}
	.forcss{
	width: 120px;	
	}
	
	div.myselect {
  width: 160px;
}
input[type=date]{
  height: 35px;
  width: 140%;
  font-family: arial, sans-serif;
  font-size: 10px;
  font-weight: bold;
  text-transform: uppercase;
  outline: none;
  border: 0;
  border-radius: 3px;
}
nav li ul li{
    z-index: 1000;
    float: left;
}
</style>
  <script>
  $(document).ready(function() {
 var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>
  <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
</head>
<body>
<?php
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
else{ header("location: logout.php");}
?>

<br>
<?php
$resultreg = mysqli_query($db, "SELECT * FROM regstu WHERE school='".$_SESSION["school"]."'");
while ($rowreg = mysqli_fetch_assoc($resultreg)) {
$regstud[] = $rowreg['student_name'];
}

$result2 = mysqli_query($db, "SELECT teacher_id, teacher FROM users2 WHERE role='student' AND school='".$_SESSION["school"]."' ORDER BY teacher ASC");
while ($row = mysqli_fetch_assoc($result2)) {
	if(in_array($row['teacher'], $regstud)){
		echo "";
	}
	else{
	$tid[] = $row['teacher_id'];
	$stn[] = $row['teacher'];
	}
}
?>
<div class="row-fluid" style="width:100%;">
    <br><br>
<div class="span12">
<div class="container" style="width:100%;">		<br>	
<center>
<span class="error" style="display:none; color: red;">Insertion Failed: A student with the provided information may already exist.</span>
<span class="success" style="display:none; color: green;"> Insertion was Successful.</span>
</center>
<table style="width:100%;"cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">	
<thead><tr>
<th>Student</th>
</tr></thead>
<?php
$cccc = 1;
$cccc2 = 1;
for ($i = 0; $i <= (count($tid)-1); $i++){
echo '<tr><td>';
echo "<span class='spanclass' id='hideshowspan".$tid[$i]."'>".$stn[$i]."</span><span id='checkspan".$tid[$i]."' class='0'></span><br>";
echo '<form name="formid'.$tid[$i].'" class="formclass" id="form'.$tid[$i].'">';
echo '<input value="'.$tid[$i].'" style="display: none;" name="regstu_id" id="teacher_id2_in_'.$tid[$i].'" />';		
echo '<input type="text" style="display: none;" id="student_name2_in_'.$tid[$i].'" name="student_name" value="'.$stn[$i].'" />';
echo '<input placeholder="sex" type="text" class="forcss" name="sex" id="sex2_in_'.$tid[$i].'" /><br>';
echo '<select  id="caa2_in_'.$tid[$i].'" style="width: 120px;" class="forcss" name="caa" required >';
	$resultcl = mysqli_query($db, "SELECT * FROM classes");
						while($rowcl = mysqli_fetch_assoc($resultcl))
							{  
								//echo '<option value="'.$rowcl['class_name'].'">';
								echo '<option>';
								if($ctype=="Js"){	
								if($cccc <= 3){
								echo 'JS'.$cccc;	
								}
								elseif($cccc >= 4 && $cccc <= 6){
								echo 'SS'.($cccc2 - 3);	
								}else{
									break;
								}
								$cccc++;	
								$cccc2++;
									}
								else{	
								if($ctype=="Primary"){	
								echo 'Primary '.$cccc;
								if($cccc > 5){
									break;
								}
								$cccc++;	
								}
								else{
								echo 'Year '.$cccc;
								if($cccc > 11){
									break;
								}
								$cccc++;	
								}
								}//end of else
								echo '</option>';
								
							}
echo '</select>';
echo '<select name="yoa" id="yoa2_in_'.$tid[$i].'" required >';
	$resultyr = mysqli_query($db, "SELECT * FROM years");
						while($rowyr = mysqli_fetch_assoc($resultyr))
							{  
								echo '<option value="'.$rowyr['year'].'">';
								echo $rowyr['year'];
								echo '</option>';
							}

echo '</select></div><br>';
echo '<input id="admno2_in_'.$tid[$i].'" placeholder="admin no" class="forcss" type="text" name="admno" required/><br>';
echo '<input id="reason2_in_'.$tid[$i].'" class="forcss" placeholder="reason for leaving" type="text" name="reason" /><br><br>';
echo '<div class="myselect">';
echo '<input id="dob2_in_'.$tid[$i].'" style="width: 120px;" placeholder="DOB" type="date" name="dob" /><br>';
echo '</div>';
echo '<input id="house2_in_'.$tid[$i].'" class="forcss" placeholder="House" type="text" name="house" /><br>';
echo '<input type="submit" class="submit_button" name="formsub2_in_'.$tid[$i].'" id="formsub2_in_'.$tid[$i].'" value="Add Students" />';
echo '</form>';
echo '</td>';
echo '</tr>';
}
echo '</table>';
?>
</div></div></div>
<?php
include("footer.php");		
	?>
	</body>