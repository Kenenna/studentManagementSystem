<?php
session_start();
include("auth.php"); //include auth.php file on all secure pages
require_once("connection.php");
$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
							//echo $ctype;
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Get Result</title>
<script src="table/js/jquery.js" type="text/javascript"></script>
<script>
function printDiv(eleId){
    var PW = window.open('', '_blank', 'Print content');
	PW.document.write(document.getElementById(eleId).innerHTML);
    PW.document.close();
    PW.focus();
    PW.print();
    PW.close();
}
</script>
<style>
.pbutton {
	background-color:#44c767;
	-moz-border-radius:28px;
	-webkit-border-radius:28px;
	border-radius:2px;
	border:1px solid #18ab29;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:15px;
	padding:6px 24px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
	float: left;
}
.pbutton:hover {
	background-color:#5cbf2a;
}
.pbutton:active {
	position:relative;
	top:1px;
}
.pbutton2 {
	background-color:#44c767;
	-moz-border-radius:2px;
	-webkit-border-radius:28px;
	border-radius:28px;
	border:1px solid #18ab29;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:15px;
	padding:6px 24px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
}
.pbutton2:hover {
	background-color:#5cbf2a;
}
.pbutton2:active {
	position:relative;
	top:1px;
}
</style>
<style>
section {
    width: 80%;  
    margin: auto;
    padding: 8px;
}
div#one {
    width: 80%; 
    float: left;
}
div#two {
    margin-left: 1%;  
}

#section3 {
    width: 80%;  
    margin: auto;
    padding: 10px;
}
div#one3 {
    width: 50%; 
    float: left;
}
#heading{
	color: red;
}
</style>

<script>
$(document).ready(function() {	
$("#resultpdf").submit(function( evt ) {
			evt.preventDefault();
var countlist = $("#resultlist li").length;	
if(countlist > 0){
$(".liresultlist").fadeOut(500); 	
}		
$.ajax({
type: "POST",
url: "pdf4/examples/resultpdf.php",
cache: false,
beforeSend: function(){
	$("#loadit").addClass("loader");
	$("#loadit").after("<label id='forremoval' style='color: red;' >We are preparing your download. Please wait...</label>");
	$('#attpdfsubmit').attr( 'onClick', 'return false' );
	},
data: $("#resultpdf").serializeArray(),
success: function(response){
$("#forresultit").remove();		
$("#resultlist").append("<li class='liresultlist'><a class='pbutton2' style='margin: auto; text-align: center;' id='forresult' href='pdf4/examples/"+response+"' download>download your result</a></li>");	
},
complete: function(){
$("#loadit").removeClass("loader");	
$("#forremoval").remove();
$('#attpdfsubmit').attr( 'onClick', 'return true' );
}
});			
});

for(i=1; i<=193; i++){
	if($("#ttable td").eq(i).text()==0){
	$("#ttable td").eq(i).text("-");
	}
}

});
</script>
<script>
$(document).ready(function() {	
$("#maxscoreform").submit(function( evt ) {
			evt.preventDefault();	
$.ajax({
type: "POST",
url: "maxscore.php",
cache: false,
data: $("#maxscoreform").serializeArray(),
success: function(response){
alert(response);
}
});			
});
});
</script>
<style>
.loader {
  border: 8px solid #f3f3f3;
  border-radius: 50%;
  border-top: 8px solid blue;
  border-right: 8px solid green;
  border-bottom: 8px solid red;
  width: 20px;
  height: 20px;
  -webkit-animation: spin 2s linear infinite;
  animation: spin 2s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.dnone{
	display: none;
}
</style>
</head>
<body>
<br>
<?php
$student_name = $_POST['student_name'];	
$term = $_POST['term'];
$year = $_POST['year'];
$class = $_POST['class_name'];
$arms = $_POST['arms'];
 $queryres = "SELECT resvis FROM scores WHERE student_name='$student_name' AND class_name='$class' AND term='$term' AND year='$year' AND school='".$_SESSION["school"]."'";  
	 $resultres = mysqli_query($db, $queryres); 
	 while($rowres = mysqli_fetch_assoc($resultres))
	{
$rtres2[] = $rowres['resvis'];
	}
$rtres = current($rtres2);	
if($rtres==1){
?>
<div id="printMe">
<table style="width:90%; border-top:0; border-bottom: 1px solid red; margin:auto; padding:auto;">
<?php
$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsc = mysqli_fetch_assoc($resultsch))
							{  
								$school2[] = $rowsc['school'];
								$address2[] = $rowsc['address'];
								$tel2[] = $rowsc['tel'];
								$fax2[] = $rowsc['fax'];
								$email2[] = $rowsc['email'];
								$img2[] = $rowsc['img'];
							}
							$schooll = current($school2);
							$address = current($address2);
							$tel = current($tel2);
							$fax = current($fax2);
							$email = current($email2);
							$img = current($img2);

?>
<tr><td style="font-size:12px;"><?php echo '<img src="'.$img.'" align="left" height="60" width="100" />' ?>&nbsp;&nbsp;<?php echo strtoupper($schooll); ?><br>&nbsp;&nbsp;<?php echo strtoupper($address); ?><br>
&nbsp;&nbsp;Tel: <?php echo $tel; ?>; &nbsp;Fax: <?php echo $fax; ?>; &nbsp;Email: <?php echo $email; ?><span style="float:right;"><?php echo date("jS F, Y"); ?></span></td>
</tr></table>
<?php
if(isset($_POST['subbyclass3']) OR isset($_POST['submit3']) OR isset($_POST['submittoresult']) OR isset($_POST['submit8'])){
$term = $_POST['term'];
$year = $_POST['year'];
$class = $_POST['class_name'];
$arms = $_POST['arms'];

if(($ctype=="Js")OR($ctype=="Primary")){
$checkclass = mysqli_query($db, "SELECT * FROM classes where class_name='$class'");
while($rowcla = mysqli_fetch_assoc($checkclass)){
$cll2[] = $rowcla['class_name2'];
}
$class = current($cll2);
}else{
$class = $_POST['class_name'];	
}

if($term == 'First Term'){
echo '<table style="width:100%; text-align:center; font-weight:bold; font-size:14px;"><tr><td>RESULT SHEET FOR FIRST TERM, '.$year.'/'.($year+1).' SESSION</td></tr>';
echo '</table>';
}
else if($term == 'Second Term'){
echo '<table style="width:100%; text-align:center; font-weight:bold; font-size:14px;"><tr><td>RESULT SHEET FOR SECOND TERM, '.$year.'/'.($year+1).' SESSION</td></tr>';	
echo '</table>';
}
else{
echo '<table style="width:100%; text-align:center; font-weight:bold; font-size:14px;"><tr><td>RESULT SHEET FOR THIRD TERM, '.$year.'/'.($year+1).' SESSION</td></tr>';
echo '</table>';
}}


if(isset($_POST['subbyarm3'])){
$term = $_POST['term'];
$year = $_POST['year'];
$class = $_POST['class_name'];

if(($ctype=="Js")OR($ctype=="Primary")){
$checkclass = mysqli_query($db, "SELECT * FROM classes where class_name='$class'");
while($rowcla = mysqli_fetch_assoc($checkclass)){
$cll2[] = $rowcla['class_name2'];
}
$class = current($cll2);
}else{
$class = $_POST['class_name'];	
}

if($term == 'First Term'){
echo '<table style="width:100%; text-align:center; font-weight:bold; font-size:14px;"><tr><td>RESULT SHEET FOR FIRST TERM, '.$year.'/'.($year+1).' SESSION</td></tr>';
echo '</table>';
}
else if($term == 'Second Term'){
echo '<table style="width:100%; text-align:center; font-weight:bold; font-size:14px;"><tr><td>RESULT SHEET FOR SECOND TERM, '.$year.'/'.($year+1).' SESSION</td></tr>';	
echo '</table>';
}
else{
echo '<table style="width:100%; text-align:center; font-weight:bold; font-size:14px;"><tr><td>RESULT SHEET FOR THIRD TERM, '.$year.'/'.($year+1).' SESSION</td></tr>';
echo '</table>';
}}
?>
<?php 
if(isset($_POST['subbyclass3']) OR isset($_POST['submit3']) OR isset($_POST['submittoresult']) OR isset($_POST['submittoresulttochart'])){
$student_name = $_POST['student_name'];	
$term = $_POST['term'];
$year = $_POST['year'];
$class = $_POST['class_name'];
$sig = $_POST['sig'];
$arms = $_POST['arms'];
echo '<table style="width:90%; margin:auto; padding:auto; text-align:center; font-size: 10px;">';

if(($ctype=="Js")OR($ctype=="Primary")){
$checkclass2 = mysqli_query($db, "SELECT * FROM classes where class_name='$class'");
while($rowcla2 = mysqli_fetch_assoc($checkclass2)){
$cll4[] = $rowcla2['class_name2'];
}
$class = current($cll4);
}else{
$class = $_POST['class_name'];	
}


//include "connection.php";	
$student_name = $_POST['student_name'];
$resultpic = mysqli_query($db, "SELECT * FROM img WHERE student_name='$student_name' AND school='".$_SESSION["school"]."'");
						while($rowpic = mysqli_fetch_assoc($resultpic))
							{
$rpic[] = $rowpic['img'];							
}
$rpic2 = current($rpic);
$result3 = mysqli_query($db, "SELECT * FROM maxattname WHERE year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($row3 = mysqli_fetch_assoc($result3)) {
$termbegin1[] = $row3['termbegin'];	
}
$termbegin = current($termbegin1);
$resultall = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$termbegin') AND ((attend='present') OR (attend='absent')) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$attall = mysqli_num_rows($resultall);
$atall2 = $attall * 2;


$resultsex = mysqli_query($db, "SELECT * FROM regstu WHERE student_name='$student_name' AND school='".$_SESSION["school"]."'");
						while($rowsex = mysqli_fetch_assoc($resultsex))
							{
$rsex[] = $rowsex['sex'];
$rdob[] = $rowsex['dob'];	
$admno[] = $rowsex['admno'];					
}
$rsex2 = current($rsex);
$rdob2 = current($rdob);
$admno2 = current($admno);


$student_name = $_POST['student_name'];
$resultatt = mysqli_query($db, "SELECT datename FROM attend WHERE student_name='$student_name' AND attend='present' AND class='".$_POST['class_name']."' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$att2 = mysqli_num_rows($resultatt);
$att = $att2 ;	
//echo $class;	
?>
<tbody style="height: 13px;">
<tr>
<td>Student Name: <?php echo $student_name; ?></td>
<td>Admission No: <?php echo $admno2; ?></td>
<td>Sex: <?php echo $rsex2; ?></td>
<td rowspan="3"><?php echo '<img style="float:right;" src="'.$rpic2.'" height="60" width="80"/>' ?></td>  
</tr>
<tr>
<td>Class: <?php echo $class; if($arms==""){echo "";}else{echo " ".$arms;} ?></td>
<td>Term: <?php echo $term; ?></td>
<td>Session: <?php echo $year."/".($year+1)." Session"; ?></td>  
</tr>
<tr>
<td>No of Times Present: <?php echo $att; ?></td>
<td>No of Times School Open: <?php echo $atall2; ?></td>
<td>Date of Birth: <?php echo date("jS F, Y", strtotime($rdob2)); ?></td>
</tr>
</tbody>
</table>
<?php } ?>

<?php 
if(isset($_POST['subbyarm3']) OR isset($_POST['submit8'])){
$student_name = $_POST['student_name'];	
$term = $_POST['term'];
$year = $_POST['year'];
$class = $_POST['class_name'];
$sig = $_POST['sig'];
$arms = $_POST['arms'];

echo '<table style="width:90%; margin:auto; padding:auto; text-align:center; font-size: 10px;">';

if(($ctype=="Js")OR($ctype=="Primary")){
$checkclass2 = mysqli_query($db, "SELECT * FROM classes where class_name='$class'");
while($rowcla2 = mysqli_fetch_assoc($checkclass2)){
$cll4[] = $rowcla2['class_name2'];
}
$class = current($cll4);
}else{
$class = $_POST['class_name'];	
}
//include "connection.php";	
$student_name = $_POST['student_name'];
$resultpic = mysqli_query($db, "SELECT * FROM img WHERE student_name='$student_name' AND school='".$_SESSION["school"]."'");
						while($rowpic = mysqli_fetch_assoc($resultpic))
							{
$rpic[] = $rowpic['img'];							
}
$rpic2 = current($rpic);
$result3 = mysqli_query($db, "SELECT * FROM maxattname WHERE year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($row3 = mysqli_fetch_assoc($result3)) {
$termbegin1[] = $row3['termbegin'];	
}
$termbegin = current($termbegin1);
$resultall = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$termbegin') AND ((attend='present') OR (attend='absent')) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$attall = mysqli_num_rows($resultall);
$atall2 = $attall * 2;


$resultsex = mysqli_query($db, "SELECT * FROM regstu WHERE student_name='$student_name' AND school='".$_SESSION["school"]."'");
						while($rowsex = mysqli_fetch_assoc($resultsex))
							{
$rsex[] = $rowsex['sex'];
$rdob[] = $rowsex['dob'];	
$admno[] = $rowsex['admno'];					
}
$rsex2 = current($rsex);
$rdob2 = current($rdob);
$admno2 = current($admno);


$student_name = $_POST['student_name'];
$resultatt = mysqli_query($db, "SELECT datename FROM attend WHERE student_name='$student_name' AND attend='present' AND class='".$_POST['class_name']."' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$att2 = mysqli_num_rows($resultatt);
$att = $att2 ;	
	echo $class_name;
?>
<tbody style="height: 13px;">
<tr>
<td>Student Name: <?php echo $student_name; ?></td>
<td>Admission No: <?php echo $admno2; ?></td>
<td>Sex: <?php echo $rsex2; ?></td>
<td rowspan="3"><?php echo '<img style="float:right;" src="'.$rpic2.'" height="60" width="80"/>' ?></td>  
</tr>
<tr>
<td>Class: <?php echo $class; if($arms==""){echo "";}else{echo " ".$arms;} ?></td>
<td>Term: <?php echo $term; ?></td>
<td>Year: <?php echo $year; ?></td>  
</tr>
<tr>
<td>No of Times Present: <?php echo $att; ?></td>
<td>No of Times School Open: <?php echo $atall2; ?></td>
<td>Date of Birth: <?php echo date("jS F Y", strtotime($rdob2)); ?></td>
</tr>
</tbody>
</table>
<?php } ?>

<table id="ttable" style="width:90%; border: 1px solid black; margin:auto; padding:auto; text-align:center; font-size: 10px;" border="1">
<tr><td colspan="12" ><div style="color:red; font-size:12px; text-align:center;">CONGNITIVE ASSESSMENT</div></td></tr>
<?php
	if(isset($_POST['submittoresult'])){
		$su1 = $_POST['su2'];
		$su = unserialize(base64_decode($su1));
		$cc1 = $_POST['cc2'];
		$cc = unserialize(base64_decode($cc1));
		$dd1 = $_POST['dd2'];
		$dd = unserialize(base64_decode($dd1));
		$ca1 = $_POST['ca2'];
		$ca = unserialize(base64_decode($ca1));
		$exam1 = $_POST['exam2'];
		$exam = unserialize(base64_decode($exam1));
		$tt1 = $_POST['tt2'];
		$tt = unserialize(base64_decode($tt1));
		$av1 = $_POST['av2'];
		$av = unserialize(base64_decode($av1));
		$ccav1 = $_POST['ccav2'];
		$ccav = unserialize(base64_decode($ccav1));
		$grade1 = $_POST['grade2'];
		$grade = unserialize(base64_decode($grade1));
		$tn1 = $_POST['tn2'];
		$tn = unserialize(base64_decode($tn1));
		$re1 = $_POST['re2'];
		$re = unserialize(base64_decode($re1));
		$hs1 = $_POST['hs2'];
		$hs = unserialize(base64_decode($hs1));
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		$arms = $_POST['arms'];
	
for($i=0; $i<=(count($su)-1); $i++){
if($su[$i] == 'English'){							
	$resultmxbystunameeng1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='English' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeng1))
	{	
		$snm2eng1[] = $rsn['score'];
		$stin2eng[] = $rsn['student_name'];
	}
	$acengf = array_combine($stin2eng,$snm2eng1);
	$resultmxbystunameeng2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='English' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeng2))
	{	
		$snm2eng2[] = $rsn['score'];
	    $stin2eng2[] = $rsn['student_name'];
	}
	$acengs = array_combine($stin2eng2,$snm2eng2);
	$resultmxbystunameeng3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='English' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeng3))
	{	
		$snm2eng3[] = $rsn['score'];
		$stin2eng3[] = $rsn['student_name'];
	}
	$acengt = array_combine($stin2eng3,$snm2eng3);
	$arinall = array($acengf, $acengs, $acengt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acengkeys = (array_keys($largest_arr));
	
$foreng1 = array();
for($v=0; $v<=120; $v++){
$foreeng1[] = $snm2eng1[$v];
}
$foreng1 = $foreeng1;

$foreng2 = array();
for($v=0; $v<=120; $v++){
$foreeng2[] = $snm2eng2[$v];
}
$foreng2 = $foreeng2;

$foreng3 = array();
for($v=0; $v<=120; $v++){
$foreeng3[] = $snm2eng3[$v];
}
$foreng3 = $foreeng3;

$array_all_eng = array(array_filter($foreng1), array_filter($foreng2), array_filter($foreng3));
	$countingeng = 0;
	while($countingeng <= 120){
	if(count(array_column($array_all_eng, $countingeng)) == 3){
	$engf2[] = round(array_sum(array_column($array_all_eng, $countingeng))/3);
	}
	else if(count(array_column($array_all_eng, $countingeng)) == 2){
	$engf2[] = round(array_sum(array_column($array_all_eng, $countingeng))/2);
	}
	else if(count(array_column($array_all_eng, $countingeng)) == 1){
	$engf2[] = round(array_sum(array_column($array_all_eng, $countingeng))/1);
	}
	else{
	$engf2[] = round(array_sum(array_column($array_all_eng, $countingeng))/3);	
	}
	$countingeng++;
	}
	$engf = implode("-",array_filter($engf2));
	$engmx2 = explode("-",$engf);
	$engmx = max(explode("-",$engf));
	$stnameandscoreEng = array_combine($acengkeys,$engmx2);
	$maxinallsub = $engmx;	
	}
	else if($su[$i] == 'Mathematics'){
	$resultmxbystunamemat1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Mathematics' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemat1))
	{	
		$snm2mat1[] = $rsn['score'];
		$stin2mat[] = $rsn['student_name'];
	}
	$acmatf = array_combine($stin2mat,$snm2mat1);
	$resultmxbystunamemat2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Mathematics' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemat2))
	{	
		$snm2mat2[] = $rsn['score'];
	    $stin2mat2[] = $rsn['student_name'];
	}
	$acmats = array_combine($stin2mat2,$snm2mat2);
	$resultmxbystunamemat3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Mathematics' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemat3))
	{	
		$snm2mat3[] = $rsn['score'];
		$stin2mat3[] = $rsn['student_name'];
	}
	$acmatt = array_combine($stin2mat3,$snm2mat3);
	$arinall = array($acmatf, $acmats, $acmatt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acmatkeys = (array_keys($largest_arr));
	
$format1 = 	array($snm2mat1[0], $snm2mat1[1], $snm2mat1[2], $snm2mat1[3], $snm2mat1[4], $snm2mat1[5], $snm2mat1[6], $snm2mat1[7], $snm2mat1[8], $snm2mat1[9], $snm2mat1[10], $snm2mat1[11], $snm2mat1[12], $snm2mat1[13], $snm2mat1[14], $snm2mat1[15], $snm2mat1[16], $snm2mat1[17], $snm2mat1[18], $snm2mat1[19], 
		  $snm2mat1[20], $snm2mat1[21], $snm2mat1[22], $snm2mat1[23], $snm2mat1[24], $snm2mat1[25], $snm2mat1[26], $snm2mat1[27], $snm2mat1[28], $snm2mat1[29], $snm2mat1[30], $snm2mat1[31], $snm2mat1[32], $snm2mat1[33], $snm2mat1[34], $snm2mat1[35], $snm2mat1[36], $snm2mat1[37], $snm2mat1[38], $snm2mat1[39], 
		  $snm2mat1[40], $snm2mat1[41], $snm2mat1[42], $snm2mat1[43], $snm2mat1[44], $snm2mat1[45], $snm2mat1[46], $snm2mat1[47], $snm2mat1[48], $snm2mat1[49], $snm2mat1[50], $snm2mat1[51], $snm2mat1[52], $snm2mat1[53], $snm2mat1[54], $snm2mat1[55], $snm2mat1[56], $snm2mat1[57], $snm2mat1[58], $snm2mat1[59], 
		  $snm2mat1[60], $snm2mat1[61], $snm2mat1[62], $snm2mat1[63], $snm2mat1[64], $snm2mat1[65], $snm2mat1[66], $snm2mat1[67], $snm2mat1[68], $snm2mat1[69], $snm2mat1[70], $snm2mat1[71], $snm2mat1[72], $snm2mat1[73], $snm2mat1[74], $snm2mat1[75], $snm2mat1[76], $snm2mat1[77], $snm2mat1[78], $snm2mat1[79], 
		  $snm2mat1[80], $snm2mat1[81], $snm2mat1[82], $snm2mat1[83], $snm2mat1[84], $snm2mat1[85], $snm2mat1[86], $snm2mat1[87], $snm2mat1[88], $snm2mat1[89], $snm2mat1[90], $snm2mat1[91], $snm2mat1[92], $snm2mat1[93], $snm2mat1[94], $snm2mat1[95], $snm2mat1[96], $snm2mat1[97], $snm2mat1[98], $snm2mat1[99], 
		  $snm2mat1[100], $snm2mat1[101], $snm2mat1[102], $snm2mat1[103], $snm2mat1[104], $snm2mat1[105], $snm2mat1[106], $snm2mat1[107], $snm2mat1[108], $snm2mat1[109], $snm2mat1[110], $snm2mat1[111], $snm2mat1[112], $snm2mat1[113], $snm2mat1[114], $snm2mat1[115], $snm2mat1[116], $snm2mat1[117], $snm2mat1[118], $snm2mat1[119],
		  $snm2mat1[120]);
$format2 = 	array($snm2mat2[0], $snm2mat2[1], $snm2mat2[2], $snm2mat2[3], $snm2mat2[4], $snm2mat2[5], $snm2mat2[6], $snm2mat2[7], $snm2mat2[8], $snm2mat2[9], $snm2mat2[10], $snm2mat2[11], $snm2mat2[12], $snm2mat2[13], $snm2mat2[14], $snm2mat2[15], $snm2mat2[16], $snm2mat2[17], $snm2mat2[18], $snm2mat2[19], 
		  $snm2mat2[20], $snm2mat2[21], $snm2mat2[22], $snm2mat2[23], $snm2mat2[24], $snm2mat2[25], $snm2mat2[26], $snm2mat2[27], $snm2mat2[28], $snm2mat2[29], $snm2mat2[30], $snm2mat2[31], $snm2mat2[32], $snm2mat2[33], $snm2mat2[34], $snm2mat2[35], $snm2mat2[36], $snm2mat2[37], $snm2mat2[38], $snm2mat2[39], 
		  $snm2mat2[40], $snm2mat2[41], $snm2mat2[42], $snm2mat2[43], $snm2mat2[44], $snm2mat2[45], $snm2mat2[46], $snm2mat2[47], $snm2mat2[48], $snm2mat2[49], $snm2mat2[50], $snm2mat2[51], $snm2mat2[52], $snm2mat2[53], $snm2mat2[54], $snm2mat2[55], $snm2mat2[56], $snm2mat2[57], $snm2mat2[58], $snm2mat2[59],
		  $snm2mat2[60], $snm2mat2[61], $snm2mat2[62], $snm2mat2[63], $snm2mat2[64], $snm2mat2[65], $snm2mat2[66], $snm2mat2[67], $snm2mat2[68], $snm2mat2[69], $snm2mat2[70], $snm2mat2[71], $snm2mat2[72], $snm2mat2[73], $snm2mat2[74], $snm2mat2[75], $snm2mat2[76], $snm2mat2[77], $snm2mat2[78], $snm2mat2[79],
		  $snm2mat2[80], $snm2mat2[81], $snm2mat2[82], $snm2mat2[83], $snm2mat2[84], $snm2mat2[85], $snm2mat2[86], $snm2mat2[87], $snm2mat2[88], $snm2mat2[89], $snm2mat2[90], $snm2mat2[91], $snm2mat2[92], $snm2mat2[93], $snm2mat2[94], $snm2mat2[95], $snm2mat2[96], $snm2mat2[97], $snm2mat2[98], $snm2mat2[99],
		   $snm2mat2[100], $snm2mat2[101], $snm2mat2[102], $snm2mat2[103], $snm2mat2[104], $snm2mat2[105], $snm2mat2[106], $snm2mat2[107], $snm2mat2[108], $snm2mat2[109], $snm2mat2[110], $snm2mat2[111], $snm2mat2[112], $snm2mat2[113], $snm2mat2[114], $snm2mat2[115], $snm2mat2[116], $snm2mat2[117], $snm2mat2[118], $snm2mat2[119],
		  $snm2mat2[120]);
$format3 = 	array($snm2mat3[0], $snm2mat3[1], $snm2mat3[2], $snm2mat3[3], $snm2mat3[4], $snm2mat3[5], $snm2mat3[6], $snm2mat3[7], $snm2mat3[8], $snm2mat3[9], $snm2mat3[10], $snm2mat3[11], $snm2mat3[12], $snm2mat3[13], $snm2mat3[14], $snm2mat3[15], $snm2mat3[16], $snm2mat3[17], $snm2mat3[18], $snm2mat3[19],
		  $snm2mat3[20], $snm2mat3[21], $snm2mat3[22], $snm2mat3[23], $snm2mat3[24], $snm2mat3[25], $snm2mat3[26], $snm2mat3[27], $snm2mat3[28], $snm2mat3[29], $snm2mat3[30], $snm2mat3[31], $snm2mat3[32], $snm2mat3[33], $snm2mat3[34], $snm2mat3[35], $snm2mat3[36], $snm2mat3[37], $snm2mat3[38], $snm2mat3[39],
		  $snm2mat3[40], $snm2mat3[41], $snm2mat3[42], $snm2mat3[43], $snm2mat3[44], $snm2mat3[45], $snm2mat3[46], $snm2mat3[47], $snm2mat3[48], $snm2mat3[49], $snm2mat3[50], $snm2mat3[51], $snm2mat3[52], $snm2mat3[53], $snm2mat3[54], $snm2mat3[55], $snm2mat3[56], $snm2mat3[57], $snm2mat3[58], $snm2mat3[59],
		  $snm2mat3[60], $snm2mat3[61], $snm2mat3[62], $snm2mat3[63], $snm2mat3[64], $snm2mat3[65], $snm2mat3[66], $snm2mat3[67], $snm2mat3[68], $snm2mat3[69], $snm2mat3[70], $snm2mat3[71], $snm2mat3[72], $snm2mat3[73], $snm2mat3[74], $snm2mat3[75], $snm2mat3[76], $snm2mat3[77], $snm2mat3[78], $snm2mat3[79],
		  $snm2mat3[80], $snm2mat3[81], $snm2mat3[82], $snm2mat3[83], $snm2mat3[84], $snm2mat3[85], $snm2mat3[86], $snm2mat3[87], $snm2mat3[88], $snm2mat3[89], $snm2mat3[90], $snm2mat3[91], $snm2mat3[92], $snm2mat3[93], $snm2mat3[94], $snm2mat3[95], $snm2mat3[96], $snm2mat3[97], $snm2mat3[98], $snm2mat3[99],
		  $snm2mat3[100], $snm2mat3[101], $snm2mat3[102], $snm2mat3[103], $snm2mat3[104], $snm2mat3[105], $snm2mat3[106], $snm2mat3[107], $snm2mat3[108], $snm2mat3[109], $snm2mat3[110], $snm2mat3[111], $snm2mat3[112], $snm2mat3[113], $snm2mat3[114], $snm2mat3[115], $snm2mat3[116], $snm2mat3[117], $snm2mat3[118], $snm2mat3[119],
		  $snm2mat3[120]);	  
	$array_all_mat = array(array_filter($format1), array_filter($format2), array_filter($format3));
	$countingmat = 0;
	while($countingmat <= 120){
	if(count(array_column($array_all_mat, $countingmat)) == 3){
	$matf2[] = round(array_sum(array_column($array_all_mat, $countingmat))/3);
	}
	else if(count(array_column($array_all_mat, $countingmat)) == 2){
	$matf2[] = round(array_sum(array_column($array_all_mat, $countingmat))/2);
	}
	else if(count(array_column($array_all_mat, $countingmat)) == 1){
	$matf2[] = round(array_sum(array_column($array_all_mat, $countingmat))/1);
	}
	else{
	$matf2[] = round(array_sum(array_column($array_all_mat, $countingmat))/3);	
	}
	$countingmat++;
	}
	$matf = implode("-",array_filter($matf2));
	$matmx2 = explode("-",$matf);
	$matmx = max(explode("-",$matf));
	$stnameandscoreMat = array_combine($acmatkeys,$matmx2);
	$maxinallsub = $matmx;		
	}
	
	else if($su[$i] == 'French'){
	$resultmxbystunamefre1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='French' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefre1))
	{	
		$snm2fre1[] = $rsn['score'];
		$stin2fre[] = $rsn['student_name'];
	}
	$acfref = array_combine($stin2fre,$snm2fre1);
	$resultmxbystunamefre2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='French' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefre2))
	{	
		$snm2fre2[] = $rsn['score'];
	    $stin2fre2[] = $rsn['student_name'];
	}
	$acfres = array_combine($stin2fre2,$snm2fre2);
	$resultmxbystunamefre3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='French' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefre3))
	{	
		$snm2fre3[] = $rsn['score'];
		$stin2fre3[] = $rsn['student_name'];
	}
	$acfret = array_combine($stin2fre3,$snm2fre3);
	$arinall = array($acfref, $acfres, $acfret);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acfrekeys = (array_keys($largest_arr));
$forfre1 = 	array($snm2fre1[0], $snm2fre1[1], $snm2fre1[2], $snm2fre1[3], $snm2fre1[4], $snm2fre1[5], $snm2fre1[6], $snm2fre1[7], $snm2fre1[8], $snm2fre1[9], $snm2fre1[10], $snm2fre1[11], $snm2fre1[12], $snm2fre1[13], $snm2fre1[14], $snm2fre1[15], $snm2fre1[16], $snm2fre1[17], $snm2fre1[18], $snm2fre1[19], 
		  $snm2fre1[20], $snm2fre1[21], $snm2fre1[22], $snm2fre1[23], $snm2fre1[24], $snm2fre1[25], $snm2fre1[26], $snm2fre1[27], $snm2fre1[28], $snm2fre1[29], $snm2fre1[30], $snm2fre1[31], $snm2fre1[32], $snm2fre1[33], $snm2fre1[34], $snm2fre1[35], $snm2fre1[36], $snm2fre1[37], $snm2fre1[38], $snm2fre1[39], 
		  $snm2fre1[40], $snm2fre1[41], $snm2fre1[42], $snm2fre1[43], $snm2fre1[44], $snm2fre1[45], $snm2fre1[46], $snm2fre1[47], $snm2fre1[48], $snm2fre1[49], $snm2fre1[50], $snm2fre1[51], $snm2fre1[52], $snm2fre1[53], $snm2fre1[54], $snm2fre1[55], $snm2fre1[56], $snm2fre1[57], $snm2fre1[58], $snm2fre1[59], 
		  $snm2fre1[60], $snm2fre1[61], $snm2fre1[62], $snm2fre1[63], $snm2fre1[64], $snm2fre1[65], $snm2fre1[66], $snm2fre1[67], $snm2fre1[68], $snm2fre1[69], $snm2fre1[70], $snm2fre1[71], $snm2fre1[72], $snm2fre1[73], $snm2fre1[74], $snm2fre1[75], $snm2fre1[76], $snm2fre1[77], $snm2fre1[78], $snm2fre1[79], 
		  $snm2fre1[80], $snm2fre1[81], $snm2fre1[82], $snm2fre1[83], $snm2fre1[84], $snm2fre1[85], $snm2fre1[86], $snm2fre1[87], $snm2fre1[88], $snm2fre1[89], $snm2fre1[90], $snm2fre1[91], $snm2fre1[92], $snm2fre1[93], $snm2fre1[94], $snm2fre1[95], $snm2fre1[96], $snm2fre1[97], $snm2fre1[98], $snm2fre1[99], 
		  $snm2fre1[100], $snm2fre1[101], $snm2fre1[102], $snm2fre1[103], $snm2fre1[104], $snm2fre1[105], $snm2fre1[106], $snm2fre1[107], $snm2fre1[108], $snm2fre1[109], $snm2fre1[110], $snm2fre1[111], $snm2fre1[112], $snm2fre1[113], $snm2fre1[114], $snm2fre1[115], $snm2fre1[116], $snm2fre1[117], $snm2fre1[118], $snm2fre1[119],
		  $snm2fre1[120]);
$forfre2 = 	array($snm2fre2[0], $snm2fre2[1], $snm2fre2[2], $snm2fre2[3], $snm2fre2[4], $snm2fre2[5], $snm2fre2[6], $snm2fre2[7], $snm2fre2[8], $snm2fre2[9], $snm2fre2[10], $snm2fre2[11], $snm2fre2[12], $snm2fre2[13], $snm2fre2[14], $snm2fre2[15], $snm2fre2[16], $snm2fre2[17], $snm2fre2[18], $snm2fre2[19], 
		  $snm2fre2[20], $snm2fre2[21], $snm2fre2[22], $snm2fre2[23], $snm2fre2[24], $snm2fre2[25], $snm2fre2[26], $snm2fre2[27], $snm2fre2[28], $snm2fre2[29], $snm2fre2[30], $snm2fre2[31], $snm2fre2[32], $snm2fre2[33], $snm2fre2[34], $snm2fre2[35], $snm2fre2[36], $snm2fre2[37], $snm2fre2[38], $snm2fre2[39], 
		  $snm2fre2[40], $snm2fre2[41], $snm2fre2[42], $snm2fre2[43], $snm2fre2[44], $snm2fre2[45], $snm2fre2[46], $snm2fre2[47], $snm2fre2[48], $snm2fre2[49], $snm2fre2[50], $snm2fre2[51], $snm2fre2[52], $snm2fre2[53], $snm2fre2[54], $snm2fre2[55], $snm2fre2[56], $snm2fre2[57], $snm2fre2[58], $snm2fre2[59],
		  $snm2fre2[60], $snm2fre2[61], $snm2fre2[62], $snm2fre2[63], $snm2fre2[64], $snm2fre2[65], $snm2fre2[66], $snm2fre2[67], $snm2fre2[68], $snm2fre2[69], $snm2fre2[70], $snm2fre2[71], $snm2fre2[72], $snm2fre2[73], $snm2fre2[74], $snm2fre2[75], $snm2fre2[76], $snm2fre2[77], $snm2fre2[78], $snm2fre2[79],
		  $snm2fre2[80], $snm2fre2[81], $snm2fre2[82], $snm2fre2[83], $snm2fre2[84], $snm2fre2[85], $snm2fre2[86], $snm2fre2[87], $snm2fre2[88], $snm2fre2[89], $snm2fre2[90], $snm2fre2[91], $snm2fre2[92], $snm2fre2[93], $snm2fre2[94], $snm2fre2[95], $snm2fre2[96], $snm2fre2[97], $snm2fre2[98], $snm2fre2[99],
		   $snm2fre2[100], $snm2fre2[101], $snm2fre2[102], $snm2fre2[103], $snm2fre2[104], $snm2fre2[105], $snm2fre2[106], $snm2fre2[107], $snm2fre2[108], $snm2fre2[109], $snm2fre2[110], $snm2fre2[111], $snm2fre2[112], $snm2fre2[113], $snm2fre2[114], $snm2fre2[115], $snm2fre2[116], $snm2fre2[117], $snm2fre2[118], $snm2fre2[119],
		  $snm2fre2[120]);
$forfre3 = 	array($snm2fre3[0], $snm2fre3[1], $snm2fre3[2], $snm2fre3[3], $snm2fre3[4], $snm2fre3[5], $snm2fre3[6], $snm2fre3[7], $snm2fre3[8], $snm2fre3[9], $snm2fre3[10], $snm2fre3[11], $snm2fre3[12], $snm2fre3[13], $snm2fre3[14], $snm2fre3[15], $snm2fre3[16], $snm2fre3[17], $snm2fre3[18], $snm2fre3[19],
		  $snm2fre3[20], $snm2fre3[21], $snm2fre3[22], $snm2fre3[23], $snm2fre3[24], $snm2fre3[25], $snm2fre3[26], $snm2fre3[27], $snm2fre3[28], $snm2fre3[29], $snm2fre3[30], $snm2fre3[31], $snm2fre3[32], $snm2fre3[33], $snm2fre3[34], $snm2fre3[35], $snm2fre3[36], $snm2fre3[37], $snm2fre3[38], $snm2fre3[39],
		  $snm2fre3[40], $snm2fre3[41], $snm2fre3[42], $snm2fre3[43], $snm2fre3[44], $snm2fre3[45], $snm2fre3[46], $snm2fre3[47], $snm2fre3[48], $snm2fre3[49], $snm2fre3[50], $snm2fre3[51], $snm2fre3[52], $snm2fre3[53], $snm2fre3[54], $snm2fre3[55], $snm2fre3[56], $snm2fre3[57], $snm2fre3[58], $snm2fre3[59],
		  $snm2fre3[60], $snm2fre3[61], $snm2fre3[62], $snm2fre3[63], $snm2fre3[64], $snm2fre3[65], $snm2fre3[66], $snm2fre3[67], $snm2fre3[68], $snm2fre3[69], $snm2fre3[70], $snm2fre3[71], $snm2fre3[72], $snm2fre3[73], $snm2fre3[74], $snm2fre3[75], $snm2fre3[76], $snm2fre3[77], $snm2fre3[78], $snm2fre3[79],
		  $snm2fre3[80], $snm2fre3[81], $snm2fre3[82], $snm2fre3[83], $snm2fre3[84], $snm2fre3[85], $snm2fre3[86], $snm2fre3[87], $snm2fre3[88], $snm2fre3[89], $snm2fre3[90], $snm2fre3[91], $snm2fre3[92], $snm2fre3[93], $snm2fre3[94], $snm2fre3[95], $snm2fre3[96], $snm2fre3[97], $snm2fre3[98], $snm2fre3[99],
		  $snm2fre3[100], $snm2fre3[101], $snm2fre3[102], $snm2fre3[103], $snm2fre3[104], $snm2fre3[105], $snm2fre3[106], $snm2fre3[107], $snm2fre3[108], $snm2fre3[109], $snm2fre3[110], $snm2fre3[111], $snm2fre3[112], $snm2fre3[113], $snm2fre3[114], $snm2fre3[115], $snm2fre3[116], $snm2fre3[117], $snm2fre3[118], $snm2fre3[119],
		  $snm2fre3[120]);	  
	$array_all_fre = array(array_filter($forfre1), array_filter($forfre2), array_filter($forfre3));
	$countingfre = 0;
	while($countingfre <= 120){
	if(count(array_column($array_all_fre, $countingfre)) == 3){
	$fref2[] = round(array_sum(array_column($array_all_fre, $countingfre))/3);
	}
	else if(count(array_column($array_all_fre, $countingfre)) == 2){
	$fref2[] = round(array_sum(array_column($array_all_fre, $countingfre))/2);
	}
	else if(count(array_column($array_all_fre, $countingfre)) == 1){
	$fref2[] = round(array_sum(array_column($array_all_fre, $countingfre))/1);
	}
	else{
	$fref2[] = round(array_sum(array_column($array_all_fre, $countingfre))/3);	
	}
	$countingfre++;
	}
	$fref = implode("-",array_filter($fref2));
	$fremx2 = explode("-",$fref);
	$fremx = max(explode("-",$fref));
	$stnameandscoreFre = array_combine($acfrekeys,$fremx2);
	$maxinallsub = $fremx;		
	}
	else if($su[$i] == 'Agricultural Science'){
		$resultmxbystunameagr1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Agricultural Science' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameagr1))
	{	
		$snm2agr1[] = $rsn['score'];
		$stin2agr[] = $rsn['student_name'];
	}
	$acagrf = array_combine($stin2agr,$snm2agr1);
	$resultmxbystunameagr2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Agricultural Science' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameagr2))
	{	
		$snm2agr2[] = $rsn['score'];
	    $stin2agr2[] = $rsn['student_name'];
	}
	$acagrs = array_combine($stin2agr2,$snm2agr2);
	$resultmxbystunameagr3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Agricultural Science' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameagr3))
	{	
		$snm2agr3[] = $rsn['score'];
		$stin2agr3[] = $rsn['student_name'];
	}
	$acagrt = array_combine($stin2agr3,$snm2agr3);
	$arinall = array($acagrf, $acagrs, $acagrt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acagrkeys = (array_keys($largest_arr));
$foragr1 = 	array($snm2agr1[0], $snm2agr1[1], $snm2agr1[2], $snm2agr1[3], $snm2agr1[4], $snm2agr1[5], $snm2agr1[6], $snm2agr1[7], $snm2agr1[8], $snm2agr1[9], $snm2agr1[10], $snm2agr1[11], $snm2agr1[12], $snm2agr1[13], $snm2agr1[14], $snm2agr1[15], $snm2agr1[16], $snm2agr1[17], $snm2agr1[18], $snm2agr1[19], 
		  $snm2agr1[20], $snm2agr1[21], $snm2agr1[22], $snm2agr1[23], $snm2agr1[24], $snm2agr1[25], $snm2agr1[26], $snm2agr1[27], $snm2agr1[28], $snm2agr1[29], $snm2agr1[30], $snm2agr1[31], $snm2agr1[32], $snm2agr1[33], $snm2agr1[34], $snm2agr1[35], $snm2agr1[36], $snm2agr1[37], $snm2agr1[38], $snm2agr1[39], 
		  $snm2agr1[40], $snm2agr1[41], $snm2agr1[42], $snm2agr1[43], $snm2agr1[44], $snm2agr1[45], $snm2agr1[46], $snm2agr1[47], $snm2agr1[48], $snm2agr1[49], $snm2agr1[50], $snm2agr1[51], $snm2agr1[52], $snm2agr1[53], $snm2agr1[54], $snm2agr1[55], $snm2agr1[56], $snm2agr1[57], $snm2agr1[58], $snm2agr1[59], 
		  $snm2agr1[60], $snm2agr1[61], $snm2agr1[62], $snm2agr1[63], $snm2agr1[64], $snm2agr1[65], $snm2agr1[66], $snm2agr1[67], $snm2agr1[68], $snm2agr1[69], $snm2agr1[70], $snm2agr1[71], $snm2agr1[72], $snm2agr1[73], $snm2agr1[74], $snm2agr1[75], $snm2agr1[76], $snm2agr1[77], $snm2agr1[78], $snm2agr1[79], 
		  $snm2agr1[80], $snm2agr1[81], $snm2agr1[82], $snm2agr1[83], $snm2agr1[84], $snm2agr1[85], $snm2agr1[86], $snm2agr1[87], $snm2agr1[88], $snm2agr1[89], $snm2agr1[90], $snm2agr1[91], $snm2agr1[92], $snm2agr1[93], $snm2agr1[94], $snm2agr1[95], $snm2agr1[96], $snm2agr1[97], $snm2agr1[98], $snm2agr1[99], 
		  $snm2agr1[100], $snm2agr1[101], $snm2agr1[102], $snm2agr1[103], $snm2agr1[104], $snm2agr1[105], $snm2agr1[106], $snm2agr1[107], $snm2agr1[108], $snm2agr1[109], $snm2agr1[110], $snm2agr1[111], $snm2agr1[112], $snm2agr1[113], $snm2agr1[114], $snm2agr1[115], $snm2agr1[116], $snm2agr1[117], $snm2agr1[118], $snm2agr1[119],
		  $snm2agr1[120]);
$foragr2 = 	array($snm2agr2[0], $snm2agr2[1], $snm2agr2[2], $snm2agr2[3], $snm2agr2[4], $snm2agr2[5], $snm2agr2[6], $snm2agr2[7], $snm2agr2[8], $snm2agr2[9], $snm2agr2[10], $snm2agr2[11], $snm2agr2[12], $snm2agr2[13], $snm2agr2[14], $snm2agr2[15], $snm2agr2[16], $snm2agr2[17], $snm2agr2[18], $snm2agr2[19], 
		  $snm2agr2[20], $snm2agr2[21], $snm2agr2[22], $snm2agr2[23], $snm2agr2[24], $snm2agr2[25], $snm2agr2[26], $snm2agr2[27], $snm2agr2[28], $snm2agr2[29], $snm2agr2[30], $snm2agr2[31], $snm2agr2[32], $snm2agr2[33], $snm2agr2[34], $snm2agr2[35], $snm2agr2[36], $snm2agr2[37], $snm2agr2[38], $snm2agr2[39], 
		  $snm2agr2[40], $snm2agr2[41], $snm2agr2[42], $snm2agr2[43], $snm2fre2[44], $snm2agr2[45], $snm2agr2[46], $snm2agr2[47], $snm2agr2[48], $snm2agr2[49], $snm2agr2[50], $snm2agr2[51], $snm2agr2[52], $snm2agr2[53], $snm2agr2[54], $snm2agr2[55], $snm2agr2[56], $snm2agr2[57], $snm2agr2[58], $snm2agr2[59],
		  $snm2agr2[60], $snm2agr2[61], $snm2agr2[62], $snm2agr2[63], $snm2fre2[64], $snm2agr2[65], $snm2agr2[66], $snm2agr2[67], $snm2agr2[68], $snm2agr2[69], $snm2agr2[70], $snm2agr2[71], $snm2agr2[72], $snm2agr2[73], $snm2agr2[74], $snm2agr2[75], $snm2agr2[76], $snm2agr2[77], $snm2agr2[78], $snm2agr2[79],
		  $snm2agr2[80], $snm2agr2[81], $snm2agr2[82], $snm2agr2[83], $snm2fre2[84], $snm2agr2[85], $snm2agr2[86], $snm2agr2[87], $snm2agr2[88], $snm2agr2[89], $snm2agr2[90], $snm2agr2[91], $snm2agr2[92], $snm2agr2[93], $snm2agr2[94], $snm2agr2[95], $snm2agr2[96], $snm2agr2[97], $snm2agr2[98], $snm2agr2[99],
		   $snm2agr2[100], $snm2agr2[101], $snm2agr2[102], $snm2agr2[103], $snm2agr2[104], $snm2agr2[105], $snm2agr2[106], $snm2agr2[107], $snm2agr2[108], $snm2agr2[109], $snm2agr2[110], $snm2agr2[111], $snm2agr2[112], $snm2agr2[113], $snm2agr2[114], $snm2agr2[115], $snm2agr2[116], $snm2agr2[117], $snm2agr2[118], $snm2agr2[119],
		  $snm2agr2[120]);
$foragr3 = 	array($snm2agr3[0], $snm2agr3[1], $snm2agr3[2], $snm2agr3[3], $snm2agr3[4], $snm2agr3[5], $snm2agr3[6], $snm2agr3[7], $snm2agr3[8], $snm2agr3[9], $snm2agr3[10], $snm2agr3[11], $snm2agr3[12], $snm2agr3[13], $snm2agr3[14], $snm2agr3[15], $snm2agr3[16], $snm2agr3[17], $snm2agr3[18], $snm2agr3[19],
		  $snm2agr3[20], $snm2agr3[21], $snm2agr3[22], $snm2agr3[23], $snm2agr3[24], $snm2agr3[25], $snm2agr3[26], $snm2agr3[27], $snm2agr3[28], $snm2agr3[29], $snm2agr3[30], $snm2agr3[31], $snm2agr3[32], $snm2agr3[33], $snm2agr3[34], $snm2agr3[35], $snm2agr3[36], $snm2agr3[37], $snm2agr3[38], $snm2agr3[39], 
		  $snm2agr3[41], $snm2agr3[41], $snm2agr3[42], $snm2agr3[43], $snm2agr3[44], $snm2agr3[45], $snm2agr3[46], $snm2agr3[47], $snm2agr3[48], $snm2agr3[49], $snm2agr3[50], $snm2agr3[51], $snm2agr3[52], $snm2agr3[53], $snm2agr3[54], $snm2agr3[55], $snm2agr3[56], $snm2agr3[57], $snm2agr3[58], $snm2agr3[59],
		  $snm2agr3[60], $snm2agr3[61], $snm2agr3[62], $snm2agr3[63], $snm2agr3[64], $snm2agr3[65], $snm2agr3[66], $snm2agr3[67], $snm2agr3[68], $snm2agr3[69], $snm2agr3[70], $snm2agr3[71], $snm2agr3[72], $snm2agr3[73], $snm2agr3[74], $snm2agr3[75], $snm2agr3[76], $snm2agr3[77], $snm2agr3[78], $snm2agr3[79],
		  $snm2agr3[80], $snm2agr3[81], $snm2agr3[82], $snm2agr3[83], $snm2agr3[84], $snm2agr3[85], $snm2agr3[86], $snm2agr3[87], $snm2agr3[88], $snm2agr3[89], $snm2agr3[90], $snm2agr3[91], $snm2agr3[92], $snm2agr3[93], $snm2agr3[94], $snm2agr3[95], $snm2agr3[96], $snm2agr3[97], $snm2agr3[98], $snm2agr3[99],
		  $snm2agr3[100], $snm2agr3[101], $snm2agr3[102], $snm2agr3[103], $snm2agr3[104], $snm2agr3[105], $snm2agr3[106], $snm2agr3[107], $snm2agr3[108], $snm2agr3[109], $snm2agr3[110], $snm2agr3[111], $snm2agr3[112], $snm2agr3[113], $snm2agr3[114], $snm2agr3[115], $snm2agr3[116], $snm2agr3[117], $snm2agr3[118], $snm2agr3[119],
		  $snm2agr3[120]);	  
	$array_all_agr = array(array_filter($foragr1), array_filter($foragr2), array_filter($foragr3));
	$countingagr = 0;
	while($countingagr <= 120){
	if(count(array_column($array_all_agr, $countingagr)) == 3){
	$agrf2[] = round(array_sum(array_column($array_all_agr, $countingagr))/3);
	}
	else if(count(array_column($array_all_agr, $countingagr)) == 2){
	$agrf2[] = round(array_sum(array_column($array_all_agr, $countingagr))/2);
	}
	else if(count(array_column($array_all_agr, $countingagr)) == 1){
	$agrf2[] = round(array_sum(array_column($array_all_agr, $countingagr))/1);
	}
	else{
	$agrf2[] = round(array_sum(array_column($array_all_agr, $countingagr))/3);	
	}
	$countingagr++;
	}
	$agrf = implode("-",array_filter($agrf2));
	$agrmx2 = explode("-",$agrf);
	$agrmx = max(explode("-",$agrf));
	$stnameandscoreAgr = array_combine($acagrkeys,$agrmx2);
	$maxinallsub = $agrmx;	
	}
	else if($su[$i] == 'Basic Science'){
		$resultmxbystunamebas1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Basic Science' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebas1))
	{	
		$snm2bas1[] = $rsn['score'];
		$stin2bas[] = $rsn['student_name'];
	}
	$acbasf = array_combine($stin2bas,$snm2bas1);
	$resultmxbystunamebas2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Basic Science' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebas2))
	{	
		$snm2bas2[] = $rsn['score'];
	    $stin2bas2[] = $rsn['student_name'];
	}
	$acbass = array_combine($stin2bas2,$snm2bas2);
	$resultmxbystunamebas3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Basic Science' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebas3))
	{	
		$snm2bas3[] = $rsn['score'];
		$stin2bas3[] = $rsn['student_name'];
	}
	$acbast = array_combine($stin2bas3,$snm2bas3);
	$arinall = array($acbasf, $acbass, $acbast);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acbaskeys = (array_keys($largest_arr));
$forbas1 = 	array($snm2bas1[0], $snm2bas1[1], $snm2bas1[2], $snm2bas1[3], $snm2bas1[4], $snm2bas1[5], $snm2bas1[6], $snm2bas1[7], $snm2bas1[8], $snm2bas1[9], $snm2bas1[10], $snm2bas1[11], $snm2bas1[12], $snm2bas1[13], $snm2bas1[14], $snm2bas1[15], $snm2bas1[16], $snm2bas1[17], $snm2bas1[18], $snm2bas1[19], 
		  $snm2bas1[20], $snm2bas1[21], $snm2bas1[22], $snm2bas1[23], $snm2bas1[24], $snm2bas1[25], $snm2bas1[26], $snm2bas1[27], $snm2bas1[28], $snm2bas1[29], $snm2bas1[30], $snm2bas1[31], $snm2bas1[32], $snm2bas1[33], $snm2bas1[34], $snm2bas1[35], $snm2bas1[36], $snm2bas1[37], $snm2bas1[38], $snm2bas1[39], 
		  $snm2bas1[40], $snm2bas1[41], $snm2bas1[42], $snm2bas1[43], $snm2bas1[44], $snm2bas1[45], $snm2bas1[46], $snm2bas1[47], $snm2bas1[48], $snm2bas1[49], $snm2bas1[50], $snm2bas1[51], $snm2bas1[52], $snm2bas1[53], $snm2bas1[54], $snm2bas1[55], $snm2bas1[56], $snm2bas1[57], $snm2bas1[58], $snm2bas1[59], 
		  $snm2bas1[60], $snm2bas1[61], $snm2bas1[62], $snm2bas1[63], $snm2bas1[64], $snm2bas1[65], $snm2bas1[66], $snm2bas1[67], $snm2bas1[68], $snm2bas1[69], $snm2bas1[70], $snm2bas1[71], $snm2bas1[72], $snm2bas1[73], $snm2bas1[74], $snm2bas1[75], $snm2bas1[76], $snm2bas1[77], $snm2bas1[78], $snm2bas1[79], 
		  $snm2bas1[80], $snm2bas1[81], $snm2bas1[82], $snm2bas1[83], $snm2bas1[84], $snm2bas1[85], $snm2bas1[86], $snm2bas1[87], $snm2bas1[88], $snm2bas1[89], $snm2bas1[90], $snm2bas1[91], $snm2bas1[92], $snm2bas1[93], $snm2bas1[94], $snm2bas1[95], $snm2bas1[96], $snm2bas1[97], $snm2bas1[98], $snm2bas1[99], 
		  $snm2bas1[100], $snm2bas1[101], $snm2bas1[102], $snm2bas1[103], $snm2bas1[104], $snm2bas1[105], $snm2bas1[106], $snm2bas1[107], $snm2bas1[108], $snm2bas1[109], $snm2bas1[110], $snm2bas1[111], $snm2bas1[112], $snm2bas1[113], $snm2bas1[114], $snm2bas1[115], $snm2bas1[116], $snm2bas1[117], $snm2bas1[118], $snm2bas1[119], 
		  $snm2bas1[120]);
$forbas2 = 	array($snm2bas2[0], $snm2bas2[1], $snm2bas2[2], $snm2bas2[3], $snm2bas2[4], $snm2bas2[5], $snm2bas2[6], $snm2bas2[7], $snm2bas2[8], $snm2bas2[9], $snm2bas2[10], $snm2bas2[11], $snm2bas1[12], $snm2bas2[13], $snm2bas2[14], $snm2bas2[15], $snm2bas2[16], $snm2bas2[17], $snm2bas2[18], $snm2bas2[19], 
		  $snm2bas2[20], $snm2bas2[21], $snm2bas2[22], $snm2bas2[23], $snm2bas2[24], $snm2bas2[25], $snm2bas2[26], $snm2bas2[27], $snm2bas2[28], $snm2bas2[29], $snm2bas2[30], $snm2bas2[31], $snm2bas2[32], $snm2bas2[33], $snm2bas2[34], $snm2bas2[35], $snm2bas2[36], $snm2bas2[37], $snm2bas2[38], $snm2bas2[39], 
		  $snm2bas2[40], $snm2bas2[41], $snm2bas2[42], $snm2bas2[43], $snm2bas2[44], $snm2bas2[45], $snm2bas2[46], $snm2bas2[47], $snm2bas2[48], $snm2bas2[49], $snm2bas2[50], $snm2bas2[51], $snm2bas2[52], $snm2bas2[53], $snm2bas2[54], $snm2bas2[55], $snm2bas2[56], $snm2bas2[57], $snm2bas2[58], $snm2bas2[59], 
		  $snm2bas2[60], $snm2bas2[61], $snm2bas2[62], $snm2bas2[63], $snm2bas2[64], $snm2bas2[65], $snm2bas2[66], $snm2bas2[67], $snm2bas2[68], $snm2bas2[69], $snm2bas2[70], $snm2bas2[71], $snm2bas2[72], $snm2bas2[73], $snm2bas2[74], $snm2bas2[75], $snm2bas2[76], $snm2bas2[77], $snm2bas2[78], $snm2bas2[79], 
		  $snm2bas2[80], $snm2bas2[81], $snm2bas2[82], $snm2bas2[83], $snm2bas2[84], $snm2bas2[85], $snm2bas2[86], $snm2bas2[87], $snm2bas2[88], $snm2bas2[89], $snm2bas2[90], $snm2bas2[91], $snm2bas2[92], $snm2bas2[93], $snm2bas2[94], $snm2bas2[95], $snm2bas2[96], $snm2bas2[97], $snm2bas2[98], $snm2bas2[99], 
		  		  $snm2bas2[100], $snm2bas2[101], $snm2bas2[102], $snm2bas2[103], $snm2bas2[104], $snm2bas2[105], $snm2bas2[106], $snm2bas2[107], $snm2bas2[108], $snm2bas2[109], $snm2bas2[110], $snm2bas2[111], $snm2bas2[112], $snm2bas2[113], $snm2bas2[114], $snm2bas2[115], $snm2bas2[116], $snm2bas2[117], $snm2bas2[118], $snm2bas2[119], 
		  $snm2bas3[120]);
$forbas3 = 	array($snm2bas3[0], $snm2bas3[1], $snm2bas3[2], $snm2bas3[3], $snm2bas3[4], $snm2bas3[5], $snm2bas3[6], $snm2bas3[7], $snm2bas3[8], $snm2bas3[9], $snm2bas3[10], $snm2bas3[11], $snm2bas3[12], $snm2bas3[13], $snm2bas3[14], $snm2bas3[15], $snm2bas3[16], $snm2bas3[17], $snm2bas3[18], $snm2bas3[19],
		  $snm2bas3[20], $snm2bas3[21], $snm2bas3[22], $snm2bas3[23], $snm2bas3[24], $snm2bas3[25], $snm2bas3[26], $snm2bas3[27], $snm2bas3[28], $snm2bas3[29], $snm2bas3[30], $snm2bas3[31], $snm2bas3[32], $snm2bas3[33], $snm2bas3[34], $snm2bas3[35], $snm2bas3[36], $snm2bas3[37], $snm2bas3[38], $snm2bas3[39], 
		  $snm2bas3[40], $snm2bas3[41], $snm2bas3[42], $snm2bas3[43], $snm2bas3[44], $snm2bas3[45], $snm2bas3[46], $snm2bas3[47], $snm2bas3[48], $snm2bas3[49], $snm2bas3[50], $snm2bas3[51], $snm2bas3[52], $snm2bas3[53], $snm2bas3[54], $snm2bas3[55], $snm2bas3[56], $snm2bas3[57], $snm2bas3[58], $snm2bas3[69], 
		  $snm2bas3[60], $snm2bas3[61], $snm2bas3[62], $snm2bas3[63], $snm2bas3[64], $snm2bas3[65], $snm2bas3[66], $snm2bas3[67], $snm2bas3[68], $snm2bas3[69], $snm2bas3[70], $snm2bas3[71], $snm2bas3[72], $snm2bas3[73], $snm2bas3[74], $snm2bas3[75], $snm2bas3[76], $snm2bas3[77], $snm2bas3[78], $snm2bas3[79], 
		  $snm2bas3[80], $snm2bas3[81], $snm2bas3[82], $snm2bas3[83], $snm2bas3[84], $snm2bas3[85], $snm2bas3[86], $snm2bas3[87], $snm2bas3[88], $snm2bas3[89], $snm2bas3[90], $snm2bas3[91], $snm2bas3[92], $snm2bas3[93], $snm2bas3[94], $snm2bas3[95], $snm2bas3[96], $snm2bas3[97], $snm2bas3[98], $snm2bas3[99], 
		  $snm2bas3[100], $snm2bas3[101], $snm2bas3[102], $snm2bas3[103], $snm2bas3[104], $snm2bas3[105], $snm2bas3[106], $snm2bas3[107], $snm2bas3[108], $snm2bas3[109], $snm2bas3[110], $snm2bas3[111], $snm2bas3[112], $snm2bas3[113], $snm2bas3[114], $snm2bas3[115], $snm2bas3[116], $snm2bas3[117], $snm2bas3[118], $snm2bas3[119], 
		  $snm2bas3[120]);
	$array_all_bas = array(array_filter($forbas1), array_filter($forbas2), array_filter($forbas3));
	$countingbas = 0;
	while($countingbas <= 120){
	if(count(array_column($array_all_bas, $countingbas)) == 3){
	$basf2[] = round(array_sum(array_column($array_all_bas, $countingbas))/3);
	}
	else if(count(array_column($array_all_bas, $countingbas)) == 2){
	$basf2[] = round(array_sum(array_column($array_all_bas, $countingbas))/2);
	}
	else if(count(array_column($array_all_bas, $countingbas)) == 1){
	$basf2[] = round(array_sum(array_column($array_all_bas, $countingbas))/1);
	}
	else{
	$basf2[] = round(array_sum(array_column($array_all_bas, $countingbas))/3);	
	}
	$countingbas++;
	}
	$basf = implode("-",array_filter($basf2));
	$basmx2 = explode("-",$basf);
	$basmx = max(explode("-",$basf));
	$stnameandscoreBas = array_combine($acbaskeys,$basmx2);
	$maxinallsub = $basmx;		  
	}
	else if($su[$i] == 'Biology'){
		$resultmxbystunamebio1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Biology' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebio1))
	{	
		$snm2bio1[] = $rsn['score'];
		$stin2bio[] = $rsn['student_name'];
	}
	$acbiof = array_combine($stin2bio,$snm2bio1);
	$resultmxbystunamebio2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Biology' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebio2))
	{	
		$snm2bio2[] = $rsn['score'];
	    $stin2bio2[] = $rsn['student_name'];
	}
	$acbios = array_combine($stin2bio2,$snm2bio2);
	$resultmxbystunamebio3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Biology' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebio3))
	{	
		$snm2bio3[] = $rsn['score'];
		$stin2bio3[] = $rsn['student_name'];
	}
	$acbiot = array_combine($stin2bio3,$snm2bio3);
	$arinall = array($acbiof, $acbios, $acbiot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acbiokeys = (array_keys($largest_arr));
$forbio1 = 	array($snm2bio1[0], $snm2bio1[1], $snm2bio1[2], $snm2bio1[3], $snm2bio1[4], $snm2bio1[5], $snm2bio1[6], $snm2bio1[7], $snm2bio1[8], $snm2bio1[9], $snm2bio1[10], $snm2bio1[11], $snm2bio1[12], $snm2bio1[13], $snm2bio1[14], $snm2bio1[15], $snm2bio1[16], $snm2bio1[17], $snm2bio1[18], $snm2bio1[19], 
		$snm2bio1[20], $snm2bio1[21], $snm2bio1[22], $snm2bio1[23], $snm2bio1[24], $snm2bio1[25], $snm2bio1[26], $snm2bio1[27], $snm2bio1[28], $snm2bio1[29], $snm2bio1[30], $snm2bio1[31], $snm2bio1[32], $snm2bio1[33], $snm2bio1[34], $snm2bio1[35], $snm2bio1[36], $snm2bio1[37], $snm2bio1[38], $snm2bio1[39], 
		$snm2bio1[40], $snm2bio1[41], $snm2bio1[42], $snm2bio1[43], $snm2bio1[44], $snm2bio1[45], $snm2bio1[46], $snm2bio1[47], $snm2bio1[48], $snm2bio1[49], $snm2bio1[50], $snm2bio1[51], $snm2bio1[52], $snm2bio1[53], $snm2bio1[54], $snm2bio1[55], $snm2bio1[56], $snm2bio1[57], $snm2bio1[58], $snm2bio1[59], 
		$snm2bio1[60], $snm2bio1[61], $snm2bio1[62], $snm2bio1[63], $snm2bio1[64], $snm2bio1[65], $snm2bio1[66], $snm2bio1[67], $snm2bio1[68], $snm2bio1[69], $snm2bio1[70], $snm2bio1[71], $snm2bio1[72], $snm2bio1[73], $snm2bio1[74], $snm2bio1[75], $snm2bio1[76], $snm2bio1[77], $snm2bio1[78], $snm2bio1[79], 
		$snm2bio1[80], $snm2bio1[81], $snm2bio1[82], $snm2bio1[83], $snm2bio1[84], $snm2bio1[85], $snm2bio1[86], $snm2bio1[87], $snm2bio1[88], $snm2bio1[89], $snm2bio1[90], $snm2bio1[91], $snm2bio1[92], $snm2bio1[93], $snm2bio1[94], $snm2bio1[95], $snm2bio1[96], $snm2bio1[97], $snm2bio1[98], $snm2bio1[99], 
		$snm2bio1[100], $snm2bio1[101], $snm2bio1[102], $snm2bio1[103], $snm2bio1[104], $snm2bio1[105], $snm2bio1[106], $snm2bio1[107], $snm2bio1[108], $snm2bio1[109], $snm2bio1[110], $snm2bio1[111], $snm2bio1[112], $snm2bio1[113], $snm2bio1[114], $snm2bio1[115], $snm2bio1[116], $snm2bio1[117], $snm2bio1[118], $snm2bio1[119], 
		$snm2bio1[120]);
$forbio2 = 	array($snm2bio2[0], $snm2bio2[1], $snm2bio2[2], $snm2bio2[3], $snm2bio2[4], $snm2bio2[5], $snm2bio2[6], $snm2bio2[7], $snm2bio2[8], $snm2bio2[9], $snm2bio2[10], $snm2bio2[11], $snm2bio2[12], $snm2bio2[13], $snm2bio2[14], $snm2bio2[15], $snm2bio2[16], $snm2bio2[17], $snm2bio2[18], $snm2bio2[19], 
		$snm2bio2[20], $snm2bio2[21], $snm2bio2[22], $snm2bio2[23], $snm2bio2[24], $snm2bio2[25], $snm2bio2[26], $snm2bio2[27], $snm2bio2[28], $snm2bio2[29], $snm2bio2[30], $snm2bio2[31], $snm2bio2[32], $snm2bio2[33], $snm2bio2[34], $snm2bio2[35], $snm2bio2[36], $snm2bio2[37], $snm2bio2[38], $snm2bio2[39], 
		$snm2bio2[40], $snm2bio2[41], $snm2bio2[42], $snm2bio2[43], $snm2bio2[44], $snm2bio2[45], $snm2bio2[46], $snm2bio2[47], $snm2bio2[48], $snm2bio2[49], $snm2bio2[50], $snm2bio2[51], $snm2bio2[52], $snm2bio2[53], $snm2bio2[54], $snm2bio2[55], $snm2bio2[56], $snm2bio2[57], $snm2bio2[58], $snm2bio2[59], 
		$snm2bio2[60], $snm2bio2[61], $snm2bio2[62], $snm2bio2[63], $snm2bio2[64], $snm2bio2[65], $snm2bio2[66], $snm2bio2[67], $snm2bio2[68], $snm2bio2[69], $snm2bio2[70], $snm2bio2[71], $snm2bio2[72], $snm2bio2[73], $snm2bio2[74], $snm2bio2[75], $snm2bio2[76], $snm2bio2[77], $snm2bio2[78], $snm2bio2[79], 
		$snm2bio2[80], $snm2bio2[81], $snm2bio2[82], $snm2bio2[83], $snm2bio2[84], $snm2bio2[85], $snm2bio2[86], $snm2bio2[87], $snm2bio2[88], $snm2bio2[89], $snm2bio2[90], $snm2bio2[91], $snm2bio2[92], $snm2bio2[93], $snm2bio2[94], $snm2bio2[95], $snm2bio2[96], $snm2bio2[97], $snm2bio2[98], $snm2bio2[99], 
		$snm2bio2[100], $snm2bio2[101], $snm2bio2[102], $snm2bio2[103], $snm2bio2[104], $snm2bio2[105], $snm2bio2[106], $snm2bio2[107], $snm2bio2[108], $snm2bio2[109], $snm2bio2[110], $snm2bio2[111], $snm2bio2[112], $snm2bio2[113], $snm2bio2[114], $snm2bio2[115], $snm2bio2[116], $snm2bio2[117], $snm2bio2[118], $snm2bio2[119], 
		$snm2bio2[120]);
$forbio3 = 	array($snm2bio3[0], $snm2bio3[1], $snm2bio3[2], $snm2bio3[3], $snm2bio3[4], $snm2bio3[5], $snm2bio3[6], $snm2bio3[7], $snm2bio3[8], $snm2bio3[9], $snm2bio3[10], $snm2bio3[11], $snm2bio3[12], $snm2bio3[13], $snm2bio3[14], $snm2bio3[15], $snm2bio3[16], $snm2bio3[17], $snm2bio3[18], $snm2bio3[19], 
		$snm2bio3[20], $snm2bio3[21], $snm2bio3[22], $snm2bio3[23], $snm2bio3[24], $snm2bio3[25], $snm2bio3[26], $snm2bio3[27], $snm2bio3[28], $snm2bio3[29], $snm2bio3[30], $snm2bio3[31], $snm2bio3[32], $snm2bio3[33], $snm2bio3[34], $snm2bio3[35], $snm2bio3[36], $snm2bio3[37], $snm2bio3[38], $snm2bio3[39], 
		$snm2bio3[40], $snm2bio3[41], $snm2bio3[42], $snm2bio3[43], $snm2bio3[44], $snm2bio3[45], $snm2bio3[46], $snm2bio3[47], $snm2bio3[48], $snm2bio3[49], $snm2bio3[50], $snm2bio3[51], $snm2bio3[52], $snm2bio3[53], $snm2bio3[54], $snm2bio3[55], $snm2bio3[56], $snm2bio3[57], $snm2bio3[58], $snm2bio3[59], 
		$snm2bio3[60], $snm2bio3[61], $snm2bio3[62], $snm2bio3[63], $snm2bio3[64], $snm2bio3[65], $snm2bio3[66], $snm2bio3[67], $snm2bio3[68], $snm2bio3[69], $snm2bio3[70], $snm2bio3[71], $snm2bio3[72], $snm2bio3[73], $snm2bio3[74], $snm2bio3[75], $snm2bio3[76], $snm2bio3[77], $snm2bio3[78], $snm2bio3[79], 
		$snm2bio3[80], $snm2bio3[81], $snm2bio3[82], $snm2bio3[83], $snm2bio3[84], $snm2bio3[85], $snm2bio3[86], $snm2bio3[87], $snm2bio3[88], $snm2bio3[89], $snm2bio3[90], $snm2bio3[91], $snm2bio3[92], $snm2bio3[93], $snm2bio3[94], $snm2bio3[95], $snm2bio3[96], $snm2bio3[97], $snm2bio3[98], $snm2bio3[99], 
		$snm2bio3[100], $snm2bio3[101], $snm2bio3[102], $snm2bio3[103], $snm2bio3[104], $snm2bio3[105], $snm2bio3[106], $snm2bio3[107], $snm2bio3[108], $snm2bio3[109], $snm2bio3[110], $snm2bio3[111], $snm2bio3[112], $snm2bio3[113], $snm2bio3[114], $snm2bio3[115], $snm2bio3[116], $snm2bio3[117], $snm2bio3[118], $snm2bio3[119], 
		$snm2bio3[120]);
	$array_all_bio = array(array_filter($forbio1), array_filter($forbio2), array_filter($forbio3));
	$countingbio = 0;
	while($countingbio <= 120){
	if(count(array_column($array_all_bio, $countingbio)) == 3){
	$biof2[] = round(array_sum(array_column($array_all_bio, $countingbio))/3);
	}
	else if(count(array_column($array_all_bio, $countingbio)) == 2){
	$biof2[] = round(array_sum(array_column($array_all_bio, $countingbio))/2);
	}
	else if(count(array_column($array_all_bio, $countingbio)) == 1){
	$biof2[] = round(array_sum(array_column($array_all_bio, $countingbio))/1);
	}
	else{
	$biof2[] = round(array_sum(array_column($array_all_bio, $countingbio))/3);	
	}
	$countingbio++;
	}
	$biof = implode("-",array_filter($biof2));
	$biomx2 = explode("-",$biof);
	$biomx = max(explode("-",$biof));
	$stnameandscoreBio = array_combine($acbiokeys,$biomx2);
	$maxinallsub = $biomx;			
	}
	else if($su[$i] == 'Business Studies'){
		$resultmxbystunamebus1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Business Studies' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebus1))
	{	
		$snm2bus1[] = $rsn['score'];
		$stin2bus[] = $rsn['student_name'];
	}
	$acbusf = array_combine($stin2bus,$snm2bus1);
	$resultmxbystunamebus2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Business Studies' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebus2))
	{	
		$snm2bus2[] = $rsn['score'];
	    $stin2bus2[] = $rsn['student_name'];
	}
	$acbuss = array_combine($stin2bus2,$snm2bus2);
	$resultmxbystunamebus3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Business Studies' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebus3))
	{	
		$snm2bus3[] = $rsn['score'];
		$stin2bus3[] = $rsn['student_name'];
	}
	$acbust = array_combine($stin2bus3,$snm2bus3);
	$arinall = array($acbusf, $acbuss, $acbust);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acbuskeys = (array_keys($largest_arr));
$forbus1 = 	array($snm2bus1[0], $snm2bus1[1], $snm2bus1[2], $snm2bus1[3], $snm2bus1[4], $snm2bus1[5], $snm2bus1[6], $snm2bus1[7], $snm2bus1[8], $snm2bus1[9], $snm2bus1[10], $snm2bus1[11], $snm2bus1[12], $snm2bus1[13], $snm2bus1[14], $snm2bus1[15], $snm2bus1[16], $snm2bus1[17], $snm2bus1[18], $snm2bus1[19], 
		$snm2bus1[20], $snm2bus1[21], $snm2bus1[22], $snm2bus1[23], $snm2bus1[24], $snm2bus1[25], $snm2bus1[26], $snm2bus1[27], $snm2bus1[28], $snm2bus1[29], $snm2bus1[30], $snm2bus1[31], $snm2bus1[32], $snm2bus1[33], $snm2bus1[34], $snm2bus1[35], $snm2bus1[36], $snm2bus1[37], $snm2bus1[38], $snm2bus1[39], 
		$snm2bus1[40], $snm2bus1[41], $snm2bus1[42], $snm2bus1[43], $snm2bus1[44], $snm2bus1[45], $snm2bus1[46], $snm2bus1[47], $snm2bus1[48], $snm2bus1[49], $snm2bus1[50], $snm2bus1[51], $snm2bus1[52], $snm2bus1[53], $snm2bus1[54], $snm2bus1[55], $snm2bus1[56], $snm2bus1[57], $snm2bus1[58], $snm2bus1[59], 
		$snm2bus1[60], $snm2bio1[61], $snm2bus1[62], $snm2bus1[63], $snm2bus1[64], $snm2bus1[65], $snm2bus1[66], $snm2bus1[67], $snm2bus1[68], $snm2bus1[69], $snm2bus1[70], $snm2bus1[71], $snm2bus1[72], $snm2bus1[73], $snm2bus1[74], $snm2bus1[75], $snm2bus1[76], $snm2bus1[77], $snm2bus1[78], $snm2bus1[79], 
		$snm2bus1[80], $snm2bus1[81], $snm2bus1[82], $snm2bus1[83], $snm2bus1[84], $snm2bus1[85], $snm2bus1[86], $snm2bus1[87], $snm2bus1[88], $snm2bus1[89], $snm2bus1[90], $snm2bus1[91], $snm2bus1[92], $snm2bus1[93], $snm2bus1[94], $snm2bus1[95], $snm2bus1[96], $snm2bus1[97], $snm2bus1[98], $snm2bus1[99], 
		$snm2bus1[100], $snm2bus1[101], $snm2bus1[102], $snm2bus1[103], $snm2bus1[104], $snm2bus1[105], $snm2bus1[106], $snm2bus1[107], $snm2bus1[108], $snm2bus1[109], $snm2bus1[110], $snm2bus1[111], $snm2bus1[112], $snm2bus1[113], $snm2bus1[114], $snm2bus1[115], $snm2bus1[116], $snm2bus1[117], $snm2bus1[118], $snm2bus1[119], 
		$snm2bus1[120]);
$forbus2 = 	array($snm2bus2[0], $snm2bus2[1], $snm2bus2[2], $snm2bus2[3], $snm2bus2[4], $snm2bus2[5], $snm2bus2[6], $snm2bus2[7], $snm2bus2[8], $snm2bus2[9], $snm2bus2[10], $snm2bus2[11], $snm2bus2[12], $snm2bus2[13], $snm2bus2[14], $snm2bus2[15], $snm2bus2[16], $snm2bus2[17], $snm2bus2[18], $snm2bus2[19], 
		$snm2bus2[20], $snm2bus2[21], $snm2bus2[22], $snm2bus2[23], $snm2bus2[24], $snm2bus2[25], $snm2bus2[26], $snm2bus2[27], $snm2bus2[28], $snm2bus2[29], $snm2bus2[30], $snm2bus2[31], $snm2bus2[32], $snm2bus2[33], $snm2bus2[34], $snm2bus2[35], $snm2bus2[36], $snm2bus2[37], $snm2bus2[38], $snm2bus2[39], 
		$snm2bus2[40], $snm2bus2[41], $snm2bus2[42], $snm2bus2[43], $snm2bus2[44], $snm2bus2[45], $snm2bus2[46], $snm2bus2[47], $snm2bus2[48], $snm2bus2[49], $snm2bus2[50], $snm2bus2[51], $snm2bus2[52], $snm2bus2[53], $snm2bus2[54], $snm2bus2[55], $snm2bus2[56], $snm2bus2[57], $snm2bus2[58], $snm2bus2[59], 
		$snm2bus2[60], $snm2bus2[61], $snm2bus2[62], $snm2bus2[63], $snm2bus2[64], $snm2bus2[65], $snm2bus2[66], $snm2bus2[67], $snm2bus2[68], $snm2bus2[69], $snm2bus2[70], $snm2bus2[71], $snm2bus2[72], $snm2bus2[73], $snm2bus2[74], $snm2bus2[75], $snm2bus2[76], $snm2bus2[77], $snm2bus2[78], $snm2bus2[79], 
		$snm2bus2[80], $snm2bus2[81], $snm2bus2[82], $snm2bus2[83], $snm2bus2[84], $snm2bus2[85], $snm2bus2[86], $snm2bus2[87], $snm2bus2[88], $snm2bus2[89], $snm2bus2[90], $snm2bus2[91], $snm2bus2[92], $snm2bus2[93], $snm2bus2[94], $snm2bus2[95], $snm2bus2[96], $snm2bus2[97], $snm2bus2[98], $snm2bus2[99], 
		$snm2bus2[100], $snm2bus2[101], $snm2bus2[102], $snm2bus2[103], $snm2bus2[104], $snm2bus2[105], $snm2bus2[106], $snm2bus2[107], $snm2bus2[108], $snm2bus2[109], $snm2bus2[110], $snm2bus2[111], $snm2bus2[112], $snm2bus2[113], $snm2bus2[114], $snm2bus2[115], $snm2bus2[116], $snm2bus2[117], $snm2bus2[118], $snm2bus2[119], 
		$snm2bus2[120]);
$forbus3 = 	array($snm2bus3[0], $snm2bus3[1], $snm2bus3[2], $snm2bus3[3], $snm2bus3[4], $snm2bus3[5], $snm2bus3[6], $snm2bus3[7], $snm2bus3[8], $snm2bus3[9], $snm2bus3[10], $snm2bus3[11], $snm2bus3[12], $snm2bus3[13], $snm2bus3[14], $snm2bus3[15], $snm2bus3[16], $snm2bus3[17], $snm2bus3[18], $snm2bus3[19], 
		$snm2bus3[20], $snm2bus3[21], $snm2bus3[22], $snm2bus3[23], $snm2bus3[24], $snm2bus3[25], $snm2bus3[26], $snm2bus3[27], $snm2bus3[28], $snm2bus3[29], $snm2bus3[30], $snm2bus3[31], $snm2bus3[32], $snm2bus3[33], $snm2bus3[34], $snm2bus3[35], $snm2bus3[36], $snm2bus3[37], $snm2bus3[38], $snm2bus3[39], 
		$snm2bus3[40], $snm2bus3[41], $snm2bus3[42], $snm2bus3[43], $snm2bus3[44], $snm2bus3[45], $snm2bus3[46], $snm2bus3[47], $snm2bus3[48], $snm2bus3[49], $snm2bus3[50], $snm2bus3[51], $snm2bus3[52], $snm2bus3[53], $snm2bus3[54], $snm2bus3[55], $snm2bus3[56], $snm2bus3[57], $snm2bus3[58], $snm2bus3[59], 
		$snm2bus3[60], $snm2bus3[61], $snm2bus3[62], $snm2bus3[63], $snm2bus3[64], $snm2bus3[65], $snm2bus3[66], $snm2bus3[67], $snm2bus3[68], $snm2bus3[69], $snm2bus3[70], $snm2bus3[71], $snm2bus3[72], $snm2bus3[73], $snm2bus3[74], $snm2bus3[75], $snm2bus3[76], $snm2bus3[77], $snm2bus3[78], $snm2bus3[79], 
		$snm2bus3[80], $snm2bus3[81], $snm2bus3[82], $snm2bus3[83], $snm2bus3[84], $snm2bus3[85], $snm2bus3[86], $snm2bus3[87], $snm2bus3[88], $snm2bus3[89], $snm2bus3[90], $snm2bus3[91], $snm2bus3[92], $snm2bus3[93], $snm2bus3[94], $snm2bus3[95], $snm2bus3[96], $snm2bus3[97], $snm2bus3[98], $snm2bus3[99], 
		$snm2bus3[100], $snm2bus3[101], $snm2bus3[102], $snm2bus3[103], $snm2bus3[104], $snm2bus3[105], $snm2bus3[106], $snm2bus3[107], $snm2bus3[108], $snm2bus3[109], $snm2bus3[110], $snm2bus3[111], $snm2bus3[112], $snm2bus3[113], $snm2bus3[114], $snm2bus3[115], $snm2bus3[116], $snm2bus3[117], $snm2bus3[118], $snm2bus3[119], 
		$snm2bus3[120]);
	$array_all_bus = array(array_filter($forbus1), array_filter($forbus2), array_filter($forbus3));
	$countingbus = 0;
	while($countingbus <= 120){
	if(count(array_column($array_all_bus, $countingbus)) == 3){
	$busf2[] = round(array_sum(array_column($array_all_bus, $countingbus))/3);
	}
	else if(count(array_column($array_all_bus, $countingbus)) == 2){
	$busf2[] = round(array_sum(array_column($array_all_bus, $countingbus))/2);
	}
	else if(count(array_column($array_all_bus, $countingbus)) == 1){
	$busf2[] = round(array_sum(array_column($array_all_bus, $countingbus))/1);
	}
	else{
	$busf2[] = round(array_sum(array_column($array_all_bus, $countingbus))/3);	
	}
	$countingbus++;
	}
	$busf = implode("-",array_filter($busf2));
	$busmx2 = explode("-",$busf);
	$busmx = max(explode("-",$busf));
	$stnameandscoreBus = array_combine($acbuskeys,$busmx2);
	$maxinallsub = $busmx;			
	}
	else if($su[$i] == 'Catering'){
		$resultmxbystunamecat1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Catering' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecat1))
	{	
		$snm2cat1[] = $rsn['score'];
		$stin2cat[] = $rsn['student_name'];
	}
	$accatf = array_combine($stin2cat,$snm2cat1);
	$resultmxbystunamecat2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Catering' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecat2))
	{	
		$snm2cat2[] = $rsn['score'];
	    $stin2cat2[] = $rsn['student_name'];
	}
	$accats = array_combine($stin2cat2,$snm2cat2);
	$resultmxbystunamecat3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Catering' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecat3))
	{	
		$snm2cat3[] = $rsn['score'];
		$stin2cat3[] = $rsn['student_name'];
	}
	$accatt = array_combine($stin2cat3,$snm2cat3);
	$arinall = array($accatf, $accats, $accatt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$accatkeys = (array_keys($largest_arr));
	
$forcat1 = array();
for($v=0; $v<=120; $v++){
$forccat1[] = $snm2cat1[$v];
}
$forcat1 = $forccat1;

$forcat2 = array();
for($v=0; $v<=120; $v++){
$forccat2[] = $snm2cat2[$v];
}
$forcat2 = $forccat2;

$forcat3 = array();
for($v=0; $v<=120; $v++){
$forccat3[] = $snm2cat3[$v];
}
$forcat3 = $forccat3;

	$array_all_cat = array(array_filter($forcat1), array_filter($forcat2), array_filter($forcat3));
	$countingcat = 0;
	while($countingcat <= 120){
	if(count(array_column($array_all_cat, $countingcat)) == 3){
	$catf2[] = round(array_sum(array_column($array_all_cat, $countingcat))/3);
	}
	else if(count(array_column($array_all_cat, $countingcat)) == 2){
	$catf2[] = round(array_sum(array_column($array_all_cat, $countingcat))/2);
	}
	else if(count(array_column($array_all_cat, $countingcat)) == 1){
	$catf2[] = round(array_sum(array_column($array_all_cat, $countingcat))/1);
	}
	else{
	$catf2[] = round(array_sum(array_column($array_all_cat, $countingcat))/3);	
	}
	$countingcat++;
	}
	$catf = implode("-",array_filter($catf2));
	$catmx2 = explode("-",$catf);
	$catmx = max(explode("-",$catf));
	$stnameandscoreCat = array_combine($accatkeys,$catmx2);
	$maxinallsub = $catmx;			
	}
	else if($su[$i] == 'Chemistry'){
		$resultmxbystunameche1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Chemistry' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameche1))
	{	
		$snm2che1[] = $rsn['score'];
		$stin2che[] = $rsn['student_name'];
	}
	$acchef = array_combine($stin2che,$snm2che1);
	$resultmxbystunameche2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Chemistry' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameche2))
	{	
		$snm2che2[] = $rsn['score'];
	    $stin2che2[] = $rsn['student_name'];
	}
	$acches = array_combine($stin2che2,$snm2che2);
	$resultmxbystunameche3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Chemistry' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameche3))
	{	
		$snm2che3[] = $rsn['score'];
		$stin2che3[] = $rsn['student_name'];
	}
	$acchet = array_combine($stin2che3,$snm2che3);
	$arinall = array($acchef, $acches, $acchet);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acchekeys = (array_keys($largest_arr));
	
$forche1 = array();
for($v=0; $v<=120; $v++){
$forcche1[] = $snm2che1[$v];
}
$forche1 = $forcche1;

$forche2 = array();
for($v=0; $v<=120; $v++){
$forcche2[] = $snm2che2[$v];
}
$forche2 = $forcche2;

$forche3 = array();
for($v=0; $v<=120; $v++){
$forcche3[] = $snm2che3[$v];
}
$forche3 = $forcche3;

	$array_all_che = array(array_filter($forche1), array_filter($forche2), array_filter($forche3));
	$countingche = 0;
	while($countingche <= 120){
	if(count(array_column($array_all_che, $countingche)) == 3){
	$chef2[] = round(array_sum(array_column($array_all_che, $countingche))/3);
	}
	else if(count(array_column($array_all_che, $countingche)) == 2){
	$chef2[] = round(array_sum(array_column($array_all_che, $countingche))/2);
	}
	else if(count(array_column($array_all_che, $countingche)) == 1){
	$chef2[] = round(array_sum(array_column($array_all_che, $countingche))/1);
	}
	else{
	$chef2[] = round(array_sum(array_column($array_all_che, $countingche))/3);	
	}
	$countingche++;
	}
	$chef = implode("-",array_filter($chef2));
	$chemx2 = explode("-",$chef);
	$chemx = max(explode("-",$chef));
	$stnameandscoreChe = array_combine($acchekeys,$chemx2);
	$maxinallsub = $chemx;			
	}
	else if($su[$i] == 'Civic Education'){
		$resultmxbystunameciv1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Civic Education' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameciv1))
	{	
		$snm2civ1[] = $rsn['score'];
		$stin2civ[] = $rsn['student_name'];
	}
	$accivf = array_combine($stin2civ,$snm2civ1);
	$resultmxbystunameciv2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Civic Education' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameciv2))
	{	
		$snm2civ2[] = $rsn['score'];
	    $stin2civ2[] = $rsn['student_name'];
	}
	$accivs = array_combine($stin2civ2,$snm2civ2);
	$resultmxbystunameciv3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Civic Education' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameciv3))
	{	
		$snm2civ3[] = $rsn['score'];
		$stin2civ3[] = $rsn['student_name'];
	}
	$accivt = array_combine($stin2civ3,$snm2civ3);
	$arinall = array($accivf, $accivs, $accivt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$accivkeys = (array_keys($largest_arr));
	
$forciv1 = array();
for($v=0; $v<=120; $v++){
$forcciv1[] = $snm2civ1[$v];
}
$forciv1 = $forcciv1;

$forciv2 = array();
for($v=0; $v<=120; $v++){
$forcciv2[] = $snm2civ2[$v];
}
$forciv2 = $forcciv2;

$forciv3 = array();
for($v=0; $v<=120; $v++){
$forcciv3[] = $snm2civ3[$v];
}
$forciv3 = $forcciv3;

	$array_all_civ = array(array_filter($forciv1), array_filter($forciv2), array_filter($forciv3));
	$countingciv = 0;
	while($countingciv <= 120){
	if(count(array_column($array_all_civ, $countingciv)) == 3){
	$civf2[] = round(array_sum(array_column($array_all_civ, $countingciv))/3);
	}
	else if(count(array_column($array_all_civ, $countingciv)) == 2){
	$civf2[] = round(array_sum(array_column($array_all_civ, $countingciv))/2);
	}
	else if(count(array_column($array_all_civ, $countingciv)) == 1){
	$civf2[] = round(array_sum(array_column($array_all_civ, $countingciv))/1);
	}
	else{
	$civf2[] = round(array_sum(array_column($array_all_civ, $countingciv))/3);	
	}
	$countingciv++;
	}
	$civf = implode("-",array_filter($civf2));
	$civmx2 = explode("-",$civf);
	$civmx = max(explode("-",$civf));
	$stnameandscoreCiv = array_combine($accivkeys,$civmx2);
	$maxinallsub = $civmx;			
	}
	
	else if($su[$i] == 'Creative and Cultural Arts'){
		$resultmxbystunamecca1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Creative and Cultural Arts' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecca1))
	{	
		$snm2cca1[] = $rsn['score'];
		$stin2cca[] = $rsn['student_name'];
	}
	$acccaf = array_combine($stin2cca,$snm2cca1);
	$resultmxbystunamecca2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Creative and Cultural Arts' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecca2))
	{	
		$snm2cca2[] = $rsn['score'];
	    $stin2cca2[] = $rsn['student_name'];
	}
	$acccas = array_combine($stin2cca2,$snm2cca2);
	$resultmxbystunamecca3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Creative and Cultural Arts Studies' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecca3))
	{	
		$snm2cca3[] = $rsn['score'];
		$stin2cca3[] = $rsn['student_name'];
	}
	$acccat = array_combine($stin2cca3,$snm2cca3);
	$arinall = array($acccaf, $acccas, $acccat);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acccakeys = (array_keys($largest_arr));
	
$forcca1 = array();
$forcca2 = array();
$forcca3 = array();
for($v=0; $v<=120; $v++){
$forccca1[] = $snm2cca1[$v];
$forccca2[] = $snm2cca2[$v];
$forccca3[] = $snm2cca3[$v];
}
$forcca1 = $forccca1;
$forcca2 = $forccca2;
$forcca3 = $forccca3;

	$array_all_cca = array(array_filter($forcca1), array_filter($forcca2), array_filter($forcca3));
	$countingcca = 0;
	while($countingcca <= 120){
	if(count(array_column($array_all_cca, $countingcca)) == 3){
	$ccaf2[] = round(array_sum(array_column($array_all_cca, $countingcca))/3);
	}
	else if(count(array_column($array_all_cca, $countingcca)) == 2){
	$ccaf2[] = round(array_sum(array_column($array_all_cca, $countingcca))/2);
	}
	else if(count(array_column($array_all_cca, $countingcca)) == 1){
	$ccaf2[] = round(array_sum(array_column($array_all_cca, $countingcca))/1);
	}
	else{
	$ccaf2[] = round(array_sum(array_column($array_all_cca, $countingcca))/3);	
	}
	$countingcca++;
	}
	$ccaf = implode("-",array_filter($ccaf2));
	$ccamx2 = explode("-",$ccaf);
	$ccamx = max(explode("-",$ccaf));
	$stnameandscoreCca = array_combine($acccakeys,$ccamx2);
	$maxinallsub = $ccamx;			
	}
	
	else if($su[$i] == 'CRK'){
		$resultmxbystunamecrk1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='CRK' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecrk1))
	{	
		$snm2crk1[] = $rsn['score'];
		$stin2crk[] = $rsn['student_name'];
	}
	$accrkf = array_combine($stin2crk,$snm2crk1);
	$resultmxbystunamecrk2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='CRK' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecrk2))
	{	
		$snm2crk2[] = $rsn['score'];
	    $stin2crk2[] = $rsn['student_name'];
	}
	$accrks = array_combine($stin2crk2,$snm2crk2);
	$resultmxbystunamecrk3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='CRK' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecrk3))
	{	
		$snm2crk3[] = $rsn['score'];
		$stin2crk3[] = $rsn['student_name'];
	}
	$accrkt = array_combine($stin2crk3,$snm2crk3);
	$arinall = array($accrkf, $accrks, $accrkt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$accrkkeys = (array_keys($largest_arr));
	
$forcrk1 = array();
for($v=0; $v<=120; $v++){
$forccrk1[] = $snm2crk1[$v];
}
$forcrk1 = $forccrk1;

$forcrk2 = array();
for($v=0; $v<=120; $v++){
$forccrk2[] = $snm2crk2[$v];
}
$forcrk2 = $forccrk2;

$forcrk3 = array();
for($v=0; $v<=120; $v++){
$forccrk3[] = $snm2crk3[$v];
}
$forcrk3 = $forccrk3;

	$array_all_crk = array(array_filter($forcrk1), array_filter($forcrk2), array_filter($forcrk3));
	$countingcrk = 0;
	while($countingcrk <= 120){
	if(count(array_column($array_all_crk, $countingcrk)) == 3){
	$crkf2[] = round(array_sum(array_column($array_all_crk, $countingcrk))/3);
	}
	else if(count(array_column($array_all_crk, $countingcrk)) == 2){
	$crkf2[] = round(array_sum(array_column($array_all_crk, $countingcrk))/2);
	}
	else if(count(array_column($array_all_crk, $countingcrk)) == 1){
	$crkf2[] = round(array_sum(array_column($array_all_crk, $countingcrk))/1);
	}
	else{
	$crkf2[] = round(array_sum(array_column($array_all_crk, $countingcrk))/3);	
	}
	$countingcrk++;
	}
	$crkf = implode("-",array_filter($crkf2));
	$crkmx2 = explode("-",$crkf);
	$crkmx = max(explode("-",$crkf));
	$stnameandscoreCrk = array_combine($accrkkeys,$crkmx2);
	$maxinallsub = $crkmx;			
	}
		else if($su[$i] == 'Economics'){
		$resultmxbystunameeco1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Economics' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeco1))
	{	
		$snm2eco1[] = $rsn['score'];
		$stin2eco[] = $rsn['student_name'];
	}
	$acecof = array_combine($stin2eco,$snm2eco1);
	$resultmxbystunameeco2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Economics' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeco2))
	{	
		$snm2eco2[] = $rsn['score'];
	    $stin2eco2[] = $rsn['student_name'];
	}
	$acecos = array_combine($stin2eco2,$snm2eco2);
	$resultmxbystunameeco3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Economics' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeco3))
	{	
		$snm2eco3[] = $rsn['score'];
		$stin2eco3[] = $rsn['student_name'];
	}
	$acecot = array_combine($stin2eco3,$snm2eco3);
	$arinall = array($acecof, $acecos, $acecot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acecokeys = (array_keys($largest_arr));
	
$foreco1 = array();
$foreco2 = array();
$foreco3 = array();
for($v=0; $v<=120; $v++){
$foreeco1[] = $snm2eco1[$v];
$foreeco2[] = $snm2eco2[$v];
$foreeco3[] = $snm2eco3[$v];
}
$foreco1 = $foreeco1;
$foreco2 = $foreeco2;
$foreco3 = $foreeco3;

	$array_all_eco = array(array_filter($foreco1), array_filter($foreco2), array_filter($foreco3));
	$countingeco = 0;
	while($countingeco <= 120){
	if(count(array_column($array_all_eco, $countingeco)) == 3){
	$ecof2[] = round(array_sum(array_column($array_all_eco, $countingeco))/3);
	}
	else if(count(array_column($array_all_eco, $countingeco)) == 2){
	$ecof2[] = round(array_sum(array_column($array_all_eco, $countingeco))/2);
	}
	else if(count(array_column($array_all_eco, $countingeco)) == 1){
	$ecof2[] = round(array_sum(array_column($array_all_eco, $countingeco))/1);
	}
	else{
	$ecof2[] = round(array_sum(array_column($array_all_eco, $countingeco))/3);	
	}
	$countingeco++;
	}
	$ecof = implode("-",array_filter($ecof2));
	$ecomx2 = explode("-",$ecof);
	$ecomx = max(explode("-",$ecof));
	$stnameandscoreEco = array_combine($acecokeys,$ecomx2);
	$maxinallsub = $ecomx;			
	}
	else if($su[$i] == 'Financial Accounting'){
		$resultmxbystunamefin1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Financial Accounting' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefin1))
	{	
		$snm2fin1[] = $rsn['score'];
		$stin2fin[] = $rsn['student_name'];
	}
	$acfinf = array_combine($stin2fin,$snm2fin1);
	$resultmxbystunamefin2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Financial Accounting' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefin2))
	{	
		$snm2fin2[] = $rsn['score'];
	    $stin2fin2[] = $rsn['student_name'];
	}
	$acfins = array_combine($stin2fin2,$snm2fin2);
	$resultmxbystunamefin3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Financial Accounting' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefin3))
	{	
		$snm2fin3[] = $rsn['score'];
		$stin2fin3[] = $rsn['student_name'];
	}
	$acfint = array_combine($stin2fin3,$snm2fin3);
	$arinall = array($acfinf, $acfins, $acfint);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acfinkeys = (array_keys($largest_arr));
	
$forfin1 = array();
$forfin2 = array();
$forfin3 = array();
for($v=0; $v<=120; $v++){
$forffin1[] = $snm2fin1[$v];
$forffin2[] = $snm2fin2[$v];
$forffin3[] = $snm2fin3[$v];
}
$forfin1 = $forffin1;
$forfin2 = $forffin2;
$forfin3 = $forffin3;

	$array_all_fin = array(array_filter($forfin1), array_filter($forfin2), array_filter($forfin3));
	$countingfin = 0;
	while($countingfin <= 120){
	if(count(array_column($array_all_fin, $countingfin)) == 3){
	$finf2[] = round(array_sum(array_column($array_all_fin, $countingfin))/3);
	}
	else if(count(array_column($array_all_fin, $countingfin)) == 2){
	$finf2[] = round(array_sum(array_column($array_all_fin, $countingfin))/2);
	}
	else if(count(array_column($array_all_fin, $countingfin)) == 1){
	$finf2[] = round(array_sum(array_column($array_all_fin, $countingfin))/1);
	}
	else{
	$finf2[] = round(array_sum(array_column($array_all_fin, $countingfin))/3);	
	}
	$countingfin++;
	}
	$finf = implode("-",array_filter($finf2));
	$finmx2 = explode("-",$finf);
	$finmx = max(explode("-",$finf));
	$stnameandscoreFin = array_combine($acfinkeys,$finmx2);
	$maxinallsub = $finmx;			
	}
		else if($su[$i] == 'Music'){
		$resultmxbystunamemus1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Music' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemus1))
	{	
		$snm2mus1[] = $rsn['score'];
		$stin2mus[] = $rsn['student_name'];
	}
	$acmusf = array_combine($stin2mus,$snm2mus1);
	$resultmxbystunamemus2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Music' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemus2))
	{	
		$snm2mus2[] = $rsn['score'];
	    $stin2mus2[] = $rsn['student_name'];
	}
	$acmuss = array_combine($stin2mus2,$snm2mus2);
	$resultmxbystunamemus3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Music' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemus3))
	{	
		$snm2mus3[] = $rsn['score'];
		$stin2mus3[] = $rsn['student_name'];
	}
	$acmust = array_combine($stin2mus3,$snm2mus3);
	$arinall = array($acmusf, $acmuss, $acmust);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acmuskeys = (array_keys($largest_arr));
	
$formus1 = array();
$formus2 = array();
$formus3 = array();
for($v=0; $v<=120; $v++){
$formmus1[] = $snm2mus1[$v];
$formmus2[] = $snm2mus2[$v];
$formmus3[] = $snm2mus3[$v];
}
$formus1 = $formmus1;
$formus2 = $formmus2;
$formus3 = $formmus3;

	$array_all_mus = array(array_filter($formus1), array_filter($formus2), array_filter($formus3));
	$countingmus = 0;
	while($countingmus <= 120){
	if(count(array_column($array_all_mus, $countingmus)) == 3){
	$musf2[] = round(array_sum(array_column($array_all_mus, $countingmus))/3);
	}
	else if(count(array_column($array_all_mus, $countingmus)) == 2){
	$musf2[] = round(array_sum(array_column($array_all_mus, $countingmus))/2);
	}
	else if(count(array_column($array_all_mus, $countingmus)) == 1){
	$musf2[] = round(array_sum(array_column($array_all_mus, $countingmus))/1);
	}
	else{
	$musf2[] = round(array_sum(array_column($array_all_mus, $countingmus))/3);	
	}
	$countingmus++;
	}
	$musf = implode("-",array_filter($musf2));
	$musmx2 = explode("-",$musf);
	$musmx = max(explode("-",$musf));
	$stnameandscoreMus = array_combine($acmuskeys,$musmx2);
	$maxinallsub = $musmx;			
	}
		else if($su[$i] == 'Food and Nutrition'){
		$resultmxbystunamefoo1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Food and Nutrition' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefoo1))
	{	
		$snm2foo1[] = $rsn['score'];
		$stin2foo[] = $rsn['student_name'];
	}
	$acfoof = array_combine($stin2foo,$snm2foo1);
	$resultmxbystunamefoo2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Food and Nutrition' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefoo2))
	{	
		$snm2foo2[] = $rsn['score'];
	    $stin2foo2[] = $rsn['student_name'];
	}
	$acfoos = array_combine($stin2foo2,$snm2foo2);
	$resultmxbystunamefoo3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Food and Nutrition' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefoo3))
	{	
		$snm2foo3[] = $rsn['score'];
		$stin2foo3[] = $rsn['student_name'];
	}
	$acfoot = array_combine($stin2foo3,$snm2foo3);
	$arinall = array($acfoof, $acfoos, $acfoot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acfookeys = (array_keys($largest_arr));
	
$forfoo1 = array();
$forfoo2 = array();
$forfoo3 = array();
for($v=0; $v<=120; $v++){
$forffoo1[] = $snm2foo1[$v];
$forffoo2[] = $snm2foo2[$v];
$forffoo3[] = $snm2foo3[$v];
}
$forfoo1 = $forffoo1;
$forfoo2 = $forffoo2;
$forfoo3 = $forffoo3;

	$array_all_foo = array(array_filter($forfoo1), array_filter($forfoo2), array_filter($forfoo3));
	$countingfoo = 0;
	while($countingfoo <= 120){
	if(count(array_column($array_all_foo, $countingfoo)) == 3){
	$foof2[] = round(array_sum(array_column($array_all_foo, $countingfoo))/3);
	}
	else if(count(array_column($array_all_foo, $countingfoo)) == 2){
	$foof2[] = round(array_sum(array_column($array_all_foo, $countingfoo))/2);
	}
	else if(count(array_column($array_all_foo, $countingfoo)) == 1){
	$foof2[] = round(array_sum(array_column($array_all_foo, $countingfoo))/1);
	}
	else{
	$foof2[] = round(array_sum(array_column($array_all_foo, $countingfoo))/3);	
	}
	$countingfoo++;
	}
	$foof = implode("-",array_filter($foof2));
	$foomx2 = explode("-",$foof);
	$foomx = max(explode("-",$foof));
	$stnameandscoreFoo = array_combine($acfookeys,$foomx2);
	$maxinallsub = $foomx;			
	}
		else if($su[$i] == 'Government'){
		$resultmxbystunamegov1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Government' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegov1))
	{	
		$snm2gov1[] = $rsn['score'];
		$stin2gov[] = $rsn['student_name'];
	}
	$acgovf = array_combine($stin2gov,$snm2gov1);
	$resultmxbystunamegov2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Government' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegov2))
	{	
		$snm2gov2[] = $rsn['score'];
	    $stin2gov2[] = $rsn['student_name'];
	}
	$acgovs = array_combine($stin2gov2,$snm2gov2);
	$resultmxbystunamegov3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Government' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegov3))
	{	
		$snm2gov3[] = $rsn['score'];
		$stin2gov3[] = $rsn['student_name'];
	}
	$acgovt = array_combine($stin2gov3,$snm2gov3);
	$arinall = array($acgovf, $acgovs, $acgovt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acgovkeys = (array_keys($largest_arr));
	
$forgov1 = array();
$forgov2 = array();
$forgov3 = array();
for($v=0; $v<=120; $v++){
$forggov1[] = $snm2gov1[$v];
$forggov2[] = $snm2gov2[$v];
$forggov3[] = $snm2gov3[$v];
}
$forgov1 = $forggov1;
$forgov2 = $forggov2;
$forgov3 = $forggov3;

	$array_all_gov = array(array_filter($forgov1), array_filter($forgov2), array_filter($forgov3));
	$countinggov = 0;
	while($countinggov <= 120){
	if(count(array_column($array_all_gov, $countinggov)) == 3){
	$govf2[] = round(array_sum(array_column($array_all_gov, $countinggov))/3);
	}
	else if(count(array_column($array_all_gov, $countinggov)) == 2){
	$govf2[] = round(array_sum(array_column($array_all_gov, $countinggov))/2);
	}
	else if(count(array_column($array_all_gov, $countinggov)) == 1){
	$govf2[] = round(array_sum(array_column($array_all_gov, $countinggov))/1);
	}
	else{
	$govf2[] = round(array_sum(array_column($array_all_gov, $countinggov))/3);	
	}
	$countinggov++;
	}
	$govf = implode("-",array_filter($govf2));
	$govmx2 = explode("-",$govf);
	$govmx = max(explode("-",$govf));
	$stnameandscoreGov = array_combine($acgovkeys,$govmx2);
	$maxinallsub = $govmx;			
	}
	else if($su[$i] == 'Hausa'){
		$resultmxbystunamehau1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Hausa' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehau1))
	{	
		$snm2hau1[] = $rsn['score'];
		$stin2hau[] = $rsn['student_name'];
	}
	$achauf = array_combine($stin2hau,$snm2hau1);
	$resultmxbystunamehau2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Hausa' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehau2))
	{	
		$snm2hau2[] = $rsn['score'];
	    $stin2hau2[] = $rsn['student_name'];
	}
	$achaus = array_combine($stin2hau2,$snm2hau2);
	$resultmxbystunamehau3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Hausa' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehau3))
	{	
		$snm2hau3[] = $rsn['score'];
		$stin2hau3[] = $rsn['student_name'];
	}
	$achaut = array_combine($stin2hau3,$snm2hau3);
	$arinall = array($achauf, $achaus, $achaut);
	//print_r($arinall);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$achaukeys = (array_keys($largest_arr));
	
$forhau1 = array();
$forhau2 = array();
$forhau3 = array();
for($v=0; $v<=120; $v++){
$forhhau1[] = $snm2hau1[$v];
$forhhau2[] = $snm2hau2[$v];
$forhhau3[] = $snm2hau3[$v];
}
$forhau1 = $forhhau1;
$forhau2 = $forhhau2;
$forhau3 = $forhhau3;
//print_r($array_all_irs);

	$array_all_hau = array(array_filter($forhau1), array_filter($forhau2), array_filter($forhau3));
	$countinghau = 0;
	while($countinghau <= 120){
	if(count(array_column($array_all_hau, $countinghau)) == 3){
	$hauf2[] = round(array_sum(array_column($array_all_hau, $countinghau))/3);
	}
	else if(count(array_column($array_all_hau, $countinghau)) == 2){
	$hauf2[] = round(array_sum(array_column($array_all_hau, $countinghau))/2);
	}
	else if(count(array_column($array_all_hau, $countinghau)) == 1){
	$hauf2[] = round(array_sum(array_column($array_all_hau, $countinghau))/1);
	}
	else{
	$hauf2[] = round(array_sum(array_column($array_all_hau, $countinghau))/3);	
	}
	$countinghau++;
	}
	$hauf = implode("-",array_filter($hauf2));
	$haumx2 = explode("-",$hauf);
	$haumx = max(explode("-",$hauf));
	$stnameandscoreHau = array_combine($achaukeys,$haumx2);
	$maxinallsub = $haumx;			
	}
	else if($su[$i] == 'History'){
		$resultmxbystunamehis1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='History' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehis1))
	{	
		$snm2his1[] = $rsn['score'];
		$stin2his[] = $rsn['student_name'];
	}
	$achisf = array_combine($stin2his,$snm2his1);
	$resultmxbystunamehis2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='History' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehis2))
	{	
		$snm2his2[] = $rsn['score'];
	    $stin2his2[] = $rsn['student_name'];
	}
	$achiss = array_combine($stin2his2,$snm2his2);
	$resultmxbystunamehis3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='History' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehis3))
	{	
		$snm2his3[] = $rsn['score'];
		$stin2his3[] = $rsn['student_name'];
	}
	$achist = array_combine($stin2his3,$snm2his3);
	$arinall = array($achisf, $achiss, $achist);
	//print_r($arinall);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$achiskeys = (array_keys($largest_arr));
	
$forhis1 = array();
$forhis2 = array();
$forhis3 = array();
for($v=0; $v<=120; $v++){
$forhhis1[] = $snm2his1[$v];
$forhhis2[] = $snm2his2[$v];
$forhhis3[] = $snm2his3[$v];
}
$forhis1 = $forhhis1;
$forhis2 = $forhhis2;
$forhis3 = $forhhis3;
//print_r($array_all_irs);

	$array_all_his = array(array_filter($forhis1), array_filter($forhis2), array_filter($forhis3));
	$countinghis = 0;
	while($countinghis <= 120){
	if(count(array_column($array_all_his, $countinghis)) == 3){
	$hisf2[] = round(array_sum(array_column($array_all_his, $countinghis))/3);
	}
	else if(count(array_column($array_all_his, $countinghis)) == 2){
	$hisf2[] = round(array_sum(array_column($array_all_his, $countinghis))/2);
	}
	else if(count(array_column($array_all_his, $countinghis)) == 1){
	$hisf2[] = round(array_sum(array_column($array_all_his, $countinghis))/1);
	}
	else{
	$hisf2[] = round(array_sum(array_column($array_all_his, $countinghis))/3);	
	}
	$countinghis++;
	}
	$hisf = implode("-",array_filter($hisf2));
	$hismx2 = explode("-",$hisf);
	$hismx = max(explode("-",$hisf));
	$stnameandscoreHis = array_combine($achiskeys,$hismx2);
	$maxinallsub = $hismx;			
	}
		else if($su[$i] == 'ICT'){
		$resultmxbystunameict1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='ICT' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameict1))
	{	
		$snm2ict1[] = $rsn['score'];
		$stin2ict[] = $rsn['student_name'];
	}
	$acictf = array_combine($stin2ict,$snm2ict1);
	$resultmxbystunameict2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='ICT' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameict2))
	{	
		$snm2ict2[] = $rsn['score'];
	    $stin2ict2[] = $rsn['student_name'];
	}
	$acicts = array_combine($stin2ict2,$snm2ict2);
	$resultmxbystunameict3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='ICT' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameict3))
	{	
		$snm2ict3[] = $rsn['score'];
		$stin2ict3[] = $rsn['student_name'];
	}
	$acictt = array_combine($stin2ict3,$snm2ict3);
	$arinall = array($acictf, $acicts, $acictt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acictkeys = (array_keys($largest_arr));
	
$forict1 = array();
$forict2 = array();
$forict3 = array();
for($v=0; $v<=120; $v++){
$foriict1[] = $snm2ict1[$v];
$foriict2[] = $snm2ict2[$v];
$foriict3[] = $snm2ict3[$v];
}
$forict1 = $foriict1;
$forict2 = $foriict2;
$forict3 = $foriict3;

	$array_all_ict = array(array_filter($forict1), array_filter($forict2), array_filter($forict3));
	$countingict = 0;
	while($countingict <= 120){
	if(count(array_column($array_all_ict, $countingict)) == 3){
	$ictf2[] = round(array_sum(array_column($array_all_ict, $countingict))/3);
	}
	else if(count(array_column($array_all_ict, $countingict)) == 2){
	$ictf2[] = round(array_sum(array_column($array_all_ict, $countingict))/2);
	}
	else if(count(array_column($array_all_ict, $countingict)) == 1){
	$ictf2[] = round(array_sum(array_column($array_all_ict, $countingict))/1);
	}
	else{
	$ictf2[] = round(array_sum(array_column($array_all_ict, $countingict))/3);	
	}
	$countingict++;
	}
	$ictf = implode("-",array_filter($ictf2));
	$ictmx2 = explode("-",$ictf);
	$ictmx = max(explode("-",$ictf));
	$stnameandscoreIct = array_combine($acictkeys,$ictmx2);
	$maxinallsub = $ictmx;			
	}
	else if($su[$i] == 'Igbo'){
		$resultmxbystunameigb1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Igbo' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameigb1))
	{	
		$snm2igb1[] = $rsn['score'];
		$stin2igb[] = $rsn['student_name'];
	}
	$acigbf = array_combine($stin2igb,$snm2igb1);
	$resultmxbystunameigb2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Igbo' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameigb2))
	{	
		$snm2igb2[] = $rsn['score'];
	    $stin2igb2[] = $rsn['student_name'];
	}
	$acigbs = array_combine($stin2igb2,$snm2igb2);
	$resultmxbystunameigb3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Igbo' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameigb3))
	{	
		$snm2igb3[] = $rsn['score'];
		$stin2igb3[] = $rsn['student_name'];
	}
	$acigbt = array_combine($stin2igb3,$snm2igb3);
	$arinall = array($acigbf, $acigbs, $acigbt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acigbkeys = (array_keys($largest_arr));
	
$forigb1 = array();
$forigb2 = array();
$forigb3 = array();
for($v=0; $v<=120; $v++){
$foriigb1[] = $snm2igb1[$v];
$foriigb2[] = $snm2igb2[$v];
$foriigb3[] = $snm2igb3[$v];
}
$forigb1 = $foriigb1;
$forigb2 = $foriigb2;
$forigb3 = $foriigb3;

	$array_all_igb = array(array_filter($forigb1), array_filter($forigb2), array_filter($forigb3));
	$countingigb = 0;
	while($countingigb <= 120){
	if(count(array_column($array_all_igb, $countingigb)) == 3){
	$igbf2[] = round(array_sum(array_column($array_all_igb, $countingigb))/3);
	}
	else if(count(array_column($array_all_igb, $countingigb)) == 2){
	$igbf2[] = round(array_sum(array_column($array_all_igb, $countingigb))/2);
	}
	else if(count(array_column($array_all_igb, $countingigb)) == 1){
	$igbf2[] = round(array_sum(array_column($array_all_igb, $countingigb))/1);
	}
	else{
	$igbf2[] = round(array_sum(array_column($array_all_igb, $countingigb))/3);	
	}
	$countingigb++;
	}
	$igbf = implode("-",array_filter($igbf2));
	$igbmx2 = explode("-",$igbf);
	$igbmx = max(explode("-",$igbf));
	$stnameandscoreIgb = array_combine($acigbkeys,$igbmx2);
	$maxinallsub = $igbmx;			
	}
	
	else if($su[$i] == 'Islamic Religious Studies'){
		$resultmxbystunameirs1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Islamic Religious Studies' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameirs1))
	{	
		$snm2irs1[] = $rsn['score'];
		$stin2irs[] = $rsn['student_name'];
	}
	$acirsf = array_combine($stin2irs,$snm2irs1);
	$resultmxbystunameirs2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Islamic Religious Studies' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameirs2))
	{	
		$snm2irs2[] = $rsn['score'];
	    $stin2irs2[] = $rsn['student_name'];
	}
	$acirss = array_combine($stin2irs2,$snm2irs2);
	$resultmxbystunameirs3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Islamic Religious Studies' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameirs3))
	{	
		$snm2irs3[] = $rsn['score'];
		$stin2irs3[] = $rsn['student_name'];
	}
	$acirst = array_combine($stin2irs3,$snm2irs3);
	$arinall = array($acirsf, $acirss, $acirst);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acirskeys = (array_keys($largest_arr));
	
$forirs1 = array();
$forirs2 = array();
$forirs3 = array();
for($v=0; $v<=120; $v++){
$foriirs1[] = $snm2irs1[$v];
$foriirs2[] = $snm2irs2[$v];
$foriirs3[] = $snm2irs3[$v];
}
$forirs1 = $foriirs1;
$forirs2 = $foriirs2;
$forirs3 = $foriirs3;

	$array_all_irs = array(array_filter($forirs1), array_filter($forirs2), array_filter($forirs3));
	$countingirs = 0;
	while($countingirs <= 120){
	if(count(array_column($array_all_irs, $countingirs)) == 3){
	$irsf2[] = round(array_sum(array_column($array_all_irs, $countingirs))/3);
	}
	else if(count(array_column($array_all_irs, $countingirs)) == 2){
	$irsf2[] = round(array_sum(array_column($array_all_irs, $countingirs))/2);
	}
	else if(count(array_column($array_all_irs, $countingirs)) == 1){
	$irsf2[] = round(array_sum(array_column($array_all_irs, $countingirs))/1);
	}
	else{
	$irsf2[] = round(array_sum(array_column($array_all_irs, $countingirs))/3);	
	}
	$countingirs++;
	}
	$irsf = implode("-",array_filter($irsf2));
	$irsmx2 = explode("-",$irsf);
	$irsmx = max(explode("-",$irsf));
	$stnameandscoreIrs = array_combine($acirskeys,$irsmx2);
	$maxinallsub = $irsmx;			
	}
	
	else if($su[$i] == 'Literature in English'){
		$resultmxbystunamelit1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Literature in English' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamelit1))
	{	
		$snm2lit1[] = $rsn['score'];
		$stin2lit[] = $rsn['student_name'];
	}
	$aclitf = array_combine($stin2lit,$snm2lit1);
	$resultmxbystunamelit2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Literature in English' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamelit2))
	{	
		$snm2lit2[] = $rsn['score'];
	    $stin2lit2[] = $rsn['student_name'];
	}
	$aclits = array_combine($stin2lit2,$snm2lit2);
	$resultmxbystunamelit3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Literature in English' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamelit3))
	{	
		$snm2lit3[] = $rsn['score'];
		$stin2lit3[] = $rsn['student_name'];
	}
	$aclitt = array_combine($stin2lit3,$snm2lit3);
	$arinall = array($aclitf, $aclits, $aclitt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$aclitkeys = (array_keys($largest_arr));
	
$forlit1 = array();
$forlit2 = array();
$forlit3 = array();
for($v=0; $v<=120; $v++){
$forllit1[] = $snm2lit1[$v];
$forllit2[] = $snm2lit2[$v];
$forllit3[] = $snm2lit3[$v];
}
$forlit1 = $forllit1;
$forlit2 = $forllit2;
$forlit3 = $forllit3;

	$array_all_lit = array(array_filter($forlit1), array_filter($forlit2), array_filter($forlit3));
	$countinglit = 0;
	while($countinglit <= 120){
	if(count(array_column($array_all_lit, $countinglit)) == 3){
	$litf2[] = round(array_sum(array_column($array_all_lit, $countinglit))/3);
	}
	else if(count(array_column($array_all_lit, $countinglit)) == 2){
	$litf2[] = round(array_sum(array_column($array_all_lit, $countinglit))/2);
	}
	else if(count(array_column($array_all_lit, $countinglit)) == 1){
	$litf2[] = round(array_sum(array_column($array_all_lit, $countinglit))/1);
	}
	else{
	$litf2[] = round(array_sum(array_column($array_all_lit, $countinglit))/3);	
	}
	$countinglit++;
	}
	$litf = implode("-",array_filter($litf2));
	$litmx2 = explode("-",$litf);
	$litmx = max(explode("-",$litf));
	$stnameandscoreLit = array_combine($aclitkeys,$litmx2);
	$maxinallsub = $litmx;			
	}
	else if($su[$i] == 'Marketing'){
		$resultmxbystunamemar1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Marketing' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemar1))
	{	
		$snm2mar1[] = $rsn['score'];
		$stin2mar[] = $rsn['student_name'];
	}
	$acmarf = array_combine($stin2mar,$snm2mar1);
	$resultmxbystunamemar2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Marketing' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemar2))
	{	
		$snm2mar2[] = $rsn['score'];
	    $stin2mar2[] = $rsn['student_name'];
	}
	$acmars = array_combine($stin2mar2,$snm2mar2);
	$resultmxbystunamemar3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Marketing' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemar3))
	{	
		$snm2mar3[] = $rsn['score'];
		$stin2mar3[] = $rsn['student_name'];
	}
	$acmart = array_combine($stin2mar3,$snm2mar3);
	$arinall = array($acmarf, $acmars, $acmart);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acmarkeys = (array_keys($largest_arr));
	
$formar1 = array();
$formar2 = array();
$formar3 = array();
for($v=0; $v<=120; $v++){
$formmar1[] = $snm2mar1[$v];
$formmar2[] = $snm2mar2[$v];
$formmar3[] = $snm2mar3[$v];
}
$formar1 = $formmar1;
$formar2 = $formmar2;
$formar3 = $formmar3;

	$array_all_mar = array(array_filter($formar1), array_filter($formar2), array_filter($formar3));
	$countingmar = 0;
	while($countingmar <= 120){
	if(count(array_column($array_all_mar, $countingmar)) == 3){
	$marf2[] = round(array_sum(array_column($array_all_mar, $countingmar))/3);
	}
	else if(count(array_column($array_all_mar, $countingmar)) == 2){
	$marf2[] = round(array_sum(array_column($array_all_mar, $countingmar))/2);
	}
	else if(count(array_column($array_all_mar, $countingmar)) == 1){
	$marf2[] = round(array_sum(array_column($array_all_mar, $countingmar))/1);
	}
	else{
	$marf2[] = round(array_sum(array_column($array_all_mar, $countingmar))/3);	
	}
	$countingmar++;
	}
	$marf = implode("-",array_filter($marf2));
	$marmx2 = explode("-",$marf);
	$marmx = max(explode("-",$marf));
	$stnameandscoreMar = array_combine($acmarkeys,$marmx2);
	$maxinallsub = $marmx;			
	}
		else if($su[$i] == 'PHE'){
		$resultmxbystunamephe1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='PHE' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephe1))
	{	
		$snm2phe1[] = $rsn['score'];
		$stin2phe[] = $rsn['student_name'];
	}
	$acphef = array_combine($stin2phe,$snm2phe1);
	$resultmxbystunamephe2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='PHE' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephe2))
	{	
		$snm2phe2[] = $rsn['score'];
	    $stin2phe2[] = $rsn['student_name'];
	}
	$acphes = array_combine($stin2phe2,$snm2phe2);
	$resultmxbystunamephe3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='PHE' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephe3))
	{	
		$snm2phe3[] = $rsn['score'];
		$stin2phe3[] = $rsn['student_name'];
	}
	$acphet = array_combine($stin2phe3,$snm2phe3);
	$arinall = array($acphef, $acphes, $acphet);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acphekeys = (array_keys($largest_arr));
	
$forphe1 = array();
$forphe2 = array();
$forphe3 = array();
for($v=0; $v<=120; $v++){
$forpphe1[] = $snm2phe1[$v];
$forpphe2[] = $snm2phe2[$v];
$forpphe3[] = $snm2phe3[$v];
}
$forphe1 = $forpphe1;
$forphe2 = $forpphe2;
$forphe3 = $forpphe3;

	$array_all_phe = array(array_filter($forphe1), array_filter($forphe2), array_filter($forphe3));
	$countingphe = 0;
	while($countingphe <= 120){
	if(count(array_column($array_all_phe, $countingphe)) == 3){
	$phef2[] = round(array_sum(array_column($array_all_phe, $countingphe))/3);
	}
	else if(count(array_column($array_all_phe, $countingphe)) == 2){
	$phef2[] = round(array_sum(array_column($array_all_phe, $countingphe))/2);
	}
	else if(count(array_column($array_all_phe, $countingphe)) == 1){
	$phef2[] = round(array_sum(array_column($array_all_phe, $countingphe))/1);
	}
	else{
	$phef2[] = round(array_sum(array_column($array_all_phe, $countingphe))/3);	
	}
	$countingphe++;
	}
	$phef = implode("-",array_filter($phef2));
	$phemx2 = explode("-",$phef);
	$phemx = max(explode("-",$phef));
	$stnameandscorePhe = array_combine($acphekeys,$phemx2);
	$maxinallsub = $phemx;			
	}
	else if($su[$i] == 'Physics'){
		$resultmxbystunamephy1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Physics' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephy1))
	{	
		$snm2phy1[] = $rsn['score'];
		$stin2phy[] = $rsn['student_name'];
	}
	$acphyf = array_combine($stin2phy,$snm2phy1);
	$resultmxbystunamephy2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Physics' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephy2))
	{	
		$snm2phy2[] = $rsn['score'];
	    $stin2phy2[] = $rsn['student_name'];
	}
	$acphys = array_combine($stin2phy2,$snm2phy2);
	$resultmxbystunamephy3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Physics' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephy3))
	{	
		$snm2phy3[] = $rsn['score'];
		$stin2phy3[] = $rsn['student_name'];
	}
	$acphyt = array_combine($stin2phy3,$snm2phy3);
	$arinall = array($acphyf, $acphys, $acphyt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acphykeys = (array_keys($largest_arr));
	
$forphy1 = array();
$forphy2 = array();
$forphy3 = array();
for($v=0; $v<=120; $v++){
$forpphy1[] = $snm2phy1[$v];
$forpphy2[] = $snm2phy2[$v];
$forpphy3[] = $snm2phy3[$v];
}
$forphy1 = $forpphy1;
$forphy2 = $forpphy2;
$forphy3 = $forpphy3;

	$array_all_phy = array(array_filter($forphy1), array_filter($forphy2), array_filter($forphy3));
	$countingphy = 0;
	while($countingphy <= 120){
	if(count(array_column($array_all_phy, $countingphy)) == 3){
	$phyf2[] = round(array_sum(array_column($array_all_phy, $countingphy))/3);
	}
	else if(count(array_column($array_all_phy, $countingphy)) == 2){
	$phyf2[] = round(array_sum(array_column($array_all_phy, $countingphy))/2);
	}
	else if(count(array_column($array_all_phy, $countingphy)) == 1){
	$phyf2[] = round(array_sum(array_column($array_all_phy, $countingphy))/1);
	}
	else{
	$phyf2[] = round(array_sum(array_column($array_all_phy, $countingphy))/3);	
	}
	$countingphy++;
	}
	$phyf = implode("-",array_filter($phyf2));
	$phymx2 = explode("-",$phyf);
	$phymx = max(explode("-",$phyf));
	$stnameandscorePhy = array_combine($acphykeys,$phymx2);
	$maxinallsub = $phymx;			
	}
	
	else if($su[$i] == 'Phonics'){
		$resultmxbystunamepho1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Phonics' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamepho1))
	{	
		$snm2pho1[] = $rsn['score'];
		$stin2pho[] = $rsn['student_name'];
	}
	$acphof = array_combine($stin2pho,$snm2pho1);
	$resultmxbystunamepho2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Phonics' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamepho2))
	{	
		$snm2pho2[] = $rsn['score'];
	    $stin2pho2[] = $rsn['student_name'];
	}
	$acphos = array_combine($stin2pho2,$snm2pho2);
	$resultmxbystunamepho3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Phonics' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamepho3))
	{	
		$snm2pho3[] = $rsn['score'];
		$stin2pho3[] = $rsn['student_name'];
	}
	$acphot = array_combine($stin2pho3,$snm2pho3);
	$arinall = array($acphof, $acphos, $acphot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acphokeys = (array_keys($largest_arr));
	
$forpho1 = array();
$forpho2 = array();
$forpho3 = array();
for($v=0; $v<=120; $v++){
$forppho1[] = $snm2pho1[$v];
$forppho2[] = $snm2pho2[$v];
$forppho3[] = $snm2pho3[$v];
}
$forpho1 = $forppho1;
$forpho2 = $forppho2;
$forpho3 = $forppho3;

	$array_all_pho = array(array_filter($forpho1), array_filter($forpho2), array_filter($forpho3));
	$countingpho = 0;
	while($countingpho <= 120){
	if(count(array_column($array_all_pho, $countingpho)) == 3){
	$phof2[] = round(array_sum(array_column($array_all_pho, $countingpho))/3);
	}
	else if(count(array_column($array_all_pho, $countingpho)) == 2){
	$phof2[] = round(array_sum(array_column($array_all_pho, $countingpho))/2);
	}
	else if(count(array_column($array_all_pho, $countingpho)) == 1){
	$phof2[] = round(array_sum(array_column($array_all_pho, $countingpho))/1);
	}
	else{
	$phof2[] = round(array_sum(array_column($array_all_pho, $countingpho))/3);	
	}
	$countingpho++;
	}
	$phof = implode("-",array_filter($phof2));
	$phomx2 = explode("-",$phof);
	$phomx = max(explode("-",$phof));
	$stnameandscorePho = array_combine($acphokeys,$phomx2);
	$maxinallsub = $phomx;			
	}
	
		else if($su[$i] == 'Social Studies'){
		$resultmxbystunamesoc1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Social Studies' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesoc1))
	{	
		$snm2soc1[] = $rsn['score'];
		$stin2soc[] = $rsn['student_name'];
	}
	$acsocf = array_combine($stin2soc,$snm2soc1);
	$resultmxbystunamesoc2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Social Studies' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesoc2))
	{	
		$snm2soc2[] = $rsn['score'];
	    $stin2soc2[] = $rsn['student_name'];
	}
	$acsocs = array_combine($stin2soc2,$snm2soc2);
	$resultmxbystunamesoc3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Social Studies' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesoc3))
	{	
		$snm2soc3[] = $rsn['score'];
		$stin2soc3[] = $rsn['student_name'];
	}
	$acsoct = array_combine($stin2soc3,$snm2soc3);
	$arinall = array($acsocf, $acsocs, $acsoct);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acsockeys = (array_keys($largest_arr));
	
$forsoc1 = array();
$forsoc2 = array();
$forsoc3 = array();
for($v=0; $v<=120; $v++){
$forssoc1[] = $snm2soc1[$v];
$forssoc2[] = $snm2soc2[$v];
$forssoc3[] = $snm2soc3[$v];
}
$forsoc1 = $forssoc1;
$forsoc2 = $forssoc2;
$forsoc3 = $forssoc3;

	$array_all_soc = array(array_filter($forsoc1), array_filter($forsoc2), array_filter($forsoc3));
	$countingsoc = 0;
	while($countingsoc <= 120){
	if(count(array_column($array_all_soc, $countingsoc)) == 3){
	$socf2[] = round(array_sum(array_column($array_all_soc, $countingsoc))/3);
	}
	else if(count(array_column($array_all_soc, $countingsoc)) == 2){
	$socf2[] = round(array_sum(array_column($array_all_soc, $countingsoc))/2);
	}
	else if(count(array_column($array_all_soc, $countingsoc)) == 1){
	$socf2[] = round(array_sum(array_column($array_all_soc, $countingsoc))/1);
	}
	else{
	$socf2[] = round(array_sum(array_column($array_all_soc, $countingsoc))/3);	
	}
	$countingsoc++;
	}
	$socf = implode("-",array_filter($socf2));
	$socmx2 = explode("-",$socf);
	$socmx = max(explode("-",$socf));
	$stnameandscoreSoc = array_combine($acsockeys,$socmx2);
	$maxinallsub = $socmx;			
	}
	else if($su[$i] == 'Sociology'){
		$resultmxbystunamesocio1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Sociology' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesocio1))
	{	
		$snm2socio1[] = $rsn['score'];
		$stin2socio[] = $rsn['student_name'];
	}
	$acsociof = array_combine($stin2socio,$snm2socio1);
	$resultmxbystunamesocio2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Sociology' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesocio2))
	{	
		$snm2socio2[] = $rsn['score'];
	    $stin2socio2[] = $rsn['student_name'];
	}
	$acsocios = array_combine($stin2socio2,$snm2socio2);
	$resultmxbystunamesocio3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Sociology' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesocio3))
	{	
		$snm2socio3[] = $rsn['score'];
		$stin2socio3[] = $rsn['student_name'];
	}
	$acsociot = array_combine($stin2socio3,$snm2socio3);
	$arinall = array($acsociof, $acsocios, $acsociot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acsociokeys = (array_keys($largest_arr));
	
$forsocio1 = array();
$forsocio2 = array();
$forsocio3 = array();
for($v=0; $v<=120; $v++){
$forssocio1[] = $snm2socio1[$v];
$forssocio2[] = $snm2socio2[$v];
$forssocio3[] = $snm2socio3[$v];
}
$forsocio1 = $forssocio1;
$forsocio2 = $forssocio2;
$forsocio3 = $forssocio3;

	$array_all_socio = array(array_filter($forsocio1), array_filter($forsocio2), array_filter($forsocio3));
	$countingsocio = 0;
	while($countingsocio <= 120){
	if(count(array_column($array_all_socio, $countingsocio)) == 3){
	$sociof2[] = round(array_sum(array_column($array_all_socio, $countingsocio))/3);
	}
	else if(count(array_column($array_all_socio, $countingsocio)) == 2){
	$sociof2[] = round(array_sum(array_column($array_all_socio, $countingsocio))/2);
	}
	else if(count(array_column($array_all_socio, $countingsocio)) == 1){
	$sociof2[] = round(array_sum(array_column($array_all_socio, $countingsocio))/1);
	}
	else{
	$sociof2[] = round(array_sum(array_column($array_all_socio, $countingsocio))/3);	
	}
	$countingsocio++;
	}
	$sociof = implode("-",array_filter($sociof2));
	$sociomx2 = explode("-",$sociof);
	$sociomx = max(explode("-",$sociof));
	$stnameandscoreSocio = array_combine($acsociokeys,$sociomx2);
	$maxinallsub = $sociomx;			
	}
	else if($su[$i] == 'TD'){
		$resultmxbystunametd1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='TD' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunametd1))
	{	
		$snm2td1[] = $rsn['score'];
		$stin2td[] = $rsn['student_name'];
	}
	$actdf = array_combine($stin2td,$snm2td1);
	$resultmxbystunametd2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='TD' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunametd2))
	{	
		$snm2td2[] = $rsn['score'];
	    $stin2td2[] = $rsn['student_name'];
	}
	$actds = array_combine($stin2td2,$snm2td2);
	$resultmxbystunametd3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='TD' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunametd3))
	{	
		$snm2td3[] = $rsn['score'];
		$stin2td3[] = $rsn['student_name'];
	}
	$actdt = array_combine($stin2td3,$snm2td3);
	$arinall = array($actdf, $actds, $actdt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$actdkeys = (array_keys($largest_arr));
	
$fortd1 = array();
$fortd2 = array();
$fortd3 = array();
for($v=0; $v<=120; $v++){
$forttd1[] = $snm2td1[$v];
$forttd2[] = $snm2td2[$v];
$forttd3[] = $snm2td3[$v];
}
$fortd1 = $forttd1;
$fortd2 = $forttd2;
$fortd3 = $forttd3;

	$array_all_td = array(array_filter($fortd1), array_filter($fortd2), array_filter($fortd3));
	$countingtd = 0;
	while($countingtd <= 120){
	if(count(array_column($array_all_td, $countingtd)) == 3){
	$tdf2[] = round(array_sum(array_column($array_all_td, $countingtd))/3);
	}
	else if(count(array_column($array_all_td, $countingtd)) == 2){
	$tdf2[] = round(array_sum(array_column($array_all_td, $countingtd))/2);
	}
	else if(count(array_column($array_all_td, $countingtd)) == 1){
	$tdf2[] = round(array_sum(array_column($array_all_td, $countingtd))/1);
	}
	else{
	$tdf2[] = round(array_sum(array_column($array_all_td, $countingtd))/3);	
	}
	$countingtd++;
	}
	$tdf = implode("-",array_filter($tdf2));
	$tdmx2 = explode("-",$tdf);
	$tdmx = max(explode("-",$tdf));
	$stnameandscoreTd = array_combine($actdkeys,$tdmx2);
	$maxinallsub = $tdmx;			
	}
	else if($su[$i] == 'VA'){
		$resultmxbystunameva1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='VA' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameva1))
	{	
		$snm2va1[] = $rsn['score'];
		$stin2va[] = $rsn['student_name'];
	}
	$acvaf = array_combine($stin2va,$snm2va1);
	$resultmxbystunameva2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='VA' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameva2))
	{	
		$snm2va2[] = $rsn['score'];
	    $stin2va2[] = $rsn['student_name'];
	}
	$acvas = array_combine($stin2va2,$snm2va2);
	$resultmxbystunameva3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='VA' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameva3))
	{	
		$snm2va3[] = $rsn['score'];
		$stin2va3[] = $rsn['student_name'];
	}
	$acvat = array_combine($stin2va3,$snm2va3);
	$arinall = array($acvaf, $acvas, $acvat);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acvakeys = (array_keys($largest_arr));
	
$forva1 = array();
$forva2 = array();
$forva3 = array();
for($v=0; $v<=120; $v++){
$forvva1[] = $snm2va1[$v];
$forvva2[] = $snm2va2[$v];
$forvva3[] = $snm2va3[$v];
}
$forva1 = $forvva1;
$forva2 = $forvva2;
$forva3 = $forvva3;

	$array_all_va = array(array_filter($forva1), array_filter($forva2), array_filter($forva3));
	$countingva = 0;
	while($countingva <= 120){
	if(count(array_column($array_all_va, $countingva)) == 3){
	$vaf2[] = round(array_sum(array_column($array_all_va, $countingva))/3);
	}
	else if(count(array_column($array_all_va, $countingva)) == 2){
	$vaf2[] = round(array_sum(array_column($array_all_va, $countingva))/2);
	}
	else if(count(array_column($array_all_va, $countingva)) == 1){
	$vaf2[] = round(array_sum(array_column($array_all_va, $countingva))/1);
	}
	else{
	$vaf2[] = round(array_sum(array_column($array_all_va, $countingva))/3);	
	}
	$countingva++;
	}
	$vaf = implode("-",array_filter($vaf2));
	$vamx2 = explode("-",$vaf);
	$vamx = max(explode("-",$vaf));
	$stnameandscoreVa = array_combine($acvakeys,$vamx2);
	$maxinallsub = $vamx;			
	}
	else if($su[$i] == 'Vocational Aptitude'){
		$resultmxbystunamevap1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Vocational Aptitude' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevap1))
	{	
		$snm2vap1[] = $rsn['score'];
		$stin2vap[] = $rsn['student_name'];
	}
	$acvapf = array_combine($stin2vap,$snm2vap1);
	$resultmxbystunamevap2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Vocational Aptitude' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevap2))
	{	
		$snm2vap2[] = $rsn['score'];
	    $stin2vap2[] = $rsn['student_name'];
	}
	$acvaps = array_combine($stin2vap2,$snm2vap2);
	$resultmxbystunamevap3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Vocational Aptitude' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevap3))
	{	
		$snm2vap3[] = $rsn['score'];
		$stin2vap3[] = $rsn['student_name'];
	}
	$acvapt = array_combine($stin2vap3,$snm2vap3);
	$arinall = array($acvapf, $acvaps, $acvapt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acvapkeys = (array_keys($largest_arr));
	
$forvap1 = array();
$forvap2 = array();
$forvap3 = array();
for($v=0; $v<=120; $v++){
$forvvap1[] = $snm2vap1[$v];
$forvvap2[] = $snm2vap2[$v];
$forvvap3[] = $snm2vap3[$v];
}
$forvap1 = $forvvap1;
$forvap2 = $forvvap2;
$forvap3 = $forvvap3;

	$array_all_vap = array(array_filter($forvap1), array_filter($forvap2), array_filter($forvap3));
	$countingvap = 0;
	while($countingvap <= 120){
	if(count(array_column($array_all_vap, $countingvap)) == 3){
	$vapf2[] = round(array_sum(array_column($array_all_vap, $countingvap))/3);
	}
	else if(count(array_column($array_all_vap, $countingvap)) == 2){
	$vapf2[] = round(array_sum(array_column($array_all_vap, $countingvap))/2);
	}
	else if(count(array_column($array_all_vap, $countingvap)) == 1){
	$vapf2[] = round(array_sum(array_column($array_all_vap, $countingvap))/1);
	}
	else{
	$vapf2[] = round(array_sum(array_column($array_all_vap, $countingvap))/3);	
	}
	$countingvap++;
	}
	$vapf = implode("-",array_filter($vapf2));
	$vapmx2 = explode("-",$vapf);
	$vapmx = max(explode("-",$vapf));
	$stnameandscoreVap = array_combine($acvapkeys,$vapmx2);
	$maxinallsub = $vapmx;			
	}
	else if($su[$i] == 'Yoruba'){
		$resultmxbystunameyor1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Yoruba' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameyor1))
	{	
		$snm2yor1[] = $rsn['score'];
		$stin2yor[] = $rsn['student_name'];
	}
	$acyorf = array_combine($stin2yor,$snm2yor1);
	$resultmxbystunameyor2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Yoruba' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameyor2))
	{	
		$snm2yor2[] = $rsn['score'];
	    $stin2yor2[] = $rsn['student_name'];
	}
	$acyors = array_combine($stin2yor2,$snm2yor2);
	$resultmxbystunameyor3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Yoruba' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameyor3))
	{	
		$snm2yor3[] = $rsn['score'];
		$stin2yor3[] = $rsn['student_name'];
	}
	$acyort = array_combine($stin2yor3,$snm2yor3);
	$arinall = array($acyorf, $acyors, $acyort);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acyorkeys = (array_keys($largest_arr));
	
$foryor1 = array();
$foryor2 = array();
$foryor3 = array();
for($v=0; $v<=120; $v++){
$foryyor1[] = $snm2yor1[$v];
$foryyor2[] = $snm2yor2[$v];
$foryyor3[] = $snm2yor3[$v];
}
$foryor1 = $foryyor1;
$foryor2 = $foryyor2;
$foryor3 = $foryyor3;

	$array_all_yor = array(array_filter($foryor1), array_filter($foryor2), array_filter($foryor3));
	$countingyor = 0;
	while($countingyor <= 120){
	if(count(array_column($array_all_yor, $countingyor)) == 3){
	$yorf2[] = round(array_sum(array_column($array_all_yor, $countingyor))/3);
	}
	else if(count(array_column($array_all_yor, $countingyor)) == 2){
	$yorf2[] = round(array_sum(array_column($array_all_yor, $countingyor))/2);
	}
	else if(count(array_column($array_all_yor, $countingyor)) == 1){
	$yorf2[] = round(array_sum(array_column($array_all_yor, $countingyor))/1);
	}
	else{
	$yorf2[] = round(array_sum(array_column($array_all_yor, $countingyor))/3);	
	}
	$countingyor++;
	}
	$yorf = implode("-",array_filter($yorf2));
	$yormx2 = explode("-",$yorf);
	$yormx = max(explode("-",$yorf));
	$stnameandscoreYor = array_combine($acyorkeys,$yormx2);
	$maxinallsub = $yormx;			
	}
	
	else if($su[$i] == 'Quantitative Reasoning'){
		$resultmxbystunameqr1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Quantitative Reasoning' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameqr1))
	{	
		$snm2qr1[] = $rsn['score'];
		$stin2qr[] = $rsn['student_name'];
	}
	$acqrf = array_combine($stin2qr,$snm2qr1);
	$resultmxbystunameqr2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Quantitative Reasoning' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameqr2))
	{	
		$snm2qr2[] = $rsn['score'];
	    $stin2qr2[] = $rsn['student_name'];
	}
	$acqrs = array_combine($stin2qr2,$snm2qr2);
	$resultmxbystunameqr3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Quantitative Reasoning' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameqr3))
	{	
		$snm2qr3[] = $rsn['score'];
		$stin2qr3[] = $rsn['student_name'];
	}
	$acqrt = array_combine($stin2qr3,$snm2qr3);
	$arinall = array($acqrf, $acqrs, $acqrt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acqrkeys = (array_keys($largest_arr));
	
$forqr1 = array();
$forqr2 = array();
$forqr3 = array();
for($v=0; $v<=120; $v++){
$forqqr1[] = $snm2qr1[$v];
$forqqr2[] = $snm2qr2[$v];
$forqqr3[] = $snm2qr3[$v];
}
$forqr1 = $forqqr1;
$forqr2 = $forqqr2;
$forqr3 = $forqqr3;

	$array_all_qr = array(array_filter($forqr1), array_filter($forqr2), array_filter($forqr3));
	$countingqr = 0;
	while($countingqr <= 120){
	if(count(array_column($array_all_qr, $countingqr)) == 3){
	$qrf2[] = round(array_sum(array_column($array_all_qr, $countingqr))/3);
	}
	else if(count(array_column($array_all_qr, $countingqr)) == 2){
	$qrf2[] = round(array_sum(array_column($array_all_qr, $countingqr))/2);
	}
	else if(count(array_column($array_all_qr, $countingqr)) == 1){
	$qrf2[] = round(array_sum(array_column($array_all_qr, $countingqr))/1);
	}
	else{
	$qrf2[] = round(array_sum(array_column($array_all_qr, $countingqr))/3);	
	}
	$countingqr++;
	}
	$qrf = implode("-",array_filter($qrf2));
	$qrmx2 = explode("-",$qrf);
	$qrmx = max(explode("-",$qrf));
	$stnameandscoreQr = array_combine($acqrkeys,$qrmx2);
	$maxinallsub = $qrmx;			
	}
	else if($su[$i] == 'Verbal Reasoning'){
		$resultmxbystunamevr1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Verbal Reasoning' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevr1))
	{	
		$snm2vr1[] = $rsn['score'];
		$stin2vr[] = $rsn['student_name'];
	}
	$acvrf = array_combine($stin2vr,$snm2vr1);
	$resultmxbystunamevr2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Verbal Reasoning' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevr2))
	{	
		$snm2vr2[] = $rsn['score'];
	    $stin2vr2[] = $rsn['student_name'];
	}
	$acvrs = array_combine($stin2vr2,$snm2vr2);
	$resultmxbystunamevr3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Verbal Reasoning' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevr3))
	{	
		$snm2vr3[] = $rsn['score'];
		$stin2vr3[] = $rsn['student_name'];
	}
	$acvrt = array_combine($stin2vr3,$snm2vr3);
	$arinall = array($acvrf, $acvrs, $acvrt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acvrkeys = (array_keys($largest_arr));
	
$forvr1 = array();
$forvr2 = array();
$forvr3 = array();
for($v=0; $v<=120; $v++){
$forvvr1[] = $snm2vr1[$v];
$forvvr2[] = $snm2vr2[$v];
$forvvr3[] = $snm2vr3[$v];
}
$forvr1 = $forvvr1;
$forvr2 = $forvvr2;
$forvr3 = $forvvr3;

	$array_all_vr = array(array_filter($forvr1), array_filter($forvr2), array_filter($forvr3));
	$countingvr = 0;
	while($countingvr <= 120){
	if(count(array_column($array_all_vr, $countingvr)) == 3){
	$vrf2[] = round(array_sum(array_column($array_all_vr, $countingvr))/3);
	}
	else if(count(array_column($array_all_vr, $countingvr)) == 2){
	$vrf2[] = round(array_sum(array_column($array_all_vr, $countingvr))/2);
	}
	else if(count(array_column($array_all_vr, $countingvr)) == 1){
	$vrf2[] = round(array_sum(array_column($array_all_vr, $countingvr))/1);
	}
	else{
	$vrf2[] = round(array_sum(array_column($array_all_vr, $countingvr))/3);	
	}
	$countingvr++;
	}
	$vrf = implode("-",array_filter($vrf2));
	$vrmx2 = explode("-",$vrf);
	$vrmx = max(explode("-",$vrf));
	$stnameandscoreVr = array_combine($acvrkeys,$vrmx2);
	$maxinallsub = $vrmx;			
	}
		else if($su[$i] == 'Geography'){
		$resultmxbystunamegeo1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Geography' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegeo1))
	{	
		$snm2geo1[] = $rsn['score'];
		$stin2geo[] = $rsn['student_name'];
	}
	$acgeof = array_combine($stin2geo,$snm2geo1);
	$resultmxbystunamegeo2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Geography' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegeo2))
	{	
		$snm2geo2[] = $rsn['score'];
	    $stin2geo2[] = $rsn['student_name'];
	}
	$acgeos = array_combine($stin2geo2,$snm2geo2);
	$resultmxbystunamegeo3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Geography' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegeo3))
	{	
		$snm2geo3[] = $rsn['score'];
		$stin2geo3[] = $rsn['student_name'];
	}
	$acgeot = array_combine($stin2geo3,$snm2geo3);
	$arinall = array($acgeof, $acgeos, $acgeot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acgeokeys = (array_keys($largest_arr));
	
$forgeo1 = array();
$forgeo2 = array();
$forgeo3 = array();
for($v=0; $v<=120; $v++){
$forggeo1[] = $snm2geo1[$v];
$forggeo2[] = $snm2geo2[$v];
$forggeo3[] = $snm2geo3[$v];
}
$forgeo1 = $forggeo1;
$forgeo2 = $forggeo2;
$forgeo3 = $forggeo3;

	$array_all_geo = array(array_filter($forgeo1), array_filter($forgeo2), array_filter($forgeo3));
	$countinggeo = 0;
	while($countinggeo <= 120){
	if(count(array_column($array_all_geo, $countinggeo)) == 3){
	$geof2[] = round(array_sum(array_column($array_all_geo, $countinggeo))/3);
	}
	else if(count(array_column($array_all_geo, $countinggeo)) == 2){
	$geof2[] = round(array_sum(array_column($array_all_geo, $countinggeo))/2);
	}
	else if(count(array_column($array_all_geo, $countinggeo)) == 1){
	$geof2[] = round(array_sum(array_column($array_all_geo, $countinggeo))/1);
	}
	else{
	$geof2[] = round(array_sum(array_column($array_all_geo, $countinggeo))/3);	
	}
	$countinggeo++;
	}
	$geof = implode("-",array_filter($geof2));
	$geomx2 = explode("-",$geof);
	$geomx = max(explode("-",$geof));
	$stnameandscoreGeo = array_combine($acgeokeys,$geomx2);
	$maxinallsub = $geomx;			
	}
	
	elseif($su[$i] == 'Handwriting'){							
	$resultmxbystunamehw1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Handwriting' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehw1))
	{	
		$snm2hw1[] = $rsn['score'];
		$stin2hw[] = $rsn['student_name'];
	}
	$achwf = array_combine($stin2hw,$snm2hw1);
	$resultmxbystunamehw2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Handwriting' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehw2))
	{	
		$snm2hw2[] = $rsn['score'];
	    $stin2hw2[] = $rsn['student_name'];
	}
	$achws = array_combine($stin2hw2,$snm2hw2);
	$resultmxbystunamehw3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Handwriting' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehw3))
	{	
		$snm2hw3[] = $rsn['score'];
		$stin2hw3[] = $rsn['student_name'];
	}
	$achwt = array_combine($stin2hw3,$snm2hw3);
	$arinall = array($achwf, $achws, $achwt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$achwkeys = (array_keys($largest_arr));
	
$forhw1 = array();
for($v=0; $v<=120; $v++){
$forhhw1[] = $snm2hw1[$v];
}
$forhw1 = $forhhw1;

$forhw2 = array();
for($v=0; $v<=120; $v++){
$forhhw2[] = $snm2hw2[$v];
}
$forhw2 = $forhhw2;

$forhw3 = array();
for($v=0; $v<=120; $v++){
$forhhw3[] = $snm2hw3[$v];
}
$forhw3 = $forhhw3;

$array_all_hw = array(array_filter($forhw1), array_filter($forhw2), array_filter($forhw3));
	$countinghw = 0;
	while($countinghw <= 120){
	if(count(array_column($array_all_hw, $countinghw)) == 3){
	$hwf2[] = round(array_sum(array_column($array_all_hw, $countinghw))/3);
	}
	else if(count(array_column($array_all_hw, $countinghw)) == 2){
	$hwf2[] = round(array_sum(array_column($array_all_hw, $countinghw))/2);
	}
	else if(count(array_column($array_all_hw, $countinghw)) == 1){
	$hwf2[] = round(array_sum(array_column($array_all_hw, $countinghw))/1);
	}
	else{
	$hwf2[] = round(array_sum(array_column($array_all_hw, $countinghw))/3);	
	}
	$countinghw++;
	}
	$hwf = implode("-",array_filter($hwf2));
	$hwmx2 = explode("-",$hwf);
	$hwmx = max(explode("-",$hwf));
	$stnameandscoreHw = array_combine($achwkeys,$hwmx2);
	$maxinallsub = $hwmx;	
	}
	else{	
			$maxinallsub = "-";	
		}				
}	
echo '<tr id="heading"><td>SUBJECT</td><td>CA</td><td>EXAM</td><td>THIRD TERM TOTAL</td><td>SECOND TERM TOTAL</td><td>FIRST TERM TOTAL</td><td>AV. OF THREE TERMS</td><td>CLASS HIGHEST</td><td>CLASS AVERAGE</td><td>GRADE</td><td>TEACHER\'S NAME</td><td>REMARK</td></tr>';			
		for ($x = 0; $x <= (count($su)-1); $x++){
echo '<tr><td>'.$su[$x].'</td><td>'.$ca[$x].'</td><td>'.$exam[$x].'</td><td>'.$tt[$x].'</td><td>'.$dd[$x].'</td><td>'.$cc[$x].'</td><td>'.$av[$x].'</td><td>'.$hs[$x].'</td><td id="mytd">'.round($ccav[$x]).'</td><td>'.$grade[$x].'</td><td>'.$tn[$x].'</td><td>'.$re[$x].'</td></tr>';			
		}
echo '</table>';
	}
	
		
	
	else if(isset($_POST['subbyarm3'])){

$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		$arms = $_POST['arms'];
if($arms!=""){	
	if($term == "Third Term"){	
	$result1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	$sql2 = mysqli_query($db, "SELECT * FROM maxes where subjectname='$subject' AND classname='$class' AND yearname='$year' AND termname='$term' AND teachername='$tna' AND teacheridname='$tid' AND school='".$_SESSION["school"]."'");
					
						while($row1 = mysqli_fetch_assoc($result1))
							{ 
								$firsubject[] = $row1['subject'];
								$firscore[] = $row1['score'];
							}
							$firsubject11 = $firsubject;
							$firscore11 = $firscore;
							$c = array_combine($firsubject11, $firscore11);
							ksort($c);
							$c = array_values($c);
							
	$result2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
						while($row2 = mysqli_fetch_assoc($result2))
							{ 
								$secsubject[] = $row2['subject'];
								$secscore[] = $row2['score'];
							}
							$secsubject22 = $secsubject;
							$secscore22 = $secscore;
							$d = array_combine($secsubject22, $secscore22);
							ksort($d);
							$d = array_values($d);
				
							
	$result3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
						while($row3 = mysqli_fetch_assoc($result3))
							{ 
								$thirsubject[] = $row3['subject'];
								$thirscore[] = $row3['score'];
							}
							$thirsubject33 = $thirsubject;
							$thirscore33 = $thirscore;
							$t = array_combine($thirsubject33, $thirscore33);
							ksort($t);
							$t = array_values($t);						
							
							$e = array_map(function () {
							return array_sum(func_get_args());
							},$c, $d, $t);
							ksort($e);
		
							
	echo '<tr id="heading"><td>SUBJECT</td><td>CA</td><td>EXAM</td><td>THIRD TERM</td><td>SECOND TERM</td><td>FIRST TERM</td><td>AV. OF THREE TERMS</td><td>CLASS HIGHEST</td><td>CLASS AVERAGE</td><td>GRADE</td><td>TEACHER\'S NAME</td><td>REMARK</td></tr>';	
	
	
	$result = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."' ORDER BY subject ASC");
	
	$recav = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
	$recavmax = mysqli_query($db, "SELECT MAX(score) AS agrmax FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
	while($rowcav = mysqli_fetch_assoc($recav))
							{
							$agrcavin[]	= $rowcav['score'];
							}
							$agrcav = array_filter($agrcavin);
							$agrcav2 = array_sum($agrcav);
	$numbagr = count(array_filter($agrcav));
	$agrcav3 = $agrcav2/$numbagr;
	
	$recav1 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Basic Science' AND school='".$_SESSION["school"]."'");
	while($rowcav1 = mysqli_fetch_assoc($recav1))
							{
							$bascavin[]	= $rowcav1['score'];
							}
							$bascav = array_filter($bascavin);
							$bascav2 = array_sum($bascav);
	$numbbas = count(array_filter($bascav));
	$bascav3 = $bascav2/$numbbas;
	
	$recav2 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='English' AND school='".$_SESSION["school"]."'");
	$recav2max = mysqli_query($db, "SELECT MAX(score) AS engmax FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='English' AND school='".$_SESSION["school"]."'");
	while($rowcav2 = mysqli_fetch_assoc($recav2))
							{
							$engcavin[]	= $rowcav2['score'];
							}
							$engcav = array_filter($engcavin);
							$engcav2 = array_sum($engcav);
	$numbeng = count(array_filter($engcav));
	$engcav3 = round($engcav2/$numbeng);
	while($rowcav2max = mysqli_fetch_assoc($recav2max))
							{
							$engcavinmax[]	= $rowcav2max['engmax'];
							}
							$engcavmax = array_filter($engcavinmax);
							$engcav2max = array_sum($engcavmax);
	$numbengmax = count(array_filter($engcavmax));
	$engcav3max = $engcav2max/$numbengmax;
	//echo $engcav3max;
	
	$recav3 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Business Studies' AND school='".$_SESSION["school"]."'");
	while($rowcav3 = mysqli_fetch_assoc($recav3))
							{
							$buscavin[]	= $rowcav3['score'];
							}
							$buscav = array_filter($buscavin);
							$buscav2 = array_sum($buscav);
	$numbbus = count(array_filter($buscav));
	$buscav3 = round($buscav2/$numbbus);
	
	$recav4 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Catering' AND school='".$_SESSION["school"]."'");
	while($rowcav4 = mysqli_fetch_assoc($recav4))
							{
							$catcavin[]	= $rowcav4['score'];
							}
							$catcav = array_filter($catcavin);
							$catcav2 = array_sum($catcav);
	$numbcat = count(array_filter($catcav));
	$catcav3 = $catcav2/$numbcat;
	
	$recav5 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Civic Education' AND school='".$_SESSION["school"]."'");
	while($rowcav5 = mysqli_fetch_assoc($recav5))
							{
							$civcavin[]	= $rowcav5['score'];
							}
							$civcav = array_filter($civcavin);
							$civcav2 = array_sum($civcav);
	$numbciv = count(array_filter($civcav));
	$civcav3 = $civcav2/$numbciv;
	
	$recav6 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Crk' AND school='".$_SESSION["school"]."'");
	while($rowcav6 = mysqli_fetch_assoc($recav6))
							{
							$crkcavin[]	= $rowcav6['score'];
							}
							$crkcav = array_filter($crkcavin);
							$crkcav2 = array_sum($crkcav);
	$numbcrk = count(array_filter($crkcav));
	$crkcav3 = $crkcav2/$numbcrk;
	
	$recav7 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Food and Nutrition' AND school='".$_SESSION["school"]."'");
	while($rowcav7 = mysqli_fetch_assoc($recav7))
							{
							$foocavin[]	= $rowcav7['score'];
							}
							$foocav = array_filter($foocavin);
							$foocav2 = array_sum($foocav);
	$numbfoo = count(array_filter($foocav));
	$foocav3 = $foocav2/$numbfoo;
	
	$recav8 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='French' AND school='".$_SESSION["school"]."'");
	while($rowcav8 = mysqli_fetch_assoc($recav8))
							{
							$frecavin[]	= $rowcav8['score'];
							}
							$frecav = array_filter($frecavin);
							$frecav2 = array_sum($frecav);
	$numbfre = count(array_filter($frecav));
	$frecav3 = $frecav2/$numbfre;
	
	$recav9 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='ICT' AND school='".$_SESSION["school"]."'");
	while($rowcav9 = mysqli_fetch_assoc($recav9))
							{
							$ictcavin[]	= $rowcav9['score'];
							}
							$ictcav = array_filter($ictcavin);
							$ictcav2 = array_sum($ictcav);
	$numbict = count(array_filter($ictcav));
	$ictcav3 = $ictcav2/$numbict;
	
	$recav10 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Igbo' AND school='".$_SESSION["school"]."'");
	while($rowcav10 = mysqli_fetch_assoc($recav10))
							{
							$igbcavin[]	= $rowcav10['score'];
							}
							$igbcav = array_filter($igbcavin);
							$igbcav2 = array_sum($igbcav);
	$numbigb = count(array_filter($igbcav));
	$igbcav3 = $igbcav2/$numbigb;
	
	$recav11 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Mathematics' AND school='".$_SESSION["school"]."'");
	while($rowcav11 = mysqli_fetch_assoc($recav11))
							{
							$matcavin[]	= $rowcav11['score'];
							}
							$matcav = array_filter($matcavin);
							$matcav2 = array_sum($matcav);
	$numbmat = count(array_filter($matcav));
	$matcav3 = $matcav2/$numbmat;
	
	$recav12 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Music' AND school='".$_SESSION["school"]."'");
	while($rowcav12 = mysqli_fetch_assoc($recav12))
							{
							$muscavin[]	= $rowcav12['score'];
							}
							$muscav = array_filter($muscavin);
							$muscav2 = array_sum($muscav);
	$numbmus = count(array_filter($muscav));
	$muscav3 = $muscav2/$numbmus;
	
	$recav13 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='PHE' AND school='".$_SESSION["school"]."'");
	while($rowcav13 = mysqli_fetch_assoc($recav13))
							{
							$phecavin[]	= $rowcav13['score'];
							}
							$phecav = array_filter($phecavin);
							$phecav2 = array_sum($phecav);
	$numbphe = count(array_filter($phecav));
	$phecav3 = $phecav2/$numbphe;

	$recav14 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Social Studies' AND school='".$_SESSION["school"]."'");
	while($rowcav14 = mysqli_fetch_assoc($recav14))
							{
							$soccavin[]	= $rowcav14['score'];
							}
							$soccav = array_filter($soccavin);
							$soccav2 = array_sum($soccav);
	$numbsoc = count(array_filter($soccav));
	$soccav3 = $soccav2/$numbsoc;
	
	$recav15 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Biology' AND school='".$_SESSION["school"]."'");
	while($rowcav15 = mysqli_fetch_assoc($recav15))
							{
							$biocavin[]	= $rowcav15['score'];
							}
							$biocav = array_filter($biocavin);
							$biocav2 = array_sum($biocav);
	$numbbio = count(array_filter($biocav));
	$biocav3 = $biocav2/$numbbio;
	
	$recav16 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Chemistry' AND school='".$_SESSION["school"]."'");
	while($rowcav16 = mysqli_fetch_assoc($recav16))
							{
							$checavin[]	= $rowcav16['score'];
							}
							$checav = array_filter($checavin);
							$checav2 = array_sum($checav);
	$numbche = count(array_filter($checav));
	$checav3 = $checav2/$numbche;
	
	$recav17 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Economics' AND school='".$_SESSION["school"]."'");
	while($rowcav17 = mysqli_fetch_assoc($recav17))
							{
							$ecocavin[]	= $rowcav17['score'];
							}
							$ecocav = array_filter($ecocavin);
							$ecocav2 = array_sum($ecocav);
	$numbeco = count(array_filter($ecocav));
	$ecocav3 = $ecocav2/$numbeco;
	
	$recav18 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Government' AND school='".$_SESSION["school"]."'");
	while($rowcav18 = mysqli_fetch_assoc($recav18))
							{
							$govcavin[]	= $rowcav18['score'];
							}
							$govcav = array_filter($govcavin);
							$govcav2 = array_sum($govcav);
	$numbgov = count(array_filter($govcav));
	$govcav3 = $govcav2/$numbgov;
	
	$recav19 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='VA' AND school='".$_SESSION["school"]."'");
	while($rowcav19 = mysqli_fetch_assoc($recav19))
							{
							$vacavin[]	= $rowcav19['score'];
							}
							$vacav = array_filter($vacavin);
							$vacav2 = array_sum($vacav);
	$numbva = count(array_filter($vacav));
	$vacav3 = $vacav2/$numbva;
	
	$recav20 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='TD' AND school='".$_SESSION["school"]."'");
	while($rowcav20 = mysqli_fetch_assoc($recav20))
							{
							$tdcavin[]	= $rowcav20['score'];
							}
							$vacav = array_filter($tdcavin);
							$tdcav2 = array_sum($tdcav);
	$numbtd = count(array_filter($tdcav));
	$tdcav3 = $tdcav2/$numbtd;
	
	$recav21 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Sociology' AND school='".$_SESSION["school"]."'");
	while($rowcav21 = mysqli_fetch_assoc($recav21))
							{
							$socicavin[]	= $rowcav21['score'];
							}
							$socicav = array_filter($socicavin);
							$socicav2 = array_sum($socicav);
	$numbsoci = count(array_filter($socicav));
	$socicav3 = $socicav2/$numbsoci;
							
	$recav22 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Physics' AND school='".$_SESSION["school"]."'");
	while($rowcav22 = mysqli_fetch_assoc($recav22))
							{
							$phycavin[]	= $rowcav22['score'];
							}
							$phycav = array_filter($phycavin);
							$phycav2 = array_sum($phycav);
	$numbphy = count(array_filter($phycav));
	$phycav3 = $phycav2/$numbphy;
	
	$recav23 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Marketing' AND school='".$_SESSION["school"]."'");
	while($rowcav23 = mysqli_fetch_assoc($recav23))
							{
							$marcavin[]	= $rowcav23['score'];
							}
							$marcav = array_filter($marcavin);
							$marcav2 = array_sum($marcav);
	$numbmar = count(array_filter($marcav));
	$marcav3 = $marcav2/$numbmar;
	
	$recav24 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Lit in English' AND school='".$_SESSION["school"]."'");
	while($rowcav24 = mysqli_fetch_assoc($recav24))
							{
							$litcavin[]	= $rowcav24['score'];
							}
							$litcav = array_filter($litcavin);
							$litcav2 = array_sum($litcav);
	$numblit = count(array_filter($litcav));
	$litcav3 = $litcav2/$numblit;
	
	$recav25 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Yoruba' AND school='".$_SESSION["school"]."'");
	while($rowcav25 = mysqli_fetch_assoc($recav25))
							{
							$yorcavin[]	= $rowcav25['score'];
							}
							$yorcav = array_filter($yorcavin);
							$yorcav2 = array_sum($yorcav);
	$numbyor = count(array_filter($yorcav));
	$yorcav3 = $yorcav2/$numbyor;
	
	$recav26 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Quantitative Reasoning' AND school='".$_SESSION["school"]."'");
	while($rowcav26 = mysqli_fetch_assoc($recav26))
							{
							$qrcavin[]	= $rowcav26['score'];
							}
							$qrcav = array_filter($qrcavin);
							$qrcav2 = array_sum($qrcav);
	$numbqr = count(array_filter($qrcav));
	$qrcav3 = $qrcav2/$numbqr;
	
	$recav27 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Verbal Reasoning' AND school='".$_SESSION["school"]."'");
	while($rowcav27 = mysqli_fetch_assoc($recav27))
							{
							$vrcavin[]	= $rowcav27['score'];
							}
							$vrcav = array_filter($vrcavin);
							$vrcav2 = array_sum($vrcav);
	$numbvr = count(array_filter($vrcav));
	$vrcav3 = $vrcav2/$numbvr;
	
		$recav28 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Geography' AND school='".$_SESSION["school"]."'");
	$recavmax28 = mysqli_query($db, "SELECT MAX(score) AS agrmax FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Geography' AND school='".$_SESSION["school"]."'");
	while($rowcav28 = mysqli_fetch_assoc($recav28))
							{
							$geocavin[]	= $rowcav28['score'];
							}
							$geocav = array_filter($geocavin);
							$geocav2 = array_sum($geocav);
	$numbgeo = count(array_filter($geocav));
	$geocav3 = $geocav2/$numbgeo;
	
	$recav29 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Handwriting' AND school='".$_SESSION["school"]."'");
	while($rowcav29 = mysqli_fetch_assoc($recav29))
							{
							$hwcavin[]	= $rowcav29['score'];
							}
							$hwcav = array_filter($hwcavin);
							$hwcav2 = array_sum($hwcav);
	$numbhw = count(array_filter($hwcav));
	$hwcav3 = $hwcav2/$numbhw;
	
	$recav30 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Vocational Aptitude' AND school='".$_SESSION["school"]."'");
	while($rowcav30 = mysqli_fetch_assoc($recav30))
							{
							$vapcavin[]	= $rowcav30['score'];
							}
							$vapcav = array_filter($vapcavin);
							$vapcav2 = array_sum($vapcav);
	$numbvap = count(array_filter($vapcav));
	$vapcav3 = $vapcav2/$numbvap;
	
	$recav31 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Phonics' AND school='".$_SESSION["school"]."'");
	while($rowcav31 = mysqli_fetch_assoc($recav31))
							{
							$phocavin[]	= $rowcav31['score'];
							}
							$phocav = array_filter($phocavin);
							$phocav2 = array_sum($phocav);
	$numbpho = count(array_filter($phocav));
	$phocav3 = $phocav2/$numbpho;
	
	$recav32 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Islamic Religious Studies' AND school='".$_SESSION["school"]."'");
	while($rowcav32 = mysqli_fetch_assoc($recav32))
							{
							$irscavin[]	= $rowcav32['score'];
							}
							$irscav = array_filter($irscavin);
							$irscav2 = array_sum($irscav);
	$numbirs = count(array_filter($irscav));
	$irscav3 = $irscav2/$numbirs;
	
	$recav33 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Creative and Cultural Arts' AND school='".$_SESSION["school"]."'");
	while($rowcav33 = mysqli_fetch_assoc($recav33))
							{
							$ccacavin[]	= $rowcav33['score'];
							}
							$ccacav = array_filter($ccacavin);
							$ccacav2 = array_sum($ccacav);
	$numbcca = count(array_filter($ccacav));
	$ccacav3 = $ccacav2/$numbcca;
	
	$recav34 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='History' AND school='".$_SESSION["school"]."'");
	while($rowcav34 = mysqli_fetch_assoc($recav34))
							{
							$hiscavin[]	= $rowcav34['score'];
							}
							$hiscav = array_filter($hiscavin);
							$hiscav2 = array_sum($hiscav);
	$numbhis = count(array_filter($hiscav));
	$hiscav3 = $hiscav2/$numbhis;
	
	$recav35 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Hausa' AND school='".$_SESSION["school"]."'");
	while($rowcav35 = mysqli_fetch_assoc($recav35))
							{
							$haucavin[]	= $rowcav35['score'];
							}
							$haucav = array_filter($haucavin);
							$haucav2 = array_sum($haucav);
	$numbhau = count(array_filter($haucav));
	$haucav3 = $haucav2/$numbhau;
	
	$recav36 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Hausa' AND school='".$_SESSION["school"]."'");
	while($rowcav36 = mysqli_fetch_assoc($recav36))
							{
							$fincavin[]	= $rowcav36['score'];
							}
							$fincav = array_filter($fincavin);
							$fincav2 = array_sum($fincav);
	$numbfin = count(array_filter($fincav));
	$fincav3 = $fincav2/$numbfin;
	
	$engcount = 0;
	$counter = 0;
	$counted = 0;
	while($row = mysqli_fetch_assoc($result))
							{		
		$to = Array($c[$counted], $d[$counted], $t[$counted]);
		if(($t[$counted] == 0) AND ($c[$counted] != 0) AND ($d[$counted] != 0)){$avdiv = 2; $t[$counted] = "-";}
		elseif(($t[$counted] != 0) AND ($c[$counted] != 0) AND ($d[$counted] == 0)){$avdiv = 2; $d[$counted] = "-";}
		elseif(($t[$counted] != 0) AND ($c[$counted] == 0) AND ($d[$counted] != 0)){$avdiv = 2; $d[$counted] = "-";}
		elseif(($t[$counted] == 0) AND ($c[$counted] != 0) AND ($d[$counted] == 0)){$avdiv = 1; $t[$counted] = "-"; $d[$counted] = "-";}
		elseif(($t[$counted] == 0) AND ($c[$counted] == 0) AND ($d[$counted] != 0)){$avdiv = 1; $c[$counted] = "-"; $t[$counted] = "-";}
		elseif(($t[$counted] != 0) AND ($c[$counted] == 0) AND ($d[$counted] == 0)){$avdiv = 1; $c[$counted] = "-"; $d[$counted] = "-";}
		elseif(($t[$counted] != 0) AND ($c[$counted] != 0) AND ($d[$counted] != 0)){$avdiv = 3;}
		else{$avdiv = 3;}
		$to2 = array_sum($to);
		$av = round($to2/$avdiv);
								$cc = $c[$counted];
								$dd = $d[$counted];
								$tt = $t[$counted];
								$grbnt = mysqli_query($db, "SELECT grade FROM gradeband WHERE score='$av'");
							while($rowgrbnt = mysqli_fetch_assoc($grbnt))
							{
							$grade2	= $rowgrbnt['grade'];
							}
							$grade = $grade2;
								
								if($row["subject"] == "Agricultural Science"){$ccav = $agrcav3;}
								elseif($row["subject"] == "Basic Science"){$ccav = $bascav3;}
								elseif($row["subject"] == "English"){$ccav = $engcav3;}
								elseif($row["subject"] == "Business Studies"){$ccav = $buscav3;}
								elseif($row["subject"] == "Catering"){$ccav = $catcav3;}
								elseif($row["subject"] == "Civic Education"){$ccav = $civcav3;}
								elseif($row["subject"] == "Crk"){$ccav = $crkcav3;}
								elseif($row["subject"] == "Food and Nutrition"){$ccav = $foocav3;}
								elseif($row["subject"] == "ICT"){$ccav = $ictcav3;}
								elseif($row["subject"] == "French"){$ccav = $frecav3;}
								elseif($row["subject"] == "Igbo"){$ccav = $igbcav3;}
								elseif($row["subject"] == "Mathematics"){$ccav = $matcav3;}
								elseif($row["subject"] == "Music"){$ccav = $muscav3;}
								elseif($row["subject"] == "PHE"){$ccav = $phecav3;}
								elseif($row["subject"] == "Social Studies"){$ccav = $soccav3;}
								elseif($row["subject"] == "Biology"){$ccav = $biocav3;}
								elseif($row["subject"] == "Chemistry"){$ccav = $checav3;}
								elseif($row["subject"] == "Economics"){$ccav = $ecocav3;}
								elseif($row["subject"] == "Government"){$ccav = $govcav3;}
								elseif($row["subject"] == "VA"){$ccav = $vacav3;}
								elseif($row["subject"] == "TD"){$ccav = $tdcav3;}
								elseif($row["subject"] == "Sociology"){$ccav = $socicav3;}
								elseif($row["subject"] == "Marketing"){$ccav = $marcav3;}
								elseif($row["subject"] == "Physics"){$ccav = $phycav3;}
								elseif($row["subject"] == "Lit in English"){$ccav = $litcav3;}
								elseif($row["subject"] == "Yoruba"){$ccav = $yorcav3;}
								elseif($row["subject"] == "Quantitative Reasoning"){$ccav = $qrcav3;}
								elseif($row["subject"] == "Verbal Reasoning"){$ccav = $vrcav3;}
								elseif($row["subject"] == "Geography"){$ccav = $geocav3;}
								elseif($row["subject"] == "Handwriting"){$ccav = $hwcav3;}
								elseif($row["subject"] == "Vocational Aptitude"){$ccav = $vapcav3;}
								elseif($row["subject"] == "Phonics"){$ccav = $phocav3;}
								elseif($row["subject"] == "Islamic Religious Studies"){$ccav = $irscav3;}
								elseif($row["subject"] == "Creative and Cultural Arts"){$ccav = $ccacav3;}
								elseif($row["subject"] == "History"){$ccav = $hiscav3;}
								elseif($row["subject"] == "Hausa"){$ccav = $haucav3;}
								elseif($row["subject"] == "Financial Accounting"){$ccav = $fincav3;}
								elseif($ccav == ""){$ccav = "-";}
								else{$ccav = "-";}
								$su = $row["subject"];
								$tn = $row["teacher_name"];
								$re = $row["remark"];
								$ct = $row["ca"];
								$ex = $row["exam"];
								
if($su == 'English'){							
	$resultmxbystunameeng1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='English' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeng1))
	{	
		$snm2eng1[] = $rsn['score'];
		$stin2eng[] = $rsn['student_name'];
	}
	$acengf = array_combine($stin2eng,$snm2eng1);
	$resultmxbystunameeng2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='English' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeng2))
	{	
		$snm2eng2[] = $rsn['score'];
	    $stin2eng2[] = $rsn['student_name'];
	}
	$acengs = array_combine($stin2eng2,$snm2eng2);
	$resultmxbystunameeng3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='English' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeng3))
	{	
		$snm2eng3[] = $rsn['score'];
		$stin2eng3[] = $rsn['student_name'];
	}
	$acengt = array_combine($stin2eng3,$snm2eng3);
	$arinall = array($acengf, $acengs, $acengt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acengkeys = (array_keys($largest_arr));
	
$foreng1 = array($snm2eng1[0], $snm2eng1[1], $snm2eng1[2], $snm2eng1[3], $snm2eng1[4], $snm2eng1[5], $snm2eng1[6], $snm2eng1[7], $snm2eng1[8], $snm2eng1[9], $snm2eng1[10], $snm2eng1[11], $snm2eng1[12], $snm2eng1[13], $snm2eng1[14], $snm2eng1[15], $snm2eng1[16], $snm2eng1[17], $snm2eng1[18], $snm2eng1[19], 
		  $snm2eng1[20], $snm2eng1[21], $snm2eng1[22], $snm2eng1[23], $snm2eng1[24], $snm2eng1[25], $snm2eng1[26], $snm2eng1[27], $snm2eng1[28], $snm2eng1[29], $snm2eng1[30], $snm2eng1[31], $snm2eng1[32], $snm2eng1[33], $snm2eng1[34], $snm2eng1[35], $snm2eng1[36], $snm2eng1[37], $snm2eng1[38], $snm2eng1[39], 
		  $snm2eng1[40], $snm2eng1[41], $snm2eng1[42], $snm2eng1[43], $snm2eng1[44], $snm2eng1[45], $snm2eng1[46], $snm2eng1[47], $snm2eng1[48], $snm2eng1[49], $snm2eng1[50], $snm2eng1[51], $snm2eng1[52], $snm2eng1[53], $snm2eng1[54], $snm2eng1[55], $snm2eng1[56], $snm2eng1[57], $snm2eng1[58], $snm2eng1[59], 
		  $snm2eng1[60], $snm2eng1[61], $snm2eng1[62], $snm2eng1[63], $snm2eng1[64], $snm2eng1[65], $snm2eng1[66], $snm2eng1[67], $snm2eng1[68], $snm2eng1[69], $snm2eng1[70], $snm2eng1[71], $snm2eng1[72], $snm2eng1[73], $snm2eng1[74], $snm2eng1[75], $snm2eng1[76], $snm2eng1[77], $snm2eng1[78], $snm2eng1[79], 
		  $snm2eng1[80], $snm2eng1[81], $snm2eng1[82], $snm2eng1[83], $snm2eng1[84], $snm2eng1[85], $snm2eng1[86], $snm2eng1[87], $snm2eng1[88], $snm2eng1[89], $snm2eng1[90], $snm2eng1[91], $snm2eng1[92], $snm2eng1[93], $snm2eng1[94], $snm2eng1[95], $snm2eng1[96], $snm2eng1[97], $snm2eng1[98], $snm2eng1[99], 
		  $snm2eng1[100], $snm2eng1[101], $snm2eng1[102], $snm2eng1[103], $snm2eng1[104], $snm2eng1[105], $snm2eng1[106], $snm2eng1[107], $snm2eng1[108], $snm2eng1[109], $snm2eng1[110], $snm2eng1[111], $snm2eng1[112], $snm2eng1[113], $snm2eng1[114], $snm2eng1[115], $snm2eng1[116], $snm2eng1[117], $snm2eng1[118], $snm2eng1[119],
		  $snm2eng1[120]);
$foreng2 = array($snm2eng2[0], $snm2eng2[1], $snm2eng2[2], $snm2eng2[3], $snm2eng2[4], $snm2eng2[5], $snm2eng2[6], $snm2eng2[7], $snm2eng2[8], $snm2eng2[9], $snm2eng2[10], $snm2eng2[11], $snm2eng2[12], $snm2eng2[13], $snm2eng2[14], $snm2eng2[15], $snm2eng2[16], $snm2eng2[17], $snm2eng2[18], $snm2eng2[19], 
		  $snm2eng2[20], $snm2eng2[21], $snm2eng2[22], $snm2eng2[23], $snm2eng2[24], $snm2eng2[25], $snm2eng2[26], $snm2eng2[27], $snm2eng2[28], $snm2eng2[29], $snm2eng2[30], $snm2eng2[31], $snm2eng2[32], $snm2eng2[33], $snm2eng2[34], $snm2eng2[35], $snm2eng2[36], $snm2eng2[37], $snm2eng2[38], $snm2eng2[39], 
		  $snm2eng2[40], $snm2eng2[41], $snm2eng2[42], $snm2eng2[43], $snm2eng2[44], $snm2eng2[45], $snm2eng2[46], $snm2eng2[47], $snm2eng2[48], $snm2eng2[49], $snm2eng2[50], $snm2eng2[51], $snm2eng2[52], $snm2eng2[53], $snm2eng2[54], $snm2eng2[55], $snm2eng2[56], $snm2eng2[57], $snm2eng2[58], $snm2eng2[59],
		  $snm2eng2[60], $snm2eng2[61], $snm2eng2[62], $snm2eng2[63], $snm2eng2[64], $snm2eng2[65], $snm2eng2[66], $snm2eng2[67], $snm2eng2[68], $snm2eng2[69], $snm2eng2[70], $snm2eng2[71], $snm2eng2[72], $snm2eng2[73], $snm2eng2[74], $snm2eng2[75], $snm2eng2[76], $snm2eng2[77], $snm2eng2[78], $snm2eng2[79],
		  $snm2eng2[80], $snm2eng2[81], $snm2eng2[82], $snm2eng2[83], $snm2eng2[84], $snm2eng2[85], $snm2eng2[86], $snm2eng2[87], $snm2eng2[88], $snm2eng2[89], $snm2eng2[90], $snm2eng2[91], $snm2eng2[92], $snm2eng2[93], $snm2eng2[94], $snm2eng2[95], $snm2eng2[96], $snm2eng2[97], $snm2eng2[98], $snm2eng2[99],
		   $snm2eng2[100], $snm2eng2[101], $snm2eng2[102], $snm2eng2[103], $snm2eng2[104], $snm2eng2[105], $snm2eng2[106], $snm2eng2[107], $snm2eng2[108], $snm2eng2[109], $snm2eng2[110], $snm2eng2[111], $snm2eng2[112], $snm2eng2[113], $snm2eng2[114], $snm2eng2[115], $snm2eng2[116], $snm2eng2[117], $snm2eng2[118], $snm2eng2[119],
		  $snm2eng2[120]);
$foreng3 = array($snm2eng3[0], $snm2eng3[1], $snm2eng3[2], $snm2eng3[3], $snm2eng3[4], $snm2eng3[5], $snm2eng3[6], $snm2eng3[7], $snm2eng3[8], $snm2eng3[9], $snm2eng3[10], $snm2eng3[11], $snm2eng3[12], $snm2eng3[13], $snm2eng3[14], $snm2eng3[15], $snm2eng3[16], $snm2eng3[17], $snm2eng3[18], $snm2eng3[19],
		  $snm2eng3[20], $snm2eng3[21], $snm2eng3[22], $snm2eng3[23], $snm2eng3[24], $snm2eng3[25], $snm2eng3[26], $snm2eng3[27], $snm2eng3[28], $snm2eng3[29], $snm2eng3[30], $snm2eng3[31], $snm2eng3[32], $snm2eng3[33], $snm2eng3[34], $snm2eng3[35], $snm2eng3[36], $snm2eng3[37], $snm2eng3[38], $snm2eng3[39],
		  $snm2eng3[40], $snm2eng3[41], $snm2eng3[42], $snm2eng3[43], $snm2eng3[44], $snm2eng3[45], $snm2eng3[46], $snm2eng3[47], $snm2eng3[48], $snm2eng3[49], $snm2eng3[50], $snm2eng3[51], $snm2eng3[52], $snm2eng3[53], $snm2eng3[54], $snm2eng3[55], $snm2eng3[56], $snm2eng3[57], $snm2eng3[58], $snm2eng3[59],
		  $snm2eng3[60], $snm2eng3[61], $snm2eng3[62], $snm2eng3[63], $snm2eng3[64], $snm2eng3[65], $snm2eng3[66], $snm2eng3[67], $snm2eng3[68], $snm2eng3[69], $snm2eng3[70], $snm2eng3[71], $snm2eng3[72], $snm2eng3[73], $snm2eng3[74], $snm2eng3[75], $snm2eng3[76], $snm2eng3[77], $snm2eng3[78], $snm2eng3[79],
		  $snm2eng3[80], $snm2eng3[81], $snm2eng3[82], $snm2eng3[83], $snm2eng3[84], $snm2eng3[85], $snm2eng3[86], $snm2eng3[87], $snm2eng3[88], $snm2eng3[89], $snm2eng3[90], $snm2eng3[91], $snm2eng3[92], $snm2eng3[93], $snm2eng3[94], $snm2eng3[95], $snm2eng3[96], $snm2eng3[97], $snm2eng3[98], $snm2eng3[99],
		  $snm2eng3[100], $snm2eng3[101], $snm2eng3[102], $snm2eng3[103], $snm2eng3[104], $snm2eng3[105], $snm2eng3[106], $snm2eng3[107], $snm2eng3[108], $snm2eng3[109], $snm2eng3[110], $snm2eng3[111], $snm2eng3[112], $snm2eng3[113], $snm2eng3[114], $snm2eng3[115], $snm2eng3[116], $snm2eng3[117], $snm2eng3[118], $snm2eng3[119],
		  $snm2eng3[120]);
$array_all_eng = array(array_filter($foreng1), array_filter($foreng2), array_filter($foreng3));
	$countingeng = 0;
	while($countingeng <= 120){
	if(count(array_column($array_all_eng, $countingeng)) == 3){
	$engf2[] = round(array_sum(array_column($array_all_eng, $countingeng))/3);
	}
	else if(count(array_column($array_all_eng, $countingeng)) == 2){
	$engf2[] = round(array_sum(array_column($array_all_eng, $countingeng))/2);
	}
	else if(count(array_column($array_all_eng, $countingeng)) == 1){
	$engf2[] = round(array_sum(array_column($array_all_eng, $countingeng))/1);
	}
	else{
	$engf2[] = round(array_sum(array_column($array_all_eng, $countingeng))/3);	
	}
	$countingeng++;
	}
	$engf = implode("-",array_filter($engf2));
	$engmx2 = explode("-",$engf);
	$engmx = max(explode("-",$engf));
	$stnameandscoreEng = array_combine($acengkeys,$engmx2);
	//print_r($stnameandscoreEng);
	echo '<br>';
	$maxinallsub = $engmx;	
	}
	else if($su == 'Agricultural Science'){
		$resultmxbystunameagr1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Agricultural Science' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameagr1))
	{	
		$snm2agr1[] = $rsn['score'];
		$stin2agr[] = $rsn['student_name'];
	}
	$acagrf = array_combine($stin2agr,$snm2agr1);
	$resultmxbystunameagr2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Agricultural Science' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameagr2))
	{	
		$snm2agr2[] = $rsn['score'];
	    $stin2agr2[] = $rsn['student_name'];
	}
	$acagrs = array_combine($stin2agr2,$snm2agr2);
	$resultmxbystunameagr3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Agricultural Science' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameagr3))
	{	
		$snm2agr3[] = $rsn['score'];
		$stin2agr3[] = $rsn['student_name'];
	}
	$acagrt = array_combine($stin2agr3,$snm2agr3);
	$arinall = array($acagrf, $acagrs, $acagrt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acagrkeys = (array_keys($largest_arr));
$foragr1 = 	array($snm2agr1[0], $snm2agr1[1], $snm2agr1[2], $snm2agr1[3], $snm2agr1[4], $snm2agr1[5], $snm2agr1[6], $snm2agr1[7], $snm2agr1[8], $snm2agr1[9], $snm2agr1[10], $snm2agr1[11], $snm2agr1[12], $snm2agr1[13], $snm2agr1[14], $snm2agr1[15], $snm2agr1[16], $snm2agr1[17], $snm2agr1[18], $snm2agr1[19], 
		  $snm2agr1[20], $snm2agr1[21], $snm2agr1[22], $snm2agr1[23], $snm2agr1[24], $snm2agr1[25], $snm2agr1[26], $snm2agr1[27], $snm2agr1[28], $snm2agr1[29], $snm2agr1[30], $snm2agr1[31], $snm2agr1[32], $snm2agr1[33], $snm2agr1[34], $snm2fre1[35], $snm2agr1[36], $snm2agr1[37], $snm2agr1[38], $snm2agr1[39], 
		  $snm2agr1[40], $snm2agr1[41], $snm2agr1[42], $snm2agr1[43], $snm2agr1[44], $snm2agr1[45], $snm2agr1[46], $snm2agr1[47], $snm2agr1[48], $snm2agr1[49], $snm2agr1[50], $snm2agr1[51], $snm2agr1[52], $snm2agr1[53], $snm2agr1[54], $snm2fre1[55], $snm2agr1[56], $snm2agr1[57], $snm2agr1[58], $snm2agr1[59], 
		  $snm2agr1[60], $snm2agr1[61], $snm2agr1[62], $snm2agr1[63], $snm2agr1[64], $snm2agr1[65], $snm2agr1[66], $snm2agr1[67], $snm2agr1[68], $snm2agr1[69], $snm2agr1[70], $snm2agr1[71], $snm2agr1[72], $snm2agr1[73], $snm2agr1[74], $snm2fre1[75], $snm2agr1[76], $snm2agr1[77], $snm2agr1[78], $snm2agr1[79], 
		  $snm2agr1[80], $snm2agr1[81], $snm2agr1[82], $snm2agr1[83], $snm2agr1[84], $snm2agr1[85], $snm2agr1[86], $snm2agr1[87], $snm2agr1[88], $snm2agr1[89], $snm2agr1[90], $snm2agr1[91], $snm2agr1[92], $snm2agr1[93], $snm2agr1[94], $snm2fre1[95], $snm2agr1[96], $snm2agr1[97], $snm2agr1[98], $snm2agr1[99], 
		  $snm2agr1[100], $snm2agr1[101], $snm2agr1[102], $snm2agr1[103], $snm2agr1[104], $snm2agr1[105], $snm2agr1[106], $snm2agr1[107], $snm2agr1[108], $snm2agr1[109], $snm2agr1[110], $snm2agr1[111], $snm2agr1[112], $snm2agr1[113], $snm2agr1[114], $snm2agr1[115], $snm2agr1[116], $snm2agr1[117], $snm2agr1[118], $snm2agr1[119],
		  $snm2agr1[120]);
$foragr2 = 	array($snm2agr2[0], $snm2agr2[1], $snm2agr2[2], $snm2agr2[3], $snm2agr2[4], $snm2agr2[5], $snm2agr2[6], $snm2agr2[7], $snm2agr2[8], $snm2agr2[9], $snm2agr2[10], $snm2agr2[11], $snm2agr2[12], $snm2agr2[13], $snm2agr2[14], $snm2agr2[15], $snm2agr2[16], $snm2agr2[17], $snm2agr2[18], $snm2agr2[19], 
		  $snm2agr2[20], $snm2agr2[21], $snm2agr2[22], $snm2agr2[23], $snm2agr2[24], $snm2agr2[25], $snm2agr2[26], $snm2agr2[27], $snm2agr2[28], $snm2agr2[29], $snm2agr2[30], $snm2agr2[31], $snm2agr2[32], $snm2agr2[33], $snm2agr2[34], $snm2agr2[35], $snm2agr2[36], $snm2agr2[37], $snm2agr2[38], $snm2agr2[39], 
		  $snm2agr2[40], $snm2agr2[41], $snm2agr2[42], $snm2agr2[43], $snm2fre2[44], $snm2agr2[45], $snm2agr2[46], $snm2agr2[47], $snm2agr2[48], $snm2agr2[49], $snm2agr2[50], $snm2agr2[51], $snm2agr2[52], $snm2agr2[53], $snm2agr2[54], $snm2agr2[55], $snm2agr2[56], $snm2agr2[57], $snm2agr2[58], $snm2agr2[59],
		  $snm2agr2[60], $snm2agr2[61], $snm2agr2[62], $snm2agr2[63], $snm2fre2[64], $snm2agr2[65], $snm2agr2[66], $snm2agr2[67], $snm2agr2[68], $snm2agr2[69], $snm2agr2[70], $snm2agr2[71], $snm2agr2[72], $snm2agr2[73], $snm2agr2[74], $snm2agr2[75], $snm2agr2[76], $snm2agr2[77], $snm2agr2[78], $snm2agr2[79],
		  $snm2agr2[80], $snm2agr2[81], $snm2agr2[82], $snm2agr2[83], $snm2fre2[84], $snm2agr2[85], $snm2agr2[86], $snm2agr2[87], $snm2agr2[88], $snm2agr2[89], $snm2agr2[90], $snm2agr2[91], $snm2agr2[92], $snm2agr2[93], $snm2agr2[94], $snm2agr2[95], $snm2agr2[96], $snm2agr2[97], $snm2agr2[98], $snm2agr2[99],
		   $snm2agr2[100], $snm2agr2[101], $snm2agr2[102], $snm2agr2[103], $snm2agr2[104], $snm2agr2[105], $snm2agr2[106], $snm2agr2[107], $snm2agr2[108], $snm2agr2[109], $snm2agr2[110], $snm2agr2[111], $snm2agr2[112], $snm2agr2[113], $snm2agr2[114], $snm2agr2[115], $snm2agr2[116], $snm2agr2[117], $snm2agr2[118], $snm2agr2[119],
		  $snm2agr2[120]);
$foragr3 = 	array($snm2agr3[0], $snm2agr3[1], $snm2agr3[2], $snm2agr3[3], $snm2agr3[4], $snm2agr3[5], $snm2agr3[6], $snm2agr3[7], $snm2agr3[8], $snm2agr3[9], $snm2agr3[10], $snm2agr3[11], $snm2agr3[12], $snm2agr3[13], $snm2agr3[14], $snm2agr3[15], $snm2agr3[16], $snm2agr3[17], $snm2agr3[18], $snm2agr3[19],
		  $snm2agr3[20], $snm2agr3[21], $snm2agr3[22], $snm2agr3[23], $snm2agr3[24], $snm2agr3[25], $snm2agr3[26], $snm2agr3[27], $snm2agr3[28], $snm2agr3[29], $snm2agr3[30], $snm2agr3[31], $snm2agr3[32], $snm2agr3[33], $snm2agr3[34], $snm2agr3[35], $snm2agr3[36], $snm2agr3[37], $snm2agr3[38], $snm2agr3[39], 
		  $snm2agr3[41], $snm2agr3[41], $snm2agr3[42], $snm2agr3[43], $snm2agr3[44], $snm2agr3[45], $snm2agr3[46], $snm2agr3[47], $snm2agr3[48], $snm2agr3[49], $snm2agr3[50], $snm2agr3[51], $snm2agr3[52], $snm2agr3[53], $snm2agr3[54], $snm2agr3[55], $snm2agr3[56], $snm2agr3[57], $snm2agr3[58], $snm2agr3[59],
		  $snm2agr3[60], $snm2agr3[61], $snm2agr3[62], $snm2agr3[63], $snm2agr3[64], $snm2agr3[65], $snm2agr3[66], $snm2agr3[67], $snm2agr3[68], $snm2agr3[69], $snm2agr3[70], $snm2agr3[71], $snm2agr3[72], $snm2agr3[73], $snm2agr3[74], $snm2agr3[75], $snm2agr3[76], $snm2agr3[77], $snm2agr3[78], $snm2agr3[79],
		  $snm2agr3[80], $snm2agr3[81], $snm2agr3[82], $snm2agr3[83], $snm2agr3[84], $snm2agr3[85], $snm2agr3[86], $snm2agr3[87], $snm2agr3[88], $snm2agr3[89], $snm2agr3[90], $snm2agr3[91], $snm2agr3[92], $snm2agr3[93], $snm2agr3[94], $snm2agr3[95], $snm2agr3[96], $snm2agr3[97], $snm2agr3[98], $snm2agr3[99],
		  $snm2agr3[100], $snm2agr3[101], $snm2agr3[102], $snm2agr3[103], $snm2agr3[104], $snm2agr3[105], $snm2agr3[106], $snm2agr3[107], $snm2agr3[108], $snm2agr3[109], $snm2agr3[110], $snm2agr3[111], $snm2agr3[112], $snm2agr3[113], $snm2agr3[114], $snm2agr3[115], $snm2agr3[116], $snm2agr3[117], $snm2agr3[118], $snm2agr3[119],
		  $snm2agr3[120]);	  
	$array_all_agr = array(array_filter($foragr1), array_filter($foragr2), array_filter($foragr3));
	$countingagr = 0;
	while($countingagr <= 120){
	if(count(array_column($array_all_agr, $countingagr)) == 3){
	$agrf2[] = round(array_sum(array_column($array_all_agr, $countingagr))/3);
	}
	else if(count(array_column($array_all_agr, $countingagr)) == 2){
	$agrf2[] = round(array_sum(array_column($array_all_agr, $countingagr))/2);
	}
	else if(count(array_column($array_all_agr, $countingagr)) == 1){
	$agrf2[] = round(array_sum(array_column($array_all_agr, $countingagr))/1);
	}
	else{
	$agrf2[] = round(array_sum(array_column($array_all_agr, $countingagr))/3);	
	}
	$countingagr++;
	}
	$agrf = implode("-",array_filter($agrf2));
	$agrmx2 = explode("-",$agrf);
	$agrmx = max(explode("-",$agrf));
	$stnameandscoreAgr = array_combine($acagrkeys,$agrmx2);
	//print_r($stnameandscoreAgr);
	//echo '<br>';
	$maxinallsub = $agrmx;	
	}
	else if($su == 'Basic Science'){
		$resultmxbystunamebas1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Basic Science' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebas1))
	{	
		$snm2bas1[] = $rsn['score'];
		$stin2bas[] = $rsn['student_name'];
	}
	$acbasf = array_combine($stin2bas,$snm2bas1);
	$resultmxbystunamebas2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Basic Science' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebas2))
	{	
		$snm2bas2[] = $rsn['score'];
	    $stin2bas2[] = $rsn['student_name'];
	}
	$acbass = array_combine($stin2bas2,$snm2bas2);
	$resultmxbystunamebas3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Basic Science' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebas3))
	{	
		$snm2bas3[] = $rsn['score'];
		$stin2bas3[] = $rsn['student_name'];
	}
	$acbast = array_combine($stin2bas3,$snm2bas3);
	$arinall = array($acbasf, $acbass, $acbast);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acbaskeys = (array_keys($largest_arr));
$forbas1 = 	array($snm2bas1[0], $snm2bas1[1], $snm2bas1[2], $snm2bas1[3], $snm2bas1[4], $snm2bas1[5], $snm2bas1[6], $snm2bas1[7], $snm2bas1[8], $snm2bas1[9], $snm2bas1[10], $snm2bas1[11], $snm2bas1[12], $snm2bas1[13], $snm2bas1[14], $snm2bas1[15], $snm2bas1[16], $snm2bas1[17], $snm2bas1[18], $snm2bas1[19], 
		  $snm2bas1[20], $snm2bas1[21], $snm2bas1[22], $snm2bas1[23], $snm2bas1[24], $snm2bas1[25], $snm2bas1[26], $snm2bas1[27], $snm2bas1[28], $snm2bas1[29], $snm2bas1[30], $snm2bas1[31], $snm2bas1[32], $snm2bas1[33], $snm2bas1[34], $snm2bas1[35], $snm2bas1[36], $snm2bas1[37], $snm2bas1[38], $snm2bas1[39], 
		  $snm2bas1[40], $snm2bas1[41], $snm2bas1[42], $snm2bas1[43], $snm2bas1[44], $snm2bas1[45], $snm2bas1[46], $snm2bas1[47], $snm2bas1[48], $snm2bas1[49], $snm2bas1[50], $snm2bas1[51], $snm2bas1[52], $snm2bas1[53], $snm2bas1[54], $snm2bas1[55], $snm2bas1[56], $snm2bas1[57], $snm2bas1[58], $snm2bas1[59], 
		  $snm2bas1[60], $snm2bas1[61], $snm2bas1[62], $snm2bas1[63], $snm2bas1[64], $snm2bas1[65], $snm2bas1[66], $snm2bas1[67], $snm2bas1[68], $snm2bas1[69], $snm2bas1[70], $snm2bas1[71], $snm2bas1[72], $snm2bas1[73], $snm2bas1[74], $snm2bas1[75], $snm2bas1[76], $snm2bas1[77], $snm2bas1[78], $snm2bas1[79], 
		  $snm2bas1[80], $snm2bas1[81], $snm2bas1[82], $snm2bas1[83], $snm2bas1[84], $snm2bas1[85], $snm2bas1[86], $snm2bas1[87], $snm2bas1[88], $snm2bas1[89], $snm2bas1[90], $snm2bas1[91], $snm2bas1[92], $snm2bas1[93], $snm2bas1[94], $snm2bas1[95], $snm2bas1[96], $snm2bas1[97], $snm2bas1[98], $snm2bas1[99], 
		  $snm2bas1[100], $snm2bas1[101], $snm2bas1[102], $snm2bas1[103], $snm2bas1[104], $snm2bas1[105], $snm2bas1[106], $snm2bas1[107], $snm2bas1[108], $snm2bas1[109], $snm2bas1[110], $snm2bas1[111], $snm2bas1[112], $snm2bas1[113], $snm2bas1[114], $snm2bas1[115], $snm2bas1[116], $snm2bas1[117], $snm2bas1[118], $snm2bas1[119], 
		  $snm2bas1[120]);
$foragr2 = 	array($snm2bas2[0], $snm2bas2[1], $snm2bas2[2], $snm2bas2[3], $snm2bas2[4], $snm2bas2[5], $snm2bas2[6], $snm2bas2[7], $snm2bas2[8], $snm2bas2[9], $snm2bas2[10], $snm2bas2[11], $snm2bas1[12], $snm2bas2[13], $snm2bas2[14], $snm2bas2[15], $snm2bas2[16], $snm2bas2[17], $snm2bas2[18], $snm2bas2[19], 
		  $snm2bas2[20], $snm2bas2[21], $snm2bas2[22], $snm2bas2[23], $snm2bas2[24], $snm2bas2[25], $snm2bas2[26], $snm2bas2[27], $snm2bas2[28], $snm2bas2[29], $snm2bas2[30], $snm2bas2[31], $snm2bas2[32], $snm2bas2[33], $snm2bas2[34], $snm2bas2[35], $snm2bas2[36], $snm2bas2[37], $snm2bas2[38], $snm2bas2[39], 
		  $snm2bas2[40], $snm2bas2[41], $snm2bas2[42], $snm2bas2[43], $snm2bas2[44], $snm2bas2[45], $snm2bas2[46], $snm2bas2[47], $snm2bas2[48], $snm2bas2[49], $snm2bas2[50], $snm2bas2[51], $snm2bas2[52], $snm2bas2[53], $snm2bas2[54], $snm2bas2[55], $snm2bas2[56], $snm2bas2[57], $snm2bas2[58], $snm2bas2[59], 
		  $snm2bas2[60], $snm2bas2[61], $snm2bas2[62], $snm2bas2[63], $snm2bas2[64], $snm2bas2[65], $snm2bas2[66], $snm2bas2[67], $snm2bas2[68], $snm2bas2[69], $snm2bas2[70], $snm2bas2[71], $snm2bas2[72], $snm2bas2[73], $snm2bas2[74], $snm2bas2[75], $snm2bas2[76], $snm2bas2[77], $snm2bas2[78], $snm2bas2[79], 
		  $snm2bas2[80], $snm2bas2[81], $snm2bas2[82], $snm2bas2[83], $snm2bas2[84], $snm2bas2[85], $snm2bas2[86], $snm2bas2[87], $snm2bas2[88], $snm2bas2[89], $snm2bas2[90], $snm2bas2[91], $snm2bas2[92], $snm2bas2[93], $snm2bas2[94], $snm2bas2[95], $snm2bas2[96], $snm2bas2[97], $snm2bas2[98], $snm2bas2[99], 
		  $snm2bas2[100], $snm2bas2[101], $snm2bas2[102], $snm2bas2[103], $snm2bas2[104], $snm2bas2[105], $snm2bas2[106], $snm2bas2[107], $snm2bas2[108], $snm2bas2[109], $snm2bas2[110], $snm2bas2[111], $snm2bas2[112], $snm2bas2[113], $snm2bas2[114], $snm2bas2[115], $snm2bas2[116], $snm2bas2[117], $snm2bas2[118], $snm2bas2[119], 
		  $snm2bas2[120]);
$foragr3 = 	array($snm2bas3[0], $snm2bas3[1], $snm2bas3[2], $snm2bas3[3], $snm2bas3[4], $snm2bas3[5], $snm2bas3[6], $snm2bas3[7], $snm2bas3[8], $snm2bas3[9], $snm2bas3[10], $snm2bas3[11], $snm2bas3[12], $snm2bas3[13], $snm2bas3[14], $snm2bas3[15], $snm2bas3[16], $snm2bas3[17], $snm2bas3[18], $snm2bas3[19],
		  $snm2bas3[20], $snm2bas3[21], $snm2bas3[22], $snm2bas3[23], $snm2bas3[24], $snm2bas3[25], $snm2bas3[26], $snm2bas3[27], $snm2bas3[28], $snm2bas3[29], $snm2bas3[30], $snm2bas3[31], $snm2bas3[32], $snm2bas3[33], $snm2bas3[34], $snm2bas3[35], $snm2bas3[36], $snm2bas3[37], $snm2bas3[38], $snm2bas3[39], 
		  $snm2bas3[40], $snm2bas3[41], $snm2bas3[42], $snm2bas3[43], $snm2bas3[44], $snm2bas3[45], $snm2bas3[46], $snm2bas3[47], $snm2bas3[48], $snm2bas3[49], $snm2bas3[50], $snm2bas3[51], $snm2bas3[52], $snm2bas3[53], $snm2bas3[54], $snm2bas3[55], $snm2bas3[56], $snm2bas3[57], $snm2bas3[58], $snm2bas3[69], 
		  $snm2bas3[60], $snm2bas3[61], $snm2bas3[62], $snm2bas3[63], $snm2bas3[64], $snm2bas3[65], $snm2bas3[66], $snm2bas3[67], $snm2bas3[68], $snm2bas3[69], $snm2bas3[70], $snm2bas3[71], $snm2bas3[72], $snm2bas3[73], $snm2bas3[74], $snm2bas3[75], $snm2bas3[76], $snm2bas3[77], $snm2bas3[78], $snm2bas3[79], 
		  $snm2bas3[80], $snm2bas3[81], $snm2bas3[82], $snm2bas3[83], $snm2bas3[84], $snm2bas3[85], $snm2bas3[86], $snm2bas3[87], $snm2bas3[88], $snm2bas3[89], $snm2bas3[90], $snm2bas3[91], $snm2bas3[92], $snm2bas3[93], $snm2bas3[94], $snm2bas3[95], $snm2bas3[96], $snm2bas3[97], $snm2bas3[98], $snm2bas3[99], 
		  $snm2bas3[100], $snm2bas3[101], $snm2bas3[102], $snm2bas3[103], $snm2bas3[104], $snm2bas3[105], $snm2bas3[106], $snm2bas3[107], $snm2bas3[108], $snm2bas3[109], $snm2bas3[110], $snm2bas3[111], $snm2bas3[112], $snm2bas3[113], $snm2bas3[114], $snm2bas3[115], $snm2bas3[116], $snm2bas3[117], $snm2bas3[118], $snm2bas3[119], 
		  $snm2bas3[120]);	  
	$array_all_bas = array(array_filter($forbas1), array_filter($forbas2), array_filter($forbas3));
	$countingbas = 0;
	while($countingbas <= 120){
	if(count(array_column($array_all_bas, $countingbas)) == 3){
	$basf2[] = round(array_sum(array_column($array_all_bas, $countingbas))/3);
	}
	else if(count(array_column($array_all_bas, $countingbas)) == 2){
	$basf2[] = round(array_sum(array_column($array_all_bas, $countingbas))/2);
	}
	else if(count(array_column($array_all_bas, $countingbas)) == 1){
	$basf2[] = round(array_sum(array_column($array_all_bas, $countingbas))/1);
	}
	else{
	$basf2[] = round(array_sum(array_column($array_all_bas, $countingbas))/3);	
	}
	$countingbas++;
	}
	$basf = implode("-",array_filter($basf2));
	$basmx2 = explode("-",$basf);
	$basmx = max(explode("-",$basf));
	$stnameandscoreBas = array_combine($acbaskeys,$basmx2);
	$maxinallsub = $basmx;	
	}
			else if($su == 'Biology'){
		$resultmxbystunamebio1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Biology' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebio1))
	{	
		$snm2bio1[] = $rsn['score'];
		$stin2bio[] = $rsn['student_name'];
	}
	$acbiof = array_combine($stin2bio,$snm2bio1);
	$resultmxbystunamebio2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Biology' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebio2))
	{	
		$snm2bio2[] = $rsn['score'];
	    $stin2bio2[] = $rsn['student_name'];
	}
	$acbios = array_combine($stin2bio2,$snm2bio2);
	$resultmxbystunamebio3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Biology' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebio3))
	{	
		$snm2bio3[] = $rsn['score'];
		$stin2bio3[] = $rsn['student_name'];
	}
	$acbiot = array_combine($stin2bio3,$snm2bio3);
	$arinall = array($acbiof, $acbios, $acbiot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acbiokeys = (array_keys($largest_arr));
$forbio1 = 	array($snm2bio1[0], $snm2bio1[1], $snm2bio1[2], $snm2bio1[3], $snm2bio1[4], $snm2bio1[5], $snm2bio1[6], $snm2bio1[7], $snm2bio1[8], $snm2bio1[9], $snm2bio1[10], $snm2bio1[11], $snm2bio1[12], $snm2bio1[13], $snm2bio1[14], $snm2bio1[15], $snm2bio1[16], $snm2bio1[17], $snm2bio1[18], $snm2bio1[19], 
		$snm2bio1[20], $snm2bio1[21], $snm2bio1[22], $snm2bio1[23], $snm2bio1[24], $snm2bio1[25], $snm2bio1[26], $snm2bio1[27], $snm2bio1[28], $snm2bio1[29], $snm2bio1[30], $snm2bio1[31], $snm2bio1[32], $snm2bio1[33], $snm2bio1[34], $snm2bio1[35], $snm2bio1[36], $snm2bio1[37], $snm2bio1[38], $snm2bio1[39], 
		$snm2bio1[40], $snm2bio1[41], $snm2bio1[42], $snm2bio1[43], $snm2bio1[44], $snm2bio1[45], $snm2bio1[46], $snm2bio1[47], $snm2bio1[48], $snm2bio1[49], $snm2bio1[50], $snm2bio1[51], $snm2bio1[52], $snm2bio1[53], $snm2bio1[54], $snm2bio1[55], $snm2bio1[56], $snm2bio1[57], $snm2bio1[58], $snm2bio1[59], 
		$snm2bio1[60], $snm2bio1[61], $snm2bio1[62], $snm2bio1[63], $snm2bio1[64], $snm2bio1[65], $snm2bio1[66], $snm2bio1[67], $snm2bio1[68], $snm2bio1[69], $snm2bio1[70], $snm2bio1[71], $snm2bio1[72], $snm2bio1[73], $snm2bio1[74], $snm2bio1[75], $snm2bio1[76], $snm2bio1[77], $snm2bio1[78], $snm2bio1[79], 
		$snm2bio1[80], $snm2bio1[81], $snm2bio1[82], $snm2bio1[83], $snm2bio1[84], $snm2bio1[85], $snm2bio1[86], $snm2bio1[87], $snm2bio1[88], $snm2bio1[89], $snm2bio1[90], $snm2bio1[91], $snm2bio1[92], $snm2bio1[93], $snm2bio1[94], $snm2bio1[95], $snm2bio1[96], $snm2bio1[97], $snm2bio1[98], $snm2bio1[99], 
		$snm2bio1[100], $snm2bio1[101], $snm2bio1[102], $snm2bio1[103], $snm2bio1[104], $snm2bio1[105], $snm2bio1[106], $snm2bio1[107], $snm2bio1[108], $snm2bio1[109], $snm2bio1[110], $snm2bio1[111], $snm2bio1[112], $snm2bio1[113], $snm2bio1[114], $snm2bio1[115], $snm2bio1[116], $snm2bio1[117], $snm2bio1[118], $snm2bio1[119], 
		$snm2bio1[120]);
$forbio2 = 	array($snm2bio2[0], $snm2bio2[1], $snm2bio2[2], $snm2bio2[3], $snm2bio2[4], $snm2bio2[5], $snm2bio2[6], $snm2bio2[7], $snm2bio2[8], $snm2bio2[9], $snm2bio2[10], $snm2bio2[11], $snm2bio2[12], $snm2bio2[13], $snm2bio2[14], $snm2bio2[15], $snm2bio2[16], $snm2bio2[17], $snm2bio2[18], $snm2bio2[19], 
		$snm2bio2[20], $snm2bio2[21], $snm2bio2[22], $snm2bio2[23], $snm2bio2[24], $snm2bio2[25], $snm2bio2[26], $snm2bio2[27], $snm2bio2[28], $snm2bio2[29], $snm2bio2[30], $snm2bio2[31], $snm2bio2[32], $snm2bio2[33], $snm2bio2[34], $snm2bio2[35], $snm2bio2[36], $snm2bio2[37], $snm2bio2[38], $snm2bio2[39], 
		$snm2bio2[40], $snm2bio2[41], $snm2bio2[42], $snm2bio2[43], $snm2bio2[44], $snm2bio2[45], $snm2bio2[46], $snm2bio2[47], $snm2bio2[48], $snm2bio2[49], $snm2bio2[50], $snm2bio2[51], $snm2bio2[52], $snm2bio2[53], $snm2bio2[54], $snm2bio2[55], $snm2bio2[56], $snm2bio2[57], $snm2bio2[58], $snm2bio2[59], 
		$snm2bio2[60], $snm2bio2[61], $snm2bio2[62], $snm2bio2[63], $snm2bio2[64], $snm2bio2[65], $snm2bio2[66], $snm2bio2[67], $snm2bio2[68], $snm2bio2[69], $snm2bio2[70], $snm2bio2[71], $snm2bio2[72], $snm2bio2[73], $snm2bio2[74], $snm2bio2[75], $snm2bio2[76], $snm2bio2[77], $snm2bio2[78], $snm2bio2[79], 
		$snm2bio2[80], $snm2bio2[81], $snm2bio2[82], $snm2bio2[83], $snm2bio2[84], $snm2bio2[85], $snm2bio2[86], $snm2bio2[87], $snm2bio2[88], $snm2bio2[89], $snm2bio2[90], $snm2bio2[91], $snm2bio2[92], $snm2bio2[93], $snm2bio2[94], $snm2bio2[95], $snm2bio2[96], $snm2bio2[97], $snm2bio2[98], $snm2bio2[99], 
		$snm2bio2[100], $snm2bio2[101], $snm2bio2[102], $snm2bio2[103], $snm2bio2[104], $snm2bio2[105], $snm2bio2[106], $snm2bio2[107], $snm2bio2[108], $snm2bio2[109], $snm2bio2[110], $snm2bio2[111], $snm2bio2[112], $snm2bio2[113], $snm2bio2[114], $snm2bio2[115], $snm2bio2[116], $snm2bio2[117], $snm2bio2[118], $snm2bio2[119], 
		$snm2bio2[120]);
$forbio3 = 	array($snm2bio3[0], $snm2bio3[1], $snm2bio3[2], $snm2bio3[3], $snm2bio3[4], $snm2bio3[5], $snm2bio3[6], $snm2bio3[7], $snm2bio3[8], $snm2bio3[9], $snm2bio3[10], $snm2bio3[11], $snm2bio3[12], $snm2bio3[13], $snm2bio3[14], $snm2bio3[15], $snm2bio3[16], $snm2bio3[17], $snm2bio3[18], $snm2bio3[19], 
		$snm2bio3[20], $snm2bio3[21], $snm2bio3[22], $snm2bio3[23], $snm2bio3[24], $snm2bio3[25], $snm2bio3[26], $snm2bio3[27], $snm2bio3[28], $snm2bio3[29], $snm2bio3[30], $snm2bio3[31], $snm2bio3[32], $snm2bio3[33], $snm2bio3[34], $snm2bio3[35], $snm2bio3[36], $snm2bio3[37], $snm2bio3[38], $snm2bio3[39], 
		$snm2bio3[40], $snm2bio3[41], $snm2bio3[42], $snm2bio3[43], $snm2bio3[44], $snm2bio3[45], $snm2bio3[46], $snm2bio3[47], $snm2bio3[48], $snm2bio3[49], $snm2bio3[50], $snm2bio3[51], $snm2bio3[52], $snm2bio3[53], $snm2bio3[54], $snm2bio3[55], $snm2bio3[56], $snm2bio3[57], $snm2bio3[58], $snm2bio3[59], 
		$snm2bio3[60], $snm2bio3[61], $snm2bio3[62], $snm2bio3[63], $snm2bio3[64], $snm2bio3[65], $snm2bio3[66], $snm2bio3[67], $snm2bio3[68], $snm2bio3[69], $snm2bio3[70], $snm2bio3[71], $snm2bio3[72], $snm2bio3[73], $snm2bio3[74], $snm2bio3[75], $snm2bio3[76], $snm2bio3[77], $snm2bio3[78], $snm2bio3[79], 
		$snm2bio3[80], $snm2bio3[81], $snm2bio3[82], $snm2bio3[83], $snm2bio3[84], $snm2bio3[85], $snm2bio3[86], $snm2bio3[87], $snm2bio3[88], $snm2bio3[89], $snm2bio3[90], $snm2bio3[91], $snm2bio3[92], $snm2bio3[93], $snm2bio3[94], $snm2bio3[95], $snm2bio3[96], $snm2bio3[97], $snm2bio3[98], $snm2bio3[99], 
		$snm2bio3[100], $snm2bio3[101], $snm2bio3[102], $snm2bio3[103], $snm2bio3[104], $snm2bio3[105], $snm2bio3[106], $snm2bio3[107], $snm2bio3[108], $snm2bio3[109], $snm2bio3[110], $snm2bio3[111], $snm2bio3[112], $snm2bio3[113], $snm2bio3[114], $snm2bio3[115], $snm2bio3[116], $snm2bio3[117], $snm2bio3[118], $snm2bio3[119], 
		$snm2bio3[120]);
	}
	else if($su == 'Business Studies'){
		$resultmxbystunamebus1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Business Studies' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebus1))
	{	
		$snm2bus1[] = $rsn['score'];
		$stin2bus[] = $rsn['student_name'];
	}
	$acbusf = array_combine($stin2bus,$snm2bus1);
	$resultmxbystunamebus2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Business Studies' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebus2))
	{	
		$snm2bus2[] = $rsn['score'];
	    $stin2bus2[] = $rsn['student_name'];
	}
	$acbuss = array_combine($stin2bus2,$snm2bus2);
	$resultmxbystunamebus3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Business Studies' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebus3))
	{	
		$snm2bus3[] = $rsn['score'];
		$stin2bus3[] = $rsn['student_name'];
	}
	$acbust = array_combine($stin2bus3,$snm2bus3);
	$arinall = array($acbusf, $acbuss, $acbust);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acbuskeys = (array_keys($largest_arr));
$forbus1 = 	array($snm2bus1[0], $snm2bus1[1], $snm2bus1[2], $snm2bus1[3], $snm2bus1[4], $snm2bus1[5], $snm2bus1[6], $snm2bus1[7], $snm2bus1[8], $snm2bus1[9], $snm2bus1[10], $snm2bus1[11], $snm2bus1[12], $snm2bus1[13], $snm2bus1[14], $snm2bus1[15], $snm2bus1[16], $snm2bus1[17], $snm2bus1[18], $snm2bus1[19], 
		$snm2bus1[20], $snm2bus1[21], $snm2bus1[22], $snm2bus1[23], $snm2bus1[24], $snm2bus1[25], $snm2bus1[26], $snm2bus1[27], $snm2bus1[28], $snm2bus1[29], $snm2bus1[30], $snm2bus1[31], $snm2bus1[32], $snm2bus1[33], $snm2bus1[34], $snm2bus1[35], $snm2bus1[36], $snm2bus1[37], $snm2bus1[38], $snm2bus1[39], 
		$snm2bus1[40], $snm2bus1[41], $snm2bus1[42], $snm2bus1[43], $snm2bus1[44], $snm2bus1[45], $snm2bus1[46], $snm2bus1[47], $snm2bus1[48], $snm2bus1[49], $snm2bus1[50], $snm2bus1[51], $snm2bus1[52], $snm2bus1[53], $snm2bus1[54], $snm2bus1[55], $snm2bus1[56], $snm2bus1[57], $snm2bus1[58], $snm2bus1[59], 
		$snm2bus1[60], $snm2bio1[61], $snm2bus1[62], $snm2bus1[63], $snm2bus1[64], $snm2bus1[65], $snm2bus1[66], $snm2bus1[67], $snm2bus1[68], $snm2bus1[69], $snm2bus1[70], $snm2bus1[71], $snm2bus1[72], $snm2bus1[73], $snm2bus1[74], $snm2bus1[75], $snm2bus1[76], $snm2bus1[77], $snm2bus1[78], $snm2bus1[79], 
		$snm2bus1[80], $snm2bus1[81], $snm2bus1[82], $snm2bus1[83], $snm2bus1[84], $snm2bus1[85], $snm2bus1[86], $snm2bus1[87], $snm2bus1[88], $snm2bus1[89], $snm2bus1[90], $snm2bus1[91], $snm2bus1[92], $snm2bus1[93], $snm2bus1[94], $snm2bus1[95], $snm2bus1[96], $snm2bus1[97], $snm2bus1[98], $snm2bus1[99], 
		$snm2bus1[100], $snm2bus1[101], $snm2bus1[102], $snm2bus1[103], $snm2bus1[104], $snm2bus1[105], $snm2bus1[106], $snm2bus1[107], $snm2bus1[108], $snm2bus1[109], $snm2bus1[110], $snm2bus1[111], $snm2bus1[112], $snm2bus1[113], $snm2bus1[114], $snm2bus1[115], $snm2bus1[116], $snm2bus1[117], $snm2bus1[118], $snm2bus1[119], 
		$snm2bus1[120]);
$forbus2 = 	array($snm2bus2[0], $snm2bus2[1], $snm2bus2[2], $snm2bus2[3], $snm2bus2[4], $snm2bus2[5], $snm2bus2[6], $snm2bus2[7], $snm2bus2[8], $snm2bus2[9], $snm2bus2[10], $snm2bus2[11], $snm2bus2[12], $snm2bus2[13], $snm2bus2[14], $snm2bus2[15], $snm2bus2[16], $snm2bus2[17], $snm2bus2[18], $snm2bus2[19], 
		$snm2bus2[20], $snm2bus2[21], $snm2bus2[22], $snm2bus2[23], $snm2bus2[24], $snm2bus2[25], $snm2bus2[26], $snm2bus2[27], $snm2bus2[28], $snm2bus2[29], $snm2bus2[30], $snm2bus2[31], $snm2bus2[32], $snm2bus2[33], $snm2bus2[34], $snm2bus2[35], $snm2bus2[36], $snm2bus2[37], $snm2bus2[38], $snm2bus2[39], 
		$snm2bus2[40], $snm2bus2[41], $snm2bus2[42], $snm2bus2[43], $snm2bus2[44], $snm2bus2[45], $snm2bus2[46], $snm2bus2[47], $snm2bus2[48], $snm2bus2[49], $snm2bus2[50], $snm2bus2[51], $snm2bus2[52], $snm2bus2[53], $snm2bus2[54], $snm2bus2[55], $snm2bus2[56], $snm2bus2[57], $snm2bus2[58], $snm2bus2[59], 
		$snm2bus2[60], $snm2bus2[61], $snm2bus2[62], $snm2bus2[63], $snm2bus2[64], $snm2bus2[65], $snm2bus2[66], $snm2bus2[67], $snm2bus2[68], $snm2bus2[69], $snm2bus2[70], $snm2bus2[71], $snm2bus2[72], $snm2bus2[73], $snm2bus2[74], $snm2bus2[75], $snm2bus2[76], $snm2bus2[77], $snm2bus2[78], $snm2bus2[79], 
		$snm2bus2[80], $snm2bus2[81], $snm2bus2[82], $snm2bus2[83], $snm2bus2[84], $snm2bus2[85], $snm2bus2[86], $snm2bus2[87], $snm2bus2[88], $snm2bus2[89], $snm2bus2[90], $snm2bus2[91], $snm2bus2[92], $snm2bus2[93], $snm2bus2[94], $snm2bus2[95], $snm2bus2[96], $snm2bus2[97], $snm2bus2[98], $snm2bus2[99], 
		$snm2bus2[100], $snm2bus2[101], $snm2bus2[102], $snm2bus2[103], $snm2bus2[104], $snm2bus2[105], $snm2bus2[106], $snm2bus2[107], $snm2bus2[108], $snm2bus2[109], $snm2bus2[110], $snm2bus2[111], $snm2bus2[112], $snm2bus2[113], $snm2bus2[114], $snm2bus2[115], $snm2bus2[116], $snm2bus2[117], $snm2bus2[118], $snm2bus2[119], 
		$snm2bus2[120]);
$forbus3 = 	array($snm2bus3[0], $snm2bus3[1], $snm2bus3[2], $snm2bus3[3], $snm2bus3[4], $snm2bus3[5], $snm2bus3[6], $snm2bus3[7], $snm2bus3[8], $snm2bus3[9], $snm2bus3[10], $snm2bus3[11], $snm2bus3[12], $snm2bus3[13], $snm2bus3[14], $snm2bus3[15], $snm2bus3[16], $snm2bus3[17], $snm2bus3[18], $snm2bus3[19], 
		$snm2bus3[20], $snm2bus3[21], $snm2bus3[22], $snm2bus3[23], $snm2bus3[24], $snm2bus3[25], $snm2bus3[26], $snm2bus3[27], $snm2bus3[28], $snm2bus3[29], $snm2bus3[30], $snm2bus3[31], $snm2bus3[32], $snm2bus3[33], $snm2bus3[34], $snm2bus3[35], $snm2bus3[36], $snm2bus3[37], $snm2bus3[38], $snm2bus3[39], 
		$snm2bus3[40], $snm2bus3[41], $snm2bus3[42], $snm2bus3[43], $snm2bus3[44], $snm2bus3[45], $snm2bus3[46], $snm2bus3[47], $snm2bus3[48], $snm2bus3[49], $snm2bus3[50], $snm2bus3[51], $snm2bus3[52], $snm2bus3[53], $snm2bus3[54], $snm2bus3[55], $snm2bus3[56], $snm2bus3[57], $snm2bus3[58], $snm2bus3[59], 
		$snm2bus3[60], $snm2bus3[61], $snm2bus3[62], $snm2bus3[63], $snm2bus3[64], $snm2bus3[65], $snm2bus3[66], $snm2bus3[67], $snm2bus3[68], $snm2bus3[69], $snm2bus3[70], $snm2bus3[71], $snm2bus3[72], $snm2bus3[73], $snm2bus3[74], $snm2bus3[75], $snm2bus3[76], $snm2bus3[77], $snm2bus3[78], $snm2bus3[79], 
		$snm2bus3[80], $snm2bus3[81], $snm2bus3[82], $snm2bus3[83], $snm2bus3[84], $snm2bus3[85], $snm2bus3[86], $snm2bus3[87], $snm2bus3[88], $snm2bus3[89], $snm2bus3[90], $snm2bus3[91], $snm2bus3[92], $snm2bus3[93], $snm2bus3[94], $snm2bus3[95], $snm2bus3[96], $snm2bus3[97], $snm2bus3[98], $snm2bus3[99], 
		$snm2bus3[100], $snm2bus3[101], $snm2bus3[102], $snm2bus3[103], $snm2bus3[104], $snm2bus3[105], $snm2bus3[106], $snm2bus3[107], $snm2bus3[108], $snm2bus3[109], $snm2bus3[110], $snm2bus3[111], $snm2bus3[112], $snm2bus3[113], $snm2bus3[114], $snm2bus3[115], $snm2bus3[116], $snm2bus3[117], $snm2bus3[118], $snm2bus3[119], 
		$snm2bus3[120]);
	$array_all_bus = array(array_filter($forbus1), array_filter($forbus2), array_filter($forbus3));
	$countingbus = 0;
	while($countingbus <= 120){
	if(count(array_column($array_all_bus, $countingbus)) == 3){
	$busf2[] = round(array_sum(array_column($array_all_bus, $countingbus))/3);
	}
	else if(count(array_column($array_all_bus, $countingbus)) == 2){
	$busf2[] = round(array_sum(array_column($array_all_bus, $countingbus))/2);
	}
	else if(count(array_column($array_all_bus, $countingbus)) == 1){
	$busf2[] = round(array_sum(array_column($array_all_bus, $countingbus))/1);
	}
	else{
	$busf2[] = round(array_sum(array_column($array_all_bus, $countingbus))/3);	
	}
	$countingbus++;
	}
	$busf = implode("-",array_filter($busf2));
	$busmx2 = explode("-",$busf);
	$busmx = max(explode("-",$busf));
	$stnameandscoreBus = array_combine($acbuskeys,$busmx2);
	$maxinallsub = $busmx;			
	}
	else if($su == 'Catering'){
		$resultmxbystunamecat1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Catering' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecat1))
	{	
		$snm2cat1[] = $rsn['score'];
		$stin2cat[] = $rsn['student_name'];
	}
	$accatf = array_combine($stin2cat,$snm2cat1);
	$resultmxbystunamecat2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Catering' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecat2))
	{	
		$snm2cat2[] = $rsn['score'];
	    $stin2cat2[] = $rsn['student_name'];
	}
	$accats = array_combine($stin2cat2,$snm2cat2);
	$resultmxbystunamecat3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Catering' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecat3))
	{	
		$snm2cat3[] = $rsn['score'];
		$stin2cat3[] = $rsn['student_name'];
	}
	$accatt = array_combine($stin2cat3,$snm2cat3);
	$arinall = array($accatf, $accats, $accatt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$accatkeys = (array_keys($largest_arr));
	
$forcat1 = array();
for($v=0; $v<=120; $v++){
$forccat1[] = $snm2cat1[$v];
}
$forcat1 = $forccat1;

$forcat2 = array();
for($v=0; $v<=120; $v++){
$forccat2[] = $snm2cat2[$v];
}
$forcat2 = $forccat2;

$forcat3 = array();
for($v=0; $v<=120; $v++){
$forccat3[] = $snm2cat3[$v];
}
$forcat3 = $forccat3;

	$array_all_cat = array(array_filter($forcat1), array_filter($forcat2), array_filter($forcat3));
	$countingcat = 0;
	while($countingcat <= 120){
	if(count(array_column($array_all_cat, $countingcat)) == 3){
	$catf2[] = round(array_sum(array_column($array_all_cat, $countingcat))/3);
	}
	else if(count(array_column($array_all_cat, $countingcat)) == 2){
	$catf2[] = round(array_sum(array_column($array_all_cat, $countingcat))/2);
	}
	else if(count(array_column($array_all_cat, $countingcat)) == 1){
	$catf2[] = round(array_sum(array_column($array_all_cat, $countingcat))/1);
	}
	else{
	$catf2[] = round(array_sum(array_column($array_all_cat, $countingcat))/3);	
	}
	$countingcat++;
	}
	$catf = implode("-",array_filter($catf2));
	$catmx2 = explode("-",$catf);
	$catmx = max(explode("-",$catf));
	$stnameandscoreCat = array_combine($accatkeys,$catmx2);
	$maxinallsub = $catmx;			
	}
	else if($su == 'Chemistry'){
		$resultmxbystunameche1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Chemistry' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameche1))
	{	
		$snm2che1[] = $rsn['score'];
		$stin2che[] = $rsn['student_name'];
	}
	$acchef = array_combine($stin2che,$snm2che1);
	$resultmxbystunameche2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Chemistry' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameche2))
	{	
		$snm2che2[] = $rsn['score'];
	    $stin2che2[] = $rsn['student_name'];
	}
	$acches = array_combine($stin2che2,$snm2che2);
	$resultmxbystunameche3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Chemistry' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameche3))
	{	
		$snm2che3[] = $rsn['score'];
		$stin2che3[] = $rsn['student_name'];
	}
	$acchet = array_combine($stin2che3,$snm2che3);
	$arinall = array($acchef, $acches, $acchet);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acchekeys = (array_keys($largest_arr));
	
$forche1 = array();
for($v=0; $v<=120; $v++){
$forcche1[] = $snm2che1[$v];
}
$forche1 = $forcche1;

$forche2 = array();
for($v=0; $v<=120; $v++){
$forcche2[] = $snm2che2[$v];
}
$forche2 = $forcche2;

$forche3 = array();
for($v=0; $v<=120; $v++){
$forcche3[] = $snm2che3[$v];
}
$forche3 = $forcche3;

	$array_all_che = array(array_filter($forche1), array_filter($forche2), array_filter($forche3));
	$countingche = 0;
	while($countingche <= 120){
	if(count(array_column($array_all_che, $countingche)) == 3){
	$chef2[] = round(array_sum(array_column($array_all_che, $countingche))/3);
	}
	else if(count(array_column($array_all_che, $countingche)) == 2){
	$chef2[] = round(array_sum(array_column($array_all_che, $countingche))/2);
	}
	else if(count(array_column($array_all_che, $countingche)) == 1){
	$chef2[] = round(array_sum(array_column($array_all_che, $countingche))/1);
	}
	else{
	$chef2[] = round(array_sum(array_column($array_all_che, $countingche))/3);	
	}
	$countingche++;
	}
	$chef = implode("-",array_filter($chef2));
	$chemx2 = explode("-",$chef);
	$chemx = max(explode("-",$chef));
	$stnameandscoreChe = array_combine($acchekeys,$chemx2);
	$maxinallsub = $chemx;			
	}
	else if($su == 'Civic Education'){
		$resultmxbystunameciv1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Civic Education' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameciv1))
	{	
		$snm2civ1[] = $rsn['score'];
		$stin2civ[] = $rsn['student_name'];
	}
	$accivf = array_combine($stin2civ,$snm2civ1);
	$resultmxbystunameciv2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Civic Education' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameciv2))
	{	
		$snm2civ2[] = $rsn['score'];
	    $stin2civ2[] = $rsn['student_name'];
	}
	$accivs = array_combine($stin2civ2,$snm2civ2);
	$resultmxbystunameciv3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Civic Education' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameciv3))
	{	
		$snm2civ3[] = $rsn['score'];
		$stin2civ3[] = $rsn['student_name'];
	}
	$accivt = array_combine($stin2civ3,$snm2civ3);
	$arinall = array($accivf, $accivs, $accivt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$accivkeys = (array_keys($largest_arr));
	
$forciv1 = array();
for($v=0; $v<=120; $v++){
$forcciv1[] = $snm2civ1[$v];
}
$forciv1 = $forcciv1;

$forciv2 = array();
for($v=0; $v<=120; $v++){
$forcciv2[] = $snm2civ2[$v];
}
$forciv2 = $forcciv2;

$forciv3 = array();
for($v=0; $v<=120; $v++){
$forcciv3[] = $snm2civ3[$v];
}
$forciv3 = $forcciv3;

	$array_all_civ = array(array_filter($forciv1), array_filter($forciv2), array_filter($forciv3));
	$countingciv = 0;
	while($countingciv <= 120){
	if(count(array_column($array_all_civ, $countingciv)) == 3){
	$civf2[] = round(array_sum(array_column($array_all_civ, $countingciv))/3);
	}
	else if(count(array_column($array_all_civ, $countingciv)) == 2){
	$civf2[] = round(array_sum(array_column($array_all_civ, $countingciv))/2);
	}
	else if(count(array_column($array_all_civ, $countingciv)) == 1){
	$civf2[] = round(array_sum(array_column($array_all_civ, $countingciv))/1);
	}
	else{
	$civf2[] = round(array_sum(array_column($array_all_civ, $countingciv))/3);	
	}
	$countingciv++;
	}
	$civf = implode("-",array_filter($civf2));
	$civmx2 = explode("-",$civf);
	$civmx = max(explode("-",$civf));
	$stnameandscoreCiv = array_combine($accivkeys,$civmx2);
	$maxinallsub = $civmx;			
	}
	
	else if($su == 'Creative and Cultural Arts'){
		$resultmxbystunamecca1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Creative and Cultural Arts' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecca1))
	{	
		$snm2cca1[] = $rsn['score'];
		$stin2cca[] = $rsn['student_name'];
	}
	$acccaf = array_combine($stin2cca,$snm2cca1);
	$resultmxbystunamecca2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Creative and Cultural Arts' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecca2))
	{	
		$snm2cca2[] = $rsn['score'];
	    $stin2cca2[] = $rsn['student_name'];
	}
	$acccas = array_combine($stin2cca2,$snm2cca2);
	$resultmxbystunamecca3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Creative and Cultural Arts Studies' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecca3))
	{	
		$snm2cca3[] = $rsn['score'];
		$stin2cca3[] = $rsn['student_name'];
	}
	$acccat = array_combine($stin2cca3,$snm2cca3);
	$arinall = array($acccaf, $acccas, $acccat);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acccakeys = (array_keys($largest_arr));
	
$forcca1 = array();
$forcca2 = array();
$forcca3 = array();
for($v=0; $v<=120; $v++){
$forccca1[] = $snm2cca1[$v];
$forccca2[] = $snm2cca2[$v];
$forccca3[] = $snm2cca3[$v];
}
$forcca1 = $forccca1;
$forcca2 = $forccca2;
$forcca3 = $forccca3;

	$array_all_cca = array(array_filter($forcca1), array_filter($forcca2), array_filter($forcca3));
	$countingcca = 0;
	while($countingcca <= 120){
	if(count(array_column($array_all_cca, $countingcca)) == 3){
	$ccaf2[] = round(array_sum(array_column($array_all_cca, $countingcca))/3);
	}
	else if(count(array_column($array_all_cca, $countingcca)) == 2){
	$ccaf2[] = round(array_sum(array_column($array_all_cca, $countingcca))/2);
	}
	else if(count(array_column($array_all_cca, $countingcca)) == 1){
	$ccaf2[] = round(array_sum(array_column($array_all_cca, $countingcca))/1);
	}
	else{
	$ccaf2[] = round(array_sum(array_column($array_all_cca, $countingcca))/3);	
	}
	$countingcca++;
	}
	$ccaf = implode("-",array_filter($ccaf2));
	$ccamx2 = explode("-",$ccaf);
	$ccamx = max(explode("-",$ccaf));
	$stnameandscoreCca = array_combine($acccakeys,$ccamx2);
	$maxinallsub = $ccamx;			
	}
	
		else if($su == 'CRK'){
		$resultmxbystunamecrk1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='CRK' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecrk1))
	{	
		$snm2crk1[] = $rsn['score'];
		$stin2crk[] = $rsn['student_name'];
	}
	$accrkf = array_combine($stin2crk,$snm2crk1);
	$resultmxbystunamecrk2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='CRK' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecrk2))
	{	
		$snm2crk2[] = $rsn['score'];
	    $stin2crk2[] = $rsn['student_name'];
	}
	$accrks = array_combine($stin2crk2,$snm2crk2);
	$resultmxbystunamecrk3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='CRK' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecRK3))
	{	
		$snm2crk3[] = $rsn['score'];
		$stin2crk3[] = $rsn['student_name'];
	}
	$accrkt = array_combine($stin2crk3,$snm2crk3);
	$arinall = array($accrkf, $accrks, $accrkt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$accrkkeys = (array_keys($largest_arr));
	
$forcrk1 = array();
for($v=0; $v<=120; $v++){
$forccrk1[] = $snm2crk1[$v];
}
$forcrk1 = $forccrk1;

$forcrk2 = array();
for($v=0; $v<=120; $v++){
$forccrk2[] = $snm2crk2[$v];
}
$forcrk2 = $forccrk2;

$forcrk3 = array();
for($v=0; $v<=120; $v++){
$forccrk3[] = $snm2crk3[$v];
}
$forcrk3 = $forccrk3;

	$array_all_crk = array(array_filter($forcrk1), array_filter($forcrk2), array_filter($forcrk3));
	$countingcrk = 0;
	while($countingcrk <= 120){
	if(count(array_column($array_all_crk, $countingcrk)) == 3){
	$crkf2[] = round(array_sum(array_column($array_all_crk, $countingcrk))/3);
	}
	else if(count(array_column($array_all_crk, $countingcrk)) == 2){
	$crkf2[] = round(array_sum(array_column($array_all_crk, $countingcrk))/2);
	}
	else if(count(array_column($array_all_crk, $countingcrk)) == 1){
	$crkf2[] = round(array_sum(array_column($array_all_crk, $countingcrk))/1);
	}
	else{
	$crkf2[] = round(array_sum(array_column($array_all_crk, $countingcrk))/3);	
	}
	$countingcrk++;
	}
	$crkf = implode("-",array_filter($crkf2));
	$crkmx2 = explode("-",$crkf);
	$crkmx = max(explode("-",$crkf));
	$stnameandscoreCrk = array_combine($accrkkeys,$crkmx2);
	$maxinallsub = $crkmx;			
	}
	else if($su == 'Economics'){
		$resultmxbystunameeco1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Economics' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeco1))
	{	
		$snm2eco1[] = $rsn['score'];
		$stin2eco[] = $rsn['student_name'];
	}
	$acecof = array_combine($stin2eco,$snm2eco1);
	$resultmxbystunameeco2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Economics' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeco2))
	{	
		$snm2eco2[] = $rsn['score'];
	    $stin2eco2[] = $rsn['student_name'];
	}
	$acecos = array_combine($stin2eco2,$snm2eco2);
	$resultmxbystunameeco3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Economics' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeco3))
	{	
		$snm2eco3[] = $rsn['score'];
		$stin2eco3[] = $rsn['student_name'];
	}
	$acecot = array_combine($stin2eco3,$snm2eco3);
	$arinall = array($acecof, $acecos, $acecot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acecokeys = (array_keys($largest_arr));
	
$foreco1 = array();
$foreco2 = array();
$foreco3 = array();
for($v=0; $v<=120; $v++){
$foreeco1[] = $snm2eco1[$v];
$foreeco2[] = $snm2eco2[$v];
$foreeco3[] = $snm2eco3[$v];
}
$foreco1 = $foreeco1;
$foreco2 = $foreeco2;
$foreco3 = $foreeco3;

	$array_all_eco = array(array_filter($foreco1), array_filter($foreco2), array_filter($foreco3));
	$countingeco = 0;
	while($countingeco <= 120){
	if(count(array_column($array_all_eco, $countingeco)) == 3){
	$ecof2[] = round(array_sum(array_column($array_all_eco, $countingeco))/3);
	}
	else if(count(array_column($array_all_eco, $countingeco)) == 2){
	$ecof2[] = round(array_sum(array_column($array_all_eco, $countingeco))/2);
	}
	else if(count(array_column($array_all_eco, $countingeco)) == 1){
	$ecof2[] = round(array_sum(array_column($array_all_eco, $countingeco))/1);
	}
	else{
	$ecof2[] = round(array_sum(array_column($array_all_eco, $countingeco))/3);	
	}
	$countingeco++;
	}
	$ecof = implode("-",array_filter($ecof2));
	$ecomx2 = explode("-",$ecof);
	$ecomx = max(explode("-",$ecof));
	$stnameandscoreEco = array_combine($acecokeys,$ecomx2);
	$maxinallsub = $ecomx;			
	}
	else if($su == 'Financial Accounting'){
		$resultmxbystunamefin1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Financial Accounting' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefin1))
	{	
		$snm2fin1[] = $rsn['score'];
		$stin2fin[] = $rsn['student_name'];
	}
	$acfinf = array_combine($stin2fin,$snm2fin1);
	$resultmxbystunamefin2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Financial Accounting' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefin2))
	{	
		$snm2fin2[] = $rsn['score'];
	    $stin2fin2[] = $rsn['student_name'];
	}
	$acfins = array_combine($stin2fin2,$snm2fin2);
	$resultmxbystunamefin3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Financial Accounting' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefin3))
	{	
		$snm2fin3[] = $rsn['score'];
		$stin2fin3[] = $rsn['student_name'];
	}
	$acfint = array_combine($stin2fin3,$snm2fin3);
	$arinall = array($acfinf, $acfins, $acfint);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acfinkeys = (array_keys($largest_arr));
	
$forfin1 = array();
$forfin2 = array();
$forfin3 = array();
for($v=0; $v<=120; $v++){
$forffin1[] = $snm2fin1[$v];
$forffin2[] = $snm2fin2[$v];
$forffin3[] = $snm2fin3[$v];
}
$forfin1 = $forffin1;
$forfin2 = $forffin2;
$forfin3 = $forffin3;

	$array_all_fin = array(array_filter($forfin1), array_filter($forfin2), array_filter($forfin3));
	$countingfin = 0;
	while($countingfin <= 120){
	if(count(array_column($array_all_fin, $countingfin)) == 3){
	$finf2[] = round(array_sum(array_column($array_all_fin, $countingfin))/3);
	}
	else if(count(array_column($array_all_fin, $countingfin)) == 2){
	$finf2[] = round(array_sum(array_column($array_all_fin, $countingfin))/2);
	}
	else if(count(array_column($array_all_fin, $countingfin)) == 1){
	$finf2[] = round(array_sum(array_column($array_all_fin, $countingfin))/1);
	}
	else{
	$finf2[] = round(array_sum(array_column($array_all_fin, $countingfin))/3);	
	}
	$countingfin++;
	}
	$finf = implode("-",array_filter($finf2));
	$finmx2 = explode("-",$finf);
	$finmx = max(explode("-",$finf));
	$stnameandscoreFin = array_combine($acfinkeys,$finmx2);
	$maxinallsub = $finmx;			
	}
		else if($su == 'Food and Nutrition'){
		$resultmxbystunamefoo1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Food and Nutrition' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefoo1))
	{	
		$snm2foo1[] = $rsn['score'];
		$stin2foo[] = $rsn['student_name'];
	}
	$acfoof = array_combine($stin2foo,$snm2foo1);
	$resultmxbystunamefoo2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Food and Nutrition' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefoo2))
	{	
		$snm2foo2[] = $rsn['score'];
	    $stin2foo2[] = $rsn['student_name'];
	}
	$acfoos = array_combine($stin2foo2,$snm2foo2);
	$resultmxbystunamefoo3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Food and Nutrition' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefoo3))
	{	
		$snm2foo3[] = $rsn['score'];
		$stin2foo3[] = $rsn['student_name'];
	}
	$acfoot = array_combine($stin2foo3,$snm2foo3);
	$arinall = array($acfoof, $acfoos, $acfoot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acfookeys = (array_keys($largest_arr));
	
$forfoo1 = array();
$forfoo2 = array();
$forfoo3 = array();
for($v=0; $v<=120; $v++){
$forffoo1[] = $snm2foo1[$v];
$forffoo2[] = $snm2foo2[$v];
$forffoo3[] = $snm2foo3[$v];
}
$forfoo1 = $forffoo1;
$forfoo2 = $forffoo2;
$forfoo3 = $forffoo3;

	$array_all_foo = array(array_filter($forfoo1), array_filter($forfoo2), array_filter($forfoo3));
	$countingfoo = 0;
	while($countingfoo <= 120){
	if(count(array_column($array_all_foo, $countingfoo)) == 3){
	$foof2[] = round(array_sum(array_column($array_all_foo, $countingfoo))/3);
	}
	else if(count(array_column($array_all_foo, $countingfoo)) == 2){
	$foof2[] = round(array_sum(array_column($array_all_foo, $countingfoo))/2);
	}
	else if(count(array_column($array_all_foo, $countingfoo)) == 1){
	$foof2[] = round(array_sum(array_column($array_all_foo, $countingfoo))/1);
	}
	else{
	$foof2[] = round(array_sum(array_column($array_all_foo, $countingfoo))/3);	
	}
	$countingfoo++;
	}
	$foof = implode("-",array_filter($foof2));
	$foomx2 = explode("-",$foof);
	$foomx = max(explode("-",$foof));
	$stnameandscoreFoo = array_combine($acfookeys,$foomx2);
	$maxinallsub = $foomx;			
	}
	else if($su == 'French'){
	$resultmxbystunamefre1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='French' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefre1))
	{	
		$snm2fre1[] = $rsn['score'];
		$stin2fre[] = $rsn['student_name'];
	}
	$acfref = array_combine($stin2fre,$snm2fre1);
	$resultmxbystunamefre2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='French' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefre2))
	{	
		$snm2fre2[] = $rsn['score'];
	    $stin2fre2[] = $rsn['student_name'];
	}
	$acfres = array_combine($stin2fre2,$snm2fre2);
	$resultmxbystunamefre3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='French' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefre3))
	{	
		$snm2fre3[] = $rsn['score'];
		$stin2fre3[] = $rsn['student_name'];
	}
	$acfret = array_combine($stin2fre3,$snm2fre3);
	$arinall = array($acfref, $acfres, $acfret);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acfrekeys = (array_keys($largest_arr));
$forfre1 = array();
$forfre2 = array();
$forfre3 = array();
for($v=0; $v<=120; $v++){
$forffre1[] = $snm2fre1[$v];
$forffre2[] = $snm2fre2[$v];
$forffre3[] = $snm2fre3[$v];
}
$forfre1 = $forffre1;
$forfre2 = $forffre2;
$forfre3 = $forffre3; 
 $array_all_fre = array(array_filter($forfre1), array_filter($forfre2), array_filter($forfre3));
	$countingfre = 0;
	while($countingfre <= 120){
	if(count(array_column($array_all_fre, $countingfre)) == 3){
	$fref2[] = round(array_sum(array_column($array_all_fre, $countingfre))/3);
	}
	else if(count(array_column($array_all_fre, $countingfre)) == 2){
	$fref2[] = round(array_sum(array_column($array_all_fre, $countingfre))/2);
	}
	else if(count(array_column($array_all_fre, $countingfre)) == 1){
	$fref2[] = round(array_sum(array_column($array_all_fre, $countingfre))/1);
	}
	else{
	$fref2[] = round(array_sum(array_column($array_all_fre, $countingfre))/3);	
	}
	$countingfre++;
	}
	$fref = implode("-",array_filter($fref2));
	$fremx2 = explode("-",$fref);
	$fremx = max(explode("-",$fref));
	$stnameandscoreFre = array_combine($acfrekeys,$fremx2);
	//print_r($stnameandscoreFre);
	//echo '<br>';
	$maxinallsub = $fremx;	
	}
		else if($su == 'Geography'){
		$resultmxbystunamegeo1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Geography' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegeo1))
	{	
		$snm2geo1[] = $rsn['score'];
		$stin2geo[] = $rsn['student_name'];
	}
	$acgeof = array_combine($stin2geo,$snm2geo1);
	$resultmxbystunamegeo2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Geography' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegeo2))
	{	
		$snm2geo2[] = $rsn['score'];
	    $stin2geo2[] = $rsn['student_name'];
	}
	$acgeos = array_combine($stin2geo2,$snm2geo2);
	$resultmxbystunamegeo3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Geography' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegeo3))
	{	
		$snm2geo3[] = $rsn['score'];
		$stin2geo3[] = $rsn['student_name'];
	}
	$acgeot = array_combine($stin2geo3,$snm2geo3);
	$arinall = array($acgeof, $acgeos, $acgeot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acgeokeys = (array_keys($largest_arr));
	
$forgeo1 = array();
$forgeo2 = array();
$forgeo3 = array();
for($v=0; $v<=120; $v++){
$forggeo1[] = $snm2geo1[$v];
$forggeo2[] = $snm2geo2[$v];
$forggeo3[] = $snm2geo3[$v];
}
$forgeo1 = $forggeo1;
$forgeo2 = $forggeo2;
$forgeo3 = $forggeo3;

	$array_all_geo = array(array_filter($forgeo1), array_filter($forgeo2), array_filter($forgeo3));
	$countinggeo = 0;
	while($countinggeo <= 120){
	if(count(array_column($array_all_geo, $countinggeo)) == 3){
	$geof2[] = round(array_sum(array_column($array_all_geo, $countinggeo))/3);
	}
	else if(count(array_column($array_all_geo, $countinggeo)) == 2){
	$geof2[] = round(array_sum(array_column($array_all_geo, $countinggeo))/2);
	}
	else if(count(array_column($array_all_geo, $countinggeo)) == 1){
	$geof2[] = round(array_sum(array_column($array_all_geo, $countinggeo))/1);
	}
	else{
	$geof2[] = round(array_sum(array_column($array_all_geo, $countinggeo))/3);	
	}
	$countinggeo++;
	}
	$geof = implode("-",array_filter($geof2));
	$geomx2 = explode("-",$geof);
	$geomx = max(explode("-",$geof));
	$stnameandscoreGeo = array_combine($acgeokeys,$geomx2);
	$maxinallsub = $geomx;			
	}
		else if($su == 'Government'){
		$resultmxbystunamegov1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Government' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegov1))
	{	
		$snm2gov1[] = $rsn['score'];
		$stin2gov[] = $rsn['student_name'];
	}
	$acgovf = array_combine($stin2gov,$snm2gov1);
	$resultmxbystunamegov2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Government' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegov2))
	{	
		$snm2gov2[] = $rsn['score'];
	    $stin2gov2[] = $rsn['student_name'];
	}
	$acgovs = array_combine($stin2gov2,$snm2gov2);
	$resultmxbystunamegov3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Government' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegov3))
	{	
		$snm2gov3[] = $rsn['score'];
		$stin2gov3[] = $rsn['student_name'];
	}
	$acgovt = array_combine($stin2gov3,$snm2gov3);
	$arinall = array($acgovf, $acgovs, $acgovt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acgovkeys = (array_keys($largest_arr));
	
$forgov1 = array();
$forgov2 = array();
$forgov3 = array();
for($v=0; $v<=120; $v++){
$forggov1[] = $snm2gov1[$v];
$forggov2[] = $snm2gov2[$v];
$forggov3[] = $snm2gov3[$v];
}
$forgov1 = $forggov1;
$forgov2 = $forggov2;
$forgov3 = $forggov3;

	$array_all_gov = array(array_filter($forgov1), array_filter($forgov2), array_filter($forgov3));
	$countinggov = 0;
	while($countinggov <= 120){
	if(count(array_column($array_all_gov, $countinggov)) == 3){
	$govf2[] = round(array_sum(array_column($array_all_gov, $countinggov))/3);
	}
	else if(count(array_column($array_all_gov, $countinggov)) == 2){
	$govf2[] = round(array_sum(array_column($array_all_gov, $countinggov))/2);
	}
	else if(count(array_column($array_all_gov, $countinggov)) == 1){
	$govf2[] = round(array_sum(array_column($array_all_gov, $countinggov))/1);
	}
	else{
	$govf2[] = round(array_sum(array_column($array_all_gov, $countinggov))/3);	
	}
	$countinggov++;
	}
	$govf = implode("-",array_filter($govf2));
	$govmx2 = explode("-",$govf);
	$govmx = max(explode("-",$govf));
	$stnameandscoreGov = array_combine($acgovkeys,$govmx2);
	$maxinallsub = $govmx;			
	}
	else if($su == 'Hausa'){
		$resultmxbystunamehau1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Hausa' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehau1))
	{	
		$snm2hau1[] = $rsn['score'];
		$stin2hau[] = $rsn['student_name'];
	}
	$achauf = array_combine($stin2hau,$snm2hau1);
	$resultmxbystunamehau2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Hausa' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehau2))
	{	
		$snm2hau2[] = $rsn['score'];
	    $stin2hau2[] = $rsn['student_name'];
	}
	$achaus = array_combine($stin2hau2,$snm2hau2);
	$resultmxbystunamehau3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Hausa' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehau3))
	{	
		$snm2hau3[] = $rsn['score'];
		$stin2hau3[] = $rsn['student_name'];
	}
	$achaut = array_combine($stin2hau3,$snm2hau3);
	$arinall = array($achauf, $achaus, $achaut);
	//print_r($arinall);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$achaukeys = (array_keys($largest_arr));
	
$forhau1 = array();
$forhau2 = array();
$forhau3 = array();
for($v=0; $v<=120; $v++){
$forhhau1[] = $snm2hau1[$v];
$forhhau2[] = $snm2hau2[$v];
$forhhau3[] = $snm2hau3[$v];
}
$forhau1 = $forhhau1;
$forhau2 = $forhhau2;
$forhau3 = $forhhau3;
//print_r($array_all_irs);

	$array_all_hau = array(array_filter($forhau1), array_filter($forhau2), array_filter($forhau3));
	$countinghau = 0;
	while($countinghau <= 120){
	if(count(array_column($array_all_hau, $countinghau)) == 3){
	$hauf2[] = round(array_sum(array_column($array_all_hau, $countinghau))/3);
	}
	else if(count(array_column($array_all_hau, $countinghau)) == 2){
	$hauf2[] = round(array_sum(array_column($array_all_hau, $countinghau))/2);
	}
	else if(count(array_column($array_all_hau, $countinghau)) == 1){
	$hauf2[] = round(array_sum(array_column($array_all_hau, $countinghau))/1);
	}
	else{
	$hauf2[] = round(array_sum(array_column($array_all_hau, $countinghau))/3);	
	}
	$countinghau++;
	}
	$hauf = implode("-",array_filter($hauf2));
	$haumx2 = explode("-",$hauf);
	$haumx = max(explode("-",$hauf));
	$stnameandscoreHau = array_combine($achaukeys,$haumx2);
	$maxinallsub = $haumx;			
	}
	else if($su == 'History'){
		$resultmxbystunamehis1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='History' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehis1))
	{	
		$snm2his1[] = $rsn['score'];
		$stin2his[] = $rsn['student_name'];
	}
	$achisf = array_combine($stin2his,$snm2his1);
	$resultmxbystunamehis2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='History' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehis2))
	{	
		$snm2his2[] = $rsn['score'];
	    $stin2his2[] = $rsn['student_name'];
	}
	$achiss = array_combine($stin2his2,$snm2his2);
	$resultmxbystunamehis3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='History' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehis3))
	{	
		$snm2his3[] = $rsn['score'];
		$stin2his3[] = $rsn['student_name'];
	}
	$achist = array_combine($stin2his3,$snm2his3);
	$arinall = array($achisf, $achiss, $achist);
	//print_r($arinall);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$achiskeys = (array_keys($largest_arr));
	
$forhis1 = array();
$forhis2 = array();
$forhis3 = array();
for($v=0; $v<=120; $v++){
$forhhis1[] = $snm2his1[$v];
$forhhis2[] = $snm2his2[$v];
$forhhis3[] = $snm2his3[$v];
}
$forhis1 = $forhhis1;
$forhis2 = $forhhis2;
$forhis3 = $forhhis3;
//print_r($array_all_irs);

	$array_all_his = array(array_filter($forhis1), array_filter($forhis2), array_filter($forhis3));
	$countinghis = 0;
	while($countinghis <= 120){
	if(count(array_column($array_all_his, $countinghis)) == 3){
	$hisf2[] = round(array_sum(array_column($array_all_his, $countinghis))/3);
	}
	else if(count(array_column($array_all_his, $countinghis)) == 2){
	$hisf2[] = round(array_sum(array_column($array_all_his, $countinghis))/2);
	}
	else if(count(array_column($array_all_his, $countinghis)) == 1){
	$hisf2[] = round(array_sum(array_column($array_all_his, $countinghis))/1);
	}
	else{
	$hisf2[] = round(array_sum(array_column($array_all_his, $countinghis))/3);	
	}
	$countinghis++;
	}
	$hisf = implode("-",array_filter($hisf2));
	$hismx2 = explode("-",$hisf);
	$hismx = max(explode("-",$hisf));
	$stnameandscoreHis = array_combine($achiskeys,$hismx2);
	$maxinallsub = $hismx;			
	}
		else if($su == 'ICT'){
		$resultmxbystunameict1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='ICT' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameict1))
	{	
		$snm2ict1[] = $rsn['score'];
		$stin2ict[] = $rsn['student_name'];
	}
	$acgovf = array_combine($stin2ict,$snm2ict1);
	$resultmxbystunameict2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='ICT' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameict2))
	{	
		$snm2ict2[] = $rsn['score'];
	    $stin2ict2[] = $rsn['student_name'];
	}
	$acicts = array_combine($stin2ict2,$snm2ict2);
	$resultmxbystunameict3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='ICT' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameict3))
	{	
		$snm2ict3[] = $rsn['score'];
		$stin2ict3[] = $rsn['student_name'];
	}
	$acictt = array_combine($stin2ict3,$snm2ict3);
	$arinall = array($acictf, $acicts, $acictt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acictkeys = (array_keys($largest_arr));
	
$forict1 = array();
$forict2 = array();
$forict3 = array();
for($v=0; $v<=120; $v++){
$foriict1[] = $snm2ict1[$v];
$foriict2[] = $snm2ict2[$v];
$foriict3[] = $snm2ict3[$v];
}
$forict1 = $foriict1;
$forict2 = $foriict2;
$forict3 = $foriict3;

	$array_all_ict = array(array_filter($forict1), array_filter($forict2), array_filter($forict3));
	$countingict = 0;
	while($countingict <= 120){
	if(count(array_column($array_all_ict, $countingict)) == 3){
	$ictf2[] = round(array_sum(array_column($array_all_ict, $countingict))/3);
	}
	else if(count(array_column($array_all_ict, $countingict)) == 2){
	$ictf2[] = round(array_sum(array_column($array_all_ict, $countingict))/2);
	}
	else if(count(array_column($array_all_ict, $countingict)) == 1){
	$ictf2[] = round(array_sum(array_column($array_all_ict, $countingict))/1);
	}
	else{
	$ictf2[] = round(array_sum(array_column($array_all_ict, $countingict))/3);	
	}
	$countingict++;
	}
	$ictf = implode("-",array_filter($ictf2));
	$ictmx2 = explode("-",$ictf);
	$ictmx = max(explode("-",$ictf));
	$stnameandscoreIct = array_combine($acictkeys,$ictmx2);
	$maxinallsub = $ictmx;			
	}
	else if($su == 'Igbo'){
		$resultmxbystunameigb1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Igbo' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameigb1))
	{	
		$snm2igb1[] = $rsn['score'];
		$stin2igb[] = $rsn['student_name'];
	}
	$acigbf = array_combine($stin2igb,$snm2igb1);
	$resultmxbystunameigb2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Igbo' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameigb2))
	{	
		$snm2igb2[] = $rsn['score'];
	    $stin2igb2[] = $rsn['student_name'];
	}
	$acigbs = array_combine($stin2igb2,$snm2igb2);
	$resultmxbystunameigb3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Igbo' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameigb3))
	{	
		$snm2igb3[] = $rsn['score'];
		$stin2igb3[] = $rsn['student_name'];
	}
	$acigbt = array_combine($stin2igb3,$snm2igb3);
	$arinall = array($acigbf, $acigbs, $acigbt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acigbkeys = (array_keys($largest_arr));
	
$forigb1 = array();
$forigb2 = array();
$forigb3 = array();
for($v=0; $v<=120; $v++){
$foriigb1[] = $snm2igb1[$v];
$foriigb2[] = $snm2igb2[$v];
$foriigb3[] = $snm2igb3[$v];
}
$forigb1 = $foriigb1;
$forigb2 = $foriigb2;
$forigb3 = $foriigb3;

	$array_all_igb = array(array_filter($forigb1), array_filter($forigb2), array_filter($forigb3));
	$countingigb = 0;
	while($countingigb <= 120){
	if(count(array_column($array_all_igb, $countingigb)) == 3){
	$igbf2[] = round(array_sum(array_column($array_all_igb, $countingigb))/3);
	}
	else if(count(array_column($array_all_igb, $countingigb)) == 2){
	$igbf2[] = round(array_sum(array_column($array_all_igb, $countingigb))/2);
	}
	else if(count(array_column($array_all_igb, $countingigb)) == 1){
	$igbf2[] = round(array_sum(array_column($array_all_igb, $countingigb))/1);
	}
	else{
	$igbf2[] = round(array_sum(array_column($array_all_igb, $countingigb))/3);	
	}
	$countingigb++;
	}
	$igbf = implode("-",array_filter($igbf2));
	$igbmx2 = explode("-",$igbf);
	$igbmx = max(explode("-",$igbf));
	$stnameandscoreIgb = array_combine($acigbkeys,$igbmx2);
	$maxinallsub = $igbmx;			
	}
	
	else if($su == 'Islamic Religious Studies'){
		$resultmxbystunameirs1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Islamic Religious Studies' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameirs1))
	{	
		$snm2irs1[] = $rsn['score'];
		$stin2irs[] = $rsn['student_name'];
	}
	$acirsf = array_combine($stin2irs,$snm2irs1);
	$resultmxbystunameirs2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Islamic Religious Studies' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameirs2))
	{	
		$snm2irs2[] = $rsn['score'];
	    $stin2irs2[] = $rsn['student_name'];
	}
	$acirss = array_combine($stin2irs2,$snm2irs2);
	$resultmxbystunameirs3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Islamic Religious Studies' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameirs3))
	{	
		$snm2irs3[] = $rsn['score'];
		$stin2irs3[] = $rsn['student_name'];
	}
	$acirst = array_combine($stin2irs3,$snm2irs3);
	$arinall = array($acirsf, $acirss, $acirst);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acirskeys = (array_keys($largest_arr));
	
$forirs1 = array();
$forirs2 = array();
$forirs3 = array();
for($v=0; $v<=120; $v++){
$foriirs1[] = $snm2irs1[$v];
$foriirs2[] = $snm2irs2[$v];
$foriirs3[] = $snm2irs3[$v];
}
$forirs1 = $foriirs1;
$forirs2 = $foriirs2;
$forirs3 = $foriirs3;

	$array_all_irs = array(array_filter($forirs1), array_filter($forirs2), array_filter($forirs3));
	$countingirs = 0;
	while($countingirs <= 120){
	if(count(array_column($array_all_irs, $countingirs)) == 3){
	$irsf2[] = round(array_sum(array_column($array_all_irs, $countingirs))/3);
	}
	else if(count(array_column($array_all_irs, $countingirs)) == 2){
	$irsf2[] = round(array_sum(array_column($array_all_irs, $countingirs))/2);
	}
	else if(count(array_column($array_all_irs, $countingirs)) == 1){
	$irsf2[] = round(array_sum(array_column($array_all_irs, $countingirs))/1);
	}
	else{
	$irsf2[] = round(array_sum(array_column($array_all_irs, $countingirs))/3);	
	}
	$countingirs++;
	}
	$irsf = implode("-",array_filter($irsf2));
	$irsmx2 = explode("-",$irsf);
	$irsmx = max(explode("-",$irsf));
	$stnameandscoreIrs = array_combine($acirskeys,$irsmx2);
	$maxinallsub = $irsmx;			
	} 
	else if($su == 'Literature in English'){
		$resultmxbystunamelit1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Literature in English' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamelit1))
	{	
		$snm2lit1[] = $rsn['score'];
		$stin2lit[] = $rsn['student_name'];
	}
	$aclitf = array_combine($stin2lit,$snm2lit1);
	$resultmxbystunamelit2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Literature in English' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamelit2))
	{	
		$snm2lit2[] = $rsn['score'];
	    $stin2lit2[] = $rsn['student_name'];
	}
	$aclits = array_combine($stin2lit2,$snm2lit2);
	$resultmxbystunamelit3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Literature in English' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamelit3))
	{	
		$snm2lit3[] = $rsn['score'];
		$stin2lit3[] = $rsn['student_name'];
	}
	$aclitt = array_combine($stin2lit3,$snm2lit3);
	$arinall = array($aclitf, $aclits, $aclitt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$aclitkeys = (array_keys($largest_arr));
	
$forlit1 = array();
$forlit2 = array();
$forlit3 = array();
for($v=0; $v<=120; $v++){
$forllit1[] = $snm2lit1[$v];
$forllit2[] = $snm2lit2[$v];
$forllit3[] = $snm2lit3[$v];
}
$forlit1 = $forllit1;
$forlit2 = $forllit2;
$forlit3 = $forllit3;

	$array_all_lit = array(array_filter($forlit1), array_filter($forlit2), array_filter($forlit3));
	$countinglit = 0;
	while($countinglit <= 120){
	if(count(array_column($array_all_lit, $countinglit)) == 3){
	$litf2[] = round(array_sum(array_column($array_all_lit, $countinglit))/3);
	}
	else if(count(array_column($array_all_lit, $countinglit)) == 2){
	$litf2[] = round(array_sum(array_column($array_all_lit, $countinglit))/2);
	}
	else if(count(array_column($array_all_lit, $countinglit)) == 1){
	$litf2[] = round(array_sum(array_column($array_all_lit, $countinglit))/1);
	}
	else{
	$litf2[] = round(array_sum(array_column($array_all_lit, $countinglit))/3);	
	}
	$countinglit++;
	}
	$litf = implode("-",array_filter($litf2));
	$litmx2 = explode("-",$litf);
	$litmx = max(explode("-",$litf));
	$stnameandscoreLit = array_combine($aclitkeys,$litmx2);
	$maxinallsub = $litmx;			
	}
		else if($su == 'Marketing'){
		$resultmxbystunamemar1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Marketing' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemar1))
	{	
		$snm2mar1[] = $rsn['score'];
		$stin2mar[] = $rsn['student_name'];
	}
	$acmarf = array_combine($stin2mar,$snm2mar1);
	$resultmxbystunamemar2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Marketing' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemar2))
	{	
		$snm2mar2[] = $rsn['score'];
	    $stin2mar2[] = $rsn['student_name'];
	}
	$acmars = array_combine($stin2mar2,$snm2mar2);
	$resultmxbystunamemar3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Marketing' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemar3))
	{	
		$snm2mar3[] = $rsn['score'];
		$stin2mar3[] = $rsn['student_name'];
	}
	$acmart = array_combine($stin2mar3,$snm2mar3);
	$arinall = array($acmarf, $acmars, $acmart);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acmarkeys = (array_keys($largest_arr));
	
$formar1 = array();
$formar2 = array();
$formar3 = array();
for($v=0; $v<=120; $v++){
$formmar1[] = $snm2mar1[$v];
$formmar2[] = $snm2mar2[$v];
$formmar3[] = $snm2mar3[$v];
}
$formar1 = $formmar1;
$formar2 = $formmar2;
$formar3 = $formmar3;

	$array_all_mar = array(array_filter($formar1), array_filter($formar2), array_filter($formar3));
	$countingmar = 0;
	while($countingmar <= 120){
	if(count(array_column($array_all_mar, $countingmar)) == 3){
	$marf2[] = round(array_sum(array_column($array_all_mar, $countingmar))/3);
	}
	else if(count(array_column($array_all_mar, $countingmar)) == 2){
	$marf2[] = round(array_sum(array_column($array_all_mar, $countingmar))/2);
	}
	else if(count(array_column($array_all_mar, $countingmar)) == 1){
	$marf2[] = round(array_sum(array_column($array_all_mar, $countingmar))/1);
	}
	else{
	$marf2[] = round(array_sum(array_column($array_all_mar, $countingmar))/3);	
	}
	$countingmar++;
	}
	$marf = implode("-",array_filter($marf2));
	$marmx2 = explode("-",$marf);
	$marmx = max(explode("-",$marf));
	$stnameandscoreMar = array_combine($acmarkeys,$marmx2);
	$maxinallsub = $marmx;			
	}
	else if($su == 'Mathematics'){
	$resultmxbystunamemat1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Mathematics' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemat1))
	{	
		$snm2mat1[] = $rsn['score'];
		$stin2mat[] = $rsn['student_name'];
	}
	$acmatf = array_combine($stin2mat,$snm2mat1);
	$resultmxbystunamemat2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Mathematics' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemat2))
	{	
		$snm2mat2[] = $rsn['score'];
	    $stin2mat2[] = $rsn['student_name'];
	}
	$acmats = array_combine($stin2mat2,$snm2mat2);
	$resultmxbystunamemat3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Mathematics' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemat3))
	{	
		$snm2mat3[] = $rsn['score'];
		$stin2mat3[] = $rsn['student_name'];
	}
	$acmatt = array_combine($stin2mat3,$snm2mat3);
	$arinall = array($acmatf, $acmats, $acmatt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acmatkeys = (array_keys($largest_arr));
$format1 = array();
$format2 = array();
$format3 = array();
for($v=0; $v<=120; $v++){
$formmat1[] = $snm2mat1[$v];
$formmat2[] = $snm2mat2[$v];
$formmat3[] = $snm2mat3[$v];
}
$format1 = $formmat1;
$format2 = $formmat2;
$format3 = $formmat3;  
	$array_all_mat = array(array_filter($format1), array_filter($format2), array_filter($format3));
	$countingmat = 0;
while($countingmat <= 120){
	if(count(array_column($array_all_mat, $countingmat)) == 3){
	$matf2[] = round(array_sum(array_column($array_all_mat, $countingmat))/3);
	}
	else if(count(array_column($array_all_mat, $countingmat)) == 2){
	$matf2[] = round(array_sum(array_column($array_all_mat, $countingmat))/2);
	}
	else if(count(array_column($array_all_mat, $countingmat)) == 1){
	$matf2[] = round(array_sum(array_column($array_all_mat, $countingmat))/1);
	}
	else{
	$matf2[] = round(array_sum(array_column($array_all_mat, $countingmat))/3);	
	}
	$countingmat++;
	}
	$matf = implode("-",array_filter($matf2));
	$matmx2 = explode("-",$matf);
	$matmx = max(explode("-",$matf));
	$stnameandscoreMat = array_combine($acmatkeys,$matmx2);
	//print_r($stnameandscoreMat);
	//echo '<br>';
	$maxinallsub = $matmx;		
	}
		else if($su == 'Music'){
		$resultmxbystunamemus1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Music' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemus1))
	{	
		$snm2mus1[] = $rsn['score'];
		$stin2mus[] = $rsn['student_name'];
	}
	$acmusf = array_combine($stin2mus,$snm2mus1);
	$resultmxbystunamemus2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Music' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemus2))
	{	
		$snm2mus2[] = $rsn['score'];
	    $stin2mus2[] = $rsn['student_name'];
	}
	$acmuss = array_combine($stin2mus2,$snm2mus2);
	$resultmxbystunamemus3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Music' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemus3))
	{	
		$snm2mus3[] = $rsn['score'];
		$stin2mus3[] = $rsn['student_name'];
	}
	$acmust = array_combine($stin2mus3,$snm2mus3);
	$arinall = array($acmusf, $acmuss, $acmust);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acmuskeys = (array_keys($largest_arr));
	
$formus1 = array();
$formus2 = array();
$formus3 = array();
for($v=0; $v<=120; $v++){
$formmus1[] = $snm2mus1[$v];
$formmus2[] = $snm2mus2[$v];
$formmus3[] = $snm2mus3[$v];
}
$formus1 = $formmus1;
$formus2 = $formmus2;
$formus3 = $formmus3;

	$array_all_mus = array(array_filter($formus1), array_filter($formus2), array_filter($formus3));
	$countingmus = 0;
	while($countingmus <= 120){
	if(count(array_column($array_all_mus, $countingmus)) == 3){
	$musf2[] = round(array_sum(array_column($array_all_mus, $countingmus))/3);
	}
	else if(count(array_column($array_all_mus, $countingmus)) == 2){
	$musf2[] = round(array_sum(array_column($array_all_mus, $countingmus))/2);
	}
	else if(count(array_column($array_all_mus, $countingmus)) == 1){
	$musf2[] = round(array_sum(array_column($array_all_mus, $countingmus))/1);
	}
	else{
	$musf2[] = round(array_sum(array_column($array_all_mus, $countingmus))/3);	
	}
	$countingmus++;
	}
	$musf = implode("-",array_filter($musf2));
	$musmx2 = explode("-",$musf);
	$musmx = max(explode("-",$musf));
	$stnameandscoreMus = array_combine($acmuskeys,$musmx2);
	$maxinallsub = $musmx;			
	}
	else if($su == 'PHE'){
		$resultmxbystunamephe1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='PHE' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephe1))
	{	
		$snm2phe1[] = $rsn['score'];
		$stin2phe[] = $rsn['student_name'];
	}
	$acphef = array_combine($stin2phe,$snm2phe1);
	$resultmxbystunamephe2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='PHE' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephe2))
	{	
		$snm2phe2[] = $rsn['score'];
	    $stin2phe2[] = $rsn['student_name'];
	}
	$acphes = array_combine($stin2phe2,$snm2phe2);
	$resultmxbystunamephe3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='PHE' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephe3))
	{	
		$snm2phe3[] = $rsn['score'];
		$stin2phe3[] = $rsn['student_name'];
	}
	$acphet = array_combine($stin2phe3,$snm2phe3);
	$arinall = array($acphef, $acphes, $acphet);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acphekeys = (array_keys($largest_arr));
	
$forphe1 = array();
$forphe2 = array();
$forphe3 = array();
for($v=0; $v<=120; $v++){
$forpphe1[] = $snm2phe1[$v];
$forpphe2[] = $snm2phe2[$v];
$forpphe3[] = $snm2phe3[$v];
}
$forphe1 = $forpphe1;
$forphe2 = $forpphe2;
$forphe3 = $forpphe3;

	$array_all_phe = array(array_filter($forphe1), array_filter($forphe2), array_filter($forphe3));
	$countingphe = 0;
	while($countingphe <= 120){
	if(count(array_column($array_all_phe, $countingphe)) == 3){
	$phef2[] = round(array_sum(array_column($array_all_phe, $countingphe))/3);
	}
	else if(count(array_column($array_all_phe, $countingphe)) == 2){
	$phef2[] = round(array_sum(array_column($array_all_phe, $countingphe))/2);
	}
	else if(count(array_column($array_all_phe, $countingphe)) == 1){
	$phef2[] = round(array_sum(array_column($array_all_phe, $countingphe))/1);
	}
	else{
	$phef2[] = round(array_sum(array_column($array_all_phe, $countingphe))/3);	
	}
	$countingphe++;
	}
	$phef = implode("-",array_filter($phef2));
	$phemx2 = explode("-",$phef);
	$phemx = max(explode("-",$phef));
	$stnameandscorePhe = array_combine($acphekeys,$phemx2);
	$maxinallsub = $phemx;			
	}
		else if($su == 'Phonics'){
		$resultmxbystunamepho1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Phonics' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamepho1))
	{	
		$snm2pho1[] = $rsn['score'];
		$stin2pho[] = $rsn['student_name'];
	}
	$acphof = array_combine($stin2pho,$snm2pho1);
	$resultmxbystunamepho2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Phonics' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamepho2))
	{	
		$snm2pho2[] = $rsn['score'];
	    $stin2pho2[] = $rsn['student_name'];
	}
	$acphos = array_combine($stin2pho2,$snm2pho2);
	$resultmxbystunamepho3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Phonics' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamepho3))
	{	
		$snm2pho3[] = $rsn['score'];
		$stin2pho3[] = $rsn['student_name'];
	}
	$acphot = array_combine($stin2pho3,$snm2pho3);
	$arinall = array($acphof, $acphos, $acphot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acphokeys = (array_keys($largest_arr));
	
$forpho1 = array();
$forpho2 = array();
$forpho3 = array();
for($v=0; $v<=120; $v++){
$forppho1[] = $snm2pho1[$v];
$forppho2[] = $snm2pho2[$v];
$forppho3[] = $snm2pho3[$v];
}
$forpho1 = $forppho1;
$forpho2 = $forppho2;
$forpho3 = $forppho3;

	$array_all_pho = array(array_filter($forpho1), array_filter($forpho2), array_filter($forpho3));
	$countingpho = 0;
	while($countingpho <= 120){
	if(count(array_column($array_all_pho, $countingpho)) == 3){
	$phof2[] = round(array_sum(array_column($array_all_pho, $countingpho))/3);
	}
	else if(count(array_column($array_all_pho, $countingpho)) == 2){
	$phof2[] = round(array_sum(array_column($array_all_pho, $countingpho))/2);
	}
	else if(count(array_column($array_all_pho, $countingpho)) == 1){
	$phof2[] = round(array_sum(array_column($array_all_pho, $countingpho))/1);
	}
	else{
	$phof2[] = round(array_sum(array_column($array_all_pho, $countingpho))/3);	
	}
	$countingpho++;
	}
	$phof = implode("-",array_filter($phof2));
	$phomx2 = explode("-",$phof);
	$phomx = max(explode("-",$phof));
	$stnameandscorePho = array_combine($acphokeys,$phomx2);
	$maxinallsub = $phomx;			
	}
	
	else if($su == 'Physics'){
		$resultmxbystunamephy1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Physics' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephy1))
	{	
		$snm2phy1[] = $rsn['score'];
		$stin2phy[] = $rsn['student_name'];
	}
	$acphyf = array_combine($stin2phy,$snm2phy1);
	$resultmxbystunamephy2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Physics' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephy2))
	{	
		$snm2phy2[] = $rsn['score'];
	    $stin2phy2[] = $rsn['student_name'];
	}
	$acphys = array_combine($stin2phy2,$snm2phy2);
	$resultmxbystunamephy3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Physics' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephy3))
	{	
		$snm2phy3[] = $rsn['score'];
		$stin2phy3[] = $rsn['student_name'];
	}
	$acphyt = array_combine($stin2phy3,$snm2phy3);
	$arinall = array($acphyf, $acphys, $acphyt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acphykeys = (array_keys($largest_arr));
	
$forphy1 = array();
$forphy2 = array();
$forphy3 = array();
for($v=0; $v<=120; $v++){
$forpphy1[] = $snm2phy1[$v];
$forpphy2[] = $snm2phy2[$v];
$forpphy3[] = $snm2phy3[$v];
}
$forphy1 = $forpphy1;
$forphy2 = $forpphy2;
$forphy3 = $forpphy3;

	$array_all_phy = array(array_filter($forphy1), array_filter($forphy2), array_filter($forphy3));
	$countingphy = 0;
	while($countingphy <= 120){
	if(count(array_column($array_all_phy, $countingphy)) == 3){
	$phyf2[] = round(array_sum(array_column($array_all_phy, $countingphy))/3);
	}
	else if(count(array_column($array_all_phy, $countingphy)) == 2){
	$phyf2[] = round(array_sum(array_column($array_all_phy, $countingphy))/2);
	}
	else if(count(array_column($array_all_phy, $countingphy)) == 1){
	$phyf2[] = round(array_sum(array_column($array_all_phy, $countingphy))/1);
	}
	else{
	$phyf2[] = round(array_sum(array_column($array_all_phy, $countingphy))/3);	
	}
	$countingphy++;
	}
	$phyf = implode("-",array_filter($phyf2));
	$phymx2 = explode("-",$phyf);
	$phymx = max(explode("-",$phyf));
	$stnameandscorePhy = array_combine($acphykeys,$phymx2);
	$maxinallsub = $phymx;			
	}
	else if($su == 'Social Studies'){
		$resultmxbystunamesoc1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Social Studies' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesoc1))
	{	
		$snm2soc1[] = $rsn['score'];
		$stin2soc[] = $rsn['student_name'];
	}
	$acsocf = array_combine($stin2soc,$snm2soc1);
	$resultmxbystunamesoc2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Social Studies' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesoc2))
	{	
		$snm2soc2[] = $rsn['score'];
	    $stin2soc2[] = $rsn['student_name'];
	}
	$acsocs = array_combine($stin2soc2,$snm2soc2);
	$resultmxbystunamesoc3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Social Studies' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesoc3))
	{	
		$snm2soc3[] = $rsn['score'];
		$stin2soc3[] = $rsn['student_name'];
	}
	$acsoct = array_combine($stin2soc3,$snm2soc3);
	$arinall = array($acsocf, $acsocs, $acsoct);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acsockeys = (array_keys($largest_arr));
	
$forsoc1 = array();
$forsoc2 = array();
$forsoc3 = array();
for($v=0; $v<=120; $v++){
$forssoc1[] = $snm2soc1[$v];
$forssoc2[] = $snm2soc2[$v];
$forssoc3[] = $snm2soc3[$v];
}
$forsoc1 = $forssoc1;
$forsoc2 = $forssoc2;
$forsoc3 = $forssoc3;

	$array_all_soc = array(array_filter($forsoc1), array_filter($forsoc2), array_filter($forsoc3));
	$countingsoc = 0;
	while($countingsoc <= 120){
	if(count(array_column($array_all_soc, $countingsoc)) == 3){
	$socf2[] = round(array_sum(array_column($array_all_soc, $countingsoc))/3);
	}
	else if(count(array_column($array_all_soc, $countingsoc)) == 2){
	$socf2[] = round(array_sum(array_column($array_all_soc, $countingsoc))/2);
	}
	else if(count(array_column($array_all_soc, $countingsoc)) == 1){
	$socf2[] = round(array_sum(array_column($array_all_soc, $countingsoc))/1);
	}
	else{
	$socf2[] = round(array_sum(array_column($array_all_soc, $countingsoc))/3);	
	}
	$countingsoc++;
	}
	$socf = implode("-",array_filter($socf2));
	$socmx2 = explode("-",$socf);
	$socmx = max(explode("-",$socf));
	$stnameandscoreSoc = array_combine($acsockeys,$socmx2);
	$maxinallsub = $socmx;			
	}
		else if($su == 'Sociology'){
		$resultmxbystunamesocio1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Sociology' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesocio1))
	{	
		$snm2socio1[] = $rsn['score'];
		$stin2socio[] = $rsn['student_name'];
	}
	$acsociof = array_combine($stin2socio,$snm2socio1);
	$resultmxbystunamesocio2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Sociology' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesocio2))
	{	
		$snm2socio2[] = $rsn['score'];
	    $stin2socio2[] = $rsn['student_name'];
	}
	$acsocios = array_combine($stin2socio2,$snm2socio2);
	$resultmxbystunamesocio3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Sociology' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesocio3))
	{	
		$snm2socio3[] = $rsn['score'];
		$stin2socio3[] = $rsn['student_name'];
	}
	$acsociot = array_combine($stin2socio3,$snm2socio3);
	$arinall = array($acsociof, $acsocios, $acsociot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acsociokeys = (array_keys($largest_arr));
	
$forsocio1 = array();
$forsocio2 = array();
$forsocio3 = array();
for($v=0; $v<=120; $v++){
$forssocio1[] = $snm2socio1[$v];
$forssocio2[] = $snm2socio2[$v];
$forssocio3[] = $snm2socio3[$v];
}
$forsocio1 = $forssocio1;
$forsocio2 = $forssocio2;
$forsocio3 = $forssocio3;

	$array_all_socio = array(array_filter($forsocio1), array_filter($forsocio2), array_filter($forsocio3));
	$countingsocio = 0;
	while($countingsocio <= 120){
	if(count(array_column($array_all_socio, $countingsocio)) == 3){
	$sociof2[] = round(array_sum(array_column($array_all_socio, $countingsocio))/3);
	}
	else if(count(array_column($array_all_socio, $countingsocio)) == 2){
	$sociof2[] = round(array_sum(array_column($array_all_socio, $countingsocio))/2);
	}
	else if(count(array_column($array_all_socio, $countingsocio)) == 1){
	$sociof2[] = round(array_sum(array_column($array_all_socio, $countingsocio))/1);
	}
	else{
	$sociof2[] = round(array_sum(array_column($array_all_socio, $countingsocio))/3);	
	}
	$countingsocio++;
	}
	$sociof = implode("-",array_filter($sociof2));
	$sociomx2 = explode("-",$sociof);
	$sociomx = max(explode("-",$sociof));
	$stnameandscoreSocio = array_combine($acsociokeys,$sociomx2);
	$maxinallsub = $sociomx;			
	}
	else if($su == 'TD'){
		$resultmxbystunametd1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='TD' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunametd1))
	{	
		$snm2td1[] = $rsn['score'];
		$stin2td[] = $rsn['student_name'];
	}
	$actdf = array_combine($stin2td,$snm2td1);
	$resultmxbystunametd2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='TD' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunametd2))
	{	
		$snm2td2[] = $rsn['score'];
	    $stin2td2[] = $rsn['student_name'];
	}
	$actds = array_combine($stin2td2,$snm2td2);
	$resultmxbystunametd3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='TD' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunametd3))
	{	
		$snm2td3[] = $rsn['score'];
		$stin2td3[] = $rsn['student_name'];
	}
	$actdt = array_combine($stin2td3,$snm2td3);
	$arinall = array($actdf, $actds, $actdt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$actdkeys = (array_keys($largest_arr));
	
$fortd1 = array();
$fortd2 = array();
$fortd3 = array();
for($v=0; $v<=120; $v++){
$forttd1[] = $snm2td1[$v];
$forttd2[] = $snm2td2[$v];
$forttd3[] = $snm2td3[$v];
}
$fortd1 = $forttd1;
$fortd2 = $forttd2;
$fortd3 = $forttd3;

	$array_all_td = array(array_filter($fortd1), array_filter($fortd2), array_filter($fortd3));
	$countingtd = 0;
	while($countingtd <= 120){
	if(count(array_column($array_all_td, $countingtd)) == 3){
	$tdf2[] = round(array_sum(array_column($array_all_td, $countingtd))/3);
	}
	else if(count(array_column($array_all_td, $countingtd)) == 2){
	$tdf2[] = round(array_sum(array_column($array_all_td, $countingtd))/2);
	}
	else if(count(array_column($array_all_td, $countingtd)) == 1){
	$tdf2[] = round(array_sum(array_column($array_all_td, $countingtd))/1);
	}
	else{
	$tdf2[] = round(array_sum(array_column($array_all_td, $countingtd))/3);	
	}
	$countingtd++;
	}
	$tdf = implode("-",array_filter($tdf2));
	$tdmx2 = explode("-",$tdf);
	$tdmx = max(explode("-",$tdf));
	$stnameandscoreTd = array_combine($actdkeys,$tdmx2);
	$maxinallsub = $tdmx;			
	}
	else if($su == 'VA'){
		$resultmxbystunameva1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='VA' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameva1))
	{	
		$snm2va1[] = $rsn['score'];
		$stin2va[] = $rsn['student_name'];
	}
	$acvaf = array_combine($stin2va,$snm2va1);
	$resultmxbystunameva2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='VA' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameva2))
	{	
		$snm2va2[] = $rsn['score'];
	    $stin2va2[] = $rsn['student_name'];
	}
	$acvas = array_combine($stin2va2,$snm2va2);
	$resultmxbystunameva3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='VA' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameva3))
	{	
		$snm2va3[] = $rsn['score'];
		$stin2va3[] = $rsn['student_name'];
	}
	$acvat = array_combine($stin2va3,$snm2va3);
	$arinall = array($acvaf, $acvas, $acvat);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acvakeys = (array_keys($largest_arr));
	
$forva1 = array();
$forva2 = array();
$forva3 = array();
for($v=0; $v<=120; $v++){
$forvva1[] = $snm2va1[$v];
$forvva2[] = $snm2va2[$v];
$forvva3[] = $snm2va3[$v];
}
$forva1 = $forvva1;
$forva2 = $forvva2;
$forva3 = $forvva3;

	$array_all_va = array(array_filter($forva1), array_filter($forva2), array_filter($forva3));
	$countingva = 0;
	while($countingva <= 120){
	if(count(array_column($array_all_va, $countingva)) == 3){
	$vaf2[] = round(array_sum(array_column($array_all_va, $countingva))/3);
	}
	else if(count(array_column($array_all_va, $countingva)) == 2){
	$vaf2[] = round(array_sum(array_column($array_all_va, $countingva))/2);
	}
	else if(count(array_column($array_all_va, $countingva)) == 1){
	$vaf2[] = round(array_sum(array_column($array_all_va, $countingva))/1);
	}
	else{
	$vaf2[] = round(array_sum(array_column($array_all_va, $countingva))/3);	
	}
	$countingva++;
	}
	$vaf = implode("-",array_filter($vaf2));
	$vamx2 = explode("-",$vaf);
	$vamx = max(explode("-",$vaf));
	$stnameandscoreVa = array_combine($acvakeys,$vamx2);
	$maxinallsub = $vamx;			
	}
	else if($su == 'Vocational Aptitude'){
		$resultmxbystunamevap1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Vocational Aptitude' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevap1))
	{	
		$snm2vap1[] = $rsn['score'];
		$stin2vap[] = $rsn['student_name'];
	}
	$acvapf = array_combine($stin2vap,$snm2vap1);
	$resultmxbystunamevap2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Vocational Aptitude' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevap2))
	{	
		$snm2vap2[] = $rsn['score'];
	    $stin2vap2[] = $rsn['student_name'];
	}
	$acvaps = array_combine($stin2vap2,$snm2vap2);
	$resultmxbystunamevap3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Vocational Aptitude' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevap3))
	{	
		$snm2vap3[] = $rsn['score'];
		$stin2vap3[] = $rsn['student_name'];
	}
	$acvapt = array_combine($stin2vap3,$snm2vap3);
	$arinall = array($acvapf, $acvaps, $acvapt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acvapkeys = (array_keys($largest_arr));
	
$forvap1 = array();
$forvap2 = array();
$forvap3 = array();
for($v=0; $v<=120; $v++){
$forvvap1[] = $snm2vap1[$v];
$forvvap2[] = $snm2vap2[$v];
$forvvap3[] = $snm2vap3[$v];
}
$forvap1 = $forvvap1;
$forvap2 = $forvvap2;
$forvap3 = $forvvap3;

	$array_all_vap = array(array_filter($forvap1), array_filter($forvap2), array_filter($forvap3));
	$countingvap = 0;
	while($countingvap <= 120){
	if(count(array_column($array_all_vap, $countingvap)) == 3){
	$vapf2[] = round(array_sum(array_column($array_all_vap, $countingvap))/3);
	}
	else if(count(array_column($array_all_vap, $countingvap)) == 2){
	$vapf2[] = round(array_sum(array_column($array_all_vap, $countingvap))/2);
	}
	else if(count(array_column($array_all_vap, $countingvap)) == 1){
	$vapf2[] = round(array_sum(array_column($array_all_vap, $countingvap))/1);
	}
	else{
	$vapf2[] = round(array_sum(array_column($array_all_vap, $countingvap))/3);	
	}
	$countingvap++;
	}
	$vapf = implode("-",array_filter($vapf2));
	$vapmx2 = explode("-",$vapf);
	$vapmx = max(explode("-",$vapf));
	$stnameandscoreVap = array_combine($acvapkeys,$vapmx2);
	$maxinallsub = $vapmx;			
	}
	else if($su == 'Yoruba'){
		$resultmxbystunameyor1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Yoruba' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameyor1))
	{	
		$snm2yor1[] = $rsn['score'];
		$stin2yor[] = $rsn['student_name'];
	}
	$acyorf = array_combine($stin2yor,$snm2yor1);
	$resultmxbystunameyor2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Yoruba' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameyor2))
	{	
		$snm2yor2[] = $rsn['score'];
	    $stin2yor2[] = $rsn['student_name'];
	}
	$acyors = array_combine($stin2yor2,$snm2yor2);
	$resultmxbystunameyor3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Yoruba' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameyor3))
	{	
		$snm2yor3[] = $rsn['score'];
		$stin2yor3[] = $rsn['student_name'];
	}
	$acyort = array_combine($stin2yor3,$snm2yor3);
	$arinall = array($acyorf, $acyors, $acyort);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acyorkeys = (array_keys($largest_arr));
	
$foryor1 = array();
$foryor2 = array();
$foryor3 = array();
for($v=0; $v<=120; $v++){
$foryyor1[] = $snm2yor1[$v];
$foryyor2[] = $snm2yor2[$v];
$foryyor3[] = $snm2yor3[$v];
}
$foryor1 = $foryyor1;
$foryor2 = $foryyor2;
$foryor3 = $foryyor3;

	$array_all_yor = array(array_filter($foryor1), array_filter($foryor2), array_filter($foryor3));
	$countingyor = 0;
	while($countingyor <= 120){
	if(count(array_column($array_all_yor, $countingyor)) == 3){
	$yorf2[] = round(array_sum(array_column($array_all_yor, $countingyor))/3);
	}
	else if(count(array_column($array_all_yor, $countingyor)) == 2){
	$yorf2[] = round(array_sum(array_column($array_all_yor, $countingyor))/2);
	}
	else if(count(array_column($array_all_yor, $countingyor)) == 1){
	$yorf2[] = round(array_sum(array_column($array_all_yor, $countingyor))/1);
	}
	else{
	$yorf2[] = round(array_sum(array_column($array_all_yor, $countingyor))/3);	
	}
	$countingyor++;
	}
	$yorf = implode("-",array_filter($yorf2));
	$yormx2 = explode("-",$yorf);
	$yormx = max(explode("-",$yorf));
	$stnameandscoreYor = array_combine($acyorkeys,$yormx2);
	$maxinallsub = $yormx;			
	}
	else if($su == 'Quantitative Reasoning'){
		$resultmxbystunameqr1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Quantitative Reasoning' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameqr1))
	{	
		$snm2qr1[] = $rsn['score'];
		$stin2qr[] = $rsn['student_name'];
	}
	$acqrf = array_combine($stin2qr,$snm2qr1);
	$resultmxbystunameqr2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Quantitative Reasoning' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameqr2))
	{	
		$snm2qr2[] = $rsn['score'];
	    $stin2qr2[] = $rsn['student_name'];
	}
	$acqrs = array_combine($stin2qr2,$snm2qr2);
	$resultmxbystunameqr3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Quantitative Reasoning' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameqr3))
	{	
		$snm2qr3[] = $rsn['score'];
		$stin2qr3[] = $rsn['student_name'];
	}
	$acqrt = array_combine($stin2qr3,$snm2qr3);
	$arinall = array($acqrf, $acqrs, $acqrt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acqrkeys = (array_keys($largest_arr));
	
$forqr1 = array();
$forqr2 = array();
$forqr3 = array();
for($v=0; $v<=120; $v++){
$forqqr1[] = $snm2qr1[$v];
$forqqr2[] = $snm2qr2[$v];
$forqqr3[] = $snm2qr3[$v];
}
$forqr1 = $forqqr1;
$forqr2 = $forqqr2;
$forqr3 = $forqqr3;

	$array_all_qr = array(array_filter($forqr1), array_filter($forqr2), array_filter($forqr3));
	$countingqr = 0;
	while($countingqr <= 120){
	if(count(array_column($array_all_qr, $countingqr)) == 3){
	$qrf2[] = round(array_sum(array_column($array_all_qr, $countingqr))/3);
	}
	else if(count(array_column($array_all_qr, $countingqr)) == 2){
	$qrf2[] = round(array_sum(array_column($array_all_qr, $countingqr))/2);
	}
	else if(count(array_column($array_all_qr, $countingqr)) == 1){
	$qrf2[] = round(array_sum(array_column($array_all_qr, $countingqr))/1);
	}
	else{
	$qrf2[] = round(array_sum(array_column($array_all_qr, $countingqr))/3);	
	}
	$countingqr++;
	}
	$qrf = implode("-",array_filter($qrf2));
	$qrmx2 = explode("-",$qrf);
	$qrmx = max(explode("-",$qrf));
	$stnameandscoreQr = array_combine($acqrkeys,$qrmx2);
	$maxinallsub = $qrmx;			
	}
	else if($su == 'Verbal Reasoning'){
		$resultmxbystunamevr1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Verbal Reasoning' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevr1))
	{	
		$snm2vr1[] = $rsn['score'];
		$stin2vr[] = $rsn['student_name'];
	}
	$acvrf = array_combine($stin2vr,$snm2vr1);
	$resultmxbystunamevr2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Verbal Reasoning' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevr2))
	{	
		$snm2vr2[] = $rsn['score'];
	    $stin2vr2[] = $rsn['student_name'];
	}
	$acvrs = array_combine($stin2vr2,$snm2vr2);
	$resultmxbystunamevr3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Verbal Reasoning' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevr3))
	{	
		$snm2vr3[] = $rsn['score'];
		$stin2vr3[] = $rsn['student_name'];
	}
	$acvrt = array_combine($stin2vr3,$snm2vr3);
	$arinall = array($acvrf, $acvrs, $acvrt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acvrkeys = (array_keys($largest_arr));
	
$forvr1 = array();
$forvr2 = array();
$forvr3 = array();
for($v=0; $v<=120; $v++){
$forvvr1[] = $snm2vr1[$v];
$forvvr2[] = $snm2vr2[$v];
$forvvr3[] = $snm2vr3[$v];
}
$forvr1 = $forvvr1;
$forvr2 = $forvvr2;
$forvr3 = $forvvr3;

	$array_all_vr = array(array_filter($forvr1), array_filter($forvr2), array_filter($forvr3));
	$countingvr = 0;
	while($countingvr <= 120){
	if(count(array_column($array_all_vr, $countingvr)) == 3){
	$vrf2[] = round(array_sum(array_column($array_all_vr, $countingvr))/3);
	}
	else if(count(array_column($array_all_vr, $countingvr)) == 2){
	$vrf2[] = round(array_sum(array_column($array_all_vr, $countingvr))/2);
	}
	else if(count(array_column($array_all_vr, $countingvr)) == 1){
	$vrf2[] = round(array_sum(array_column($array_all_vr, $countingvr))/1);
	}
	else{
	$vrf2[] = round(array_sum(array_column($array_all_vr, $countingvr))/3);	
	}
	$countingvr++;
	}
	$vrf = implode("-",array_filter($vrf2));
	$vrmx2 = explode("-",$vrf);
	$vrmx = max(explode("-",$vrf));
	$stnameandscoreVr = array_combine($acvrkeys,$vrmx2);
	$maxinallsub = $vrmx;			
	}
	elseif($su == 'Handwriting'){							
	$resultmxbystunamehw1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Handwriting' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehw1))
	{	
		$snm2hw1[] = $rsn['score'];
		$stin2hw[] = $rsn['student_name'];
	}
	$achwf = array_combine($stin2hw,$snm2hw1);
	$resultmxbystunamehw2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Handwriting' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehw2))
	{	
		$snm2hw2[] = $rsn['score'];
	    $stin2hw2[] = $rsn['student_name'];
	}
	$achws = array_combine($stin2hw2,$snm2hw2);
	$resultmxbystunamehw3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Handwriting' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehw3))
	{	
		$snm2hw3[] = $rsn['score'];
		$stin2hw3[] = $rsn['student_name'];
	}
	$achwt = array_combine($stin2hw3,$snm2hw3);
	$arinall = array($achwf, $achws, $achwt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$achwkeys = (array_keys($largest_arr));
	
$forhw1 = array();
for($v=0; $v<=120; $v++){
$forhhw1[] = $snm2hw1[$v];
}
$forhw1 = $forhhw1;

$forhw2 = array();
for($v=0; $v<=120; $v++){
$forhhw2[] = $snm2hw2[$v];
}
$forhw2 = $forhhw2;

$forhw3 = array();
for($v=0; $v<=120; $v++){
$forhhw3[] = $snm2hw3[$v];
}
$forhw3 = $forhhw3;

$array_all_hw = array(array_filter($forhw1), array_filter($forhw2), array_filter($forhw3));
	$countinghw = 0;
	while($countinghw <= 120){
	if(count(array_column($array_all_hw, $countinghw)) == 3){
	$hwf2[] = round(array_sum(array_column($array_all_hw, $countinghw))/3);
	}
	else if(count(array_column($array_all_hw, $countinghw)) == 2){
	$hwf2[] = round(array_sum(array_column($array_all_hw, $countinghw))/2);
	}
	else if(count(array_column($array_all_hw, $countinghw)) == 1){
	$hwf2[] = round(array_sum(array_column($array_all_hw, $countinghw))/1);
	}
	else{
	$hwf2[] = round(array_sum(array_column($array_all_hw, $countinghw))/3);	
	}
	$countinghw++;
	}
	$hwf = implode("-",array_filter($hwf2));
	$hwmx2 = explode("-",$hwf);
	$hwmx = max(explode("-",$hwf));
	$stnameandscoreHw = array_combine($achwkeys,$hwmx2);
	$maxinallsub = $hwmx;	
	}
	
	else{	
			$maxinallsub = "-";	
		}		
					echo '<tr><td>'.$su.'</td><td>'.$ct.'</td><td>'.$ex.'</td><td>'.$tt.'</td><td>'.$dd.'</td><td>'.$cc.'</td><td>'.$av.'</td><td>'.$maxinallsub.'</td><td id="mytd">'.round($ccav).'</td><td>'.$grade.'</td><td>'.$tn.'</td><td style="text-align: left;">'.$re.'</td></tr>';	
							$counted++;
							$arrsubj2[] = $su;
							$ca2[] = $ct;
							$exam2[] = $ex;
							$fir2[] = $cc;
							$sec2[] = $dd;
							$thir2[] = $tt;
							$av2[] = $av;
							$ccav2[] = round($ccav);
							$grad2[] = $grade;
							$teacher2[] = $tn;
							$remark2[] = $re;
							$maxinallsub2[] = $maxinallsub;
							}	
							$arrsubj = $arrsubj2;
							$casubarm = $ca2;
							$examsubarm = $exam2;
							$fir = $fir2;
							$sec = $sec2;
							$thir = $thir2;
							$avv = $av2;
							$ccavv = $ccav2;
							$grad = $grad2;
							$teacher = $teacher2;
							$remark = $remark2;						
							$hssubarm = $maxinallsub2;
	}				
	else{
		echo '<tr id="heading"><td>SUBJECT</td><td>CA</td><td>EXAM</td><td>TOTAL</td><td>GRADE</td><td>TEACHER\'S NAME</td><td>REMARK</td></tr>';	
		$result = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
							$grbnt = mysqli_query($db, "SELECT grade FROM gradeband WHERE score='".$row["score"]."'");
							while($rowgrbnt = mysqli_fetch_assoc($grbnt))
							{
							$grade2	= $rowgrbnt['grade'];
							}
							$grade = $grade2;
								
							$row2subject[] = $row["subject"];	
							$row2ca[] = $row["ca"];	
							$row2exam[] = $row["exam"];
							$row2score[] = $row["score"];
							$row2teacher_name[] = $row["teacher_name"];
							$row2remark[] = $row["remark"];
							$grad2[] = $grade;
								echo '<tr><td>'.$row["subject"].'</td><td>'.$row["ca"].'</td><td>'.$row["exam"].'</td><td>'.$row["score"].'</td><td>'.$grade.'</td><td>'.$row["teacher_name"].'</td><td style="text-align: left;">'.$row["remark"].'</td></tr>';	
							}	
							$arrsubj = $row2subject;	
							$ca = $row2ca;	
							$exam = $row2exam;
							$tt = $row2score;
							$grad = $grad2;
							$teacher = $row2teacher_name;
							$remark = $row2remark;	
}	
}
}
	
else if(isset($_POST['submit8'])){
$term = $_POST['term'];
$year = $_POST['year'];
$class_name = $_POST['class_name'];
$arms = $_POST['arms'];
$student_name = $_POST['student_name'];
	if($arms==""){
if($term == "Third Term"){	
	$result1 = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	$sql2 = mysqli_query($db, "SELECT * FROM maxes where subjectname='$subject' AND classname='$class' AND yearname='$year' AND termname='$term' AND teachername='$tna' AND teacheridname='$tid' AND school='".$_SESSION["school"]."'");
					
						while($row1 = mysqli_fetch_assoc($result1))
							{ 
								$firsubject[] = $row1['subject'];
								$firscore[] = $row1['score'];
							}
							$firsubject11 = $firsubject;
							$firscore11 = $firscore;
							$c = array_combine($firsubject11, $firscore11);
							ksort($c);
							$c = array_values($c);
							
	$result2 = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
						while($row2 = mysqli_fetch_assoc($result2))
							{ 
								$secsubject[] = $row2['subject'];
								$secscore[] = $row2['score'];
							}
							$secsubject22 = $secsubject;
							$secscore22 = $secscore;
							$d = array_combine($secsubject22, $secscore22);
							ksort($d);
							$d = array_values($d);
				
							
	$result3 = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
						while($row3 = mysqli_fetch_assoc($result3))
							{ 
								$thirsubject[] = $row3['subject'];
								$thirscore[] = $row3['score'];
							}
							$thirsubject33 = $thirsubject;
							$thirscore33 = $thirscore;
							$t = array_combine($thirsubject33, $thirscore33);
							ksort($t);
							$t = array_values($t);						
							
							$e = array_map(function () {
							return array_sum(func_get_args());
							},$c, $d, $t);
							ksort($e);
		
							
	echo '<tr id="heading"><td>SUBJECT</td><td>CA</td><td>EXAM</td><td>THIRD TERM</td><td>SECOND TERM</td><td>FIRST TERM</td><td>AV. OF THREE TERMS</td><td>CLASS HIGHEST</td><td>CLASS AVERAGE</td><td>GRADE</td><td>TEACHER\'S NAME</td><td>REMARK</td></tr>';	
	
	
	$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."' ORDER BY subject ASC");
	
	$recav = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
	$recavmax = mysqli_query($db, "SELECT MAX(score) AS agrmax FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
	while($rowcav = mysqli_fetch_assoc($recav))
							{
							$agrcavin[]	= $rowcav['score'];
							}
							$agrcav = array_filter($agrcavin);
							$agrcav2 = array_sum($agrcav);
	$numbagr = count(array_filter($agrcav));
	$agrcav3 = $agrcav2/$numbagr;
	
	$recav1 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Basic Science' AND school='".$_SESSION["school"]."'");
	while($rowcav1 = mysqli_fetch_assoc($recav1))
							{
							$bascavin[]	= $rowcav1['score'];
							}
							$bascav = array_filter($bascavin);
							$bascav2 = array_sum($bascav);
	$numbbas = count(array_filter($bascav));
	$bascav3 = $bascav2/$numbbas;
	
	$recav2 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='English' AND school='".$_SESSION["school"]."'");
	$recav2max = mysqli_query($db, "SELECT MAX(score) AS engmax FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='English' AND school='".$_SESSION["school"]."'");
	while($rowcav2 = mysqli_fetch_assoc($recav2))
							{
							$engcavin[]	= $rowcav2['score'];
							}
							$engcav = array_filter($engcavin);
							$engcav2 = array_sum($engcav);
	$numbeng = count(array_filter($engcav));
	$engcav3 = round($engcav2/$numbeng);
	while($rowcav2max = mysqli_fetch_assoc($recav2max))
							{
							$engcavinmax[]	= $rowcav2max['engmax'];
							}
							$engcavmax = array_filter($engcavinmax);
							$engcav2max = array_sum($engcavmax);
	$numbengmax = count(array_filter($engcavmax));
	$engcav3max = $engcav2max/$numbengmax;
	//echo $engcav3max;
	
	$recav3 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Business Studies' AND school='".$_SESSION["school"]."'");
	while($rowcav3 = mysqli_fetch_assoc($recav3))
							{
							$buscavin[]	= $rowcav3['score'];
							}
							$buscav = array_filter($buscavin);
							$buscav2 = array_sum($buscav);
	$numbbus = count(array_filter($buscav));
	$buscav3 = round($buscav2/$numbbus);
	
	$recav4 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Catering' AND school='".$_SESSION["school"]."'");
	while($rowcav4 = mysqli_fetch_assoc($recav4))
							{
							$catcavin[]	= $rowcav4['score'];
							}
							$catcav = array_filter($catcavin);
							$catcav2 = array_sum($catcav);
	$numbcat = count(array_filter($catcav));
	$catcav3 = $catcav2/$numbcat;
	
	$recav5 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Civic Education' AND school='".$_SESSION["school"]."'");
	while($rowcav5 = mysqli_fetch_assoc($recav5))
							{
							$civcavin[]	= $rowcav5['score'];
							}
							$civcav = array_filter($civcavin);
							$civcav2 = array_sum($civcav);
	$numbciv = count(array_filter($civcav));
	$civcav3 = $civcav2/$numbciv;
	
	$recav6 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Crk' AND school='".$_SESSION["school"]."'");
	while($rowcav6 = mysqli_fetch_assoc($recav6))
							{
							$crkcavin[]	= $rowcav6['score'];
							}
							$crkcav = array_filter($crkcavin);
							$crkcav2 = array_sum($crkcav);
	$numbcrk = count(array_filter($crkcav));
	$crkcav3 = $crkcav2/$numbcrk;
	
	$recav7 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Food and Nutrition' AND school='".$_SESSION["school"]."'");
	while($rowcav7 = mysqli_fetch_assoc($recav7))
							{
							$foocavin[]	= $rowcav7['score'];
							}
							$foocav = array_filter($foocavin);
							$foocav2 = array_sum($foocav);
	$numbfoo = count(array_filter($foocav));
	$foocav3 = $foocav2/$numbfoo;
	
	$recav8 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='French' AND school='".$_SESSION["school"]."'");
	while($rowcav8 = mysqli_fetch_assoc($recav8))
							{
							$frecavin[]	= $rowcav8['score'];
							}
							$frecav = array_filter($frecavin);
							$frecav2 = array_sum($frecav);
	$numbfre = count(array_filter($frecav));
	$frecav3 = $frecav2/$numbfre;
	
	$recav9 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='ICT' AND school='".$_SESSION["school"]."'");
	while($rowcav9 = mysqli_fetch_assoc($recav9))
							{
							$ictcavin[]	= $rowcav9['score'];
							}
							$ictcav = array_filter($ictcavin);
							$ictcav2 = array_sum($ictcav);
	$numbict = count(array_filter($ictcav));
	$ictcav3 = $ictcav2/$numbict;
	
	$recav10 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Igbo' AND school='".$_SESSION["school"]."'");
	while($rowcav10 = mysqli_fetch_assoc($recav10))
							{
							$igbcavin[]	= $rowcav10['score'];
							}
							$igbcav = array_filter($igbcavin);
							$igbcav2 = array_sum($igbcav);
	$numbigb = count(array_filter($igbcav));
	$igbcav3 = $igbcav2/$numbigb;
	
	$recav11 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Mathematics' AND school='".$_SESSION["school"]."'");
	while($rowcav11 = mysqli_fetch_assoc($recav11))
							{
							$matcavin[]	= $rowcav11['score'];
							}
							$matcav = array_filter($matcavin);
							$matcav2 = array_sum($matcav);
	$numbmat = count(array_filter($matcav));
	$matcav3 = $matcav2/$numbmat;
	
	$recav12 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Music' AND school='".$_SESSION["school"]."'");
	while($rowcav12 = mysqli_fetch_assoc($recav12))
							{
							$muscavin[]	= $rowcav12['score'];
							}
							$muscav = array_filter($muscavin);
							$muscav2 = array_sum($muscav);
	$numbmus = count(array_filter($muscav));
	$muscav3 = $muscav2/$numbmus;
	
	$recav13 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='PHE' AND school='".$_SESSION["school"]."'");
	while($rowcav13 = mysqli_fetch_assoc($recav13))
							{
							$phecavin[]	= $rowcav13['score'];
							}
							$phecav = array_filter($phecavin);
							$phecav2 = array_sum($phecav);
	$numbphe = count(array_filter($phecav));
	$phecav3 = $phecav2/$numbphe;

	$recav14 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Social Studies' AND school='".$_SESSION["school"]."'");
	while($rowcav14 = mysqli_fetch_assoc($recav14))
							{
							$soccavin[]	= $rowcav14['score'];
							}
							$soccav = array_filter($soccavin);
							$soccav2 = array_sum($soccav);
	$numbsoc = count(array_filter($soccav));
	$soccav3 = $soccav2/$numbsoc;
	
	$recav15 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Biology' AND school='".$_SESSION["school"]."'");
	while($rowcav15 = mysqli_fetch_assoc($recav15))
							{
							$biocavin[]	= $rowcav15['score'];
							}
							$biocav = array_filter($biocavin);
							$biocav2 = array_sum($biocav);
	$numbbio = count(array_filter($biocav));
	$biocav3 = $biocav2/$numbbio;
	
	$recav16 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Chemistry' AND school='".$_SESSION["school"]."'");
	while($rowcav16 = mysqli_fetch_assoc($recav16))
							{
							$checavin[]	= $rowcav16['score'];
							}
							$checav = array_filter($checavin);
							$checav2 = array_sum($checav);
	$numbche = count(array_filter($checav));
	$checav3 = $checav2/$numbche;
	
	$recav17 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Economics' AND school='".$_SESSION["school"]."'");
	while($rowcav17 = mysqli_fetch_assoc($recav17))
							{
							$ecocavin[]	= $rowcav17['score'];
							}
							$ecocav = array_filter($ecocavin);
							$ecocav2 = array_sum($ecocav);
	$numbeco = count(array_filter($ecocav));
	$ecocav3 = $ecocav2/$numbeco;
	
	$recav18 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Government' AND school='".$_SESSION["school"]."'");
	while($rowcav18 = mysqli_fetch_assoc($recav18))
							{
							$govcavin[]	= $rowcav18['score'];
							}
							$govcav = array_filter($govcavin);
							$govcav2 = array_sum($govcav);
	$numbgov = count(array_filter($govcav));
	$govcav3 = $govcav2/$numbgov;
	
	$recav19 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='VA' AND school='".$_SESSION["school"]."'");
	while($rowcav19 = mysqli_fetch_assoc($recav19))
							{
							$vacavin[]	= $rowcav19['score'];
							}
							$vacav = array_filter($vacavin);
							$vacav2 = array_sum($vacav);
	$numbva = count(array_filter($vacav));
	$vacav3 = $vacav2/$numbva;
	
	$recav20 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='TD' AND school='".$_SESSION["school"]."'");
	while($rowcav20 = mysqli_fetch_assoc($recav20))
							{
							$tdcavin[]	= $rowcav20['score'];
							}
							$vacav = array_filter($tdcavin);
							$tdcav2 = array_sum($tdcav);
	$numbtd = count(array_filter($tdcav));
	$tdcav3 = $tdcav2/$numbtd;
	
	$recav21 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Sociology' AND school='".$_SESSION["school"]."'");
	while($rowcav21 = mysqli_fetch_assoc($recav21))
							{
							$socicavin[]	= $rowcav21['score'];
							}
							$socicav = array_filter($socicavin);
							$socicav2 = array_sum($socicav);
	$numbsoci = count(array_filter($socicav));
	$socicav3 = $socicav2/$numbsoci;
							
	$recav22 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Physics' AND school='".$_SESSION["school"]."'");
	while($rowcav22 = mysqli_fetch_assoc($recav22))
							{
							$phycavin[]	= $rowcav22['score'];
							}
							$phycav = array_filter($phycavin);
							$phycav2 = array_sum($phycav);
	$numbphy = count(array_filter($phycav));
	$phycav3 = $phycav2/$numbphy;
	
	$recav23 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Marketing' AND school='".$_SESSION["school"]."'");
	while($rowcav23 = mysqli_fetch_assoc($recav23))
							{
							$marcavin[]	= $rowcav23['score'];
							}
							$marcav = array_filter($marcavin);
							$marcav2 = array_sum($marcav);
	$numbmar = count(array_filter($marcav));
	$marcav3 = $marcav2/$numbmar;
	
	$recav24 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Lit in English' AND school='".$_SESSION["school"]."'");
	while($rowcav24 = mysqli_fetch_assoc($recav24))
							{
							$litcavin[]	= $rowcav24['score'];
							}
							$litcav = array_filter($litcavin);
							$litcav2 = array_sum($litcav);
	$numblit = count(array_filter($litcav));
	$litcav3 = $litcav2/$numblit;
	
	$recav25 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Yoruba' AND school='".$_SESSION["school"]."'");
	while($rowcav25 = mysqli_fetch_assoc($recav25))
							{
							$yorcavin[]	= $rowcav25['score'];
							}
							$yorcav = array_filter($yorcavin);
							$yorcav2 = array_sum($yorcav);
	$numbyor = count(array_filter($yorcav));
	$yorcav3 = $yorcav2/$numbyor;
	
	$recav26 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Quantitative Reasoning' AND school='".$_SESSION["school"]."'");
	while($rowcav26 = mysqli_fetch_assoc($recav26))
							{
							$qrcavin[]	= $rowcav26['score'];
							}
							$qrcav = array_filter($qrcavin);
							$qrcav2 = array_sum($qrcav);
	$numbqr = count(array_filter($qrcav));
	$qrcav3 = $qrcav2/$numbqr;
	
	$recav27 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Verbal Reasoning' AND school='".$_SESSION["school"]."'");
	while($rowcav27 = mysqli_fetch_assoc($recav27))
							{
							$vrcavin[]	= $rowcav27['score'];
							}
							$vrcav = array_filter($vrcavin);
							$vrcav2 = array_sum($vrcav);
	$numbvr = count(array_filter($vrcav));
	$vrcav3 = $vrcav2/$numbvr;
	
		$recav28 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Geography' AND school='".$_SESSION["school"]."'");
	while($rowcav28 = mysqli_fetch_assoc($recav28))
							{
							$geocavin[]	= $rowcav28['score'];
							}
							$geocav = array_filter($geocavin);
							$geocav2 = array_sum($geocav);
	$numbgeo = count(array_filter($geocav));
	$geocav3 = $geocav2/$numbgeo;
	
	$recav29 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Handwriting' AND school='".$_SESSION["school"]."'");
	while($rowcav29 = mysqli_fetch_assoc($recav29))
							{
							$hwcavin[]	= $rowcav29['score'];
							}
							$hwcav = array_filter($hwcavin);
							$hwcav2 = array_sum($hwcav);
	$numbhw = count(array_filter($hwcav));
	$hwcav3 = $hwcav2/$numbhw;
	
	$recav30 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Vocational Aptitude' AND school='".$_SESSION["school"]."'");
	while($rowcav30 = mysqli_fetch_assoc($recav30))
							{
							$vapcavin[]	= $rowcav30['score'];
							}
							$vapcav = array_filter($vapcavin);
							$vapcav2 = array_sum($vapcav);
	$numbvap = count(array_filter($vapcav));
	$vapcav3 = $vapcav2/$numbvap;
	
	$recav31 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Phonics' AND school='".$_SESSION["school"]."'");
	while($rowcav31 = mysqli_fetch_assoc($recav31))
							{
							$phocavin[]	= $rowcav31['score'];
							}
							$phocav = array_filter($phocavin);
							$phocav2 = array_sum($phocav);
	$numbpho = count(array_filter($phocav));
	$phocav3 = $phocav2/$numbpho;
	
	$recav32 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Islamic Religious Studies' AND school='".$_SESSION["school"]."'");
	while($rowcav32 = mysqli_fetch_assoc($recav32))
							{
							$irscavin[]	= $rowcav32['score'];
							}
							$irscav = array_filter($irscavin);
							$irscav2 = array_sum($irscav);
	$numbirs = count(array_filter($irscav));
	$irscav3 = $irscav2/$numbirs;
	
		$recav33 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Creative and Cultural Arts' AND school='".$_SESSION["school"]."'");
	while($rowcav33 = mysqli_fetch_assoc($recav33))
							{
							$ccacavin[]	= $rowcav33['score'];
							}
							$ccacav = array_filter($ccacavin);
							$ccacav2 = array_sum($ccacav);
	$numbcca = count(array_filter($ccacav));
	$ccacav3 = $ccacav2/$numbcca;
	
	$recav34 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='History' AND school='".$_SESSION["school"]."'");
	while($rowcav34 = mysqli_fetch_assoc($recav34))
							{
							$hiscavin[]	= $rowcav34['score'];
							}
							$hiscav = array_filter($hiscavin);
							$hiscav2 = array_sum($hiscav);
	$numbhis = count(array_filter($hiscav));
	$hiscav3 = $hiscav2/$numbhis;
	
	$recav35 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Hausa' AND school='".$_SESSION["school"]."'");
	while($rowcav35 = mysqli_fetch_assoc($recav35))
							{
							$haucavin[]	= $rowcav35['score'];
							}
							$haucav = array_filter($haucavin);
							$haucav2 = array_sum($haucav);
	$numbhau = count(array_filter($haucav));
	$haucav3 = $haucav2/$numbhau;
	
	$recav36 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Hausa' AND school='".$_SESSION["school"]."'");
	while($rowcav36 = mysqli_fetch_assoc($recav36))
							{
							$fincavin[]	= $rowcav36['score'];
							}
							$fincav = array_filter($fincavin);
							$fincav2 = array_sum($fincav);
	$numbfin = count(array_filter($fincav));
	$fincav3 = $fincav2/$numbfin;
	
	$engcount = 0;
	$counter = 0;
	$counted = 0;
	while($row = mysqli_fetch_assoc($result))
							{		
		$to = Array($c[$counted], $d[$counted], $t[$counted]);
		if(($t[$counted] == 0) AND ($c[$counted] != 0) AND ($d[$counted] != 0)){$avdiv = 2; $t[$counted] = "-";}
		elseif(($t[$counted] != 0) AND ($c[$counted] != 0) AND ($d[$counted] == 0)){$avdiv = 2; $d[$counted] = "-";}
		elseif(($t[$counted] != 0) AND ($c[$counted] == 0) AND ($d[$counted] != 0)){$avdiv = 2; $d[$counted] = "-";}
		elseif(($t[$counted] == 0) AND ($c[$counted] != 0) AND ($d[$counted] == 0)){$avdiv = 1; $t[$counted] = "-"; $d[$counted] = "-";}
		elseif(($t[$counted] == 0) AND ($c[$counted] == 0) AND ($d[$counted] != 0)){$avdiv = 1; $c[$counted] = "-"; $t[$counted] = "-";}
		elseif(($t[$counted] != 0) AND ($c[$counted] == 0) AND ($d[$counted] == 0)){$avdiv = 1; $c[$counted] = "-"; $d[$counted] = "-";}
		elseif(($t[$counted] != 0) AND ($c[$counted] != 0) AND ($d[$counted] != 0)){$avdiv = 3;}
		else{$avdiv = 3;}
		$to2 = array_sum($to);
		$av = round($to2/$avdiv);
								$cc = $c[$counted];
								$dd = $d[$counted];
								$tt = $t[$counted];
							$grbnt = mysqli_query($db, "SELECT grade FROM gradeband WHERE score='$av'");
							while($rowgrbnt = mysqli_fetch_assoc($grbnt))
							{
							$grade2	= $rowgrbnt['grade'];
							}
							$grade = $grade2;
								
								if($row["subject"] == "Agricultural Science"){$ccav = $agrcav3;}
								elseif($row["subject"] == "Basic Science"){$ccav = $bascav3;}
								elseif($row["subject"] == "English"){$ccav = $engcav3;}
								elseif($row["subject"] == "Business Studies"){$ccav = $buscav3;}
								elseif($row["subject"] == "Catering"){$ccav = $catcav3;}
								elseif($row["subject"] == "Civic Education"){$ccav = $civcav3;}
								elseif($row["subject"] == "Crk"){$ccav = $crkcav3;}
								elseif($row["subject"] == "Food and Nutrition"){$ccav = $foocav3;}
								elseif($row["subject"] == "ICT"){$ccav = $ictcav3;}
								elseif($row["subject"] == "French"){$ccav = $frecav3;}
								elseif($row["subject"] == "Igbo"){$ccav = $igbcav3;}
								elseif($row["subject"] == "Mathematics"){$ccav = $matcav3;}
								elseif($row["subject"] == "Music"){$ccav = $muscav3;}
								elseif($row["subject"] == "PHE"){$ccav = $phecav3;}
								elseif($row["subject"] == "Social Studies"){$ccav = $soccav3;}
								elseif($row["subject"] == "Biology"){$ccav = $biocav3;}
								elseif($row["subject"] == "Chemistry"){$ccav = $checav3;}
								elseif($row["subject"] == "Economics"){$ccav = $ecocav3;}
								elseif($row["subject"] == "Government"){$ccav = $govcav3;}
								elseif($row["subject"] == "VA"){$ccav = $vacav3;}
								elseif($row["subject"] == "TD"){$ccav = $tdcav3;}
								elseif($row["subject"] == "Sociology"){$ccav = $socicav3;}
								elseif($row["subject"] == "Marketing"){$ccav = $marcav3;}
								elseif($row["subject"] == "Physics"){$ccav = $phycav3;}
								elseif($row["subject"] == "Lit in English"){$ccav = $litcav3;}
								elseif($row["subject"] == "Yoruba"){$ccav = $yorcav3;}
								elseif($row["subject"] == "Quantitative Reasoning"){$ccav = $qrcav3;}
								elseif($row["subject"] == "Verbal Reasoning"){$ccav = $vrcav3;}
								elseif($row["subject"] == "Geography"){$ccav = $geocav3;}
								elseif($row["subject"] == "Handwriting"){$ccav = $hwcav3;}
								elseif($row["subject"] == "Vocational Aptitude"){$ccav = $vapcav3;}
								elseif($row["subject"] == "Phonics"){$ccav = $phocav3;}
								elseif($row["subject"] == "Islamic Religious Studies"){$ccav = $irscav3;}
								elseif($row["subject"] == "Creative and Cultural Arts"){$ccav = $ccacav3;}
								elseif($row["subject"] == "History"){$ccav = $hiscav3;}
								elseif($row["subject"] == "Hausa"){$ccav = $haucav3;}
								elseif($row["subject"] == "Financial Accounting"){$ccav = $fincav3;}
								elseif($ccav == ""){$ccav = "-";}
								else{$ccav = "-";}
								$su = $row["subject"];
								$tn = $row["teacher_name"];
								$re = $row["remark"];
								$ct = $row["ca"];
								$ex = $row["exam"];
	
	if($su == 'English'){							
	$resultmxbystunameeng1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='English' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeng1))
	{	
		$snm2eng1[] = $rsn['score'];
		$stin2eng[] = $rsn['student_name'];
	}
	$acengf = array_combine($stin2eng,$snm2eng1);
	$resultmxbystunameeng2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='English' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeng2))
	{	
		$snm2eng2[] = $rsn['score'];
	    $stin2eng2[] = $rsn['student_name'];
	}
	$acengs = array_combine($stin2eng2,$snm2eng2);
	$resultmxbystunameeng3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='English' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeng3))
	{	
		$snm2eng3[] = $rsn['score'];
		$stin2eng3[] = $rsn['student_name'];
	}
	$acengt = array_combine($stin2eng3,$snm2eng3);
	$arinall = array($acengf, $acengs, $acengt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acengkeys = (array_keys($largest_arr));
	
$foreng1 = array($snm2eng1[0], $snm2eng1[1], $snm2eng1[2], $snm2eng1[3], $snm2eng1[4], $snm2eng1[5], $snm2eng1[6], $snm2eng1[7], $snm2eng1[8], $snm2eng1[9], $snm2eng1[10], $snm2eng1[11], $snm2eng1[12], $snm2eng1[13], $snm2eng1[14], $snm2eng1[15], $snm2eng1[16], $snm2eng1[17], $snm2eng1[18], $snm2eng1[19], 
		  $snm2eng1[20], $snm2eng1[21], $snm2eng1[22], $snm2eng1[23], $snm2eng1[24], $snm2eng1[25], $snm2eng1[26], $snm2eng1[27], $snm2eng1[28], $snm2eng1[29], $snm2eng1[30], $snm2eng1[31], $snm2eng1[32], $snm2eng1[33], $snm2eng1[34], $snm2eng1[35], $snm2eng1[36], $snm2eng1[37], $snm2eng1[38], $snm2eng1[39], 
		  $snm2eng1[40], $snm2eng1[41], $snm2eng1[42], $snm2eng1[43], $snm2eng1[44], $snm2eng1[45], $snm2eng1[46], $snm2eng1[47], $snm2eng1[48], $snm2eng1[49], $snm2eng1[50], $snm2eng1[51], $snm2eng1[52], $snm2eng1[53], $snm2eng1[54], $snm2eng1[55], $snm2eng1[56], $snm2eng1[57], $snm2eng1[58], $snm2eng1[59], 
		  $snm2eng1[60], $snm2eng1[61], $snm2eng1[62], $snm2eng1[63], $snm2eng1[64], $snm2eng1[65], $snm2eng1[66], $snm2eng1[67], $snm2eng1[68], $snm2eng1[69], $snm2eng1[70], $snm2eng1[71], $snm2eng1[72], $snm2eng1[73], $snm2eng1[74], $snm2eng1[75], $snm2eng1[76], $snm2eng1[77], $snm2eng1[78], $snm2eng1[79], 
		  $snm2eng1[80], $snm2eng1[81], $snm2eng1[82], $snm2eng1[83], $snm2eng1[84], $snm2eng1[85], $snm2eng1[86], $snm2eng1[87], $snm2eng1[88], $snm2eng1[89], $snm2eng1[90], $snm2eng1[91], $snm2eng1[92], $snm2eng1[93], $snm2eng1[94], $snm2eng1[95], $snm2eng1[96], $snm2eng1[97], $snm2eng1[98], $snm2eng1[99], 
		  $snm2eng1[100], $snm2eng1[101], $snm2eng1[102], $snm2eng1[103], $snm2eng1[104], $snm2eng1[105], $snm2eng1[106], $snm2eng1[107], $snm2eng1[108], $snm2eng1[109], $snm2eng1[110], $snm2eng1[111], $snm2eng1[112], $snm2eng1[113], $snm2eng1[114], $snm2eng1[115], $snm2eng1[116], $snm2eng1[117], $snm2eng1[118], $snm2eng1[119],
		  $snm2eng1[120]);
$foreng2 = array($snm2eng2[0], $snm2eng2[1], $snm2eng2[2], $snm2eng2[3], $snm2eng2[4], $snm2eng2[5], $snm2eng2[6], $snm2eng2[7], $snm2eng2[8], $snm2eng2[9], $snm2eng2[10], $snm2eng2[11], $snm2eng2[12], $snm2eng2[13], $snm2eng2[14], $snm2eng2[15], $snm2eng2[16], $snm2eng2[17], $snm2eng2[18], $snm2eng2[19], 
		  $snm2eng2[20], $snm2eng2[21], $snm2eng2[22], $snm2eng2[23], $snm2eng2[24], $snm2eng2[25], $snm2eng2[26], $snm2eng2[27], $snm2eng2[28], $snm2eng2[29], $snm2eng2[30], $snm2eng2[31], $snm2eng2[32], $snm2eng2[33], $snm2eng2[34], $snm2eng2[35], $snm2eng2[36], $snm2eng2[37], $snm2eng2[38], $snm2eng2[39], 
		  $snm2eng2[40], $snm2eng2[41], $snm2eng2[42], $snm2eng2[43], $snm2eng2[44], $snm2eng2[45], $snm2eng2[46], $snm2eng2[47], $snm2eng2[48], $snm2eng2[49], $snm2eng2[50], $snm2eng2[51], $snm2eng2[52], $snm2eng2[53], $snm2eng2[54], $snm2eng2[55], $snm2eng2[56], $snm2eng2[57], $snm2eng2[58], $snm2eng2[59],
		  $snm2eng2[60], $snm2eng2[61], $snm2eng2[62], $snm2eng2[63], $snm2eng2[64], $snm2eng2[65], $snm2eng2[66], $snm2eng2[67], $snm2eng2[68], $snm2eng2[69], $snm2eng2[70], $snm2eng2[71], $snm2eng2[72], $snm2eng2[73], $snm2eng2[74], $snm2eng2[75], $snm2eng2[76], $snm2eng2[77], $snm2eng2[78], $snm2eng2[79],
		  $snm2eng2[80], $snm2eng2[81], $snm2eng2[82], $snm2eng2[83], $snm2eng2[84], $snm2eng2[85], $snm2eng2[86], $snm2eng2[87], $snm2eng2[88], $snm2eng2[89], $snm2eng2[90], $snm2eng2[91], $snm2eng2[92], $snm2eng2[93], $snm2eng2[94], $snm2eng2[95], $snm2eng2[96], $snm2eng2[97], $snm2eng2[98], $snm2eng2[99],
		   $snm2eng2[100], $snm2eng2[101], $snm2eng2[102], $snm2eng2[103], $snm2eng2[104], $snm2eng2[105], $snm2eng2[106], $snm2eng2[107], $snm2eng2[108], $snm2eng2[109], $snm2eng2[110], $snm2eng2[111], $snm2eng2[112], $snm2eng2[113], $snm2eng2[114], $snm2eng2[115], $snm2eng2[116], $snm2eng2[117], $snm2eng2[118], $snm2eng2[119],
		  $snm2eng2[120]);
$foreng3 = array($snm2eng3[0], $snm2eng3[1], $snm2eng3[2], $snm2eng3[3], $snm2eng3[4], $snm2eng3[5], $snm2eng3[6], $snm2eng3[7], $snm2eng3[8], $snm2eng3[9], $snm2eng3[10], $snm2eng3[11], $snm2eng3[12], $snm2eng3[13], $snm2eng3[14], $snm2eng3[15], $snm2eng3[16], $snm2eng3[17], $snm2eng3[18], $snm2eng3[19],
		  $snm2eng3[20], $snm2eng3[21], $snm2eng3[22], $snm2eng3[23], $snm2eng3[24], $snm2eng3[25], $snm2eng3[26], $snm2eng3[27], $snm2eng3[28], $snm2eng3[29], $snm2eng3[30], $snm2eng3[31], $snm2eng3[32], $snm2eng3[33], $snm2eng3[34], $snm2eng3[35], $snm2eng3[36], $snm2eng3[37], $snm2eng3[38], $snm2eng3[39],
		  $snm2eng3[40], $snm2eng3[41], $snm2eng3[42], $snm2eng3[43], $snm2eng3[44], $snm2eng3[45], $snm2eng3[46], $snm2eng3[47], $snm2eng3[48], $snm2eng3[49], $snm2eng3[50], $snm2eng3[51], $snm2eng3[52], $snm2eng3[53], $snm2eng3[54], $snm2eng3[55], $snm2eng3[56], $snm2eng3[57], $snm2eng3[58], $snm2eng3[59],
		  $snm2eng3[60], $snm2eng3[61], $snm2eng3[62], $snm2eng3[63], $snm2eng3[64], $snm2eng3[65], $snm2eng3[66], $snm2eng3[67], $snm2eng3[68], $snm2eng3[69], $snm2eng3[70], $snm2eng3[71], $snm2eng3[72], $snm2eng3[73], $snm2eng3[74], $snm2eng3[75], $snm2eng3[76], $snm2eng3[77], $snm2eng3[78], $snm2eng3[79],
		  $snm2eng3[80], $snm2eng3[81], $snm2eng3[82], $snm2eng3[83], $snm2eng3[84], $snm2eng3[85], $snm2eng3[86], $snm2eng3[87], $snm2eng3[88], $snm2eng3[89], $snm2eng3[90], $snm2eng3[91], $snm2eng3[92], $snm2eng3[93], $snm2eng3[94], $snm2eng3[95], $snm2eng3[96], $snm2eng3[97], $snm2eng3[98], $snm2eng3[99],
		  $snm2eng3[100], $snm2eng3[101], $snm2eng3[102], $snm2eng3[103], $snm2eng3[104], $snm2eng3[105], $snm2eng3[106], $snm2eng3[107], $snm2eng3[108], $snm2eng3[109], $snm2eng3[110], $snm2eng3[111], $snm2eng3[112], $snm2eng3[113], $snm2eng3[114], $snm2eng3[115], $snm2eng3[116], $snm2eng3[117], $snm2eng3[118], $snm2eng3[119],
		  $snm2eng3[120]);
$array_all_eng = array(array_filter($foreng1), array_filter($foreng2), array_filter($foreng3));
	$countingeng = 0;
	while($countingeng <= 120){
	if(count(array_column($array_all_eng, $countingeng)) == 3){
	$engf2[] = round(array_sum(array_column($array_all_eng, $countingeng))/3);
	}
	else if(count(array_column($array_all_eng, $countingeng)) == 2){
	$engf2[] = round(array_sum(array_column($array_all_eng, $countingeng))/2);
	}
	else if(count(array_column($array_all_eng, $countingeng)) == 1){
	$engf2[] = round(array_sum(array_column($array_all_eng, $countingeng))/1);
	}
	else{
	$engf2[] = round(array_sum(array_column($array_all_eng, $countingeng))/3);	
	}
	$countingeng++;
	}
	$engf = implode("-",array_filter($engf2));
	$engmx2 = explode("-",$engf);
	$engmx = max(explode("-",$engf));
	$stnameandscoreEng = array_combine($acengkeys,$engmx2);
	//print_r($stnameandscoreEng);
	echo '<br>';
	$maxinallsub = $engmx;	
	}
	else if($su == 'Mathematics'){
	$resultmxbystunamemat1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Mathematics' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemat1))
	{	
		$snm2mat1[] = $rsn['score'];
		$stin2mat[] = $rsn['student_name'];
	}
	$acmatf = array_combine($stin2mat,$snm2mat1);
	$resultmxbystunamemat2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Mathematics' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemat2))
	{	
		$snm2mat2[] = $rsn['score'];
	    $stin2mat2[] = $rsn['student_name'];
	}
	$acmats = array_combine($stin2mat2,$snm2mat2);
	$resultmxbystunamemat3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Mathematics' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemat3))
	{	
		$snm2mat3[] = $rsn['score'];
		$stin2mat3[] = $rsn['student_name'];
	}
	$acmatt = array_combine($stin2mat3,$snm2mat3);
	$arinall = array($acmatf, $acmats, $acmatt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acmatkeys = (array_keys($largest_arr));
	
$format1 = 	array($snm2mat1[0], $snm2mat1[1], $snm2mat1[2], $snm2mat1[3], $snm2mat1[4], $snm2mat1[5], $snm2mat1[6], $snm2mat1[7], $snm2mat1[8], $snm2mat1[9], $snm2mat1[10], $snm2mat1[11], $snm2mat1[12], $snm2mat1[13], $snm2mat1[14], $snm2mat1[15], $snm2mat1[16], $snm2mat1[17], $snm2mat1[18], $snm2mat1[19], 
		  $snm2mat1[20], $snm2mat1[21], $snm2mat1[22], $snm2mat1[23], $snm2mat1[24], $snm2mat1[25], $snm2mat1[26], $snm2mat1[27], $snm2mat1[28], $snm2mat1[29], $snm2mat1[30], $snm2mat1[31], $snm2mat1[32], $snm2mat1[33], $snm2mat1[34], $snm2mat1[35], $snm2mat1[36], $snm2mat1[37], $snm2mat1[38], $snm2mat1[39], 
		  $snm2mat1[40], $snm2mat1[41], $snm2mat1[42], $snm2mat1[43], $snm2mat1[44], $snm2mat1[45], $snm2mat1[46], $snm2mat1[47], $snm2mat1[48], $snm2mat1[49], $snm2mat1[50], $snm2mat1[51], $snm2mat1[52], $snm2mat1[53], $snm2mat1[54], $snm2mat1[55], $snm2mat1[56], $snm2mat1[57], $snm2mat1[58], $snm2mat1[59], 
		  $snm2mat1[60], $snm2mat1[61], $snm2mat1[62], $snm2mat1[63], $snm2mat1[64], $snm2mat1[65], $snm2mat1[66], $snm2mat1[67], $snm2mat1[68], $snm2mat1[69], $snm2mat1[70], $snm2mat1[71], $snm2mat1[72], $snm2mat1[73], $snm2mat1[74], $snm2mat1[75], $snm2mat1[76], $snm2mat1[77], $snm2mat1[78], $snm2mat1[79], 
		  $snm2mat1[80], $snm2mat1[81], $snm2mat1[82], $snm2mat1[83], $snm2mat1[84], $snm2mat1[85], $snm2mat1[86], $snm2mat1[87], $snm2mat1[88], $snm2mat1[89], $snm2mat1[90], $snm2mat1[91], $snm2mat1[92], $snm2mat1[93], $snm2mat1[94], $snm2mat1[95], $snm2mat1[96], $snm2mat1[97], $snm2mat1[98], $snm2mat1[99], 
		  $snm2mat1[100], $snm2mat1[101], $snm2mat1[102], $snm2mat1[103], $snm2mat1[104], $snm2mat1[105], $snm2mat1[106], $snm2mat1[107], $snm2mat1[108], $snm2mat1[109], $snm2mat1[110], $snm2mat1[111], $snm2mat1[112], $snm2mat1[113], $snm2mat1[114], $snm2mat1[115], $snm2mat1[116], $snm2mat1[117], $snm2mat1[118], $snm2mat1[119],
		  $snm2mat1[120]);
$format2 = 	array($snm2mat2[0], $snm2mat2[1], $snm2mat2[2], $snm2mat2[3], $snm2mat2[4], $snm2mat2[5], $snm2mat2[6], $snm2mat2[7], $snm2mat2[8], $snm2mat2[9], $snm2mat2[10], $snm2mat2[11], $snm2mat2[12], $snm2mat2[13], $snm2mat2[14], $snm2mat2[15], $snm2mat2[16], $snm2mat2[17], $snm2mat2[18], $snm2mat2[19], 
		  $snm2mat2[20], $snm2mat2[21], $snm2mat2[22], $snm2mat2[23], $snm2mat2[24], $snm2mat2[25], $snm2mat2[26], $snm2mat2[27], $snm2mat2[28], $snm2mat2[29], $snm2mat2[30], $snm2mat2[31], $snm2mat2[32], $snm2mat2[33], $snm2mat2[34], $snm2mat2[35], $snm2mat2[36], $snm2mat2[37], $snm2mat2[38], $snm2mat2[39], 
		  $snm2mat2[40], $snm2mat2[41], $snm2mat2[42], $snm2mat2[43], $snm2mat2[44], $snm2mat2[45], $snm2mat2[46], $snm2mat2[47], $snm2mat2[48], $snm2mat2[49], $snm2mat2[50], $snm2mat2[51], $snm2mat2[52], $snm2mat2[53], $snm2mat2[54], $snm2mat2[55], $snm2mat2[56], $snm2mat2[57], $snm2mat2[58], $snm2mat2[59],
		  $snm2mat2[60], $snm2mat2[61], $snm2mat2[62], $snm2mat2[63], $snm2mat2[64], $snm2mat2[65], $snm2mat2[66], $snm2mat2[67], $snm2mat2[68], $snm2mat2[69], $snm2mat2[70], $snm2mat2[71], $snm2mat2[72], $snm2mat2[73], $snm2mat2[74], $snm2mat2[75], $snm2mat2[76], $snm2mat2[77], $snm2mat2[78], $snm2mat2[79],
		  $snm2mat2[80], $snm2mat2[81], $snm2mat2[82], $snm2mat2[83], $snm2mat2[84], $snm2mat2[85], $snm2mat2[86], $snm2mat2[87], $snm2mat2[88], $snm2mat2[89], $snm2mat2[90], $snm2mat2[91], $snm2mat2[92], $snm2mat2[93], $snm2mat2[94], $snm2mat2[95], $snm2mat2[96], $snm2mat2[97], $snm2mat2[98], $snm2mat2[99],
		   $snm2mat2[100], $snm2mat2[101], $snm2mat2[102], $snm2mat2[103], $snm2mat2[104], $snm2mat2[105], $snm2mat2[106], $snm2mat2[107], $snm2mat2[108], $snm2mat2[109], $snm2mat2[110], $snm2mat2[111], $snm2mat2[112], $snm2mat2[113], $snm2mat2[114], $snm2mat2[115], $snm2mat2[116], $snm2mat2[117], $snm2mat2[118], $snm2mat2[119],
		  $snm2mat2[120]);
$format3 = 	array($snm2mat3[0], $snm2mat3[1], $snm2mat3[2], $snm2mat3[3], $snm2mat3[4], $snm2mat3[5], $snm2mat3[6], $snm2mat3[7], $snm2mat3[8], $snm2mat3[9], $snm2mat3[10], $snm2mat3[11], $snm2mat3[12], $snm2mat3[13], $snm2mat3[14], $snm2mat3[15], $snm2mat3[16], $snm2mat3[17], $snm2mat3[18], $snm2mat3[19],
		  $snm2mat3[20], $snm2mat3[21], $snm2mat3[22], $snm2mat3[23], $snm2mat3[24], $snm2mat3[25], $snm2mat3[26], $snm2mat3[27], $snm2mat3[28], $snm2mat3[29], $snm2mat3[30], $snm2mat3[31], $snm2mat3[32], $snm2mat3[33], $snm2mat3[34], $snm2mat3[35], $snm2mat3[36], $snm2mat3[37], $snm2mat3[38], $snm2mat3[39],
		  $snm2mat3[40], $snm2mat3[41], $snm2mat3[42], $snm2mat3[43], $snm2mat3[44], $snm2mat3[45], $snm2mat3[46], $snm2mat3[47], $snm2mat3[48], $snm2mat3[49], $snm2mat3[50], $snm2mat3[51], $snm2mat3[52], $snm2mat3[53], $snm2mat3[54], $snm2mat3[55], $snm2mat3[56], $snm2mat3[57], $snm2mat3[58], $snm2mat3[59],
		  $snm2mat3[60], $snm2mat3[61], $snm2mat3[62], $snm2mat3[63], $snm2mat3[64], $snm2mat3[65], $snm2mat3[66], $snm2mat3[67], $snm2mat3[68], $snm2mat3[69], $snm2mat3[70], $snm2mat3[71], $snm2mat3[72], $snm2mat3[73], $snm2mat3[74], $snm2mat3[75], $snm2mat3[76], $snm2mat3[77], $snm2mat3[78], $snm2mat3[79],
		  $snm2mat3[80], $snm2mat3[81], $snm2mat3[82], $snm2mat3[83], $snm2mat3[84], $snm2mat3[85], $snm2mat3[86], $snm2mat3[87], $snm2mat3[88], $snm2mat3[89], $snm2mat3[90], $snm2mat3[91], $snm2mat3[92], $snm2mat3[93], $snm2mat3[94], $snm2mat3[95], $snm2mat3[96], $snm2mat3[97], $snm2mat3[98], $snm2mat3[99],
		  $snm2mat3[100], $snm2mat3[101], $snm2mat3[102], $snm2mat3[103], $snm2mat3[104], $snm2mat3[105], $snm2mat3[106], $snm2mat3[107], $snm2mat3[108], $snm2mat3[109], $snm2mat3[110], $snm2mat3[111], $snm2mat3[112], $snm2mat3[113], $snm2mat3[114], $snm2mat3[115], $snm2mat3[116], $snm2mat3[117], $snm2mat3[118], $snm2mat3[119],
		  $snm2mat3[120]);	  
	$array_all_mat = array(array_filter($format1), array_filter($format2), array_filter($format3));
	$countingmat = 0;
	while($countingmat <= 120){
	if(count(array_column($array_all_mat, $countingmat)) == 3){
	$matf2[] = round(array_sum(array_column($array_all_mat, $countingmat))/3);
	}
	else if(count(array_column($array_all_mat, $countingmat)) == 2){
	$matf2[] = round(array_sum(array_column($array_all_mat, $countingmat))/2);
	}
	else if(count(array_column($array_all_mat, $countingmat)) == 1){
	$matf2[] = round(array_sum(array_column($array_all_mat, $countingmat))/1);
	}
	else{
	$matf2[] = round(array_sum(array_column($array_all_mat, $countingmat))/3);	
	}
	$countingmat++;
	}
	$matf = implode("-",array_filter($matf2));
	$matmx2 = explode("-",$matf);
	$matmx = max(explode("-",$matf));
	$stnameandscoreMat = array_combine($acmatkeys,$matmx2);
	//print_r($stnameandscoreMat);
	//echo '<br>';
	$maxinallsub = $matmx;		
	}
	
	else if($su == 'French'){
	$resultmxbystunamefre1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='French' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefre1))
	{	
		$snm2fre1[] = $rsn['score'];
		$stin2fre[] = $rsn['student_name'];
	}
	$acfref = array_combine($stin2fre,$snm2fre1);
	$resultmxbystunamefre2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='French' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefre2))
	{	
		$snm2fre2[] = $rsn['score'];
	    $stin2fre2[] = $rsn['student_name'];
	}
	$acfres = array_combine($stin2fre2,$snm2fre2);
	$resultmxbystunamefre3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='French' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefre3))
	{	
		$snm2fre3[] = $rsn['score'];
		$stin2fre3[] = $rsn['student_name'];
	}
	$acfret = array_combine($stin2fre3,$snm2fre3);
	$arinall = array($acfref, $acfres, $acfret);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acfrekeys = (array_keys($largest_arr));
$forfre1 = 	array($snm2fre1[0], $snm2fre1[1], $snm2fre1[2], $snm2fre1[3], $snm2fre1[4], $snm2fre1[5], $snm2fre1[6], $snm2fre1[7], $snm2fre1[8], $snm2fre1[9], $snm2fre1[10], $snm2fre1[11], $snm2fre1[12], $snm2fre1[13], $snm2fre1[14], $snm2fre1[15], $snm2fre1[16], $snm2fre1[17], $snm2fre1[18], $snm2fre1[19], 
		  $snm2fre1[20], $snm2fre1[21], $snm2fre1[22], $snm2fre1[23], $snm2fre1[24], $snm2fre1[25], $snm2fre1[26], $snm2fre1[27], $snm2fre1[28], $snm2fre1[29], $snm2fre1[30], $snm2fre1[31], $snm2fre1[32], $snm2fre1[33], $snm2fre1[34], $snm2fre1[35], $snm2fre1[36], $snm2fre1[37], $snm2fre1[38], $snm2fre1[39], 
		  $snm2fre1[40], $snm2fre1[41], $snm2fre1[42], $snm2fre1[43], $snm2fre1[44], $snm2fre1[45], $snm2fre1[46], $snm2fre1[47], $snm2fre1[48], $snm2fre1[49], $snm2fre1[50], $snm2fre1[51], $snm2fre1[52], $snm2fre1[53], $snm2fre1[54], $snm2fre1[55], $snm2fre1[56], $snm2fre1[57], $snm2fre1[58], $snm2fre1[59], 
		  $snm2fre1[60], $snm2fre1[61], $snm2fre1[62], $snm2fre1[63], $snm2fre1[64], $snm2fre1[65], $snm2fre1[66], $snm2fre1[67], $snm2fre1[68], $snm2fre1[69], $snm2fre1[70], $snm2fre1[71], $snm2fre1[72], $snm2fre1[73], $snm2fre1[74], $snm2fre1[75], $snm2fre1[76], $snm2fre1[77], $snm2fre1[78], $snm2fre1[79], 
		  $snm2fre1[80], $snm2fre1[81], $snm2fre1[82], $snm2fre1[83], $snm2fre1[84], $snm2fre1[85], $snm2fre1[86], $snm2fre1[87], $snm2fre1[88], $snm2fre1[89], $snm2fre1[90], $snm2fre1[91], $snm2fre1[92], $snm2fre1[93], $snm2fre1[94], $snm2fre1[95], $snm2fre1[96], $snm2fre1[97], $snm2fre1[98], $snm2fre1[99], 
		  $snm2fre1[100], $snm2fre1[101], $snm2fre1[102], $snm2fre1[103], $snm2fre1[104], $snm2fre1[105], $snm2fre1[106], $snm2fre1[107], $snm2fre1[108], $snm2fre1[109], $snm2fre1[110], $snm2fre1[111], $snm2fre1[112], $snm2fre1[113], $snm2fre1[114], $snm2fre1[115], $snm2fre1[116], $snm2fre1[117], $snm2fre1[118], $snm2fre1[119],
		  $snm2fre1[120]);
$forfre2 = 	array($snm2fre2[0], $snm2fre2[1], $snm2fre2[2], $snm2fre2[3], $snm2fre2[4], $snm2fre2[5], $snm2fre2[6], $snm2fre2[7], $snm2fre2[8], $snm2fre2[9], $snm2fre2[10], $snm2fre2[11], $snm2fre2[12], $snm2fre2[13], $snm2fre2[14], $snm2fre2[15], $snm2fre2[16], $snm2fre2[17], $snm2fre2[18], $snm2fre2[19], 
		  $snm2fre2[20], $snm2fre2[21], $snm2fre2[22], $snm2fre2[23], $snm2fre2[24], $snm2fre2[25], $snm2fre2[26], $snm2fre2[27], $snm2fre2[28], $snm2fre2[29], $snm2fre2[30], $snm2fre2[31], $snm2fre2[32], $snm2fre2[33], $snm2fre2[34], $snm2fre2[35], $snm2fre2[36], $snm2fre2[37], $snm2fre2[38], $snm2fre2[39], 
		  $snm2fre2[40], $snm2fre2[41], $snm2fre2[42], $snm2fre2[43], $snm2fre2[44], $snm2fre2[45], $snm2fre2[46], $snm2fre2[47], $snm2fre2[48], $snm2fre2[49], $snm2fre2[50], $snm2fre2[51], $snm2fre2[52], $snm2fre2[53], $snm2fre2[54], $snm2fre2[55], $snm2fre2[56], $snm2fre2[57], $snm2fre2[58], $snm2fre2[59],
		  $snm2fre2[60], $snm2fre2[61], $snm2fre2[62], $snm2fre2[63], $snm2fre2[64], $snm2fre2[65], $snm2fre2[66], $snm2fre2[67], $snm2fre2[68], $snm2fre2[69], $snm2fre2[70], $snm2fre2[71], $snm2fre2[72], $snm2fre2[73], $snm2fre2[74], $snm2fre2[75], $snm2fre2[76], $snm2fre2[77], $snm2fre2[78], $snm2fre2[79],
		  $snm2fre2[80], $snm2fre2[81], $snm2fre2[82], $snm2fre2[83], $snm2fre2[84], $snm2fre2[85], $snm2fre2[86], $snm2fre2[87], $snm2fre2[88], $snm2fre2[89], $snm2fre2[90], $snm2fre2[91], $snm2fre2[92], $snm2fre2[93], $snm2fre2[94], $snm2fre2[95], $snm2fre2[96], $snm2fre2[97], $snm2fre2[98], $snm2fre2[99],
		   $snm2fre2[100], $snm2fre2[101], $snm2fre2[102], $snm2fre2[103], $snm2fre2[104], $snm2fre2[105], $snm2fre2[106], $snm2fre2[107], $snm2fre2[108], $snm2fre2[109], $snm2fre2[110], $snm2fre2[111], $snm2fre2[112], $snm2fre2[113], $snm2fre2[114], $snm2fre2[115], $snm2fre2[116], $snm2fre2[117], $snm2fre2[118], $snm2fre2[119],
		  $snm2fre2[120]);
$forfre3 = 	array($snm2fre3[0], $snm2fre3[1], $snm2fre3[2], $snm2fre3[3], $snm2fre3[4], $snm2fre3[5], $snm2fre3[6], $snm2fre3[7], $snm2fre3[8], $snm2fre3[9], $snm2fre3[10], $snm2fre3[11], $snm2fre3[12], $snm2fre3[13], $snm2fre3[14], $snm2fre3[15], $snm2fre3[16], $snm2fre3[17], $snm2fre3[18], $snm2fre3[19],
		  $snm2fre3[20], $snm2fre3[21], $snm2fre3[22], $snm2fre3[23], $snm2fre3[24], $snm2fre3[25], $snm2fre3[26], $snm2fre3[27], $snm2fre3[28], $snm2fre3[29], $snm2fre3[30], $snm2fre3[31], $snm2fre3[32], $snm2fre3[33], $snm2fre3[34], $snm2fre3[35], $snm2fre3[36], $snm2fre3[37], $snm2fre3[38], $snm2fre3[39],
		  $snm2fre3[40], $snm2fre3[41], $snm2fre3[42], $snm2fre3[43], $snm2fre3[44], $snm2fre3[45], $snm2fre3[46], $snm2fre3[47], $snm2fre3[48], $snm2fre3[49], $snm2fre3[50], $snm2fre3[51], $snm2fre3[52], $snm2fre3[53], $snm2fre3[54], $snm2fre3[55], $snm2fre3[56], $snm2fre3[57], $snm2fre3[58], $snm2fre3[59],
		  $snm2fre3[60], $snm2fre3[61], $snm2fre3[62], $snm2fre3[63], $snm2fre3[64], $snm2fre3[65], $snm2fre3[66], $snm2fre3[67], $snm2fre3[68], $snm2fre3[69], $snm2fre3[70], $snm2fre3[71], $snm2fre3[72], $snm2fre3[73], $snm2fre3[74], $snm2fre3[75], $snm2fre3[76], $snm2fre3[77], $snm2fre3[78], $snm2fre3[79],
		  $snm2fre3[80], $snm2fre3[81], $snm2fre3[82], $snm2fre3[83], $snm2fre3[84], $snm2fre3[85], $snm2fre3[86], $snm2fre3[87], $snm2fre3[88], $snm2fre3[89], $snm2fre3[90], $snm2fre3[91], $snm2fre3[92], $snm2fre3[93], $snm2fre3[94], $snm2fre3[95], $snm2fre3[96], $snm2fre3[97], $snm2fre3[98], $snm2fre3[99],
		  $snm2fre3[100], $snm2fre3[101], $snm2fre3[102], $snm2fre3[103], $snm2fre3[104], $snm2fre3[105], $snm2fre3[106], $snm2fre3[107], $snm2fre3[108], $snm2fre3[109], $snm2fre3[110], $snm2fre3[111], $snm2fre3[112], $snm2fre3[113], $snm2fre3[114], $snm2fre3[115], $snm2fre3[116], $snm2fre3[117], $snm2fre3[118], $snm2fre3[119],
		  $snm2fre3[120]);	  
	$array_all_fre = array(array_filter($forfre1), array_filter($forfre2), array_filter($forfre3));
	$countingfre = 0;
	while($countingfre <= 120){
	if(count(array_column($array_all_fre, $countingfre)) == 3){
	$fref2[] = round(array_sum(array_column($array_all_fre, $countingfre))/3);
	}
	else if(count(array_column($array_all_fre, $countingfre)) == 2){
	$fref2[] = round(array_sum(array_column($array_all_fre, $countingfre))/2);
	}
	else if(count(array_column($array_all_fre, $countingfre)) == 1){
	$fref2[] = round(array_sum(array_column($array_all_fre, $countingfre))/1);
	}
	else{
	$fref2[] = round(array_sum(array_column($array_all_fre, $countingfre))/3);	
	}
	$countingfre++;
	}
	$fref = implode("-",array_filter($fref2));
	$fremx2 = explode("-",$fref);
	$fremx = max(explode("-",$fref));
	$stnameandscoreFre = array_combine($acfrekeys,$fremx2);
	//print_r($stnameandscoreFre);
	//echo '<br>';
	$maxinallsub = $fremx;		
	}
	
	else if($su == 'Agricultural Science'){
		$resultmxbystunameagr1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Agricultural Science' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameagr1))
	{	
		$snm2agr1[] = $rsn['score'];
		$stin2agr[] = $rsn['student_name'];
	}
	$acagrf = array_combine($stin2agr,$snm2agr1);
	$resultmxbystunameagr2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Agricultural Science' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameagr2))
	{	
		$snm2agr2[] = $rsn['score'];
	    $stin2agr2[] = $rsn['student_name'];
	}
	$acagrs = array_combine($stin2agr2,$snm2agr2);
	$resultmxbystunameagr3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Agricultural Science' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameagr3))
	{	
		$snm2agr3[] = $rsn['score'];
		$stin2agr3[] = $rsn['student_name'];
	}
	$acagrt = array_combine($stin2agr3,$snm2agr3);
	$arinall = array($acagrf, $acagrs, $acagrt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acagrkeys = (array_keys($largest_arr));
$foragr1 = 	array($snm2agr1[0], $snm2agr1[1], $snm2agr1[2], $snm2agr1[3], $snm2agr1[4], $snm2agr1[5], $snm2agr1[6], $snm2agr1[7], $snm2agr1[8], $snm2agr1[9], $snm2agr1[10], $snm2agr1[11], $snm2agr1[12], $snm2agr1[13], $snm2agr1[14], $snm2agr1[15], $snm2agr1[16], $snm2agr1[17], $snm2agr1[18], $snm2agr1[19], 
		  $snm2agr1[20], $snm2agr1[21], $snm2agr1[22], $snm2agr1[23], $snm2agr1[24], $snm2agr1[25], $snm2agr1[26], $snm2agr1[27], $snm2agr1[28], $snm2agr1[29], $snm2agr1[30], $snm2agr1[31], $snm2agr1[32], $snm2agr1[33], $snm2agr1[34], $snm2fre1[35], $snm2agr1[36], $snm2agr1[37], $snm2agr1[38], $snm2agr1[39], 
		  $snm2agr1[40], $snm2agr1[41], $snm2agr1[42], $snm2agr1[43], $snm2agr1[44], $snm2agr1[45], $snm2agr1[46], $snm2agr1[47], $snm2agr1[48], $snm2agr1[49], $snm2agr1[50], $snm2agr1[51], $snm2agr1[52], $snm2agr1[53], $snm2agr1[54], $snm2fre1[55], $snm2agr1[56], $snm2agr1[57], $snm2agr1[58], $snm2agr1[59], 
		  $snm2agr1[60], $snm2agr1[61], $snm2agr1[62], $snm2agr1[63], $snm2agr1[64], $snm2agr1[65], $snm2agr1[66], $snm2agr1[67], $snm2agr1[68], $snm2agr1[69], $snm2agr1[70], $snm2agr1[71], $snm2agr1[72], $snm2agr1[73], $snm2agr1[74], $snm2fre1[75], $snm2agr1[76], $snm2agr1[77], $snm2agr1[78], $snm2agr1[79], 
		  $snm2agr1[80], $snm2agr1[81], $snm2agr1[82], $snm2agr1[83], $snm2agr1[84], $snm2agr1[85], $snm2agr1[86], $snm2agr1[87], $snm2agr1[88], $snm2agr1[89], $snm2agr1[90], $snm2agr1[91], $snm2agr1[92], $snm2agr1[93], $snm2agr1[94], $snm2fre1[95], $snm2agr1[96], $snm2agr1[97], $snm2agr1[98], $snm2agr1[99], 
		  $snm2agr1[100], $snm2agr1[101], $snm2agr1[102], $snm2agr1[103], $snm2agr1[104], $snm2agr1[105], $snm2agr1[106], $snm2agr1[107], $snm2agr1[108], $snm2agr1[109], $snm2agr1[110], $snm2agr1[111], $snm2agr1[112], $snm2agr1[113], $snm2agr1[114], $snm2agr1[115], $snm2agr1[116], $snm2agr1[117], $snm2agr1[118], $snm2agr1[119],
		  $snm2agr1[120]);
$foragr2 = 	array($snm2agr2[0], $snm2agr2[1], $snm2agr2[2], $snm2agr2[3], $snm2agr2[4], $snm2agr2[5], $snm2agr2[6], $snm2agr2[7], $snm2agr2[8], $snm2agr2[9], $snm2agr2[10], $snm2agr2[11], $snm2agr2[12], $snm2agr2[13], $snm2agr2[14], $snm2agr2[15], $snm2agr2[16], $snm2agr2[17], $snm2agr2[18], $snm2agr2[19], 
		  $snm2agr2[20], $snm2agr2[21], $snm2agr2[22], $snm2agr2[23], $snm2agr2[24], $snm2agr2[25], $snm2agr2[26], $snm2agr2[27], $snm2agr2[28], $snm2agr2[29], $snm2agr2[30], $snm2agr2[31], $snm2agr2[32], $snm2agr2[33], $snm2agr2[34], $snm2agr2[35], $snm2agr2[36], $snm2agr2[37], $snm2agr2[38], $snm2agr2[39], 
		  $snm2agr2[40], $snm2agr2[41], $snm2agr2[42], $snm2agr2[43], $snm2fre2[44], $snm2agr2[45], $snm2agr2[46], $snm2agr2[47], $snm2agr2[48], $snm2agr2[49], $snm2agr2[50], $snm2agr2[51], $snm2agr2[52], $snm2agr2[53], $snm2agr2[54], $snm2agr2[55], $snm2agr2[56], $snm2agr2[57], $snm2agr2[58], $snm2agr2[59],
		  $snm2agr2[60], $snm2agr2[61], $snm2agr2[62], $snm2agr2[63], $snm2fre2[64], $snm2agr2[65], $snm2agr2[66], $snm2agr2[67], $snm2agr2[68], $snm2agr2[69], $snm2agr2[70], $snm2agr2[71], $snm2agr2[72], $snm2agr2[73], $snm2agr2[74], $snm2agr2[75], $snm2agr2[76], $snm2agr2[77], $snm2agr2[78], $snm2agr2[79],
		  $snm2agr2[80], $snm2agr2[81], $snm2agr2[82], $snm2agr2[83], $snm2fre2[84], $snm2agr2[85], $snm2agr2[86], $snm2agr2[87], $snm2agr2[88], $snm2agr2[89], $snm2agr2[90], $snm2agr2[91], $snm2agr2[92], $snm2agr2[93], $snm2agr2[94], $snm2agr2[95], $snm2agr2[96], $snm2agr2[97], $snm2agr2[98], $snm2agr2[99],
		   $snm2agr2[100], $snm2agr2[101], $snm2agr2[102], $snm2agr2[103], $snm2agr2[104], $snm2agr2[105], $snm2agr2[106], $snm2agr2[107], $snm2agr2[108], $snm2agr2[109], $snm2agr2[110], $snm2agr2[111], $snm2agr2[112], $snm2agr2[113], $snm2agr2[114], $snm2agr2[115], $snm2agr2[116], $snm2agr2[117], $snm2agr2[118], $snm2agr2[119],
		  $snm2agr2[120]);
$foragr3 = 	array($snm2agr3[0], $snm2agr3[1], $snm2agr3[2], $snm2agr3[3], $snm2agr3[4], $snm2agr3[5], $snm2agr3[6], $snm2agr3[7], $snm2agr3[8], $snm2agr3[9], $snm2agr3[10], $snm2agr3[11], $snm2agr3[12], $snm2agr3[13], $snm2agr3[14], $snm2agr3[15], $snm2agr3[16], $snm2agr3[17], $snm2agr3[18], $snm2agr3[19],
		  $snm2agr3[20], $snm2agr3[21], $snm2agr3[22], $snm2agr3[23], $snm2agr3[24], $snm2agr3[25], $snm2agr3[26], $snm2agr3[27], $snm2agr3[28], $snm2agr3[29], $snm2agr3[30], $snm2agr3[31], $snm2agr3[32], $snm2agr3[33], $snm2agr3[34], $snm2agr3[35], $snm2agr3[36], $snm2agr3[37], $snm2agr3[38], $snm2agr3[39], 
		  $snm2agr3[41], $snm2agr3[41], $snm2agr3[42], $snm2agr3[43], $snm2agr3[44], $snm2agr3[45], $snm2agr3[46], $snm2agr3[47], $snm2agr3[48], $snm2agr3[49], $snm2agr3[50], $snm2agr3[51], $snm2agr3[52], $snm2agr3[53], $snm2agr3[54], $snm2agr3[55], $snm2agr3[56], $snm2agr3[57], $snm2agr3[58], $snm2agr3[59],
		  $snm2agr3[60], $snm2agr3[61], $snm2agr3[62], $snm2agr3[63], $snm2agr3[64], $snm2agr3[65], $snm2agr3[66], $snm2agr3[67], $snm2agr3[68], $snm2agr3[69], $snm2agr3[70], $snm2agr3[71], $snm2agr3[72], $snm2agr3[73], $snm2agr3[74], $snm2agr3[75], $snm2agr3[76], $snm2agr3[77], $snm2agr3[78], $snm2agr3[79],
		  $snm2agr3[80], $snm2agr3[81], $snm2agr3[82], $snm2agr3[83], $snm2agr3[84], $snm2agr3[85], $snm2agr3[86], $snm2agr3[87], $snm2agr3[88], $snm2agr3[89], $snm2agr3[90], $snm2agr3[91], $snm2agr3[92], $snm2agr3[93], $snm2agr3[94], $snm2agr3[95], $snm2agr3[96], $snm2agr3[97], $snm2agr3[98], $snm2agr3[99],
		  $snm2agr3[100], $snm2agr3[101], $snm2agr3[102], $snm2agr3[103], $snm2agr3[104], $snm2agr3[105], $snm2agr3[106], $snm2agr3[107], $snm2agr3[108], $snm2agr3[109], $snm2agr3[110], $snm2agr3[111], $snm2agr3[112], $snm2agr3[113], $snm2agr3[114], $snm2agr3[115], $snm2agr3[116], $snm2agr3[117], $snm2agr3[118], $snm2agr3[119],
		  $snm2agr3[120]);	  
	$array_all_agr = array(array_filter($foragr1), array_filter($foragr2), array_filter($foragr3));
	$countingagr = 0;
	while($countingagr <= 120){
	if(count(array_column($array_all_agr, $countingagr)) == 3){
	$agrf2[] = round(array_sum(array_column($array_all_agr, $countingagr))/3);
	}
	else if(count(array_column($array_all_agr, $countingagr)) == 2){
	$agrf2[] = round(array_sum(array_column($array_all_agr, $countingagr))/2);
	}
	else if(count(array_column($array_all_agr, $countingagr)) == 1){
	$agrf2[] = round(array_sum(array_column($array_all_agr, $countingagr))/1);
	}
	else{
	$agrf2[] = round(array_sum(array_column($array_all_agr, $countingagr))/3);	
	}
	$countingagr++;
	}
	$agrf = implode("-",array_filter($agrf2));
	$agrmx2 = explode("-",$agrf);
	$agrmx = max(explode("-",$agrf));
	$stnameandscoreAgr = array_combine($acagrkeys,$agrmx2);
	//print_r($stnameandscoreAgr);
	//echo '<br>';
	$maxinallsub = $agrmx;	
	}
	else if($su == 'Basic Science'){
		$resultmxbystunamebas1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Basic Science' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebas1))
	{	
		$snm2bas1[] = $rsn['score'];
		$stin2bas[] = $rsn['student_name'];
	}
	$acbasf = array_combine($stin2bas,$snm2bas1);
	$resultmxbystunamebas2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Basic Science' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebas2))
	{	
		$snm2bas2[] = $rsn['score'];
	    $stin2bas2[] = $rsn['student_name'];
	}
	$acbass = array_combine($stin2bas2,$snm2bas2);
	$resultmxbystunamebas3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Basic Science' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebas3))
	{	
		$snm2bas3[] = $rsn['score'];
		$stin2bas3[] = $rsn['student_name'];
	}
	$acbast = array_combine($stin2bas3,$snm2bas3);
	$arinall = array($acbasf, $acbass, $acbast);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acbaskeys = (array_keys($largest_arr));
$forbas1 = 	array($snm2bas1[0], $snm2bas1[1], $snm2bas1[2], $snm2bas1[3], $snm2bas1[4], $snm2bas1[5], $snm2bas1[6], $snm2bas1[7], $snm2bas1[8], $snm2bas1[9], $snm2bas1[10], $snm2bas1[11], $snm2bas1[12], $snm2bas1[13], $snm2bas1[14], $snm2bas1[15], $snm2bas1[16], $snm2bas1[17], $snm2bas1[18], $snm2bas1[19], 
		  $snm2bas1[20], $snm2bas1[21], $snm2bas1[22], $snm2bas1[23], $snm2bas1[24], $snm2bas1[25], $snm2bas1[26], $snm2bas1[27], $snm2bas1[28], $snm2bas1[29], $snm2bas1[30], $snm2bas1[31], $snm2bas1[32], $snm2bas1[33], $snm2bas1[34], $snm2bas1[35], $snm2bas1[36], $snm2bas1[37], $snm2bas1[38], $snm2bas1[39], 
		  $snm2bas1[40], $snm2bas1[41], $snm2bas1[42], $snm2bas1[43], $snm2bas1[44], $snm2bas1[45], $snm2bas1[46], $snm2bas1[47], $snm2bas1[48], $snm2bas1[49], $snm2bas1[50], $snm2bas1[51], $snm2bas1[52], $snm2bas1[53], $snm2bas1[54], $snm2bas1[55], $snm2bas1[56], $snm2bas1[57], $snm2bas1[58], $snm2bas1[59], 
		  $snm2bas1[60], $snm2bas1[61], $snm2bas1[62], $snm2bas1[63], $snm2bas1[64], $snm2bas1[65], $snm2bas1[66], $snm2bas1[67], $snm2bas1[68], $snm2bas1[69], $snm2bas1[70], $snm2bas1[71], $snm2bas1[72], $snm2bas1[73], $snm2bas1[74], $snm2bas1[75], $snm2bas1[76], $snm2bas1[77], $snm2bas1[78], $snm2bas1[79], 
		  $snm2bas1[80], $snm2bas1[81], $snm2bas1[82], $snm2bas1[83], $snm2bas1[84], $snm2bas1[85], $snm2bas1[86], $snm2bas1[87], $snm2bas1[88], $snm2bas1[89], $snm2bas1[90], $snm2bas1[91], $snm2bas1[92], $snm2bas1[93], $snm2bas1[94], $snm2bas1[95], $snm2bas1[96], $snm2bas1[97], $snm2bas1[98], $snm2bas1[99], 
		  $snm2bas1[100], $snm2bas1[101], $snm2bas1[102], $snm2bas1[103], $snm2bas1[104], $snm2bas1[105], $snm2bas1[106], $snm2bas1[107], $snm2bas1[108], $snm2bas1[109], $snm2bas1[110], $snm2bas1[111], $snm2bas1[112], $snm2bas1[113], $snm2bas1[114], $snm2bas1[115], $snm2bas1[116], $snm2bas1[117], $snm2bas1[118], $snm2bas1[119], 
		  $snm2bas1[120]);
$foragr2 = 	array($snm2bas2[0], $snm2bas2[1], $snm2bas2[2], $snm2bas2[3], $snm2bas2[4], $snm2bas2[5], $snm2bas2[6], $snm2bas2[7], $snm2bas2[8], $snm2bas2[9], $snm2bas2[10], $snm2bas2[11], $snm2bas1[12], $snm2bas2[13], $snm2bas2[14], $snm2bas2[15], $snm2bas2[16], $snm2bas2[17], $snm2bas2[18], $snm2bas2[19], 
		  $snm2bas2[20], $snm2bas2[21], $snm2bas2[22], $snm2bas2[23], $snm2bas2[24], $snm2bas2[25], $snm2bas2[26], $snm2bas2[27], $snm2bas2[28], $snm2bas2[29], $snm2bas2[30], $snm2bas2[31], $snm2bas2[32], $snm2bas2[33], $snm2bas2[34], $snm2bas2[35], $snm2bas2[36], $snm2bas2[37], $snm2bas2[38], $snm2bas2[39], 
		  $snm2bas2[40], $snm2bas2[41], $snm2bas2[42], $snm2bas2[43], $snm2bas2[44], $snm2bas2[45], $snm2bas2[46], $snm2bas2[47], $snm2bas2[48], $snm2bas2[49], $snm2bas2[50], $snm2bas2[51], $snm2bas2[52], $snm2bas2[53], $snm2bas2[54], $snm2bas2[55], $snm2bas2[56], $snm2bas2[57], $snm2bas2[58], $snm2bas2[59], 
		  $snm2bas2[60], $snm2bas2[61], $snm2bas2[62], $snm2bas2[63], $snm2bas2[64], $snm2bas2[65], $snm2bas2[66], $snm2bas2[67], $snm2bas2[68], $snm2bas2[69], $snm2bas2[70], $snm2bas2[71], $snm2bas2[72], $snm2bas2[73], $snm2bas2[74], $snm2bas2[75], $snm2bas2[76], $snm2bas2[77], $snm2bas2[78], $snm2bas2[79], 
		  $snm2bas2[80], $snm2bas2[81], $snm2bas2[82], $snm2bas2[83], $snm2bas2[84], $snm2bas2[85], $snm2bas2[86], $snm2bas2[87], $snm2bas2[88], $snm2bas2[89], $snm2bas2[90], $snm2bas2[91], $snm2bas2[92], $snm2bas2[93], $snm2bas2[94], $snm2bas2[95], $snm2bas2[96], $snm2bas2[97], $snm2bas2[98], $snm2bas2[99], 
		  $snm2bas2[100], $snm2bas2[101], $snm2bas2[102], $snm2bas2[103], $snm2bas2[104], $snm2bas2[105], $snm2bas2[106], $snm2bas2[107], $snm2bas2[108], $snm2bas2[109], $snm2bas2[110], $snm2bas2[111], $snm2bas2[112], $snm2bas2[113], $snm2bas2[114], $snm2bas2[115], $snm2bas2[116], $snm2bas2[117], $snm2bas2[118], $snm2bas2[119], 
		  $snm2bas2[120]);
$foragr3 = 	array($snm2bas3[0], $snm2bas3[1], $snm2bas3[2], $snm2bas3[3], $snm2bas3[4], $snm2bas3[5], $snm2bas3[6], $snm2bas3[7], $snm2bas3[8], $snm2bas3[9], $snm2bas3[10], $snm2bas3[11], $snm2bas3[12], $snm2bas3[13], $snm2bas3[14], $snm2bas3[15], $snm2bas3[16], $snm2bas3[17], $snm2bas3[18], $snm2bas3[19],
		  $snm2bas3[20], $snm2bas3[21], $snm2bas3[22], $snm2bas3[23], $snm2bas3[24], $snm2bas3[25], $snm2bas3[26], $snm2bas3[27], $snm2bas3[28], $snm2bas3[29], $snm2bas3[30], $snm2bas3[31], $snm2bas3[32], $snm2bas3[33], $snm2bas3[34], $snm2bas3[35], $snm2bas3[36], $snm2bas3[37], $snm2bas3[38], $snm2bas3[39], 
		  $snm2bas3[40], $snm2bas3[41], $snm2bas3[42], $snm2bas3[43], $snm2bas3[44], $snm2bas3[45], $snm2bas3[46], $snm2bas3[47], $snm2bas3[48], $snm2bas3[49], $snm2bas3[50], $snm2bas3[51], $snm2bas3[52], $snm2bas3[53], $snm2bas3[54], $snm2bas3[55], $snm2bas3[56], $snm2bas3[57], $snm2bas3[58], $snm2bas3[69], 
		  $snm2bas3[60], $snm2bas3[61], $snm2bas3[62], $snm2bas3[63], $snm2bas3[64], $snm2bas3[65], $snm2bas3[66], $snm2bas3[67], $snm2bas3[68], $snm2bas3[69], $snm2bas3[70], $snm2bas3[71], $snm2bas3[72], $snm2bas3[73], $snm2bas3[74], $snm2bas3[75], $snm2bas3[76], $snm2bas3[77], $snm2bas3[78], $snm2bas3[79], 
		  $snm2bas3[80], $snm2bas3[81], $snm2bas3[82], $snm2bas3[83], $snm2bas3[84], $snm2bas3[85], $snm2bas3[86], $snm2bas3[87], $snm2bas3[88], $snm2bas3[89], $snm2bas3[90], $snm2bas3[91], $snm2bas3[92], $snm2bas3[93], $snm2bas3[94], $snm2bas3[95], $snm2bas3[96], $snm2bas3[97], $snm2bas3[98], $snm2bas3[99], 
		  $snm2bas3[100], $snm2bas3[101], $snm2bas3[102], $snm2bas3[103], $snm2bas3[104], $snm2bas3[105], $snm2bas3[106], $snm2bas3[107], $snm2bas3[108], $snm2bas3[109], $snm2bas3[110], $snm2bas3[111], $snm2bas3[112], $snm2bas3[113], $snm2bas3[114], $snm2bas3[115], $snm2bas3[116], $snm2bas3[117], $snm2bas3[118], $snm2bas3[119], 
		  $snm2bas3[120]);	  
	$array_all_bas = array(array_filter($forbas1), array_filter($forbas2), array_filter($forbas3));
	$countingbas = 0;
	while($countingbas <= 120){
	if(count(array_column($array_all_bas, $countingbas)) == 3){
	$basf2[] = round(array_sum(array_column($array_all_bas, $countingbas))/3);
	}
	else if(count(array_column($array_all_bas, $countingbas)) == 2){
	$basf2[] = round(array_sum(array_column($array_all_bas, $countingbas))/2);
	}
	else if(count(array_column($array_all_bas, $countingbas)) == 1){
	$basf2[] = round(array_sum(array_column($array_all_bas, $countingbas))/1);
	}
	else{
	$basf2[] = round(array_sum(array_column($array_all_bas, $countingbas))/3);	
	}
	$countingbas++;
	}
	$basf = implode("-",array_filter($basf2));
	$basmx2 = explode("-",$basf);
	$basmx = max(explode("-",$basf));
	$stnameandscoreBas = array_combine($acbaskeys,$basmx2);
	$maxinallsub = $basmx;	
	}
		else if($su == 'Biology'){
		$resultmxbystunamebio1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Biology' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebio1))
	{	
		$snm2bio1[] = $rsn['score'];
		$stin2bio[] = $rsn['student_name'];
	}
	$acbiof = array_combine($stin2bio,$snm2bio1);
	$resultmxbystunamebio2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Biology' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebio2))
	{	
		$snm2bio2[] = $rsn['score'];
	    $stin2bio2[] = $rsn['student_name'];
	}
	$acbios = array_combine($stin2bio2,$snm2bio2);
	$resultmxbystunamebio3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Biology' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebio3))
	{	
		$snm2bio3[] = $rsn['score'];
		$stin2bio3[] = $rsn['student_name'];
	}
	$acbiot = array_combine($stin2bio3,$snm2bio3);
	$arinall = array($acbiof, $acbios, $acbiot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acbiokeys = (array_keys($largest_arr));
$forbio1 = 	array($snm2bio1[0], $snm2bio1[1], $snm2bio1[2], $snm2bio1[3], $snm2bio1[4], $snm2bio1[5], $snm2bio1[6], $snm2bio1[7], $snm2bio1[8], $snm2bio1[9], $snm2bio1[10], $snm2bio1[11], $snm2bio1[12], $snm2bio1[13], $snm2bio1[14], $snm2bio1[15], $snm2bio1[16], $snm2bio1[17], $snm2bio1[18], $snm2bio1[19], 
		$snm2bio1[20], $snm2bio1[21], $snm2bio1[22], $snm2bio1[23], $snm2bio1[24], $snm2bio1[25], $snm2bio1[26], $snm2bio1[27], $snm2bio1[28], $snm2bio1[29], $snm2bio1[30], $snm2bio1[31], $snm2bio1[32], $snm2bio1[33], $snm2bio1[34], $snm2bio1[35], $snm2bio1[36], $snm2bio1[37], $snm2bio1[38], $snm2bio1[39], 
		$snm2bio1[40], $snm2bio1[41], $snm2bio1[42], $snm2bio1[43], $snm2bio1[44], $snm2bio1[45], $snm2bio1[46], $snm2bio1[47], $snm2bio1[48], $snm2bio1[49], $snm2bio1[50], $snm2bio1[51], $snm2bio1[52], $snm2bio1[53], $snm2bio1[54], $snm2bio1[55], $snm2bio1[56], $snm2bio1[57], $snm2bio1[58], $snm2bio1[59], 
		$snm2bio1[60], $snm2bio1[61], $snm2bio1[62], $snm2bio1[63], $snm2bio1[64], $snm2bio1[65], $snm2bio1[66], $snm2bio1[67], $snm2bio1[68], $snm2bio1[69], $snm2bio1[70], $snm2bio1[71], $snm2bio1[72], $snm2bio1[73], $snm2bio1[74], $snm2bio1[75], $snm2bio1[76], $snm2bio1[77], $snm2bio1[78], $snm2bio1[79], 
		$snm2bio1[80], $snm2bio1[81], $snm2bio1[82], $snm2bio1[83], $snm2bio1[84], $snm2bio1[85], $snm2bio1[86], $snm2bio1[87], $snm2bio1[88], $snm2bio1[89], $snm2bio1[90], $snm2bio1[91], $snm2bio1[92], $snm2bio1[93], $snm2bio1[94], $snm2bio1[95], $snm2bio1[96], $snm2bio1[97], $snm2bio1[98], $snm2bio1[99], 
		$snm2bio1[100], $snm2bio1[101], $snm2bio1[102], $snm2bio1[103], $snm2bio1[104], $snm2bio1[105], $snm2bio1[106], $snm2bio1[107], $snm2bio1[108], $snm2bio1[109], $snm2bio1[110], $snm2bio1[111], $snm2bio1[112], $snm2bio1[113], $snm2bio1[114], $snm2bio1[115], $snm2bio1[116], $snm2bio1[117], $snm2bio1[118], $snm2bio1[119], 
		$snm2bio1[120]);
$forbio2 = 	array($snm2bio2[0], $snm2bio2[1], $snm2bio2[2], $snm2bio2[3], $snm2bio2[4], $snm2bio2[5], $snm2bio2[6], $snm2bio2[7], $snm2bio2[8], $snm2bio2[9], $snm2bio2[10], $snm2bio2[11], $snm2bio2[12], $snm2bio2[13], $snm2bio2[14], $snm2bio2[15], $snm2bio2[16], $snm2bio2[17], $snm2bio2[18], $snm2bio2[19], 
		$snm2bio2[20], $snm2bio2[21], $snm2bio2[22], $snm2bio2[23], $snm2bio2[24], $snm2bio2[25], $snm2bio2[26], $snm2bio2[27], $snm2bio2[28], $snm2bio2[29], $snm2bio2[30], $snm2bio2[31], $snm2bio2[32], $snm2bio2[33], $snm2bio2[34], $snm2bio2[35], $snm2bio2[36], $snm2bio2[37], $snm2bio2[38], $snm2bio2[39], 
		$snm2bio2[40], $snm2bio2[41], $snm2bio2[42], $snm2bio2[43], $snm2bio2[44], $snm2bio2[45], $snm2bio2[46], $snm2bio2[47], $snm2bio2[48], $snm2bio2[49], $snm2bio2[50], $snm2bio2[51], $snm2bio2[52], $snm2bio2[53], $snm2bio2[54], $snm2bio2[55], $snm2bio2[56], $snm2bio2[57], $snm2bio2[58], $snm2bio2[59], 
		$snm2bio2[60], $snm2bio2[61], $snm2bio2[62], $snm2bio2[63], $snm2bio2[64], $snm2bio2[65], $snm2bio2[66], $snm2bio2[67], $snm2bio2[68], $snm2bio2[69], $snm2bio2[70], $snm2bio2[71], $snm2bio2[72], $snm2bio2[73], $snm2bio2[74], $snm2bio2[75], $snm2bio2[76], $snm2bio2[77], $snm2bio2[78], $snm2bio2[79], 
		$snm2bio2[80], $snm2bio2[81], $snm2bio2[82], $snm2bio2[83], $snm2bio2[84], $snm2bio2[85], $snm2bio2[86], $snm2bio2[87], $snm2bio2[88], $snm2bio2[89], $snm2bio2[90], $snm2bio2[91], $snm2bio2[92], $snm2bio2[93], $snm2bio2[94], $snm2bio2[95], $snm2bio2[96], $snm2bio2[97], $snm2bio2[98], $snm2bio2[99], 
		$snm2bio2[100], $snm2bio2[101], $snm2bio2[102], $snm2bio2[103], $snm2bio2[104], $snm2bio2[105], $snm2bio2[106], $snm2bio2[107], $snm2bio2[108], $snm2bio2[109], $snm2bio2[110], $snm2bio2[111], $snm2bio2[112], $snm2bio2[113], $snm2bio2[114], $snm2bio2[115], $snm2bio2[116], $snm2bio2[117], $snm2bio2[118], $snm2bio2[119], 
		$snm2bio2[120]);
$forbio3 = 	array($snm2bio3[0], $snm2bio3[1], $snm2bio3[2], $snm2bio3[3], $snm2bio3[4], $snm2bio3[5], $snm2bio3[6], $snm2bio3[7], $snm2bio3[8], $snm2bio3[9], $snm2bio3[10], $snm2bio3[11], $snm2bio3[12], $snm2bio3[13], $snm2bio3[14], $snm2bio3[15], $snm2bio3[16], $snm2bio3[17], $snm2bio3[18], $snm2bio3[19], 
		$snm2bio3[20], $snm2bio3[21], $snm2bio3[22], $snm2bio3[23], $snm2bio3[24], $snm2bio3[25], $snm2bio3[26], $snm2bio3[27], $snm2bio3[28], $snm2bio3[29], $snm2bio3[30], $snm2bio3[31], $snm2bio3[32], $snm2bio3[33], $snm2bio3[34], $snm2bio3[35], $snm2bio3[36], $snm2bio3[37], $snm2bio3[38], $snm2bio3[39], 
		$snm2bio3[40], $snm2bio3[41], $snm2bio3[42], $snm2bio3[43], $snm2bio3[44], $snm2bio3[45], $snm2bio3[46], $snm2bio3[47], $snm2bio3[48], $snm2bio3[49], $snm2bio3[50], $snm2bio3[51], $snm2bio3[52], $snm2bio3[53], $snm2bio3[54], $snm2bio3[55], $snm2bio3[56], $snm2bio3[57], $snm2bio3[58], $snm2bio3[59], 
		$snm2bio3[60], $snm2bio3[61], $snm2bio3[62], $snm2bio3[63], $snm2bio3[64], $snm2bio3[65], $snm2bio3[66], $snm2bio3[67], $snm2bio3[68], $snm2bio3[69], $snm2bio3[70], $snm2bio3[71], $snm2bio3[72], $snm2bio3[73], $snm2bio3[74], $snm2bio3[75], $snm2bio3[76], $snm2bio3[77], $snm2bio3[78], $snm2bio3[79], 
		$snm2bio3[80], $snm2bio3[81], $snm2bio3[82], $snm2bio3[83], $snm2bio3[84], $snm2bio3[85], $snm2bio3[86], $snm2bio3[87], $snm2bio3[88], $snm2bio3[89], $snm2bio3[90], $snm2bio3[91], $snm2bio3[92], $snm2bio3[93], $snm2bio3[94], $snm2bio3[95], $snm2bio3[96], $snm2bio3[97], $snm2bio3[98], $snm2bio3[99], 
		$snm2bio3[100], $snm2bio3[101], $snm2bio3[102], $snm2bio3[103], $snm2bio3[104], $snm2bio3[105], $snm2bio3[106], $snm2bio3[107], $snm2bio3[108], $snm2bio3[109], $snm2bio3[110], $snm2bio3[111], $snm2bio3[112], $snm2bio3[113], $snm2bio3[114], $snm2bio3[115], $snm2bio3[116], $snm2bio3[117], $snm2bio3[118], $snm2bio3[119], 
		$snm2bio3[120]);
	}
	else if($su == 'Business Studies'){
		$resultmxbystunamebus1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Business Studies' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebus1))
	{	
		$snm2bus1[] = $rsn['score'];
		$stin2bus[] = $rsn['student_name'];
	}
	$acbusf = array_combine($stin2bus,$snm2bus1);
	$resultmxbystunamebus2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Business Studies' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebus2))
	{	
		$snm2bus2[] = $rsn['score'];
	    $stin2bus2[] = $rsn['student_name'];
	}
	$acbuss = array_combine($stin2bus2,$snm2bus2);
	$resultmxbystunamebus3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Business Studies' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebus3))
	{	
		$snm2bus3[] = $rsn['score'];
		$stin2bus3[] = $rsn['student_name'];
	}
	$acbust = array_combine($stin2bus3,$snm2bus3);
	$arinall = array($acbusf, $acbuss, $acbust);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acbuskeys = (array_keys($largest_arr));
$forbus1 = 	array($snm2bus1[0], $snm2bus1[1], $snm2bus1[2], $snm2bus1[3], $snm2bus1[4], $snm2bus1[5], $snm2bus1[6], $snm2bus1[7], $snm2bus1[8], $snm2bus1[9], $snm2bus1[10], $snm2bus1[11], $snm2bus1[12], $snm2bus1[13], $snm2bus1[14], $snm2bus1[15], $snm2bus1[16], $snm2bus1[17], $snm2bus1[18], $snm2bus1[19], 
		$snm2bus1[20], $snm2bus1[21], $snm2bus1[22], $snm2bus1[23], $snm2bus1[24], $snm2bus1[25], $snm2bus1[26], $snm2bus1[27], $snm2bus1[28], $snm2bus1[29], $snm2bus1[30], $snm2bus1[31], $snm2bus1[32], $snm2bus1[33], $snm2bus1[34], $snm2bus1[35], $snm2bus1[36], $snm2bus1[37], $snm2bus1[38], $snm2bus1[39], 
		$snm2bus1[40], $snm2bus1[41], $snm2bus1[42], $snm2bus1[43], $snm2bus1[44], $snm2bus1[45], $snm2bus1[46], $snm2bus1[47], $snm2bus1[48], $snm2bus1[49], $snm2bus1[50], $snm2bus1[51], $snm2bus1[52], $snm2bus1[53], $snm2bus1[54], $snm2bus1[55], $snm2bus1[56], $snm2bus1[57], $snm2bus1[58], $snm2bus1[59], 
		$snm2bus1[60], $snm2bio1[61], $snm2bus1[62], $snm2bus1[63], $snm2bus1[64], $snm2bus1[65], $snm2bus1[66], $snm2bus1[67], $snm2bus1[68], $snm2bus1[69], $snm2bus1[70], $snm2bus1[71], $snm2bus1[72], $snm2bus1[73], $snm2bus1[74], $snm2bus1[75], $snm2bus1[76], $snm2bus1[77], $snm2bus1[78], $snm2bus1[79], 
		$snm2bus1[80], $snm2bus1[81], $snm2bus1[82], $snm2bus1[83], $snm2bus1[84], $snm2bus1[85], $snm2bus1[86], $snm2bus1[87], $snm2bus1[88], $snm2bus1[89], $snm2bus1[90], $snm2bus1[91], $snm2bus1[92], $snm2bus1[93], $snm2bus1[94], $snm2bus1[95], $snm2bus1[96], $snm2bus1[97], $snm2bus1[98], $snm2bus1[99], 
		$snm2bus1[100], $snm2bus1[101], $snm2bus1[102], $snm2bus1[103], $snm2bus1[104], $snm2bus1[105], $snm2bus1[106], $snm2bus1[107], $snm2bus1[108], $snm2bus1[109], $snm2bus1[110], $snm2bus1[111], $snm2bus1[112], $snm2bus1[113], $snm2bus1[114], $snm2bus1[115], $snm2bus1[116], $snm2bus1[117], $snm2bus1[118], $snm2bus1[119], 
		$snm2bus1[120]);
$forbus2 = 	array($snm2bus2[0], $snm2bus2[1], $snm2bus2[2], $snm2bus2[3], $snm2bus2[4], $snm2bus2[5], $snm2bus2[6], $snm2bus2[7], $snm2bus2[8], $snm2bus2[9], $snm2bus2[10], $snm2bus2[11], $snm2bus2[12], $snm2bus2[13], $snm2bus2[14], $snm2bus2[15], $snm2bus2[16], $snm2bus2[17], $snm2bus2[18], $snm2bus2[19], 
		$snm2bus2[20], $snm2bus2[21], $snm2bus2[22], $snm2bus2[23], $snm2bus2[24], $snm2bus2[25], $snm2bus2[26], $snm2bus2[27], $snm2bus2[28], $snm2bus2[29], $snm2bus2[30], $snm2bus2[31], $snm2bus2[32], $snm2bus2[33], $snm2bus2[34], $snm2bus2[35], $snm2bus2[36], $snm2bus2[37], $snm2bus2[38], $snm2bus2[39], 
		$snm2bus2[40], $snm2bus2[41], $snm2bus2[42], $snm2bus2[43], $snm2bus2[44], $snm2bus2[45], $snm2bus2[46], $snm2bus2[47], $snm2bus2[48], $snm2bus2[49], $snm2bus2[50], $snm2bus2[51], $snm2bus2[52], $snm2bus2[53], $snm2bus2[54], $snm2bus2[55], $snm2bus2[56], $snm2bus2[57], $snm2bus2[58], $snm2bus2[59], 
		$snm2bus2[60], $snm2bus2[61], $snm2bus2[62], $snm2bus2[63], $snm2bus2[64], $snm2bus2[65], $snm2bus2[66], $snm2bus2[67], $snm2bus2[68], $snm2bus2[69], $snm2bus2[70], $snm2bus2[71], $snm2bus2[72], $snm2bus2[73], $snm2bus2[74], $snm2bus2[75], $snm2bus2[76], $snm2bus2[77], $snm2bus2[78], $snm2bus2[79], 
		$snm2bus2[80], $snm2bus2[81], $snm2bus2[82], $snm2bus2[83], $snm2bus2[84], $snm2bus2[85], $snm2bus2[86], $snm2bus2[87], $snm2bus2[88], $snm2bus2[89], $snm2bus2[90], $snm2bus2[91], $snm2bus2[92], $snm2bus2[93], $snm2bus2[94], $snm2bus2[95], $snm2bus2[96], $snm2bus2[97], $snm2bus2[98], $snm2bus2[99], 
		$snm2bus2[100], $snm2bus2[101], $snm2bus2[102], $snm2bus2[103], $snm2bus2[104], $snm2bus2[105], $snm2bus2[106], $snm2bus2[107], $snm2bus2[108], $snm2bus2[109], $snm2bus2[110], $snm2bus2[111], $snm2bus2[112], $snm2bus2[113], $snm2bus2[114], $snm2bus2[115], $snm2bus2[116], $snm2bus2[117], $snm2bus2[118], $snm2bus2[119], 
		$snm2bus2[120]);
$forbus3 = 	array($snm2bus3[0], $snm2bus3[1], $snm2bus3[2], $snm2bus3[3], $snm2bus3[4], $snm2bus3[5], $snm2bus3[6], $snm2bus3[7], $snm2bus3[8], $snm2bus3[9], $snm2bus3[10], $snm2bus3[11], $snm2bus3[12], $snm2bus3[13], $snm2bus3[14], $snm2bus3[15], $snm2bus3[16], $snm2bus3[17], $snm2bus3[18], $snm2bus3[19], 
		$snm2bus3[20], $snm2bus3[21], $snm2bus3[22], $snm2bus3[23], $snm2bus3[24], $snm2bus3[25], $snm2bus3[26], $snm2bus3[27], $snm2bus3[28], $snm2bus3[29], $snm2bus3[30], $snm2bus3[31], $snm2bus3[32], $snm2bus3[33], $snm2bus3[34], $snm2bus3[35], $snm2bus3[36], $snm2bus3[37], $snm2bus3[38], $snm2bus3[39], 
		$snm2bus3[40], $snm2bus3[41], $snm2bus3[42], $snm2bus3[43], $snm2bus3[44], $snm2bus3[45], $snm2bus3[46], $snm2bus3[47], $snm2bus3[48], $snm2bus3[49], $snm2bus3[50], $snm2bus3[51], $snm2bus3[52], $snm2bus3[53], $snm2bus3[54], $snm2bus3[55], $snm2bus3[56], $snm2bus3[57], $snm2bus3[58], $snm2bus3[59], 
		$snm2bus3[60], $snm2bus3[61], $snm2bus3[62], $snm2bus3[63], $snm2bus3[64], $snm2bus3[65], $snm2bus3[66], $snm2bus3[67], $snm2bus3[68], $snm2bus3[69], $snm2bus3[70], $snm2bus3[71], $snm2bus3[72], $snm2bus3[73], $snm2bus3[74], $snm2bus3[75], $snm2bus3[76], $snm2bus3[77], $snm2bus3[78], $snm2bus3[79], 
		$snm2bus3[80], $snm2bus3[81], $snm2bus3[82], $snm2bus3[83], $snm2bus3[84], $snm2bus3[85], $snm2bus3[86], $snm2bus3[87], $snm2bus3[88], $snm2bus3[89], $snm2bus3[90], $snm2bus3[91], $snm2bus3[92], $snm2bus3[93], $snm2bus3[94], $snm2bus3[95], $snm2bus3[96], $snm2bus3[97], $snm2bus3[98], $snm2bus3[99], 
		$snm2bus3[100], $snm2bus3[101], $snm2bus3[102], $snm2bus3[103], $snm2bus3[104], $snm2bus3[105], $snm2bus3[106], $snm2bus3[107], $snm2bus3[108], $snm2bus3[109], $snm2bus3[110], $snm2bus3[111], $snm2bus3[112], $snm2bus3[113], $snm2bus3[114], $snm2bus3[115], $snm2bus3[116], $snm2bus3[117], $snm2bus3[118], $snm2bus3[119], 
		$snm2bus3[120]);
	$array_all_bus = array(array_filter($forbus1), array_filter($forbus2), array_filter($forbus3));
	$countingbus = 0;
	while($countingbus <= 120){
	if(count(array_column($array_all_bus, $countingbus)) == 3){
	$busf2[] = round(array_sum(array_column($array_all_bus, $countingbus))/3);
	}
	else if(count(array_column($array_all_bus, $countingbus)) == 2){
	$busf2[] = round(array_sum(array_column($array_all_bus, $countingbus))/2);
	}
	else if(count(array_column($array_all_bus, $countingbus)) == 1){
	$busf2[] = round(array_sum(array_column($array_all_bus, $countingbus))/1);
	}
	else{
	$busf2[] = round(array_sum(array_column($array_all_bus, $countingbus))/3);	
	}
	$countingbus++;
	}
	$busf = implode("-",array_filter($busf2));
	$busmx2 = explode("-",$busf);
	$busmx = max(explode("-",$busf));
	$stnameandscoreBus = array_combine($acbuskeys,$busmx2);
	$maxinallsub = $busmx;			
	}
	else if($su == 'Catering'){
		$resultmxbystunamecat1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Catering' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecat1))
	{	
		$snm2cat1[] = $rsn['score'];
		$stin2cat[] = $rsn['student_name'];
	}
	$accatf = array_combine($stin2cat,$snm2cat1);
	$resultmxbystunamecat2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Catering' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecat2))
	{	
		$snm2cat2[] = $rsn['score'];
	    $stin2cat2[] = $rsn['student_name'];
	}
	$accats = array_combine($stin2cat2,$snm2cat2);
	$resultmxbystunamecat3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Catering' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecat3))
	{	
		$snm2cat3[] = $rsn['score'];
		$stin2cat3[] = $rsn['student_name'];
	}
	$accatt = array_combine($stin2cat3,$snm2cat3);
	$arinall = array($accatf, $accats, $accatt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$accatkeys = (array_keys($largest_arr));
	
$forcat1 = array();
for($v=0; $v<=120; $v++){
$forccat1[] = $snm2cat1[$v];
}
$forcat1 = $forccat1;

$forcat2 = array();
for($v=0; $v<=120; $v++){
$forccat2[] = $snm2cat2[$v];
}
$forcat2 = $forccat2;

$forcat3 = array();
for($v=0; $v<=120; $v++){
$forccat3[] = $snm2cat3[$v];
}
$forcat3 = $forccat3;

	$array_all_cat = array(array_filter($forcat1), array_filter($forcat2), array_filter($forcat3));
	$countingcat = 0;
	while($countingcat <= 120){
	if(count(array_column($array_all_cat, $countingcat)) == 3){
	$catf2[] = round(array_sum(array_column($array_all_cat, $countingcat))/3);
	}
	else if(count(array_column($array_all_cat, $countingcat)) == 2){
	$catf2[] = round(array_sum(array_column($array_all_cat, $countingcat))/2);
	}
	else if(count(array_column($array_all_cat, $countingcat)) == 1){
	$catf2[] = round(array_sum(array_column($array_all_cat, $countingcat))/1);
	}
	else{
	$catf2[] = round(array_sum(array_column($array_all_cat, $countingcat))/3);	
	}
	$countingcat++;
	}
	$catf = implode("-",array_filter($catf2));
	$catmx2 = explode("-",$catf);
	$catmx = max(explode("-",$catf));
	$stnameandscoreCat = array_combine($accatkeys,$catmx2);
	$maxinallsub = $catmx;			
	}
	else if($su == 'Chemistry'){
		$resultmxbystunameche1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Chemistry' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameche1))
	{	
		$snm2che1[] = $rsn['score'];
		$stin2che[] = $rsn['student_name'];
	}
	$acchef = array_combine($stin2che,$snm2che1);
	$resultmxbystunameche2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Chemistry' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameche2))
	{	
		$snm2che2[] = $rsn['score'];
	    $stin2che2[] = $rsn['student_name'];
	}
	$acches = array_combine($stin2che2,$snm2che2);
	$resultmxbystunameche3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Chemistry' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameche3))
	{	
		$snm2che3[] = $rsn['score'];
		$stin2che3[] = $rsn['student_name'];
	}
	$acchet = array_combine($stin2che3,$snm2che3);
	$arinall = array($acchef, $acches, $acchet);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acchekeys = (array_keys($largest_arr));
	
$forche1 = array();
for($v=0; $v<=120; $v++){
$forcche1[] = $snm2che1[$v];
}
$forche1 = $forcche1;

$forche2 = array();
for($v=0; $v<=120; $v++){
$forcche2[] = $snm2che2[$v];
}
$forche2 = $forcche2;

$forche3 = array();
for($v=0; $v<=120; $v++){
$forcche3[] = $snm2che3[$v];
}
$forche3 = $forcche3;

	$array_all_che = array(array_filter($forche1), array_filter($forche2), array_filter($forche3));
	$countingche = 0;
	while($countingche <= 120){
	if(count(array_column($array_all_che, $countingche)) == 3){
	$chef2[] = round(array_sum(array_column($array_all_che, $countingche))/3);
	}
	else if(count(array_column($array_all_che, $countingche)) == 2){
	$chef2[] = round(array_sum(array_column($array_all_che, $countingche))/2);
	}
	else if(count(array_column($array_all_che, $countingche)) == 1){
	$chef2[] = round(array_sum(array_column($array_all_che, $countingche))/1);
	}
	else{
	$chef2[] = round(array_sum(array_column($array_all_che, $countingche))/3);	
	}
	$countingche++;
	}
	$chef = implode("-",array_filter($chef2));
	$chemx2 = explode("-",$chef);
	$chemx = max(explode("-",$chef));
	$stnameandscoreChe = array_combine($acchekeys,$chemx2);
	$maxinallsub = $chemx;			
	}
	else if($su == 'Civic Education'){
		$resultmxbystunameciv1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Civic Education' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameciv1))
	{	
		$snm2civ1[] = $rsn['score'];
		$stin2civ[] = $rsn['student_name'];
	}
	$accivf = array_combine($stin2civ,$snm2civ1);
	$resultmxbystunameciv2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Civic Education' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameciv2))
	{	
		$snm2civ2[] = $rsn['score'];
	    $stin2civ2[] = $rsn['student_name'];
	}
	$accivs = array_combine($stin2civ2,$snm2civ2);
	$resultmxbystunameciv3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Civic Education' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameciv3))
	{	
		$snm2civ3[] = $rsn['score'];
		$stin2civ3[] = $rsn['student_name'];
	}
	$accivt = array_combine($stin2civ3,$snm2civ3);
	$arinall = array($accivf, $accivs, $accivt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$accivkeys = (array_keys($largest_arr));
	
$forciv1 = array();
for($v=0; $v<=120; $v++){
$forcciv1[] = $snm2civ1[$v];
}
$forciv1 = $forcciv1;

$forciv2 = array();
for($v=0; $v<=120; $v++){
$forcciv2[] = $snm2civ2[$v];
}
$forciv2 = $forcciv2;

$forciv3 = array();
for($v=0; $v<=120; $v++){
$forcciv3[] = $snm2civ3[$v];
}
$forciv3 = $forcciv3;

	$array_all_civ = array(array_filter($forciv1), array_filter($forciv2), array_filter($forciv3));
	$countingciv = 0;
	while($countingciv <= 120){
	if(count(array_column($array_all_civ, $countingciv)) == 3){
	$civf2[] = round(array_sum(array_column($array_all_civ, $countingciv))/3);
	}
	else if(count(array_column($array_all_civ, $countingciv)) == 2){
	$civf2[] = round(array_sum(array_column($array_all_civ, $countingciv))/2);
	}
	else if(count(array_column($array_all_civ, $countingciv)) == 1){
	$civf2[] = round(array_sum(array_column($array_all_civ, $countingciv))/1);
	}
	else{
	$civf2[] = round(array_sum(array_column($array_all_civ, $countingciv))/3);	
	}
	$countingciv++;
	}
	$civf = implode("-",array_filter($civf2));
	$civmx2 = explode("-",$civf);
	$civmx = max(explode("-",$civf));
	$stnameandscoreCiv = array_combine($accivkeys,$civmx2);
	$maxinallsub = $civmx;			
	}
	
	else if($su == 'Creative and Cultural Arts'){
		$resultmxbystunamecca1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Creative and Cultural Arts' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecca1))
	{	
		$snm2cca1[] = $rsn['score'];
		$stin2cca[] = $rsn['student_name'];
	}
	$acccaf = array_combine($stin2cca,$snm2cca1);
	$resultmxbystunamecca2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Creative and Cultural Arts' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecca2))
	{	
		$snm2cca2[] = $rsn['score'];
	    $stin2cca2[] = $rsn['student_name'];
	}
	$acccas = array_combine($stin2cca2,$snm2cca2);
	$resultmxbystunamecca3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Creative and Cultural Arts Studies' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecca3))
	{	
		$snm2cca3[] = $rsn['score'];
		$stin2cca3[] = $rsn['student_name'];
	}
	$acccat = array_combine($stin2cca3,$snm2cca3);
	$arinall = array($acccaf, $acccas, $acccat);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acccakeys = (array_keys($largest_arr));
	
$forcca1 = array();
$forcca2 = array();
$forcca3 = array();
for($v=0; $v<=120; $v++){
$forccca1[] = $snm2cca1[$v];
$forccca2[] = $snm2cca2[$v];
$forccca3[] = $snm2cca3[$v];
}
$forcca1 = $forccca1;
$forcca2 = $forccca2;
$forcca3 = $forccca3;

	$array_all_cca = array(array_filter($forcca1), array_filter($forcca2), array_filter($forcca3));
	$countingcca = 0;
	while($countingcca <= 120){
	if(count(array_column($array_all_cca, $countingcca)) == 3){
	$ccaf2[] = round(array_sum(array_column($array_all_cca, $countingcca))/3);
	}
	else if(count(array_column($array_all_cca, $countingcca)) == 2){
	$ccaf2[] = round(array_sum(array_column($array_all_cca, $countingcca))/2);
	}
	else if(count(array_column($array_all_cca, $countingcca)) == 1){
	$ccaf2[] = round(array_sum(array_column($array_all_cca, $countingcca))/1);
	}
	else{
	$ccaf2[] = round(array_sum(array_column($array_all_cca, $countingcca))/3);	
	}
	$countingcca++;
	}
	$ccaf = implode("-",array_filter($ccaf2));
	$ccamx2 = explode("-",$ccaf);
	$ccamx = max(explode("-",$ccaf));
	$stnameandscoreCca = array_combine($acccakeys,$ccamx2);
	$maxinallsub = $ccamx;			
	}
	
		else if($su == 'CRK'){
		$resultmxbystunamecrk1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='CRK' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecrk1))
	{	
		$snm2crk1[] = $rsn['score'];
		$stin2crk[] = $rsn['student_name'];
	}
	$accrkf = array_combine($stin2crk,$snm2crk1);
	$resultmxbystunamecrk2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='CRK' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecrk2))
	{	
		$snm2crk2[] = $rsn['score'];
	    $stin2crk2[] = $rsn['student_name'];
	}
	$accrks = array_combine($stin2crk2,$snm2crk2);
	$resultmxbystunamecrk3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='CRK' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecRK3))
	{	
		$snm2crk3[] = $rsn['score'];
		$stin2crk3[] = $rsn['student_name'];
	}
	$accrkt = array_combine($stin2crk3,$snm2crk3);
	$arinall = array($accrkf, $accrks, $accrkt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$accrkkeys = (array_keys($largest_arr));
	
$forcrk1 = array();
for($v=0; $v<=120; $v++){
$forccrk1[] = $snm2crk1[$v];
}
$forcrk1 = $forccrk1;

$forcrk2 = array();
for($v=0; $v<=120; $v++){
$forccrk2[] = $snm2crk2[$v];
}
$forcrk2 = $forccrk2;

$forcrk3 = array();
for($v=0; $v<=120; $v++){
$forccrk3[] = $snm2crk3[$v];
}
$forcrk3 = $forccrk3;

	$array_all_crk = array(array_filter($forcrk1), array_filter($forcrk2), array_filter($forcrk3));
	$countingcrk = 0;
	while($countingcrk <= 120){
	if(count(array_column($array_all_crk, $countingcrk)) == 3){
	$crkf2[] = round(array_sum(array_column($array_all_crk, $countingcrk))/3);
	}
	else if(count(array_column($array_all_crk, $countingcrk)) == 2){
	$crkf2[] = round(array_sum(array_column($array_all_crk, $countingcrk))/2);
	}
	else if(count(array_column($array_all_crk, $countingcrk)) == 1){
	$crkf2[] = round(array_sum(array_column($array_all_crk, $countingcrk))/1);
	}
	else{
	$crkf2[] = round(array_sum(array_column($array_all_crk, $countingcrk))/3);	
	}
	$countingcrk++;
	}
	$crkf = implode("-",array_filter($crkf2));
	$crkmx2 = explode("-",$crkf);
	$crkmx = max(explode("-",$crkf));
	$stnameandscoreCrk = array_combine($accrkkeys,$crkmx2);
	$maxinallsub = $crkmx;			
	}
	else if($su == 'Economics'){
		$resultmxbystunameeco1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Economics' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeco1))
	{	
		$snm2eco1[] = $rsn['score'];
		$stin2eco[] = $rsn['student_name'];
	}
	$acecof = array_combine($stin2eco,$snm2eco1);
	$resultmxbystunameeco2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Economics' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeco2))
	{	
		$snm2eco2[] = $rsn['score'];
	    $stin2eco2[] = $rsn['student_name'];
	}
	$acecos = array_combine($stin2eco2,$snm2eco2);
	$resultmxbystunameeco3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Economics' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeco3))
	{	
		$snm2eco3[] = $rsn['score'];
		$stin2eco3[] = $rsn['student_name'];
	}
	$acecot = array_combine($stin2eco3,$snm2eco3);
	$arinall = array($acecof, $acecos, $acecot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acecokeys = (array_keys($largest_arr));
	
$foreco1 = array();
$foreco2 = array();
$foreco3 = array();
for($v=0; $v<=120; $v++){
$foreeco1[] = $snm2eco1[$v];
$foreeco2[] = $snm2eco2[$v];
$foreeco3[] = $snm2eco3[$v];
}
$foreco1 = $foreeco1;
$foreco2 = $foreeco2;
$foreco3 = $foreeco3;

	$array_all_eco = array(array_filter($foreco1), array_filter($foreco2), array_filter($foreco3));
	$countingeco = 0;
	while($countingeco <= 120){
	if(count(array_column($array_all_eco, $countingeco)) == 3){
	$ecof2[] = round(array_sum(array_column($array_all_eco, $countingeco))/3);
	}
	else if(count(array_column($array_all_eco, $countingeco)) == 2){
	$ecof2[] = round(array_sum(array_column($array_all_eco, $countingeco))/2);
	}
	else if(count(array_column($array_all_eco, $countingeco)) == 1){
	$ecof2[] = round(array_sum(array_column($array_all_eco, $countingeco))/1);
	}
	else{
	$ecof2[] = round(array_sum(array_column($array_all_eco, $countingeco))/3);	
	}
	$countingeco++;
	}
	$ecof = implode("-",array_filter($ecof2));
	$ecomx2 = explode("-",$ecof);
	$ecomx = max(explode("-",$ecof));
	$stnameandscoreEco = array_combine($acecokeys,$ecomx2);
	$maxinallsub = $ecomx;			
	}
	else if($su == 'Financial Accounting'){
		$resultmxbystunamefin1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Financial Accounting' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefin1))
	{	
		$snm2fin1[] = $rsn['score'];
		$stin2fin[] = $rsn['student_name'];
	}
	$acfinf = array_combine($stin2fin,$snm2fin1);
	$resultmxbystunamefin2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Financial Accounting' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefin2))
	{	
		$snm2fin2[] = $rsn['score'];
	    $stin2fin2[] = $rsn['student_name'];
	}
	$acfins = array_combine($stin2fin2,$snm2fin2);
	$resultmxbystunamefin3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Financial Accounting' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefin3))
	{	
		$snm2fin3[] = $rsn['score'];
		$stin2fin3[] = $rsn['student_name'];
	}
	$acfint = array_combine($stin2fin3,$snm2fin3);
	$arinall = array($acfinf, $acfins, $acfint);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acfinkeys = (array_keys($largest_arr));
	
$forfin1 = array();
$forfin2 = array();
$forfin3 = array();
for($v=0; $v<=120; $v++){
$forffin1[] = $snm2fin1[$v];
$forffin2[] = $snm2fin2[$v];
$forffin3[] = $snm2fin3[$v];
}
$forfin1 = $forffin1;
$forfin2 = $forffin2;
$forfin3 = $forffin3;

	$array_all_fin = array(array_filter($forfin1), array_filter($forfin2), array_filter($forfin3));
	$countingfin = 0;
	while($countingfin <= 120){
	if(count(array_column($array_all_fin, $countingfin)) == 3){
	$finf2[] = round(array_sum(array_column($array_all_fin, $countingfin))/3);
	}
	else if(count(array_column($array_all_fin, $countingfin)) == 2){
	$finf2[] = round(array_sum(array_column($array_all_fin, $countingfin))/2);
	}
	else if(count(array_column($array_all_fin, $countingfin)) == 1){
	$finf2[] = round(array_sum(array_column($array_all_fin, $countingfin))/1);
	}
	else{
	$finf2[] = round(array_sum(array_column($array_all_fin, $countingfin))/3);	
	}
	$countingfin++;
	}
	$finf = implode("-",array_filter($finf2));
	$finmx2 = explode("-",$finf);
	$finmx = max(explode("-",$finf));
	$stnameandscoreFin = array_combine($acfinkeys,$finmx2);
	$maxinallsub = $finmx;			
	}
		else if($su == 'Food and Nutrition'){
		$resultmxbystunamefoo1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Food and Nutrition' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefoo1))
	{	
		$snm2foo1[] = $rsn['score'];
		$stin2foo[] = $rsn['student_name'];
	}
	$acfoof = array_combine($stin2foo,$snm2foo1);
	$resultmxbystunamefoo2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Food and Nutrition' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefoo2))
	{	
		$snm2foo2[] = $rsn['score'];
	    $stin2foo2[] = $rsn['student_name'];
	}
	$acfoos = array_combine($stin2foo2,$snm2foo2);
	$resultmxbystunamefoo3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Food and Nutrition' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefoo3))
	{	
		$snm2foo3[] = $rsn['score'];
		$stin2foo3[] = $rsn['student_name'];
	}
	$acfoot = array_combine($stin2foo3,$snm2foo3);
	$arinall = array($acfoof, $acfoos, $acfoot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acfookeys = (array_keys($largest_arr));
	
$forfoo1 = array();
$forfoo2 = array();
$forfoo3 = array();
for($v=0; $v<=120; $v++){
$forffoo1[] = $snm2foo1[$v];
$forffoo2[] = $snm2foo2[$v];
$forffoo3[] = $snm2foo3[$v];
}
$forfoo1 = $forffoo1;
$forfoo2 = $forffoo2;
$forfoo3 = $forffoo3;

	$array_all_foo = array(array_filter($forfoo1), array_filter($forfoo2), array_filter($forfoo3));
	$countingfoo = 0;
	while($countingfoo <= 120){
	if(count(array_column($array_all_foo, $countingfoo)) == 3){
	$foof2[] = round(array_sum(array_column($array_all_foo, $countingfoo))/3);
	}
	else if(count(array_column($array_all_foo, $countingfoo)) == 2){
	$foof2[] = round(array_sum(array_column($array_all_foo, $countingfoo))/2);
	}
	else if(count(array_column($array_all_foo, $countingfoo)) == 1){
	$foof2[] = round(array_sum(array_column($array_all_foo, $countingfoo))/1);
	}
	else{
	$foof2[] = round(array_sum(array_column($array_all_foo, $countingfoo))/3);	
	}
	$countingfoo++;
	}
	$foof = implode("-",array_filter($foof2));
	$foomx2 = explode("-",$foof);
	$foomx = max(explode("-",$foof));
	$stnameandscoreFoo = array_combine($acfookeys,$foomx2);
	$maxinallsub = $foomx;			
	}
		else if($su == 'Music'){
		$resultmxbystunamemus1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Music' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemus1))
	{	
		$snm2mus1[] = $rsn['score'];
		$stin2mus[] = $rsn['student_name'];
	}
	$acmusf = array_combine($stin2mus,$snm2mus1);
	$resultmxbystunamemus2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Music' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemus2))
	{	
		$snm2mus2[] = $rsn['score'];
	    $stin2mus2[] = $rsn['student_name'];
	}
	$acmuss = array_combine($stin2mus2,$snm2mus2);
	$resultmxbystunamemus3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Music' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemus3))
	{	
		$snm2mus3[] = $rsn['score'];
		$stin2mus3[] = $rsn['student_name'];
	}
	$acmust = array_combine($stin2mus3,$snm2mus3);
	$arinall = array($acmusf, $acmuss, $acmust);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acmuskeys = (array_keys($largest_arr));
	
$formus1 = array();
$formus2 = array();
$formus3 = array();
for($v=0; $v<=120; $v++){
$formmus1[] = $snm2mus1[$v];
$formmus2[] = $snm2mus2[$v];
$formmus3[] = $snm2mus3[$v];
}
$formus1 = $formmus1;
$formus2 = $formmus2;
$formus3 = $formmus3;

	$array_all_mus = array(array_filter($formus1), array_filter($formus2), array_filter($formus3));
	$countingmus = 0;
	while($countingmus <= 120){
	if(count(array_column($array_all_mus, $countingmus)) == 3){
	$musf2[] = round(array_sum(array_column($array_all_mus, $countingmus))/3);
	}
	else if(count(array_column($array_all_mus, $countingmus)) == 2){
	$musf2[] = round(array_sum(array_column($array_all_mus, $countingmus))/2);
	}
	else if(count(array_column($array_all_mus, $countingmus)) == 1){
	$musf2[] = round(array_sum(array_column($array_all_mus, $countingmus))/1);
	}
	else{
	$musf2[] = round(array_sum(array_column($array_all_mus, $countingmus))/3);	
	}
	$countingmus++;
	}
	$musf = implode("-",array_filter($musf2));
	$musmx2 = explode("-",$musf);
	$musmx = max(explode("-",$musf));
	$stnameandscoreMus = array_combine($acmuskeys,$musmx2);
	$maxinallsub = $musmx;			
	}
	else if($su == 'Government'){
		$resultmxbystunamegov1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Government' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegov1))
	{	
		$snm2gov1[] = $rsn['score'];
		$stin2gov[] = $rsn['student_name'];
	}
	$acgovf = array_combine($stin2gov,$snm2gov1);
	$resultmxbystunamegov2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Government' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegov2))
	{	
		$snm2gov2[] = $rsn['score'];
	    $stin2gov2[] = $rsn['student_name'];
	}
	$acgovs = array_combine($stin2gov2,$snm2gov2);
	$resultmxbystunamegov3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Government' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegov3))
	{	
		$snm2gov3[] = $rsn['score'];
		$stin2gov3[] = $rsn['student_name'];
	}
	$acgovt = array_combine($stin2gov3,$snm2gov3);
	$arinall = array($acgovf, $acgovs, $acgovt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acgovkeys = (array_keys($largest_arr));
	
$forgov1 = array();
$forgov2 = array();
$forgov3 = array();
for($v=0; $v<=120; $v++){
$forggov1[] = $snm2gov1[$v];
$forggov2[] = $snm2gov2[$v];
$forggov3[] = $snm2gov3[$v];
}
$forgov1 = $forggov1;
$forgov2 = $forggov2;
$forgov3 = $forggov3;

	$array_all_gov = array(array_filter($forgov1), array_filter($forgov2), array_filter($forgov3));
	$countinggov = 0;
	while($countinggov <= 120){
	if(count(array_column($array_all_gov, $countinggov)) == 3){
	$govf2[] = round(array_sum(array_column($array_all_gov, $countinggov))/3);
	}
	else if(count(array_column($array_all_gov, $countinggov)) == 2){
	$govf2[] = round(array_sum(array_column($array_all_gov, $countinggov))/2);
	}
	else if(count(array_column($array_all_gov, $countinggov)) == 1){
	$govf2[] = round(array_sum(array_column($array_all_gov, $countinggov))/1);
	}
	else{
	$govf2[] = round(array_sum(array_column($array_all_gov, $countinggov))/3);	
	}
	$countinggov++;
	}
	$govf = implode("-",array_filter($govf2));
	$govmx2 = explode("-",$govf);
	$govmx = max(explode("-",$govf));
	$stnameandscoreGov = array_combine($acgovkeys,$govmx2);
	$maxinallsub = $govmx;			
	}
	else if($su == 'Hausa'){
		$resultmxbystunamehau1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Hausa' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehau1))
	{	
		$snm2hau1[] = $rsn['score'];
		$stin2hau[] = $rsn['student_name'];
	}
	$achauf = array_combine($stin2hau,$snm2hau1);
	$resultmxbystunamehau2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Hausa' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehau2))
	{	
		$snm2hau2[] = $rsn['score'];
	    $stin2hau2[] = $rsn['student_name'];
	}
	$achaus = array_combine($stin2hau2,$snm2hau2);
	$resultmxbystunamehau3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Hausa' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehau3))
	{	
		$snm2hau3[] = $rsn['score'];
		$stin2hau3[] = $rsn['student_name'];
	}
	$achaut = array_combine($stin2hau3,$snm2hau3);
	$arinall = array($achauf, $achaus, $achaut);
	//print_r($arinall);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$achaukeys = (array_keys($largest_arr));
	
$forhau1 = array();
$forhau2 = array();
$forhau3 = array();
for($v=0; $v<=120; $v++){
$forhhau1[] = $snm2hau1[$v];
$forhhau2[] = $snm2hau2[$v];
$forhhau3[] = $snm2hau3[$v];
}
$forhau1 = $forhhau1;
$forhau2 = $forhhau2;
$forhau3 = $forhhau3;
//print_r($array_all_irs);

	$array_all_hau = array(array_filter($forhau1), array_filter($forhau2), array_filter($forhau3));
	$countinghau = 0;
	while($countinghau <= 120){
	if(count(array_column($array_all_hau, $countinghau)) == 3){
	$hauf2[] = round(array_sum(array_column($array_all_hau, $countinghau))/3);
	}
	else if(count(array_column($array_all_hau, $countinghau)) == 2){
	$hauf2[] = round(array_sum(array_column($array_all_hau, $countinghau))/2);
	}
	else if(count(array_column($array_all_hau, $countinghau)) == 1){
	$hauf2[] = round(array_sum(array_column($array_all_hau, $countinghau))/1);
	}
	else{
	$hauf2[] = round(array_sum(array_column($array_all_hau, $countinghau))/3);	
	}
	$countinghau++;
	}
	$hauf = implode("-",array_filter($hauf2));
	$haumx2 = explode("-",$hauf);
	$haumx = max(explode("-",$hauf));
	$stnameandscoreHau = array_combine($achaukeys,$haumx2);
	$maxinallsub = $haumx;			
	}
	else if($su == 'History'){
		$resultmxbystunamehis1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='History' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehis1))
	{	
		$snm2his1[] = $rsn['score'];
		$stin2his[] = $rsn['student_name'];
	}
	$achisf = array_combine($stin2his,$snm2his1);
	$resultmxbystunamehis2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='History' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehis2))
	{	
		$snm2his2[] = $rsn['score'];
	    $stin2his2[] = $rsn['student_name'];
	}
	$achiss = array_combine($stin2his2,$snm2his2);
	$resultmxbystunamehis3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='History' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehis3))
	{	
		$snm2his3[] = $rsn['score'];
		$stin2his3[] = $rsn['student_name'];
	}
	$achist = array_combine($stin2his3,$snm2his3);
	$arinall = array($achisf, $achiss, $achist);
	//print_r($arinall);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$achiskeys = (array_keys($largest_arr));
	
$forhis1 = array();
$forhis2 = array();
$forhis3 = array();
for($v=0; $v<=120; $v++){
$forhhis1[] = $snm2his1[$v];
$forhhis2[] = $snm2his2[$v];
$forhhis3[] = $snm2his3[$v];
}
$forhis1 = $forhhis1;
$forhis2 = $forhhis2;
$forhis3 = $forhhis3;
//print_r($array_all_irs);

	$array_all_his = array(array_filter($forhis1), array_filter($forhis2), array_filter($forhis3));
	$countinghis = 0;
	while($countinghis <= 120){
	if(count(array_column($array_all_his, $countinghis)) == 3){
	$hisf2[] = round(array_sum(array_column($array_all_his, $countinghis))/3);
	}
	else if(count(array_column($array_all_his, $countinghis)) == 2){
	$hisf2[] = round(array_sum(array_column($array_all_his, $countinghis))/2);
	}
	else if(count(array_column($array_all_his, $countinghis)) == 1){
	$hisf2[] = round(array_sum(array_column($array_all_his, $countinghis))/1);
	}
	else{
	$hisf2[] = round(array_sum(array_column($array_all_his, $countinghis))/3);	
	}
	$countinghis++;
	}
	$hisf = implode("-",array_filter($hisf2));
	$hismx2 = explode("-",$hisf);
	$hismx = max(explode("-",$hisf));
	$stnameandscoreHis = array_combine($achiskeys,$hismx2);
	$maxinallsub = $hismx;			
	}
		else if($su == 'ICT'){
		$resultmxbystunameict1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='ICT' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameict1))
	{	
		$snm2ict1[] = $rsn['score'];
		$stin2ict[] = $rsn['student_name'];
	}
	$acictf = array_combine($stin2ict,$snm2ict1);
	$resultmxbystunameict2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='ICT' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameict2))
	{	
		$snm2ict2[] = $rsn['score'];
	    $stin2ict2[] = $rsn['student_name'];
	}
	$acicts = array_combine($stin2ict2,$snm2ict2);
	$resultmxbystunameict3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='ICT' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameict3))
	{	
		$snm2ict3[] = $rsn['score'];
		$stin2ict3[] = $rsn['student_name'];
	}
	$acictt = array_combine($stin2ict3,$snm2ict3);
	$arinall = array($acictf, $acicts, $acictt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acictkeys = (array_keys($largest_arr));
	
$forict1 = array();
$forict2 = array();
$forict3 = array();
for($v=0; $v<=120; $v++){
$foriict1[] = $snm2ict1[$v];
$foriict2[] = $snm2ict2[$v];
$foriict3[] = $snm2ict3[$v];
}
$forict1 = $foriict1;
$forict2 = $foriict2;
$forict3 = $foriict3;

	$array_all_ict = array(array_filter($forict1), array_filter($forict2), array_filter($forict3));
	$countingict = 0;
	while($countingict <= 120){
	if(count(array_column($array_all_ict, $countingict)) == 3){
	$ictf2[] = round(array_sum(array_column($array_all_ict, $countingict))/3);
	}
	else if(count(array_column($array_all_ict, $countingict)) == 2){
	$ictf2[] = round(array_sum(array_column($array_all_ict, $countingict))/2);
	}
	else if(count(array_column($array_all_ict, $countingict)) == 1){
	$ictf2[] = round(array_sum(array_column($array_all_ict, $countingict))/1);
	}
	else{
	$ictf2[] = round(array_sum(array_column($array_all_ict, $countingict))/3);	
	}
	$countingict++;
	}
	$ictf = implode("-",array_filter($ictf2));
	$ictmx2 = explode("-",$ictf);
	$ictmx = max(explode("-",$ictf));
	$stnameandscoreIct = array_combine($acictkeys,$ictmx2);
	$maxinallsub = $ictmx;			
	}
	else if($su == 'Igbo'){
		$resultmxbystunameigb1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Igbo' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameigb1))
	{	
		$snm2igb1[] = $rsn['score'];
		$stin2igb[] = $rsn['student_name'];
	}
	$acigbf = array_combine($stin2igb,$snm2igb1);
	$resultmxbystunameigb2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Igbo' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameigb2))
	{	
		$snm2igb2[] = $rsn['score'];
	    $stin2igb2[] = $rsn['student_name'];
	}
	$acigbs = array_combine($stin2igb2,$snm2igb2);
	$resultmxbystunameigb3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Igbo' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameigb3))
	{	
		$snm2igb3[] = $rsn['score'];
		$stin2igb3[] = $rsn['student_name'];
	}
	$acigbt = array_combine($stin2igb3,$snm2igb3);
	$arinall = array($acigbf, $acigbs, $acigbt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acigbkeys = (array_keys($largest_arr));
	
$forigb1 = array();
$forigb2 = array();
$forigb3 = array();
for($v=0; $v<=120; $v++){
$foriigb1[] = $snm2igb1[$v];
$foriigb2[] = $snm2igb2[$v];
$foriigb3[] = $snm2igb3[$v];
}
$forigb1 = $foriigb1;
$forigb2 = $foriigb2;
$forigb3 = $foriigb3;

	$array_all_igb = array(array_filter($forigb1), array_filter($forigb2), array_filter($forigb3));
	$countingigb = 0;
	while($countingigb <= 120){
	if(count(array_column($array_all_igb, $countingigb)) == 3){
	$igbf2[] = round(array_sum(array_column($array_all_igb, $countingigb))/3);
	}
	else if(count(array_column($array_all_igb, $countingigb)) == 2){
	$igbf2[] = round(array_sum(array_column($array_all_igb, $countingigb))/2);
	}
	else if(count(array_column($array_all_igb, $countingigb)) == 1){
	$igbf2[] = round(array_sum(array_column($array_all_igb, $countingigb))/1);
	}
	else{
	$igbf2[] = round(array_sum(array_column($array_all_igb, $countingigb))/3);	
	}
	$countingigb++;
	}
	$igbf = implode("-",array_filter($igbf2));
	$igbmx2 = explode("-",$igbf);
	$igbmx = max(explode("-",$igbf));
	$stnameandscoreIgb = array_combine($acigbkeys,$igbmx2);
	$maxinallsub = $igbmx;			
	}
	
	else if($su == 'Islamic Religious Studies'){
		$resultmxbystunameirs1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Islamic Religious Studies' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameirs1))
	{	
		$snm2irs1[] = $rsn['score'];
		$stin2irs[] = $rsn['student_name'];
	}
	$acirsf = array_combine($stin2irs,$snm2irs1);
	$resultmxbystunameirs2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Islamic Religious Studies' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameirs2))
	{	
		$snm2irs2[] = $rsn['score'];
	    $stin2irs2[] = $rsn['student_name'];
	}
	$acirss = array_combine($stin2irs2,$snm2irs2);
	$resultmxbystunameirs3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Islamic Religious Studies' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameirs3))
	{	
		$snm2irs3[] = $rsn['score'];
		$stin2irs3[] = $rsn['student_name'];
	}
	$acirst = array_combine($stin2irs3,$snm2irs3);
	$arinall = array($acirsf, $acirss, $acirst);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acirskeys = (array_keys($largest_arr));
	
$forirs1 = array();
$forirs2 = array();
$forirs3 = array();
for($v=0; $v<=120; $v++){
$foriirs1[] = $snm2irs1[$v];
$foriirs2[] = $snm2irs2[$v];
$foriirs3[] = $snm2irs3[$v];
}
$forirs1 = $foriirs1;
$forirs2 = $foriirs2;
$forirs3 = $foriirs3;

	$array_all_irs = array(array_filter($forirs1), array_filter($forirs2), array_filter($forirs3));
	$countingirs = 0;
	while($countingirs <= 120){
	if(count(array_column($array_all_irs, $countingirs)) == 3){
	$irsf2[] = round(array_sum(array_column($array_all_irs, $countingirs))/3);
	}
	else if(count(array_column($array_all_irs, $countingirs)) == 2){
	$irsf2[] = round(array_sum(array_column($array_all_irs, $countingirs))/2);
	}
	else if(count(array_column($array_all_irs, $countingirs)) == 1){
	$irsf2[] = round(array_sum(array_column($array_all_irs, $countingirs))/1);
	}
	else{
	$irsf2[] = round(array_sum(array_column($array_all_irs, $countingirs))/3);	
	}
	$countingirs++;
	}
	$irsf = implode("-",array_filter($irsf2));
	$irsmx2 = explode("-",$irsf);
	$irsmx = max(explode("-",$irsf));
	$stnameandscoreIrs = array_combine($acirskeys,$irsmx2);
	$maxinallsub = $irsmx;			
	}
	
	else if($su == 'Literature in English'){
		$resultmxbystunamelit1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Literature in English' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamelit1))
	{	
		$snm2lit1[] = $rsn['score'];
		$stin2lit[] = $rsn['student_name'];
	}
	$aclitf = array_combine($stin2lit,$snm2lit1);
	$resultmxbystunamelit2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Literature in English' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamelit2))
	{	
		$snm2lit2[] = $rsn['score'];
	    $stin2lit2[] = $rsn['student_name'];
	}
	$aclits = array_combine($stin2lit2,$snm2lit2);
	$resultmxbystunamelit3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Literature in English' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamelit3))
	{	
		$snm2lit3[] = $rsn['score'];
		$stin2lit3[] = $rsn['student_name'];
	}
	$aclitt = array_combine($stin2lit3,$snm2lit3);
	$arinall = array($aclitf, $aclits, $aclitt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$aclitkeys = (array_keys($largest_arr));
	
$forlit1 = array();
$forlit2 = array();
$forlit3 = array();
for($v=0; $v<=120; $v++){
$forllit1[] = $snm2lit1[$v];
$forllit2[] = $snm2lit2[$v];
$forllit3[] = $snm2lit3[$v];
}
$forlit1 = $forllit1;
$forlit2 = $forllit2;
$forlit3 = $forllit3;

	$array_all_lit = array(array_filter($forlit1), array_filter($forlit2), array_filter($forlit3));
	$countinglit = 0;
	while($countinglit <= 120){
	if(count(array_column($array_all_lit, $countinglit)) == 3){
	$litf2[] = round(array_sum(array_column($array_all_lit, $countinglit))/3);
	}
	else if(count(array_column($array_all_lit, $countinglit)) == 2){
	$litf2[] = round(array_sum(array_column($array_all_lit, $countinglit))/2);
	}
	else if(count(array_column($array_all_lit, $countinglit)) == 1){
	$litf2[] = round(array_sum(array_column($array_all_lit, $countinglit))/1);
	}
	else{
	$litf2[] = round(array_sum(array_column($array_all_lit, $countinglit))/3);	
	}
	$countinglit++;
	}
	$litf = implode("-",array_filter($litf2));
	$litmx2 = explode("-",$litf);
	$litmx = max(explode("-",$litf));
	$stnameandscoreLit = array_combine($aclitkeys,$litmx2);
	$maxinallsub = $litmx;			
	}
		else if($su == 'Marketing'){
		$resultmxbystunamemar1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Marketing' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemar1))
	{	
		$snm2mar1[] = $rsn['score'];
		$stin2mar[] = $rsn['student_name'];
	}
	$acmarf = array_combine($stin2mar,$snm2mar1);
	$resultmxbystunamemar2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Marketing' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemar2))
	{	
		$snm2mar2[] = $rsn['score'];
	    $stin2mar2[] = $rsn['student_name'];
	}
	$acmars = array_combine($stin2mar2,$snm2mar2);
	$resultmxbystunamemar3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Marketing' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemar3))
	{	
		$snm2mar3[] = $rsn['score'];
		$stin2mar3[] = $rsn['student_name'];
	}
	$acmart = array_combine($stin2mar3,$snm2mar3);
	$arinall = array($acmarf, $acmars, $acmart);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acmarkeys = (array_keys($largest_arr));
	
$formar1 = array();
$formar2 = array();
$formar3 = array();
for($v=0; $v<=120; $v++){
$formmar1[] = $snm2mar1[$v];
$formmar2[] = $snm2mar2[$v];
$formmar3[] = $snm2mar3[$v];
}
$formar1 = $formmar1;
$formar2 = $formmar2;
$formar3 = $formmar3;

	$array_all_mar = array(array_filter($formar1), array_filter($formar2), array_filter($formar3));
	$countingmar = 0;
	while($countingmar <= 120){
	if(count(array_column($array_all_mar, $countingmar)) == 3){
	$marf2[] = round(array_sum(array_column($array_all_mar, $countingmar))/3);
	}
	else if(count(array_column($array_all_mar, $countingmar)) == 2){
	$marf2[] = round(array_sum(array_column($array_all_mar, $countingmar))/2);
	}
	else if(count(array_column($array_all_mar, $countingmar)) == 1){
	$marf2[] = round(array_sum(array_column($array_all_mar, $countingmar))/1);
	}
	else{
	$marf2[] = round(array_sum(array_column($array_all_mar, $countingmar))/3);	
	}
	$countingmar++;
	}
	$marf = implode("-",array_filter($marf2));
	$marmx2 = explode("-",$marf);
	$marmx = max(explode("-",$marf));
	$stnameandscoreMar = array_combine($acmarkeys,$marmx2);
	$maxinallsub = $marmx;			
	}
		else if($su == 'PHE'){
		$resultmxbystunamephe1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='PHE' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephe1))
	{	
		$snm2phe1[] = $rsn['score'];
		$stin2phe[] = $rsn['student_name'];
	}
	$acphef = array_combine($stin2phe,$snm2phe1);
	$resultmxbystunamephe2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='PHE' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephe2))
	{	
		$snm2phe2[] = $rsn['score'];
	    $stin2phe2[] = $rsn['student_name'];
	}
	$acphes = array_combine($stin2phe2,$snm2phe2);
	$resultmxbystunamephe3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='PHE' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephe3))
	{	
		$snm2phe3[] = $rsn['score'];
		$stin2phe3[] = $rsn['student_name'];
	}
	$acphet = array_combine($stin2phe3,$snm2phe3);
	$arinall = array($acphef, $acphes, $acphet);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acphekeys = (array_keys($largest_arr));
	
$forphe1 = array();
$forphe2 = array();
$forphe3 = array();
for($v=0; $v<=120; $v++){
$forpphe1[] = $snm2phe1[$v];
$forpphe2[] = $snm2phe2[$v];
$forpphe3[] = $snm2phe3[$v];
}
$forphe1 = $forpphe1;
$forphe2 = $forpphe2;
$forphe3 = $forpphe3;

	$array_all_phe = array(array_filter($forphe1), array_filter($forphe2), array_filter($forphe3));
	$countingphe = 0;
	while($countingphe <= 120){
	if(count(array_column($array_all_phe, $countingphe)) == 3){
	$phef2[] = round(array_sum(array_column($array_all_phe, $countingphe))/3);
	}
	else if(count(array_column($array_all_phe, $countingphe)) == 2){
	$phef2[] = round(array_sum(array_column($array_all_phe, $countingphe))/2);
	}
	else if(count(array_column($array_all_phe, $countingphe)) == 1){
	$phef2[] = round(array_sum(array_column($array_all_phe, $countingphe))/1);
	}
	else{
	$phef2[] = round(array_sum(array_column($array_all_phe, $countingphe))/3);	
	}
	$countingphe++;
	}
	$phef = implode("-",array_filter($phef2));
	$phemx2 = explode("-",$phef);
	$phemx = max(explode("-",$phef));
	$stnameandscorePhe = array_combine($acphekeys,$phemx2);
	$maxinallsub = $phemx;			
	}
	
	else if($su == 'Phonics'){
		$resultmxbystunamepho1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Phonics' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamepho1))
	{	
		$snm2pho1[] = $rsn['score'];
		$stin2pho[] = $rsn['student_name'];
	}
	$acphof = array_combine($stin2pho,$snm2pho1);
	$resultmxbystunamepho2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Phonics' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamepho2))
	{	
		$snm2pho2[] = $rsn['score'];
	    $stin2pho2[] = $rsn['student_name'];
	}
	$acphos = array_combine($stin2pho2,$snm2pho2);
	$resultmxbystunamepho3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Phonics' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamepho3))
	{	
		$snm2pho3[] = $rsn['score'];
		$stin2pho3[] = $rsn['student_name'];
	}
	$acphot = array_combine($stin2pho3,$snm2pho3);
	$arinall = array($acphof, $acphos, $acphot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acphokeys = (array_keys($largest_arr));
	
$forpho1 = array();
$forpho2 = array();
$forpho3 = array();
for($v=0; $v<=120; $v++){
$forppho1[] = $snm2pho1[$v];
$forppho2[] = $snm2pho2[$v];
$forppho3[] = $snm2pho3[$v];
}
$forpho1 = $forppho1;
$forpho2 = $forppho2;
$forpho3 = $forppho3;

	$array_all_pho = array(array_filter($forpho1), array_filter($forpho2), array_filter($forpho3));
	$countingpho = 0;
	while($countingpho <= 120){
	if(count(array_column($array_all_pho, $countingpho)) == 3){
	$phof2[] = round(array_sum(array_column($array_all_pho, $countingpho))/3);
	}
	else if(count(array_column($array_all_pho, $countingpho)) == 2){
	$phof2[] = round(array_sum(array_column($array_all_pho, $countingpho))/2);
	}
	else if(count(array_column($array_all_pho, $countingpho)) == 1){
	$phof2[] = round(array_sum(array_column($array_all_pho, $countingpho))/1);
	}
	else{
	$phof2[] = round(array_sum(array_column($array_all_pho, $countingpho))/3);	
	}
	$countingpho++;
	}
	$phof = implode("-",array_filter($phof2));
	$phomx2 = explode("-",$phof);
	$phomx = max(explode("-",$phof));
	$stnameandscorePho = array_combine($acphokeys,$phomx2);
	$maxinallsub = $phomx;			
	}
	
	else if($su == 'Physics'){
		$resultmxbystunamephy1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Physics' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephy1))
	{	
		$snm2phy1[] = $rsn['score'];
		$stin2phy[] = $rsn['student_name'];
	}
	$acphyf = array_combine($stin2phy,$snm2phy1);
	$resultmxbystunamephy2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Physics' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephy2))
	{	
		$snm2phy2[] = $rsn['score'];
	    $stin2phy2[] = $rsn['student_name'];
	}
	$acphys = array_combine($stin2phy2,$snm2phy2);
	$resultmxbystunamephy3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Physics' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephy3))
	{	
		$snm2phy3[] = $rsn['score'];
		$stin2phy3[] = $rsn['student_name'];
	}
	$acphyt = array_combine($stin2phy3,$snm2phy3);
	$arinall = array($acphyf, $acphys, $acphyt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acphykeys = (array_keys($largest_arr));
	
$forphy1 = array();
$forphy2 = array();
$forphy3 = array();
for($v=0; $v<=120; $v++){
$forpphy1[] = $snm2phy1[$v];
$forpphy2[] = $snm2phy2[$v];
$forpphy3[] = $snm2phy3[$v];
}
$forphy1 = $forpphy1;
$forphy2 = $forpphy2;
$forphy3 = $forpphy3;

	$array_all_phy = array(array_filter($forphy1), array_filter($forphy2), array_filter($forphy3));
	$countingphy = 0;
	while($countingphy <= 120){
	if(count(array_column($array_all_phy, $countingphy)) == 3){
	$phyf2[] = round(array_sum(array_column($array_all_phy, $countingphy))/3);
	}
	else if(count(array_column($array_all_phy, $countingphy)) == 2){
	$phyf2[] = round(array_sum(array_column($array_all_phy, $countingphy))/2);
	}
	else if(count(array_column($array_all_phy, $countingphy)) == 1){
	$phyf2[] = round(array_sum(array_column($array_all_phy, $countingphy))/1);
	}
	else{
	$phyf2[] = round(array_sum(array_column($array_all_phy, $countingphy))/3);	
	}
	$countingphy++;
	}
	$phyf = implode("-",array_filter($phyf2));
	$phymx2 = explode("-",$phyf);
	$phymx = max(explode("-",$phyf));
	$stnameandscorePhy = array_combine($acphykeys,$phymx2);
	$maxinallsub = $phymx;			
	}
	else if($su == 'Social Studies'){
		$resultmxbystunamesoc1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Social Studies' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesoc1))
	{	
		$snm2soc1[] = $rsn['score'];
		$stin2soc[] = $rsn['student_name'];
	}
	$acsocf = array_combine($stin2soc,$snm2soc1);
	$resultmxbystunamesoc2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Social Studies' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesoc2))
	{	
		$snm2soc2[] = $rsn['score'];
	    $stin2soc2[] = $rsn['student_name'];
	}
	$acsocs = array_combine($stin2soc2,$snm2soc2);
	$resultmxbystunamesoc3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Social Studies' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesoc3))
	{	
		$snm2soc3[] = $rsn['score'];
		$stin2soc3[] = $rsn['student_name'];
	}
	$acsoct = array_combine($stin2soc3,$snm2soc3);
	$arinall = array($acsocf, $acsocs, $acsoct);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acsockeys = (array_keys($largest_arr));
	
$forsoc1 = array();
$forsoc2 = array();
$forsoc3 = array();
for($v=0; $v<=120; $v++){
$forssoc1[] = $snm2soc1[$v];
$forssoc2[] = $snm2soc2[$v];
$forssoc3[] = $snm2soc3[$v];
}
$forsoc1 = $forssoc1;
$forsoc2 = $forssoc2;
$forsoc3 = $forssoc3;

	$array_all_soc = array(array_filter($forsoc1), array_filter($forsoc2), array_filter($forsoc3));
	$countingsoc = 0;
	while($countingsoc <= 120){
	if(count(array_column($array_all_soc, $countingsoc)) == 3){
	$socf2[] = round(array_sum(array_column($array_all_soc, $countingsoc))/3);
	}
	else if(count(array_column($array_all_soc, $countingsoc)) == 2){
	$socf2[] = round(array_sum(array_column($array_all_soc, $countingsoc))/2);
	}
	else if(count(array_column($array_all_soc, $countingsoc)) == 1){
	$socf2[] = round(array_sum(array_column($array_all_soc, $countingsoc))/1);
	}
	else{
	$socf2[] = round(array_sum(array_column($array_all_soc, $countingsoc))/3);	
	}
	$countingsoc++;
	}
	$socf = implode("-",array_filter($socf2));
	$socmx2 = explode("-",$socf);
	$socmx = max(explode("-",$socf));
	$stnameandscoreSoc = array_combine($acsockeys,$socmx2);
	$maxinallsub = $socmx;			
	}
		else if($su == 'Sociology'){
		$resultmxbystunamesocio1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Sociology' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesocio1))
	{	
		$snm2socio1[] = $rsn['score'];
		$stin2socio[] = $rsn['student_name'];
	}
	$acsociof = array_combine($stin2socio,$snm2socio1);
	$resultmxbystunamesocio2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Sociology' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesocio2))
	{	
		$snm2socio2[] = $rsn['score'];
	    $stin2socio2[] = $rsn['student_name'];
	}
	$acsocios = array_combine($stin2socio2,$snm2socio2);
	$resultmxbystunamesocio3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Sociology' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesocio3))
	{	
		$snm2socio3[] = $rsn['score'];
		$stin2socio3[] = $rsn['student_name'];
	}
	$acsociot = array_combine($stin2socio3,$snm2socio3);
	$arinall = array($acsociof, $acsocios, $acsociot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acsociokeys = (array_keys($largest_arr));
	
$forsocio1 = array();
$forsocio2 = array();
$forsocio3 = array();
for($v=0; $v<=120; $v++){
$forssocio1[] = $snm2socio1[$v];
$forssocio2[] = $snm2socio2[$v];
$forssocio3[] = $snm2socio3[$v];
}
$forsocio1 = $forssocio1;
$forsocio2 = $forssocio2;
$forsocio3 = $forssocio3;

	$array_all_socio = array(array_filter($forsocio1), array_filter($forsocio2), array_filter($forsocio3));
	$countingsocio = 0;
	while($countingsocio <= 120){
	if(count(array_column($array_all_socio, $countingsocio)) == 3){
	$sociof2[] = round(array_sum(array_column($array_all_socio, $countingsocio))/3);
	}
	else if(count(array_column($array_all_socio, $countingsocio)) == 2){
	$sociof2[] = round(array_sum(array_column($array_all_socio, $countingsocio))/2);
	}
	else if(count(array_column($array_all_socio, $countingsocio)) == 1){
	$sociof2[] = round(array_sum(array_column($array_all_socio, $countingsocio))/1);
	}
	else{
	$sociof2[] = round(array_sum(array_column($array_all_socio, $countingsocio))/3);	
	}
	$countingsocio++;
	}
	$sociof = implode("-",array_filter($sociof2));
	$sociomx2 = explode("-",$sociof);
	$sociomx = max(explode("-",$sociof));
	$stnameandscoreSocio = array_combine($acsociokeys,$sociomx2);
	$maxinallsub = $sociomx;			
	}
	else if($su == 'TD'){
		$resultmxbystunametd1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='TD' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunametd1))
	{	
		$snm2td1[] = $rsn['score'];
		$stin2td[] = $rsn['student_name'];
	}
	$actdf = array_combine($stin2td,$snm2td1);
	$resultmxbystunametd2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='TD' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunametd2))
	{	
		$snm2td2[] = $rsn['score'];
	    $stin2td2[] = $rsn['student_name'];
	}
	$actds = array_combine($stin2td2,$snm2td2);
	$resultmxbystunametd3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='TD' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunametd3))
	{	
		$snm2td3[] = $rsn['score'];
		$stin2td3[] = $rsn['student_name'];
	}
	$actdt = array_combine($stin2td3,$snm2td3);
	$arinall = array($actdf, $actds, $actdt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$actdkeys = (array_keys($largest_arr));
	
$fortd1 = array();
$fortd2 = array();
$fortd3 = array();
for($v=0; $v<=120; $v++){
$forttd1[] = $snm2td1[$v];
$forttd2[] = $snm2td2[$v];
$forttd3[] = $snm2td3[$v];
}
$fortd1 = $forttd1;
$fortd2 = $forttd2;
$fortd3 = $forttd3;

	$array_all_td = array(array_filter($fortd1), array_filter($fortd2), array_filter($fortd3));
	$countingtd = 0;
	while($countingtd <= 120){
	if(count(array_column($array_all_td, $countingtd)) == 3){
	$tdf2[] = round(array_sum(array_column($array_all_td, $countingtd))/3);
	}
	else if(count(array_column($array_all_td, $countingtd)) == 2){
	$tdf2[] = round(array_sum(array_column($array_all_td, $countingtd))/2);
	}
	else if(count(array_column($array_all_td, $countingtd)) == 1){
	$tdf2[] = round(array_sum(array_column($array_all_td, $countingtd))/1);
	}
	else{
	$tdf2[] = round(array_sum(array_column($array_all_td, $countingtd))/3);	
	}
	$countingtd++;
	}
	$tdf = implode("-",array_filter($tdf2));
	$tdmx2 = explode("-",$tdf);
	$tdmx = max(explode("-",$tdf));
	$stnameandscoreTd = array_combine($actdkeys,$tdmx2);
	$maxinallsub = $tdmx;			
	}
	else if($su == 'VA'){
		$resultmxbystunameva1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='VA' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameva1))
	{	
		$snm2va1[] = $rsn['score'];
		$stin2va[] = $rsn['student_name'];
	}
	$acvaf = array_combine($stin2va,$snm2va1);
	$resultmxbystunameva2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='VA' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameva2))
	{	
		$snm2va2[] = $rsn['score'];
	    $stin2va2[] = $rsn['student_name'];
	}
	$acvas = array_combine($stin2va2,$snm2va2);
	$resultmxbystunameva3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='VA' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameva3))
	{	
		$snm2va3[] = $rsn['score'];
		$stin2va3[] = $rsn['student_name'];
	}
	$acvat = array_combine($stin2va3,$snm2va3);
	$arinall = array($acvaf, $acvas, $acvat);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acvakeys = (array_keys($largest_arr));
	
$forva1 = array();
$forva2 = array();
$forva3 = array();
for($v=0; $v<=120; $v++){
$forvva1[] = $snm2va1[$v];
$forvva2[] = $snm2va2[$v];
$forvva3[] = $snm2va3[$v];
}
$forva1 = $forvva1;
$forva2 = $forvva2;
$forva3 = $forvva3;

	$array_all_va = array(array_filter($forva1), array_filter($forva2), array_filter($forva3));
	$countingva = 0;
	while($countingva <= 120){
	if(count(array_column($array_all_va, $countingva)) == 3){
	$vaf2[] = round(array_sum(array_column($array_all_va, $countingva))/3);
	}
	else if(count(array_column($array_all_va, $countingva)) == 2){
	$vaf2[] = round(array_sum(array_column($array_all_va, $countingva))/2);
	}
	else if(count(array_column($array_all_va, $countingva)) == 1){
	$vaf2[] = round(array_sum(array_column($array_all_va, $countingva))/1);
	}
	else{
	$vaf2[] = round(array_sum(array_column($array_all_va, $countingva))/3);	
	}
	$countingva++;
	}
	$vaf = implode("-",array_filter($vaf2));
	$vamx2 = explode("-",$vaf);
	$vamx = max(explode("-",$vaf));
	$stnameandscoreVa = array_combine($acvakeys,$vamx2);
	$maxinallsub = $vamx;			
	}
	else if($su == 'Vocational Aptitude'){
		$resultmxbystunamevap1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Vocational Aptitude' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevap1))
	{	
		$snm2vap1[] = $rsn['score'];
		$stin2vap[] = $rsn['student_name'];
	}
	$acvapf = array_combine($stin2vap,$snm2vap1);
	$resultmxbystunamevap2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Vocational Aptitude' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevap2))
	{	
		$snm2vap2[] = $rsn['score'];
	    $stin2vap2[] = $rsn['student_name'];
	}
	$acvaps = array_combine($stin2vap2,$snm2vap2);
	$resultmxbystunamevap3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Vocational Aptitude' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevap3))
	{	
		$snm2vap3[] = $rsn['score'];
		$stin2vap3[] = $rsn['student_name'];
	}
	$acvapt = array_combine($stin2vap3,$snm2vap3);
	$arinall = array($acvapf, $acvaps, $acvapt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acvapkeys = (array_keys($largest_arr));
	
$forvap1 = array();
$forvap2 = array();
$forvap3 = array();
for($v=0; $v<=120; $v++){
$forvvap1[] = $snm2vap1[$v];
$forvvap2[] = $snm2vap2[$v];
$forvvap3[] = $snm2vap3[$v];
}
$forvap1 = $forvvap1;
$forvap2 = $forvvap2;
$forvap3 = $forvvap3;

	$array_all_vap = array(array_filter($forvap1), array_filter($forvap2), array_filter($forvap3));
	$countingvap = 0;
	while($countingvap <= 120){
	if(count(array_column($array_all_vap, $countingvap)) == 3){
	$vapf2[] = round(array_sum(array_column($array_all_vap, $countingvap))/3);
	}
	else if(count(array_column($array_all_vap, $countingvap)) == 2){
	$vapf2[] = round(array_sum(array_column($array_all_vap, $countingvap))/2);
	}
	else if(count(array_column($array_all_vap, $countingvap)) == 1){
	$vapf2[] = round(array_sum(array_column($array_all_vap, $countingvap))/1);
	}
	else{
	$vapf2[] = round(array_sum(array_column($array_all_vap, $countingvap))/3);	
	}
	$countingvap++;
	}
	$vapf = implode("-",array_filter($vapf2));
	$vapmx2 = explode("-",$vapf);
	$vapmx = max(explode("-",$vapf));
	$stnameandscoreVap = array_combine($acvapkeys,$vapmx2);
	$maxinallsub = $vapmx;			
	}
	
	else if($su == 'Yoruba'){
		$resultmxbystunameyor1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Yoruba' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameyor1))
	{	
		$snm2yor1[] = $rsn['score'];
		$stin2yor[] = $rsn['student_name'];
	}
	$acyorf = array_combine($stin2yor,$snm2yor1);
	$resultmxbystunameyor2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Yoruba' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameyor2))
	{	
		$snm2yor2[] = $rsn['score'];
	    $stin2yor2[] = $rsn['student_name'];
	}
	$acyors = array_combine($stin2yor2,$snm2yor2);
	$resultmxbystunameyor3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Yoruba' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameyor3))
	{	
		$snm2yor3[] = $rsn['score'];
		$stin2yor3[] = $rsn['student_name'];
	}
	$acyort = array_combine($stin2yor3,$snm2yor3);
	$arinall = array($acyorf, $acyors, $acyort);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acyorkeys = (array_keys($largest_arr));
	
$foryor1 = array();
$foryor2 = array();
$foryor3 = array();
for($v=0; $v<=120; $v++){
$foryyor1[] = $snm2yor1[$v];
$foryyor2[] = $snm2yor2[$v];
$foryyor3[] = $snm2yor3[$v];
}
$foryor1 = $foryyor1;
$foryor2 = $foryyor2;
$foryor3 = $foryyor3;

	$array_all_yor = array(array_filter($foryor1), array_filter($foryor2), array_filter($foryor3));
	$countingyor = 0;
	while($countingyor <= 120){
	if(count(array_column($array_all_yor, $countingyor)) == 3){
	$yorf2[] = round(array_sum(array_column($array_all_yor, $countingyor))/3);
	}
	else if(count(array_column($array_all_yor, $countingyor)) == 2){
	$yorf2[] = round(array_sum(array_column($array_all_yor, $countingyor))/2);
	}
	else if(count(array_column($array_all_yor, $countingyor)) == 1){
	$yorf2[] = round(array_sum(array_column($array_all_yor, $countingyor))/1);
	}
	else{
	$yorf2[] = round(array_sum(array_column($array_all_yor, $countingyor))/3);	
	}
	$countingyor++;
	}
	$yorf = implode("-",array_filter($yorf2));
	$yormx2 = explode("-",$yorf);
	$yormx = max(explode("-",$yorf));
	$stnameandscoreYor = array_combine($acyorkeys,$yormx2);
	$maxinallsub = $yormx;			
	}
	else if($su == 'Quantitative Reasoning'){
		$resultmxbystunameqr1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Quantitative Reasoning' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameqr1))
	{	
		$snm2qr1[] = $rsn['score'];
		$stin2qr[] = $rsn['student_name'];
	}
	$acqrf = array_combine($stin2qr,$snm2qr1);
	$resultmxbystunameqr2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Quantitative Reasoning' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameqr2))
	{	
		$snm2qr2[] = $rsn['score'];
	    $stin2qr2[] = $rsn['student_name'];
	}
	$acqrs = array_combine($stin2qr2,$snm2qr2);
	$resultmxbystunameqr3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Quantitative Reasoning' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameqr3))
	{	
		$snm2qr3[] = $rsn['score'];
		$stin2qr3[] = $rsn['student_name'];
	}
	$acqrt = array_combine($stin2qr3,$snm2qr3);
	$arinall = array($acqrf, $acqrs, $acqrt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acqrkeys = (array_keys($largest_arr));
	
$forqr1 = array();
$forqr2 = array();
$forqr3 = array();
for($v=0; $v<=120; $v++){
$forqqr1[] = $snm2qr1[$v];
$forqqr2[] = $snm2qr2[$v];
$forqqr3[] = $snm2qr3[$v];
}
$forqr1 = $forqqr1;
$forqr2 = $forqqr2;
$forqr3 = $forqqr3;

	$array_all_qr = array(array_filter($forqr1), array_filter($forqr2), array_filter($forqr3));
	$countingqr = 0;
	while($countingqr <= 120){
	if(count(array_column($array_all_qr, $countingqr)) == 3){
	$qrf2[] = round(array_sum(array_column($array_all_qr, $countingqr))/3);
	}
	else if(count(array_column($array_all_qr, $countingqr)) == 2){
	$qrf2[] = round(array_sum(array_column($array_all_qr, $countingqr))/2);
	}
	else if(count(array_column($array_all_qr, $countingqr)) == 1){
	$qrf2[] = round(array_sum(array_column($array_all_qr, $countingqr))/1);
	}
	else{
	$qrf2[] = round(array_sum(array_column($array_all_qr, $countingqr))/3);	
	}
	$countingqr++;
	}
	$qrf = implode("-",array_filter($qrf2));
	$qrmx2 = explode("-",$qrf);
	$qrmx = max(explode("-",$qrf));
	$stnameandscoreQr = array_combine($acqrkeys,$qrmx2);
	$maxinallsub = $qrmx;			
	}
		else if($su == 'Verbal Reasoning'){
		$resultmxbystunamevr1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Verbal Reasoning' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevr1))
	{	
		$snm2vr1[] = $rsn['score'];
		$stin2vr[] = $rsn['student_name'];
	}
	$acvrf = array_combine($stin2vr,$snm2vr1);
	$resultmxbystunamevr2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Verbal Reasoning' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevr2))
	{	
		$snm2vr2[] = $rsn['score'];
	    $stin2vr2[] = $rsn['student_name'];
	}
	$acvrs = array_combine($stin2vr2,$snm2vr2);
	$resultmxbystunamevr3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Verbal Reasoning' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevr3))
	{	
		$snm2vr3[] = $rsn['score'];
		$stin2vr3[] = $rsn['student_name'];
	}
	$acvrt = array_combine($stin2vr3,$snm2vr3);
	$arinall = array($acvrf, $acvrs, $acvrt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acvrkeys = (array_keys($largest_arr));
	
$forvr1 = array();
$forvr2 = array();
$forvr3 = array();
for($v=0; $v<=120; $v++){
$forvvr1[] = $snm2vr1[$v];
$forvvr2[] = $snm2vr2[$v];
$forvvr3[] = $snm2vr3[$v];
}
$forvr1 = $forvvr1;
$forvr2 = $forvvr2;
$forvr3 = $forvvr3;

	$array_all_vr = array(array_filter($forvr1), array_filter($forvr2), array_filter($forvr3));
	$countingvr = 0;
	while($countingvr <= 120){
	if(count(array_column($array_all_vr, $countingvr)) == 3){
	$vrf2[] = round(array_sum(array_column($array_all_vr, $countingvr))/3);
	}
	else if(count(array_column($array_all_vr, $countingvr)) == 2){
	$vrf2[] = round(array_sum(array_column($array_all_vr, $countingvr))/2);
	}
	else if(count(array_column($array_all_vr, $countingvr)) == 1){
	$vrf2[] = round(array_sum(array_column($array_all_vr, $countingvr))/1);
	}
	else{
	$vrf2[] = round(array_sum(array_column($array_all_vr, $countingvr))/3);	
	}
	$countingvr++;
	}
	$vrf = implode("-",array_filter($vrf2));
	$vrmx2 = explode("-",$vrf);
	$vrmx = max(explode("-",$vrf));
	$stnameandscoreVr = array_combine($acvrkeys,$vrmx2);
	$maxinallsub = $vrmx;			
	}
			else if($su == 'Geography'){
		$resultmxbystunamegeo1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Geography' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegeo1))
	{	
		$snm2geo1[] = $rsn['score'];
		$stin2geo[] = $rsn['student_name'];
	}
	$acgeof = array_combine($stin2geo,$snm2geo1);
	$resultmxbystunamegeo2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Geography' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegeo2))
	{	
		$snm2geo2[] = $rsn['score'];
	    $stin2geo2[] = $rsn['student_name'];
	}
	$acgeos = array_combine($stin2geo2,$snm2geo2);
	$resultmxbystunamegeo3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Geography' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegeo3))
	{	
		$snm2geo3[] = $rsn['score'];
		$stin2geo3[] = $rsn['student_name'];
	}
	$acgeot = array_combine($stin2geo3,$snm2geo3);
	$arinall = array($acgeof, $acgeos, $acgeot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acgeokeys = (array_keys($largest_arr));
	
$forgeo1 = array();
$forgeo2 = array();
$forgeo3 = array();
for($v=0; $v<=120; $v++){
$forggeo1[] = $snm2geo1[$v];
$forggeo2[] = $snm2geo2[$v];
$forggeo3[] = $snm2geo3[$v];
}
$forgeo1 = $forggeo1;
$forgeo2 = $forggeo2;
$forgeo3 = $forggeo3;
		
$array_all_geo = array(array_filter($forgeo1), array_filter($forgeo2), array_filter($forgeo3));
	$countinggeo = 0;
	while($countinggeo <= 120){
	if(count(array_column($array_all_geo, $countinggeo)) == 3){
	$geof2[] = round(array_sum(array_column($array_all_geo, $countinggeo))/3);
	}
	else if(count(array_column($array_all_geo, $countinggeo)) == 2){
	$geof2[] = round(array_sum(array_column($array_all_geo, $countinggeo))/2);
	}
	else if(count(array_column($array_all_geo, $countinggeo)) == 1){
	$geof2[] = round(array_sum(array_column($array_all_geo, $countinggeo))/1);
	}
	else{
	$geof2[] = round(array_sum(array_column($array_all_geo, $countinggeo))/3);	
	}
	$countinggeo++;
	}
	$geof = implode("-",array_filter($geof2));
	$geomx2 = explode("-",$geof);
	$geomx = max(explode("-",$geof));
	$stnameandscoreGeo = array_combine($acgeokeys,$geomx2);
	$maxinallsub = $geomx;			
	}

	elseif($su == 'Handwriting'){							
	$resultmxbystunamehw1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Handwriting' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehw1))
	{	
		$snm2hw1[] = $rsn['score'];
		$stin2hw[] = $rsn['student_name'];
	}
	$achwf = array_combine($stin2hw,$snm2hw1);
	$resultmxbystunamehw2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Handwriting' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehw2))
	{	
		$snm2hw2[] = $rsn['score'];
	    $stin2hw2[] = $rsn['student_name'];
	}
	$achws = array_combine($stin2hw2,$snm2hw2);
	$resultmxbystunamehw3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Handwriting' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehw3))
	{	
		$snm2hw3[] = $rsn['score'];
		$stin2hw3[] = $rsn['student_name'];
	}
	$achwt = array_combine($stin2hw3,$snm2hw3);
	$arinall = array($achwf, $achws, $achwt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$achwkeys = (array_keys($largest_arr));
	
$forhw1 = array();
for($v=0; $v<=120; $v++){
$forhhw1[] = $snm2hw1[$v];
}
$forhw1 = $forhhw1;

$forhw2 = array();
for($v=0; $v<=120; $v++){
$forhhw2[] = $snm2hw2[$v];
}
$forhw2 = $forhhw2;

$forhw3 = array();
for($v=0; $v<=120; $v++){
$forhhw3[] = $snm2hw3[$v];
}
$forhw3 = $forhhw3;

$array_all_hw = array(array_filter($forhw1), array_filter($forhw2), array_filter($forhw3));
	$countinghw = 0;
	while($countinghw <= 120){
	if(count(array_column($array_all_hw, $countinghw)) == 3){
	$hwf2[] = round(array_sum(array_column($array_all_hw, $countinghw))/3);
	}
	else if(count(array_column($array_all_hw, $countinghw)) == 2){
	$hwf2[] = round(array_sum(array_column($array_all_hw, $countinghw))/2);
	}
	else if(count(array_column($array_all_hw, $countinghw)) == 1){
	$hwf2[] = round(array_sum(array_column($array_all_hw, $countinghw))/1);
	}
	else{
	$hwf2[] = round(array_sum(array_column($array_all_hw, $countinghw))/3);	
	}
	$countinghw++;
	}
	$hwf = implode("-",array_filter($hwf2));
	$hwmx2 = explode("-",$hwf);
	$hwmx = max(explode("-",$hwf));
	$stnameandscoreHw = array_combine($achwkeys,$hwmx2);
	$maxinallsub = $hwmx;	
	}
		else{	
			$maxinallsub = "-";	
		}
	
						echo '<tr><td>'.$su.'</td><td>'.$ct.'</td><td>'.$ex.'</td><td>'.$tt.'</td><td>'.$dd.'</td><td>'.$cc.'</td><td>'.$av.'</td><td>'.$maxinallsub.'</td><td id="mytd">'.round($ccav).'</td><td>'.$grade.'</td><td>'.$tn.'</td><td style="text-align: left;">'.$re.'</td></tr>';	
							$counted++;
							$arrsubj2[] = $su;
							$ca2[] = $ct;
							$exam2[] = $ex;
							$fir2[] = $cc;
							$sec2[] = $dd;
							$thir2[] = $tt;
							$av2[] = $av;
							$ccav2[] = round($ccav);
							$grad2[] = $grade;
							$teacher2[] = $tn;
							$remark2[] = $re;
							$maxinallsub2[] = $maxinallsub;
							}
							
							$arrsubj = $arrsubj2;
							$ca = $ca2;
							$exam = $exam2;
							$fir = $fir2;
							$sec = $sec2;
							$thir = $thir2;
							$avv = $av2;
							$ccavv = $ccav2;
							$grad = $grad2;
							$teacher = $teacher2;
							$remark = $remark2;						
							$hssubmit8 = $maxinallsub2;
							
	}				
	else{
		echo '<tr id="heading"><td>SUBJECT</td><td>CA</td><td>EXAM</td><td>TOTAL</td><td>GRADE</td><td>TEACHER\'S NAME</td><td>REMARK</td></tr>';	
		$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								$grbnt = mysqli_query($db, "SELECT grade FROM gradeband WHERE score='".$row["score"]."'");
							while($rowgrbnt = mysqli_fetch_assoc($grbnt))
							{
							$grade2	= $rowgrbnt['grade'];
							}
								
							$row2subject[] = $row["subject"];	
							$row2ca[] = $row["ca"];	
							$row2exam[] = $row["exam"];
							$row2score[] = $row["score"];
							$row2teacher_name[] = $row["teacher_name"];
							$row2remark[] = $row["remark"];
							$grad2[] = $grade;
								echo '<tr><td>'.$row["subject"].'</td><td>'.$row["ca"].'</td><td>'.$row["exam"].'</td><td>'.$row["score"].'</td><td>'.$grade.'</td><td>'.$row["teacher_name"].'</td><td style="text-align: left;">'.$row["remark"].'</td></tr>';	
							}	
							$arrsubj = $row2subject;	
							$ca = $row2ca;	
							$exam = $row2exam;
							$tt = $row2score;
							$grad = $grad2;
							$teacher = $row2teacher_name;
							$remark = $row2remark;		
	
	}
	} //end of arm present for submit8 form from chartjs3


else{
if($term == "Third Term"){	
	$result1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	$sql2 = mysqli_query($db, "SELECT * FROM maxes where subjectname='$subject' AND classname='$class' AND yearname='$year' AND termname='$term' AND teachername='$tna' AND teacheridname='$tid' AND school='".$_SESSION["school"]."'");
					
						while($row1 = mysqli_fetch_assoc($result1))
							{ 
								$firsubject[] = $row1['subject'];
								$firscore[] = $row1['score'];
							}
							$firsubject11 = $firsubject;
							$firscore11 = $firscore;
							$c = array_combine($firsubject11, $firscore11);
							ksort($c);
							$c = array_values($c);
							
	$result2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
						while($row2 = mysqli_fetch_assoc($result2))
							{ 
								$secsubject[] = $row2['subject'];
								$secscore[] = $row2['score'];
							}
							$secsubject22 = $secsubject;
							$secscore22 = $secscore;
							$d = array_combine($secsubject22, $secscore22);
							ksort($d);
							$d = array_values($d);
				
							
	$result3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
						while($row3 = mysqli_fetch_assoc($result3))
							{ 
								$thirsubject[] = $row3['subject'];
								$thirscore[] = $row3['score'];
							}
							$thirsubject33 = $thirsubject;
							$thirscore33 = $thirscore;
							$t = array_combine($thirsubject33, $thirscore33);
							ksort($t);
							$t = array_values($t);						
							
							$e = array_map(function () {
							return array_sum(func_get_args());
							},$c, $d, $t);
							ksort($e);
		
							
	echo '<tr id="heading"><td>SUBJECT</td><td>CA</td><td>EXAM</td><td>THIRD TERM</td><td>SECOND TERM</td><td>FIRST TERM</td><td>AV. OF THREE TERMS</td><td>CLASS HIGHEST</td><td>CLASS AVERAGE</td><td>GRADE</td><td>TEACHER\'S NAME</td><td>REMARK</td></tr>';	
	
	
	$result = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."' ORDER BY subject ASC");
	
	$recav = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
	$recavmax = mysqli_query($db, "SELECT MAX(score) AS agrmax FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
	while($rowcav = mysqli_fetch_assoc($recav))
							{
							$agrcavin[]	= $rowcav['score'];
							}
							$agrcav = array_filter($agrcavin);
							$agrcav2 = array_sum($agrcav);
	$numbagr = count(array_filter($agrcav));
	$agrcav3 = $agrcav2/$numbagr;
	
	$recav1 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Basic Science' AND school='".$_SESSION["school"]."'");
	while($rowcav1 = mysqli_fetch_assoc($recav1))
							{
							$bascavin[]	= $rowcav1['score'];
							}
							$bascav = array_filter($bascavin);
							$bascav2 = array_sum($bascav);
	$numbbas = count(array_filter($bascav));
	$bascav3 = $bascav2/$numbbas;
	
	$recav2 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='English' AND school='".$_SESSION["school"]."'");
	$recav2max = mysqli_query($db, "SELECT MAX(score) AS engmax FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='English' AND school='".$_SESSION["school"]."'");
	while($rowcav2 = mysqli_fetch_assoc($recav2))
							{
							$engcavin[]	= $rowcav2['score'];
							}
							$engcav = array_filter($engcavin);
							$engcav2 = array_sum($engcav);
	$numbeng = count(array_filter($engcav));
	$engcav3 = round($engcav2/$numbeng);
	while($rowcav2max = mysqli_fetch_assoc($recav2max))
							{
							$engcavinmax[]	= $rowcav2max['engmax'];
							}
							$engcavmax = array_filter($engcavinmax);
							$engcav2max = array_sum($engcavmax);
	$numbengmax = count(array_filter($engcavmax));
	$engcav3max = $engcav2max/$numbengmax;
	//echo $engcav3max;
	
	$recav3 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Business Studies' AND school='".$_SESSION["school"]."'");
	while($rowcav3 = mysqli_fetch_assoc($recav3))
							{
							$buscavin[]	= $rowcav3['score'];
							}
							$buscav = array_filter($buscavin);
							$buscav2 = array_sum($buscav);
	$numbbus = count(array_filter($buscav));
	$buscav3 = round($buscav2/$numbbus);
	
	$recav4 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Catering' AND school='".$_SESSION["school"]."'");
	while($rowcav4 = mysqli_fetch_assoc($recav4))
							{
							$catcavin[]	= $rowcav4['score'];
							}
							$catcav = array_filter($catcavin);
							$catcav2 = array_sum($catcav);
	$numbcat = count(array_filter($catcav));
	$catcav3 = $catcav2/$numbcat;
	
	$recav5 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Civic Education' AND school='".$_SESSION["school"]."'");
	while($rowcav5 = mysqli_fetch_assoc($recav5))
							{
							$civcavin[]	= $rowcav5['score'];
							}
							$civcav = array_filter($civcavin);
							$civcav2 = array_sum($civcav);
	$numbciv = count(array_filter($civcav));
	$civcav3 = $civcav2/$numbciv;
	
	$recav6 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Crk' AND school='".$_SESSION["school"]."'");
	while($rowcav6 = mysqli_fetch_assoc($recav6))
							{
							$crkcavin[]	= $rowcav6['score'];
							}
							$crkcav = array_filter($crkcavin);
							$crkcav2 = array_sum($crkcav);
	$numbcrk = count(array_filter($crkcav));
	$crkcav3 = $crkcav2/$numbcrk;
	
	$recav7 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Food and Nutrition' AND school='".$_SESSION["school"]."'");
	while($rowcav7 = mysqli_fetch_assoc($recav7))
							{
							$foocavin[]	= $rowcav7['score'];
							}
							$foocav = array_filter($foocavin);
							$foocav2 = array_sum($foocav);
	$numbfoo = count(array_filter($foocav));
	$foocav3 = $foocav2/$numbfoo;
	
	$recav8 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='French' AND school='".$_SESSION["school"]."'");
	while($rowcav8 = mysqli_fetch_assoc($recav8))
							{
							$frecavin[]	= $rowcav8['score'];
							}
							$frecav = array_filter($frecavin);
							$frecav2 = array_sum($frecav);
	$numbfre = count(array_filter($frecav));
	$frecav3 = $frecav2/$numbfre;
	
	$recav9 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='ICT' AND school='".$_SESSION["school"]."'");
	while($rowcav9 = mysqli_fetch_assoc($recav9))
							{
							$ictcavin[]	= $rowcav9['score'];
							}
							$ictcav = array_filter($ictcavin);
							$ictcav2 = array_sum($ictcav);
	$numbict = count(array_filter($ictcav));
	$ictcav3 = $ictcav2/$numbict;
	
	$recav10 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Igbo' AND school='".$_SESSION["school"]."'");
	while($rowcav10 = mysqli_fetch_assoc($recav10))
							{
							$igbcavin[]	= $rowcav10['score'];
							}
							$igbcav = array_filter($igbcavin);
							$igbcav2 = array_sum($igbcav);
	$numbigb = count(array_filter($igbcav));
	$igbcav3 = $igbcav2/$numbigb;
	
	$recav11 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Mathematics' AND school='".$_SESSION["school"]."'");
	while($rowcav11 = mysqli_fetch_assoc($recav11))
							{
							$matcavin[]	= $rowcav11['score'];
							}
							$matcav = array_filter($matcavin);
							$matcav2 = array_sum($matcav);
	$numbmat = count(array_filter($matcav));
	$matcav3 = $matcav2/$numbmat;
	
	$recav12 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Music' AND school='".$_SESSION["school"]."'");
	while($rowcav12 = mysqli_fetch_assoc($recav12))
							{
							$muscavin[]	= $rowcav12['score'];
							}
							$muscav = array_filter($muscavin);
							$muscav2 = array_sum($muscav);
	$numbmus = count(array_filter($muscav));
	$muscav3 = $muscav2/$numbmus;
	
	$recav13 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='PHE' AND school='".$_SESSION["school"]."'");
	while($rowcav13 = mysqli_fetch_assoc($recav13))
							{
							$phecavin[]	= $rowcav13['score'];
							}
							$phecav = array_filter($phecavin);
							$phecav2 = array_sum($phecav);
	$numbphe = count(array_filter($phecav));
	$phecav3 = $phecav2/$numbphe;

	$recav14 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Social Studies' AND school='".$_SESSION["school"]."'");
	while($rowcav14 = mysqli_fetch_assoc($recav14))
							{
							$soccavin[]	= $rowcav14['score'];
							}
							$soccav = array_filter($soccavin);
							$soccav2 = array_sum($soccav);
	$numbsoc = count(array_filter($soccav));
	$soccav3 = $soccav2/$numbsoc;
	
	$recav15 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Biology' AND school='".$_SESSION["school"]."'");
	while($rowcav15 = mysqli_fetch_assoc($recav15))
							{
							$biocavin[]	= $rowcav15['score'];
							}
							$biocav = array_filter($biocavin);
							$biocav2 = array_sum($biocav);
	$numbbio = count(array_filter($biocav));
	$biocav3 = $biocav2/$numbbio;
	
	$recav16 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Chemistry' AND school='".$_SESSION["school"]."'");
	while($rowcav16 = mysqli_fetch_assoc($recav16))
							{
							$checavin[]	= $rowcav16['score'];
							}
							$checav = array_filter($checavin);
							$checav2 = array_sum($checav);
	$numbche = count(array_filter($checav));
	$checav3 = $checav2/$numbche;
	
	$recav17 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Economics' AND school='".$_SESSION["school"]."'");
	while($rowcav17 = mysqli_fetch_assoc($recav17))
							{
							$ecocavin[]	= $rowcav17['score'];
							}
							$ecocav = array_filter($ecocavin);
							$ecocav2 = array_sum($ecocav);
	$numbeco = count(array_filter($ecocav));
	$ecocav3 = $ecocav2/$numbeco;
	
	$recav18 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Government' AND school='".$_SESSION["school"]."'");
	while($rowcav18 = mysqli_fetch_assoc($recav18))
							{
							$govcavin[]	= $rowcav18['score'];
							}
							$govcav = array_filter($govcavin);
							$govcav2 = array_sum($govcav);
	$numbgov = count(array_filter($govcav));
	$govcav3 = $govcav2/$numbgov;
	
	$recav19 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='VA' AND school='".$_SESSION["school"]."'");
	while($rowcav19 = mysqli_fetch_assoc($recav19))
							{
							$vacavin[]	= $rowcav19['score'];
							}
							$vacav = array_filter($vacavin);
							$vacav2 = array_sum($vacav);
	$numbva = count(array_filter($vacav));
	$vacav3 = $vacav2/$numbva;
	
	$recav20 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='TD' AND school='".$_SESSION["school"]."'");
	while($rowcav20 = mysqli_fetch_assoc($recav20))
							{
							$tdcavin[]	= $rowcav20['score'];
							}
							$vacav = array_filter($tdcavin);
							$tdcav2 = array_sum($tdcav);
	$numbtd = count(array_filter($tdcav));
	$tdcav3 = $tdcav2/$numbtd;
	
	$recav21 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Sociology' AND school='".$_SESSION["school"]."'");
	while($rowcav21 = mysqli_fetch_assoc($recav21))
							{
							$socicavin[]	= $rowcav21['score'];
							}
							$socicav = array_filter($socicavin);
							$socicav2 = array_sum($socicav);
	$numbsoci = count(array_filter($socicav));
	$socicav3 = $socicav2/$numbsoci;
							
	$recav22 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Physics' AND school='".$_SESSION["school"]."'");
	while($rowcav22 = mysqli_fetch_assoc($recav22))
							{
							$phycavin[]	= $rowcav22['score'];
							}
							$phycav = array_filter($phycavin);
							$phycav2 = array_sum($phycav);
	$numbphy = count(array_filter($phycav));
	$phycav3 = $phycav2/$numbphy;
	
	$recav23 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Marketing' AND school='".$_SESSION["school"]."'");
	while($rowcav23 = mysqli_fetch_assoc($recav23))
							{
							$marcavin[]	= $rowcav23['score'];
							}
							$marcav = array_filter($marcavin);
							$marcav2 = array_sum($marcav);
	$numbmar = count(array_filter($marcav));
	$marcav3 = $marcav2/$numbmar;
	
	$recav24 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Lit in English' AND school='".$_SESSION["school"]."'");
	while($rowcav24 = mysqli_fetch_assoc($recav24))
							{
							$litcavin[]	= $rowcav24['score'];
							}
							$litcav = array_filter($litcavin);
							$litcav2 = array_sum($litcav);
	$numblit = count(array_filter($litcav));
	$litcav3 = $litcav2/$numblit;
	
	$recav25 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Yoruba' AND school='".$_SESSION["school"]."'");
	while($rowcav25 = mysqli_fetch_assoc($recav25))
							{
							$yorcavin[]	= $rowcav25['score'];
							}
							$yorcav = array_filter($yorcavin);
							$yorcav2 = array_sum($yorcav);
	$numbyor = count(array_filter($yorcav));
	$yorcav3 = $yorcav2/$numbyor;
	
	$recav26 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Quantitative Reasoning' AND school='".$_SESSION["school"]."'");
	while($rowcav26 = mysqli_fetch_assoc($recav26))
							{
							$qrcavin[]	= $rowcav26['score'];
							}
							$qrcav = array_filter($qrcavin);
							$qrcav2 = array_sum($qrcav);
	$numbqr = count(array_filter($qrcav));
	$qrcav3 = $qrcav2/$numbqr;
	
	$recav27 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Verbal Reasoning' AND school='".$_SESSION["school"]."'");
	while($rowcav27 = mysqli_fetch_assoc($recav27))
							{
							$vrcavin[]	= $rowcav27['score'];
							}
							$vrcav = array_filter($vrcavin);
							$vrcav2 = array_sum($vrcav);
	$numbvr = count(array_filter($vrcav));
	$vrcav3 = $vrcav2/$numbvr;
	
		$recav28 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Geography' AND school='".$_SESSION["school"]."'");
	$recavmax28 = mysqli_query($db, "SELECT MAX(score) AS agrmax FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Geography' AND school='".$_SESSION["school"]."'");
	while($rowcav28 = mysqli_fetch_assoc($recav28))
							{
							$geocavin[]	= $rowcav28['score'];
							}
							$geocav = array_filter($geocavin);
							$geocav2 = array_sum($geocav);
	$numbgeo = count(array_filter($geocav));
	$geocav3 = $geocav2/$numbgeo;
	
	$recav29 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Handwriting' AND school='".$_SESSION["school"]."'");
	while($rowcav29 = mysqli_fetch_assoc($recav29))
							{
							$hwcavin[]	= $rowcav29['score'];
							}
							$hwcav = array_filter($hwcavin);
							$hwcav2 = array_sum($hwcav);
	$numbhw = count(array_filter($hwcav));
	$hwcav3 = $hwcav2/$numbhw;
	
	$recav30 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Vocational Aptitude' AND school='".$_SESSION["school"]."'");
	while($rowcav30 = mysqli_fetch_assoc($recav30))
							{
							$vapcavin[]	= $rowcav30['score'];
							}
							$vapcav = array_filter($vapcavin);
							$vapcav2 = array_sum($vapcav);
	$numbvap = count(array_filter($vapcav));
	$vapcav3 = $vapcav2/$numbvap;
	
	$recav31 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Phonics' AND school='".$_SESSION["school"]."'");
	while($rowcav31 = mysqli_fetch_assoc($recav31))
							{
							$phocavin[]	= $rowcav31['score'];
							}
							$phocav = array_filter($phocavin);
							$phocav2 = array_sum($phocav);
	$numbpho = count(array_filter($phocav));
	$phocav3 = $phocav2/$numbpho;
	
	$recav32 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Islamic Religious Studies' AND school='".$_SESSION["school"]."'");
	while($rowcav32 = mysqli_fetch_assoc($recav32))
							{
							$irscavin[]	= $rowcav32['score'];
							}
							$irscav = array_filter($irscavin);
							$irscav2 = array_sum($irscav);
	$numbirs = count(array_filter($irscav));
	$irscav3 = $irscav2/$numbirs;
	
	$recav33 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Creative and Cultural Arts' AND school='".$_SESSION["school"]."'");
	while($rowcav33 = mysqli_fetch_assoc($recav33))
							{
							$ccacavin[]	= $rowcav33['score'];
							}
							$ccacav = array_filter($ccacavin);
							$ccacav2 = array_sum($ccacav);
	$numbcca = count(array_filter($ccacav));
	$ccacav3 = $ccacav2/$numbcca;
	
		$recav34 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='History' AND school='".$_SESSION["school"]."'");
	while($rowcav34 = mysqli_fetch_assoc($recav34))
							{
							$hiscavin[]	= $rowcav34['score'];
							}
							$hiscav = array_filter($hiscavin);
							$hiscav2 = array_sum($hiscav);
	$numbhis = count(array_filter($hiscav));
	$hiscav3 = $hiscav2/$numbhis;
	
	$recav35 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Hausa' AND school='".$_SESSION["school"]."'");
	while($rowcav35 = mysqli_fetch_assoc($recav35))
							{
							$haucavin[]	= $rowcav35['score'];
							}
							$haucav = array_filter($haucavin);
							$haucav2 = array_sum($haucav);
	$numbhau = count(array_filter($haucav));
	$haucav3 = $haucav2/$numbhau;
	
	$recav36 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Hausa' AND school='".$_SESSION["school"]."'");
	while($rowcav36 = mysqli_fetch_assoc($recav36))
							{
							$fincavin[]	= $rowcav36['score'];
							}
							$fincav = array_filter($fincavin);
							$fincav2 = array_sum($fincav);
	$numbfin = count(array_filter($fincav));
	$fincav3 = $fincav2/$numbfin;
	
	$engcount = 0;
	$counter = 0;
	$counted = 0;
	while($row = mysqli_fetch_assoc($result))
							{		
		$to = Array($c[$counted], $d[$counted], $t[$counted]);
		if(($t[$counted] == 0) AND ($c[$counted] != 0) AND ($d[$counted] != 0)){$avdiv = 2; $t[$counted] = "-";}
		elseif(($t[$counted] != 0) AND ($c[$counted] != 0) AND ($d[$counted] == 0)){$avdiv = 2; $d[$counted] = "-";}
		elseif(($t[$counted] != 0) AND ($c[$counted] == 0) AND ($d[$counted] != 0)){$avdiv = 2; $d[$counted] = "-";}
		elseif(($t[$counted] == 0) AND ($c[$counted] != 0) AND ($d[$counted] == 0)){$avdiv = 1; $t[$counted] = "-"; $d[$counted] = "-";}
		elseif(($t[$counted] == 0) AND ($c[$counted] == 0) AND ($d[$counted] != 0)){$avdiv = 1; $c[$counted] = "-"; $t[$counted] = "-";}
		elseif(($t[$counted] != 0) AND ($c[$counted] == 0) AND ($d[$counted] == 0)){$avdiv = 1; $c[$counted] = "-"; $d[$counted] = "-";}
		elseif(($t[$counted] != 0) AND ($c[$counted] != 0) AND ($d[$counted] != 0)){$avdiv = 3;}
		else{$avdiv = 3;}
		$to2 = array_sum($to);
		$av = round($to2/$avdiv);
								$cc = $c[$counted];
								$dd = $d[$counted];
								$tt = $t[$counted];
								
							$grbnt = mysqli_query($db, "SELECT grade FROM gradeband WHERE score='$av'");
							while($rowgrbnt = mysqli_fetch_assoc($grbnt))
							{
							$grade2	= $rowgrbnt['grade'];
							}
							$grade = $grade2;
								
								if($row["subject"] == "Agricultural Science"){$ccav = $agrcav3;}
								elseif($row["subject"] == "Basic Science"){$ccav = $bascav3;}
								elseif($row["subject"] == "English"){$ccav = $engcav3;}
								elseif($row["subject"] == "Business Studies"){$ccav = $buscav3;}
								elseif($row["subject"] == "Catering"){$ccav = $catcav3;}
								elseif($row["subject"] == "Civic Education"){$ccav = $civcav3;}
								elseif($row["subject"] == "Crk"){$ccav = $crkcav3;}
								elseif($row["subject"] == "Food and Nutrition"){$ccav = $foocav3;}
								elseif($row["subject"] == "ICT"){$ccav = $ictcav3;}
								elseif($row["subject"] == "French"){$ccav = $frecav3;}
								elseif($row["subject"] == "Igbo"){$ccav = $igbcav3;}
								elseif($row["subject"] == "Mathematics"){$ccav = $matcav3;}
								elseif($row["subject"] == "Music"){$ccav = $muscav3;}
								elseif($row["subject"] == "PHE"){$ccav = $phecav3;}
								elseif($row["subject"] == "Social Studies"){$ccav = $soccav3;}
								elseif($row["subject"] == "Biology"){$ccav = $biocav3;}
								elseif($row["subject"] == "Chemistry"){$ccav = $checav3;}
								elseif($row["subject"] == "Economics"){$ccav = $ecocav3;}
								elseif($row["subject"] == "Government"){$ccav = $govcav3;}
								elseif($row["subject"] == "VA"){$ccav = $vacav3;}
								elseif($row["subject"] == "TD"){$ccav = $tdcav3;}
								elseif($row["subject"] == "Sociology"){$ccav = $socicav3;}
								elseif($row["subject"] == "Marketing"){$ccav = $marcav3;}
								elseif($row["subject"] == "Physics"){$ccav = $phycav3;}
								elseif($row["subject"] == "Lit in English"){$ccav = $litcav3;}
								elseif($row["subject"] == "Yoruba"){$ccav = $yorcav3;}
								elseif($row["subject"] == "Quantitative Reasoning"){$ccav = $qrcav3;}
								elseif($row["subject"] == "Verbal Reasoning"){$ccav = $vrcav3;}
								elseif($row["subject"] == "Geography"){$ccav = $geocav3;}
								elseif($row["subject"] == "Handwriting"){$ccav = $hwcav3;}
								elseif($row["subject"] == "Vocational Aptitude"){$ccav = $vapcav3;}
								elseif($row["subject"] == "Phonics"){$ccav = $phocav3;}
								elseif($row["subject"] == "Islamic Religious Studies"){$ccav = $irscav3;}
								elseif($row["subject"] == "Creative and Cultural Arts"){$ccav = $ccacav3;}
								elseif($row["subject"] == "History"){$ccav = $hiscav3;}
								elseif($row["subject"] == "Hausa"){$ccav = $haucav3;}
								elseif($row["subject"] == "Financial Accounting"){$ccav = $fincav3;}
								elseif($ccav == ""){$ccav = "-";}
								else{$ccav = "-";}
								$su = $row["subject"];
								$tn = $row["teacher_name"];
								$re = $row["remark"];
								$ct = $row["ca"];
								$ex = $row["exam"];
	
	if($su == 'English'){							
	$resultmxbystunameeng1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='English' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeng1))
	{	
		$snm2eng1[] = $rsn['score'];
		$stin2eng[] = $rsn['student_name'];
	}
	$acengf = array_combine($stin2eng,$snm2eng1);
	$resultmxbystunameeng2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='English' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeng2))
	{	
		$snm2eng2[] = $rsn['score'];
	    $stin2eng2[] = $rsn['student_name'];
	}
	$acengs = array_combine($stin2eng2,$snm2eng2);
	$resultmxbystunameeng3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='English' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeng3))
	{	
		$snm2eng3[] = $rsn['score'];
		$stin2eng3[] = $rsn['student_name'];
	}
	$acengt = array_combine($stin2eng3,$snm2eng3);
	$arinall = array($acengf, $acengs, $acengt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acengkeys = (array_keys($largest_arr));
	
$foreng1 = array($snm2eng1[0], $snm2eng1[1], $snm2eng1[2], $snm2eng1[3], $snm2eng1[4], $snm2eng1[5], $snm2eng1[6], $snm2eng1[7], $snm2eng1[8], $snm2eng1[9], $snm2eng1[10], $snm2eng1[11], $snm2eng1[12], $snm2eng1[13], $snm2eng1[14], $snm2eng1[15], $snm2eng1[16], $snm2eng1[17], $snm2eng1[18], $snm2eng1[19], 
		  $snm2eng1[20], $snm2eng1[21], $snm2eng1[22], $snm2eng1[23], $snm2eng1[24], $snm2eng1[25], $snm2eng1[26], $snm2eng1[27], $snm2eng1[28], $snm2eng1[29], $snm2eng1[30], $snm2eng1[31], $snm2eng1[32], $snm2eng1[33], $snm2eng1[34], $snm2eng1[35], $snm2eng1[36], $snm2eng1[37], $snm2eng1[38], $snm2eng1[39], 
		  $snm2eng1[40], $snm2eng1[41], $snm2eng1[42], $snm2eng1[43], $snm2eng1[44], $snm2eng1[45], $snm2eng1[46], $snm2eng1[47], $snm2eng1[48], $snm2eng1[49], $snm2eng1[50], $snm2eng1[51], $snm2eng1[52], $snm2eng1[53], $snm2eng1[54], $snm2eng1[55], $snm2eng1[56], $snm2eng1[57], $snm2eng1[58], $snm2eng1[59], 
		  $snm2eng1[60], $snm2eng1[61], $snm2eng1[62], $snm2eng1[63], $snm2eng1[64], $snm2eng1[65], $snm2eng1[66], $snm2eng1[67], $snm2eng1[68], $snm2eng1[69], $snm2eng1[70], $snm2eng1[71], $snm2eng1[72], $snm2eng1[73], $snm2eng1[74], $snm2eng1[75], $snm2eng1[76], $snm2eng1[77], $snm2eng1[78], $snm2eng1[79], 
		  $snm2eng1[80], $snm2eng1[81], $snm2eng1[82], $snm2eng1[83], $snm2eng1[84], $snm2eng1[85], $snm2eng1[86], $snm2eng1[87], $snm2eng1[88], $snm2eng1[89], $snm2eng1[90], $snm2eng1[91], $snm2eng1[92], $snm2eng1[93], $snm2eng1[94], $snm2eng1[95], $snm2eng1[96], $snm2eng1[97], $snm2eng1[98], $snm2eng1[99], 
		  $snm2eng1[100], $snm2eng1[101], $snm2eng1[102], $snm2eng1[103], $snm2eng1[104], $snm2eng1[105], $snm2eng1[106], $snm2eng1[107], $snm2eng1[108], $snm2eng1[109], $snm2eng1[110], $snm2eng1[111], $snm2eng1[112], $snm2eng1[113], $snm2eng1[114], $snm2eng1[115], $snm2eng1[116], $snm2eng1[117], $snm2eng1[118], $snm2eng1[119],
		  $snm2eng1[120]);
$foreng2 = array($snm2eng2[0], $snm2eng2[1], $snm2eng2[2], $snm2eng2[3], $snm2eng2[4], $snm2eng2[5], $snm2eng2[6], $snm2eng2[7], $snm2eng2[8], $snm2eng2[9], $snm2eng2[10], $snm2eng2[11], $snm2eng2[12], $snm2eng2[13], $snm2eng2[14], $snm2eng2[15], $snm2eng2[16], $snm2eng2[17], $snm2eng2[18], $snm2eng2[19], 
		  $snm2eng2[20], $snm2eng2[21], $snm2eng2[22], $snm2eng2[23], $snm2eng2[24], $snm2eng2[25], $snm2eng2[26], $snm2eng2[27], $snm2eng2[28], $snm2eng2[29], $snm2eng2[30], $snm2eng2[31], $snm2eng2[32], $snm2eng2[33], $snm2eng2[34], $snm2eng2[35], $snm2eng2[36], $snm2eng2[37], $snm2eng2[38], $snm2eng2[39], 
		  $snm2eng2[40], $snm2eng2[41], $snm2eng2[42], $snm2eng2[43], $snm2eng2[44], $snm2eng2[45], $snm2eng2[46], $snm2eng2[47], $snm2eng2[48], $snm2eng2[49], $snm2eng2[50], $snm2eng2[51], $snm2eng2[52], $snm2eng2[53], $snm2eng2[54], $snm2eng2[55], $snm2eng2[56], $snm2eng2[57], $snm2eng2[58], $snm2eng2[59],
		  $snm2eng2[60], $snm2eng2[61], $snm2eng2[62], $snm2eng2[63], $snm2eng2[64], $snm2eng2[65], $snm2eng2[66], $snm2eng2[67], $snm2eng2[68], $snm2eng2[69], $snm2eng2[70], $snm2eng2[71], $snm2eng2[72], $snm2eng2[73], $snm2eng2[74], $snm2eng2[75], $snm2eng2[76], $snm2eng2[77], $snm2eng2[78], $snm2eng2[79],
		  $snm2eng2[80], $snm2eng2[81], $snm2eng2[82], $snm2eng2[83], $snm2eng2[84], $snm2eng2[85], $snm2eng2[86], $snm2eng2[87], $snm2eng2[88], $snm2eng2[89], $snm2eng2[90], $snm2eng2[91], $snm2eng2[92], $snm2eng2[93], $snm2eng2[94], $snm2eng2[95], $snm2eng2[96], $snm2eng2[97], $snm2eng2[98], $snm2eng2[99],
		   $snm2eng2[100], $snm2eng2[101], $snm2eng2[102], $snm2eng2[103], $snm2eng2[104], $snm2eng2[105], $snm2eng2[106], $snm2eng2[107], $snm2eng2[108], $snm2eng2[109], $snm2eng2[110], $snm2eng2[111], $snm2eng2[112], $snm2eng2[113], $snm2eng2[114], $snm2eng2[115], $snm2eng2[116], $snm2eng2[117], $snm2eng2[118], $snm2eng2[119],
		  $snm2eng2[120]);
$foreng3 = array($snm2eng3[0], $snm2eng3[1], $snm2eng3[2], $snm2eng3[3], $snm2eng3[4], $snm2eng3[5], $snm2eng3[6], $snm2eng3[7], $snm2eng3[8], $snm2eng3[9], $snm2eng3[10], $snm2eng3[11], $snm2eng3[12], $snm2eng3[13], $snm2eng3[14], $snm2eng3[15], $snm2eng3[16], $snm2eng3[17], $snm2eng3[18], $snm2eng3[19],
		  $snm2eng3[20], $snm2eng3[21], $snm2eng3[22], $snm2eng3[23], $snm2eng3[24], $snm2eng3[25], $snm2eng3[26], $snm2eng3[27], $snm2eng3[28], $snm2eng3[29], $snm2eng3[30], $snm2eng3[31], $snm2eng3[32], $snm2eng3[33], $snm2eng3[34], $snm2eng3[35], $snm2eng3[36], $snm2eng3[37], $snm2eng3[38], $snm2eng3[39],
		  $snm2eng3[40], $snm2eng3[41], $snm2eng3[42], $snm2eng3[43], $snm2eng3[44], $snm2eng3[45], $snm2eng3[46], $snm2eng3[47], $snm2eng3[48], $snm2eng3[49], $snm2eng3[50], $snm2eng3[51], $snm2eng3[52], $snm2eng3[53], $snm2eng3[54], $snm2eng3[55], $snm2eng3[56], $snm2eng3[57], $snm2eng3[58], $snm2eng3[59],
		  $snm2eng3[60], $snm2eng3[61], $snm2eng3[62], $snm2eng3[63], $snm2eng3[64], $snm2eng3[65], $snm2eng3[66], $snm2eng3[67], $snm2eng3[68], $snm2eng3[69], $snm2eng3[70], $snm2eng3[71], $snm2eng3[72], $snm2eng3[73], $snm2eng3[74], $snm2eng3[75], $snm2eng3[76], $snm2eng3[77], $snm2eng3[78], $snm2eng3[79],
		  $snm2eng3[80], $snm2eng3[81], $snm2eng3[82], $snm2eng3[83], $snm2eng3[84], $snm2eng3[85], $snm2eng3[86], $snm2eng3[87], $snm2eng3[88], $snm2eng3[89], $snm2eng3[90], $snm2eng3[91], $snm2eng3[92], $snm2eng3[93], $snm2eng3[94], $snm2eng3[95], $snm2eng3[96], $snm2eng3[97], $snm2eng3[98], $snm2eng3[99],
		  $snm2eng3[100], $snm2eng3[101], $snm2eng3[102], $snm2eng3[103], $snm2eng3[104], $snm2eng3[105], $snm2eng3[106], $snm2eng3[107], $snm2eng3[108], $snm2eng3[109], $snm2eng3[110], $snm2eng3[111], $snm2eng3[112], $snm2eng3[113], $snm2eng3[114], $snm2eng3[115], $snm2eng3[116], $snm2eng3[117], $snm2eng3[118], $snm2eng3[119],
		  $snm2eng3[120]);
$array_all_eng = array(array_filter($foreng1), array_filter($foreng2), array_filter($foreng3));
	$countingeng = 0;
	while($countingeng <= 120){
	if(count(array_column($array_all_eng, $countingeng)) == 3){
	$engf2[] = round(array_sum(array_column($array_all_eng, $countingeng))/3);
	}
	else if(count(array_column($array_all_eng, $countingeng)) == 2){
	$engf2[] = round(array_sum(array_column($array_all_eng, $countingeng))/2);
	}
	else if(count(array_column($array_all_eng, $countingeng)) == 1){
	$engf2[] = round(array_sum(array_column($array_all_eng, $countingeng))/1);
	}
	else{
	$engf2[] = round(array_sum(array_column($array_all_eng, $countingeng))/3);	
	}
	$countingeng++;
	}
	$engf = implode("-",array_filter($engf2));
	$engmx2 = explode("-",$engf);
	$engmx = max(explode("-",$engf));
	$stnameandscoreEng = array_combine($acengkeys,$engmx2);
	//print_r($stnameandscoreEng);
	echo '<br>';
	$maxinallsub = $engmx;	
	}
	else if($su == 'Mathematics'){
	$resultmxbystunamemat1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Mathematics' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemat1))
	{	
		$snm2mat1[] = $rsn['score'];
		$stin2mat[] = $rsn['student_name'];
	}
	$acmatf = array_combine($stin2mat,$snm2mat1);
	$resultmxbystunamemat2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Mathematics' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemat2))
	{	
		$snm2mat2[] = $rsn['score'];
	    $stin2mat2[] = $rsn['student_name'];
	}
	$acmats = array_combine($stin2mat2,$snm2mat2);
	$resultmxbystunamemat3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Mathematics' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemat3))
	{	
		$snm2mat3[] = $rsn['score'];
		$stin2mat3[] = $rsn['student_name'];
	}
	$acmatt = array_combine($stin2mat3,$snm2mat3);
	$arinall = array($acmatf, $acmats, $acmatt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acmatkeys = (array_keys($largest_arr));
	
$format1 = 	array($snm2mat1[0], $snm2mat1[1], $snm2mat1[2], $snm2mat1[3], $snm2mat1[4], $snm2mat1[5], $snm2mat1[6], $snm2mat1[7], $snm2mat1[8], $snm2mat1[9], $snm2mat1[10], $snm2mat1[11], $snm2mat1[12], $snm2mat1[13], $snm2mat1[14], $snm2mat1[15], $snm2mat1[16], $snm2mat1[17], $snm2mat1[18], $snm2mat1[19], 
		  $snm2mat1[20], $snm2mat1[21], $snm2mat1[22], $snm2mat1[23], $snm2mat1[24], $snm2mat1[25], $snm2mat1[26], $snm2mat1[27], $snm2mat1[28], $snm2mat1[29], $snm2mat1[30], $snm2mat1[31], $snm2mat1[32], $snm2mat1[33], $snm2mat1[34], $snm2mat1[35], $snm2mat1[36], $snm2mat1[37], $snm2mat1[38], $snm2mat1[39], 
		  $snm2mat1[40], $snm2mat1[41], $snm2mat1[42], $snm2mat1[43], $snm2mat1[44], $snm2mat1[45], $snm2mat1[46], $snm2mat1[47], $snm2mat1[48], $snm2mat1[49], $snm2mat1[50], $snm2mat1[51], $snm2mat1[52], $snm2mat1[53], $snm2mat1[54], $snm2mat1[55], $snm2mat1[56], $snm2mat1[57], $snm2mat1[58], $snm2mat1[59], 
		  $snm2mat1[60], $snm2mat1[61], $snm2mat1[62], $snm2mat1[63], $snm2mat1[64], $snm2mat1[65], $snm2mat1[66], $snm2mat1[67], $snm2mat1[68], $snm2mat1[69], $snm2mat1[70], $snm2mat1[71], $snm2mat1[72], $snm2mat1[73], $snm2mat1[74], $snm2mat1[75], $snm2mat1[76], $snm2mat1[77], $snm2mat1[78], $snm2mat1[79], 
		  $snm2mat1[80], $snm2mat1[81], $snm2mat1[82], $snm2mat1[83], $snm2mat1[84], $snm2mat1[85], $snm2mat1[86], $snm2mat1[87], $snm2mat1[88], $snm2mat1[89], $snm2mat1[90], $snm2mat1[91], $snm2mat1[92], $snm2mat1[93], $snm2mat1[94], $snm2mat1[95], $snm2mat1[96], $snm2mat1[97], $snm2mat1[98], $snm2mat1[99], 
		  $snm2mat1[100], $snm2mat1[101], $snm2mat1[102], $snm2mat1[103], $snm2mat1[104], $snm2mat1[105], $snm2mat1[106], $snm2mat1[107], $snm2mat1[108], $snm2mat1[109], $snm2mat1[110], $snm2mat1[111], $snm2mat1[112], $snm2mat1[113], $snm2mat1[114], $snm2mat1[115], $snm2mat1[116], $snm2mat1[117], $snm2mat1[118], $snm2mat1[119],
		  $snm2mat1[120]);
$format2 = 	array($snm2mat2[0], $snm2mat2[1], $snm2mat2[2], $snm2mat2[3], $snm2mat2[4], $snm2mat2[5], $snm2mat2[6], $snm2mat2[7], $snm2mat2[8], $snm2mat2[9], $snm2mat2[10], $snm2mat2[11], $snm2mat2[12], $snm2mat2[13], $snm2mat2[14], $snm2mat2[15], $snm2mat2[16], $snm2mat2[17], $snm2mat2[18], $snm2mat2[19], 
		  $snm2mat2[20], $snm2mat2[21], $snm2mat2[22], $snm2mat2[23], $snm2mat2[24], $snm2mat2[25], $snm2mat2[26], $snm2mat2[27], $snm2mat2[28], $snm2mat2[29], $snm2mat2[30], $snm2mat2[31], $snm2mat2[32], $snm2mat2[33], $snm2mat2[34], $snm2mat2[35], $snm2mat2[36], $snm2mat2[37], $snm2mat2[38], $snm2mat2[39], 
		  $snm2mat2[40], $snm2mat2[41], $snm2mat2[42], $snm2mat2[43], $snm2mat2[44], $snm2mat2[45], $snm2mat2[46], $snm2mat2[47], $snm2mat2[48], $snm2mat2[49], $snm2mat2[50], $snm2mat2[51], $snm2mat2[52], $snm2mat2[53], $snm2mat2[54], $snm2mat2[55], $snm2mat2[56], $snm2mat2[57], $snm2mat2[58], $snm2mat2[59],
		  $snm2mat2[60], $snm2mat2[61], $snm2mat2[62], $snm2mat2[63], $snm2mat2[64], $snm2mat2[65], $snm2mat2[66], $snm2mat2[67], $snm2mat2[68], $snm2mat2[69], $snm2mat2[70], $snm2mat2[71], $snm2mat2[72], $snm2mat2[73], $snm2mat2[74], $snm2mat2[75], $snm2mat2[76], $snm2mat2[77], $snm2mat2[78], $snm2mat2[79],
		  $snm2mat2[80], $snm2mat2[81], $snm2mat2[82], $snm2mat2[83], $snm2mat2[84], $snm2mat2[85], $snm2mat2[86], $snm2mat2[87], $snm2mat2[88], $snm2mat2[89], $snm2mat2[90], $snm2mat2[91], $snm2mat2[92], $snm2mat2[93], $snm2mat2[94], $snm2mat2[95], $snm2mat2[96], $snm2mat2[97], $snm2mat2[98], $snm2mat2[99],
		   $snm2mat2[100], $snm2mat2[101], $snm2mat2[102], $snm2mat2[103], $snm2mat2[104], $snm2mat2[105], $snm2mat2[106], $snm2mat2[107], $snm2mat2[108], $snm2mat2[109], $snm2mat2[110], $snm2mat2[111], $snm2mat2[112], $snm2mat2[113], $snm2mat2[114], $snm2mat2[115], $snm2mat2[116], $snm2mat2[117], $snm2mat2[118], $snm2mat2[119],
		  $snm2mat2[120]);
$format3 = 	array($snm2mat3[0], $snm2mat3[1], $snm2mat3[2], $snm2mat3[3], $snm2mat3[4], $snm2mat3[5], $snm2mat3[6], $snm2mat3[7], $snm2mat3[8], $snm2mat3[9], $snm2mat3[10], $snm2mat3[11], $snm2mat3[12], $snm2mat3[13], $snm2mat3[14], $snm2mat3[15], $snm2mat3[16], $snm2mat3[17], $snm2mat3[18], $snm2mat3[19],
		  $snm2mat3[20], $snm2mat3[21], $snm2mat3[22], $snm2mat3[23], $snm2mat3[24], $snm2mat3[25], $snm2mat3[26], $snm2mat3[27], $snm2mat3[28], $snm2mat3[29], $snm2mat3[30], $snm2mat3[31], $snm2mat3[32], $snm2mat3[33], $snm2mat3[34], $snm2mat3[35], $snm2mat3[36], $snm2mat3[37], $snm2mat3[38], $snm2mat3[39],
		  $snm2mat3[40], $snm2mat3[41], $snm2mat3[42], $snm2mat3[43], $snm2mat3[44], $snm2mat3[45], $snm2mat3[46], $snm2mat3[47], $snm2mat3[48], $snm2mat3[49], $snm2mat3[50], $snm2mat3[51], $snm2mat3[52], $snm2mat3[53], $snm2mat3[54], $snm2mat3[55], $snm2mat3[56], $snm2mat3[57], $snm2mat3[58], $snm2mat3[59],
		  $snm2mat3[60], $snm2mat3[61], $snm2mat3[62], $snm2mat3[63], $snm2mat3[64], $snm2mat3[65], $snm2mat3[66], $snm2mat3[67], $snm2mat3[68], $snm2mat3[69], $snm2mat3[70], $snm2mat3[71], $snm2mat3[72], $snm2mat3[73], $snm2mat3[74], $snm2mat3[75], $snm2mat3[76], $snm2mat3[77], $snm2mat3[78], $snm2mat3[79],
		  $snm2mat3[80], $snm2mat3[81], $snm2mat3[82], $snm2mat3[83], $snm2mat3[84], $snm2mat3[85], $snm2mat3[86], $snm2mat3[87], $snm2mat3[88], $snm2mat3[89], $snm2mat3[90], $snm2mat3[91], $snm2mat3[92], $snm2mat3[93], $snm2mat3[94], $snm2mat3[95], $snm2mat3[96], $snm2mat3[97], $snm2mat3[98], $snm2mat3[99],
		  $snm2mat3[100], $snm2mat3[101], $snm2mat3[102], $snm2mat3[103], $snm2mat3[104], $snm2mat3[105], $snm2mat3[106], $snm2mat3[107], $snm2mat3[108], $snm2mat3[109], $snm2mat3[110], $snm2mat3[111], $snm2mat3[112], $snm2mat3[113], $snm2mat3[114], $snm2mat3[115], $snm2mat3[116], $snm2mat3[117], $snm2mat3[118], $snm2mat3[119],
		  $snm2mat3[120]);	  
	$array_all_mat = array(array_filter($format1), array_filter($format2), array_filter($format3));
	$countingmat = 0;
	while($countingmat <= 120){
	if(count(array_column($array_all_mat, $countingmat)) == 3){
	$matf2[] = round(array_sum(array_column($array_all_mat, $countingmat))/3);
	}
	else if(count(array_column($array_all_mat, $countingmat)) == 2){
	$matf2[] = round(array_sum(array_column($array_all_mat, $countingmat))/2);
	}
	else if(count(array_column($array_all_mat, $countingmat)) == 1){
	$matf2[] = round(array_sum(array_column($array_all_mat, $countingmat))/1);
	}
	else{
	$matf2[] = round(array_sum(array_column($array_all_mat, $countingmat))/3);	
	}
	$countingmat++;
	}
	$matf = implode("-",array_filter($matf2));
	$matmx2 = explode("-",$matf);
	$matmx = max(explode("-",$matf));
	$stnameandscoreMat = array_combine($acmatkeys,$matmx2);
	//print_r($stnameandscoreMat);
	//echo '<br>';
	$maxinallsub = $matmx;		
	}
	
	else if($su == 'French'){
	$resultmxbystunamefre1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='French' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefre1))
	{	
		$snm2fre1[] = $rsn['score'];
		$stin2fre[] = $rsn['student_name'];
	}
	$acfref = array_combine($stin2fre,$snm2fre1);
	$resultmxbystunamefre2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='French' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefre2))
	{	
		$snm2fre2[] = $rsn['score'];
	    $stin2fre2[] = $rsn['student_name'];
	}
	$acfres = array_combine($stin2fre2,$snm2fre2);
	$resultmxbystunamefre3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='French' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefre3))
	{	
		$snm2fre3[] = $rsn['score'];
		$stin2fre3[] = $rsn['student_name'];
	}
	$acfret = array_combine($stin2fre3,$snm2fre3);
	$arinall = array($acfref, $acfres, $acfret);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acfrekeys = (array_keys($largest_arr));
$forfre1 = 	array($snm2fre1[0], $snm2fre1[1], $snm2fre1[2], $snm2fre1[3], $snm2fre1[4], $snm2fre1[5], $snm2fre1[6], $snm2fre1[7], $snm2fre1[8], $snm2fre1[9], $snm2fre1[10], $snm2fre1[11], $snm2fre1[12], $snm2fre1[13], $snm2fre1[14], $snm2fre1[15], $snm2fre1[16], $snm2fre1[17], $snm2fre1[18], $snm2fre1[19], 
		  $snm2fre1[20], $snm2fre1[21], $snm2fre1[22], $snm2fre1[23], $snm2fre1[24], $snm2fre1[25], $snm2fre1[26], $snm2fre1[27], $snm2fre1[28], $snm2fre1[29], $snm2fre1[30], $snm2fre1[31], $snm2fre1[32], $snm2fre1[33], $snm2fre1[34], $snm2fre1[35], $snm2fre1[36], $snm2fre1[37], $snm2fre1[38], $snm2fre1[39], 
		  $snm2fre1[40], $snm2fre1[41], $snm2fre1[42], $snm2fre1[43], $snm2fre1[44], $snm2fre1[45], $snm2fre1[46], $snm2fre1[47], $snm2fre1[48], $snm2fre1[49], $snm2fre1[50], $snm2fre1[51], $snm2fre1[52], $snm2fre1[53], $snm2fre1[54], $snm2fre1[55], $snm2fre1[56], $snm2fre1[57], $snm2fre1[58], $snm2fre1[59], 
		  $snm2fre1[60], $snm2fre1[61], $snm2fre1[62], $snm2fre1[63], $snm2fre1[64], $snm2fre1[65], $snm2fre1[66], $snm2fre1[67], $snm2fre1[68], $snm2fre1[69], $snm2fre1[70], $snm2fre1[71], $snm2fre1[72], $snm2fre1[73], $snm2fre1[74], $snm2fre1[75], $snm2fre1[76], $snm2fre1[77], $snm2fre1[78], $snm2fre1[79], 
		  $snm2fre1[80], $snm2fre1[81], $snm2fre1[82], $snm2fre1[83], $snm2fre1[84], $snm2fre1[85], $snm2fre1[86], $snm2fre1[87], $snm2fre1[88], $snm2fre1[89], $snm2fre1[90], $snm2fre1[91], $snm2fre1[92], $snm2fre1[93], $snm2fre1[94], $snm2fre1[95], $snm2fre1[96], $snm2fre1[97], $snm2fre1[98], $snm2fre1[99], 
		  $snm2fre1[100], $snm2fre1[101], $snm2fre1[102], $snm2fre1[103], $snm2fre1[104], $snm2fre1[105], $snm2fre1[106], $snm2fre1[107], $snm2fre1[108], $snm2fre1[109], $snm2fre1[110], $snm2fre1[111], $snm2fre1[112], $snm2fre1[113], $snm2fre1[114], $snm2fre1[115], $snm2fre1[116], $snm2fre1[117], $snm2fre1[118], $snm2fre1[119],
		  $snm2fre1[120]);
$forfre2 = 	array($snm2fre2[0], $snm2fre2[1], $snm2fre2[2], $snm2fre2[3], $snm2fre2[4], $snm2fre2[5], $snm2fre2[6], $snm2fre2[7], $snm2fre2[8], $snm2fre2[9], $snm2fre2[10], $snm2fre2[11], $snm2fre2[12], $snm2fre2[13], $snm2fre2[14], $snm2fre2[15], $snm2fre2[16], $snm2fre2[17], $snm2fre2[18], $snm2fre2[19], 
		  $snm2fre2[20], $snm2fre2[21], $snm2fre2[22], $snm2fre2[23], $snm2fre2[24], $snm2fre2[25], $snm2fre2[26], $snm2fre2[27], $snm2fre2[28], $snm2fre2[29], $snm2fre2[30], $snm2fre2[31], $snm2fre2[32], $snm2fre2[33], $snm2fre2[34], $snm2fre2[35], $snm2fre2[36], $snm2fre2[37], $snm2fre2[38], $snm2fre2[39], 
		  $snm2fre2[40], $snm2fre2[41], $snm2fre2[42], $snm2fre2[43], $snm2fre2[44], $snm2fre2[45], $snm2fre2[46], $snm2fre2[47], $snm2fre2[48], $snm2fre2[49], $snm2fre2[50], $snm2fre2[51], $snm2fre2[52], $snm2fre2[53], $snm2fre2[54], $snm2fre2[55], $snm2fre2[56], $snm2fre2[57], $snm2fre2[58], $snm2fre2[59],
		  $snm2fre2[60], $snm2fre2[61], $snm2fre2[62], $snm2fre2[63], $snm2fre2[64], $snm2fre2[65], $snm2fre2[66], $snm2fre2[67], $snm2fre2[68], $snm2fre2[69], $snm2fre2[70], $snm2fre2[71], $snm2fre2[72], $snm2fre2[73], $snm2fre2[74], $snm2fre2[75], $snm2fre2[76], $snm2fre2[77], $snm2fre2[78], $snm2fre2[79],
		  $snm2fre2[80], $snm2fre2[81], $snm2fre2[82], $snm2fre2[83], $snm2fre2[84], $snm2fre2[85], $snm2fre2[86], $snm2fre2[87], $snm2fre2[88], $snm2fre2[89], $snm2fre2[90], $snm2fre2[91], $snm2fre2[92], $snm2fre2[93], $snm2fre2[94], $snm2fre2[95], $snm2fre2[96], $snm2fre2[97], $snm2fre2[98], $snm2fre2[99],
		   $snm2fre2[100], $snm2fre2[101], $snm2fre2[102], $snm2fre2[103], $snm2fre2[104], $snm2fre2[105], $snm2fre2[106], $snm2fre2[107], $snm2fre2[108], $snm2fre2[109], $snm2fre2[110], $snm2fre2[111], $snm2fre2[112], $snm2fre2[113], $snm2fre2[114], $snm2fre2[115], $snm2fre2[116], $snm2fre2[117], $snm2fre2[118], $snm2fre2[119],
		  $snm2fre2[120]);
$forfre3 = 	array($snm2fre3[0], $snm2fre3[1], $snm2fre3[2], $snm2fre3[3], $snm2fre3[4], $snm2fre3[5], $snm2fre3[6], $snm2fre3[7], $snm2fre3[8], $snm2fre3[9], $snm2fre3[10], $snm2fre3[11], $snm2fre3[12], $snm2fre3[13], $snm2fre3[14], $snm2fre3[15], $snm2fre3[16], $snm2fre3[17], $snm2fre3[18], $snm2fre3[19],
		  $snm2fre3[20], $snm2fre3[21], $snm2fre3[22], $snm2fre3[23], $snm2fre3[24], $snm2fre3[25], $snm2fre3[26], $snm2fre3[27], $snm2fre3[28], $snm2fre3[29], $snm2fre3[30], $snm2fre3[31], $snm2fre3[32], $snm2fre3[33], $snm2fre3[34], $snm2fre3[35], $snm2fre3[36], $snm2fre3[37], $snm2fre3[38], $snm2fre3[39],
		  $snm2fre3[40], $snm2fre3[41], $snm2fre3[42], $snm2fre3[43], $snm2fre3[44], $snm2fre3[45], $snm2fre3[46], $snm2fre3[47], $snm2fre3[48], $snm2fre3[49], $snm2fre3[50], $snm2fre3[51], $snm2fre3[52], $snm2fre3[53], $snm2fre3[54], $snm2fre3[55], $snm2fre3[56], $snm2fre3[57], $snm2fre3[58], $snm2fre3[59],
		  $snm2fre3[60], $snm2fre3[61], $snm2fre3[62], $snm2fre3[63], $snm2fre3[64], $snm2fre3[65], $snm2fre3[66], $snm2fre3[67], $snm2fre3[68], $snm2fre3[69], $snm2fre3[70], $snm2fre3[71], $snm2fre3[72], $snm2fre3[73], $snm2fre3[74], $snm2fre3[75], $snm2fre3[76], $snm2fre3[77], $snm2fre3[78], $snm2fre3[79],
		  $snm2fre3[80], $snm2fre3[81], $snm2fre3[82], $snm2fre3[83], $snm2fre3[84], $snm2fre3[85], $snm2fre3[86], $snm2fre3[87], $snm2fre3[88], $snm2fre3[89], $snm2fre3[90], $snm2fre3[91], $snm2fre3[92], $snm2fre3[93], $snm2fre3[94], $snm2fre3[95], $snm2fre3[96], $snm2fre3[97], $snm2fre3[98], $snm2fre3[99],
		  $snm2fre3[100], $snm2fre3[101], $snm2fre3[102], $snm2fre3[103], $snm2fre3[104], $snm2fre3[105], $snm2fre3[106], $snm2fre3[107], $snm2fre3[108], $snm2fre3[109], $snm2fre3[110], $snm2fre3[111], $snm2fre3[112], $snm2fre3[113], $snm2fre3[114], $snm2fre3[115], $snm2fre3[116], $snm2fre3[117], $snm2fre3[118], $snm2fre3[119],
		  $snm2fre3[120]);	  
	$array_all_fre = array(array_filter($forfre1), array_filter($forfre2), array_filter($forfre3));
	$countingfre = 0;
	while($countingfre <= 120){
	if(count(array_column($array_all_fre, $countingfre)) == 3){
	$fref2[] = round(array_sum(array_column($array_all_fre, $countingfre))/3);
	}
	else if(count(array_column($array_all_fre, $countingfre)) == 2){
	$fref2[] = round(array_sum(array_column($array_all_fre, $countingfre))/2);
	}
	else if(count(array_column($array_all_fre, $countingfre)) == 1){
	$fref2[] = round(array_sum(array_column($array_all_fre, $countingfre))/1);
	}
	else{
	$fref2[] = round(array_sum(array_column($array_all_fre, $countingfre))/3);	
	}
	$countingfre++;
	}
	$fref = implode("-",array_filter($fref2));
	$fremx2 = explode("-",$fref);
	$fremx = max(explode("-",$fref));
	$stnameandscoreFre = array_combine($acfrekeys,$fremx2);
	//print_r($stnameandscoreFre);
	//echo '<br>';
	$maxinallsub = $fremx;		
	}
	
	else if($su == 'Agricultural Science'){
		$resultmxbystunameagr1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Agricultural Science' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameagr1))
	{	
		$snm2agr1[] = $rsn['score'];
		$stin2agr[] = $rsn['student_name'];
	}
	$acagrf = array_combine($stin2agr,$snm2agr1);
	$resultmxbystunameagr2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Agricultural Science' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameagr2))
	{	
		$snm2agr2[] = $rsn['score'];
	    $stin2agr2[] = $rsn['student_name'];
	}
	$acagrs = array_combine($stin2agr2,$snm2agr2);
	$resultmxbystunameagr3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Agricultural Science' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameagr3))
	{	
		$snm2agr3[] = $rsn['score'];
		$stin2agr3[] = $rsn['student_name'];
	}
	$acagrt = array_combine($stin2agr3,$snm2agr3);
	$arinall = array($acagrf, $acagrs, $acagrt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acagrkeys = (array_keys($largest_arr));
$foragr1 = 	array($snm2agr1[0], $snm2agr1[1], $snm2agr1[2], $snm2agr1[3], $snm2agr1[4], $snm2agr1[5], $snm2agr1[6], $snm2agr1[7], $snm2agr1[8], $snm2agr1[9], $snm2agr1[10], $snm2agr1[11], $snm2agr1[12], $snm2agr1[13], $snm2agr1[14], $snm2agr1[15], $snm2agr1[16], $snm2agr1[17], $snm2agr1[18], $snm2agr1[19], 
		  $snm2agr1[20], $snm2agr1[21], $snm2agr1[22], $snm2agr1[23], $snm2agr1[24], $snm2agr1[25], $snm2agr1[26], $snm2agr1[27], $snm2agr1[28], $snm2agr1[29], $snm2agr1[30], $snm2agr1[31], $snm2agr1[32], $snm2agr1[33], $snm2agr1[34], $snm2fre1[35], $snm2agr1[36], $snm2agr1[37], $snm2agr1[38], $snm2agr1[39], 
		  $snm2agr1[40], $snm2agr1[41], $snm2agr1[42], $snm2agr1[43], $snm2agr1[44], $snm2agr1[45], $snm2agr1[46], $snm2agr1[47], $snm2agr1[48], $snm2agr1[49], $snm2agr1[50], $snm2agr1[51], $snm2agr1[52], $snm2agr1[53], $snm2agr1[54], $snm2fre1[55], $snm2agr1[56], $snm2agr1[57], $snm2agr1[58], $snm2agr1[59], 
		  $snm2agr1[60], $snm2agr1[61], $snm2agr1[62], $snm2agr1[63], $snm2agr1[64], $snm2agr1[65], $snm2agr1[66], $snm2agr1[67], $snm2agr1[68], $snm2agr1[69], $snm2agr1[70], $snm2agr1[71], $snm2agr1[72], $snm2agr1[73], $snm2agr1[74], $snm2fre1[75], $snm2agr1[76], $snm2agr1[77], $snm2agr1[78], $snm2agr1[79], 
		  $snm2agr1[80], $snm2agr1[81], $snm2agr1[82], $snm2agr1[83], $snm2agr1[84], $snm2agr1[85], $snm2agr1[86], $snm2agr1[87], $snm2agr1[88], $snm2agr1[89], $snm2agr1[90], $snm2agr1[91], $snm2agr1[92], $snm2agr1[93], $snm2agr1[94], $snm2fre1[95], $snm2agr1[96], $snm2agr1[97], $snm2agr1[98], $snm2agr1[99], 
		  $snm2agr1[100], $snm2agr1[101], $snm2agr1[102], $snm2agr1[103], $snm2agr1[104], $snm2agr1[105], $snm2agr1[106], $snm2agr1[107], $snm2agr1[108], $snm2agr1[109], $snm2agr1[110], $snm2agr1[111], $snm2agr1[112], $snm2agr1[113], $snm2agr1[114], $snm2agr1[115], $snm2agr1[116], $snm2agr1[117], $snm2agr1[118], $snm2agr1[119],
		  $snm2agr1[120]);
$foragr2 = 	array($snm2agr2[0], $snm2agr2[1], $snm2agr2[2], $snm2agr2[3], $snm2agr2[4], $snm2agr2[5], $snm2agr2[6], $snm2agr2[7], $snm2agr2[8], $snm2agr2[9], $snm2agr2[10], $snm2agr2[11], $snm2agr2[12], $snm2agr2[13], $snm2agr2[14], $snm2agr2[15], $snm2agr2[16], $snm2agr2[17], $snm2agr2[18], $snm2agr2[19], 
		  $snm2agr2[20], $snm2agr2[21], $snm2agr2[22], $snm2agr2[23], $snm2agr2[24], $snm2agr2[25], $snm2agr2[26], $snm2agr2[27], $snm2agr2[28], $snm2agr2[29], $snm2agr2[30], $snm2agr2[31], $snm2agr2[32], $snm2agr2[33], $snm2agr2[34], $snm2agr2[35], $snm2agr2[36], $snm2agr2[37], $snm2agr2[38], $snm2agr2[39], 
		  $snm2agr2[40], $snm2agr2[41], $snm2agr2[42], $snm2agr2[43], $snm2fre2[44], $snm2agr2[45], $snm2agr2[46], $snm2agr2[47], $snm2agr2[48], $snm2agr2[49], $snm2agr2[50], $snm2agr2[51], $snm2agr2[52], $snm2agr2[53], $snm2agr2[54], $snm2agr2[55], $snm2agr2[56], $snm2agr2[57], $snm2agr2[58], $snm2agr2[59],
		  $snm2agr2[60], $snm2agr2[61], $snm2agr2[62], $snm2agr2[63], $snm2fre2[64], $snm2agr2[65], $snm2agr2[66], $snm2agr2[67], $snm2agr2[68], $snm2agr2[69], $snm2agr2[70], $snm2agr2[71], $snm2agr2[72], $snm2agr2[73], $snm2agr2[74], $snm2agr2[75], $snm2agr2[76], $snm2agr2[77], $snm2agr2[78], $snm2agr2[79],
		  $snm2agr2[80], $snm2agr2[81], $snm2agr2[82], $snm2agr2[83], $snm2fre2[84], $snm2agr2[85], $snm2agr2[86], $snm2agr2[87], $snm2agr2[88], $snm2agr2[89], $snm2agr2[90], $snm2agr2[91], $snm2agr2[92], $snm2agr2[93], $snm2agr2[94], $snm2agr2[95], $snm2agr2[96], $snm2agr2[97], $snm2agr2[98], $snm2agr2[99],
		   $snm2agr2[100], $snm2agr2[101], $snm2agr2[102], $snm2agr2[103], $snm2agr2[104], $snm2agr2[105], $snm2agr2[106], $snm2agr2[107], $snm2agr2[108], $snm2agr2[109], $snm2agr2[110], $snm2agr2[111], $snm2agr2[112], $snm2agr2[113], $snm2agr2[114], $snm2agr2[115], $snm2agr2[116], $snm2agr2[117], $snm2agr2[118], $snm2agr2[119],
		  $snm2agr2[120]);
$foragr3 = 	array($snm2agr3[0], $snm2agr3[1], $snm2agr3[2], $snm2agr3[3], $snm2agr3[4], $snm2agr3[5], $snm2agr3[6], $snm2agr3[7], $snm2agr3[8], $snm2agr3[9], $snm2agr3[10], $snm2agr3[11], $snm2agr3[12], $snm2agr3[13], $snm2agr3[14], $snm2agr3[15], $snm2agr3[16], $snm2agr3[17], $snm2agr3[18], $snm2agr3[19],
		  $snm2agr3[20], $snm2agr3[21], $snm2agr3[22], $snm2agr3[23], $snm2agr3[24], $snm2agr3[25], $snm2agr3[26], $snm2agr3[27], $snm2agr3[28], $snm2agr3[29], $snm2agr3[30], $snm2agr3[31], $snm2agr3[32], $snm2agr3[33], $snm2agr3[34], $snm2agr3[35], $snm2agr3[36], $snm2agr3[37], $snm2agr3[38], $snm2agr3[39], 
		  $snm2agr3[41], $snm2agr3[41], $snm2agr3[42], $snm2agr3[43], $snm2agr3[44], $snm2agr3[45], $snm2agr3[46], $snm2agr3[47], $snm2agr3[48], $snm2agr3[49], $snm2agr3[50], $snm2agr3[51], $snm2agr3[52], $snm2agr3[53], $snm2agr3[54], $snm2agr3[55], $snm2agr3[56], $snm2agr3[57], $snm2agr3[58], $snm2agr3[59],
		  $snm2agr3[60], $snm2agr3[61], $snm2agr3[62], $snm2agr3[63], $snm2agr3[64], $snm2agr3[65], $snm2agr3[66], $snm2agr3[67], $snm2agr3[68], $snm2agr3[69], $snm2agr3[70], $snm2agr3[71], $snm2agr3[72], $snm2agr3[73], $snm2agr3[74], $snm2agr3[75], $snm2agr3[76], $snm2agr3[77], $snm2agr3[78], $snm2agr3[79],
		  $snm2agr3[80], $snm2agr3[81], $snm2agr3[82], $snm2agr3[83], $snm2agr3[84], $snm2agr3[85], $snm2agr3[86], $snm2agr3[87], $snm2agr3[88], $snm2agr3[89], $snm2agr3[90], $snm2agr3[91], $snm2agr3[92], $snm2agr3[93], $snm2agr3[94], $snm2agr3[95], $snm2agr3[96], $snm2agr3[97], $snm2agr3[98], $snm2agr3[99],
		  $snm2agr3[100], $snm2agr3[101], $snm2agr3[102], $snm2agr3[103], $snm2agr3[104], $snm2agr3[105], $snm2agr3[106], $snm2agr3[107], $snm2agr3[108], $snm2agr3[109], $snm2agr3[110], $snm2agr3[111], $snm2agr3[112], $snm2agr3[113], $snm2agr3[114], $snm2agr3[115], $snm2agr3[116], $snm2agr3[117], $snm2agr3[118], $snm2agr3[119],
		  $snm2agr3[120]);	  
	$array_all_agr = array(array_filter($foragr1), array_filter($foragr2), array_filter($foragr3));
	$countingagr = 0;
	while($countingagr <= 120){
	if(count(array_column($array_all_agr, $countingagr)) == 3){
	$agrf2[] = round(array_sum(array_column($array_all_agr, $countingagr))/3);
	}
	else if(count(array_column($array_all_agr, $countingagr)) == 2){
	$agrf2[] = round(array_sum(array_column($array_all_agr, $countingagr))/2);
	}
	else if(count(array_column($array_all_agr, $countingagr)) == 1){
	$agrf2[] = round(array_sum(array_column($array_all_agr, $countingagr))/1);
	}
	else{
	$agrf2[] = round(array_sum(array_column($array_all_agr, $countingagr))/3);	
	}
	$countingagr++;
	}
	$agrf = implode("-",array_filter($agrf2));
	$agrmx2 = explode("-",$agrf);
	$agrmx = max(explode("-",$agrf));
	$stnameandscoreAgr = array_combine($acagrkeys,$agrmx2);
	//print_r($stnameandscoreAgr);
	//echo '<br>';
	$maxinallsub = $agrmx;	
	}
	else if($su == 'Basic Science'){
		$resultmxbystunamebas1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Basic Science' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebas1))
	{	
		$snm2bas1[] = $rsn['score'];
		$stin2bas[] = $rsn['student_name'];
	}
	$acbasf = array_combine($stin2bas,$snm2bas1);
	$resultmxbystunamebas2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Basic Science' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebas2))
	{	
		$snm2bas2[] = $rsn['score'];
	    $stin2bas2[] = $rsn['student_name'];
	}
	$acbass = array_combine($stin2bas2,$snm2bas2);
	$resultmxbystunamebas3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Basic Science' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebas3))
	{	
		$snm2bas3[] = $rsn['score'];
		$stin2bas3[] = $rsn['student_name'];
	}
	$acbast = array_combine($stin2bas3,$snm2bas3);
	$arinall = array($acbasf, $acbass, $acbast);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acbaskeys = (array_keys($largest_arr));
$forbas1 = 	array($snm2bas1[0], $snm2bas1[1], $snm2bas1[2], $snm2bas1[3], $snm2bas1[4], $snm2bas1[5], $snm2bas1[6], $snm2bas1[7], $snm2bas1[8], $snm2bas1[9], $snm2bas1[10], $snm2bas1[11], $snm2bas1[12], $snm2bas1[13], $snm2bas1[14], $snm2bas1[15], $snm2bas1[16], $snm2bas1[17], $snm2bas1[18], $snm2bas1[19], 
		  $snm2bas1[20], $snm2bas1[21], $snm2bas1[22], $snm2bas1[23], $snm2bas1[24], $snm2bas1[25], $snm2bas1[26], $snm2bas1[27], $snm2bas1[28], $snm2bas1[29], $snm2bas1[30], $snm2bas1[31], $snm2bas1[32], $snm2bas1[33], $snm2bas1[34], $snm2bas1[35], $snm2bas1[36], $snm2bas1[37], $snm2bas1[38], $snm2bas1[39], 
		  $snm2bas1[40], $snm2bas1[41], $snm2bas1[42], $snm2bas1[43], $snm2bas1[44], $snm2bas1[45], $snm2bas1[46], $snm2bas1[47], $snm2bas1[48], $snm2bas1[49], $snm2bas1[50], $snm2bas1[51], $snm2bas1[52], $snm2bas1[53], $snm2bas1[54], $snm2bas1[55], $snm2bas1[56], $snm2bas1[57], $snm2bas1[58], $snm2bas1[59], 
		  $snm2bas1[60], $snm2bas1[61], $snm2bas1[62], $snm2bas1[63], $snm2bas1[64], $snm2bas1[65], $snm2bas1[66], $snm2bas1[67], $snm2bas1[68], $snm2bas1[69], $snm2bas1[70], $snm2bas1[71], $snm2bas1[72], $snm2bas1[73], $snm2bas1[74], $snm2bas1[75], $snm2bas1[76], $snm2bas1[77], $snm2bas1[78], $snm2bas1[79], 
		  $snm2bas1[80], $snm2bas1[81], $snm2bas1[82], $snm2bas1[83], $snm2bas1[84], $snm2bas1[85], $snm2bas1[86], $snm2bas1[87], $snm2bas1[88], $snm2bas1[89], $snm2bas1[90], $snm2bas1[91], $snm2bas1[92], $snm2bas1[93], $snm2bas1[94], $snm2bas1[95], $snm2bas1[96], $snm2bas1[97], $snm2bas1[98], $snm2bas1[99], 
		  $snm2bas1[100], $snm2bas1[101], $snm2bas1[102], $snm2bas1[103], $snm2bas1[104], $snm2bas1[105], $snm2bas1[106], $snm2bas1[107], $snm2bas1[108], $snm2bas1[109], $snm2bas1[110], $snm2bas1[111], $snm2bas1[112], $snm2bas1[113], $snm2bas1[114], $snm2bas1[115], $snm2bas1[116], $snm2bas1[117], $snm2bas1[118], $snm2bas1[119], 
		  $snm2bas1[120]);
$foragr2 = 	array($snm2bas2[0], $snm2bas2[1], $snm2bas2[2], $snm2bas2[3], $snm2bas2[4], $snm2bas2[5], $snm2bas2[6], $snm2bas2[7], $snm2bas2[8], $snm2bas2[9], $snm2bas2[10], $snm2bas2[11], $snm2bas1[12], $snm2bas2[13], $snm2bas2[14], $snm2bas2[15], $snm2bas2[16], $snm2bas2[17], $snm2bas2[18], $snm2bas2[19], 
		  $snm2bas2[20], $snm2bas2[21], $snm2bas2[22], $snm2bas2[23], $snm2bas2[24], $snm2bas2[25], $snm2bas2[26], $snm2bas2[27], $snm2bas2[28], $snm2bas2[29], $snm2bas2[30], $snm2bas2[31], $snm2bas2[32], $snm2bas2[33], $snm2bas2[34], $snm2bas2[35], $snm2bas2[36], $snm2bas2[37], $snm2bas2[38], $snm2bas2[39], 
		  $snm2bas2[40], $snm2bas2[41], $snm2bas2[42], $snm2bas2[43], $snm2bas2[44], $snm2bas2[45], $snm2bas2[46], $snm2bas2[47], $snm2bas2[48], $snm2bas2[49], $snm2bas2[50], $snm2bas2[51], $snm2bas2[52], $snm2bas2[53], $snm2bas2[54], $snm2bas2[55], $snm2bas2[56], $snm2bas2[57], $snm2bas2[58], $snm2bas2[59], 
		  $snm2bas2[60], $snm2bas2[61], $snm2bas2[62], $snm2bas2[63], $snm2bas2[64], $snm2bas2[65], $snm2bas2[66], $snm2bas2[67], $snm2bas2[68], $snm2bas2[69], $snm2bas2[70], $snm2bas2[71], $snm2bas2[72], $snm2bas2[73], $snm2bas2[74], $snm2bas2[75], $snm2bas2[76], $snm2bas2[77], $snm2bas2[78], $snm2bas2[79], 
		  $snm2bas2[80], $snm2bas2[81], $snm2bas2[82], $snm2bas2[83], $snm2bas2[84], $snm2bas2[85], $snm2bas2[86], $snm2bas2[87], $snm2bas2[88], $snm2bas2[89], $snm2bas2[90], $snm2bas2[91], $snm2bas2[92], $snm2bas2[93], $snm2bas2[94], $snm2bas2[95], $snm2bas2[96], $snm2bas2[97], $snm2bas2[98], $snm2bas2[99], 
		  $snm2bas2[100], $snm2bas2[101], $snm2bas2[102], $snm2bas2[103], $snm2bas2[104], $snm2bas2[105], $snm2bas2[106], $snm2bas2[107], $snm2bas2[108], $snm2bas2[109], $snm2bas2[110], $snm2bas2[111], $snm2bas2[112], $snm2bas2[113], $snm2bas2[114], $snm2bas2[115], $snm2bas2[116], $snm2bas2[117], $snm2bas2[118], $snm2bas2[119], 
		  $snm2bas2[120]);
$foragr3 = 	array($snm2bas3[0], $snm2bas3[1], $snm2bas3[2], $snm2bas3[3], $snm2bas3[4], $snm2bas3[5], $snm2bas3[6], $snm2bas3[7], $snm2bas3[8], $snm2bas3[9], $snm2bas3[10], $snm2bas3[11], $snm2bas3[12], $snm2bas3[13], $snm2bas3[14], $snm2bas3[15], $snm2bas3[16], $snm2bas3[17], $snm2bas3[18], $snm2bas3[19],
		  $snm2bas3[20], $snm2bas3[21], $snm2bas3[22], $snm2bas3[23], $snm2bas3[24], $snm2bas3[25], $snm2bas3[26], $snm2bas3[27], $snm2bas3[28], $snm2bas3[29], $snm2bas3[30], $snm2bas3[31], $snm2bas3[32], $snm2bas3[33], $snm2bas3[34], $snm2bas3[35], $snm2bas3[36], $snm2bas3[37], $snm2bas3[38], $snm2bas3[39], 
		  $snm2bas3[40], $snm2bas3[41], $snm2bas3[42], $snm2bas3[43], $snm2bas3[44], $snm2bas3[45], $snm2bas3[46], $snm2bas3[47], $snm2bas3[48], $snm2bas3[49], $snm2bas3[50], $snm2bas3[51], $snm2bas3[52], $snm2bas3[53], $snm2bas3[54], $snm2bas3[55], $snm2bas3[56], $snm2bas3[57], $snm2bas3[58], $snm2bas3[69], 
		  $snm2bas3[60], $snm2bas3[61], $snm2bas3[62], $snm2bas3[63], $snm2bas3[64], $snm2bas3[65], $snm2bas3[66], $snm2bas3[67], $snm2bas3[68], $snm2bas3[69], $snm2bas3[70], $snm2bas3[71], $snm2bas3[72], $snm2bas3[73], $snm2bas3[74], $snm2bas3[75], $snm2bas3[76], $snm2bas3[77], $snm2bas3[78], $snm2bas3[79], 
		  $snm2bas3[80], $snm2bas3[81], $snm2bas3[82], $snm2bas3[83], $snm2bas3[84], $snm2bas3[85], $snm2bas3[86], $snm2bas3[87], $snm2bas3[88], $snm2bas3[89], $snm2bas3[90], $snm2bas3[91], $snm2bas3[92], $snm2bas3[93], $snm2bas3[94], $snm2bas3[95], $snm2bas3[96], $snm2bas3[97], $snm2bas3[98], $snm2bas3[99], 
		  $snm2bas3[100], $snm2bas3[101], $snm2bas3[102], $snm2bas3[103], $snm2bas3[104], $snm2bas3[105], $snm2bas3[106], $snm2bas3[107], $snm2bas3[108], $snm2bas3[109], $snm2bas3[110], $snm2bas3[111], $snm2bas3[112], $snm2bas3[113], $snm2bas3[114], $snm2bas3[115], $snm2bas3[116], $snm2bas3[117], $snm2bas3[118], $snm2bas3[119], 
		  $snm2bas3[120]);	  
	$array_all_bas = array(array_filter($forbas1), array_filter($forbas2), array_filter($forbas3));
	$countingbas = 0;
	while($countingbas <= 120){
	if(count(array_column($array_all_bas, $countingbas)) == 3){
	$basf2[] = round(array_sum(array_column($array_all_bas, $countingbas))/3);
	}
	else if(count(array_column($array_all_bas, $countingbas)) == 2){
	$basf2[] = round(array_sum(array_column($array_all_bas, $countingbas))/2);
	}
	else if(count(array_column($array_all_bas, $countingbas)) == 1){
	$basf2[] = round(array_sum(array_column($array_all_bas, $countingbas))/1);
	}
	else{
	$basf2[] = round(array_sum(array_column($array_all_bas, $countingbas))/3);	
	}
	$countingbas++;
	}
	$basf = implode("-",array_filter($basf2));
	$basmx2 = explode("-",$basf);
	$basmx = max(explode("-",$basf));
	$stnameandscoreBas = array_combine($acbaskeys,$basmx2);
	$maxinallsub = $basmx;	
	}
		else if($su == 'Biology'){
		$resultmxbystunamebio1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Biology' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebio1))
	{	
		$snm2bio1[] = $rsn['score'];
		$stin2bio[] = $rsn['student_name'];
	}
	$acbiof = array_combine($stin2bio,$snm2bio1);
	$resultmxbystunamebio2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Biology' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebio2))
	{	
		$snm2bio2[] = $rsn['score'];
	    $stin2bio2[] = $rsn['student_name'];
	}
	$acbios = array_combine($stin2bio2,$snm2bio2);
	$resultmxbystunamebio3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Biology' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebio3))
	{	
		$snm2bio3[] = $rsn['score'];
		$stin2bio3[] = $rsn['student_name'];
	}
	$acbiot = array_combine($stin2bio3,$snm2bio3);
	$arinall = array($acbiof, $acbios, $acbiot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acbiokeys = (array_keys($largest_arr));
$forbio1 = 	array($snm2bio1[0], $snm2bio1[1], $snm2bio1[2], $snm2bio1[3], $snm2bio1[4], $snm2bio1[5], $snm2bio1[6], $snm2bio1[7], $snm2bio1[8], $snm2bio1[9], $snm2bio1[10], $snm2bio1[11], $snm2bio1[12], $snm2bio1[13], $snm2bio1[14], $snm2bio1[15], $snm2bio1[16], $snm2bio1[17], $snm2bio1[18], $snm2bio1[19], 
		$snm2bio1[20], $snm2bio1[21], $snm2bio1[22], $snm2bio1[23], $snm2bio1[24], $snm2bio1[25], $snm2bio1[26], $snm2bio1[27], $snm2bio1[28], $snm2bio1[29], $snm2bio1[30], $snm2bio1[31], $snm2bio1[32], $snm2bio1[33], $snm2bio1[34], $snm2bio1[35], $snm2bio1[36], $snm2bio1[37], $snm2bio1[38], $snm2bio1[39], 
		$snm2bio1[40], $snm2bio1[41], $snm2bio1[42], $snm2bio1[43], $snm2bio1[44], $snm2bio1[45], $snm2bio1[46], $snm2bio1[47], $snm2bio1[48], $snm2bio1[49], $snm2bio1[50], $snm2bio1[51], $snm2bio1[52], $snm2bio1[53], $snm2bio1[54], $snm2bio1[55], $snm2bio1[56], $snm2bio1[57], $snm2bio1[58], $snm2bio1[59], 
		$snm2bio1[60], $snm2bio1[61], $snm2bio1[62], $snm2bio1[63], $snm2bio1[64], $snm2bio1[65], $snm2bio1[66], $snm2bio1[67], $snm2bio1[68], $snm2bio1[69], $snm2bio1[70], $snm2bio1[71], $snm2bio1[72], $snm2bio1[73], $snm2bio1[74], $snm2bio1[75], $snm2bio1[76], $snm2bio1[77], $snm2bio1[78], $snm2bio1[79], 
		$snm2bio1[80], $snm2bio1[81], $snm2bio1[82], $snm2bio1[83], $snm2bio1[84], $snm2bio1[85], $snm2bio1[86], $snm2bio1[87], $snm2bio1[88], $snm2bio1[89], $snm2bio1[90], $snm2bio1[91], $snm2bio1[92], $snm2bio1[93], $snm2bio1[94], $snm2bio1[95], $snm2bio1[96], $snm2bio1[97], $snm2bio1[98], $snm2bio1[99], 
		$snm2bio1[100], $snm2bio1[101], $snm2bio1[102], $snm2bio1[103], $snm2bio1[104], $snm2bio1[105], $snm2bio1[106], $snm2bio1[107], $snm2bio1[108], $snm2bio1[109], $snm2bio1[110], $snm2bio1[111], $snm2bio1[112], $snm2bio1[113], $snm2bio1[114], $snm2bio1[115], $snm2bio1[116], $snm2bio1[117], $snm2bio1[118], $snm2bio1[119], 
		$snm2bio1[120]);
$forbio2 = 	array($snm2bio2[0], $snm2bio2[1], $snm2bio2[2], $snm2bio2[3], $snm2bio2[4], $snm2bio2[5], $snm2bio2[6], $snm2bio2[7], $snm2bio2[8], $snm2bio2[9], $snm2bio2[10], $snm2bio2[11], $snm2bio2[12], $snm2bio2[13], $snm2bio2[14], $snm2bio2[15], $snm2bio2[16], $snm2bio2[17], $snm2bio2[18], $snm2bio2[19], 
		$snm2bio2[20], $snm2bio2[21], $snm2bio2[22], $snm2bio2[23], $snm2bio2[24], $snm2bio2[25], $snm2bio2[26], $snm2bio2[27], $snm2bio2[28], $snm2bio2[29], $snm2bio2[30], $snm2bio2[31], $snm2bio2[32], $snm2bio2[33], $snm2bio2[34], $snm2bio2[35], $snm2bio2[36], $snm2bio2[37], $snm2bio2[38], $snm2bio2[39], 
		$snm2bio2[40], $snm2bio2[41], $snm2bio2[42], $snm2bio2[43], $snm2bio2[44], $snm2bio2[45], $snm2bio2[46], $snm2bio2[47], $snm2bio2[48], $snm2bio2[49], $snm2bio2[50], $snm2bio2[51], $snm2bio2[52], $snm2bio2[53], $snm2bio2[54], $snm2bio2[55], $snm2bio2[56], $snm2bio2[57], $snm2bio2[58], $snm2bio2[59], 
		$snm2bio2[60], $snm2bio2[61], $snm2bio2[62], $snm2bio2[63], $snm2bio2[64], $snm2bio2[65], $snm2bio2[66], $snm2bio2[67], $snm2bio2[68], $snm2bio2[69], $snm2bio2[70], $snm2bio2[71], $snm2bio2[72], $snm2bio2[73], $snm2bio2[74], $snm2bio2[75], $snm2bio2[76], $snm2bio2[77], $snm2bio2[78], $snm2bio2[79], 
		$snm2bio2[80], $snm2bio2[81], $snm2bio2[82], $snm2bio2[83], $snm2bio2[84], $snm2bio2[85], $snm2bio2[86], $snm2bio2[87], $snm2bio2[88], $snm2bio2[89], $snm2bio2[90], $snm2bio2[91], $snm2bio2[92], $snm2bio2[93], $snm2bio2[94], $snm2bio2[95], $snm2bio2[96], $snm2bio2[97], $snm2bio2[98], $snm2bio2[99], 
		$snm2bio2[100], $snm2bio2[101], $snm2bio2[102], $snm2bio2[103], $snm2bio2[104], $snm2bio2[105], $snm2bio2[106], $snm2bio2[107], $snm2bio2[108], $snm2bio2[109], $snm2bio2[110], $snm2bio2[111], $snm2bio2[112], $snm2bio2[113], $snm2bio2[114], $snm2bio2[115], $snm2bio2[116], $snm2bio2[117], $snm2bio2[118], $snm2bio2[119], 
		$snm2bio2[120]);
$forbio3 = 	array($snm2bio3[0], $snm2bio3[1], $snm2bio3[2], $snm2bio3[3], $snm2bio3[4], $snm2bio3[5], $snm2bio3[6], $snm2bio3[7], $snm2bio3[8], $snm2bio3[9], $snm2bio3[10], $snm2bio3[11], $snm2bio3[12], $snm2bio3[13], $snm2bio3[14], $snm2bio3[15], $snm2bio3[16], $snm2bio3[17], $snm2bio3[18], $snm2bio3[19], 
		$snm2bio3[20], $snm2bio3[21], $snm2bio3[22], $snm2bio3[23], $snm2bio3[24], $snm2bio3[25], $snm2bio3[26], $snm2bio3[27], $snm2bio3[28], $snm2bio3[29], $snm2bio3[30], $snm2bio3[31], $snm2bio3[32], $snm2bio3[33], $snm2bio3[34], $snm2bio3[35], $snm2bio3[36], $snm2bio3[37], $snm2bio3[38], $snm2bio3[39], 
		$snm2bio3[40], $snm2bio3[41], $snm2bio3[42], $snm2bio3[43], $snm2bio3[44], $snm2bio3[45], $snm2bio3[46], $snm2bio3[47], $snm2bio3[48], $snm2bio3[49], $snm2bio3[50], $snm2bio3[51], $snm2bio3[52], $snm2bio3[53], $snm2bio3[54], $snm2bio3[55], $snm2bio3[56], $snm2bio3[57], $snm2bio3[58], $snm2bio3[59], 
		$snm2bio3[60], $snm2bio3[61], $snm2bio3[62], $snm2bio3[63], $snm2bio3[64], $snm2bio3[65], $snm2bio3[66], $snm2bio3[67], $snm2bio3[68], $snm2bio3[69], $snm2bio3[70], $snm2bio3[71], $snm2bio3[72], $snm2bio3[73], $snm2bio3[74], $snm2bio3[75], $snm2bio3[76], $snm2bio3[77], $snm2bio3[78], $snm2bio3[79], 
		$snm2bio3[80], $snm2bio3[81], $snm2bio3[82], $snm2bio3[83], $snm2bio3[84], $snm2bio3[85], $snm2bio3[86], $snm2bio3[87], $snm2bio3[88], $snm2bio3[89], $snm2bio3[90], $snm2bio3[91], $snm2bio3[92], $snm2bio3[93], $snm2bio3[94], $snm2bio3[95], $snm2bio3[96], $snm2bio3[97], $snm2bio3[98], $snm2bio3[99], 
		$snm2bio3[100], $snm2bio3[101], $snm2bio3[102], $snm2bio3[103], $snm2bio3[104], $snm2bio3[105], $snm2bio3[106], $snm2bio3[107], $snm2bio3[108], $snm2bio3[109], $snm2bio3[110], $snm2bio3[111], $snm2bio3[112], $snm2bio3[113], $snm2bio3[114], $snm2bio3[115], $snm2bio3[116], $snm2bio3[117], $snm2bio3[118], $snm2bio3[119], 
		$snm2bio3[120]);
$array_all_bio = array(array_filter($forbio1), array_filter($forbio2), array_filter($forbio3));
	$countingbio = 0;
	while($countingbio <= 120){
	if(count(array_column($array_all_bio, $countingbio)) == 3){
	$biof2[] = round(array_sum(array_column($array_all_bio, $countingbio))/3);
	}
	else if(count(array_column($array_all_bio, $countingbio)) == 2){
	$biof2[] = round(array_sum(array_column($array_all_bio, $countingbio))/2);
	}
	else if(count(array_column($array_all_bio, $countingbio)) == 1){
	$biof2[] = round(array_sum(array_column($array_all_bio, $countingbio))/1);
	}
	else{
	$biof2[] = round(array_sum(array_column($array_all_bio, $countingbio))/3);	
	}
	$countingbio++;
	}
	$biof = implode("-",array_filter($biof2));
	$biomx2 = explode("-",$biof);
	$biomx = max(explode("-",$biof));
	$stnameandscoreBio = array_combine($acbiokeys,$biomx2);
	$maxinallsub = $biomx;	
	}
	else if($su == 'Business Studies'){
		$resultmxbystunamebus1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Business Studies' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebus1))
	{	
		$snm2bus1[] = $rsn['score'];
		$stin2bus[] = $rsn['student_name'];
	}
	$acbusf = array_combine($stin2bus,$snm2bus1);
	$resultmxbystunamebus2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Business Studies' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebus2))
	{	
		$snm2bus2[] = $rsn['score'];
	    $stin2bus2[] = $rsn['student_name'];
	}
	$acbuss = array_combine($stin2bus2,$snm2bus2);
	$resultmxbystunamebus3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Business Studies' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebus3))
	{	
		$snm2bus3[] = $rsn['score'];
		$stin2bus3[] = $rsn['student_name'];
	}
	$acbust = array_combine($stin2bus3,$snm2bus3);
	$arinall = array($acbusf, $acbuss, $acbust);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acbuskeys = (array_keys($largest_arr));
$forbus1 = 	array($snm2bus1[0], $snm2bus1[1], $snm2bus1[2], $snm2bus1[3], $snm2bus1[4], $snm2bus1[5], $snm2bus1[6], $snm2bus1[7], $snm2bus1[8], $snm2bus1[9], $snm2bus1[10], $snm2bus1[11], $snm2bus1[12], $snm2bus1[13], $snm2bus1[14], $snm2bus1[15], $snm2bus1[16], $snm2bus1[17], $snm2bus1[18], $snm2bus1[19], 
		$snm2bus1[20], $snm2bus1[21], $snm2bus1[22], $snm2bus1[23], $snm2bus1[24], $snm2bus1[25], $snm2bus1[26], $snm2bus1[27], $snm2bus1[28], $snm2bus1[29], $snm2bus1[30], $snm2bus1[31], $snm2bus1[32], $snm2bus1[33], $snm2bus1[34], $snm2bus1[35], $snm2bus1[36], $snm2bus1[37], $snm2bus1[38], $snm2bus1[39], 
		$snm2bus1[40], $snm2bus1[41], $snm2bus1[42], $snm2bus1[43], $snm2bus1[44], $snm2bus1[45], $snm2bus1[46], $snm2bus1[47], $snm2bus1[48], $snm2bus1[49], $snm2bus1[50], $snm2bus1[51], $snm2bus1[52], $snm2bus1[53], $snm2bus1[54], $snm2bus1[55], $snm2bus1[56], $snm2bus1[57], $snm2bus1[58], $snm2bus1[59], 
		$snm2bus1[60], $snm2bio1[61], $snm2bus1[62], $snm2bus1[63], $snm2bus1[64], $snm2bus1[65], $snm2bus1[66], $snm2bus1[67], $snm2bus1[68], $snm2bus1[69], $snm2bus1[70], $snm2bus1[71], $snm2bus1[72], $snm2bus1[73], $snm2bus1[74], $snm2bus1[75], $snm2bus1[76], $snm2bus1[77], $snm2bus1[78], $snm2bus1[79], 
		$snm2bus1[80], $snm2bus1[81], $snm2bus1[82], $snm2bus1[83], $snm2bus1[84], $snm2bus1[85], $snm2bus1[86], $snm2bus1[87], $snm2bus1[88], $snm2bus1[89], $snm2bus1[90], $snm2bus1[91], $snm2bus1[92], $snm2bus1[93], $snm2bus1[94], $snm2bus1[95], $snm2bus1[96], $snm2bus1[97], $snm2bus1[98], $snm2bus1[99], 
		$snm2bus1[100], $snm2bus1[101], $snm2bus1[102], $snm2bus1[103], $snm2bus1[104], $snm2bus1[105], $snm2bus1[106], $snm2bus1[107], $snm2bus1[108], $snm2bus1[109], $snm2bus1[110], $snm2bus1[111], $snm2bus1[112], $snm2bus1[113], $snm2bus1[114], $snm2bus1[115], $snm2bus1[116], $snm2bus1[117], $snm2bus1[118], $snm2bus1[119], 
		$snm2bus1[120]);
$forbus2 = 	array($snm2bus2[0], $snm2bus2[1], $snm2bus2[2], $snm2bus2[3], $snm2bus2[4], $snm2bus2[5], $snm2bus2[6], $snm2bus2[7], $snm2bus2[8], $snm2bus2[9], $snm2bus2[10], $snm2bus2[11], $snm2bus2[12], $snm2bus2[13], $snm2bus2[14], $snm2bus2[15], $snm2bus2[16], $snm2bus2[17], $snm2bus2[18], $snm2bus2[19], 
		$snm2bus2[20], $snm2bus2[21], $snm2bus2[22], $snm2bus2[23], $snm2bus2[24], $snm2bus2[25], $snm2bus2[26], $snm2bus2[27], $snm2bus2[28], $snm2bus2[29], $snm2bus2[30], $snm2bus2[31], $snm2bus2[32], $snm2bus2[33], $snm2bus2[34], $snm2bus2[35], $snm2bus2[36], $snm2bus2[37], $snm2bus2[38], $snm2bus2[39], 
		$snm2bus2[40], $snm2bus2[41], $snm2bus2[42], $snm2bus2[43], $snm2bus2[44], $snm2bus2[45], $snm2bus2[46], $snm2bus2[47], $snm2bus2[48], $snm2bus2[49], $snm2bus2[50], $snm2bus2[51], $snm2bus2[52], $snm2bus2[53], $snm2bus2[54], $snm2bus2[55], $snm2bus2[56], $snm2bus2[57], $snm2bus2[58], $snm2bus2[59], 
		$snm2bus2[60], $snm2bus2[61], $snm2bus2[62], $snm2bus2[63], $snm2bus2[64], $snm2bus2[65], $snm2bus2[66], $snm2bus2[67], $snm2bus2[68], $snm2bus2[69], $snm2bus2[70], $snm2bus2[71], $snm2bus2[72], $snm2bus2[73], $snm2bus2[74], $snm2bus2[75], $snm2bus2[76], $snm2bus2[77], $snm2bus2[78], $snm2bus2[79], 
		$snm2bus2[80], $snm2bus2[81], $snm2bus2[82], $snm2bus2[83], $snm2bus2[84], $snm2bus2[85], $snm2bus2[86], $snm2bus2[87], $snm2bus2[88], $snm2bus2[89], $snm2bus2[90], $snm2bus2[91], $snm2bus2[92], $snm2bus2[93], $snm2bus2[94], $snm2bus2[95], $snm2bus2[96], $snm2bus2[97], $snm2bus2[98], $snm2bus2[99], 
		$snm2bus2[100], $snm2bus2[101], $snm2bus2[102], $snm2bus2[103], $snm2bus2[104], $snm2bus2[105], $snm2bus2[106], $snm2bus2[107], $snm2bus2[108], $snm2bus2[109], $snm2bus2[110], $snm2bus2[111], $snm2bus2[112], $snm2bus2[113], $snm2bus2[114], $snm2bus2[115], $snm2bus2[116], $snm2bus2[117], $snm2bus2[118], $snm2bus2[119], 
		$snm2bus2[120]);
$forbus3 = 	array($snm2bus3[0], $snm2bus3[1], $snm2bus3[2], $snm2bus3[3], $snm2bus3[4], $snm2bus3[5], $snm2bus3[6], $snm2bus3[7], $snm2bus3[8], $snm2bus3[9], $snm2bus3[10], $snm2bus3[11], $snm2bus3[12], $snm2bus3[13], $snm2bus3[14], $snm2bus3[15], $snm2bus3[16], $snm2bus3[17], $snm2bus3[18], $snm2bus3[19], 
		$snm2bus3[20], $snm2bus3[21], $snm2bus3[22], $snm2bus3[23], $snm2bus3[24], $snm2bus3[25], $snm2bus3[26], $snm2bus3[27], $snm2bus3[28], $snm2bus3[29], $snm2bus3[30], $snm2bus3[31], $snm2bus3[32], $snm2bus3[33], $snm2bus3[34], $snm2bus3[35], $snm2bus3[36], $snm2bus3[37], $snm2bus3[38], $snm2bus3[39], 
		$snm2bus3[40], $snm2bus3[41], $snm2bus3[42], $snm2bus3[43], $snm2bus3[44], $snm2bus3[45], $snm2bus3[46], $snm2bus3[47], $snm2bus3[48], $snm2bus3[49], $snm2bus3[50], $snm2bus3[51], $snm2bus3[52], $snm2bus3[53], $snm2bus3[54], $snm2bus3[55], $snm2bus3[56], $snm2bus3[57], $snm2bus3[58], $snm2bus3[59], 
		$snm2bus3[60], $snm2bus3[61], $snm2bus3[62], $snm2bus3[63], $snm2bus3[64], $snm2bus3[65], $snm2bus3[66], $snm2bus3[67], $snm2bus3[68], $snm2bus3[69], $snm2bus3[70], $snm2bus3[71], $snm2bus3[72], $snm2bus3[73], $snm2bus3[74], $snm2bus3[75], $snm2bus3[76], $snm2bus3[77], $snm2bus3[78], $snm2bus3[79], 
		$snm2bus3[80], $snm2bus3[81], $snm2bus3[82], $snm2bus3[83], $snm2bus3[84], $snm2bus3[85], $snm2bus3[86], $snm2bus3[87], $snm2bus3[88], $snm2bus3[89], $snm2bus3[90], $snm2bus3[91], $snm2bus3[92], $snm2bus3[93], $snm2bus3[94], $snm2bus3[95], $snm2bus3[96], $snm2bus3[97], $snm2bus3[98], $snm2bus3[99], 
		$snm2bus3[100], $snm2bus3[101], $snm2bus3[102], $snm2bus3[103], $snm2bus3[104], $snm2bus3[105], $snm2bus3[106], $snm2bus3[107], $snm2bus3[108], $snm2bus3[109], $snm2bus3[110], $snm2bus3[111], $snm2bus3[112], $snm2bus3[113], $snm2bus3[114], $snm2bus3[115], $snm2bus3[116], $snm2bus3[117], $snm2bus3[118], $snm2bus3[119], 
		$snm2bus3[120]);
	$array_all_bus = array(array_filter($forbus1), array_filter($forbus2), array_filter($forbus3));
	$countingbus = 0;
	while($countingbus <= 120){
	if(count(array_column($array_all_bus, $countingbus)) == 3){
	$busf2[] = round(array_sum(array_column($array_all_bus, $countingbus))/3);
	}
	else if(count(array_column($array_all_bus, $countingbus)) == 2){
	$busf2[] = round(array_sum(array_column($array_all_bus, $countingbus))/2);
	}
	else if(count(array_column($array_all_bus, $countingbus)) == 1){
	$busf2[] = round(array_sum(array_column($array_all_bus, $countingbus))/1);
	}
	else{
	$busf2[] = round(array_sum(array_column($array_all_bus, $countingbus))/3);	
	}
	$countingbus++;
	}
	$busf = implode("-",array_filter($busf2));
	$busmx2 = explode("-",$busf);
	$busmx = max(explode("-",$busf));
	$stnameandscoreBus = array_combine($acbuskeys,$busmx2);
	$maxinallsub = $busmx;			
	}
	else if($su == 'Catering'){
		$resultmxbystunamecat1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Catering' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecat1))
	{	
		$snm2cat1[] = $rsn['score'];
		$stin2cat[] = $rsn['student_name'];
	}
	$accatf = array_combine($stin2cat,$snm2cat1);
	$resultmxbystunamecat2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Catering' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecat2))
	{	
		$snm2cat2[] = $rsn['score'];
	    $stin2cat2[] = $rsn['student_name'];
	}
	$accats = array_combine($stin2cat2,$snm2cat2);
	$resultmxbystunamecat3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Catering' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecat3))
	{	
		$snm2cat3[] = $rsn['score'];
		$stin2cat3[] = $rsn['student_name'];
	}
	$accatt = array_combine($stin2cat3,$snm2cat3);
	$arinall = array($accatf, $accats, $accatt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$accatkeys = (array_keys($largest_arr));
	
$forcat1 = array();
for($v=0; $v<=120; $v++){
$forccat1[] = $snm2cat1[$v];
}
$forcat1 = $forccat1;

$forcat2 = array();
for($v=0; $v<=120; $v++){
$forccat2[] = $snm2cat2[$v];
}
$forcat2 = $forccat2;

$forcat3 = array();
for($v=0; $v<=120; $v++){
$forccat3[] = $snm2cat3[$v];
}
$forcat3 = $forccat3;

	$array_all_cat = array(array_filter($forcat1), array_filter($forcat2), array_filter($forcat3));
	$countingcat = 0;
	while($countingcat <= 120){
	if(count(array_column($array_all_cat, $countingcat)) == 3){
	$catf2[] = round(array_sum(array_column($array_all_cat, $countingcat))/3);
	}
	else if(count(array_column($array_all_cat, $countingcat)) == 2){
	$catf2[] = round(array_sum(array_column($array_all_cat, $countingcat))/2);
	}
	else if(count(array_column($array_all_cat, $countingcat)) == 1){
	$catf2[] = round(array_sum(array_column($array_all_cat, $countingcat))/1);
	}
	else{
	$catf2[] = round(array_sum(array_column($array_all_cat, $countingcat))/3);	
	}
	$countingcat++;
	}
	$catf = implode("-",array_filter($catf2));
	$catmx2 = explode("-",$catf);
	$catmx = max(explode("-",$catf));
	$stnameandscoreCat = array_combine($accatkeys,$catmx2);
	$maxinallsub = $catmx;			
	}
	else if($su == 'Chemistry'){
		$resultmxbystunameche1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Chemistry' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameche1))
	{	
		$snm2che1[] = $rsn['score'];
		$stin2che[] = $rsn['student_name'];
	}
	$acchef = array_combine($stin2che,$snm2che1);
	$resultmxbystunameche2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Chemistry' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameche2))
	{	
		$snm2che2[] = $rsn['score'];
	    $stin2che2[] = $rsn['student_name'];
	}
	$acches = array_combine($stin2che2,$snm2che2);
	$resultmxbystunameche3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Chemistry' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameche3))
	{	
		$snm2che3[] = $rsn['score'];
		$stin2che3[] = $rsn['student_name'];
	}
	$acchet = array_combine($stin2che3,$snm2che3);
	$arinall = array($acchef, $acches, $acchet);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acchekeys = (array_keys($largest_arr));
	
$forche1 = array();
for($v=0; $v<=120; $v++){
$forcche1[] = $snm2che1[$v];
}
$forche1 = $forcche1;

$forche2 = array();
for($v=0; $v<=120; $v++){
$forcche2[] = $snm2che2[$v];
}
$forche2 = $forcche2;

$forche3 = array();
for($v=0; $v<=120; $v++){
$forcche3[] = $snm2che3[$v];
}
$forche3 = $forcche3;

	$array_all_che = array(array_filter($forche1), array_filter($forche2), array_filter($forche3));
	$countingche = 0;
	while($countingche <= 120){
	if(count(array_column($array_all_che, $countingche)) == 3){
	$chef2[] = round(array_sum(array_column($array_all_che, $countingche))/3);
	}
	else if(count(array_column($array_all_che, $countingche)) == 2){
	$chef2[] = round(array_sum(array_column($array_all_che, $countingche))/2);
	}
	else if(count(array_column($array_all_che, $countingche)) == 1){
	$chef2[] = round(array_sum(array_column($array_all_che, $countingche))/1);
	}
	else{
	$chef2[] = round(array_sum(array_column($array_all_che, $countingche))/3);	
	}
	$countingche++;
	}
	$chef = implode("-",array_filter($chef2));
	$chemx2 = explode("-",$chef);
	$chemx = max(explode("-",$chef));
	$stnameandscoreChe = array_combine($acchekeys,$chemx2);
	$maxinallsub = $chemx;			
	}
	else if($su == 'Civic Education'){
		$resultmxbystunameciv1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Civic Education' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameciv1))
	{	
		$snm2civ1[] = $rsn['score'];
		$stin2civ[] = $rsn['student_name'];
	}
	$accivf = array_combine($stin2civ,$snm2civ1);
	$resultmxbystunameciv2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Civic Education' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameciv2))
	{	
		$snm2civ2[] = $rsn['score'];
	    $stin2civ2[] = $rsn['student_name'];
	}
	$accivs = array_combine($stin2civ2,$snm2civ2);
	$resultmxbystunameciv3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Civic Education' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameciv3))
	{	
		$snm2civ3[] = $rsn['score'];
		$stin2civ3[] = $rsn['student_name'];
	}
	$accivt = array_combine($stin2civ3,$snm2civ3);
	$arinall = array($accivf, $accivs, $accivt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$accivkeys = (array_keys($largest_arr));
	
$forciv1 = array();
for($v=0; $v<=120; $v++){
$forcciv1[] = $snm2civ1[$v];
}
$forciv1 = $forcciv1;

$forciv2 = array();
for($v=0; $v<=120; $v++){
$forcciv2[] = $snm2civ2[$v];
}
$forciv2 = $forcciv2;

$forciv3 = array();
for($v=0; $v<=120; $v++){
$forcciv3[] = $snm2civ3[$v];
}
$forciv3 = $forcciv3;

	$array_all_civ = array(array_filter($forciv1), array_filter($forciv2), array_filter($forciv3));
	$countingciv = 0;
	while($countingciv <= 120){
	if(count(array_column($array_all_civ, $countingciv)) == 3){
	$civf2[] = round(array_sum(array_column($array_all_civ, $countingciv))/3);
	}
	else if(count(array_column($array_all_civ, $countingciv)) == 2){
	$civf2[] = round(array_sum(array_column($array_all_civ, $countingciv))/2);
	}
	else if(count(array_column($array_all_civ, $countingciv)) == 1){
	$civf2[] = round(array_sum(array_column($array_all_civ, $countingciv))/1);
	}
	else{
	$civf2[] = round(array_sum(array_column($array_all_civ, $countingciv))/3);	
	}
	$countingciv++;
	}
	$civf = implode("-",array_filter($civf2));
	$civmx2 = explode("-",$civf);
	$civmx = max(explode("-",$civf));
	$stnameandscoreCiv = array_combine($accivkeys,$civmx2);
	$maxinallsub = $civmx;			
	}
	
	else if($su == 'Creative and Cultural Arts'){
		$resultmxbystunamecca1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Creative and Cultural Arts' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecca1))
	{	
		$snm2cca1[] = $rsn['score'];
		$stin2cca[] = $rsn['student_name'];
	}
	$acccaf = array_combine($stin2cca,$snm2cca1);
	$resultmxbystunamecca2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Creative and Cultural Arts' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecca2))
	{	
		$snm2cca2[] = $rsn['score'];
	    $stin2cca2[] = $rsn['student_name'];
	}
	$acccas = array_combine($stin2cca2,$snm2cca2);
	$resultmxbystunamecca3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Creative and Cultural Arts Studies' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecca3))
	{	
		$snm2cca3[] = $rsn['score'];
		$stin2cca3[] = $rsn['student_name'];
	}
	$acccat = array_combine($stin2cca3,$snm2cca3);
	$arinall = array($acccaf, $acccas, $acccat);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acccakeys = (array_keys($largest_arr));
	
$forcca1 = array();
$forcca2 = array();
$forcca3 = array();
for($v=0; $v<=120; $v++){
$forccca1[] = $snm2cca1[$v];
$forccca2[] = $snm2cca2[$v];
$forccca3[] = $snm2cca3[$v];
}
$forcca1 = $forccca1;
$forcca2 = $forccca2;
$forcca3 = $forccca3;

	$array_all_cca = array(array_filter($forcca1), array_filter($forcca2), array_filter($forcca3));
	$countingcca = 0;
	while($countingcca <= 120){
	if(count(array_column($array_all_cca, $countingcca)) == 3){
	$ccaf2[] = round(array_sum(array_column($array_all_cca, $countingcca))/3);
	}
	else if(count(array_column($array_all_cca, $countingcca)) == 2){
	$ccaf2[] = round(array_sum(array_column($array_all_cca, $countingcca))/2);
	}
	else if(count(array_column($array_all_cca, $countingcca)) == 1){
	$ccaf2[] = round(array_sum(array_column($array_all_cca, $countingcca))/1);
	}
	else{
	$ccaf2[] = round(array_sum(array_column($array_all_cca, $countingcca))/3);	
	}
	$countingcca++;
	}
	$ccaf = implode("-",array_filter($ccaf2));
	$ccamx2 = explode("-",$ccaf);
	$ccamx = max(explode("-",$ccaf));
	$stnameandscoreCca = array_combine($acccakeys,$ccamx2);
	$maxinallsub = $ccamx;			
	}
		else if($su == 'CRK'){
		$resultmxbystunamecrk1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='CRK' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecrk1))
	{	
		$snm2crk1[] = $rsn['score'];
		$stin2crk[] = $rsn['student_name'];
	}
	$accrkf = array_combine($stin2crk,$snm2crk1);
	$resultmxbystunamecrk2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='CRK' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecrk2))
	{	
		$snm2crk2[] = $rsn['score'];
	    $stin2crk2[] = $rsn['student_name'];
	}
	$accrks = array_combine($stin2crk2,$snm2crk2);
	$resultmxbystunamecrk3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='CRK' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecrk3))
	{	
		$snm2crk3[] = $rsn['score'];
		$stin2crk3[] = $rsn['student_name'];
	}
	$accrkt = array_combine($stin2crk3,$snm2crk3);
	$arinall = array($accrkf, $accrks, $accrkt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$accrkkeys = (array_keys($largest_arr));
	
$forcrk1 = array();
for($v=0; $v<=120; $v++){
$forccrk1[] = $snm2crk1[$v];
}
$forcrk1 = $forccrk1;

$forcrk2 = array();
for($v=0; $v<=120; $v++){
$forccrk2[] = $snm2crk2[$v];
}
$forcrk2 = $forccrk2;

$forcrk3 = array();
for($v=0; $v<=120; $v++){
$forccrk3[] = $snm2crk3[$v];
}
$forcrk3 = $forccrk3;

	$array_all_crk = array(array_filter($forcrk1), array_filter($forcrk2), array_filter($forcrk3));
	$countingcrk = 0;
	while($countingcrk <= 120){
	if(count(array_column($array_all_crk, $countingcrk)) == 3){
	$crkf2[] = round(array_sum(array_column($array_all_crk, $countingcrk))/3);
	}
	else if(count(array_column($array_all_crk, $countingcrk)) == 2){
	$crkf2[] = round(array_sum(array_column($array_all_crk, $countingcrk))/2);
	}
	else if(count(array_column($array_all_crk, $countingcrk)) == 1){
	$crkf2[] = round(array_sum(array_column($array_all_crk, $countingcrk))/1);
	}
	else{
	$crkf2[] = round(array_sum(array_column($array_all_crk, $countingcrk))/3);	
	}
	$countingcrk++;
	}
	$crkf = implode("-",array_filter($crkf2));
	$crkmx2 = explode("-",$crkf);
	$crkmx = max(explode("-",$crkf));
	$stnameandscoreCrk = array_combine($accrkkeys,$crkmx2);
	$maxinallsub = $crkmx;			
	}
	else if($su == 'Economics'){
		$resultmxbystunameeco1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Economics' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeco1))
	{	
		$snm2eco1[] = $rsn['score'];
		$stin2eco[] = $rsn['student_name'];
	}
	$acecof = array_combine($stin2eco,$snm2eco1);
	$resultmxbystunameeco2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Economics' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeco2))
	{	
		$snm2eco2[] = $rsn['score'];
	    $stin2eco2[] = $rsn['student_name'];
	}
	$acecos = array_combine($stin2eco2,$snm2eco2);
	$resultmxbystunameeco3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Economics' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeco3))
	{	
		$snm2eco3[] = $rsn['score'];
		$stin2eco3[] = $rsn['student_name'];
	}
	$acecot = array_combine($stin2eco3,$snm2eco3);
	$arinall = array($acecof, $acecos, $acecot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acecokeys = (array_keys($largest_arr));
	
$foreco1 = array();
$foreco2 = array();
$foreco3 = array();
for($v=0; $v<=120; $v++){
$foreeco1[] = $snm2eco1[$v];
$foreeco2[] = $snm2eco2[$v];
$foreeco3[] = $snm2eco3[$v];
}
$foreco1 = $foreeco1;
$foreco2 = $foreeco2;
$foreco3 = $foreeco3;

	$array_all_eco = array(array_filter($foreco1), array_filter($foreco2), array_filter($foreco3));
	$countingeco = 0;
	while($countingeco <= 120){
	if(count(array_column($array_all_eco, $countingeco)) == 3){
	$ecof2[] = round(array_sum(array_column($array_all_eco, $countingeco))/3);
	}
	else if(count(array_column($array_all_eco, $countingeco)) == 2){
	$ecof2[] = round(array_sum(array_column($array_all_eco, $countingeco))/2);
	}
	else if(count(array_column($array_all_eco, $countingeco)) == 1){
	$ecof2[] = round(array_sum(array_column($array_all_eco, $countingeco))/1);
	}
	else{
	$ecof2[] = round(array_sum(array_column($array_all_eco, $countingeco))/3);	
	}
	$countingeco++;
	}
	$ecof = implode("-",array_filter($ecof2));
	$ecomx2 = explode("-",$ecof);
	$ecomx = max(explode("-",$ecof));
	$stnameandscoreEco = array_combine($acecokeys,$ecomx2);
	$maxinallsub = $ecomx;			
	}
	else if($su == 'Financial Accounting'){
		$resultmxbystunamefin1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Financial Accounting' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefin1))
	{	
		$snm2fin1[] = $rsn['score'];
		$stin2fin[] = $rsn['student_name'];
	}
	$acfinf = array_combine($stin2fin,$snm2fin1);
	$resultmxbystunamefin2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Financial Accounting' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefin2))
	{	
		$snm2fin2[] = $rsn['score'];
	    $stin2fin2[] = $rsn['student_name'];
	}
	$acfins = array_combine($stin2fin2,$snm2fin2);
	$resultmxbystunamefin3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Financial Accounting' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefin3))
	{	
		$snm2fin3[] = $rsn['score'];
		$stin2fin3[] = $rsn['student_name'];
	}
	$acfint = array_combine($stin2fin3,$snm2fin3);
	$arinall = array($acfinf, $acfins, $acfint);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acfinkeys = (array_keys($largest_arr));
	
$forfin1 = array();
$forfin2 = array();
$forfin3 = array();
for($v=0; $v<=120; $v++){
$forffin1[] = $snm2fin1[$v];
$forffin2[] = $snm2fin2[$v];
$forffin3[] = $snm2fin3[$v];
}
$forfin1 = $forffin1;
$forfin2 = $forffin2;
$forfin3 = $forffin3;

	$array_all_fin = array(array_filter($forfin1), array_filter($forfin2), array_filter($forfin3));
	$countingfin = 0;
	while($countingfin <= 120){
	if(count(array_column($array_all_fin, $countingfin)) == 3){
	$finf2[] = round(array_sum(array_column($array_all_fin, $countingfin))/3);
	}
	else if(count(array_column($array_all_fin, $countingfin)) == 2){
	$finf2[] = round(array_sum(array_column($array_all_fin, $countingfin))/2);
	}
	else if(count(array_column($array_all_fin, $countingfin)) == 1){
	$finf2[] = round(array_sum(array_column($array_all_fin, $countingfin))/1);
	}
	else{
	$finf2[] = round(array_sum(array_column($array_all_fin, $countingfin))/3);	
	}
	$countingfin++;
	}
	$finf = implode("-",array_filter($finf2));
	$finmx2 = explode("-",$finf);
	$finmx = max(explode("-",$finf));
	$stnameandscoreFin = array_combine($acfinkeys,$finmx2);
	$maxinallsub = $finmx;			
	}
		else if($su == 'Food and Nutrition'){
		$resultmxbystunamefoo1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Food and Nutrition' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefoo1))
	{	
		$snm2foo1[] = $rsn['score'];
		$stin2foo[] = $rsn['student_name'];
	}
	$acfoof = array_combine($stin2foo,$snm2foo1);
	$resultmxbystunamefoo2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Food and Nutrition' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefoo2))
	{	
		$snm2foo2[] = $rsn['score'];
	    $stin2foo2[] = $rsn['student_name'];
	}
	$acfoos = array_combine($stin2foo2,$snm2foo2);
	$resultmxbystunamefoo3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Food and Nutrition' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefoo3))
	{	
		$snm2foo3[] = $rsn['score'];
		$stin2foo3[] = $rsn['student_name'];
	}
	$acfoot = array_combine($stin2foo3,$snm2foo3);
	$arinall = array($acfoof, $acfoos, $acfoot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acfookeys = (array_keys($largest_arr));
	
$forfoo1 = array();
$forfoo2 = array();
$forfoo3 = array();
for($v=0; $v<=120; $v++){
$forffoo1[] = $snm2foo1[$v];
$forffoo2[] = $snm2foo2[$v];
$forffoo3[] = $snm2foo3[$v];
}
$forfoo1 = $forffoo1;
$forfoo2 = $forffoo2;
$forfoo3 = $forffoo3;

	$array_all_foo = array(array_filter($forfoo1), array_filter($forfoo2), array_filter($forfoo3));
	$countingfoo = 0;
	while($countingfoo <= 120){
	if(count(array_column($array_all_foo, $countingfoo)) == 3){
	$foof2[] = round(array_sum(array_column($array_all_foo, $countingfoo))/3);
	}
	else if(count(array_column($array_all_foo, $countingfoo)) == 2){
	$foof2[] = round(array_sum(array_column($array_all_foo, $countingfoo))/2);
	}
	else if(count(array_column($array_all_foo, $countingfoo)) == 1){
	$foof2[] = round(array_sum(array_column($array_all_foo, $countingfoo))/1);
	}
	else{
	$foof2[] = round(array_sum(array_column($array_all_foo, $countingfoo))/3);	
	}
	$countingfoo++;
	}
	$foof = implode("-",array_filter($foof2));
	$foomx2 = explode("-",$foof);
	$foomx = max(explode("-",$foof));
	$stnameandscoreFoo = array_combine($acfookeys,$foomx2);
	$maxinallsub = $foomx;			
	}
		else if($su == 'Music'){
		$resultmxbystunamemus1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Music' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemus1))
	{	
		$snm2mus1[] = $rsn['score'];
		$stin2mus[] = $rsn['student_name'];
	}
	$acmusf = array_combine($stin2mus,$snm2mus1);
	$resultmxbystunamemus2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Music' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemus2))
	{	
		$snm2mus2[] = $rsn['score'];
	    $stin2mus2[] = $rsn['student_name'];
	}
	$acmuss = array_combine($stin2mus2,$snm2mus2);
	$resultmxbystunamemus3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Music' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemus3))
	{	
		$snm2mus3[] = $rsn['score'];
		$stin2mus3[] = $rsn['student_name'];
	}
	$acmust = array_combine($stin2mus3,$snm2mus3);
	$arinall = array($acmusf, $acmuss, $acmust);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acmuskeys = (array_keys($largest_arr));
	
$formus1 = array();
$formus2 = array();
$formus3 = array();
for($v=0; $v<=120; $v++){
$formmus1[] = $snm2mus1[$v];
$formmus2[] = $snm2mus2[$v];
$formmus3[] = $snm2mus3[$v];
}
$formus1 = $formmus1;
$formus2 = $formmus2;
$formus3 = $formmus3;

	$array_all_mus = array(array_filter($formus1), array_filter($formus2), array_filter($formus3));
	$countingmus = 0;
	while($countingmus <= 120){
	if(count(array_column($array_all_mus, $countingmus)) == 3){
	$musf2[] = round(array_sum(array_column($array_all_mus, $countingmus))/3);
	}
	else if(count(array_column($array_all_mus, $countingmus)) == 2){
	$musf2[] = round(array_sum(array_column($array_all_mus, $countingmus))/2);
	}
	else if(count(array_column($array_all_mus, $countingmus)) == 1){
	$musf2[] = round(array_sum(array_column($array_all_mus, $countingmus))/1);
	}
	else{
	$musf2[] = round(array_sum(array_column($array_all_mus, $countingmus))/3);	
	}
	$countingmus++;
	}
	$musf = implode("-",array_filter($musf2));
	$musmx2 = explode("-",$musf);
	$musmx = max(explode("-",$musf));
	$stnameandscoreMus = array_combine($acmuskeys,$musmx2);
	$maxinallsub = $musmx;			
	}
	else if($su == 'Government'){
		$resultmxbystunamegov1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Government' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegov1))
	{	
		$snm2gov1[] = $rsn['score'];
		$stin2gov[] = $rsn['student_name'];
	}
	$acgovf = array_combine($stin2gov,$snm2gov1);
	$resultmxbystunamegov2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Government' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegov2))
	{	
		$snm2gov2[] = $rsn['score'];
	    $stin2gov2[] = $rsn['student_name'];
	}
	$acgovs = array_combine($stin2gov2,$snm2gov2);
	$resultmxbystunamegov3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Government' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegov3))
	{	
		$snm2gov3[] = $rsn['score'];
		$stin2gov3[] = $rsn['student_name'];
	}
	$acgovt = array_combine($stin2gov3,$snm2gov3);
	$arinall = array($acgovf, $acgovs, $acgovt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acgovkeys = (array_keys($largest_arr));
	
$forgov1 = array();
$forgov2 = array();
$forgov3 = array();
for($v=0; $v<=120; $v++){
$forggov1[] = $snm2gov1[$v];
$forggov2[] = $snm2gov2[$v];
$forggov3[] = $snm2gov3[$v];
}
$forgov1 = $forggov1;
$forgov2 = $forggov2;
$forgov3 = $forggov3;

	$array_all_gov = array(array_filter($forgov1), array_filter($forgov2), array_filter($forgov3));
	$countinggov = 0;
	while($countinggov <= 120){
	if(count(array_column($array_all_gov, $countinggov)) == 3){
	$govf2[] = round(array_sum(array_column($array_all_gov, $countinggov))/3);
	}
	else if(count(array_column($array_all_gov, $countinggov)) == 2){
	$govf2[] = round(array_sum(array_column($array_all_gov, $countinggov))/2);
	}
	else if(count(array_column($array_all_gov, $countinggov)) == 1){
	$govf2[] = round(array_sum(array_column($array_all_gov, $countinggov))/1);
	}
	else{
	$govf2[] = round(array_sum(array_column($array_all_gov, $countinggov))/3);	
	}
	$countinggov++;
	}
	$govf = implode("-",array_filter($govf2));
	$govmx2 = explode("-",$govf);
	$govmx = max(explode("-",$govf));
	$stnameandscoreGov = array_combine($acgovkeys,$govmx2);
	$maxinallsub = $govmx;			
	}
	else if($su == 'Hausa'){
		$resultmxbystunamehau1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Hausa' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehau1))
	{	
		$snm2hau1[] = $rsn['score'];
		$stin2hau[] = $rsn['student_name'];
	}
	$achauf = array_combine($stin2hau,$snm2hau1);
	$resultmxbystunamehau2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Hausa' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehau2))
	{	
		$snm2hau2[] = $rsn['score'];
	    $stin2hau2[] = $rsn['student_name'];
	}
	$achaus = array_combine($stin2hau2,$snm2hau2);
	$resultmxbystunamehau3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Hausa' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehau3))
	{	
		$snm2hau3[] = $rsn['score'];
		$stin2hau3[] = $rsn['student_name'];
	}
	$achaut = array_combine($stin2hau3,$snm2hau3);
	$arinall = array($achauf, $achaus, $achaut);
	//print_r($arinall);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$achaukeys = (array_keys($largest_arr));
	
$forhau1 = array();
$forhau2 = array();
$forhau3 = array();
for($v=0; $v<=120; $v++){
$forhhau1[] = $snm2hau1[$v];
$forhhau2[] = $snm2hau2[$v];
$forhhau3[] = $snm2hau3[$v];
}
$forhau1 = $forhhau1;
$forhau2 = $forhhau2;
$forhau3 = $forhhau3;
//print_r($array_all_irs);

	$array_all_hau = array(array_filter($forhau1), array_filter($forhau2), array_filter($forhau3));
	$countinghau = 0;
	while($countinghau <= 120){
	if(count(array_column($array_all_hau, $countinghau)) == 3){
	$hauf2[] = round(array_sum(array_column($array_all_hau, $countinghau))/3);
	}
	else if(count(array_column($array_all_hau, $countinghau)) == 2){
	$hauf2[] = round(array_sum(array_column($array_all_hau, $countinghau))/2);
	}
	else if(count(array_column($array_all_hau, $countinghau)) == 1){
	$hauf2[] = round(array_sum(array_column($array_all_hau, $countinghau))/1);
	}
	else{
	$hauf2[] = round(array_sum(array_column($array_all_hau, $countinghau))/3);	
	}
	$countinghau++;
	}
	$hauf = implode("-",array_filter($hauf2));
	$haumx2 = explode("-",$hauf);
	$haumx = max(explode("-",$hauf));
	$stnameandscoreHau = array_combine($achaukeys,$haumx2);
	$maxinallsub = $haumx;			
	}
	else if($su == 'History'){
		$resultmxbystunamehis1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='History' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehis1))
	{	
		$snm2his1[] = $rsn['score'];
		$stin2his[] = $rsn['student_name'];
	}
	$achisf = array_combine($stin2his,$snm2his1);
	$resultmxbystunamehis2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='History' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehis2))
	{	
		$snm2his2[] = $rsn['score'];
	    $stin2his2[] = $rsn['student_name'];
	}
	$achiss = array_combine($stin2his2,$snm2his2);
	$resultmxbystunamehis3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='History' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehis3))
	{	
		$snm2his3[] = $rsn['score'];
		$stin2his3[] = $rsn['student_name'];
	}
	$achist = array_combine($stin2his3,$snm2his3);
	$arinall = array($achisf, $achiss, $achist);
	//print_r($arinall);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$achiskeys = (array_keys($largest_arr));
	
$forhis1 = array();
$forhis2 = array();
$forhis3 = array();
for($v=0; $v<=120; $v++){
$forhhis1[] = $snm2his1[$v];
$forhhis2[] = $snm2his2[$v];
$forhhis3[] = $snm2his3[$v];
}
$forhis1 = $forhhis1;
$forhis2 = $forhhis2;
$forhis3 = $forhhis3;
//print_r($array_all_irs);

	$array_all_his = array(array_filter($forhis1), array_filter($forhis2), array_filter($forhis3));
	$countinghis = 0;
	while($countinghis <= 120){
	if(count(array_column($array_all_his, $countinghis)) == 3){
	$hisf2[] = round(array_sum(array_column($array_all_his, $countinghis))/3);
	}
	else if(count(array_column($array_all_his, $countinghis)) == 2){
	$hisf2[] = round(array_sum(array_column($array_all_his, $countinghis))/2);
	}
	else if(count(array_column($array_all_his, $countinghis)) == 1){
	$hisf2[] = round(array_sum(array_column($array_all_his, $countinghis))/1);
	}
	else{
	$hisf2[] = round(array_sum(array_column($array_all_his, $countinghis))/3);	
	}
	$countinghis++;
	}
	$hisf = implode("-",array_filter($hisf2));
	$hismx2 = explode("-",$hisf);
	$hismx = max(explode("-",$hisf));
	$stnameandscoreHis = array_combine($achiskeys,$hismx2);
	$maxinallsub = $hismx;			
	}
		else if($su == 'ICT'){
		$resultmxbystunameict1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='ICT' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameict1))
	{	
		$snm2ict1[] = $rsn['score'];
		$stin2ict[] = $rsn['student_name'];
	}
	$acictf = array_combine($stin2ict,$snm2ict1);
	$resultmxbystunameict2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='ICT' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameict2))
	{	
		$snm2ict2[] = $rsn['score'];
	    $stin2ict2[] = $rsn['student_name'];
	}
	$acicts = array_combine($stin2ict2,$snm2ict2);
	$resultmxbystunameict3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='ICT' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameict3))
	{	
		$snm2ict3[] = $rsn['score'];
		$stin2ict3[] = $rsn['student_name'];
	}
	$acictt = array_combine($stin2ict3,$snm2ict3);
	$arinall = array($acictf, $acicts, $acictt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acictkeys = (array_keys($largest_arr));
	
$forict1 = array();
$forict2 = array();
$forict3 = array();
for($v=0; $v<=120; $v++){
$foriict1[] = $snm2ict1[$v];
$foriict2[] = $snm2ict2[$v];
$foriict3[] = $snm2ict3[$v];
}
$forict1 = $foriict1;
$forict2 = $foriict2;
$forict3 = $foriict3;

	$array_all_ict = array(array_filter($forict1), array_filter($forict2), array_filter($forict3));
	$countingict = 0;
	while($countingict <= 120){
	if(count(array_column($array_all_ict, $countingict)) == 3){
	$ictf2[] = round(array_sum(array_column($array_all_ict, $countingict))/3);
	}
	else if(count(array_column($array_all_ict, $countingict)) == 2){
	$ictf2[] = round(array_sum(array_column($array_all_ict, $countingict))/2);
	}
	else if(count(array_column($array_all_ict, $countingict)) == 1){
	$ictf2[] = round(array_sum(array_column($array_all_ict, $countingict))/1);
	}
	else{
	$ictf2[] = round(array_sum(array_column($array_all_ict, $countingict))/3);	
	}
	$countingict++;
	}
	$ictf = implode("-",array_filter($ictf2));
	$ictmx2 = explode("-",$ictf);
	$ictmx = max(explode("-",$ictf));
	$stnameandscoreIct = array_combine($acictkeys,$ictmx2);
	$maxinallsub = $ictmx;			
	}
	else if($su == 'Igbo'){
		$resultmxbystunameigb1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Igbo' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameigb1))
	{	
		$snm2igb1[] = $rsn['score'];
		$stin2igb[] = $rsn['student_name'];
	}
	$acigbf = array_combine($stin2igb,$snm2igb1);
	$resultmxbystunameigb2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Igbo' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameigb2))
	{	
		$snm2igb2[] = $rsn['score'];
	    $stin2igb2[] = $rsn['student_name'];
	}
	$acigbs = array_combine($stin2igb2,$snm2igb2);
	$resultmxbystunameigb3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Igbo' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameigb3))
	{	
		$snm2igb3[] = $rsn['score'];
		$stin2igb3[] = $rsn['student_name'];
	}
	$acigbt = array_combine($stin2igb3,$snm2igb3);
	$arinall = array($acigbf, $acigbs, $acigbt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acigbkeys = (array_keys($largest_arr));
	
$forigb1 = array();
$forigb2 = array();
$forigb3 = array();
for($v=0; $v<=120; $v++){
$foriigb1[] = $snm2igb1[$v];
$foriigb2[] = $snm2igb2[$v];
$foriigb3[] = $snm2igb3[$v];
}
$forigb1 = $foriigb1;
$forigb2 = $foriigb2;
$forigb3 = $foriigb3;

	$array_all_igb = array(array_filter($forigb1), array_filter($forigb2), array_filter($forigb3));
	$countingigb = 0;
	while($countingigb <= 120){
	if(count(array_column($array_all_igb, $countingigb)) == 3){
	$igbf2[] = round(array_sum(array_column($array_all_igb, $countingigb))/3);
	}
	else if(count(array_column($array_all_igb, $countingigb)) == 2){
	$igbf2[] = round(array_sum(array_column($array_all_igb, $countingigb))/2);
	}
	else if(count(array_column($array_all_igb, $countingigb)) == 1){
	$igbf2[] = round(array_sum(array_column($array_all_igb, $countingigb))/1);
	}
	else{
	$igbf2[] = round(array_sum(array_column($array_all_igb, $countingigb))/3);	
	}
	$countingigb++;
	}
	$igbf = implode("-",array_filter($igbf2));
	$igbmx2 = explode("-",$igbf);
	$igbmx = max(explode("-",$igbf));
	$stnameandscoreIgb = array_combine($acigbkeys,$igbmx2);
	$maxinallsub = $igbmx;			
	}
	
	else if($su == 'Islamic Religious Studies'){
		$resultmxbystunameirs1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Islamic Religious Studies' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameirs1))
	{	
		$snm2irs1[] = $rsn['score'];
		$stin2irs[] = $rsn['student_name'];
	}
	$acirsf = array_combine($stin2irs,$snm2irs1);
	$resultmxbystunameirs2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Islamic Religious Studies' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameirs2))
	{	
		$snm2irs2[] = $rsn['score'];
	    $stin2irs2[] = $rsn['student_name'];
	}
	$acirss = array_combine($stin2irs2,$snm2irs2);
	$resultmxbystunameirs3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Islamic Religious Studies' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameirs3))
	{	
		$snm2irs3[] = $rsn['score'];
		$stin2irs3[] = $rsn['student_name'];
	}
	$acirst = array_combine($stin2irs3,$snm2irs3);
	$arinall = array($acirsf, $acirss, $acirst);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acirskeys = (array_keys($largest_arr));
	
$forirs1 = array();
$forirs2 = array();
$forirs3 = array();
for($v=0; $v<=120; $v++){
$foriirs1[] = $snm2irs1[$v];
$foriirs2[] = $snm2irs2[$v];
$foriirs3[] = $snm2irs3[$v];
}
$forirs1 = $foriirs1;
$forirs2 = $foriirs2;
$forirs3 = $foriirs3;

	$array_all_irs = array(array_filter($forirs1), array_filter($forirs2), array_filter($forirs3));
	$countingirs = 0;
	while($countingirs <= 120){
	if(count(array_column($array_all_irs, $countingirs)) == 3){
	$irsf2[] = round(array_sum(array_column($array_all_irs, $countingirs))/3);
	}
	else if(count(array_column($array_all_irs, $countingirs)) == 2){
	$irsf2[] = round(array_sum(array_column($array_all_irs, $countingirs))/2);
	}
	else if(count(array_column($array_all_irs, $countingirs)) == 1){
	$irsf2[] = round(array_sum(array_column($array_all_irs, $countingirs))/1);
	}
	else{
	$irsf2[] = round(array_sum(array_column($array_all_irs, $countingirs))/3);	
	}
	$countingirs++;
	}
	$irsf = implode("-",array_filter($irsf2));
	$irsmx2 = explode("-",$irsf);
	$irsmx = max(explode("-",$irsf));
	$stnameandscoreIrs = array_combine($acirskeys,$irsmx2);
	$maxinallsub = $irsmx;			
	}
	
	else if($su == 'Literature in English'){
		$resultmxbystunamelit1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Literature in English' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamelit1))
	{	
		$snm2lit1[] = $rsn['score'];
		$stin2lit[] = $rsn['student_name'];
	}
	$aclitf = array_combine($stin2lit,$snm2lit1);
	$resultmxbystunamelit2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Literature in English' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamelit2))
	{	
		$snm2lit2[] = $rsn['score'];
	    $stin2lit2[] = $rsn['student_name'];
	}
	$aclits = array_combine($stin2lit2,$snm2lit2);
	$resultmxbystunamelit3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Literature in English' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamelit3))
	{	
		$snm2lit3[] = $rsn['score'];
		$stin2lit3[] = $rsn['student_name'];
	}
	$aclitt = array_combine($stin2lit3,$snm2lit3);
	$arinall = array($aclitf, $aclits, $aclitt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$aclitkeys = (array_keys($largest_arr));
	
$forlit1 = array();
$forlit2 = array();
$forlit3 = array();
for($v=0; $v<=120; $v++){
$forllit1[] = $snm2lit1[$v];
$forllit2[] = $snm2lit2[$v];
$forllit3[] = $snm2lit3[$v];
}
$forlit1 = $forllit1;
$forlit2 = $forllit2;
$forlit3 = $forllit3;

	$array_all_lit = array(array_filter($forlit1), array_filter($forlit2), array_filter($forlit3));
	$countinglit = 0;
	while($countinglit <= 120){
	if(count(array_column($array_all_lit, $countinglit)) == 3){
	$litf2[] = round(array_sum(array_column($array_all_lit, $countinglit))/3);
	}
	else if(count(array_column($array_all_lit, $countinglit)) == 2){
	$litf2[] = round(array_sum(array_column($array_all_lit, $countinglit))/2);
	}
	else if(count(array_column($array_all_lit, $countinglit)) == 1){
	$litf2[] = round(array_sum(array_column($array_all_lit, $countinglit))/1);
	}
	else{
	$litf2[] = round(array_sum(array_column($array_all_lit, $countinglit))/3);	
	}
	$countinglit++;
	}
	$litf = implode("-",array_filter($litf2));
	$litmx2 = explode("-",$litf);
	$litmx = max(explode("-",$litf));
	$stnameandscoreLit = array_combine($aclitkeys,$litmx2);
	$maxinallsub = $litmx;			
	}
		else if($su == 'Marketing'){
		$resultmxbystunamemar1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Marketing' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemar1))
	{	
		$snm2mar1[] = $rsn['score'];
		$stin2mar[] = $rsn['student_name'];
	}
	$acmarf = array_combine($stin2mar,$snm2mar1);
	$resultmxbystunamemar2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Marketing' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemar2))
	{	
		$snm2mar2[] = $rsn['score'];
	    $stin2mar2[] = $rsn['student_name'];
	}
	$acmars = array_combine($stin2mar2,$snm2mar2);
	$resultmxbystunamemar3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Marketing' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemar3))
	{	
		$snm2mar3[] = $rsn['score'];
		$stin2mar3[] = $rsn['student_name'];
	}
	$acmart = array_combine($stin2mar3,$snm2mar3);
	$arinall = array($acmarf, $acmars, $acmart);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acmarkeys = (array_keys($largest_arr));
	
$formar1 = array();
$formar2 = array();
$formar3 = array();
for($v=0; $v<=120; $v++){
$formmar1[] = $snm2mar1[$v];
$formmar2[] = $snm2mar2[$v];
$formmar3[] = $snm2mar3[$v];
}
$formar1 = $formmar1;
$formar2 = $formmar2;
$formar3 = $formmar3;

	$array_all_mar = array(array_filter($formar1), array_filter($formar2), array_filter($formar3));
	$countingmar = 0;
	while($countingmar <= 120){
	if(count(array_column($array_all_mar, $countingmar)) == 3){
	$marf2[] = round(array_sum(array_column($array_all_mar, $countingmar))/3);
	}
	else if(count(array_column($array_all_mar, $countingmar)) == 2){
	$marf2[] = round(array_sum(array_column($array_all_mar, $countingmar))/2);
	}
	else if(count(array_column($array_all_mar, $countingmar)) == 1){
	$marf2[] = round(array_sum(array_column($array_all_mar, $countingmar))/1);
	}
	else{
	$marf2[] = round(array_sum(array_column($array_all_mar, $countingmar))/3);	
	}
	$countingmar++;
	}
	$marf = implode("-",array_filter($marf2));
	$marmx2 = explode("-",$marf);
	$marmx = max(explode("-",$marf));
	$stnameandscoreMar = array_combine($acmarkeys,$marmx2);
	$maxinallsub = $marmx;			
	}
		else if($su == 'PHE'){
		$resultmxbystunamephe1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='PHE' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephe1))
	{	
		$snm2phe1[] = $rsn['score'];
		$stin2phe[] = $rsn['student_name'];
	}
	$acphef = array_combine($stin2phe,$snm2phe1);
	$resultmxbystunamephe2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='PHE' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephe2))
	{	
		$snm2phe2[] = $rsn['score'];
	    $stin2phe2[] = $rsn['student_name'];
	}
	$acphes = array_combine($stin2phe2,$snm2phe2);
	$resultmxbystunamephe3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='PHE' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephe3))
	{	
		$snm2phe3[] = $rsn['score'];
		$stin2phe3[] = $rsn['student_name'];
	}
	$acphet = array_combine($stin2phe3,$snm2phe3);
	$arinall = array($acphef, $acphes, $acphet);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acphekeys = (array_keys($largest_arr));
	
$forphe1 = array();
$forphe2 = array();
$forphe3 = array();
for($v=0; $v<=120; $v++){
$forpphe1[] = $snm2phe1[$v];
$forpphe2[] = $snm2phe2[$v];
$forpphe3[] = $snm2phe3[$v];
}
$forphe1 = $forpphe1;
$forphe2 = $forpphe2;
$forphe3 = $forpphe3;

	$array_all_phe = array(array_filter($forphe1), array_filter($forphe2), array_filter($forphe3));
	$countingphe = 0;
	while($countingphe <= 120){
	if(count(array_column($array_all_phe, $countingphe)) == 3){
	$phef2[] = round(array_sum(array_column($array_all_phe, $countingphe))/3);
	}
	else if(count(array_column($array_all_phe, $countingphe)) == 2){
	$phef2[] = round(array_sum(array_column($array_all_phe, $countingphe))/2);
	}
	else if(count(array_column($array_all_phe, $countingphe)) == 1){
	$phef2[] = round(array_sum(array_column($array_all_phe, $countingphe))/1);
	}
	else{
	$phef2[] = round(array_sum(array_column($array_all_phe, $countingphe))/3);	
	}
	$countingphe++;
	}
	$phef = implode("-",array_filter($phef2));
	$phemx2 = explode("-",$phef);
	$phemx = max(explode("-",$phef));
	$stnameandscorePhe = array_combine($acphekeys,$phemx2);
	$maxinallsub = $phemx;			
	}
	
	else if($su == 'Phonics'){
		$resultmxbystunamepho1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Phonics' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamepho1))
	{	
		$snm2pho1[] = $rsn['score'];
		$stin2pho[] = $rsn['student_name'];
	}
	$acphof = array_combine($stin2pho,$snm2pho1);
	$resultmxbystunamepho2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Phonics' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamepho2))
	{	
		$snm2pho2[] = $rsn['score'];
	    $stin2pho2[] = $rsn['student_name'];
	}
	$acphos = array_combine($stin2pho2,$snm2pho2);
	$resultmxbystunamepho3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Phonics' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamepho3))
	{	
		$snm2pho3[] = $rsn['score'];
		$stin2pho3[] = $rsn['student_name'];
	}
	$acphot = array_combine($stin2pho3,$snm2pho3);
	$arinall = array($acphof, $acphos, $acphot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acphokeys = (array_keys($largest_arr));
	
$forpho1 = array();
$forpho2 = array();
$forpho3 = array();
for($v=0; $v<=120; $v++){
$forppho1[] = $snm2pho1[$v];
$forppho2[] = $snm2pho2[$v];
$forppho3[] = $snm2pho3[$v];
}
$forpho1 = $forppho1;
$forpho2 = $forppho2;
$forpho3 = $forppho3;

	$array_all_pho = array(array_filter($forpho1), array_filter($forpho2), array_filter($forpho3));
	$countingpho = 0;
	while($countingpho <= 120){
	if(count(array_column($array_all_pho, $countingpho)) == 3){
	$phof2[] = round(array_sum(array_column($array_all_pho, $countingpho))/3);
	}
	else if(count(array_column($array_all_pho, $countingpho)) == 2){
	$phof2[] = round(array_sum(array_column($array_all_pho, $countingpho))/2);
	}
	else if(count(array_column($array_all_pho, $countingpho)) == 1){
	$phof2[] = round(array_sum(array_column($array_all_pho, $countingpho))/1);
	}
	else{
	$phof2[] = round(array_sum(array_column($array_all_pho, $countingpho))/3);	
	}
	$countingpho++;
	}
	$phof = implode("-",array_filter($phof2));
	$phomx2 = explode("-",$phof);
	$phomx = max(explode("-",$phof));
	$stnameandscorePho = array_combine($acphokeys,$phomx2);
	$maxinallsub = $phomx;			
	}
	
	else if($su == 'Physics'){
		$resultmxbystunamephy1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Physics' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephy1))
	{	
		$snm2phy1[] = $rsn['score'];
		$stin2phy[] = $rsn['student_name'];
	}
	$acphyf = array_combine($stin2phy,$snm2phy1);
	$resultmxbystunamephy2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Physics' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephy2))
	{	
		$snm2phy2[] = $rsn['score'];
	    $stin2phy2[] = $rsn['student_name'];
	}
	$acphys = array_combine($stin2phy2,$snm2phy2);
	$resultmxbystunamephy3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Physics' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephy3))
	{	
		$snm2phy3[] = $rsn['score'];
		$stin2phy3[] = $rsn['student_name'];
	}
	$acphyt = array_combine($stin2phy3,$snm2phy3);
	$arinall = array($acphyf, $acphys, $acphyt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acphykeys = (array_keys($largest_arr));
	
$forphy1 = array();
$forphy2 = array();
$forphy3 = array();
for($v=0; $v<=120; $v++){
$forpphy1[] = $snm2phy1[$v];
$forpphy2[] = $snm2phy2[$v];
$forpphy3[] = $snm2phy3[$v];
}
$forphy1 = $forpphy1;
$forphy2 = $forpphy2;
$forphy3 = $forpphy3;

	$array_all_phy = array(array_filter($forphy1), array_filter($forphy2), array_filter($forphy3));
	$countingphy = 0;
	while($countingphy <= 120){
	if(count(array_column($array_all_phy, $countingphy)) == 3){
	$phyf2[] = round(array_sum(array_column($array_all_phy, $countingphy))/3);
	}
	else if(count(array_column($array_all_phy, $countingphy)) == 2){
	$phyf2[] = round(array_sum(array_column($array_all_phy, $countingphy))/2);
	}
	else if(count(array_column($array_all_phy, $countingphy)) == 1){
	$phyf2[] = round(array_sum(array_column($array_all_phy, $countingphy))/1);
	}
	else{
	$phyf2[] = round(array_sum(array_column($array_all_phy, $countingphy))/3);	
	}
	$countingphy++;
	}
	$phyf = implode("-",array_filter($phyf2));
	$phymx2 = explode("-",$phyf);
	$phymx = max(explode("-",$phyf));
	$stnameandscorePhy = array_combine($acphykeys,$phymx2);
	$maxinallsub = $phymx;			
	}
	else if($su == 'Social Studies'){
		$resultmxbystunamesoc1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Social Studies' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesoc1))
	{	
		$snm2soc1[] = $rsn['score'];
		$stin2soc[] = $rsn['student_name'];
	}
	$acsocf = array_combine($stin2soc,$snm2soc1);
	$resultmxbystunamesoc2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Social Studies' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesoc2))
	{	
		$snm2soc2[] = $rsn['score'];
	    $stin2soc2[] = $rsn['student_name'];
	}
	$acsocs = array_combine($stin2soc2,$snm2soc2);
	$resultmxbystunamesoc3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Social Studies' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesoc3))
	{	
		$snm2soc3[] = $rsn['score'];
		$stin2soc3[] = $rsn['student_name'];
	}
	$acsoct = array_combine($stin2soc3,$snm2soc3);
	$arinall = array($acsocf, $acsocs, $acsoct);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acsockeys = (array_keys($largest_arr));
	
$forsoc1 = array();
$forsoc2 = array();
$forsoc3 = array();
for($v=0; $v<=120; $v++){
$forssoc1[] = $snm2soc1[$v];
$forssoc2[] = $snm2soc2[$v];
$forssoc3[] = $snm2soc3[$v];
}
$forsoc1 = $forssoc1;
$forsoc2 = $forssoc2;
$forsoc3 = $forssoc3;

	$array_all_soc = array(array_filter($forsoc1), array_filter($forsoc2), array_filter($forsoc3));
	$countingsoc = 0;
	while($countingsoc <= 120){
	if(count(array_column($array_all_soc, $countingsoc)) == 3){
	$socf2[] = round(array_sum(array_column($array_all_soc, $countingsoc))/3);
	}
	else if(count(array_column($array_all_soc, $countingsoc)) == 2){
	$socf2[] = round(array_sum(array_column($array_all_soc, $countingsoc))/2);
	}
	else if(count(array_column($array_all_soc, $countingsoc)) == 1){
	$socf2[] = round(array_sum(array_column($array_all_soc, $countingsoc))/1);
	}
	else{
	$socf2[] = round(array_sum(array_column($array_all_soc, $countingsoc))/3);	
	}
	$countingsoc++;
	}
	$socf = implode("-",array_filter($socf2));
	$socmx2 = explode("-",$socf);
	$socmx = max(explode("-",$socf));
	$stnameandscoreSoc = array_combine($acsockeys,$socmx2);
	$maxinallsub = $socmx;			
	}
		else if($su == 'Sociology'){
		$resultmxbystunamesocio1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Sociology' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesocio1))
	{	
		$snm2socio1[] = $rsn['score'];
		$stin2socio[] = $rsn['student_name'];
	}
	$acsociof = array_combine($stin2socio,$snm2socio1);
	$resultmxbystunamesocio2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Sociology' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesocio2))
	{	
		$snm2socio2[] = $rsn['score'];
	    $stin2socio2[] = $rsn['student_name'];
	}
	$acsocios = array_combine($stin2socio2,$snm2socio2);
	$resultmxbystunamesocio3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Sociology' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesocio3))
	{	
		$snm2socio3[] = $rsn['score'];
		$stin2socio3[] = $rsn['student_name'];
	}
	$acsociot = array_combine($stin2socio3,$snm2socio3);
	$arinall = array($acsociof, $acsocios, $acsociot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acsociokeys = (array_keys($largest_arr));
	
$forsocio1 = array();
$forsocio2 = array();
$forsocio3 = array();
for($v=0; $v<=120; $v++){
$forssocio1[] = $snm2socio1[$v];
$forssocio2[] = $snm2socio2[$v];
$forssocio3[] = $snm2socio3[$v];
}
$forsocio1 = $forssocio1;
$forsocio2 = $forssocio2;
$forsocio3 = $forssocio3;

	$array_all_socio = array(array_filter($forsocio1), array_filter($forsocio2), array_filter($forsocio3));
	$countingsocio = 0;
	while($countingsocio <= 120){
	if(count(array_column($array_all_socio, $countingsocio)) == 3){
	$sociof2[] = round(array_sum(array_column($array_all_socio, $countingsocio))/3);
	}
	else if(count(array_column($array_all_socio, $countingsocio)) == 2){
	$sociof2[] = round(array_sum(array_column($array_all_socio, $countingsocio))/2);
	}
	else if(count(array_column($array_all_socio, $countingsocio)) == 1){
	$sociof2[] = round(array_sum(array_column($array_all_socio, $countingsocio))/1);
	}
	else{
	$sociof2[] = round(array_sum(array_column($array_all_socio, $countingsocio))/3);	
	}
	$countingsocio++;
	}
	$sociof = implode("-",array_filter($sociof2));
	$sociomx2 = explode("-",$sociof);
	$sociomx = max(explode("-",$sociof));
	$stnameandscoreSocio = array_combine($acsociokeys,$sociomx2);
	$maxinallsub = $sociomx;			
	}
	else if($su == 'TD'){
		$resultmxbystunametd1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='TD' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunametd1))
	{	
		$snm2td1[] = $rsn['score'];
		$stin2td[] = $rsn['student_name'];
	}
	$actdf = array_combine($stin2td,$snm2td1);
	$resultmxbystunametd2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='TD' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunametd2))
	{	
		$snm2td2[] = $rsn['score'];
	    $stin2td2[] = $rsn['student_name'];
	}
	$actds = array_combine($stin2td2,$snm2td2);
	$resultmxbystunametd3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='TD' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunametd3))
	{	
		$snm2td3[] = $rsn['score'];
		$stin2td3[] = $rsn['student_name'];
	}
	$actdt = array_combine($stin2td3,$snm2td3);
	$arinall = array($actdf, $actds, $actdt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$actdkeys = (array_keys($largest_arr));
	
$fortd1 = array();
$fortd2 = array();
$fortd3 = array();
for($v=0; $v<=120; $v++){
$forttd1[] = $snm2td1[$v];
$forttd2[] = $snm2td2[$v];
$forttd3[] = $snm2td3[$v];
}
$fortd1 = $forttd1;
$fortd2 = $forttd2;
$fortd3 = $forttd3;

	$array_all_td = array(array_filter($fortd1), array_filter($fortd2), array_filter($fortd3));
	$countingtd = 0;
	while($countingtd <= 120){
	if(count(array_column($array_all_td, $countingtd)) == 3){
	$tdf2[] = round(array_sum(array_column($array_all_td, $countingtd))/3);
	}
	else if(count(array_column($array_all_td, $countingtd)) == 2){
	$tdf2[] = round(array_sum(array_column($array_all_td, $countingtd))/2);
	}
	else if(count(array_column($array_all_td, $countingtd)) == 1){
	$tdf2[] = round(array_sum(array_column($array_all_td, $countingtd))/1);
	}
	else{
	$tdf2[] = round(array_sum(array_column($array_all_td, $countingtd))/3);	
	}
	$countingtd++;
	}
	$tdf = implode("-",array_filter($tdf2));
	$tdmx2 = explode("-",$tdf);
	$tdmx = max(explode("-",$tdf));
	$stnameandscoreTd = array_combine($actdkeys,$tdmx2);
	$maxinallsub = $tdmx;			
	}
	else if($su == 'VA'){
		$resultmxbystunameva1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='VA' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameva1))
	{	
		$snm2va1[] = $rsn['score'];
		$stin2va[] = $rsn['student_name'];
	}
	$acvaf = array_combine($stin2va,$snm2va1);
	$resultmxbystunameva2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='VA' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameva2))
	{	
		$snm2va2[] = $rsn['score'];
	    $stin2va2[] = $rsn['student_name'];
	}
	$acvas = array_combine($stin2va2,$snm2va2);
	$resultmxbystunameva3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='VA' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameva3))
	{	
		$snm2va3[] = $rsn['score'];
		$stin2va3[] = $rsn['student_name'];
	}
	$acvat = array_combine($stin2va3,$snm2va3);
	$arinall = array($acvaf, $acvas, $acvat);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acvakeys = (array_keys($largest_arr));
	
$forva1 = array();
$forva2 = array();
$forva3 = array();
for($v=0; $v<=120; $v++){
$forvva1[] = $snm2va1[$v];
$forvva2[] = $snm2va2[$v];
$forvva3[] = $snm2va3[$v];
}
$forva1 = $forvva1;
$forva2 = $forvva2;
$forva3 = $forvva3;

	$array_all_va = array(array_filter($forva1), array_filter($forva2), array_filter($forva3));
	$countingva = 0;
	while($countingva <= 120){
	if(count(array_column($array_all_va, $countingva)) == 3){
	$vaf2[] = round(array_sum(array_column($array_all_va, $countingva))/3);
	}
	else if(count(array_column($array_all_va, $countingva)) == 2){
	$vaf2[] = round(array_sum(array_column($array_all_va, $countingva))/2);
	}
	else if(count(array_column($array_all_va, $countingva)) == 1){
	$vaf2[] = round(array_sum(array_column($array_all_va, $countingva))/1);
	}
	else{
	$vaf2[] = round(array_sum(array_column($array_all_va, $countingva))/3);	
	}
	$countingva++;
	}
	$vaf = implode("-",array_filter($vaf2));
	$vamx2 = explode("-",$vaf);
	$vamx = max(explode("-",$vaf));
	$stnameandscoreVa = array_combine($acvakeys,$vamx2);
	$maxinallsub = $vamx;			
	}
	else if($su == 'Vocational Aptitude'){
		$resultmxbystunamevap1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Vocational Aptitude' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevap1))
	{	
		$snm2vap1[] = $rsn['score'];
		$stin2vap[] = $rsn['student_name'];
	}
	$acvapf = array_combine($stin2vap,$snm2vap1);
	$resultmxbystunamevap2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Vocational Aptitude' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevap2))
	{	
		$snm2vap2[] = $rsn['score'];
	    $stin2vap2[] = $rsn['student_name'];
	}
	$acvaps = array_combine($stin2vap2,$snm2vap2);
	$resultmxbystunamevap3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Vocational Aptitude' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevap3))
	{	
		$snm2vap3[] = $rsn['score'];
		$stin2vap3[] = $rsn['student_name'];
	}
	$acvapt = array_combine($stin2vap3,$snm2vap3);
	$arinall = array($acvapf, $acvaps, $acvapt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acvapkeys = (array_keys($largest_arr));
	
$forvap1 = array();
$forvap2 = array();
$forvap3 = array();
for($v=0; $v<=120; $v++){
$forvvap1[] = $snm2vap1[$v];
$forvvap2[] = $snm2vap2[$v];
$forvvap3[] = $snm2vap3[$v];
}
$forvap1 = $forvvap1;
$forvap2 = $forvvap2;
$forvap3 = $forvvap3;

	$array_all_vap = array(array_filter($forvap1), array_filter($forvap2), array_filter($forvap3));
	$countingvap = 0;
	while($countingvap <= 120){
	if(count(array_column($array_all_vap, $countingvap)) == 3){
	$vapf2[] = round(array_sum(array_column($array_all_vap, $countingvap))/3);
	}
	else if(count(array_column($array_all_vap, $countingvap)) == 2){
	$vapf2[] = round(array_sum(array_column($array_all_vap, $countingvap))/2);
	}
	else if(count(array_column($array_all_vap, $countingvap)) == 1){
	$vapf2[] = round(array_sum(array_column($array_all_vap, $countingvap))/1);
	}
	else{
	$vapf2[] = round(array_sum(array_column($array_all_vap, $countingvap))/3);	
	}
	$countingvap++;
	}
	$vapf = implode("-",array_filter($vapf2));
	$vapmx2 = explode("-",$vapf);
	$vapmx = max(explode("-",$vapf));
	$stnameandscoreVap = array_combine($acvapkeys,$vapmx2);
	$maxinallsub = $vapmx;			
	}
	else if($su == 'Yoruba'){
		$resultmxbystunameyor1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Yoruba' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameyor1))
	{	
		$snm2yor1[] = $rsn['score'];
		$stin2yor[] = $rsn['student_name'];
	}
	$acyorf = array_combine($stin2yor,$snm2yor1);
	$resultmxbystunameyor2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Yoruba' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameyor2))
	{	
		$snm2yor2[] = $rsn['score'];
	    $stin2yor2[] = $rsn['student_name'];
	}
	$acyors = array_combine($stin2yor2,$snm2yor2);
	$resultmxbystunameyor3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Yoruba' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameyor3))
	{	
		$snm2yor3[] = $rsn['score'];
		$stin2yor3[] = $rsn['student_name'];
	}
	$acyort = array_combine($stin2yor3,$snm2yor3);
	$arinall = array($acyorf, $acyors, $acyort);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acyorkeys = (array_keys($largest_arr));
	
$foryor1 = array();
$foryor2 = array();
$foryor3 = array();
for($v=0; $v<=120; $v++){
$foryyor1[] = $snm2yor1[$v];
$foryyor2[] = $snm2yor2[$v];
$foryyor3[] = $snm2yor3[$v];
}
$foryor1 = $foryyor1;
$foryor2 = $foryyor2;
$foryor3 = $foryyor3;

	$array_all_yor = array(array_filter($foryor1), array_filter($foryor2), array_filter($foryor3));
	$countingyor = 0;
	while($countingyor <= 120){
	if(count(array_column($array_all_yor, $countingyor)) == 3){
	$yorf2[] = round(array_sum(array_column($array_all_yor, $countingyor))/3);
	}
	else if(count(array_column($array_all_yor, $countingyor)) == 2){
	$yorf2[] = round(array_sum(array_column($array_all_yor, $countingyor))/2);
	}
	else if(count(array_column($array_all_yor, $countingyor)) == 1){
	$yorf2[] = round(array_sum(array_column($array_all_yor, $countingyor))/1);
	}
	else{
	$yorf2[] = round(array_sum(array_column($array_all_yor, $countingyor))/3);	
	}
	$countingyor++;
	}
	$yorf = implode("-",array_filter($yorf2));
	$yormx2 = explode("-",$yorf);
	$yormx = max(explode("-",$yorf));
	$stnameandscoreYor = array_combine($acyorkeys,$yormx2);
	$maxinallsub = $yormx;			
	}
	else if($su == 'Quantitative Reasoning'){
		$resultmxbystunameqr1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Quantitative Reasoning' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameqr1))
	{	
		$snm2qr1[] = $rsn['score'];
		$stin2qr[] = $rsn['student_name'];
	}
	$acqrf = array_combine($stin2qr,$snm2qr1);
	$resultmxbystunameqr2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Quantitative Reasoning' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameqr2))
	{	
		$snm2qr2[] = $rsn['score'];
	    $stin2qr2[] = $rsn['student_name'];
	}
	$acqrs = array_combine($stin2qr2,$snm2qr2);
	$resultmxbystunameqr3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Quantitative Reasoning' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameqr3))
	{	
		$snm2qr3[] = $rsn['score'];
		$stin2qr3[] = $rsn['student_name'];
	}
	$acqrt = array_combine($stin2qr3,$snm2qr3);
	$arinall = array($acqrf, $acqrs, $acqrt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acqrkeys = (array_keys($largest_arr));
	
$forqr1 = array();
$forqr2 = array();
$forqr3 = array();
for($v=0; $v<=120; $v++){
$forqqr1[] = $snm2qr1[$v];
$forqqr2[] = $snm2qr2[$v];
$forqqr3[] = $snm2qr3[$v];
}
$forqr1 = $forqqr1;
$forqr2 = $forqqr2;
$forqr3 = $forqqr3;

	$array_all_qr = array(array_filter($forqr1), array_filter($forqr2), array_filter($forqr3));
	$countingqr = 0;
	while($countingqr <= 120){
	if(count(array_column($array_all_qr, $countingqr)) == 3){
	$qrf2[] = round(array_sum(array_column($array_all_qr, $countingqr))/3);
	}
	else if(count(array_column($array_all_qr, $countingqr)) == 2){
	$qrf2[] = round(array_sum(array_column($array_all_qr, $countingqr))/2);
	}
	else if(count(array_column($array_all_qr, $countingqr)) == 1){
	$qrf2[] = round(array_sum(array_column($array_all_qr, $countingqr))/1);
	}
	else{
	$qrf2[] = round(array_sum(array_column($array_all_qr, $countingqr))/3);	
	}
	$countingqr++;
	}
	$qrf = implode("-",array_filter($qrf2));
	$qrmx2 = explode("-",$qrf);
	$qrmx = max(explode("-",$qrf));
	$stnameandscoreQr = array_combine($acqrkeys,$qrmx2);
	$maxinallsub = $qrmx;			
	}
		else if($su == 'Verbal Reasoning'){
		$resultmxbystunamevr1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Verbal Reasoning' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevr1))
	{	
		$snm2vr1[] = $rsn['score'];
		$stin2vr[] = $rsn['student_name'];
	}
	$acvrf = array_combine($stin2vr,$snm2vr1);
	$resultmxbystunamevr2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Verbal Reasoning' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevr2))
	{	
		$snm2vr2[] = $rsn['score'];
	    $stin2vr2[] = $rsn['student_name'];
	}
	$acvrs = array_combine($stin2vr2,$snm2vr2);
	$resultmxbystunamevr3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Verbal Reasoning' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevr3))
	{	
		$snm2vr3[] = $rsn['score'];
		$stin2vr3[] = $rsn['student_name'];
	}
	$acvrt = array_combine($stin2vr3,$snm2vr3);
	$arinall = array($acvrf, $acvrs, $acvrt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acvrkeys = (array_keys($largest_arr));
	
$forvr1 = array();
$forvr2 = array();
$forvr3 = array();
for($v=0; $v<=120; $v++){
$forvvr1[] = $snm2vr1[$v];
$forvvr2[] = $snm2vr2[$v];
$forvvr3[] = $snm2vr3[$v];
}
$forvr1 = $forvvr1;
$forvr2 = $forvvr2;
$forvr3 = $forvvr3;

	$array_all_vr = array(array_filter($forvr1), array_filter($forvr2), array_filter($forvr3));
	$countingvr = 0;
	while($countingvr <= 120){
	if(count(array_column($array_all_vr, $countingvr)) == 3){
	$vrf2[] = round(array_sum(array_column($array_all_vr, $countingvr))/3);
	}
	else if(count(array_column($array_all_vr, $countingvr)) == 2){
	$vrf2[] = round(array_sum(array_column($array_all_vr, $countingvr))/2);
	}
	else if(count(array_column($array_all_vr, $countingvr)) == 1){
	$vrf2[] = round(array_sum(array_column($array_all_vr, $countingvr))/1);
	}
	else{
	$vrf2[] = round(array_sum(array_column($array_all_vr, $countingvr))/3);	
	}
	$countingvr++;
	}
	$vrf = implode("-",array_filter($vrf2));
	$vrmx2 = explode("-",$vrf);
	$vrmx = max(explode("-",$vrf));
	$stnameandscoreVr = array_combine($acvrkeys,$vrmx2);
	$maxinallsub = $vrmx;			
	}
		else if($su == 'Geography'){
		$resultmxbystunamegeo1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Geography' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegeo1))
	{	
		$snm2geo1[] = $rsn['score'];
		$stin2geo[] = $rsn['student_name'];
	}
	$acgeof = array_combine($stin2geo,$snm2geo1);
	$resultmxbystunamegeo2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Geography' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegeo2))
	{	
		$snm2geo2[] = $rsn['score'];
	    $stin2geo2[] = $rsn['student_name'];
	}
	$acgeos = array_combine($stin2geo2,$snm2geo2);
	$resultmxbystunamegeo3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Geography' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegeo3))
	{	
		$snm2geo3[] = $rsn['score'];
		$stin2geo3[] = $rsn['student_name'];
	}
	$acgeot = array_combine($stin2geo3,$snm2geo3);
	$arinall = array($acgeof, $acgeos, $acgeot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acgeokeys = (array_keys($largest_arr));
	
$forgeo1 = array();
$forgeo2 = array();
$forgeo3 = array();
for($v=0; $v<=120; $v++){
$forggeo1[] = $snm2geo1[$v];
$forggeo2[] = $snm2geo2[$v];
$forggeo3[] = $snm2geo3[$v];
}
$forgeo1 = $forggeo1;
$forgeo2 = $forggeo2;
$forgeo3 = $forggeo3;

	$array_all_geo = array(array_filter($forgeo1), array_filter($forgeo2), array_filter($forgeo3));
	$countinggeo = 0;
	while($countinggeo <= 120){
	if(count(array_column($array_all_geo, $countinggeo)) == 3){
	$geof2[] = round(array_sum(array_column($array_all_geo, $countinggeo))/3);
	}
	else if(count(array_column($array_all_geo, $countinggeo)) == 2){
	$geof2[] = round(array_sum(array_column($array_all_geo, $countinggeo))/2);
	}
	else if(count(array_column($array_all_geo, $countinggeo)) == 1){
	$geof2[] = round(array_sum(array_column($array_all_geo, $countinggeo))/1);
	}
	else{
	$geof2[] = round(array_sum(array_column($array_all_geo, $countinggeo))/3);	
	}
	$countinggeo++;
	}
	$geof = implode("-",array_filter($geof2));
	$geomx2 = explode("-",$geof);
	$geomx = max(explode("-",$geof));
	$stnameandscoreGeo = array_combine($acgeokeys,$geomx2);
	$maxinallsub = $geomx;			
	}	
	
	elseif($su == 'Handwriting'){							
	$resultmxbystunamehw1 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Handwriting' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehw1))
	{	
		$snm2hw1[] = $rsn['score'];
		$stin2hw[] = $rsn['student_name'];
	}
	$achwf = array_combine($stin2hw,$snm2hw1);
	$resultmxbystunamehw2 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Handwriting' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehw2))
	{	
		$snm2hw2[] = $rsn['score'];
	    $stin2hw2[] = $rsn['student_name'];
	}
	$achws = array_combine($stin2hw2,$snm2hw2);
	$resultmxbystunamehw3 = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND class_name='$class_name' AND subject='Handwriting' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehw3))
	{	
		$snm2hw3[] = $rsn['score'];
		$stin2hw3[] = $rsn['student_name'];
	}
	$achwt = array_combine($stin2hw3,$snm2hw3);
	$arinall = array($achwf, $achws, $achwt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$achwkeys = (array_keys($largest_arr));
	
$forhw1 = array();
for($v=0; $v<=120; $v++){
$forhhw1[] = $snm2hw1[$v];
}
$forhw1 = $forhhw1;

$forhw2 = array();
for($v=0; $v<=120; $v++){
$forhhw2[] = $snm2hw2[$v];
}
$forhw2 = $forhhw2;

$forhw3 = array();
for($v=0; $v<=120; $v++){
$forhhw3[] = $snm2hw3[$v];
}
$forhw3 = $forhhw3;

$array_all_hw = array(array_filter($forhw1), array_filter($forhw2), array_filter($forhw3));
	$countinghw = 0;
	while($countinghw <= 120){
	if(count(array_column($array_all_hw, $countinghw)) == 3){
	$hwf2[] = round(array_sum(array_column($array_all_hw, $countinghw))/3);
	}
	else if(count(array_column($array_all_hw, $countinghw)) == 2){
	$hwf2[] = round(array_sum(array_column($array_all_hw, $countinghw))/2);
	}
	else if(count(array_column($array_all_hw, $countinghw)) == 1){
	$hwf2[] = round(array_sum(array_column($array_all_hw, $countinghw))/1);
	}
	else{
	$hwf2[] = round(array_sum(array_column($array_all_hw, $countinghw))/3);	
	}
	$countinghw++;
	}
	$hwf = implode("-",array_filter($hwf2));
	$hwmx2 = explode("-",$hwf);
	$hwmx = max(explode("-",$hwf));
	$stnameandscoreHw = array_combine($achwkeys,$hwmx2);
	$maxinallsub = $hwmx;	
	}	
		else{	
			$maxinallsub = "-";	
		}
	
						echo '<tr><td>'.$su.'</td><td>'.$ct.'</td><td>'.$ex.'</td><td>'.$tt.'</td><td>'.$dd.'</td><td>'.$cc.'</td><td>'.$av.'</td><td>'.$maxinallsub.'</td><td id="mytd">'.round($ccav).'</td><td>'.$grade.'</td><td>'.$tn.'</td><td style="text-align: left;">'.$re.'</td></tr>';	
							$counted++;
							$arrsubj2[] = $su;
							$ca2[] = $ct;
							$exam2[] = $ex;
							$fir2[] = $cc;
							$sec2[] = $dd;
							$thir2[] = $tt;
							$av2[] = $av;
							$ccav2[] = round($ccav);
							$grad2[] = $grade;
							$teacher2[] = $tn;
							$remark2[] = $re;
							$maxinallsub2[] = $maxinallsub;
							}
							
							$arrsubj = $arrsubj2;
							$ca = $ca2;
							$exam = $exam2;
							$fir = $fir2;
							$sec = $sec2;
							$thir = $thir2;
							$avv = $av2;
							$ccavv = $ccav2;
							$grad = $grad2;
							$teacher = $teacher2;
							$remark = $remark2;						
							$hs = $maxinallsub2;
	}				
	else{
		echo '<tr id="heading"><td>SUBJECT</td><td>CA</td><td>EXAM</td><td>TOTAL</td><td>GRADE</td><td>TEACHER\'S NAME</td><td>REMARK</td></tr>';	
		$result = mysqli_query($db, "SELECT * FROM scores WHERE arms='$arms' AND student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
								$grbnt = mysqli_query($db, "SELECT grade FROM gradeband WHERE score='".$row["score"]."'");
							while($rowgrbnt = mysqli_fetch_assoc($grbnt))
							{
							$grade2	= $rowgrbnt['grade'];
							}
								
							$row2subject[] = $row["subject"];	
							$row2ca[] = $row["ca"];	
							$row2exam[] = $row["exam"];
							$row2score[] = $row["score"];
							$row2teacher_name[] = $row["teacher_name"];
							$row2remark[] = $row["remark"];
							$grad2[] = $grade;
								echo '<tr><td>'.$row["subject"].'</td><td>'.$row["ca"].'</td><td>'.$row["exam"].'</td><td>'.$row["score"].'</td><td>'.$grade.'</td><td>'.$row["teacher_name"].'</td><td style="text-align: left;">'.$row["remark"].'</td></tr>';	
							}	
							$arrsubj = $row2subject;	
							$ca = $row2ca;	
							$exam = $row2exam;
							$tt = $row2score;
							$grad = $grad2;
							$teacher = $row2teacher_name;
							$remark = $row2remark;		
	
	}
}

}

else if(isset($_POST['submit3'])){
$term = $_POST['term'];
$year = $_POST['year'];
$class_name = $_POST['class_name'];
$arms = $_POST['arms'];
$checker = $_POST['checker'];
$student_name = $_POST['student_name'];
	if($arms=="" OR $checker=="yes"){
if($term == "Third Term"){	
	$result1 = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	$sql2 = mysqli_query($db, "SELECT * FROM maxes where subjectname='$subject' AND classname='$class' AND yearname='$year' AND termname='$term' AND teachername='$tna' AND teacheridname='$tid' AND school='".$_SESSION["school"]."'");
					
						while($row1 = mysqli_fetch_assoc($result1))
							{ 
								$firsubject[] = $row1['subject'];
								$firscore[] = $row1['score'];
							}
							$firsubject11 = $firsubject;
							$firscore11 = $firscore;
							$c = array_combine($firsubject11, $firscore11);
							ksort($c);
							$c = array_values($c);
							
	$result2 = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
						while($row2 = mysqli_fetch_assoc($result2))
							{ 
								$secsubject[] = $row2['subject'];
								$secscore[] = $row2['score'];
							}
							$secsubject22 = $secsubject;
							$secscore22 = $secscore;
							$d = array_combine($secsubject22, $secscore22);
							ksort($d);
							$d = array_values($d);
				
							
	$result3 = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
						while($row3 = mysqli_fetch_assoc($result3))
							{ 
								$thirsubject[] = $row3['subject'];
								$thirscore[] = $row3['score'];
							}
							$thirsubject33 = $thirsubject;
							$thirscore33 = $thirscore;
							$t = array_combine($thirsubject33, $thirscore33);
							ksort($t);
							$t = array_values($t);						
							
							$e = array_map(function () {
							return array_sum(func_get_args());
							},$c, $d, $t);
							ksort($e);
		
							
	echo '<tr id="heading"><td>SUBJECT</td><td>CA</td><td>EXAM</td><td>THIRD TERM</td><td>SECOND TERM</td><td>FIRST TERM</td><td>AV. OF THREE TERMS</td><td>CLASS HIGHEST</td><td>CLASS AVERAGE</td><td>GRADE</td><td>TEACHER\'S NAME</td><td>REMARK</td></tr>';	
	
	
	$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."' ORDER BY subject ASC");
	
	$recav = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
	$recavmax = mysqli_query($db, "SELECT MAX(score) AS agrmax FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
	while($rowcav = mysqli_fetch_assoc($recav))
							{
							$agrcavin[]	= $rowcav['score'];
							}
							$agrcav = array_filter($agrcavin);
							$agrcav2 = array_sum($agrcav);
	$numbagr = count(array_filter($agrcav));
	$agrcav3 = $agrcav2/$numbagr;
	
	$recav1 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Basic Science' AND school='".$_SESSION["school"]."'");
	while($rowcav1 = mysqli_fetch_assoc($recav1))
							{
							$bascavin[]	= $rowcav1['score'];
							}
							$bascav = array_filter($bascavin);
							$bascav2 = array_sum($bascav);
	$numbbas = count(array_filter($bascav));
	$bascav3 = $bascav2/$numbbas;
	
	$recav2 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='English' AND school='".$_SESSION["school"]."'");
	$recav2max = mysqli_query($db, "SELECT MAX(score) AS engmax FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='English' AND school='".$_SESSION["school"]."'");
	while($rowcav2 = mysqli_fetch_assoc($recav2))
							{
							$engcavin[]	= $rowcav2['score'];
							}
							$engcav = array_filter($engcavin);
							$engcav2 = array_sum($engcav);
	$numbeng = count(array_filter($engcav));
	$engcav3 = round($engcav2/$numbeng);
	while($rowcav2max = mysqli_fetch_assoc($recav2max))
							{
							$engcavinmax[]	= $rowcav2max['engmax'];
							}
							$engcavmax = array_filter($engcavinmax);
							$engcav2max = array_sum($engcavmax);
	$numbengmax = count(array_filter($engcavmax));
	$engcav3max = $engcav2max/$numbengmax;
	//echo $engcav3max;
	
	$recav3 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Business Studies' AND school='".$_SESSION["school"]."'");
	while($rowcav3 = mysqli_fetch_assoc($recav3))
							{
							$buscavin[]	= $rowcav3['score'];
							}
							$buscav = array_filter($buscavin);
							$buscav2 = array_sum($buscav);
	$numbbus = count(array_filter($buscav));
	$buscav3 = round($buscav2/$numbbus);
	
	$recav4 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Catering' AND school='".$_SESSION["school"]."'");
	while($rowcav4 = mysqli_fetch_assoc($recav4))
							{
							$catcavin[]	= $rowcav4['score'];
							}
							$catcav = array_filter($catcavin);
							$catcav2 = array_sum($catcav);
	$numbcat = count(array_filter($catcav));
	$catcav3 = $catcav2/$numbcat;
	
	$recav5 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Civic Education' AND school='".$_SESSION["school"]."'");
	while($rowcav5 = mysqli_fetch_assoc($recav5))
							{
							$civcavin[]	= $rowcav5['score'];
							}
							$civcav = array_filter($civcavin);
							$civcav2 = array_sum($civcav);
	$numbciv = count(array_filter($civcav));
	$civcav3 = $civcav2/$numbciv;
	
	$recav6 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Crk' AND school='".$_SESSION["school"]."'");
	while($rowcav6 = mysqli_fetch_assoc($recav6))
							{
							$crkcavin[]	= $rowcav6['score'];
							}
							$crkcav = array_filter($crkcavin);
							$crkcav2 = array_sum($crkcav);
	$numbcrk = count(array_filter($crkcav));
	$crkcav3 = $crkcav2/$numbcrk;
	
	$recav7 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Food and Nutrition' AND school='".$_SESSION["school"]."'");
	while($rowcav7 = mysqli_fetch_assoc($recav7))
							{
							$foocavin[]	= $rowcav7['score'];
							}
							$foocav = array_filter($foocavin);
							$foocav2 = array_sum($foocav);
	$numbfoo = count(array_filter($foocav));
	$foocav3 = $foocav2/$numbfoo;
	
	$recav8 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='French' AND school='".$_SESSION["school"]."'");
	while($rowcav8 = mysqli_fetch_assoc($recav8))
							{
							$frecavin[]	= $rowcav8['score'];
							}
							$frecav = array_filter($frecavin);
							$frecav2 = array_sum($frecav);
	$numbfre = count(array_filter($frecav));
	$frecav3 = $frecav2/$numbfre;
	
	$recav9 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='ICT' AND school='".$_SESSION["school"]."'");
	while($rowcav9 = mysqli_fetch_assoc($recav9))
							{
							$ictcavin[]	= $rowcav9['score'];
							}
							$ictcav = array_filter($ictcavin);
							$ictcav2 = array_sum($ictcav);
	$numbict = count(array_filter($ictcav));
	$ictcav3 = $ictcav2/$numbict;
	
	$recav10 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Igbo' AND school='".$_SESSION["school"]."'");
	while($rowcav10 = mysqli_fetch_assoc($recav10))
							{
							$igbcavin[]	= $rowcav10['score'];
							}
							$igbcav = array_filter($igbcavin);
							$igbcav2 = array_sum($igbcav);
	$numbigb = count(array_filter($igbcav));
	$igbcav3 = $igbcav2/$numbigb;
	
	$recav11 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Mathematics' AND school='".$_SESSION["school"]."'");
	while($rowcav11 = mysqli_fetch_assoc($recav11))
							{
							$matcavin[]	= $rowcav11['score'];
							}
							$matcav = array_filter($matcavin);
							$matcav2 = array_sum($matcav);
	$numbmat = count(array_filter($matcav));
	$matcav3 = $matcav2/$numbmat;
	
	$recav12 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Music' AND school='".$_SESSION["school"]."'");
	while($rowcav12 = mysqli_fetch_assoc($recav12))
							{
							$muscavin[]	= $rowcav12['score'];
							}
							$muscav = array_filter($muscavin);
							$muscav2 = array_sum($muscav);
	$numbmus = count(array_filter($muscav));
	$muscav3 = $muscav2/$numbmus;
	
	$recav13 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='PHE' AND school='".$_SESSION["school"]."'");
	while($rowcav13 = mysqli_fetch_assoc($recav13))
							{
							$phecavin[]	= $rowcav13['score'];
							}
							$phecav = array_filter($phecavin);
							$phecav2 = array_sum($phecav);
	$numbphe = count(array_filter($phecav));
	$phecav3 = $phecav2/$numbphe;

	$recav14 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Social Studies' AND school='".$_SESSION["school"]."'");
	while($rowcav14 = mysqli_fetch_assoc($recav14))
							{
							$soccavin[]	= $rowcav14['score'];
							}
							$soccav = array_filter($soccavin);
							$soccav2 = array_sum($soccav);
	$numbsoc = count(array_filter($soccav));
	$soccav3 = $soccav2/$numbsoc;
	
	$recav15 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Biology' AND school='".$_SESSION["school"]."'");
	while($rowcav15 = mysqli_fetch_assoc($recav15))
							{
							$biocavin[]	= $rowcav15['score'];
							}
							$biocav = array_filter($biocavin);
							$biocav2 = array_sum($biocav);
	$numbbio = count(array_filter($biocav));
	$biocav3 = $biocav2/$numbbio;
	
	$recav16 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Chemistry' AND school='".$_SESSION["school"]."'");
	while($rowcav16 = mysqli_fetch_assoc($recav16))
							{
							$checavin[]	= $rowcav16['score'];
							}
							$checav = array_filter($checavin);
							$checav2 = array_sum($checav);
	$numbche = count(array_filter($checav));
	$checav3 = $checav2/$numbche;
	
	$recav17 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Economics' AND school='".$_SESSION["school"]."'");
	while($rowcav17 = mysqli_fetch_assoc($recav17))
							{
							$ecocavin[]	= $rowcav17['score'];
							}
							$ecocav = array_filter($ecocavin);
							$ecocav2 = array_sum($ecocav);
	$numbeco = count(array_filter($ecocav));
	$ecocav3 = $ecocav2/$numbeco;
	
	$recav18 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Government' AND school='".$_SESSION["school"]."'");
	while($rowcav18 = mysqli_fetch_assoc($recav18))
							{
							$govcavin[]	= $rowcav18['score'];
							}
							$govcav = array_filter($govcavin);
							$govcav2 = array_sum($govcav);
	$numbgov = count(array_filter($govcav));
	$govcav3 = $govcav2/$numbgov;
	
	$recav19 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='VA' AND school='".$_SESSION["school"]."'");
	while($rowcav19 = mysqli_fetch_assoc($recav19))
							{
							$vacavin[]	= $rowcav19['score'];
							}
							$vacav = array_filter($vacavin);
							$vacav2 = array_sum($vacav);
	$numbva = count(array_filter($vacav));
	$vacav3 = $vacav2/$numbva;
	
	$recav20 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='TD' AND school='".$_SESSION["school"]."'");
	while($rowcav20 = mysqli_fetch_assoc($recav20))
							{
							$tdcavin[]	= $rowcav20['score'];
							}
							$vacav = array_filter($tdcavin);
							$tdcav2 = array_sum($tdcav);
	$numbtd = count(array_filter($tdcav));
	$tdcav3 = $tdcav2/$numbtd;
	
	$recav21 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Sociology' AND school='".$_SESSION["school"]."'");
	while($rowcav21 = mysqli_fetch_assoc($recav21))
							{
							$socicavin[]	= $rowcav21['score'];
							}
							$socicav = array_filter($socicavin);
							$socicav2 = array_sum($socicav);
	$numbsoci = count(array_filter($socicav));
	$socicav3 = $socicav2/$numbsoci;
							
	$recav22 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Physics' AND school='".$_SESSION["school"]."'");
	while($rowcav22 = mysqli_fetch_assoc($recav22))
							{
							$phycavin[]	= $rowcav22['score'];
							}
							$phycav = array_filter($phycavin);
							$phycav2 = array_sum($phycav);
	$numbphy = count(array_filter($phycav));
	$phycav3 = $phycav2/$numbphy;
	
	$recav23 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Marketing' AND school='".$_SESSION["school"]."'");
	while($rowcav23 = mysqli_fetch_assoc($recav23))
							{
							$marcavin[]	= $rowcav23['score'];
							}
							$marcav = array_filter($marcavin);
							$marcav2 = array_sum($marcav);
	$numbmar = count(array_filter($marcav));
	$marcav3 = $marcav2/$numbmar;
	
	$recav24 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Lit in English' AND school='".$_SESSION["school"]."'");
	while($rowcav24 = mysqli_fetch_assoc($recav24))
							{
							$litcavin[]	= $rowcav24['score'];
							}
							$litcav = array_filter($litcavin);
							$litcav2 = array_sum($litcav);
	$numblit = count(array_filter($litcav));
	$litcav3 = $litcav2/$numblit;
	
	$recav25 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Yoruba' AND school='".$_SESSION["school"]."'");
	while($rowcav25 = mysqli_fetch_assoc($recav25))
							{
							$yorcavin[]	= $rowcav25['score'];
							}
							$yorcav = array_filter($yorcavin);
							$yorcav2 = array_sum($yorcav);
	$numbyor = count(array_filter($yorcav));
	$yorcav3 = $yorcav2/$numbyor;
	
	$recav26 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Quantitative Reasoning' AND school='".$_SESSION["school"]."'");
	$recavmax26 = mysqli_query($db, "SELECT MAX(score) AS qrmax FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Quantitative Reasoning' AND school='".$_SESSION["school"]."'");
	while($rowcav26 = mysqli_fetch_assoc($recav26))
							{
							$qrcavin[]	= $rowcav26['score'];
							}
							$qrcav = array_filter($qrcavin);
							$qrcav2 = array_sum($qrcav);
	$numbqr = count(array_filter($qrcav));
	$qrcav3 = $qrcav2/$numbqr;
	
	$recav27 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Quantitative Reasoning' AND school='".$_SESSION["school"]."'");
	$recavmax27 = mysqli_query($db, "SELECT MAX(score) AS vrmax FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Verbal Reasoning' AND school='".$_SESSION["school"]."'");
	while($rowcav27 = mysqli_fetch_assoc($recav27))
							{
							$vrcavin[]	= $rowcav27['score'];
							}
							$vrcav = array_filter($vrcavin);
							$vrcav2 = array_sum($vrcav);
	$numbvr = count(array_filter($vrcav));
	$vrcav3 = $vrcav2/$numbvr;
	
	$recav28 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Geography' AND school='".$_SESSION["school"]."'");
	$recavmax28 = mysqli_query($db, "SELECT MAX(score) AS agrmax FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Geography' AND school='".$_SESSION["school"]."'");
	while($rowcav28 = mysqli_fetch_assoc($recav28))
							{
							$geocavin[]	= $rowcav28['score'];
							}
							$geocav = array_filter($geocavin);
							$geocav2 = array_sum($geocav);
	$numbgeo = count(array_filter($geocav));
	$geocav3 = $geocav2/$numbgeo;
	
	$recav29 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Handwriting' AND school='".$_SESSION["school"]."'");
	while($rowcav29 = mysqli_fetch_assoc($recav29))
							{
							$hwcavin[]	= $rowcav29['score'];
							}
							$hwcav = array_filter($hwcavin);
							$hwcav2 = array_sum($hwcav);
	$numbhw = count(array_filter($hwcav));
	$hwcav3 = $hwcav2/$numbhw;
	
	$recav30 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Vocational Aptitude' AND school='".$_SESSION["school"]."'");
	while($rowcav30 = mysqli_fetch_assoc($recav30))
							{
							$vapcavin[]	= $rowcav30['score'];
							}
							$vapcav = array_filter($vapcavin);
							$vapcav2 = array_sum($vapcav);
	$numbvap = count(array_filter($vapcav));
	$vapcav3 = $vapcav2/$numbvap;
	
	$recav31 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Phonics' AND school='".$_SESSION["school"]."'");
	while($rowcav31 = mysqli_fetch_assoc($recav31))
							{
							$phocavin[]	= $rowcav31['score'];
							}
							$phocav = array_filter($phocavin);
							$phocav2 = array_sum($phocav);
	$numbpho = count(array_filter($phocav));
	$phocav3 = $phocav2/$numbpho;
	
	$recav32 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Islamic Religious Studies' AND school='".$_SESSION["school"]."'");
	while($rowcav32 = mysqli_fetch_assoc($recav32))
							{
							$irscavin[]	= $rowcav32['score'];
							}
							$irscav = array_filter($irscavin);
							$irscav2 = array_sum($irscav);
	$numbirs = count(array_filter($irscav));
	$irscav3 = $irscav2/$numbirs;
	
		$recav33 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Creative and Cultural Arts' AND school='".$_SESSION["school"]."'");
	while($rowcav33 = mysqli_fetch_assoc($recav33))
							{
							$ccacavin[]	= $rowcav33['score'];
							}
							$ccacav = array_filter($ccacavin);
							$ccacav2 = array_sum($ccacav);
	$numbcca = count(array_filter($ccacav));
	$ccacav3 = $ccacav2/$numbcca;
	
	$recav34 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='History' AND school='".$_SESSION["school"]."'");
	while($rowcav34 = mysqli_fetch_assoc($recav34))
							{
							$hiscavin[]	= $rowcav34['score'];
							}
							$hiscav = array_filter($hiscavin);
							$hiscav2 = array_sum($hiscav);
	$numbhis = count(array_filter($hiscav));
	$hiscav3 = $hiscav2/$numbhis;
	
	$recav35 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Hausa' AND school='".$_SESSION["school"]."'");
	while($rowcav35 = mysqli_fetch_assoc($recav35))
							{
							$haucavin[]	= $rowcav35['score'];
							}
							$haucav = array_filter($haucavin);
							$haucav2 = array_sum($haucav);
	$numbhau = count(array_filter($haucav));
	$haucav3 = $haucav2/$numbhau;
	
	$recav36 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Hausa' AND school='".$_SESSION["school"]."'");
	while($rowcav36 = mysqli_fetch_assoc($recav36))
							{
							$fincavin[]	= $rowcav36['score'];
							}
							$fincav = array_filter($fincavin);
							$fincav2 = array_sum($fincav);
	$numbfin = count(array_filter($fincav));
	$fincav3 = $fincav2/$numbfin;
	
	$engcount = 0;
	$counter = 0;
	$counted = 0;
	while($row = mysqli_fetch_assoc($result))
							{		
		$to = Array($c[$counted], $d[$counted], $t[$counted]);
		if(($t[$counted] == 0) AND ($c[$counted] != 0) AND ($d[$counted] != 0)){$avdiv = 2; $t[$counted] = "-";}
		elseif(($t[$counted] != 0) AND ($c[$counted] != 0) AND ($d[$counted] == 0)){$avdiv = 2; $d[$counted] = "-";}
		elseif(($t[$counted] != 0) AND ($c[$counted] == 0) AND ($d[$counted] != 0)){$avdiv = 2; $d[$counted] = "-";}
		elseif(($t[$counted] == 0) AND ($c[$counted] != 0) AND ($d[$counted] == 0)){$avdiv = 1; $t[$counted] = "-"; $d[$counted] = "-";}
		elseif(($t[$counted] == 0) AND ($c[$counted] == 0) AND ($d[$counted] != 0)){$avdiv = 1; $c[$counted] = "-"; $t[$counted] = "-";}
		elseif(($t[$counted] != 0) AND ($c[$counted] == 0) AND ($d[$counted] == 0)){$avdiv = 1; $c[$counted] = "-"; $d[$counted] = "-";}
		elseif(($t[$counted] != 0) AND ($c[$counted] != 0) AND ($d[$counted] != 0)){$avdiv = 3;}
		else{$avdiv = 3;}
		$to2 = array_sum($to);
		$av = round($to2/$avdiv);
								$cc = $c[$counted];
								$dd = $d[$counted];
								$tt = $t[$counted];				
								
								$grb = mysqli_query($db, "SELECT grade FROM gradeband WHERE score='$av'");
							while($rowgrb = mysqli_fetch_assoc($grb))
							{
							$grade2	= $rowgrb['grade'];
							}
							$grade = $grade2;
							
								if($row["subject"] == "Agricultural Science"){$ccav = $agrcav3;}
								elseif($row["subject"] == "Basic Science"){$ccav = $bascav3;}
								elseif($row["subject"] == "English"){$ccav = $engcav3;}
								elseif($row["subject"] == "Business Studies"){$ccav = $buscav3;}
								elseif($row["subject"] == "Catering"){$ccav = $catcav3;}
								elseif($row["subject"] == "Civic Education"){$ccav = $civcav3;}
								elseif($row["subject"] == "Crk"){$ccav = $crkcav3;}
								elseif($row["subject"] == "Food and Nutrition"){$ccav = $foocav3;}
								elseif($row["subject"] == "ICT"){$ccav = $ictcav3;}
								elseif($row["subject"] == "French"){$ccav = $frecav3;}
								elseif($row["subject"] == "Igbo"){$ccav = $igbcav3;}
								elseif($row["subject"] == "Mathematics"){$ccav = $matcav3;}
								elseif($row["subject"] == "Music"){$ccav = $muscav3;}
								elseif($row["subject"] == "PHE"){$ccav = $phecav3;}
								elseif($row["subject"] == "Social Studies"){$ccav = $soccav3;}
								elseif($row["subject"] == "Biology"){$ccav = $biocav3;}
								elseif($row["subject"] == "Chemistry"){$ccav = $checav3;}
								elseif($row["subject"] == "Economics"){$ccav = $ecocav3;}
								elseif($row["subject"] == "Government"){$ccav = $govcav3;}
								elseif($row["subject"] == "VA"){$ccav = $vacav3;}
								elseif($row["subject"] == "TD"){$ccav = $tdcav3;}
								elseif($row["subject"] == "Sociology"){$ccav = $socicav3;}
								elseif($row["subject"] == "Marketing"){$ccav = $marcav3;}
								elseif($row["subject"] == "Physics"){$ccav = $phycav3;}
								elseif($row["subject"] == "Lit in English"){$ccav = $litcav3;}
								elseif($row["subject"] == "Yoruba"){$ccav = $yorcav3;}
								elseif($row["subject"] == "Quantitative Reasoning"){$ccav = $qrcav3;}
								elseif($row["subject"] == "Verbal Reasoning"){$ccav = $vrcav3;}
								elseif($row["subject"] == "Geography"){$ccav = $geocav3;}
								elseif($row["subject"] == "Handwriting"){$ccav = $hwcav3;}
								elseif($row["subject"] == "Vocational Aptitude"){$ccav = $vapcav3;}
								elseif($row["subject"] == "Phonics"){$ccav = $phocav3;}
								elseif($row["subject"] == "Islamic Religious Studies"){$ccav = $irscav3;}
								elseif($row["subject"] == "Creative and Cultural Arts"){$ccav = $ccacav3;}
								elseif($row["subject"] == "History"){$ccav = $hiscav3;}
								elseif($row["subject"] == "Hausa"){$ccav = $haucav3;}
								elseif($row["subject"] == "Financial Accounting"){$ccav = $fincav3;}
								elseif($ccav == ""){$ccav = "-";}
								else{$ccav = "-";}
								$su = $row["subject"];
								$tn = $row["teacher_name"];
								$re = $row["remark"];
								$ct = $row["ca"];
								$ex = $row["exam"];
	
	if($su == 'English'){							
	$resultmxbystunameeng1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='English' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeng1))
	{	
		$snm2eng1[] = $rsn['score'];
		$stin2eng[] = $rsn['student_name'];
	}
	$acengf = array_combine($stin2eng,$snm2eng1);
	$resultmxbystunameeng2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='English' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeng2))
	{	
		$snm2eng2[] = $rsn['score'];
	    $stin2eng2[] = $rsn['student_name'];
	}
	$acengs = array_combine($stin2eng2,$snm2eng2);
	$resultmxbystunameeng3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='English' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeng3))
	{	
		$snm2eng3[] = $rsn['score'];
		$stin2eng3[] = $rsn['student_name'];
	}
	$acengt = array_combine($stin2eng3,$snm2eng3);
	$arinall = array($acengf, $acengs, $acengt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acengkeys = (array_keys($largest_arr));
	
$foreng1 = array($snm2eng1[0], $snm2eng1[1], $snm2eng1[2], $snm2eng1[3], $snm2eng1[4], $snm2eng1[5], $snm2eng1[6], $snm2eng1[7], $snm2eng1[8], $snm2eng1[9], $snm2eng1[10], $snm2eng1[11], $snm2eng1[12], $snm2eng1[13], $snm2eng1[14], $snm2eng1[15], $snm2eng1[16], $snm2eng1[17], $snm2eng1[18], $snm2eng1[19], 
		  $snm2eng1[20], $snm2eng1[21], $snm2eng1[22], $snm2eng1[23], $snm2eng1[24], $snm2eng1[25], $snm2eng1[26], $snm2eng1[27], $snm2eng1[28], $snm2eng1[29], $snm2eng1[30], $snm2eng1[31], $snm2eng1[32], $snm2eng1[33], $snm2eng1[34], $snm2eng1[35], $snm2eng1[36], $snm2eng1[37], $snm2eng1[38], $snm2eng1[39], 
		  $snm2eng1[40], $snm2eng1[41], $snm2eng1[42], $snm2eng1[43], $snm2eng1[44], $snm2eng1[45], $snm2eng1[46], $snm2eng1[47], $snm2eng1[48], $snm2eng1[49], $snm2eng1[50], $snm2eng1[51], $snm2eng1[52], $snm2eng1[53], $snm2eng1[54], $snm2eng1[55], $snm2eng1[56], $snm2eng1[57], $snm2eng1[58], $snm2eng1[59], 
		  $snm2eng1[60], $snm2eng1[61], $snm2eng1[62], $snm2eng1[63], $snm2eng1[64], $snm2eng1[65], $snm2eng1[66], $snm2eng1[67], $snm2eng1[68], $snm2eng1[69], $snm2eng1[70], $snm2eng1[71], $snm2eng1[72], $snm2eng1[73], $snm2eng1[74], $snm2eng1[75], $snm2eng1[76], $snm2eng1[77], $snm2eng1[78], $snm2eng1[79], 
		  $snm2eng1[80], $snm2eng1[81], $snm2eng1[82], $snm2eng1[83], $snm2eng1[84], $snm2eng1[85], $snm2eng1[86], $snm2eng1[87], $snm2eng1[88], $snm2eng1[89], $snm2eng1[90], $snm2eng1[91], $snm2eng1[92], $snm2eng1[93], $snm2eng1[94], $snm2eng1[95], $snm2eng1[96], $snm2eng1[97], $snm2eng1[98], $snm2eng1[99], 
		  $snm2eng1[100], $snm2eng1[101], $snm2eng1[102], $snm2eng1[103], $snm2eng1[104], $snm2eng1[105], $snm2eng1[106], $snm2eng1[107], $snm2eng1[108], $snm2eng1[109], $snm2eng1[110], $snm2eng1[111], $snm2eng1[112], $snm2eng1[113], $snm2eng1[114], $snm2eng1[115], $snm2eng1[116], $snm2eng1[117], $snm2eng1[118], $snm2eng1[119],
		  $snm2eng1[120]);
$foreng2 = array($snm2eng2[0], $snm2eng2[1], $snm2eng2[2], $snm2eng2[3], $snm2eng2[4], $snm2eng2[5], $snm2eng2[6], $snm2eng2[7], $snm2eng2[8], $snm2eng2[9], $snm2eng2[10], $snm2eng2[11], $snm2eng2[12], $snm2eng2[13], $snm2eng2[14], $snm2eng2[15], $snm2eng2[16], $snm2eng2[17], $snm2eng2[18], $snm2eng2[19], 
		  $snm2eng2[20], $snm2eng2[21], $snm2eng2[22], $snm2eng2[23], $snm2eng2[24], $snm2eng2[25], $snm2eng2[26], $snm2eng2[27], $snm2eng2[28], $snm2eng2[29], $snm2eng2[30], $snm2eng2[31], $snm2eng2[32], $snm2eng2[33], $snm2eng2[34], $snm2eng2[35], $snm2eng2[36], $snm2eng2[37], $snm2eng2[38], $snm2eng2[39], 
		  $snm2eng2[40], $snm2eng2[41], $snm2eng2[42], $snm2eng2[43], $snm2eng2[44], $snm2eng2[45], $snm2eng2[46], $snm2eng2[47], $snm2eng2[48], $snm2eng2[49], $snm2eng2[50], $snm2eng2[51], $snm2eng2[52], $snm2eng2[53], $snm2eng2[54], $snm2eng2[55], $snm2eng2[56], $snm2eng2[57], $snm2eng2[58], $snm2eng2[59],
		  $snm2eng2[60], $snm2eng2[61], $snm2eng2[62], $snm2eng2[63], $snm2eng2[64], $snm2eng2[65], $snm2eng2[66], $snm2eng2[67], $snm2eng2[68], $snm2eng2[69], $snm2eng2[70], $snm2eng2[71], $snm2eng2[72], $snm2eng2[73], $snm2eng2[74], $snm2eng2[75], $snm2eng2[76], $snm2eng2[77], $snm2eng2[78], $snm2eng2[79],
		  $snm2eng2[80], $snm2eng2[81], $snm2eng2[82], $snm2eng2[83], $snm2eng2[84], $snm2eng2[85], $snm2eng2[86], $snm2eng2[87], $snm2eng2[88], $snm2eng2[89], $snm2eng2[90], $snm2eng2[91], $snm2eng2[92], $snm2eng2[93], $snm2eng2[94], $snm2eng2[95], $snm2eng2[96], $snm2eng2[97], $snm2eng2[98], $snm2eng2[99],
		   $snm2eng2[100], $snm2eng2[101], $snm2eng2[102], $snm2eng2[103], $snm2eng2[104], $snm2eng2[105], $snm2eng2[106], $snm2eng2[107], $snm2eng2[108], $snm2eng2[109], $snm2eng2[110], $snm2eng2[111], $snm2eng2[112], $snm2eng2[113], $snm2eng2[114], $snm2eng2[115], $snm2eng2[116], $snm2eng2[117], $snm2eng2[118], $snm2eng2[119],
		  $snm2eng2[120]);
$foreng3 = array($snm2eng3[0], $snm2eng3[1], $snm2eng3[2], $snm2eng3[3], $snm2eng3[4], $snm2eng3[5], $snm2eng3[6], $snm2eng3[7], $snm2eng3[8], $snm2eng3[9], $snm2eng3[10], $snm2eng3[11], $snm2eng3[12], $snm2eng3[13], $snm2eng3[14], $snm2eng3[15], $snm2eng3[16], $snm2eng3[17], $snm2eng3[18], $snm2eng3[19],
		  $snm2eng3[20], $snm2eng3[21], $snm2eng3[22], $snm2eng3[23], $snm2eng3[24], $snm2eng3[25], $snm2eng3[26], $snm2eng3[27], $snm2eng3[28], $snm2eng3[29], $snm2eng3[30], $snm2eng3[31], $snm2eng3[32], $snm2eng3[33], $snm2eng3[34], $snm2eng3[35], $snm2eng3[36], $snm2eng3[37], $snm2eng3[38], $snm2eng3[39],
		  $snm2eng3[40], $snm2eng3[41], $snm2eng3[42], $snm2eng3[43], $snm2eng3[44], $snm2eng3[45], $snm2eng3[46], $snm2eng3[47], $snm2eng3[48], $snm2eng3[49], $snm2eng3[50], $snm2eng3[51], $snm2eng3[52], $snm2eng3[53], $snm2eng3[54], $snm2eng3[55], $snm2eng3[56], $snm2eng3[57], $snm2eng3[58], $snm2eng3[59],
		  $snm2eng3[60], $snm2eng3[61], $snm2eng3[62], $snm2eng3[63], $snm2eng3[64], $snm2eng3[65], $snm2eng3[66], $snm2eng3[67], $snm2eng3[68], $snm2eng3[69], $snm2eng3[70], $snm2eng3[71], $snm2eng3[72], $snm2eng3[73], $snm2eng3[74], $snm2eng3[75], $snm2eng3[76], $snm2eng3[77], $snm2eng3[78], $snm2eng3[79],
		  $snm2eng3[80], $snm2eng3[81], $snm2eng3[82], $snm2eng3[83], $snm2eng3[84], $snm2eng3[85], $snm2eng3[86], $snm2eng3[87], $snm2eng3[88], $snm2eng3[89], $snm2eng3[90], $snm2eng3[91], $snm2eng3[92], $snm2eng3[93], $snm2eng3[94], $snm2eng3[95], $snm2eng3[96], $snm2eng3[97], $snm2eng3[98], $snm2eng3[99],
		  $snm2eng3[100], $snm2eng3[101], $snm2eng3[102], $snm2eng3[103], $snm2eng3[104], $snm2eng3[105], $snm2eng3[106], $snm2eng3[107], $snm2eng3[108], $snm2eng3[109], $snm2eng3[110], $snm2eng3[111], $snm2eng3[112], $snm2eng3[113], $snm2eng3[114], $snm2eng3[115], $snm2eng3[116], $snm2eng3[117], $snm2eng3[118], $snm2eng3[119],
		  $snm2eng3[120]);
$array_all_eng = array(array_filter($foreng1), array_filter($foreng2), array_filter($foreng3));
	$countingeng = 0;
	while($countingeng <= 120){
	if(count(array_column($array_all_eng, $countingeng)) == 3){
	$engf2[] = round(array_sum(array_column($array_all_eng, $countingeng))/3);
	}
	else if(count(array_column($array_all_eng, $countingeng)) == 2){
	$engf2[] = round(array_sum(array_column($array_all_eng, $countingeng))/2);
	}
	else if(count(array_column($array_all_eng, $countingeng)) == 1){
	$engf2[] = round(array_sum(array_column($array_all_eng, $countingeng))/1);
	}
	else{
	$engf2[] = round(array_sum(array_column($array_all_eng, $countingeng))/3);	
	}
	$countingeng++;
	}
	$engf = implode("-",array_filter($engf2));
	$engmx2 = explode("-",$engf);
	$engmx = max(explode("-",$engf));
	$stnameandscoreEng = array_combine($acengkeys,$engmx2);
	//print_r($stnameandscoreEng);
	echo '<br>';
	$maxinallsub = $engmx;	
	}
	else if($su == 'Mathematics'){
	$resultmxbystunamemat1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Mathematics' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemat1))
	{	
		$snm2mat1[] = $rsn['score'];
		$stin2mat[] = $rsn['student_name'];
	}
	$acmatf = array_combine($stin2mat,$snm2mat1);
	$resultmxbystunamemat2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Mathematics' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemat2))
	{	
		$snm2mat2[] = $rsn['score'];
	    $stin2mat2[] = $rsn['student_name'];
	}
	$acmats = array_combine($stin2mat2,$snm2mat2);
	$resultmxbystunamemat3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Mathematics' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemat3))
	{	
		$snm2mat3[] = $rsn['score'];
		$stin2mat3[] = $rsn['student_name'];
	}
	$acmatt = array_combine($stin2mat3,$snm2mat3);
	$arinall = array($acmatf, $acmats, $acmatt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acmatkeys = (array_keys($largest_arr));
	
$format1 = 	array($snm2mat1[0], $snm2mat1[1], $snm2mat1[2], $snm2mat1[3], $snm2mat1[4], $snm2mat1[5], $snm2mat1[6], $snm2mat1[7], $snm2mat1[8], $snm2mat1[9], $snm2mat1[10], $snm2mat1[11], $snm2mat1[12], $snm2mat1[13], $snm2mat1[14], $snm2mat1[15], $snm2mat1[16], $snm2mat1[17], $snm2mat1[18], $snm2mat1[19], 
		  $snm2mat1[20], $snm2mat1[21], $snm2mat1[22], $snm2mat1[23], $snm2mat1[24], $snm2mat1[25], $snm2mat1[26], $snm2mat1[27], $snm2mat1[28], $snm2mat1[29], $snm2mat1[30], $snm2mat1[31], $snm2mat1[32], $snm2mat1[33], $snm2mat1[34], $snm2mat1[35], $snm2mat1[36], $snm2mat1[37], $snm2mat1[38], $snm2mat1[39], 
		  $snm2mat1[40], $snm2mat1[41], $snm2mat1[42], $snm2mat1[43], $snm2mat1[44], $snm2mat1[45], $snm2mat1[46], $snm2mat1[47], $snm2mat1[48], $snm2mat1[49], $snm2mat1[50], $snm2mat1[51], $snm2mat1[52], $snm2mat1[53], $snm2mat1[54], $snm2mat1[55], $snm2mat1[56], $snm2mat1[57], $snm2mat1[58], $snm2mat1[59], 
		  $snm2mat1[60], $snm2mat1[61], $snm2mat1[62], $snm2mat1[63], $snm2mat1[64], $snm2mat1[65], $snm2mat1[66], $snm2mat1[67], $snm2mat1[68], $snm2mat1[69], $snm2mat1[70], $snm2mat1[71], $snm2mat1[72], $snm2mat1[73], $snm2mat1[74], $snm2mat1[75], $snm2mat1[76], $snm2mat1[77], $snm2mat1[78], $snm2mat1[79], 
		  $snm2mat1[80], $snm2mat1[81], $snm2mat1[82], $snm2mat1[83], $snm2mat1[84], $snm2mat1[85], $snm2mat1[86], $snm2mat1[87], $snm2mat1[88], $snm2mat1[89], $snm2mat1[90], $snm2mat1[91], $snm2mat1[92], $snm2mat1[93], $snm2mat1[94], $snm2mat1[95], $snm2mat1[96], $snm2mat1[97], $snm2mat1[98], $snm2mat1[99], 
		  $snm2mat1[100], $snm2mat1[101], $snm2mat1[102], $snm2mat1[103], $snm2mat1[104], $snm2mat1[105], $snm2mat1[106], $snm2mat1[107], $snm2mat1[108], $snm2mat1[109], $snm2mat1[110], $snm2mat1[111], $snm2mat1[112], $snm2mat1[113], $snm2mat1[114], $snm2mat1[115], $snm2mat1[116], $snm2mat1[117], $snm2mat1[118], $snm2mat1[119],
		  $snm2mat1[120]);
$format2 = 	array($snm2mat2[0], $snm2mat2[1], $snm2mat2[2], $snm2mat2[3], $snm2mat2[4], $snm2mat2[5], $snm2mat2[6], $snm2mat2[7], $snm2mat2[8], $snm2mat2[9], $snm2mat2[10], $snm2mat2[11], $snm2mat2[12], $snm2mat2[13], $snm2mat2[14], $snm2mat2[15], $snm2mat2[16], $snm2mat2[17], $snm2mat2[18], $snm2mat2[19], 
		  $snm2mat2[20], $snm2mat2[21], $snm2mat2[22], $snm2mat2[23], $snm2mat2[24], $snm2mat2[25], $snm2mat2[26], $snm2mat2[27], $snm2mat2[28], $snm2mat2[29], $snm2mat2[30], $snm2mat2[31], $snm2mat2[32], $snm2mat2[33], $snm2mat2[34], $snm2mat2[35], $snm2mat2[36], $snm2mat2[37], $snm2mat2[38], $snm2mat2[39], 
		  $snm2mat2[40], $snm2mat2[41], $snm2mat2[42], $snm2mat2[43], $snm2mat2[44], $snm2mat2[45], $snm2mat2[46], $snm2mat2[47], $snm2mat2[48], $snm2mat2[49], $snm2mat2[50], $snm2mat2[51], $snm2mat2[52], $snm2mat2[53], $snm2mat2[54], $snm2mat2[55], $snm2mat2[56], $snm2mat2[57], $snm2mat2[58], $snm2mat2[59],
		  $snm2mat2[60], $snm2mat2[61], $snm2mat2[62], $snm2mat2[63], $snm2mat2[64], $snm2mat2[65], $snm2mat2[66], $snm2mat2[67], $snm2mat2[68], $snm2mat2[69], $snm2mat2[70], $snm2mat2[71], $snm2mat2[72], $snm2mat2[73], $snm2mat2[74], $snm2mat2[75], $snm2mat2[76], $snm2mat2[77], $snm2mat2[78], $snm2mat2[79],
		  $snm2mat2[80], $snm2mat2[81], $snm2mat2[82], $snm2mat2[83], $snm2mat2[84], $snm2mat2[85], $snm2mat2[86], $snm2mat2[87], $snm2mat2[88], $snm2mat2[89], $snm2mat2[90], $snm2mat2[91], $snm2mat2[92], $snm2mat2[93], $snm2mat2[94], $snm2mat2[95], $snm2mat2[96], $snm2mat2[97], $snm2mat2[98], $snm2mat2[99],
		   $snm2mat2[100], $snm2mat2[101], $snm2mat2[102], $snm2mat2[103], $snm2mat2[104], $snm2mat2[105], $snm2mat2[106], $snm2mat2[107], $snm2mat2[108], $snm2mat2[109], $snm2mat2[110], $snm2mat2[111], $snm2mat2[112], $snm2mat2[113], $snm2mat2[114], $snm2mat2[115], $snm2mat2[116], $snm2mat2[117], $snm2mat2[118], $snm2mat2[119],
		  $snm2mat2[120]);
$format3 = 	array($snm2mat3[0], $snm2mat3[1], $snm2mat3[2], $snm2mat3[3], $snm2mat3[4], $snm2mat3[5], $snm2mat3[6], $snm2mat3[7], $snm2mat3[8], $snm2mat3[9], $snm2mat3[10], $snm2mat3[11], $snm2mat3[12], $snm2mat3[13], $snm2mat3[14], $snm2mat3[15], $snm2mat3[16], $snm2mat3[17], $snm2mat3[18], $snm2mat3[19],
		  $snm2mat3[20], $snm2mat3[21], $snm2mat3[22], $snm2mat3[23], $snm2mat3[24], $snm2mat3[25], $snm2mat3[26], $snm2mat3[27], $snm2mat3[28], $snm2mat3[29], $snm2mat3[30], $snm2mat3[31], $snm2mat3[32], $snm2mat3[33], $snm2mat3[34], $snm2mat3[35], $snm2mat3[36], $snm2mat3[37], $snm2mat3[38], $snm2mat3[39],
		  $snm2mat3[40], $snm2mat3[41], $snm2mat3[42], $snm2mat3[43], $snm2mat3[44], $snm2mat3[45], $snm2mat3[46], $snm2mat3[47], $snm2mat3[48], $snm2mat3[49], $snm2mat3[50], $snm2mat3[51], $snm2mat3[52], $snm2mat3[53], $snm2mat3[54], $snm2mat3[55], $snm2mat3[56], $snm2mat3[57], $snm2mat3[58], $snm2mat3[59],
		  $snm2mat3[60], $snm2mat3[61], $snm2mat3[62], $snm2mat3[63], $snm2mat3[64], $snm2mat3[65], $snm2mat3[66], $snm2mat3[67], $snm2mat3[68], $snm2mat3[69], $snm2mat3[70], $snm2mat3[71], $snm2mat3[72], $snm2mat3[73], $snm2mat3[74], $snm2mat3[75], $snm2mat3[76], $snm2mat3[77], $snm2mat3[78], $snm2mat3[79],
		  $snm2mat3[80], $snm2mat3[81], $snm2mat3[82], $snm2mat3[83], $snm2mat3[84], $snm2mat3[85], $snm2mat3[86], $snm2mat3[87], $snm2mat3[88], $snm2mat3[89], $snm2mat3[90], $snm2mat3[91], $snm2mat3[92], $snm2mat3[93], $snm2mat3[94], $snm2mat3[95], $snm2mat3[96], $snm2mat3[97], $snm2mat3[98], $snm2mat3[99],
		  $snm2mat3[100], $snm2mat3[101], $snm2mat3[102], $snm2mat3[103], $snm2mat3[104], $snm2mat3[105], $snm2mat3[106], $snm2mat3[107], $snm2mat3[108], $snm2mat3[109], $snm2mat3[110], $snm2mat3[111], $snm2mat3[112], $snm2mat3[113], $snm2mat3[114], $snm2mat3[115], $snm2mat3[116], $snm2mat3[117], $snm2mat3[118], $snm2mat3[119],
		  $snm2mat3[120]);	  
	$array_all_mat = array(array_filter($format1), array_filter($format2), array_filter($format3));
	$countingmat = 0;
	while($countingmat <= 120){
	if(count(array_column($array_all_mat, $countingmat)) == 3){
	$matf2[] = round(array_sum(array_column($array_all_mat, $countingmat))/3);
	}
	else if(count(array_column($array_all_mat, $countingmat)) == 2){
	$matf2[] = round(array_sum(array_column($array_all_mat, $countingmat))/2);
	}
	else if(count(array_column($array_all_mat, $countingmat)) == 1){
	$matf2[] = round(array_sum(array_column($array_all_mat, $countingmat))/1);
	}
	else{
	$matf2[] = round(array_sum(array_column($array_all_mat, $countingmat))/3);	
	}
	$countingmat++;
	}
	$matf = implode("-",array_filter($matf2));
	$matmx2 = explode("-",$matf);
	$matmx = max(explode("-",$matf));
	$stnameandscoreMat = array_combine($acmatkeys,$matmx2);
	//print_r($stnameandscoreMat);
	//echo '<br>';
	$maxinallsub = $matmx;		
	}
	else if($su == 'French'){
	$resultmxbystunamefre1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='French' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefre1))
	{	
		$snm2fre1[] = $rsn['score'];
		$stin2fre[] = $rsn['student_name'];
	}
	$acfref = array_combine($stin2fre,$snm2fre1);
	$resultmxbystunamefre2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='French' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefre2))
	{	
		$snm2fre2[] = $rsn['score'];
	    $stin2fre2[] = $rsn['student_name'];
	}
	$acfres = array_combine($stin2fre2,$snm2fre2);
	$resultmxbystunamefre3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='French' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefre3))
	{	
		$snm2fre3[] = $rsn['score'];
		$stin2fre3[] = $rsn['student_name'];
	}
	$acfret = array_combine($stin2fre3,$snm2fre3);
	$arinall = array($acfref, $acfres, $acfret);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acfrekeys = (array_keys($largest_arr));
$forfre1 = 	array($snm2fre1[0], $snm2fre1[1], $snm2fre1[2], $snm2fre1[3], $snm2fre1[4], $snm2fre1[5], $snm2fre1[6], $snm2fre1[7], $snm2fre1[8], $snm2fre1[9], $snm2fre1[10], $snm2fre1[11], $snm2fre1[12], $snm2fre1[13], $snm2fre1[14], $snm2fre1[15], $snm2fre1[16], $snm2fre1[17], $snm2fre1[18], $snm2fre1[19], 
		  $snm2fre1[20], $snm2fre1[21], $snm2fre1[22], $snm2fre1[23], $snm2fre1[24], $snm2fre1[25], $snm2fre1[26], $snm2fre1[27], $snm2fre1[28], $snm2fre1[29], $snm2fre1[30], $snm2fre1[31], $snm2fre1[32], $snm2fre1[33], $snm2fre1[34], $snm2fre1[35], $snm2fre1[36], $snm2fre1[37], $snm2fre1[38], $snm2fre1[39], 
		  $snm2fre1[40], $snm2fre1[41], $snm2fre1[42], $snm2fre1[43], $snm2fre1[44], $snm2fre1[45], $snm2fre1[46], $snm2fre1[47], $snm2fre1[48], $snm2fre1[49], $snm2fre1[50], $snm2fre1[51], $snm2fre1[52], $snm2fre1[53], $snm2fre1[54], $snm2fre1[55], $snm2fre1[56], $snm2fre1[57], $snm2fre1[58], $snm2fre1[59], 
		  $snm2fre1[60], $snm2fre1[61], $snm2fre1[62], $snm2fre1[63], $snm2fre1[64], $snm2fre1[65], $snm2fre1[66], $snm2fre1[67], $snm2fre1[68], $snm2fre1[69], $snm2fre1[70], $snm2fre1[71], $snm2fre1[72], $snm2fre1[73], $snm2fre1[74], $snm2fre1[75], $snm2fre1[76], $snm2fre1[77], $snm2fre1[78], $snm2fre1[79], 
		  $snm2fre1[80], $snm2fre1[81], $snm2fre1[82], $snm2fre1[83], $snm2fre1[84], $snm2fre1[85], $snm2fre1[86], $snm2fre1[87], $snm2fre1[88], $snm2fre1[89], $snm2fre1[90], $snm2fre1[91], $snm2fre1[92], $snm2fre1[93], $snm2fre1[94], $snm2fre1[95], $snm2fre1[96], $snm2fre1[97], $snm2fre1[98], $snm2fre1[99], 
		  $snm2fre1[100], $snm2fre1[101], $snm2fre1[102], $snm2fre1[103], $snm2fre1[104], $snm2fre1[105], $snm2fre1[106], $snm2fre1[107], $snm2fre1[108], $snm2fre1[109], $snm2fre1[110], $snm2fre1[111], $snm2fre1[112], $snm2fre1[113], $snm2fre1[114], $snm2fre1[115], $snm2fre1[116], $snm2fre1[117], $snm2fre1[118], $snm2fre1[119],
		  $snm2fre1[120]);
$forfre2 = 	array($snm2fre2[0], $snm2fre2[1], $snm2fre2[2], $snm2fre2[3], $snm2fre2[4], $snm2fre2[5], $snm2fre2[6], $snm2fre2[7], $snm2fre2[8], $snm2fre2[9], $snm2fre2[10], $snm2fre2[11], $snm2fre2[12], $snm2fre2[13], $snm2fre2[14], $snm2fre2[15], $snm2fre2[16], $snm2fre2[17], $snm2fre2[18], $snm2fre2[19], 
		  $snm2fre2[20], $snm2fre2[21], $snm2fre2[22], $snm2fre2[23], $snm2fre2[24], $snm2fre2[25], $snm2fre2[26], $snm2fre2[27], $snm2fre2[28], $snm2fre2[29], $snm2fre2[30], $snm2fre2[31], $snm2fre2[32], $snm2fre2[33], $snm2fre2[34], $snm2fre2[35], $snm2fre2[36], $snm2fre2[37], $snm2fre2[38], $snm2fre2[39], 
		  $snm2fre2[40], $snm2fre2[41], $snm2fre2[42], $snm2fre2[43], $snm2fre2[44], $snm2fre2[45], $snm2fre2[46], $snm2fre2[47], $snm2fre2[48], $snm2fre2[49], $snm2fre2[50], $snm2fre2[51], $snm2fre2[52], $snm2fre2[53], $snm2fre2[54], $snm2fre2[55], $snm2fre2[56], $snm2fre2[57], $snm2fre2[58], $snm2fre2[59],
		  $snm2fre2[60], $snm2fre2[61], $snm2fre2[62], $snm2fre2[63], $snm2fre2[64], $snm2fre2[65], $snm2fre2[66], $snm2fre2[67], $snm2fre2[68], $snm2fre2[69], $snm2fre2[70], $snm2fre2[71], $snm2fre2[72], $snm2fre2[73], $snm2fre2[74], $snm2fre2[75], $snm2fre2[76], $snm2fre2[77], $snm2fre2[78], $snm2fre2[79],
		  $snm2fre2[80], $snm2fre2[81], $snm2fre2[82], $snm2fre2[83], $snm2fre2[84], $snm2fre2[85], $snm2fre2[86], $snm2fre2[87], $snm2fre2[88], $snm2fre2[89], $snm2fre2[90], $snm2fre2[91], $snm2fre2[92], $snm2fre2[93], $snm2fre2[94], $snm2fre2[95], $snm2fre2[96], $snm2fre2[97], $snm2fre2[98], $snm2fre2[99],
		   $snm2fre2[100], $snm2fre2[101], $snm2fre2[102], $snm2fre2[103], $snm2fre2[104], $snm2fre2[105], $snm2fre2[106], $snm2fre2[107], $snm2fre2[108], $snm2fre2[109], $snm2fre2[110], $snm2fre2[111], $snm2fre2[112], $snm2fre2[113], $snm2fre2[114], $snm2fre2[115], $snm2fre2[116], $snm2fre2[117], $snm2fre2[118], $snm2fre2[119],
		  $snm2fre2[120]);
$forfre3 = 	array($snm2fre3[0], $snm2fre3[1], $snm2fre3[2], $snm2fre3[3], $snm2fre3[4], $snm2fre3[5], $snm2fre3[6], $snm2fre3[7], $snm2fre3[8], $snm2fre3[9], $snm2fre3[10], $snm2fre3[11], $snm2fre3[12], $snm2fre3[13], $snm2fre3[14], $snm2fre3[15], $snm2fre3[16], $snm2fre3[17], $snm2fre3[18], $snm2fre3[19],
		  $snm2fre3[20], $snm2fre3[21], $snm2fre3[22], $snm2fre3[23], $snm2fre3[24], $snm2fre3[25], $snm2fre3[26], $snm2fre3[27], $snm2fre3[28], $snm2fre3[29], $snm2fre3[30], $snm2fre3[31], $snm2fre3[32], $snm2fre3[33], $snm2fre3[34], $snm2fre3[35], $snm2fre3[36], $snm2fre3[37], $snm2fre3[38], $snm2fre3[39],
		  $snm2fre3[40], $snm2fre3[41], $snm2fre3[42], $snm2fre3[43], $snm2fre3[44], $snm2fre3[45], $snm2fre3[46], $snm2fre3[47], $snm2fre3[48], $snm2fre3[49], $snm2fre3[50], $snm2fre3[51], $snm2fre3[52], $snm2fre3[53], $snm2fre3[54], $snm2fre3[55], $snm2fre3[56], $snm2fre3[57], $snm2fre3[58], $snm2fre3[59],
		  $snm2fre3[60], $snm2fre3[61], $snm2fre3[62], $snm2fre3[63], $snm2fre3[64], $snm2fre3[65], $snm2fre3[66], $snm2fre3[67], $snm2fre3[68], $snm2fre3[69], $snm2fre3[70], $snm2fre3[71], $snm2fre3[72], $snm2fre3[73], $snm2fre3[74], $snm2fre3[75], $snm2fre3[76], $snm2fre3[77], $snm2fre3[78], $snm2fre3[79],
		  $snm2fre3[80], $snm2fre3[81], $snm2fre3[82], $snm2fre3[83], $snm2fre3[84], $snm2fre3[85], $snm2fre3[86], $snm2fre3[87], $snm2fre3[88], $snm2fre3[89], $snm2fre3[90], $snm2fre3[91], $snm2fre3[92], $snm2fre3[93], $snm2fre3[94], $snm2fre3[95], $snm2fre3[96], $snm2fre3[97], $snm2fre3[98], $snm2fre3[99],
		  $snm2fre3[100], $snm2fre3[101], $snm2fre3[102], $snm2fre3[103], $snm2fre3[104], $snm2fre3[105], $snm2fre3[106], $snm2fre3[107], $snm2fre3[108], $snm2fre3[109], $snm2fre3[110], $snm2fre3[111], $snm2fre3[112], $snm2fre3[113], $snm2fre3[114], $snm2fre3[115], $snm2fre3[116], $snm2fre3[117], $snm2fre3[118], $snm2fre3[119],
		  $snm2fre3[120]);	  
	$array_all_fre = array(array_filter($forfre1), array_filter($forfre2), array_filter($forfre3));
	$countingfre = 0;
	while($countingfre <= 120){
	if(count(array_column($array_all_fre, $countingfre)) == 3){
	$fref2[] = round(array_sum(array_column($array_all_fre, $countingfre))/3);
	}
	else if(count(array_column($array_all_fre, $countingfre)) == 2){
	$fref2[] = round(array_sum(array_column($array_all_fre, $countingfre))/2);
	}
	else if(count(array_column($array_all_fre, $countingfre)) == 1){
	$fref2[] = round(array_sum(array_column($array_all_fre, $countingfre))/1);
	}
	else{
	$fref2[] = round(array_sum(array_column($array_all_fre, $countingfre))/3);	
	}
	$countingfre++;
	}
	$fref = implode("-",array_filter($fref2));
	$fremx2 = explode("-",$fref);
	$fremx = max(explode("-",$fref));
	$stnameandscoreFre = array_combine($acfrekeys,$fremx2);
	//print_r($stnameandscoreFre);
	//echo '<br>';
	$maxinallsub = $fremx;		
	}
	
	else if($su == 'Agricultural Science'){
		$resultmxbystunameagr1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Agricultural Science' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameagr1))
	{	
		$snm2agr1[] = $rsn['score'];
		$stin2agr[] = $rsn['student_name'];
	}
	$acagrf = array_combine($stin2agr,$snm2agr1);
	$resultmxbystunameagr2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Agricultural Science' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameagr2))
	{	
		$snm2agr2[] = $rsn['score'];
	    $stin2agr2[] = $rsn['student_name'];
	}
	$acagrs = array_combine($stin2agr2,$snm2agr2);
	$resultmxbystunameagr3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Agricultural Science' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameagr3))
	{	
		$snm2agr3[] = $rsn['score'];
		$stin2agr3[] = $rsn['student_name'];
	}
	$acagrt = array_combine($stin2agr3,$snm2agr3);
	$arinall = array($acagrf, $acagrs, $acagrt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acagrkeys = (array_keys($largest_arr));
$foragr1 = 	array($snm2agr1[0], $snm2agr1[1], $snm2agr1[2], $snm2agr1[3], $snm2agr1[4], $snm2agr1[5], $snm2agr1[6], $snm2agr1[7], $snm2agr1[8], $snm2agr1[9], $snm2agr1[10], $snm2agr1[11], $snm2agr1[12], $snm2agr1[13], $snm2agr1[14], $snm2agr1[15], $snm2agr1[16], $snm2agr1[17], $snm2agr1[18], $snm2agr1[19], 
		  $snm2agr1[20], $snm2agr1[21], $snm2agr1[22], $snm2agr1[23], $snm2agr1[24], $snm2agr1[25], $snm2agr1[26], $snm2agr1[27], $snm2agr1[28], $snm2agr1[29], $snm2agr1[30], $snm2agr1[31], $snm2agr1[32], $snm2agr1[33], $snm2agr1[34], $snm2fre1[35], $snm2agr1[36], $snm2agr1[37], $snm2agr1[38], $snm2agr1[39], 
		  $snm2agr1[40], $snm2agr1[41], $snm2agr1[42], $snm2agr1[43], $snm2agr1[44], $snm2agr1[45], $snm2agr1[46], $snm2agr1[47], $snm2agr1[48], $snm2agr1[49], $snm2agr1[50], $snm2agr1[51], $snm2agr1[52], $snm2agr1[53], $snm2agr1[54], $snm2fre1[55], $snm2agr1[56], $snm2agr1[57], $snm2agr1[58], $snm2agr1[59], 
		  $snm2agr1[60], $snm2agr1[61], $snm2agr1[62], $snm2agr1[63], $snm2agr1[64], $snm2agr1[65], $snm2agr1[66], $snm2agr1[67], $snm2agr1[68], $snm2agr1[69], $snm2agr1[70], $snm2agr1[71], $snm2agr1[72], $snm2agr1[73], $snm2agr1[74], $snm2fre1[75], $snm2agr1[76], $snm2agr1[77], $snm2agr1[78], $snm2agr1[79], 
		  $snm2agr1[80], $snm2agr1[81], $snm2agr1[82], $snm2agr1[83], $snm2agr1[84], $snm2agr1[85], $snm2agr1[86], $snm2agr1[87], $snm2agr1[88], $snm2agr1[89], $snm2agr1[90], $snm2agr1[91], $snm2agr1[92], $snm2agr1[93], $snm2agr1[94], $snm2fre1[95], $snm2agr1[96], $snm2agr1[97], $snm2agr1[98], $snm2agr1[99], 
		  $snm2agr1[100], $snm2agr1[101], $snm2agr1[102], $snm2agr1[103], $snm2agr1[104], $snm2agr1[105], $snm2agr1[106], $snm2agr1[107], $snm2agr1[108], $snm2agr1[109], $snm2agr1[110], $snm2agr1[111], $snm2agr1[112], $snm2agr1[113], $snm2agr1[114], $snm2agr1[115], $snm2agr1[116], $snm2agr1[117], $snm2agr1[118], $snm2agr1[119],
		  $snm2agr1[120]);
$foragr2 = 	array($snm2agr2[0], $snm2agr2[1], $snm2agr2[2], $snm2agr2[3], $snm2agr2[4], $snm2agr2[5], $snm2agr2[6], $snm2agr2[7], $snm2agr2[8], $snm2agr2[9], $snm2agr2[10], $snm2agr2[11], $snm2agr2[12], $snm2agr2[13], $snm2agr2[14], $snm2agr2[15], $snm2agr2[16], $snm2agr2[17], $snm2agr2[18], $snm2agr2[19], 
		  $snm2agr2[20], $snm2agr2[21], $snm2agr2[22], $snm2agr2[23], $snm2agr2[24], $snm2agr2[25], $snm2agr2[26], $snm2agr2[27], $snm2agr2[28], $snm2agr2[29], $snm2agr2[30], $snm2agr2[31], $snm2agr2[32], $snm2agr2[33], $snm2agr2[34], $snm2agr2[35], $snm2agr2[36], $snm2agr2[37], $snm2agr2[38], $snm2agr2[39], 
		  $snm2agr2[40], $snm2agr2[41], $snm2agr2[42], $snm2agr2[43], $snm2fre2[44], $snm2agr2[45], $snm2agr2[46], $snm2agr2[47], $snm2agr2[48], $snm2agr2[49], $snm2agr2[50], $snm2agr2[51], $snm2agr2[52], $snm2agr2[53], $snm2agr2[54], $snm2agr2[55], $snm2agr2[56], $snm2agr2[57], $snm2agr2[58], $snm2agr2[59],
		  $snm2agr2[60], $snm2agr2[61], $snm2agr2[62], $snm2agr2[63], $snm2fre2[64], $snm2agr2[65], $snm2agr2[66], $snm2agr2[67], $snm2agr2[68], $snm2agr2[69], $snm2agr2[70], $snm2agr2[71], $snm2agr2[72], $snm2agr2[73], $snm2agr2[74], $snm2agr2[75], $snm2agr2[76], $snm2agr2[77], $snm2agr2[78], $snm2agr2[79],
		  $snm2agr2[80], $snm2agr2[81], $snm2agr2[82], $snm2agr2[83], $snm2fre2[84], $snm2agr2[85], $snm2agr2[86], $snm2agr2[87], $snm2agr2[88], $snm2agr2[89], $snm2agr2[90], $snm2agr2[91], $snm2agr2[92], $snm2agr2[93], $snm2agr2[94], $snm2agr2[95], $snm2agr2[96], $snm2agr2[97], $snm2agr2[98], $snm2agr2[99],
		   $snm2agr2[100], $snm2agr2[101], $snm2agr2[102], $snm2agr2[103], $snm2agr2[104], $snm2agr2[105], $snm2agr2[106], $snm2agr2[107], $snm2agr2[108], $snm2agr2[109], $snm2agr2[110], $snm2agr2[111], $snm2agr2[112], $snm2agr2[113], $snm2agr2[114], $snm2agr2[115], $snm2agr2[116], $snm2agr2[117], $snm2agr2[118], $snm2agr2[119],
		  $snm2agr2[120]);
$foragr3 = 	array($snm2agr3[0], $snm2agr3[1], $snm2agr3[2], $snm2agr3[3], $snm2agr3[4], $snm2agr3[5], $snm2agr3[6], $snm2agr3[7], $snm2agr3[8], $snm2agr3[9], $snm2agr3[10], $snm2agr3[11], $snm2agr3[12], $snm2agr3[13], $snm2agr3[14], $snm2agr3[15], $snm2agr3[16], $snm2agr3[17], $snm2agr3[18], $snm2agr3[19],
		  $snm2agr3[20], $snm2agr3[21], $snm2agr3[22], $snm2agr3[23], $snm2agr3[24], $snm2agr3[25], $snm2agr3[26], $snm2agr3[27], $snm2agr3[28], $snm2agr3[29], $snm2agr3[30], $snm2agr3[31], $snm2agr3[32], $snm2agr3[33], $snm2agr3[34], $snm2agr3[35], $snm2agr3[36], $snm2agr3[37], $snm2agr3[38], $snm2agr3[39], 
		  $snm2agr3[41], $snm2agr3[41], $snm2agr3[42], $snm2agr3[43], $snm2agr3[44], $snm2agr3[45], $snm2agr3[46], $snm2agr3[47], $snm2agr3[48], $snm2agr3[49], $snm2agr3[50], $snm2agr3[51], $snm2agr3[52], $snm2agr3[53], $snm2agr3[54], $snm2agr3[55], $snm2agr3[56], $snm2agr3[57], $snm2agr3[58], $snm2agr3[59],
		  $snm2agr3[60], $snm2agr3[61], $snm2agr3[62], $snm2agr3[63], $snm2agr3[64], $snm2agr3[65], $snm2agr3[66], $snm2agr3[67], $snm2agr3[68], $snm2agr3[69], $snm2agr3[70], $snm2agr3[71], $snm2agr3[72], $snm2agr3[73], $snm2agr3[74], $snm2agr3[75], $snm2agr3[76], $snm2agr3[77], $snm2agr3[78], $snm2agr3[79],
		  $snm2agr3[80], $snm2agr3[81], $snm2agr3[82], $snm2agr3[83], $snm2agr3[84], $snm2agr3[85], $snm2agr3[86], $snm2agr3[87], $snm2agr3[88], $snm2agr3[89], $snm2agr3[90], $snm2agr3[91], $snm2agr3[92], $snm2agr3[93], $snm2agr3[94], $snm2agr3[95], $snm2agr3[96], $snm2agr3[97], $snm2agr3[98], $snm2agr3[99],
		  $snm2agr3[100], $snm2agr3[101], $snm2agr3[102], $snm2agr3[103], $snm2agr3[104], $snm2agr3[105], $snm2agr3[106], $snm2agr3[107], $snm2agr3[108], $snm2agr3[109], $snm2agr3[110], $snm2agr3[111], $snm2agr3[112], $snm2agr3[113], $snm2agr3[114], $snm2agr3[115], $snm2agr3[116], $snm2agr3[117], $snm2agr3[118], $snm2agr3[119],
		  $snm2agr3[120]);	  
	$array_all_agr = array(array_filter($foragr1), array_filter($foragr2), array_filter($foragr3));
	$countingagr = 0;
	while($countingagr <= 120){
	if(count(array_column($array_all_agr, $countingagr)) == 3){
	$agrf2[] = round(array_sum(array_column($array_all_agr, $countingagr))/3);
	}
	else if(count(array_column($array_all_agr, $countingagr)) == 2){
	$agrf2[] = round(array_sum(array_column($array_all_agr, $countingagr))/2);
	}
	else if(count(array_column($array_all_agr, $countingagr)) == 1){
	$agrf2[] = round(array_sum(array_column($array_all_agr, $countingagr))/1);
	}
	else{
	$agrf2[] = round(array_sum(array_column($array_all_agr, $countingagr))/3);	
	}
	$countingagr++;
	}
	$agrf = implode("-",array_filter($agrf2));
	$agrmx2 = explode("-",$agrf);
	$agrmx = max(explode("-",$agrf));
	$stnameandscoreAgr = array_combine($acagrkeys,$agrmx2);
	//print_r($stnameandscoreAgr);
	//echo '<br>';
	$maxinallsub = $agrmx;	
	}
	else if($su == 'Basic Science'){
		$resultmxbystunamebas1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Basic Science' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebas1))
	{	
		$snm2bas1[] = $rsn['score'];
		$stin2bas[] = $rsn['student_name'];
	}
	$acbasf = array_combine($stin2bas,$snm2bas1);
	$resultmxbystunamebas2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Basic Science' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebas2))
	{	
		$snm2bas2[] = $rsn['score'];
	    $stin2bas2[] = $rsn['student_name'];
	}
	$acbass = array_combine($stin2bas2,$snm2bas2);
	$resultmxbystunamebas3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Basic Science' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebas3))
	{	
		$snm2bas3[] = $rsn['score'];
		$stin2bas3[] = $rsn['student_name'];
	}
	$acbast = array_combine($stin2bas3,$snm2bas3);
	$arinall = array($acbasf, $acbass, $acbast);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acbaskeys = (array_keys($largest_arr));
$forbas1 = 	array($snm2bas1[0], $snm2bas1[1], $snm2bas1[2], $snm2bas1[3], $snm2bas1[4], $snm2bas1[5], $snm2bas1[6], $snm2bas1[7], $snm2bas1[8], $snm2bas1[9], $snm2bas1[10], $snm2bas1[11], $snm2bas1[12], $snm2bas1[13], $snm2bas1[14], $snm2bas1[15], $snm2bas1[16], $snm2bas1[17], $snm2bas1[18], $snm2bas1[19], 
		  $snm2bas1[20], $snm2bas1[21], $snm2bas1[22], $snm2bas1[23], $snm2bas1[24], $snm2bas1[25], $snm2bas1[26], $snm2bas1[27], $snm2bas1[28], $snm2bas1[29], $snm2bas1[30], $snm2bas1[31], $snm2bas1[32], $snm2bas1[33], $snm2bas1[34], $snm2bas1[35], $snm2bas1[36], $snm2bas1[37], $snm2bas1[38], $snm2bas1[39], 
		  $snm2bas1[40], $snm2bas1[41], $snm2bas1[42], $snm2bas1[43], $snm2bas1[44], $snm2bas1[45], $snm2bas1[46], $snm2bas1[47], $snm2bas1[48], $snm2bas1[49], $snm2bas1[50], $snm2bas1[51], $snm2bas1[52], $snm2bas1[53], $snm2bas1[54], $snm2bas1[55], $snm2bas1[56], $snm2bas1[57], $snm2bas1[58], $snm2bas1[59], 
		  $snm2bas1[60], $snm2bas1[61], $snm2bas1[62], $snm2bas1[63], $snm2bas1[64], $snm2bas1[65], $snm2bas1[66], $snm2bas1[67], $snm2bas1[68], $snm2bas1[69], $snm2bas1[70], $snm2bas1[71], $snm2bas1[72], $snm2bas1[73], $snm2bas1[74], $snm2bas1[75], $snm2bas1[76], $snm2bas1[77], $snm2bas1[78], $snm2bas1[79], 
		  $snm2bas1[80], $snm2bas1[81], $snm2bas1[82], $snm2bas1[83], $snm2bas1[84], $snm2bas1[85], $snm2bas1[86], $snm2bas1[87], $snm2bas1[88], $snm2bas1[89], $snm2bas1[90], $snm2bas1[91], $snm2bas1[92], $snm2bas1[93], $snm2bas1[94], $snm2bas1[95], $snm2bas1[96], $snm2bas1[97], $snm2bas1[98], $snm2bas1[99], 
		  $snm2bas1[100], $snm2bas1[101], $snm2bas1[102], $snm2bas1[103], $snm2bas1[104], $snm2bas1[105], $snm2bas1[106], $snm2bas1[107], $snm2bas1[108], $snm2bas1[109], $snm2bas1[110], $snm2bas1[111], $snm2bas1[112], $snm2bas1[113], $snm2bas1[114], $snm2bas1[115], $snm2bas1[116], $snm2bas1[117], $snm2bas1[118], $snm2bas1[119], 
		  $snm2bas1[120]);
$foragr2 = 	array($snm2bas2[0], $snm2bas2[1], $snm2bas2[2], $snm2bas2[3], $snm2bas2[4], $snm2bas2[5], $snm2bas2[6], $snm2bas2[7], $snm2bas2[8], $snm2bas2[9], $snm2bas2[10], $snm2bas2[11], $snm2bas1[12], $snm2bas2[13], $snm2bas2[14], $snm2bas2[15], $snm2bas2[16], $snm2bas2[17], $snm2bas2[18], $snm2bas2[19], 
		  $snm2bas2[20], $snm2bas2[21], $snm2bas2[22], $snm2bas2[23], $snm2bas2[24], $snm2bas2[25], $snm2bas2[26], $snm2bas2[27], $snm2bas2[28], $snm2bas2[29], $snm2bas2[30], $snm2bas2[31], $snm2bas2[32], $snm2bas2[33], $snm2bas2[34], $snm2bas2[35], $snm2bas2[36], $snm2bas2[37], $snm2bas2[38], $snm2bas2[39], 
		  $snm2bas2[40], $snm2bas2[41], $snm2bas2[42], $snm2bas2[43], $snm2bas2[44], $snm2bas2[45], $snm2bas2[46], $snm2bas2[47], $snm2bas2[48], $snm2bas2[49], $snm2bas2[50], $snm2bas2[51], $snm2bas2[52], $snm2bas2[53], $snm2bas2[54], $snm2bas2[55], $snm2bas2[56], $snm2bas2[57], $snm2bas2[58], $snm2bas2[59], 
		  $snm2bas2[60], $snm2bas2[61], $snm2bas2[62], $snm2bas2[63], $snm2bas2[64], $snm2bas2[65], $snm2bas2[66], $snm2bas2[67], $snm2bas2[68], $snm2bas2[69], $snm2bas2[70], $snm2bas2[71], $snm2bas2[72], $snm2bas2[73], $snm2bas2[74], $snm2bas2[75], $snm2bas2[76], $snm2bas2[77], $snm2bas2[78], $snm2bas2[79], 
		  $snm2bas2[80], $snm2bas2[81], $snm2bas2[82], $snm2bas2[83], $snm2bas2[84], $snm2bas2[85], $snm2bas2[86], $snm2bas2[87], $snm2bas2[88], $snm2bas2[89], $snm2bas2[90], $snm2bas2[91], $snm2bas2[92], $snm2bas2[93], $snm2bas2[94], $snm2bas2[95], $snm2bas2[96], $snm2bas2[97], $snm2bas2[98], $snm2bas2[99], 
		  $snm2bas2[100], $snm2bas2[101], $snm2bas2[102], $snm2bas2[103], $snm2bas2[104], $snm2bas2[105], $snm2bas2[106], $snm2bas2[107], $snm2bas2[108], $snm2bas2[109], $snm2bas2[110], $snm2bas2[111], $snm2bas2[112], $snm2bas2[113], $snm2bas2[114], $snm2bas2[115], $snm2bas2[116], $snm2bas2[117], $snm2bas2[118], $snm2bas2[119], 
		  $snm2bas2[120]);
$foragr3 = 	array($snm2bas3[0], $snm2bas3[1], $snm2bas3[2], $snm2bas3[3], $snm2bas3[4], $snm2bas3[5], $snm2bas3[6], $snm2bas3[7], $snm2bas3[8], $snm2bas3[9], $snm2bas3[10], $snm2bas3[11], $snm2bas3[12], $snm2bas3[13], $snm2bas3[14], $snm2bas3[15], $snm2bas3[16], $snm2bas3[17], $snm2bas3[18], $snm2bas3[19],
		  $snm2bas3[20], $snm2bas3[21], $snm2bas3[22], $snm2bas3[23], $snm2bas3[24], $snm2bas3[25], $snm2bas3[26], $snm2bas3[27], $snm2bas3[28], $snm2bas3[29], $snm2bas3[30], $snm2bas3[31], $snm2bas3[32], $snm2bas3[33], $snm2bas3[34], $snm2bas3[35], $snm2bas3[36], $snm2bas3[37], $snm2bas3[38], $snm2bas3[39], 
		  $snm2bas3[40], $snm2bas3[41], $snm2bas3[42], $snm2bas3[43], $snm2bas3[44], $snm2bas3[45], $snm2bas3[46], $snm2bas3[47], $snm2bas3[48], $snm2bas3[49], $snm2bas3[50], $snm2bas3[51], $snm2bas3[52], $snm2bas3[53], $snm2bas3[54], $snm2bas3[55], $snm2bas3[56], $snm2bas3[57], $snm2bas3[58], $snm2bas3[69], 
		  $snm2bas3[60], $snm2bas3[61], $snm2bas3[62], $snm2bas3[63], $snm2bas3[64], $snm2bas3[65], $snm2bas3[66], $snm2bas3[67], $snm2bas3[68], $snm2bas3[69], $snm2bas3[70], $snm2bas3[71], $snm2bas3[72], $snm2bas3[73], $snm2bas3[74], $snm2bas3[75], $snm2bas3[76], $snm2bas3[77], $snm2bas3[78], $snm2bas3[79], 
		  $snm2bas3[80], $snm2bas3[81], $snm2bas3[82], $snm2bas3[83], $snm2bas3[84], $snm2bas3[85], $snm2bas3[86], $snm2bas3[87], $snm2bas3[88], $snm2bas3[89], $snm2bas3[90], $snm2bas3[91], $snm2bas3[92], $snm2bas3[93], $snm2bas3[94], $snm2bas3[95], $snm2bas3[96], $snm2bas3[97], $snm2bas3[98], $snm2bas3[99], 
		  $snm2bas3[100], $snm2bas3[101], $snm2bas3[102], $snm2bas3[103], $snm2bas3[104], $snm2bas3[105], $snm2bas3[106], $snm2bas3[107], $snm2bas3[108], $snm2bas3[109], $snm2bas3[110], $snm2bas3[111], $snm2bas3[112], $snm2bas3[113], $snm2bas3[114], $snm2bas3[115], $snm2bas3[116], $snm2bas3[117], $snm2bas3[118], $snm2bas3[119], 
		  $snm2bas3[120]);	  
	$array_all_bas = array(array_filter($forbas1), array_filter($forbas2), array_filter($forbas3));
	$countingbas = 0;
	while($countingbas <= 120){
	if(count(array_column($array_all_bas, $countingbas)) == 3){
	$basf2[] = round(array_sum(array_column($array_all_bas, $countingbas))/3);
	}
	else if(count(array_column($array_all_bas, $countingbas)) == 2){
	$basf2[] = round(array_sum(array_column($array_all_bas, $countingbas))/2);
	}
	else if(count(array_column($array_all_bas, $countingbas)) == 1){
	$basf2[] = round(array_sum(array_column($array_all_bas, $countingbas))/1);
	}
	else{
	$basf2[] = round(array_sum(array_column($array_all_bas, $countingbas))/3);	
	}
	$countingbas++;
	}
	$basf = implode("-",array_filter($basf2));
	$basmx2 = explode("-",$basf);
	$basmx = max(explode("-",$basf));
	$stnameandscoreBas = array_combine($acbaskeys,$basmx2);
	$maxinallsub = $basmx;	
	}
		else if($su == 'Biology'){
		$resultmxbystunamebio1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Biology' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebio1))
	{	
		$snm2bio1[] = $rsn['score'];
		$stin2bio[] = $rsn['student_name'];
	}
	$acbiof = array_combine($stin2bio,$snm2bio1);
	$resultmxbystunamebio2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Biology' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebio2))
	{	
		$snm2bio2[] = $rsn['score'];
	    $stin2bio2[] = $rsn['student_name'];
	}
	$acbios = array_combine($stin2bio2,$snm2bio2);
	$resultmxbystunamebio3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Biology' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebio3))
	{	
		$snm2bio3[] = $rsn['score'];
		$stin2bio3[] = $rsn['student_name'];
	}
	$acbiot = array_combine($stin2bio3,$snm2bio3);
	$arinall = array($acbiof, $acbios, $acbiot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acbiokeys = (array_keys($largest_arr));
	
$forbio1 = array();
$forbio2 = array();
$forbio3 = array();
for($v=0; $v<=120; $v++){
$forbbio1[] = $snm2bio1[$v];
$forbbio2[] = $snm2bio2[$v];
$forbbio3[] = $snm2bio3[$v];
}
$forbio1 = $forbbio1;
$forbio2 = $forbbio2;
$forbio3 = $forbbio3;
		
$array_all_bio = array(array_filter($forbio1), array_filter($forbio2), array_filter($forbio3));
	$countingbio = 0;
	while($countingbio <= 120){
	if(count(array_column($array_all_bio, $countingbio)) == 3){
	$biof2[] = round(array_sum(array_column($array_all_bio, $countingbio))/3);
	}
	else if(count(array_column($array_all_bio, $countingbio)) == 2){
	$biof2[] = round(array_sum(array_column($array_all_bio, $countingbio))/2);
	}
	else if(count(array_column($array_all_bio, $countingbio)) == 1){
	$biof2[] = round(array_sum(array_column($array_all_bio, $countingbio))/1);
	}
	else{
	$biof2[] = round(array_sum(array_column($array_all_bio, $countingbio))/3);	
	}
	$countingbio++;
	}
	$biof = implode("-",array_filter($biof2));
	$biomx2 = explode("-",$biof);
	$biomx = max(explode("-",$biof));
	$stnameandscoreBio = array_combine($acbiokeys,$biomx2);
	$maxinallsub = $biomx;			
	}
	else if($su == 'Business Studies'){
		$resultmxbystunamebus1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Business Studies' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebus1))
	{	
		$snm2bus1[] = $rsn['score'];
		$stin2bus[] = $rsn['student_name'];
	}
	$acbusf = array_combine($stin2bus,$snm2bus1);
	$resultmxbystunamebus2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Business Studies' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebus2))
	{	
		$snm2bus2[] = $rsn['score'];
	    $stin2bus2[] = $rsn['student_name'];
	}
	$acbuss = array_combine($stin2bus2,$snm2bus2);
	$resultmxbystunamebus3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Business Studies' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebus3))
	{	
		$snm2bus3[] = $rsn['score'];
		$stin2bus3[] = $rsn['student_name'];
	}
	$acbust = array_combine($stin2bus3,$snm2bus3);
	$arinall = array($acbusf, $acbuss, $acbust);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acbuskeys = (array_keys($largest_arr));
$forbus1 = 	array($snm2bus1[0], $snm2bus1[1], $snm2bus1[2], $snm2bus1[3], $snm2bus1[4], $snm2bus1[5], $snm2bus1[6], $snm2bus1[7], $snm2bus1[8], $snm2bus1[9], $snm2bus1[10], $snm2bus1[11], $snm2bus1[12], $snm2bus1[13], $snm2bus1[14], $snm2bus1[15], $snm2bus1[16], $snm2bus1[17], $snm2bus1[18], $snm2bus1[19], 
		$snm2bus1[20], $snm2bus1[21], $snm2bus1[22], $snm2bus1[23], $snm2bus1[24], $snm2bus1[25], $snm2bus1[26], $snm2bus1[27], $snm2bus1[28], $snm2bus1[29], $snm2bus1[30], $snm2bus1[31], $snm2bus1[32], $snm2bus1[33], $snm2bus1[34], $snm2bus1[35], $snm2bus1[36], $snm2bus1[37], $snm2bus1[38], $snm2bus1[39], 
		$snm2bus1[40], $snm2bus1[41], $snm2bus1[42], $snm2bus1[43], $snm2bus1[44], $snm2bus1[45], $snm2bus1[46], $snm2bus1[47], $snm2bus1[48], $snm2bus1[49], $snm2bus1[50], $snm2bus1[51], $snm2bus1[52], $snm2bus1[53], $snm2bus1[54], $snm2bus1[55], $snm2bus1[56], $snm2bus1[57], $snm2bus1[58], $snm2bus1[59], 
		$snm2bus1[60], $snm2bio1[61], $snm2bus1[62], $snm2bus1[63], $snm2bus1[64], $snm2bus1[65], $snm2bus1[66], $snm2bus1[67], $snm2bus1[68], $snm2bus1[69], $snm2bus1[70], $snm2bus1[71], $snm2bus1[72], $snm2bus1[73], $snm2bus1[74], $snm2bus1[75], $snm2bus1[76], $snm2bus1[77], $snm2bus1[78], $snm2bus1[79], 
		$snm2bus1[80], $snm2bus1[81], $snm2bus1[82], $snm2bus1[83], $snm2bus1[84], $snm2bus1[85], $snm2bus1[86], $snm2bus1[87], $snm2bus1[88], $snm2bus1[89], $snm2bus1[90], $snm2bus1[91], $snm2bus1[92], $snm2bus1[93], $snm2bus1[94], $snm2bus1[95], $snm2bus1[96], $snm2bus1[97], $snm2bus1[98], $snm2bus1[99], 
		$snm2bus1[100], $snm2bus1[101], $snm2bus1[102], $snm2bus1[103], $snm2bus1[104], $snm2bus1[105], $snm2bus1[106], $snm2bus1[107], $snm2bus1[108], $snm2bus1[109], $snm2bus1[110], $snm2bus1[111], $snm2bus1[112], $snm2bus1[113], $snm2bus1[114], $snm2bus1[115], $snm2bus1[116], $snm2bus1[117], $snm2bus1[118], $snm2bus1[119], 
		$snm2bus1[120]);
$forbus2 = 	array($snm2bus2[0], $snm2bus2[1], $snm2bus2[2], $snm2bus2[3], $snm2bus2[4], $snm2bus2[5], $snm2bus2[6], $snm2bus2[7], $snm2bus2[8], $snm2bus2[9], $snm2bus2[10], $snm2bus2[11], $snm2bus2[12], $snm2bus2[13], $snm2bus2[14], $snm2bus2[15], $snm2bus2[16], $snm2bus2[17], $snm2bus2[18], $snm2bus2[19], 
		$snm2bus2[20], $snm2bus2[21], $snm2bus2[22], $snm2bus2[23], $snm2bus2[24], $snm2bus2[25], $snm2bus2[26], $snm2bus2[27], $snm2bus2[28], $snm2bus2[29], $snm2bus2[30], $snm2bus2[31], $snm2bus2[32], $snm2bus2[33], $snm2bus2[34], $snm2bus2[35], $snm2bus2[36], $snm2bus2[37], $snm2bus2[38], $snm2bus2[39], 
		$snm2bus2[40], $snm2bus2[41], $snm2bus2[42], $snm2bus2[43], $snm2bus2[44], $snm2bus2[45], $snm2bus2[46], $snm2bus2[47], $snm2bus2[48], $snm2bus2[49], $snm2bus2[50], $snm2bus2[51], $snm2bus2[52], $snm2bus2[53], $snm2bus2[54], $snm2bus2[55], $snm2bus2[56], $snm2bus2[57], $snm2bus2[58], $snm2bus2[59], 
		$snm2bus2[60], $snm2bus2[61], $snm2bus2[62], $snm2bus2[63], $snm2bus2[64], $snm2bus2[65], $snm2bus2[66], $snm2bus2[67], $snm2bus2[68], $snm2bus2[69], $snm2bus2[70], $snm2bus2[71], $snm2bus2[72], $snm2bus2[73], $snm2bus2[74], $snm2bus2[75], $snm2bus2[76], $snm2bus2[77], $snm2bus2[78], $snm2bus2[79], 
		$snm2bus2[80], $snm2bus2[81], $snm2bus2[82], $snm2bus2[83], $snm2bus2[84], $snm2bus2[85], $snm2bus2[86], $snm2bus2[87], $snm2bus2[88], $snm2bus2[89], $snm2bus2[90], $snm2bus2[91], $snm2bus2[92], $snm2bus2[93], $snm2bus2[94], $snm2bus2[95], $snm2bus2[96], $snm2bus2[97], $snm2bus2[98], $snm2bus2[99], 
		$snm2bus2[100], $snm2bus2[101], $snm2bus2[102], $snm2bus2[103], $snm2bus2[104], $snm2bus2[105], $snm2bus2[106], $snm2bus2[107], $snm2bus2[108], $snm2bus2[109], $snm2bus2[110], $snm2bus2[111], $snm2bus2[112], $snm2bus2[113], $snm2bus2[114], $snm2bus2[115], $snm2bus2[116], $snm2bus2[117], $snm2bus2[118], $snm2bus2[119], 
		$snm2bus2[120]);
$forbus3 = 	array($snm2bus3[0], $snm2bus3[1], $snm2bus3[2], $snm2bus3[3], $snm2bus3[4], $snm2bus3[5], $snm2bus3[6], $snm2bus3[7], $snm2bus3[8], $snm2bus3[9], $snm2bus3[10], $snm2bus3[11], $snm2bus3[12], $snm2bus3[13], $snm2bus3[14], $snm2bus3[15], $snm2bus3[16], $snm2bus3[17], $snm2bus3[18], $snm2bus3[19], 
		$snm2bus3[20], $snm2bus3[21], $snm2bus3[22], $snm2bus3[23], $snm2bus3[24], $snm2bus3[25], $snm2bus3[26], $snm2bus3[27], $snm2bus3[28], $snm2bus3[29], $snm2bus3[30], $snm2bus3[31], $snm2bus3[32], $snm2bus3[33], $snm2bus3[34], $snm2bus3[35], $snm2bus3[36], $snm2bus3[37], $snm2bus3[38], $snm2bus3[39], 
		$snm2bus3[40], $snm2bus3[41], $snm2bus3[42], $snm2bus3[43], $snm2bus3[44], $snm2bus3[45], $snm2bus3[46], $snm2bus3[47], $snm2bus3[48], $snm2bus3[49], $snm2bus3[50], $snm2bus3[51], $snm2bus3[52], $snm2bus3[53], $snm2bus3[54], $snm2bus3[55], $snm2bus3[56], $snm2bus3[57], $snm2bus3[58], $snm2bus3[59], 
		$snm2bus3[60], $snm2bus3[61], $snm2bus3[62], $snm2bus3[63], $snm2bus3[64], $snm2bus3[65], $snm2bus3[66], $snm2bus3[67], $snm2bus3[68], $snm2bus3[69], $snm2bus3[70], $snm2bus3[71], $snm2bus3[72], $snm2bus3[73], $snm2bus3[74], $snm2bus3[75], $snm2bus3[76], $snm2bus3[77], $snm2bus3[78], $snm2bus3[79], 
		$snm2bus3[80], $snm2bus3[81], $snm2bus3[82], $snm2bus3[83], $snm2bus3[84], $snm2bus3[85], $snm2bus3[86], $snm2bus3[87], $snm2bus3[88], $snm2bus3[89], $snm2bus3[90], $snm2bus3[91], $snm2bus3[92], $snm2bus3[93], $snm2bus3[94], $snm2bus3[95], $snm2bus3[96], $snm2bus3[97], $snm2bus3[98], $snm2bus3[99], 
		$snm2bus3[100], $snm2bus3[101], $snm2bus3[102], $snm2bus3[103], $snm2bus3[104], $snm2bus3[105], $snm2bus3[106], $snm2bus3[107], $snm2bus3[108], $snm2bus3[109], $snm2bus3[110], $snm2bus3[111], $snm2bus3[112], $snm2bus3[113], $snm2bus3[114], $snm2bus3[115], $snm2bus3[116], $snm2bus3[117], $snm2bus3[118], $snm2bus3[119], 
		$snm2bus3[120]);
	$array_all_bus = array(array_filter($forbus1), array_filter($forbus2), array_filter($forbus3));
	$countingbus = 0;
	while($countingbus <= 120){
	if(count(array_column($array_all_bus, $countingbus)) == 3){
	$busf2[] = round(array_sum(array_column($array_all_bus, $countingbus))/3);
	}
	else if(count(array_column($array_all_bus, $countingbus)) == 2){
	$busf2[] = round(array_sum(array_column($array_all_bus, $countingbus))/2);
	}
	else if(count(array_column($array_all_bus, $countingbus)) == 1){
	$busf2[] = round(array_sum(array_column($array_all_bus, $countingbus))/1);
	}
	else{
	$busf2[] = round(array_sum(array_column($array_all_bus, $countingbus))/3);	
	}
	$countingbus++;
	}
	$busf = implode("-",array_filter($busf2));
	$busmx2 = explode("-",$busf);
	$busmx = max(explode("-",$busf));
	$stnameandscoreBus = array_combine($acbuskeys,$busmx2);
	$maxinallsub = $busmx;			
	}
	else if($su == 'Catering'){
		$resultmxbystunamecat1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Catering' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecat1))
	{	
		$snm2cat1[] = $rsn['score'];
		$stin2cat[] = $rsn['student_name'];
	}
	$accatf = array_combine($stin2cat,$snm2cat1);
	$resultmxbystunamecat2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Catering' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecat2))
	{	
		$snm2cat2[] = $rsn['score'];
	    $stin2cat2[] = $rsn['student_name'];
	}
	$accats = array_combine($stin2cat2,$snm2cat2);
	$resultmxbystunamecat3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Catering' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecat3))
	{	
		$snm2cat3[] = $rsn['score'];
		$stin2cat3[] = $rsn['student_name'];
	}
	$accatt = array_combine($stin2cat3,$snm2cat3);
	$arinall = array($accatf, $accats, $accatt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$accatkeys = (array_keys($largest_arr));
	
$forcat1 = array();
for($v=0; $v<=120; $v++){
$forccat1[] = $snm2cat1[$v];
}
$forcat1 = $forccat1;

$forcat2 = array();
for($v=0; $v<=120; $v++){
$forccat2[] = $snm2cat2[$v];
}
$forcat2 = $forccat2;

$forcat3 = array();
for($v=0; $v<=120; $v++){
$forccat3[] = $snm2cat3[$v];
}
$forcat3 = $forccat3;

	$array_all_cat = array(array_filter($forcat1), array_filter($forcat2), array_filter($forcat3));
	$countingcat = 0;
	while($countingcat <= 120){
	if(count(array_column($array_all_cat, $countingcat)) == 3){
	$catf2[] = round(array_sum(array_column($array_all_cat, $countingcat))/3);
	}
	else if(count(array_column($array_all_cat, $countingcat)) == 2){
	$catf2[] = round(array_sum(array_column($array_all_cat, $countingcat))/2);
	}
	else if(count(array_column($array_all_cat, $countingcat)) == 1){
	$catf2[] = round(array_sum(array_column($array_all_cat, $countingcat))/1);
	}
	else{
	$catf2[] = round(array_sum(array_column($array_all_cat, $countingcat))/3);	
	}
	$countingcat++;
	}
	$catf = implode("-",array_filter($catf2));
	$catmx2 = explode("-",$catf);
	$catmx = max(explode("-",$catf));
	$stnameandscoreCat = array_combine($accatkeys,$catmx2);
	$maxinallsub = $catmx;			
	}
	else if($su == 'Chemistry'){
		$resultmxbystunameche1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Chemistry' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameche1))
	{	
		$snm2che1[] = $rsn['score'];
		$stin2che[] = $rsn['student_name'];
	}
	$acchef = array_combine($stin2che,$snm2che1);
	$resultmxbystunameche2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Chemistry' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameche2))
	{	
		$snm2che2[] = $rsn['score'];
	    $stin2che2[] = $rsn['student_name'];
	}
	$acches = array_combine($stin2che2,$snm2che2);
	$resultmxbystunameche3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Chemistry' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameche3))
	{	
		$snm2che3[] = $rsn['score'];
		$stin2che3[] = $rsn['student_name'];
	}
	$acchet = array_combine($stin2che3,$snm2che3);
	$arinall = array($acchef, $acches, $acchet);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acchekeys = (array_keys($largest_arr));
	
$forche1 = array();
for($v=0; $v<=120; $v++){
$forcche1[] = $snm2che1[$v];
}
$forche1 = $forcche1;

$forche2 = array();
for($v=0; $v<=120; $v++){
$forcche2[] = $snm2che2[$v];
}
$forche2 = $forcche2;

$forche3 = array();
for($v=0; $v<=120; $v++){
$forcche3[] = $snm2che3[$v];
}
$forche3 = $forcche3;

	$array_all_che = array(array_filter($forche1), array_filter($forche2), array_filter($forche3));
	$countingche = 0;
	while($countingche <= 120){
	if(count(array_column($array_all_che, $countingche)) == 3){
	$chef2[] = round(array_sum(array_column($array_all_che, $countingche))/3);
	}
	else if(count(array_column($array_all_che, $countingche)) == 2){
	$chef2[] = round(array_sum(array_column($array_all_che, $countingche))/2);
	}
	else if(count(array_column($array_all_che, $countingche)) == 1){
	$chef2[] = round(array_sum(array_column($array_all_che, $countingche))/1);
	}
	else{
	$chef2[] = round(array_sum(array_column($array_all_che, $countingche))/3);	
	}
	$countingche++;
	}
	$chef = implode("-",array_filter($chef2));
	$chemx2 = explode("-",$chef);
	$chemx = max(explode("-",$chef));
	$stnameandscoreChe = array_combine($acchekeys,$chemx2);
	$maxinallsub = $chemx;			
	}
	else if($su == 'Civic Education'){
		$resultmxbystunameciv1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Civic Education' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameciv1))
	{	
		$snm2civ1[] = $rsn['score'];
		$stin2civ[] = $rsn['student_name'];
	}
	$accivf = array_combine($stin2civ,$snm2civ1);
	$resultmxbystunameciv2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Civic Education' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameciv2))
	{	
		$snm2civ2[] = $rsn['score'];
	    $stin2civ2[] = $rsn['student_name'];
	}
	$accivs = array_combine($stin2civ2,$snm2civ2);
	$resultmxbystunameciv3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Civic Education' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameciv3))
	{	
		$snm2civ3[] = $rsn['score'];
		$stin2civ3[] = $rsn['student_name'];
	}
	$accivt = array_combine($stin2civ3,$snm2civ3);
	$arinall = array($accivf, $accivs, $accivt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$accivkeys = (array_keys($largest_arr));
	
$forciv1 = array();
for($v=0; $v<=120; $v++){
$forcciv1[] = $snm2civ1[$v];
}
$forciv1 = $forcciv1;

$forciv2 = array();
for($v=0; $v<=120; $v++){
$forcciv2[] = $snm2civ2[$v];
}
$forciv2 = $forcciv2;

$forciv3 = array();
for($v=0; $v<=120; $v++){
$forcciv3[] = $snm2civ3[$v];
}
$forciv3 = $forcciv3;

	$array_all_civ = array(array_filter($forciv1), array_filter($forciv2), array_filter($forciv3));
	$countingciv = 0;
	while($countingciv <= 120){
	if(count(array_column($array_all_civ, $countingciv)) == 3){
	$civf2[] = round(array_sum(array_column($array_all_civ, $countingciv))/3);
	}
	else if(count(array_column($array_all_civ, $countingciv)) == 2){
	$civf2[] = round(array_sum(array_column($array_all_civ, $countingciv))/2);
	}
	else if(count(array_column($array_all_civ, $countingciv)) == 1){
	$civf2[] = round(array_sum(array_column($array_all_civ, $countingciv))/1);
	}
	else{
	$civf2[] = round(array_sum(array_column($array_all_civ, $countingciv))/3);	
	}
	$countingciv++;
	}
	$civf = implode("-",array_filter($civf2));
	$civmx2 = explode("-",$civf);
	$civmx = max(explode("-",$civf));
	$stnameandscoreCiv = array_combine($accivkeys,$civmx2);
	$maxinallsub = $civmx;			
	}
	
	else if($su == 'Creative and Cultural Arts'){
		$resultmxbystunamecca1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Creative and Cultural Arts' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecca1))
	{	
		$snm2cca1[] = $rsn['score'];
		$stin2cca[] = $rsn['student_name'];
	}
	$acccaf = array_combine($stin2cca,$snm2cca1);
	$resultmxbystunamecca2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Creative and Cultural Arts' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecca2))
	{	
		$snm2cca2[] = $rsn['score'];
	    $stin2cca2[] = $rsn['student_name'];
	}
	$acccas = array_combine($stin2cca2,$snm2cca2);
	$resultmxbystunamecca3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Creative and Cultural Arts Studies' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecca3))
	{	
		$snm2cca3[] = $rsn['score'];
		$stin2cca3[] = $rsn['student_name'];
	}
	$acccat = array_combine($stin2cca3,$snm2cca3);
	$arinall = array($acccaf, $acccas, $acccat);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acccakeys = (array_keys($largest_arr));
	
$forcca1 = array();
$forcca2 = array();
$forcca3 = array();
for($v=0; $v<=120; $v++){
$forccca1[] = $snm2cca1[$v];
$forccca2[] = $snm2cca2[$v];
$forccca3[] = $snm2cca3[$v];
}
$forcca1 = $forccca1;
$forcca2 = $forccca2;
$forcca3 = $forccca3;

	$array_all_cca = array(array_filter($forcca1), array_filter($forcca2), array_filter($forcca3));
	$countingcca = 0;
	while($countingcca <= 120){
	if(count(array_column($array_all_cca, $countingcca)) == 3){
	$ccaf2[] = round(array_sum(array_column($array_all_cca, $countingcca))/3);
	}
	else if(count(array_column($array_all_cca, $countingcca)) == 2){
	$ccaf2[] = round(array_sum(array_column($array_all_cca, $countingcca))/2);
	}
	else if(count(array_column($array_all_cca, $countingcca)) == 1){
	$ccaf2[] = round(array_sum(array_column($array_all_cca, $countingcca))/1);
	}
	else{
	$ccaf2[] = round(array_sum(array_column($array_all_cca, $countingcca))/3);	
	}
	$countingcca++;
	}
	$ccaf = implode("-",array_filter($ccaf2));
	$ccamx2 = explode("-",$ccaf);
	$ccamx = max(explode("-",$ccaf));
	$stnameandscoreCca = array_combine($acccakeys,$ccamx2);
	$maxinallsub = $ccamx;			
	}
		else if($su == 'CRK'){
		$resultmxbystunamecrk1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='CRK' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecrk1))
	{	
		$snm2crk1[] = $rsn['score'];
		$stin2crk[] = $rsn['student_name'];
	}
	$accrkf = array_combine($stin2crk,$snm2crk1);
	$resultmxbystunamecrk2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='CRK' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecrk2))
	{	
		$snm2crk2[] = $rsn['score'];
	    $stin2crk2[] = $rsn['student_name'];
	}
	$accrks = array_combine($stin2crk2,$snm2crk2);
	$resultmxbystunamecrk3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='CRK' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecRK3))
	{	
		$snm2crk3[] = $rsn['score'];
		$stin2crk3[] = $rsn['student_name'];
	}
	$accrkt = array_combine($stin2crk3,$snm2crk3);
	$arinall = array($accrkf, $accrks, $accrkt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$accrkkeys = (array_keys($largest_arr));
	
$forcrk1 = array();
for($v=0; $v<=120; $v++){
$forccrk1[] = $snm2crk1[$v];
}
$forcrk1 = $forccrk1;

$forcrk2 = array();
for($v=0; $v<=120; $v++){
$forccrk2[] = $snm2crk2[$v];
}
$forcrk2 = $forccrk2;

$forcrk3 = array();
for($v=0; $v<=120; $v++){
$forccrk3[] = $snm2crk3[$v];
}
$forcrk3 = $forccrk3;

	$array_all_crk = array(array_filter($forcrk1), array_filter($forcrk2), array_filter($forcrk3));
	$countingcrk = 0;
	while($countingcrk <= 120){
	if(count(array_column($array_all_crk, $countingcrk)) == 3){
	$crkf2[] = round(array_sum(array_column($array_all_crk, $countingcrk))/3);
	}
	else if(count(array_column($array_all_crk, $countingcrk)) == 2){
	$crkf2[] = round(array_sum(array_column($array_all_crk, $countingcrk))/2);
	}
	else if(count(array_column($array_all_crk, $countingcrk)) == 1){
	$crkf2[] = round(array_sum(array_column($array_all_crk, $countingcrk))/1);
	}
	else{
	$crkf2[] = round(array_sum(array_column($array_all_crk, $countingcrk))/3);	
	}
	$countingcrk++;
	}
	$crkf = implode("-",array_filter($crkf2));
	$crkmx2 = explode("-",$crkf);
	$crkmx = max(explode("-",$crkf));
	$stnameandscoreCrk = array_combine($accrkkeys,$crkmx2);
	$maxinallsub = $crkmx;			
	}
	else if($su == 'Economics'){
		$resultmxbystunameeco1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Economics' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeco1))
	{	
		$snm2eco1[] = $rsn['score'];
		$stin2eco[] = $rsn['student_name'];
	}
	$acecof = array_combine($stin2eco,$snm2eco1);
	$resultmxbystunameeco2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Economics' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeco2))
	{	
		$snm2eco2[] = $rsn['score'];
	    $stin2eco2[] = $rsn['student_name'];
	}
	$acecos = array_combine($stin2eco2,$snm2eco2);
	$resultmxbystunameeco3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Economics' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeco3))
	{	
		$snm2eco3[] = $rsn['score'];
		$stin2eco3[] = $rsn['student_name'];
	}
	$acecot = array_combine($stin2eco3,$snm2eco3);
	$arinall = array($acecof, $acecos, $acecot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acecokeys = (array_keys($largest_arr));
	
$foreco1 = array();
$foreco2 = array();
$foreco3 = array();
for($v=0; $v<=120; $v++){
$foreeco1[] = $snm2eco1[$v];
$foreeco2[] = $snm2eco2[$v];
$foreeco3[] = $snm2eco3[$v];
}
$foreco1 = $foreeco1;
$foreco2 = $foreeco2;
$foreco3 = $foreeco3;

	$array_all_eco = array(array_filter($foreco1), array_filter($foreco2), array_filter($foreco3));
	$countingeco = 0;
	while($countingeco <= 120){
	if(count(array_column($array_all_eco, $countingeco)) == 3){
	$ecof2[] = round(array_sum(array_column($array_all_eco, $countingeco))/3);
	}
	else if(count(array_column($array_all_eco, $countingeco)) == 2){
	$ecof2[] = round(array_sum(array_column($array_all_eco, $countingeco))/2);
	}
	else if(count(array_column($array_all_eco, $countingeco)) == 1){
	$ecof2[] = round(array_sum(array_column($array_all_eco, $countingeco))/1);
	}
	else{
	$ecof2[] = round(array_sum(array_column($array_all_eco, $countingeco))/3);	
	}
	$countingeco++;
	}
	$ecof = implode("-",array_filter($ecof2));
	$ecomx2 = explode("-",$ecof);
	$ecomx = max(explode("-",$ecof));
	$stnameandscoreEco = array_combine($acecokeys,$ecomx2);
	$maxinallsub = $ecomx;			
	}
	
	else if($su == 'Financial Accounting'){
		$resultmxbystunamefin1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Financial Accounting' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefin1))
	{
		$snm2fin1[] = $rsn['score'];
		$stin2fin[] = $rsn['student_name'];
	}
	$acfinf = array_combine($stin2fin,$snm2fin1);
	$resultmxbystunamefin2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Financial Accounting' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefin2))
	{
		$snm2fin2[] = $rsn['score'];
		$stin2fin2[] = $rsn['student_name'];	
	}
	$acfins = array_combine($stin2fin2,$snm2fin2);
	$resultmxbystunamefin3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Financial Accounting' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefin3))
	{	
		$snm2fin3[] = $rsn['score'];
		$stin2fin3[] = $rsn['student_name'];
	}
	$acfint = array_combine($stin2fin3,$snm2fin3);
	$arinall = array($acfinf, $acfins, $acfint);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acfinkeys = (array_keys($largest_arr));
	
$forfin1 = array();
$forfin2 = array();
$forfin3 = array();
for($v=0; $v<=120; $v++){
$forffin1[] = $snm2fin1[$v];
$forffin2[] = $snm2fin2[$v];
$forffin3[] = $snm2fin3[$v];
}
$forfin1 = $forffin1;
$forfin2 = $forffin2;
$forfin3 = $forffin3;

	$array_all_fin = array(array_filter($forfin1), array_filter($forfin2), array_filter($forfin3));
	$countingfin = 0;
	while($countingfin <= 120){
	if(count(array_column($array_all_fin, $countingfin)) == 3){
	$finf2[] = round(array_sum(array_column($array_all_fin, $countingfin))/3);
	}
	else if(count(array_column($array_all_fin, $countingfin)) == 2){
	$finf2[] = round(array_sum(array_column($array_all_fin, $countingfin))/2);
	}
	else if(count(array_column($array_all_fin, $countingfin)) == 1){
	$finf2[] = round(array_sum(array_column($array_all_fin, $countingfin))/1);
	}
	else{
	$finf2[] = round(array_sum(array_column($array_all_fin, $countingfin))/3);	
	}
	$countingfin++;
	}
	$finf = implode("-",array_filter($finf2));
	$finmx2 = explode("-",$finf);
	$finmx = max(explode("-",$finf));
	$stnameandscoreFin = array_combine($acfinkeys,$finmx2);
	$maxinallsub = $finmx;			
	}
	
	else if($su == 'Food and Nutrition'){
		$resultmxbystunamefoo1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Food and Nutrition' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefoo1))
	{	
		$snm2foo1[] = $rsn['score'];
		$stin2foo[] = $rsn['student_name'];
	}
	$acfoof = array_combine($stin2foo,$snm2foo1);
	$resultmxbystunamefoo2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Food and Nutrition' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefoo2))
	{	
		$snm2foo2[] = $rsn['score'];
	    $stin2foo2[] = $rsn['student_name'];
	}
	$acfoos = array_combine($stin2foo2,$snm2foo2);
	$resultmxbystunamefoo3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Food and Nutrition' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefoo3))
	{	
		$snm2foo3[] = $rsn['score'];
		$stin2foo3[] = $rsn['student_name'];
	}
	$acfoot = array_combine($stin2foo3,$snm2foo3);
	$arinall = array($acfoof, $acfoos, $acfoot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acfookeys = (array_keys($largest_arr));
	
$forfoo1 = array();
$forfoo2 = array();
$forfoo3 = array();
for($v=0; $v<=120; $v++){
$forffoo1[] = $snm2foo1[$v];
$forffoo2[] = $snm2foo2[$v];
$forffoo3[] = $snm2foo3[$v];
}
$forfoo1 = $forffoo1;
$forfoo2 = $forffoo2;
$forfoo3 = $forffoo3;

	$array_all_foo = array(array_filter($forfoo1), array_filter($forfoo2), array_filter($forfoo3));
	$countingfoo = 0;
	while($countingfoo <= 120){
	if(count(array_column($array_all_foo, $countingfoo)) == 3){
	$foof2[] = round(array_sum(array_column($array_all_foo, $countingfoo))/3);
	}
	else if(count(array_column($array_all_foo, $countingfoo)) == 2){
	$foof2[] = round(array_sum(array_column($array_all_foo, $countingfoo))/2);
	}
	else if(count(array_column($array_all_foo, $countingfoo)) == 1){
	$foof2[] = round(array_sum(array_column($array_all_foo, $countingfoo))/1);
	}
	else{
	$foof2[] = round(array_sum(array_column($array_all_foo, $countingfoo))/3);	
	}
	$countingfoo++;
	}
	$foof = implode("-",array_filter($foof2));
	$foomx2 = explode("-",$foof);
	$foomx = max(explode("-",$foof));
	$stnameandscoreFoo = array_combine($acfookeys,$foomx2);
	$maxinallsub = $foomx;			
	}
		else if($su == 'Music'){
		$resultmxbystunamemus1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Music' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemus1))
	{	
		$snm2mus1[] = $rsn['score'];
		$stin2mus[] = $rsn['student_name'];
	}
	$acmusf = array_combine($stin2mus,$snm2mus1);
	$resultmxbystunamemus2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Music' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemus2))
	{	
		$snm2mus2[] = $rsn['score'];
	    $stin2mus2[] = $rsn['student_name'];
	}
	$acmuss = array_combine($stin2mus2,$snm2mus2);
	//print_r($acmuss);
	$resultmxbystunamemus3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Music' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemus3))
	{	
		$snm2mus3[] = $rsn['score'];
		$stin2mus3[] = $rsn['student_name'];
	}
	$acmust = array_combine($stin2mus3,$snm2mus3);
	$arinall = array($acmusf, $acmuss, $acmust);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acmuskeys = (array_keys($largest_arr));
	
$formus1 = array();
$formus2 = array();
$formus3 = array();
for($v=0; $v<=120; $v++){
$formmus1[] = $snm2mus1[$v];
$formmus2[] = $snm2mus2[$v];
$formmus3[] = $snm2mus3[$v];
}
$formus1 = $formmus1;
$formus2 = $formmus2;
$formus3 = $formmus3;

	$array_all_mus = array(array_filter($formus1), array_filter($formus2), array_filter($formus3));
	$countingmus = 0;
	while($countingmus <= 120){
	if(count(array_column($array_all_mus, $countingmus)) == 3){
	$musf2[] = round(array_sum(array_column($array_all_mus, $countingmus))/3);
	}
	else if(count(array_column($array_all_mus, $countingmus)) == 2){
	$musf2[] = round(array_sum(array_column($array_all_mus, $countingmus))/2);
	}
	else if(count(array_column($array_all_mus, $countingmus)) == 1){
	$musf2[] = round(array_sum(array_column($array_all_mus, $countingmus))/1);
	}
	else{
	$musf2[] = round(array_sum(array_column($array_all_mus, $countingmus))/3);	
	}
	$countingmus++;
	}
	$musf = implode("-",array_filter($musf2));
	$musmx2 = explode("-",$musf);
	$musmx = max(explode("-",$musf));
	$stnameandscoreMus = array_combine($acmuskeys,$musmx2);
	$maxinallsub = $musmx;			
	}
	else if($su == 'Government'){
		$resultmxbystunamegov1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Government' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegov1))
	{	
		$snm2gov1[] = $rsn['score'];
		$stin2gov[] = $rsn['student_name'];
	}
	$acgovf = array_combine($stin2gov,$snm2gov1);
	$resultmxbystunamegov2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Government' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegov2))
	{	
		$snm2gov2[] = $rsn['score'];
	    $stin2gov2[] = $rsn['student_name'];
	}
	$acgovs = array_combine($stin2gov2,$snm2gov2);
	$resultmxbystunamegov3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Government' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegov3))
	{	
		$snm2gov3[] = $rsn['score'];
		$stin2gov3[] = $rsn['student_name'];
	}
	$acgovt = array_combine($stin2gov3,$snm2gov3);
	$arinall = array($acgovf, $acgovs, $acgovt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acgovkeys = (array_keys($largest_arr));
	
$forgov1 = array();
$forgov2 = array();
$forgov3 = array();
for($v=0; $v<=120; $v++){
$forggov1[] = $snm2gov1[$v];
$forggov2[] = $snm2gov2[$v];
$forggov3[] = $snm2gov3[$v];
}
$forgov1 = $forggov1;
$forgov2 = $forggov2;
$forgov3 = $forggov3;

	$array_all_gov = array(array_filter($forgov1), array_filter($forgov2), array_filter($forgov3));
	$countinggov = 0;
	while($countinggov <= 120){
	if(count(array_column($array_all_gov, $countinggov)) == 3){
	$govf2[] = round(array_sum(array_column($array_all_gov, $countinggov))/3);
	}
	else if(count(array_column($array_all_gov, $countinggov)) == 2){
	$govf2[] = round(array_sum(array_column($array_all_gov, $countinggov))/2);
	}
	else if(count(array_column($array_all_gov, $countinggov)) == 1){
	$govf2[] = round(array_sum(array_column($array_all_gov, $countinggov))/1);
	}
	else{
	$govf2[] = round(array_sum(array_column($array_all_gov, $countinggov))/3);	
	}
	$countinggov++;
	}
	$govf = implode("-",array_filter($govf2));
	$govmx2 = explode("-",$govf);
	$govmx = max(explode("-",$govf));
	$stnameandscoreGov = array_combine($acgovkeys,$govmx2);
	$maxinallsub = $govmx;			
	}
		else if($su == 'Hausa'){
		$resultmxbystunamehau1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Hausa' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehau1))
	{	
		$snm2hau1[] = $rsn['score'];
		$stin2hau[] = $rsn['student_name'];
	}
	$achauf = array_combine($stin2hau,$snm2hau1);
	$resultmxbystunamehau2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Hausa' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehau2))
	{	
		$snm2hau2[] = $rsn['score'];
	    $stin2hau2[] = $rsn['student_name'];
	}
	$achaus = array_combine($stin2hau2,$snm2hau2);
	$resultmxbystunamehau3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Hausa' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehau3))
	{	
		$snm2hau3[] = $rsn['score'];
		$stin2hau3[] = $rsn['student_name'];
	}
	$achaut = array_combine($stin2hau3,$snm2hau3);
	$arinall = array($achauf, $achaus, $achaut);
	//print_r($arinall);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$achaukeys = (array_keys($largest_arr));
	
$forhau1 = array();
$forhau2 = array();
$forhau3 = array();
for($v=0; $v<=120; $v++){
$forhhau1[] = $snm2hau1[$v];
$forhhau2[] = $snm2hau2[$v];
$forhhau3[] = $snm2hau3[$v];
}
$forhau1 = $forhhau1;
$forhau2 = $forhhau2;
$forhau3 = $forhhau3;
//print_r($array_all_irs);

	$array_all_hau = array(array_filter($forhau1), array_filter($forhau2), array_filter($forhau3));
	$countinghau = 0;
	while($countinghau <= 120){
	if(count(array_column($array_all_hau, $countinghau)) == 3){
	$hauf2[] = round(array_sum(array_column($array_all_hau, $countinghau))/3);
	}
	else if(count(array_column($array_all_hau, $countinghau)) == 2){
	$hauf2[] = round(array_sum(array_column($array_all_hau, $countinghau))/2);
	}
	else if(count(array_column($array_all_hau, $countinghau)) == 1){
	$hauf2[] = round(array_sum(array_column($array_all_hau, $countinghau))/1);
	}
	else{
	$hauf2[] = round(array_sum(array_column($array_all_hau, $countinghau))/3);	
	}
	$countinghau++;
	}
	$hauf = implode("-",array_filter($hauf2));
	$haumx2 = explode("-",$hauf);
	$haumx = max(explode("-",$hauf));
	$stnameandscoreHau = array_combine($achaukeys,$haumx2);
	$maxinallsub = $haumx;			
	}
	else if($su == 'History'){
		$resultmxbystunamehis1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='History' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehis1))
	{	
		$snm2his1[] = $rsn['score'];
		$stin2his[] = $rsn['student_name'];
	}
	$achisf = array_combine($stin2his,$snm2his1);
	$resultmxbystunamehis2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='History' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehis2))
	{	
		$snm2his2[] = $rsn['score'];
	    $stin2his2[] = $rsn['student_name'];
	}
	$achiss = array_combine($stin2his2,$snm2his2);
	$resultmxbystunamehis3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='History' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehis3))
	{	
		$snm2his3[] = $rsn['score'];
		$stin2his3[] = $rsn['student_name'];
	}
	$achist = array_combine($stin2his3,$snm2his3);
	$arinall = array($achisf, $achiss, $achist);
	//print_r($arinall);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$achiskeys = (array_keys($largest_arr));
	
$forhis1 = array();
$forhis2 = array();
$forhis3 = array();
for($v=0; $v<=120; $v++){
$forhhis1[] = $snm2his1[$v];
$forhhis2[] = $snm2his2[$v];
$forhhis3[] = $snm2his3[$v];
}
$forhis1 = $forhhis1;
$forhis2 = $forhhis2;
$forhis3 = $forhhis3;
//print_r($array_all_irs);

	$array_all_his = array(array_filter($forhis1), array_filter($forhis2), array_filter($forhis3));
	$countinghis = 0;
	while($countinghis <= 120){
	if(count(array_column($array_all_his, $countinghis)) == 3){
	$hisf2[] = round(array_sum(array_column($array_all_his, $countinghis))/3);
	}
	else if(count(array_column($array_all_his, $countinghis)) == 2){
	$hisf2[] = round(array_sum(array_column($array_all_his, $countinghis))/2);
	}
	else if(count(array_column($array_all_his, $countinghis)) == 1){
	$hisf2[] = round(array_sum(array_column($array_all_his, $countinghis))/1);
	}
	else{
	$hisf2[] = round(array_sum(array_column($array_all_his, $countinghis))/3);	
	}
	$countinghis++;
	}
	$hisf = implode("-",array_filter($hisf2));
	$hismx2 = explode("-",$hisf);
	$hismx = max(explode("-",$hisf));
	$stnameandscoreHis = array_combine($achiskeys,$hismx2);
	$maxinallsub = $hismx;			
	}
	
		else if($su == 'ICT'){
		$resultmxbystunameict1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='ICT' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameict1))
	{	
		$snm2ict1[] = $rsn['score'];
		$stin2ict[] = $rsn['student_name'];
	}
	$acictf = array_combine($stin2ict,$snm2ict1);
	$resultmxbystunameict2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='ICT' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameict2))
	{	
		$snm2ict2[] = $rsn['score'];
	    $stin2ict2[] = $rsn['student_name'];
	}
	$acicts = array_combine($stin2ict2,$snm2ict2);
	$resultmxbystunameict3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='ICT' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameict3))
	{	
		$snm2ict3[] = $rsn['score'];
		$stin2ict3[] = $rsn['student_name'];
	}
	$acictt = array_combine($stin2ict3,$snm2ict3);
	$arinall = array($acictf, $acicts, $acictt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acictkeys = (array_keys($largest_arr));
	
$forict1 = array();
$forict2 = array();
$forict3 = array();
for($v=0; $v<=120; $v++){
$foriict1[] = $snm2ict1[$v];
$foriict2[] = $snm2ict2[$v];
$foriict3[] = $snm2ict3[$v];
}
$forict1 = $foriict1;
$forict2 = $foriict2;
$forict3 = $foriict3;

	$array_all_ict = array(array_filter($forict1), array_filter($forict2), array_filter($forict3));
	$countingict = 0;
	while($countingict <= 120){
	if(count(array_column($array_all_ict, $countingict)) == 3){
	$ictf2[] = round(array_sum(array_column($array_all_ict, $countingict))/3);
	}
	else if(count(array_column($array_all_ict, $countingict)) == 2){
	$ictf2[] = round(array_sum(array_column($array_all_ict, $countingict))/2);
	}
	else if(count(array_column($array_all_ict, $countingict)) == 1){
	$ictf2[] = round(array_sum(array_column($array_all_ict, $countingict))/1);
	}
	else{
	$ictf2[] = round(array_sum(array_column($array_all_ict, $countingict))/3);	
	}
	$countingict++;
	}
	$ictf = implode("-",array_filter($ictf2));
	$ictmx2 = explode("-",$ictf);
	$ictmx = max(explode("-",$ictf));
	$stnameandscoreIct = array_combine($acictkeys,$ictmx2);
	$maxinallsub = $ictmx;			
	}
	else if($su == 'Igbo'){
		$resultmxbystunameigb1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Igbo' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameigb1))
	{	
		$snm2igb1[] = $rsn['score'];
		$stin2igb[] = $rsn['student_name'];
	}
	$acigbf = array_combine($stin2igb,$snm2igb1);
	$resultmxbystunameigb2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Igbo' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameigb2))
	{	
		$snm2igb2[] = $rsn['score'];
	    $stin2igb2[] = $rsn['student_name'];
	}
	$acigbs = array_combine($stin2igb2,$snm2igb2);
	$resultmxbystunameigb3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Igbo' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameigb3))
	{	
		$snm2igb3[] = $rsn['score'];
		$stin2igb3[] = $rsn['student_name'];
	}
	$acigbt = array_combine($stin2igb3,$snm2igb3);
	$arinall = array($acigbf, $acigbs, $acigbt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acigbkeys = (array_keys($largest_arr));
	
$forigb1 = array();
$forigb2 = array();
$forigb3 = array();
for($v=0; $v<=120; $v++){
$foriigb1[] = $snm2igb1[$v];
$foriigb2[] = $snm2igb2[$v];
$foriigb3[] = $snm2igb3[$v];
}
$forigb1 = $foriigb1;
$forigb2 = $foriigb2;
$forigb3 = $foriigb3;

	$array_all_igb = array(array_filter($forigb1), array_filter($forigb2), array_filter($forigb3));
	$countingigb = 0;
	while($countingigb <= 120){
	if(count(array_column($array_all_igb, $countingigb)) == 3){
	$igbf2[] = round(array_sum(array_column($array_all_igb, $countingigb))/3);
	}
	else if(count(array_column($array_all_igb, $countingigb)) == 2){
	$igbf2[] = round(array_sum(array_column($array_all_igb, $countingigb))/2);
	}
	else if(count(array_column($array_all_igb, $countingigb)) == 1){
	$igbf2[] = round(array_sum(array_column($array_all_igb, $countingigb))/1);
	}
	else{
	$igbf2[] = round(array_sum(array_column($array_all_igb, $countingigb))/3);	
	}
	$countingigb++;
	}
	$igbf = implode("-",array_filter($igbf2));
	$igbmx2 = explode("-",$igbf);
	$igbmx = max(explode("-",$igbf));
	$stnameandscoreIgb = array_combine($acigbkeys,$igbmx2);
	$maxinallsub = $igbmx;			
	}
	
	else if($su == 'Islamic Religious Studies'){
		$resultmxbystunameirs1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Islamic Religious Studies' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameirs1))
	{	
		$snm2irs1[] = $rsn['score'];
		$stin2irs[] = $rsn['student_name'];
	}
	$acirsf = array_combine($stin2irs,$snm2irs1);
	$resultmxbystunameirs2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Islamic Religious Studies' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameirs2))
	{	
		$snm2irs2[] = $rsn['score'];
	    $stin2irs2[] = $rsn['student_name'];
	}
	$acirss = array_combine($stin2irs2,$snm2irs2);
	$resultmxbystunameirs3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Islamic Religious Studies' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameirs3))
	{	
		$snm2irs3[] = $rsn['score'];
		$stin2irs3[] = $rsn['student_name'];
	}
	$acirst = array_combine($stin2irs3,$snm2irs3);
	$arinall = array($acirsf, $acirss, $acirst);
	//print_r($arinall);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acirskeys = (array_keys($largest_arr));
	
$forirs1 = array();
$forirs2 = array();
$forirs3 = array();
for($v=0; $v<=120; $v++){
$foriirs1[] = $snm2irs1[$v];
$foriirs2[] = $snm2irs2[$v];
$foriirs3[] = $snm2irs3[$v];
}
$forirs1 = $foriirs1;
$forirs2 = $foriirs2;
$forirs3 = $foriirs3;
//print_r($array_all_irs);

	$array_all_irs = array(array_filter($forirs1), array_filter($forirs2), array_filter($forirs3));
	$countingirs = 0;
	while($countingirs <= 120){
	if(count(array_column($array_all_irs, $countingirs)) == 3){
	$irsf2[] = round(array_sum(array_column($array_all_irs, $countingirs))/3);
	}
	else if(count(array_column($array_all_irs, $countingirs)) == 2){
	$irsf2[] = round(array_sum(array_column($array_all_irs, $countingirs))/2);
	}
	else if(count(array_column($array_all_irs, $countingirs)) == 1){
	$irsf2[] = round(array_sum(array_column($array_all_irs, $countingirs))/1);
	}
	else{
	$irsf2[] = round(array_sum(array_column($array_all_irs, $countingirs))/3);	
	}
	$countingirs++;
	}
	$irsf = implode("-",array_filter($irsf2));
	$irsmx2 = explode("-",$irsf);
	$irsmx = max(explode("-",$irsf));
	$stnameandscoreIrs = array_combine($acirskeys,$irsmx2);
	$maxinallsub = $irsmx;			
	}
	
	else if($su == 'Literature in English'){
		$resultmxbystunamelit1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Literature in English' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamelit1))
	{	
		$snm2lit1[] = $rsn['score'];
		$stin2lit[] = $rsn['student_name'];
	}
	$aclitf = array_combine($stin2lit,$snm2lit1);
	$resultmxbystunamelit2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Literature in English' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamelit2))
	{	
		$snm2lit2[] = $rsn['score'];
	    $stin2lit2[] = $rsn['student_name'];
	}
	$aclits = array_combine($stin2lit2,$snm2lit2);
	$resultmxbystunamelit3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Literature in English' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamelit3))
	{	
		$snm2lit3[] = $rsn['score'];
		$stin2lit3[] = $rsn['student_name'];
	}
	$aclitt = array_combine($stin2lit3,$snm2lit3);
	$arinall = array($aclitf, $aclits, $aclitt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$aclitkeys = (array_keys($largest_arr));
	
$forlit1 = array();
$forlit2 = array();
$forlit3 = array();
for($v=0; $v<=120; $v++){
$forllit1[] = $snm2lit1[$v];
$forllit2[] = $snm2lit2[$v];
$forllit3[] = $snm2lit3[$v];
}
$forlit1 = $forllit1;
$forlit2 = $forllit2;
$forlit3 = $forllit3;

	$array_all_lit = array(array_filter($forlit1), array_filter($forlit2), array_filter($forlit3));
	$countinglit = 0;
	while($countinglit <= 120){
	if(count(array_column($array_all_lit, $countinglit)) == 3){
	$litf2[] = round(array_sum(array_column($array_all_lit, $countinglit))/3);
	}
	else if(count(array_column($array_all_lit, $countinglit)) == 2){
	$litf2[] = round(array_sum(array_column($array_all_lit, $countinglit))/2);
	}
	else if(count(array_column($array_all_lit, $countinglit)) == 1){
	$litf2[] = round(array_sum(array_column($array_all_lit, $countinglit))/1);
	}
	else{
	$litf2[] = round(array_sum(array_column($array_all_lit, $countinglit))/3);	
	}
	$countinglit++;
	}
	$litf = implode("-",array_filter($litf2));
	$litmx2 = explode("-",$litf);
	$litmx = max(explode("-",$litf));
	$stnameandscoreLit = array_combine($aclitkeys,$litmx2);
	$maxinallsub = $litmx;			
	}
		else if($su == 'Marketing'){
		$resultmxbystunamemar1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Marketing' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemar1))
	{	
		$snm2mar1[] = $rsn['score'];
		$stin2mar[] = $rsn['student_name'];
	}
	$acmarf = array_combine($stin2mar,$snm2mar1);
	$resultmxbystunamemar2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Marketing' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemar2))
	{	
		$snm2mar2[] = $rsn['score'];
	    $stin2mar2[] = $rsn['student_name'];
	}
	$acmars = array_combine($stin2mar2,$snm2mar2);
	$resultmxbystunamemar3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Marketing' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemar3))
	{	
		$snm2mar3[] = $rsn['score'];
		$stin2mar3[] = $rsn['student_name'];
	}
	$acmart = array_combine($stin2mar3,$snm2mar3);
	$arinall = array($acmarf, $acmars, $acmart);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acmarkeys = (array_keys($largest_arr));
	
$formar1 = array();
$formar2 = array();
$formar3 = array();
for($v=0; $v<=120; $v++){
$formmar1[] = $snm2mar1[$v];
$formmar2[] = $snm2mar2[$v];
$formmar3[] = $snm2mar3[$v];
}
$formar1 = $formmar1;
$formar2 = $formmar2;
$formar3 = $formmar3;

	$array_all_mar = array(array_filter($formar1), array_filter($formar2), array_filter($formar3));
	$countingmar = 0;
	while($countingmar <= 120){
	if(count(array_column($array_all_mar, $countingmar)) == 3){
	$marf2[] = round(array_sum(array_column($array_all_mar, $countingmar))/3);
	}
	else if(count(array_column($array_all_mar, $countingmar)) == 2){
	$marf2[] = round(array_sum(array_column($array_all_mar, $countingmar))/2);
	}
	else if(count(array_column($array_all_mar, $countingmar)) == 1){
	$marf2[] = round(array_sum(array_column($array_all_mar, $countingmar))/1);
	}
	else{
	$marf2[] = round(array_sum(array_column($array_all_mar, $countingmar))/3);	
	}
	$countingmar++;
	}
	$marf = implode("-",array_filter($marf2));
	$marmx2 = explode("-",$marf);
	$marmx = max(explode("-",$marf));
	$stnameandscoreMar = array_combine($acmarkeys,$marmx2);
	$maxinallsub = $marmx;			
	}
		else if($su == 'PHE'){
		$resultmxbystunamephe1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='PHE' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephe1))
	{	
		$snm2phe1[] = $rsn['score'];
		$stin2phe[] = $rsn['student_name'];
	}
	$acphef = array_combine($stin2phe,$snm2phe1);
	$resultmxbystunamephe2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='PHE' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephe2))
	{	
		$snm2phe2[] = $rsn['score'];
	    $stin2phe2[] = $rsn['student_name'];
	}
	$acphes = array_combine($stin2phe2,$snm2phe2);
	$resultmxbystunamephe3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='PHE' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephe3))
	{	
		$snm2phe3[] = $rsn['score'];
		$stin2phe3[] = $rsn['student_name'];
	}
	$acphet = array_combine($stin2phe3,$snm2phe3);
	$arinall = array($acphef, $acphes, $acphet);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acphekeys = (array_keys($largest_arr));
	
$forphe1 = array();
$forphe2 = array();
$forphe3 = array();
for($v=0; $v<=120; $v++){
$forpphe1[] = $snm2phe1[$v];
$forpphe2[] = $snm2phe2[$v];
$forpphe3[] = $snm2phe3[$v];
}
$forphe1 = $forpphe1;
$forphe2 = $forpphe2;
$forphe3 = $forpphe3;

	$array_all_phe = array(array_filter($forphe1), array_filter($forphe2), array_filter($forphe3));
	$countingphe = 0;
	while($countingphe <= 120){
	if(count(array_column($array_all_phe, $countingphe)) == 3){
	$phef2[] = round(array_sum(array_column($array_all_phe, $countingphe))/3);
	}
	else if(count(array_column($array_all_phe, $countingphe)) == 2){
	$phef2[] = round(array_sum(array_column($array_all_phe, $countingphe))/2);
	}
	else if(count(array_column($array_all_phe, $countingphe)) == 1){
	$phef2[] = round(array_sum(array_column($array_all_phe, $countingphe))/1);
	}
	else{
	$phef2[] = round(array_sum(array_column($array_all_phe, $countingphe))/3);	
	}
	$countingphe++;
	}
	$phef = implode("-",array_filter($phef2));
	$phemx2 = explode("-",$phef);
	$phemx = max(explode("-",$phef));
	$stnameandscorePhe = array_combine($acphekeys,$phemx2);
	$maxinallsub = $phemx;			
	}
	
	else if($su == 'Phonics'){
		$resultmxbystunamepho1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Phonics' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamepho1))
	{	
		$snm2pho1[] = $rsn['score'];
		$stin2pho[] = $rsn['student_name'];
	}
	$acphof = array_combine($stin2pho,$snm2pho1);
	$resultmxbystunamepho2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Phonics' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamepho2))
	{	
		$snm2pho2[] = $rsn['score'];
	    $stin2pho2[] = $rsn['student_name'];
	}
	$acphos = array_combine($stin2pho2,$snm2pho2);
	$resultmxbystunamepho3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Phonics' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamepho3))
	{	
		$snm2pho3[] = $rsn['score'];
		$stin2pho3[] = $rsn['student_name'];
	}
	$acphot = array_combine($stin2pho3,$snm2pho3);
	$arinall = array($acphof, $acphos, $acphot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acphokeys = (array_keys($largest_arr));
	
$forpho1 = array();
$forpho2 = array();
$forpho3 = array();
for($v=0; $v<=120; $v++){
$forppho1[] = $snm2pho1[$v];
$forppho2[] = $snm2pho2[$v];
$forppho3[] = $snm2pho3[$v];
}
$forpho1 = $forppho1;
$forpho2 = $forppho2;
$forpho3 = $forppho3;

	$array_all_pho = array(array_filter($forpho1), array_filter($forpho2), array_filter($forpho3));
	$countingpho = 0;
	while($countingpho <= 120){
	if(count(array_column($array_all_pho, $countingpho)) == 3){
	$phof2[] = round(array_sum(array_column($array_all_pho, $countingpho))/3);
	}
	else if(count(array_column($array_all_pho, $countingpho)) == 2){
	$phof2[] = round(array_sum(array_column($array_all_pho, $countingpho))/2);
	}
	else if(count(array_column($array_all_pho, $countingpho)) == 1){
	$phof2[] = round(array_sum(array_column($array_all_pho, $countingpho))/1);
	}
	else{
	$phof2[] = round(array_sum(array_column($array_all_pho, $countingpho))/3);	
	}
	$countingpho++;
	}
	$phof = implode("-",array_filter($phof2));
	$phomx2 = explode("-",$phof);
	$phomx = max(explode("-",$phof));
	$stnameandscorePho = array_combine($acphokeys,$phomx2);
	$maxinallsub = $phomx;			
	}
	
	else if($su == 'Physics'){
		$resultmxbystunamephy1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Physics' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephy1))
	{	
		$snm2phy1[] = $rsn['score'];
		$stin2phy[] = $rsn['student_name'];
	}
	$acphyf = array_combine($stin2phy,$snm2phy1);
	$resultmxbystunamephy2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Physics' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephy2))
	{	
		$snm2phy2[] = $rsn['score'];
	    $stin2phy2[] = $rsn['student_name'];
	}
	$acphys = array_combine($stin2phy2,$snm2phy2);
	$resultmxbystunamephy3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Physics' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephy3))
	{	
		$snm2phy3[] = $rsn['score'];
		$stin2phy3[] = $rsn['student_name'];
	}
	$acphyt = array_combine($stin2phy3,$snm2phy3);
	$arinall = array($acphyf, $acphys, $acphyt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acphykeys = (array_keys($largest_arr));
	
$forphy1 = array();
$forphy2 = array();
$forphy3 = array();
for($v=0; $v<=120; $v++){
$forpphy1[] = $snm2phy1[$v];
$forpphy2[] = $snm2phy2[$v];
$forpphy3[] = $snm2phy3[$v];
}
$forphy1 = $forpphy1;
$forphy2 = $forpphy2;
$forphy3 = $forpphy3;

	$array_all_phy = array(array_filter($forphy1), array_filter($forphy2), array_filter($forphy3));
	$countingphy = 0;
	while($countingphy <= 120){
	if(count(array_column($array_all_phy, $countingphy)) == 3){
	$phyf2[] = round(array_sum(array_column($array_all_phy, $countingphy))/3);
	}
	else if(count(array_column($array_all_phy, $countingphy)) == 2){
	$phyf2[] = round(array_sum(array_column($array_all_phy, $countingphy))/2);
	}
	else if(count(array_column($array_all_phy, $countingphy)) == 1){
	$phyf2[] = round(array_sum(array_column($array_all_phy, $countingphy))/1);
	}
	else{
	$phyf2[] = round(array_sum(array_column($array_all_phy, $countingphy))/3);	
	}
	$countingphy++;
	}
	$phyf = implode("-",array_filter($phyf2));
	$phymx2 = explode("-",$phyf);
	$phymx = max(explode("-",$phyf));
	$stnameandscorePhy = array_combine($acphykeys,$phymx2);
	$maxinallsub = $phymx;			
	}
	else if($su == 'Social Studies'){
		$resultmxbystunamesoc1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Social Studies' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesoc1))
	{	
		$snm2soc1[] = $rsn['score'];
		$stin2soc[] = $rsn['student_name'];
	}
	$acsocf = array_combine($stin2soc,$snm2soc1);
	$resultmxbystunamesoc2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Social Studies' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesoc2))
	{	
		$snm2soc2[] = $rsn['score'];
	    $stin2soc2[] = $rsn['student_name'];
	}
	$acsocs = array_combine($stin2soc2,$snm2soc2);
	$resultmxbystunamesoc3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Social Studies' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesoc3))
	{	
		$snm2soc3[] = $rsn['score'];
		$stin2soc3[] = $rsn['student_name'];
	}
	$acsoct = array_combine($stin2soc3,$snm2soc3);
	$arinall = array($acsocf, $acsocs, $acsoct);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acsockeys = (array_keys($largest_arr));
	
$forsoc1 = array();
$forsoc2 = array();
$forsoc3 = array();
for($v=0; $v<=120; $v++){
$forssoc1[] = $snm2soc1[$v];
$forssoc2[] = $snm2soc2[$v];
$forssoc3[] = $snm2soc3[$v];
}
$forsoc1 = $forssoc1;
$forsoc2 = $forssoc2;
$forsoc3 = $forssoc3;

	$array_all_soc = array(array_filter($forsoc1), array_filter($forsoc2), array_filter($forsoc3));
	$countingsoc = 0;
	while($countingsoc <= 120){
	if(count(array_column($array_all_soc, $countingsoc)) == 3){
	$socf2[] = round(array_sum(array_column($array_all_soc, $countingsoc))/3);
	}
	else if(count(array_column($array_all_soc, $countingsoc)) == 2){
	$socf2[] = round(array_sum(array_column($array_all_soc, $countingsoc))/2);
	}
	else if(count(array_column($array_all_soc, $countingsoc)) == 1){
	$socf2[] = round(array_sum(array_column($array_all_soc, $countingsoc))/1);
	}
	else{
	$socf2[] = round(array_sum(array_column($array_all_soc, $countingsoc))/3);	
	}
	$countingsoc++;
	}
	$socf = implode("-",array_filter($socf2));
	$socmx2 = explode("-",$socf);
	$socmx = max(explode("-",$socf));
	$stnameandscoreSoc = array_combine($acsockeys,$socmx2);
	$maxinallsub = $socmx;			
	}
		else if($su == 'Sociology'){
		$resultmxbystunamesocio1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Sociology' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesocio1))
	{	
		$snm2socio1[] = $rsn['score'];
		$stin2socio[] = $rsn['student_name'];
	}
	$acsociof = array_combine($stin2socio,$snm2socio1);
	$resultmxbystunamesocio2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Sociology' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesocio2))
	{	
		$snm2socio2[] = $rsn['score'];
	    $stin2socio2[] = $rsn['student_name'];
	}
	$acsocios = array_combine($stin2socio2,$snm2socio2);
	$resultmxbystunamesocio3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Sociology' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesocio3))
	{	
		$snm2socio3[] = $rsn['score'];
		$stin2socio3[] = $rsn['student_name'];
	}
	$acsociot = array_combine($stin2socio3,$snm2socio3);
	$arinall = array($acsociof, $acsocios, $acsociot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acsociokeys = (array_keys($largest_arr));
	
$forsocio1 = array();
$forsocio2 = array();
$forsocio3 = array();
for($v=0; $v<=120; $v++){
$forssocio1[] = $snm2socio1[$v];
$forssocio2[] = $snm2socio2[$v];
$forssocio3[] = $snm2socio3[$v];
}
$forsocio1 = $forssocio1;
$forsocio2 = $forssocio2;
$forsocio3 = $forssocio3;

	$array_all_socio = array(array_filter($forsocio1), array_filter($forsocio2), array_filter($forsocio3));
	$countingsocio = 0;
	while($countingsocio <= 120){
	if(count(array_column($array_all_socio, $countingsocio)) == 3){
	$sociof2[] = round(array_sum(array_column($array_all_socio, $countingsocio))/3);
	}
	else if(count(array_column($array_all_socio, $countingsocio)) == 2){
	$sociof2[] = round(array_sum(array_column($array_all_socio, $countingsocio))/2);
	}
	else if(count(array_column($array_all_socio, $countingsocio)) == 1){
	$sociof2[] = round(array_sum(array_column($array_all_socio, $countingsocio))/1);
	}
	else{
	$sociof2[] = round(array_sum(array_column($array_all_socio, $countingsocio))/3);	
	}
	$countingsocio++;
	}
	$sociof = implode("-",array_filter($sociof2));
	$sociomx2 = explode("-",$sociof);
	$sociomx = max(explode("-",$sociof));
	$stnameandscoreSocio = array_combine($acsociokeys,$sociomx2);
	$maxinallsub = $sociomx;			
	}
	else if($su == 'TD'){
		$resultmxbystunametd1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='TD' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunametd1))
	{	
		$snm2td1[] = $rsn['score'];
		$stin2td[] = $rsn['student_name'];
	}
	$actdf = array_combine($stin2td,$snm2td1);
	$resultmxbystunametd2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='TD' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunametd2))
	{	
		$snm2td2[] = $rsn['score'];
	    $stin2td2[] = $rsn['student_name'];
	}
	$actds = array_combine($stin2td2,$snm2td2);
	$resultmxbystunametd3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='TD' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunametd3))
	{	
		$snm2td3[] = $rsn['score'];
		$stin2td3[] = $rsn['student_name'];
	}
	$actdt = array_combine($stin2td3,$snm2td3);
	$arinall = array($actdf, $actds, $actdt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$actdkeys = (array_keys($largest_arr));
	
$fortd1 = array();
$fortd2 = array();
$fortd3 = array();
for($v=0; $v<=120; $v++){
$forttd1[] = $snm2td1[$v];
$forttd2[] = $snm2td2[$v];
$forttd3[] = $snm2td3[$v];
}
$fortd1 = $forttd1;
$fortd2 = $forttd2;
$fortd3 = $forttd3;

	$array_all_td = array(array_filter($fortd1), array_filter($fortd2), array_filter($fortd3));
	$countingtd = 0;
	while($countingtd <= 120){
	if(count(array_column($array_all_td, $countingtd)) == 3){
	$tdf2[] = round(array_sum(array_column($array_all_td, $countingtd))/3);
	}
	else if(count(array_column($array_all_td, $countingtd)) == 2){
	$tdf2[] = round(array_sum(array_column($array_all_td, $countingtd))/2);
	}
	else if(count(array_column($array_all_td, $countingtd)) == 1){
	$tdf2[] = round(array_sum(array_column($array_all_td, $countingtd))/1);
	}
	else{
	$tdf2[] = round(array_sum(array_column($array_all_td, $countingtd))/3);	
	}
	$countingtd++;
	}
	$tdf = implode("-",array_filter($tdf2));
	$tdmx2 = explode("-",$tdf);
	$tdmx = max(explode("-",$tdf));
	$stnameandscoreTd = array_combine($actdkeys,$tdmx2);
	$maxinallsub = $tdmx;			
	}
	else if($su == 'VA'){
		$resultmxbystunameva1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='VA' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameva1))
	{	
		$snm2va1[] = $rsn['score'];
		$stin2va[] = $rsn['student_name'];
	}
	$acvaf = array_combine($stin2va,$snm2va1);
	$resultmxbystunameva2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='VA' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameva2))
	{	
		$snm2va2[] = $rsn['score'];
	    $stin2va2[] = $rsn['student_name'];
	}
	$acvas = array_combine($stin2va2,$snm2va2);
	$resultmxbystunameva3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='VA' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameva3))
	{	
		$snm2va3[] = $rsn['score'];
		$stin2va3[] = $rsn['student_name'];
	}
	$acvat = array_combine($stin2va3,$snm2va3);
	$arinall = array($acvaf, $acvas, $acvat);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acvakeys = (array_keys($largest_arr));
	
$forva1 = array();
$forva2 = array();
$forva3 = array();
for($v=0; $v<=120; $v++){
$forvva1[] = $snm2va1[$v];
$forvva2[] = $snm2va2[$v];
$forvva3[] = $snm2va3[$v];
}
$forva1 = $forvva1;
$forva2 = $forvva2;
$forva3 = $forvva3;

	$array_all_va = array(array_filter($forva1), array_filter($forva2), array_filter($forva3));
	$countingva = 0;
	while($countingva <= 120){
	if(count(array_column($array_all_va, $countingva)) == 3){
	$vaf2[] = round(array_sum(array_column($array_all_va, $countingva))/3);
	}
	else if(count(array_column($array_all_va, $countingva)) == 2){
	$vaf2[] = round(array_sum(array_column($array_all_va, $countingva))/2);
	}
	else if(count(array_column($array_all_va, $countingva)) == 1){
	$vaf2[] = round(array_sum(array_column($array_all_va, $countingva))/1);
	}
	else{
	$vaf2[] = round(array_sum(array_column($array_all_va, $countingva))/3);	
	}
	$countingva++;
	}
	$vaf = implode("-",array_filter($vaf2));
	$vamx2 = explode("-",$vaf);
	$vamx = max(explode("-",$vaf));
	$stnameandscoreVa = array_combine($acvakeys,$vamx2);
	$maxinallsub = $vamx;			
	}
	else if($su == 'Vocational Aptitude'){
		$resultmxbystunamevap1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Vocational Aptitude' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevap1))
	{	
		$snm2vap1[] = $rsn['score'];
		$stin2vap[] = $rsn['student_name'];
	}
	$acvapf = array_combine($stin2vap,$snm2vap1);
	$resultmxbystunamevap2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Vocational Aptitude' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevap2))
	{	
		$snm2vap2[] = $rsn['score'];
	    $stin2vap2[] = $rsn['student_name'];
	}
	$acvaps = array_combine($stin2vap2,$snm2vap2);
	$resultmxbystunamevap3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Vocational Aptitude' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevap3))
	{	
		$snm2vap3[] = $rsn['score'];
		$stin2vap3[] = $rsn['student_name'];
	}
	$acvapt = array_combine($stin2vap3,$snm2vap3);
	$arinall = array($acvapf, $acvaps, $acvapt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acvapkeys = (array_keys($largest_arr));
	//print_r($acvapkeys);
$forvap1 = array();
$forvap2 = array();
$forvap3 = array();
for($v=0; $v<=120; $v++){
$forvvap1[] = $snm2vap1[$v];
$forvvap2[] = $snm2vap2[$v];
$forvvap3[] = $snm2vap3[$v];
}
$forvap1 = $forvvap1;
$forvap2 = $forvvap2;
$forvap3 = $forvvap3;

	$array_all_vap = array(array_filter($forvap1), array_filter($forvap2), array_filter($forvap3));
	$countingvap = 0;
	while($countingvap <= 120){
	if(count(array_column($array_all_vap, $countingvap)) == 3){
	$vapf2[] = round(array_sum(array_column($array_all_vap, $countingvap))/3);
	}
	else if(count(array_column($array_all_vap, $countingvap)) == 2){
	$vapf2[] = round(array_sum(array_column($array_all_vap, $countingvap))/2);
	}
	else if(count(array_column($array_all_vap, $countingvap)) == 1){
	$vapf2[] = round(array_sum(array_column($array_all_vap, $countingvap))/1);
	}
	else{
	$vapf2[] = round(array_sum(array_column($array_all_vap, $countingvap))/3);	
	}
	$countingvap++;
	}
	$vapf = implode("-",array_filter($vapf2));
	//echo $vapf;
	$vapmx2 = explode("-",$vapf);
	$vapmx = max(explode("-",$vapf));
	$stnameandscoreVap = array_combine($acvapkeys,$vapmx2);
	$maxinallsub = $vapmx;			
	}
	else if($su == 'Yoruba'){
		$resultmxbystunameyor1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Yoruba' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameyor1))
	{	
		$snm2yor1[] = $rsn['score'];
		$stin2yor[] = $rsn['student_name'];
	}
	$acyorf = array_combine($stin2yor,$snm2yor1);
	$resultmxbystunameyor2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Yoruba' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameyor2))
	{	
		$snm2yor2[] = $rsn['score'];
	    $stin2yor2[] = $rsn['student_name'];
	}
	$acyors = array_combine($stin2yor2,$snm2yor2);
	$resultmxbystunameyor3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Yoruba' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameyor3))
	{	
		$snm2yor3[] = $rsn['score'];
		$stin2yor3[] = $rsn['student_name'];
	}
	$acyort = array_combine($stin2yor3,$snm2yor3);
	$arinall = array($acyorf, $acyors, $acyort);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acyorkeys = (array_keys($largest_arr));
	
$foryor1 = array();
$foryor2 = array();
$foryor3 = array();
for($v=0; $v<=120; $v++){
$foryyor1[] = $snm2yor1[$v];
$foryyor2[] = $snm2yor2[$v];
$foryyor3[] = $snm2yor3[$v];
}
$foryor1 = $foryyor1;
$foryor2 = $foryyor2;
$foryor3 = $foryyor3;

	$array_all_yor = array(array_filter($foryor1), array_filter($foryor2), array_filter($foryor3));
	$countingyor = 0;
	while($countingyor <= 120){
	if(count(array_column($array_all_yor, $countingyor)) == 3){
	$yorf2[] = round(array_sum(array_column($array_all_yor, $countingyor))/3);
	}
	else if(count(array_column($array_all_yor, $countingyor)) == 2){
	$yorf2[] = round(array_sum(array_column($array_all_yor, $countingyor))/2);
	}
	else if(count(array_column($array_all_yor, $countingyor)) == 1){
	$yorf2[] = round(array_sum(array_column($array_all_yor, $countingyor))/1);
	}
	else{
	$yorf2[] = round(array_sum(array_column($array_all_yor, $countingyor))/3);	
	}
	$countingyor++;
	}
	$yorf = implode("-",array_filter($yorf2));
	$yormx2 = explode("-",$yorf);
	$yormx = max(explode("-",$yorf));
	$stnameandscoreYor = array_combine($acyorkeys,$yormx2);
	$maxinallsub = $yormx;			
	}
	else if($su == 'Quantitative Reasoning'){
		$resultmxbystunameqr1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Quantitative Reasoning' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameqr1))
	{	
		$snm2qr1[] = $rsn['score'];
		$stin2qr[] = $rsn['student_name'];
	}
	$acqrf = array_combine($stin2qr,$snm2qr1);
	$resultmxbystunameqr2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Quantitative Reasoning' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameqr2))
	{	
		$snm2qr2[] = $rsn['score'];
	    $stin2qr2[] = $rsn['student_name'];
	}
	$acqrs = array_combine($stin2qr2,$snm2qr2);
	$resultmxbystunameqr3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Quantitative Reasoning' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameqr3))
	{	
		$snm2qr3[] = $rsn['score'];
		$stin2qr3[] = $rsn['student_name'];
	}
	$acqrt = array_combine($stin2qr3,$snm2qr3);
	$arinall = array($acqrf, $acqrs, $acqrt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acqrkeys = (array_keys($largest_arr));
	
$forqr1 = array();
$forqr2 = array();
$forqr3 = array();
for($v=0; $v<=120; $v++){
$forqqr1[] = $snm2qr1[$v];
$forqqr2[] = $snm2qr2[$v];
$forqqr3[] = $snm2qr3[$v];
}
$forqr1 = $forqqr1;
$forqr2 = $forqqr2;
$forqr3 = $forqqr3;

	$array_all_qr = array(array_filter($forqr1), array_filter($forqr2), array_filter($forqr3));
	$countingqr = 0;
	while($countingqr <= 120){
	if(count(array_column($array_all_qr, $countingqr)) == 3){
	$qrf2[] = round(array_sum(array_column($array_all_qr, $countingqr))/3);
	}
	else if(count(array_column($array_all_qr, $countingqr)) == 2){
	$qrf2[] = round(array_sum(array_column($array_all_qr, $countingqr))/2);
	}
	else if(count(array_column($array_all_qr, $countingqr)) == 1){
	$qrf2[] = round(array_sum(array_column($array_all_qr, $countingqr))/1);
	}
	else{
	$qrf2[] = round(array_sum(array_column($array_all_qr, $countingqr))/3);	
	}
	$countingqr++;
	}
	$qrf = implode("-",array_filter($qrf2));
	$qrmx2 = explode("-",$qrf);
	$qrmx = max(explode("-",$qrf));
	$stnameandscoreQr = array_combine($acqrkeys,$qrmx2);
	$maxinallsub = $qrmx;			
	}
		else if($su == 'Verbal Reasoning'){
		$resultmxbystunamevr1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Verbal Reasoning' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevr1))
	{	
		$snm2vr1[] = $rsn['score'];
		$stin2vr[] = $rsn['student_name'];
	}
	$acvrf = array_combine($stin2vr,$snm2vr1);
	$resultmxbystunamevr2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Verbal Reasoning' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevr2))
	{	
		$snm2vr2[] = $rsn['score'];
	    $stin2vr2[] = $rsn['student_name'];
	}
	$acvrs = array_combine($stin2vr2,$snm2vr2);
	$resultmxbystunamevr3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Verbal Reasoning' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevr3))
	{	
		$snm2vr3[] = $rsn['score'];
		$stin2vr3[] = $rsn['student_name'];
	}
	$acvrt = array_combine($stin2vr3,$snm2vr3);
	$arinall = array($acvrf, $acvrs, $acvrt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acvrkeys = (array_keys($largest_arr));
	
$forvr1 = array();
$forvr2 = array();
$forvr3 = array();
for($v=0; $v<=120; $v++){
$forvvr1[] = $snm2vr1[$v];
$forvvr2[] = $snm2vr2[$v];
$forvvr3[] = $snm2vr3[$v];
}
$forvr1 = $forvvr1;
$forvr2 = $forvvr2;
$forvr3 = $forvvr3;

	$array_all_vr = array(array_filter($forvr1), array_filter($forvr2), array_filter($forvr3));
	$countingvr = 0;
	while($countingvr <= 120){
	if(count(array_column($array_all_vr, $countingvr)) == 3){
	$vrf2[] = round(array_sum(array_column($array_all_vr, $countingvr))/3);
	}
	else if(count(array_column($array_all_vr, $countingvr)) == 2){
	$vrf2[] = round(array_sum(array_column($array_all_vr, $countingvr))/2);
	}
	else if(count(array_column($array_all_vr, $countingvr)) == 1){
	$vrf2[] = round(array_sum(array_column($array_all_vr, $countingvr))/1);
	}
	else{
	$vrf2[] = round(array_sum(array_column($array_all_vr, $countingvr))/3);	
	}
	$countingvr++;
	}
	$vrf = implode("-",array_filter($vrf2));
	$vrmx2 = explode("-",$vrf);
	$vrmx = max(explode("-",$vrf));
	$stnameandscoreVr = array_combine($acvrkeys,$vrmx2);
	$maxinallsub = $vrmx;			
	}

		else if($su == 'Geography'){
		$resultmxbystunamegeo1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Geography' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegeo1))
	{	
		$snm2geo1[] = $rsn['score'];
		$stin2geo[] = $rsn['student_name'];
	}
	$acgeof = array_combine($stin2geo,$snm2geo1);
	$resultmxbystunamegeo2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Geography' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegeo2))
	{	
		$snm2geo2[] = $rsn['score'];
	    $stin2geo2[] = $rsn['student_name'];
	}
	$acgeos = array_combine($stin2geo2,$snm2geo2);
	$resultmxbystunamegeo3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Geography' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegeo3))
	{	
		$snm2geo3[] = $rsn['score'];
		$stin2geo3[] = $rsn['student_name'];
	}
	$acgeot = array_combine($stin2geo3,$snm2geo3);
	$arinall = array($acgeof, $acgeos, $acgeot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acgeokeys = (array_keys($largest_arr));
	
$forgeo1 = array();
$forgeo2 = array();
$forgeo3 = array();
for($v=0; $v<=120; $v++){
$forggeo1[] = $snm2geo1[$v];
$forggeo2[] = $snm2geo2[$v];
$forggeo3[] = $snm2geo3[$v];
}
$forgeo1 = $forggeo1;
$forgeo2 = $forggeo2;
$forgeo3 = $forggeo3;
		
$array_all_geo = array(array_filter($forgeo1), array_filter($forgeo2), array_filter($forgeo3));
	$countinggeo = 0;
	while($countinggeo <= 120){
	if(count(array_column($array_all_geo, $countinggeo)) == 3){
	$geof2[] = round(array_sum(array_column($array_all_geo, $countinggeo))/3);
	}
	else if(count(array_column($array_all_geo, $countinggeo)) == 2){
	$geof2[] = round(array_sum(array_column($array_all_geo, $countinggeo))/2);
	}
	else if(count(array_column($array_all_geo, $countinggeo)) == 1){
	$geof2[] = round(array_sum(array_column($array_all_geo, $countinggeo))/1);
	}
	else{
	$geof2[] = round(array_sum(array_column($array_all_geo, $countinggeo))/3);	
	}
	$countinggeo++;
	}
	$geof = implode("-",array_filter($geof2));
	$geomx2 = explode("-",$geof);
	$geomx = max(explode("-",$geof));
	$stnameandscoreGeo = array_combine($acgeokeys,$geomx2);
	$maxinallsub = $geomx;			
	}
	
	elseif($su == 'Handwriting'){							
	$resultmxbystunamehw1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Handwriting' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehw1))
	{	
		$snm2hw1[] = $rsn['score'];
		$stin2hw[] = $rsn['student_name'];
	}
	$achwf = array_combine($stin2hw,$snm2hw1);
	$resultmxbystunamehw2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Handwriting' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehw2))
	{	
		$snm2hw2[] = $rsn['score'];
	    $stin2hw2[] = $rsn['student_name'];
	}
	$achws = array_combine($stin2hw2,$snm2hw2);
	$resultmxbystunamehw3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Handwriting' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehw3))
	{	
		$snm2hw3[] = $rsn['score'];
		$stin2hw3[] = $rsn['student_name'];
	}
	$achwt = array_combine($stin2hw3,$snm2hw3);
	$arinall = array($achwf, $achws, $achwt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$achwkeys = (array_keys($largest_arr));
	
$forhw1 = array();
for($v=0; $v<=120; $v++){
$forhhw1[] = $snm2hw1[$v];
}
$forhw1 = $forhhw1;

$forhw2 = array();
for($v=0; $v<=120; $v++){
$forhhw2[] = $snm2hw2[$v];
}
$forhw2 = $forhhw2;

$forhw3 = array();
for($v=0; $v<=120; $v++){
$forhhw3[] = $snm2hw3[$v];
}
$forhw3 = $forhhw3;

$array_all_hw = array(array_filter($forhw1), array_filter($forhw2), array_filter($forhw3));
	$countinghw = 0;
	while($countinghw <= 120){
	if(count(array_column($array_all_hw, $countinghw)) == 3){
	$hwf2[] = round(array_sum(array_column($array_all_hw, $countinghw))/3);
	}
	else if(count(array_column($array_all_hw, $countinghw)) == 2){
	$hwf2[] = round(array_sum(array_column($array_all_hw, $countinghw))/2);
	}
	else if(count(array_column($array_all_hw, $countinghw)) == 1){
	$hwf2[] = round(array_sum(array_column($array_all_hw, $countinghw))/1);
	}
	else{
	$hwf2[] = round(array_sum(array_column($array_all_hw, $countinghw))/3);	
	}
	$countinghw++;
	}
	$hwf = implode("-",array_filter($hwf2));
	$hwmx2 = explode("-",$hwf);
	$hwmx = max(explode("-",$hwf));
	$stnameandscoreHw = array_combine($achwkeys,$hwmx2);
	$maxinallsub = $hwmx;	
	}
		else{	
			$maxinallsub = "-";	
		}
	
						echo '<tr><td>'.$su.'</td><td>'.$ct.'</td><td>'.$ex.'</td><td>'.$tt.'</td><td>'.$dd.'</td><td>'.$cc.'</td><td>'.$av.'</td><td>'.$maxinallsub.'</td><td id="mytd">'.round($ccav).'</td><td>'.$grade.'</td><td>'.$tn.'</td><td style="text-align: left;">'.$re.'</td></tr>';	
							$counted++;
							$arrsubj2[] = $su;
							$ca2[] = $ct;
							$exam2[] = $ex;
							$fir2[] = $cc;
							$sec2[] = $dd;
							$thir2[] = $tt;
							$av2[] = $av;
							$ccav2[] = round($ccav);
							$grad2[] = $grade;
							$teacher2[] = $tn;
							$remark2[] = $re;
							$maxinallsub2[] = $maxinallsub;
							}
							
							$arrsubj = $arrsubj2;
							$caclass = $ca2;
							$examclass = $exam2;
							$fir = $fir2;
							$sec = $sec2;
							$thir = $thir2;
							$avv = $av2;
							$ccavv = $ccav2;
							$grad = $grad2;
							$teacher = $teacher2;
							$remark = $remark2;						
							$hssnoarm = $maxinallsub2;
	}				
	else{
		echo '<tr id="heading"><td>SUBJECT</td><td>CA</td><td>EXAM</td><td>TOTAL</td><td>GRADE</td><td>TEACHER\'S NAME</td><td>REMARK</td></tr>';	
		$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
							$grbnt = mysqli_query($db, "SELECT grade FROM gradeband WHERE score='".$row["score"]."'");
							while($rowgrbnt = mysqli_fetch_assoc($grbnt))
							{
							$grade2	= $rowgrbnt['grade'];
							}
							$grade = $grade2;
							
							$row2subject[] = $row["subject"];	
							$row2ca[] = $row["ca"];	
							$row2exam[] = $row["exam"];
							$row2score[] = $row["score"];
							$row2teacher_name[] = $row["teacher_name"];
							$row2remark[] = $row["remark"];
							$grad2[] = $grade;
								echo '<tr><td>'.$row["subject"].'</td><td>'.$row["ca"].'</td><td>'.$row["exam"].'</td><td>'.$row["score"].'</td><td>'.$grade.'</td><td>'.$row["teacher_name"].'</td><td style="text-align: left;">'.$row["remark"].'</td></tr>';	
							}	
							$arrsubj = $row2subject;	
							$caclass = $row2ca;	
							$examclass = $row2exam;
							$score = $row2score;
							$grad = $grad2;
							$teacher = $row2teacher_name;
							$remark = $row2remark;	
	}
	}

}
	
	else{
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
	if($term == "Third Term"){	
	$result1 = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	$sql2 = mysqli_query($db, "SELECT * FROM maxes where subjectname='$subject' AND classname='$class' AND yearname='$year' AND termname='$term' AND teachername='$tna' AND teacheridname='$tid' AND school='".$_SESSION["school"]."'");
					
						while($row1 = mysqli_fetch_assoc($result1))
							{ 
								$firsubject[] = $row1['subject'];
								$firscore[] = $row1['score'];
							}
							$firsubject11 = $firsubject;
							$firscore11 = $firscore;
							$c = array_combine($firsubject11, $firscore11);
							ksort($c);
							$c = array_values($c);
							
	$result2 = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
						while($row2 = mysqli_fetch_assoc($result2))
							{ 
								$secsubject[] = $row2['subject'];
								$secscore[] = $row2['score'];
							}
							$secsubject22 = $secsubject;
							$secscore22 = $secscore;
							$d = array_combine($secsubject22, $secscore22);
							ksort($d);
							$d = array_values($d);
				
							
	$result3 = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
						while($row3 = mysqli_fetch_assoc($result3))
							{ 
								$thirsubject[] = $row3['subject'];
								$thirscore[] = $row3['score'];
							}
							$thirsubject33 = $thirsubject;
							$thirscore33 = $thirscore;
							$t = array_combine($thirsubject33, $thirscore33);
							ksort($t);
							$t = array_values($t);						
							
							$e = array_map(function () {
							return array_sum(func_get_args());
							},$c, $d, $t);
							ksort($e);
		
							
	echo '<tr id="heading"><td>SUBJECT</td><td>CA</td><td>EXAM</td><td>THIRD TERM</td><td>SECOND TERM</td><td>FIRST TERM</td><td>AV. OF THREE TERMS</td><td>CLASS HIGHEST</td><td>CLASS AVERAGE</td><td>GRADE</td><td>TEACHER\'S NAME</td><td>REMARK</td></tr>';	
	
	
	$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."' ORDER BY subject ASC");
	
	$recav = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
	$recavmax = mysqli_query($db, "SELECT MAX(score) AS agrmax FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
	while($rowcav = mysqli_fetch_assoc($recav))
							{
							$agrcavin[]	= $rowcav['score'];
							}
							$agrcav = array_filter($agrcavin);
							$agrcav2 = array_sum($agrcav);
	$numbagr = count(array_filter($agrcav));
	$agrcav3 = $agrcav2/$numbagr;
	
	$recav1 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Basic Science' AND school='".$_SESSION["school"]."'");
	while($rowcav1 = mysqli_fetch_assoc($recav1))
							{
							$bascavin[]	= $rowcav1['score'];
							}
							$bascav = array_filter($bascavin);
							$bascav2 = array_sum($bascav);
	$numbbas = count(array_filter($bascav));
	$bascav3 = $bascav2/$numbbas;
	
	$recav2 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='English' AND school='".$_SESSION["school"]."'");
	$recav2max = mysqli_query($db, "SELECT MAX(score) AS engmax FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='English' AND school='".$_SESSION["school"]."'");
	while($rowcav2 = mysqli_fetch_assoc($recav2))
							{
							$engcavin[]	= $rowcav2['score'];
							}
							$engcav = array_filter($engcavin);
							$engcav2 = array_sum($engcav);
	$numbeng = count(array_filter($engcav));
	$engcav3 = round($engcav2/$numbeng);
	while($rowcav2max = mysqli_fetch_assoc($recav2max))
							{
							$engcavinmax[]	= $rowcav2max['engmax'];
							}
							$engcavmax = array_filter($engcavinmax);
							$engcav2max = array_sum($engcavmax);
	$numbengmax = count(array_filter($engcavmax));
	$engcav3max = $engcav2max/$numbengmax;
	//echo $engcav3max;
	
	$recav3 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Business Studies' AND school='".$_SESSION["school"]."'");
	while($rowcav3 = mysqli_fetch_assoc($recav3))
							{
							$buscavin[]	= $rowcav3['score'];
							}
							$buscav = array_filter($buscavin);
							$buscav2 = array_sum($buscav);
	$numbbus = count(array_filter($buscav));
	$buscav3 = round($buscav2/$numbbus);
	
	$recav4 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Catering' AND school='".$_SESSION["school"]."'");
	while($rowcav4 = mysqli_fetch_assoc($recav4))
							{
							$catcavin[]	= $rowcav4['score'];
							}
							$catcav = array_filter($catcavin);
							$catcav2 = array_sum($catcav);
	$numbcat = count(array_filter($catcav));
	$catcav3 = $catcav2/$numbcat;
	
	$recav5 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Civic Education' AND school='".$_SESSION["school"]."'");
	while($rowcav5 = mysqli_fetch_assoc($recav5))
							{
							$civcavin[]	= $rowcav5['score'];
							}
							$civcav = array_filter($civcavin);
							$civcav2 = array_sum($civcav);
	$numbciv = count(array_filter($civcav));
	$civcav3 = $civcav2/$numbciv;
	
	$recav6 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Crk' AND school='".$_SESSION["school"]."'");
	while($rowcav6 = mysqli_fetch_assoc($recav6))
							{
							$crkcavin[]	= $rowcav6['score'];
							}
							$crkcav = array_filter($crkcavin);
							$crkcav2 = array_sum($crkcav);
	$numbcrk = count(array_filter($crkcav));
	$crkcav3 = $crkcav2/$numbcrk;
	
	$recav7 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Food and Nutrition' AND school='".$_SESSION["school"]."'");
	while($rowcav7 = mysqli_fetch_assoc($recav7))
							{
							$foocavin[]	= $rowcav7['score'];
							}
							$foocav = array_filter($foocavin);
							$foocav2 = array_sum($foocav);
	$numbfoo = count(array_filter($foocav));
	$foocav3 = $foocav2/$numbfoo;
	
	$recav8 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='French' AND school='".$_SESSION["school"]."'");
	while($rowcav8 = mysqli_fetch_assoc($recav8))
							{
							$frecavin[]	= $rowcav8['score'];
							}
							$frecav = array_filter($frecavin);
							$frecav2 = array_sum($frecav);
	$numbfre = count(array_filter($frecav));
	$frecav3 = $frecav2/$numbfre;
	
	$recav9 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='ICT' AND school='".$_SESSION["school"]."'");
	while($rowcav9 = mysqli_fetch_assoc($recav9))
							{
							$ictcavin[]	= $rowcav9['score'];
							}
							$ictcav = array_filter($ictcavin);
							$ictcav2 = array_sum($ictcav);
	$numbict = count(array_filter($ictcav));
	$ictcav3 = $ictcav2/$numbict;
	
	$recav10 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Igbo' AND school='".$_SESSION["school"]."'");
	while($rowcav10 = mysqli_fetch_assoc($recav10))
							{
							$igbcavin[]	= $rowcav10['score'];
							}
							$igbcav = array_filter($igbcavin);
							$igbcav2 = array_sum($igbcav);
	$numbigb = count(array_filter($igbcav));
	$igbcav3 = $igbcav2/$numbigb;
	
	$recav11 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Mathematics' AND school='".$_SESSION["school"]."'");
	while($rowcav11 = mysqli_fetch_assoc($recav11))
							{
							$matcavin[]	= $rowcav11['score'];
							}
							$matcav = array_filter($matcavin);
							$matcav2 = array_sum($matcav);
	$numbmat = count(array_filter($matcav));
	$matcav3 = $matcav2/$numbmat;
	
	$recav12 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Music' AND school='".$_SESSION["school"]."'");
	while($rowcav12 = mysqli_fetch_assoc($recav12))
							{
							$muscavin[]	= $rowcav12['score'];
							}
							$muscav = array_filter($muscavin);
							$muscav2 = array_sum($muscav);
	$numbmus = count(array_filter($muscav));
	$muscav3 = $muscav2/$numbmus;
	
	$recav13 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='PHE' AND school='".$_SESSION["school"]."'");
	while($rowcav13 = mysqli_fetch_assoc($recav13))
							{
							$phecavin[]	= $rowcav13['score'];
							}
							$phecav = array_filter($phecavin);
							$phecav2 = array_sum($phecav);
	$numbphe = count(array_filter($phecav));
	$phecav3 = $phecav2/$numbphe;

	$recav14 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Social Studies' AND school='".$_SESSION["school"]."'");
	while($rowcav14 = mysqli_fetch_assoc($recav14))
							{
							$soccavin[]	= $rowcav14['score'];
							}
							$soccav = array_filter($soccavin);
							$soccav2 = array_sum($soccav);
	$numbsoc = count(array_filter($soccav));
	$soccav3 = $soccav2/$numbsoc;
	
	$recav15 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Biology' AND school='".$_SESSION["school"]."'");
	while($rowcav15 = mysqli_fetch_assoc($recav15))
							{
							$biocavin[]	= $rowcav15['score'];
							}
							$biocav = array_filter($biocavin);
							$biocav2 = array_sum($biocav);
	$numbbio = count(array_filter($biocav));
	$biocav3 = $biocav2/$numbbio;
	
	$recav16 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Chemistry' AND school='".$_SESSION["school"]."'");
	while($rowcav16 = mysqli_fetch_assoc($recav16))
							{
							$checavin[]	= $rowcav16['score'];
							}
							$checav = array_filter($checavin);
							$checav2 = array_sum($checav);
	$numbche = count(array_filter($checav));
	$checav3 = $checav2/$numbche;
	
	$recav17 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Economics' AND school='".$_SESSION["school"]."'");
	while($rowcav17 = mysqli_fetch_assoc($recav17))
							{
							$ecocavin[]	= $rowcav17['score'];
							}
							$ecocav = array_filter($ecocavin);
							$ecocav2 = array_sum($ecocav);
	$numbeco = count(array_filter($ecocav));
	$ecocav3 = $ecocav2/$numbeco;
	
	$recav18 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Government' AND school='".$_SESSION["school"]."'");
	while($rowcav18 = mysqli_fetch_assoc($recav18))
							{
							$govcavin[]	= $rowcav18['score'];
							}
							$govcav = array_filter($govcavin);
							$govcav2 = array_sum($govcav);
	$numbgov = count(array_filter($govcav));
	$govcav3 = $govcav2/$numbgov;
	
	$recav19 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='VA' AND school='".$_SESSION["school"]."'");
	while($rowcav19 = mysqli_fetch_assoc($recav19))
							{
							$vacavin[]	= $rowcav19['score'];
							}
							$vacav = array_filter($vacavin);
							$vacav2 = array_sum($vacav);
	$numbva = count(array_filter($vacav));
	$vacav3 = $vacav2/$numbva;
	
	$recav20 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='TD' AND school='".$_SESSION["school"]."'");
	while($rowcav20 = mysqli_fetch_assoc($recav20))
							{
							$tdcavin[]	= $rowcav20['score'];
							}
							$vacav = array_filter($tdcavin);
							$tdcav2 = array_sum($tdcav);
	$numbtd = count(array_filter($tdcav));
	$tdcav3 = $tdcav2/$numbtd;
	
	$recav21 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Sociology' AND school='".$_SESSION["school"]."'");
	while($rowcav21 = mysqli_fetch_assoc($recav21))
							{
							$socicavin[]	= $rowcav21['score'];
							}
							$socicav = array_filter($socicavin);
							$socicav2 = array_sum($socicav);
	$numbsoci = count(array_filter($socicav));
	$socicav3 = $socicav2/$numbsoci;
							
	$recav22 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Physics' AND school='".$_SESSION["school"]."'");
	while($rowcav22 = mysqli_fetch_assoc($recav22))
							{
							$phycavin[]	= $rowcav22['score'];
							}
							$phycav = array_filter($phycavin);
							$phycav2 = array_sum($phycav);
	$numbphy = count(array_filter($phycav));
	$phycav3 = $phycav2/$numbphy;
	
	$recav23 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Marketing' AND school='".$_SESSION["school"]."'");
	while($rowcav23 = mysqli_fetch_assoc($recav23))
							{
							$marcavin[]	= $rowcav23['score'];
							}
							$marcav = array_filter($marcavin);
							$marcav2 = array_sum($marcav);
	$numbmar = count(array_filter($marcav));
	$marcav3 = $marcav2/$numbmar;
	
	$recav24 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Lit in English' AND school='".$_SESSION["school"]."'");
	while($rowcav24 = mysqli_fetch_assoc($recav24))
							{
							$litcavin[]	= $rowcav24['score'];
							}
							$litcav = array_filter($litcavin);
							$litcav2 = array_sum($litcav);
	$numblit = count(array_filter($litcav));
	$litcav3 = $litcav2/$numblit;
	
	$recav25 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Yoruba' AND school='".$_SESSION["school"]."'");
	while($rowcav25 = mysqli_fetch_assoc($recav25))
							{
							$yorcavin[]	= $rowcav25['score'];
							}
							$yorcav = array_filter($yorcavin);
							$yorcav2 = array_sum($yorcav);
	$numbyor = count(array_filter($yorcav));
	$yorcav3 = $yorcav2/$numbyor;
	
	$recav26 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Quantitative Reasoning' AND school='".$_SESSION["school"]."'");
	while($rowcav26 = mysqli_fetch_assoc($recav26))
							{
							$qrcavin[]	= $rowcav26['score'];
							}
							$qrcav = array_filter($qrcavin);
							$qrcav2 = array_sum($qrcav);
	$numbqr = count(array_filter($qrcav));
	$qrcav3 = $qrcav2/$numbqr;
	
	$recav27 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Verbal Reasoning' AND school='".$_SESSION["school"]."'");
	while($rowcav27 = mysqli_fetch_assoc($recav27))
							{
							$vrcavin[]	= $rowcav27['score'];
							}
							$vrcav = array_filter($vrcavin);
							$vrcav2 = array_sum($vrcav);
	$numbvr = count(array_filter($vrcav));
	$vrcav3 = $vrcav2/$numbvr;
	
	$recav28 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Geography' AND school='".$_SESSION["school"]."'");
	$recavmax28 = mysqli_query($db, "SELECT MAX(score) AS agrmax FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Geography' AND school='".$_SESSION["school"]."'");
	while($rowcav28 = mysqli_fetch_assoc($recav28))
							{
							$geocavin[]	= $rowcav28['score'];
							}
							$geocav = array_filter($geocavin);
							$geocav2 = array_sum($geocav);
	$numbgeo = count(array_filter($geocav));
	$geocav3 = $geocav2/$numbgeo;
	
	$recav29 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Handwriting' AND school='".$_SESSION["school"]."'");
	while($rowcav29 = mysqli_fetch_assoc($recav29))
							{
							$hwcavin[]	= $rowcav29['score'];
							}
							$hwcav = array_filter($hwcavin);
							$hwcav2 = array_sum($hwcav);
	$numbhw = count(array_filter($hwcav));
	$hwcav3 = $hwcav2/$numbhw;
	
	$recav30 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Vocational Aptitude' AND school='".$_SESSION["school"]."'");
	while($rowcav30 = mysqli_fetch_assoc($recav30))
							{
							$vapcavin[]	= $rowcav30['score'];
							}
							$vapcav = array_filter($vapcavin);
							$vapcav2 = array_sum($vapcav);
	$numbvap = count(array_filter($vapcav));
	$vapcav3 = $vapcav2/$numbvap;
	
	$recav31 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Phonics' AND school='".$_SESSION["school"]."'");
	while($rowcav31 = mysqli_fetch_assoc($recav31))
							{
							$phocavin[]	= $rowcav31['score'];
							}
							$phocav = array_filter($phocavin);
							$phocav2 = array_sum($phocav);
	$numbpho = count(array_filter($phocav));
	$phocav3 = $phocav2/$numbpho;
	
	$recav32 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Islamic Religious Studies' AND school='".$_SESSION["school"]."'");
	while($rowcav32 = mysqli_fetch_assoc($recav32))
							{
							$irscavin[]	= $rowcav32['score'];
							}
							$irscav = array_filter($irscavin);
							$irscav2 = array_sum($irscav);
	$numbirs = count(array_filter($irscav));
	$irscav3 = $irscav2/$numbirs;
	
	$recav33 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Creative and Cultural Arts' AND school='".$_SESSION["school"]."'");
	while($rowcav33 = mysqli_fetch_assoc($recav33))
							{
							$ccacavin[]	= $rowcav33['score'];
							}
							$ccacav = array_filter($ccacavin);
							$ccacav2 = array_sum($ccacav);
	$numbcca = count(array_filter($ccacav));
	$ccacav3 = $ccacav2/$numbcca;
	
		$recav34 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='History' AND school='".$_SESSION["school"]."'");
	while($rowcav34 = mysqli_fetch_assoc($recav34))
							{
							$hiscavin[]	= $rowcav34['score'];
							}
							$hiscav = array_filter($hiscavin);
							$hiscav2 = array_sum($hiscav);
	$numbhis = count(array_filter($hiscav));
	$hiscav3 = $hiscav2/$numbhis;
	
	$recav35 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Hausa' AND school='".$_SESSION["school"]."'");
	while($rowcav35 = mysqli_fetch_assoc($recav35))
							{
							$haucavin[]	= $rowcav35['score'];
							}
							$haucav = array_filter($haucavin);
							$haucav2 = array_sum($haucav);
	$numbhau = count(array_filter($haucav));
	$haucav3 = $haucav2/$numbhau;
	
	$recav36 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Hausa' AND school='".$_SESSION["school"]."'");
	while($rowcav36 = mysqli_fetch_assoc($recav36))
							{
							$fincavin[]	= $rowcav36['score'];
							}
							$fincav = array_filter($fincavin);
							$fincav2 = array_sum($fincav);
	$numbfin = count(array_filter($fincav));
	$fincav3 = $fincav2/$numbfin;
	
	$engcount = 0;
	$counter = 0;
	$counted = 0;
	while($row = mysqli_fetch_assoc($result))
							{		
		$to = Array($c[$counted], $d[$counted], $t[$counted]);
		if(($t[$counted] == 0) AND ($c[$counted] != 0) AND ($d[$counted] != 0)){$avdiv = 2; $t[$counted] = "-";}
		elseif(($t[$counted] != 0) AND ($c[$counted] != 0) AND ($d[$counted] == 0)){$avdiv = 2; $d[$counted] = "-";}
		elseif(($t[$counted] != 0) AND ($c[$counted] == 0) AND ($d[$counted] != 0)){$avdiv = 2; $d[$counted] = "-";}
		elseif(($t[$counted] == 0) AND ($c[$counted] != 0) AND ($d[$counted] == 0)){$avdiv = 1; $t[$counted] = "-"; $d[$counted] = "-";}
		elseif(($t[$counted] == 0) AND ($c[$counted] == 0) AND ($d[$counted] != 0)){$avdiv = 1; $c[$counted] = "-"; $t[$counted] = "-";}
		elseif(($t[$counted] != 0) AND ($c[$counted] == 0) AND ($d[$counted] == 0)){$avdiv = 1; $c[$counted] = "-"; $d[$counted] = "-";}
		elseif(($t[$counted] != 0) AND ($c[$counted] != 0) AND ($d[$counted] != 0)){$avdiv = 3;}
		else{$avdiv = 3;}
		$to2 = array_sum($to);
		$av = round($to2/$avdiv);
								$cc = $c[$counted];
								$dd = $d[$counted];
								$tt = $t[$counted];
							
							$grbnt = mysqli_query($db, "SELECT grade FROM gradeband WHERE score='$av'");
							while($rowgrbnt = mysqli_fetch_assoc($grbnt))
							{
							$grade2	= $rowgrbnt['grade'];
							}
							$grade = $grade2;
								
								if($row["subject"] == "Agricultural Science"){$ccav = $agrcav3;}
								elseif($row["subject"] == "Basic Science"){$ccav = $bascav3;}
								elseif($row["subject"] == "English"){$ccav = $engcav3;}
								elseif($row["subject"] == "Business Studies"){$ccav = $buscav3;}
								elseif($row["subject"] == "Catering"){$ccav = $catcav3;}
								elseif($row["subject"] == "Civic Education"){$ccav = $civcav3;}
								elseif($row["subject"] == "Crk"){$ccav = $crkcav3;}
								elseif($row["subject"] == "Food and Nutrition"){$ccav = $foocav3;}
								elseif($row["subject"] == "ICT"){$ccav = $ictcav3;}
								elseif($row["subject"] == "French"){$ccav = $frecav3;}
								elseif($row["subject"] == "Igbo"){$ccav = $igbcav3;}
								elseif($row["subject"] == "Mathematics"){$ccav = $matcav3;}
								elseif($row["subject"] == "Music"){$ccav = $muscav3;}
								elseif($row["subject"] == "PHE"){$ccav = $phecav3;}
								elseif($row["subject"] == "Social Studies"){$ccav = $soccav3;}
								elseif($row["subject"] == "Biology"){$ccav = $biocav3;}
								elseif($row["subject"] == "Chemistry"){$ccav = $checav3;}
								elseif($row["subject"] == "Economics"){$ccav = $ecocav3;}
								elseif($row["subject"] == "Government"){$ccav = $govcav3;}
								elseif($row["subject"] == "VA"){$ccav = $vacav3;}
								elseif($row["subject"] == "TD"){$ccav = $tdcav3;}
								elseif($row["subject"] == "Sociology"){$ccav = $socicav3;}
								elseif($row["subject"] == "Marketing"){$ccav = $marcav3;}
								elseif($row["subject"] == "Physics"){$ccav = $phycav3;}
								elseif($row["subject"] == "Lit in English"){$ccav = $litcav3;}
								elseif($row["subject"] == "Yoruba"){$ccav = $yorcav3;}
								elseif($row["subject"] == "Quantitative Reasoning"){$ccav = $qrcav3;}
								elseif($row["subject"] == "Verbal Reasoning"){$ccav = $vrcav3;}
								elseif($row["subject"] == "Geography"){$ccav = $geocav3;}
								elseif($row["subject"] == "Handwriting"){$ccav = $hwcav3;}
								elseif($row["subject"] == "Vocational Aptitude"){$ccav = $vapcav3;}
								elseif($row["subject"] == "Phonics"){$ccav = $phocav3;}
								elseif($row["subject"] == "Islamic Religious Studies"){$ccav = $irscav3;}
								elseif($row["subject"] == "Creative and Cultural Arts"){$ccav = $ccacav3;}
								elseif($row["subject"] == "History"){$ccav = $hiscav3;}
								elseif($row["subject"] == "Hausa"){$ccav = $haucav3;}
								elseif($row["subject"] == "Financial Accounting"){$ccav = $fincav3;}
								elseif($ccav == ""){$ccav = "-";}
								else{$ccav = "-";}
								$su = $row["subject"];
								$tn = $row["teacher_name"];
								$re = $row["remark"];
								$ct = $row["ca"];
								$ex = $row["exam"];
	
	if($su == 'English'){							
	$resultmxbystunameeng1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='English' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeng1))
	{	
		$snm2eng1[] = $rsn['score'];
		$stin2eng[] = $rsn['student_name'];
	}
	$acengf = array_combine($stin2eng,$snm2eng1);
	$resultmxbystunameeng2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='English' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeng2))
	{	
		$snm2eng2[] = $rsn['score'];
	    $stin2eng2[] = $rsn['student_name'];
	}
	$acengs = array_combine($stin2eng2,$snm2eng2);
	$resultmxbystunameeng3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='English' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeng3))
	{	
		$snm2eng3[] = $rsn['score'];
		$stin2eng3[] = $rsn['student_name'];
	}
	$acengt = array_combine($stin2eng3,$snm2eng3);
	$arinall = array($acengf, $acengs, $acengt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acengkeys = (array_keys($largest_arr));
	
$foreng1 = array($snm2eng1[0], $snm2eng1[1], $snm2eng1[2], $snm2eng1[3], $snm2eng1[4], $snm2eng1[5], $snm2eng1[6], $snm2eng1[7], $snm2eng1[8], $snm2eng1[9], $snm2eng1[10], $snm2eng1[11], $snm2eng1[12], $snm2eng1[13], $snm2eng1[14], $snm2eng1[15], $snm2eng1[16], $snm2eng1[17], $snm2eng1[18], $snm2eng1[19], 
		  $snm2eng1[20], $snm2eng1[21], $snm2eng1[22], $snm2eng1[23], $snm2eng1[24], $snm2eng1[25], $snm2eng1[26], $snm2eng1[27], $snm2eng1[28], $snm2eng1[29], $snm2eng1[30], $snm2eng1[31], $snm2eng1[32], $snm2eng1[33], $snm2eng1[34], $snm2eng1[35], $snm2eng1[36], $snm2eng1[37], $snm2eng1[38], $snm2eng1[39], 
		  $snm2eng1[40], $snm2eng1[41], $snm2eng1[42], $snm2eng1[43], $snm2eng1[44], $snm2eng1[45], $snm2eng1[46], $snm2eng1[47], $snm2eng1[48], $snm2eng1[49], $snm2eng1[50], $snm2eng1[51], $snm2eng1[52], $snm2eng1[53], $snm2eng1[54], $snm2eng1[55], $snm2eng1[56], $snm2eng1[57], $snm2eng1[58], $snm2eng1[59], 
		  $snm2eng1[60], $snm2eng1[61], $snm2eng1[62], $snm2eng1[63], $snm2eng1[64], $snm2eng1[65], $snm2eng1[66], $snm2eng1[67], $snm2eng1[68], $snm2eng1[69], $snm2eng1[70], $snm2eng1[71], $snm2eng1[72], $snm2eng1[73], $snm2eng1[74], $snm2eng1[75], $snm2eng1[76], $snm2eng1[77], $snm2eng1[78], $snm2eng1[79], 
		  $snm2eng1[80], $snm2eng1[81], $snm2eng1[82], $snm2eng1[83], $snm2eng1[84], $snm2eng1[85], $snm2eng1[86], $snm2eng1[87], $snm2eng1[88], $snm2eng1[89], $snm2eng1[90], $snm2eng1[91], $snm2eng1[92], $snm2eng1[93], $snm2eng1[94], $snm2eng1[95], $snm2eng1[96], $snm2eng1[97], $snm2eng1[98], $snm2eng1[99], 
		  $snm2eng1[100], $snm2eng1[101], $snm2eng1[102], $snm2eng1[103], $snm2eng1[104], $snm2eng1[105], $snm2eng1[106], $snm2eng1[107], $snm2eng1[108], $snm2eng1[109], $snm2eng1[110], $snm2eng1[111], $snm2eng1[112], $snm2eng1[113], $snm2eng1[114], $snm2eng1[115], $snm2eng1[116], $snm2eng1[117], $snm2eng1[118], $snm2eng1[119],
		  $snm2eng1[120]);
$foreng2 = array($snm2eng2[0], $snm2eng2[1], $snm2eng2[2], $snm2eng2[3], $snm2eng2[4], $snm2eng2[5], $snm2eng2[6], $snm2eng2[7], $snm2eng2[8], $snm2eng2[9], $snm2eng2[10], $snm2eng2[11], $snm2eng2[12], $snm2eng2[13], $snm2eng2[14], $snm2eng2[15], $snm2eng2[16], $snm2eng2[17], $snm2eng2[18], $snm2eng2[19], 
		  $snm2eng2[20], $snm2eng2[21], $snm2eng2[22], $snm2eng2[23], $snm2eng2[24], $snm2eng2[25], $snm2eng2[26], $snm2eng2[27], $snm2eng2[28], $snm2eng2[29], $snm2eng2[30], $snm2eng2[31], $snm2eng2[32], $snm2eng2[33], $snm2eng2[34], $snm2eng2[35], $snm2eng2[36], $snm2eng2[37], $snm2eng2[38], $snm2eng2[39], 
		  $snm2eng2[40], $snm2eng2[41], $snm2eng2[42], $snm2eng2[43], $snm2eng2[44], $snm2eng2[45], $snm2eng2[46], $snm2eng2[47], $snm2eng2[48], $snm2eng2[49], $snm2eng2[50], $snm2eng2[51], $snm2eng2[52], $snm2eng2[53], $snm2eng2[54], $snm2eng2[55], $snm2eng2[56], $snm2eng2[57], $snm2eng2[58], $snm2eng2[59],
		  $snm2eng2[60], $snm2eng2[61], $snm2eng2[62], $snm2eng2[63], $snm2eng2[64], $snm2eng2[65], $snm2eng2[66], $snm2eng2[67], $snm2eng2[68], $snm2eng2[69], $snm2eng2[70], $snm2eng2[71], $snm2eng2[72], $snm2eng2[73], $snm2eng2[74], $snm2eng2[75], $snm2eng2[76], $snm2eng2[77], $snm2eng2[78], $snm2eng2[79],
		  $snm2eng2[80], $snm2eng2[81], $snm2eng2[82], $snm2eng2[83], $snm2eng2[84], $snm2eng2[85], $snm2eng2[86], $snm2eng2[87], $snm2eng2[88], $snm2eng2[89], $snm2eng2[90], $snm2eng2[91], $snm2eng2[92], $snm2eng2[93], $snm2eng2[94], $snm2eng2[95], $snm2eng2[96], $snm2eng2[97], $snm2eng2[98], $snm2eng2[99],
		   $snm2eng2[100], $snm2eng2[101], $snm2eng2[102], $snm2eng2[103], $snm2eng2[104], $snm2eng2[105], $snm2eng2[106], $snm2eng2[107], $snm2eng2[108], $snm2eng2[109], $snm2eng2[110], $snm2eng2[111], $snm2eng2[112], $snm2eng2[113], $snm2eng2[114], $snm2eng2[115], $snm2eng2[116], $snm2eng2[117], $snm2eng2[118], $snm2eng2[119],
		  $snm2eng2[120]);
$foreng3 = array($snm2eng3[0], $snm2eng3[1], $snm2eng3[2], $snm2eng3[3], $snm2eng3[4], $snm2eng3[5], $snm2eng3[6], $snm2eng3[7], $snm2eng3[8], $snm2eng3[9], $snm2eng3[10], $snm2eng3[11], $snm2eng3[12], $snm2eng3[13], $snm2eng3[14], $snm2eng3[15], $snm2eng3[16], $snm2eng3[17], $snm2eng3[18], $snm2eng3[19],
		  $snm2eng3[20], $snm2eng3[21], $snm2eng3[22], $snm2eng3[23], $snm2eng3[24], $snm2eng3[25], $snm2eng3[26], $snm2eng3[27], $snm2eng3[28], $snm2eng3[29], $snm2eng3[30], $snm2eng3[31], $snm2eng3[32], $snm2eng3[33], $snm2eng3[34], $snm2eng3[35], $snm2eng3[36], $snm2eng3[37], $snm2eng3[38], $snm2eng3[39],
		  $snm2eng3[40], $snm2eng3[41], $snm2eng3[42], $snm2eng3[43], $snm2eng3[44], $snm2eng3[45], $snm2eng3[46], $snm2eng3[47], $snm2eng3[48], $snm2eng3[49], $snm2eng3[50], $snm2eng3[51], $snm2eng3[52], $snm2eng3[53], $snm2eng3[54], $snm2eng3[55], $snm2eng3[56], $snm2eng3[57], $snm2eng3[58], $snm2eng3[59],
		  $snm2eng3[60], $snm2eng3[61], $snm2eng3[62], $snm2eng3[63], $snm2eng3[64], $snm2eng3[65], $snm2eng3[66], $snm2eng3[67], $snm2eng3[68], $snm2eng3[69], $snm2eng3[70], $snm2eng3[71], $snm2eng3[72], $snm2eng3[73], $snm2eng3[74], $snm2eng3[75], $snm2eng3[76], $snm2eng3[77], $snm2eng3[78], $snm2eng3[79],
		  $snm2eng3[80], $snm2eng3[81], $snm2eng3[82], $snm2eng3[83], $snm2eng3[84], $snm2eng3[85], $snm2eng3[86], $snm2eng3[87], $snm2eng3[88], $snm2eng3[89], $snm2eng3[90], $snm2eng3[91], $snm2eng3[92], $snm2eng3[93], $snm2eng3[94], $snm2eng3[95], $snm2eng3[96], $snm2eng3[97], $snm2eng3[98], $snm2eng3[99],
		  $snm2eng3[100], $snm2eng3[101], $snm2eng3[102], $snm2eng3[103], $snm2eng3[104], $snm2eng3[105], $snm2eng3[106], $snm2eng3[107], $snm2eng3[108], $snm2eng3[109], $snm2eng3[110], $snm2eng3[111], $snm2eng3[112], $snm2eng3[113], $snm2eng3[114], $snm2eng3[115], $snm2eng3[116], $snm2eng3[117], $snm2eng3[118], $snm2eng3[119],
		  $snm2eng3[120]);
$array_all_eng = array(array_filter($foreng1), array_filter($foreng2), array_filter($foreng3));
	$countingeng = 0;
	while($countingeng <= 120){
	if(count(array_column($array_all_eng, $countingeng)) == 3){
	$engf2[] = round(array_sum(array_column($array_all_eng, $countingeng))/3);
	}
	else if(count(array_column($array_all_eng, $countingeng)) == 2){
	$engf2[] = round(array_sum(array_column($array_all_eng, $countingeng))/2);
	}
	else if(count(array_column($array_all_eng, $countingeng)) == 1){
	$engf2[] = round(array_sum(array_column($array_all_eng, $countingeng))/1);
	}
	else{
	$engf2[] = round(array_sum(array_column($array_all_eng, $countingeng))/3);	
	}
	$countingeng++;
	}
	$engf = implode("-",array_filter($engf2));
	$engmx2 = explode("-",$engf);
	$engmx = max(explode("-",$engf));
	$stnameandscoreEng = array_combine($acengkeys,$engmx2);
	//print_r($stnameandscoreEng);
	echo '<br>';
	$maxinallsub = $engmx;	
	}
	else if($su == 'Mathematics'){
	$resultmxbystunamemat1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Mathematics' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemat1))
	{	
		$snm2mat1[] = $rsn['score'];
		$stin2mat[] = $rsn['student_name'];
	}
	$acmatf = array_combine($stin2mat,$snm2mat1);
	$resultmxbystunamemat2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Mathematics' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemat2))
	{	
		$snm2mat2[] = $rsn['score'];
	    $stin2mat2[] = $rsn['student_name'];
	}
	$acmats = array_combine($stin2mat2,$snm2mat2);
	$resultmxbystunamemat3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Mathematics' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemat3))
	{	
		$snm2mat3[] = $rsn['score'];
		$stin2mat3[] = $rsn['student_name'];
	}
	$acmatt = array_combine($stin2mat3,$snm2mat3);
	$arinall = array($acmatf, $acmats, $acmatt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acmatkeys = (array_keys($largest_arr));
	
$format1 = 	array($snm2mat1[0], $snm2mat1[1], $snm2mat1[2], $snm2mat1[3], $snm2mat1[4], $snm2mat1[5], $snm2mat1[6], $snm2mat1[7], $snm2mat1[8], $snm2mat1[9], $snm2mat1[10], $snm2mat1[11], $snm2mat1[12], $snm2mat1[13], $snm2mat1[14], $snm2mat1[15], $snm2mat1[16], $snm2mat1[17], $snm2mat1[18], $snm2mat1[19], 
		  $snm2mat1[20], $snm2mat1[21], $snm2mat1[22], $snm2mat1[23], $snm2mat1[24], $snm2mat1[25], $snm2mat1[26], $snm2mat1[27], $snm2mat1[28], $snm2mat1[29], $snm2mat1[30], $snm2mat1[31], $snm2mat1[32], $snm2mat1[33], $snm2mat1[34], $snm2mat1[35], $snm2mat1[36], $snm2mat1[37], $snm2mat1[38], $snm2mat1[39], 
		  $snm2mat1[40], $snm2mat1[41], $snm2mat1[42], $snm2mat1[43], $snm2mat1[44], $snm2mat1[45], $snm2mat1[46], $snm2mat1[47], $snm2mat1[48], $snm2mat1[49], $snm2mat1[50], $snm2mat1[51], $snm2mat1[52], $snm2mat1[53], $snm2mat1[54], $snm2mat1[55], $snm2mat1[56], $snm2mat1[57], $snm2mat1[58], $snm2mat1[59], 
		  $snm2mat1[60], $snm2mat1[61], $snm2mat1[62], $snm2mat1[63], $snm2mat1[64], $snm2mat1[65], $snm2mat1[66], $snm2mat1[67], $snm2mat1[68], $snm2mat1[69], $snm2mat1[70], $snm2mat1[71], $snm2mat1[72], $snm2mat1[73], $snm2mat1[74], $snm2mat1[75], $snm2mat1[76], $snm2mat1[77], $snm2mat1[78], $snm2mat1[79], 
		  $snm2mat1[80], $snm2mat1[81], $snm2mat1[82], $snm2mat1[83], $snm2mat1[84], $snm2mat1[85], $snm2mat1[86], $snm2mat1[87], $snm2mat1[88], $snm2mat1[89], $snm2mat1[90], $snm2mat1[91], $snm2mat1[92], $snm2mat1[93], $snm2mat1[94], $snm2mat1[95], $snm2mat1[96], $snm2mat1[97], $snm2mat1[98], $snm2mat1[99], 
		  $snm2mat1[100], $snm2mat1[101], $snm2mat1[102], $snm2mat1[103], $snm2mat1[104], $snm2mat1[105], $snm2mat1[106], $snm2mat1[107], $snm2mat1[108], $snm2mat1[109], $snm2mat1[110], $snm2mat1[111], $snm2mat1[112], $snm2mat1[113], $snm2mat1[114], $snm2mat1[115], $snm2mat1[116], $snm2mat1[117], $snm2mat1[118], $snm2mat1[119],
		  $snm2mat1[120]);
$format2 = 	array($snm2mat2[0], $snm2mat2[1], $snm2mat2[2], $snm2mat2[3], $snm2mat2[4], $snm2mat2[5], $snm2mat2[6], $snm2mat2[7], $snm2mat2[8], $snm2mat2[9], $snm2mat2[10], $snm2mat2[11], $snm2mat2[12], $snm2mat2[13], $snm2mat2[14], $snm2mat2[15], $snm2mat2[16], $snm2mat2[17], $snm2mat2[18], $snm2mat2[19], 
		  $snm2mat2[20], $snm2mat2[21], $snm2mat2[22], $snm2mat2[23], $snm2mat2[24], $snm2mat2[25], $snm2mat2[26], $snm2mat2[27], $snm2mat2[28], $snm2mat2[29], $snm2mat2[30], $snm2mat2[31], $snm2mat2[32], $snm2mat2[33], $snm2mat2[34], $snm2mat2[35], $snm2mat2[36], $snm2mat2[37], $snm2mat2[38], $snm2mat2[39], 
		  $snm2mat2[40], $snm2mat2[41], $snm2mat2[42], $snm2mat2[43], $snm2mat2[44], $snm2mat2[45], $snm2mat2[46], $snm2mat2[47], $snm2mat2[48], $snm2mat2[49], $snm2mat2[50], $snm2mat2[51], $snm2mat2[52], $snm2mat2[53], $snm2mat2[54], $snm2mat2[55], $snm2mat2[56], $snm2mat2[57], $snm2mat2[58], $snm2mat2[59],
		  $snm2mat2[60], $snm2mat2[61], $snm2mat2[62], $snm2mat2[63], $snm2mat2[64], $snm2mat2[65], $snm2mat2[66], $snm2mat2[67], $snm2mat2[68], $snm2mat2[69], $snm2mat2[70], $snm2mat2[71], $snm2mat2[72], $snm2mat2[73], $snm2mat2[74], $snm2mat2[75], $snm2mat2[76], $snm2mat2[77], $snm2mat2[78], $snm2mat2[79],
		  $snm2mat2[80], $snm2mat2[81], $snm2mat2[82], $snm2mat2[83], $snm2mat2[84], $snm2mat2[85], $snm2mat2[86], $snm2mat2[87], $snm2mat2[88], $snm2mat2[89], $snm2mat2[90], $snm2mat2[91], $snm2mat2[92], $snm2mat2[93], $snm2mat2[94], $snm2mat2[95], $snm2mat2[96], $snm2mat2[97], $snm2mat2[98], $snm2mat2[99],
		   $snm2mat2[100], $snm2mat2[101], $snm2mat2[102], $snm2mat2[103], $snm2mat2[104], $snm2mat2[105], $snm2mat2[106], $snm2mat2[107], $snm2mat2[108], $snm2mat2[109], $snm2mat2[110], $snm2mat2[111], $snm2mat2[112], $snm2mat2[113], $snm2mat2[114], $snm2mat2[115], $snm2mat2[116], $snm2mat2[117], $snm2mat2[118], $snm2mat2[119],
		  $snm2mat2[120]);
$format3 = 	array($snm2mat3[0], $snm2mat3[1], $snm2mat3[2], $snm2mat3[3], $snm2mat3[4], $snm2mat3[5], $snm2mat3[6], $snm2mat3[7], $snm2mat3[8], $snm2mat3[9], $snm2mat3[10], $snm2mat3[11], $snm2mat3[12], $snm2mat3[13], $snm2mat3[14], $snm2mat3[15], $snm2mat3[16], $snm2mat3[17], $snm2mat3[18], $snm2mat3[19],
		  $snm2mat3[20], $snm2mat3[21], $snm2mat3[22], $snm2mat3[23], $snm2mat3[24], $snm2mat3[25], $snm2mat3[26], $snm2mat3[27], $snm2mat3[28], $snm2mat3[29], $snm2mat3[30], $snm2mat3[31], $snm2mat3[32], $snm2mat3[33], $snm2mat3[34], $snm2mat3[35], $snm2mat3[36], $snm2mat3[37], $snm2mat3[38], $snm2mat3[39],
		  $snm2mat3[40], $snm2mat3[41], $snm2mat3[42], $snm2mat3[43], $snm2mat3[44], $snm2mat3[45], $snm2mat3[46], $snm2mat3[47], $snm2mat3[48], $snm2mat3[49], $snm2mat3[50], $snm2mat3[51], $snm2mat3[52], $snm2mat3[53], $snm2mat3[54], $snm2mat3[55], $snm2mat3[56], $snm2mat3[57], $snm2mat3[58], $snm2mat3[59],
		  $snm2mat3[60], $snm2mat3[61], $snm2mat3[62], $snm2mat3[63], $snm2mat3[64], $snm2mat3[65], $snm2mat3[66], $snm2mat3[67], $snm2mat3[68], $snm2mat3[69], $snm2mat3[70], $snm2mat3[71], $snm2mat3[72], $snm2mat3[73], $snm2mat3[74], $snm2mat3[75], $snm2mat3[76], $snm2mat3[77], $snm2mat3[78], $snm2mat3[79],
		  $snm2mat3[80], $snm2mat3[81], $snm2mat3[82], $snm2mat3[83], $snm2mat3[84], $snm2mat3[85], $snm2mat3[86], $snm2mat3[87], $snm2mat3[88], $snm2mat3[89], $snm2mat3[90], $snm2mat3[91], $snm2mat3[92], $snm2mat3[93], $snm2mat3[94], $snm2mat3[95], $snm2mat3[96], $snm2mat3[97], $snm2mat3[98], $snm2mat3[99],
		  $snm2mat3[100], $snm2mat3[101], $snm2mat3[102], $snm2mat3[103], $snm2mat3[104], $snm2mat3[105], $snm2mat3[106], $snm2mat3[107], $snm2mat3[108], $snm2mat3[109], $snm2mat3[110], $snm2mat3[111], $snm2mat3[112], $snm2mat3[113], $snm2mat3[114], $snm2mat3[115], $snm2mat3[116], $snm2mat3[117], $snm2mat3[118], $snm2mat3[119],
		  $snm2mat3[120]);	  
	$array_all_mat = array(array_filter($format1), array_filter($format2), array_filter($format3));
	$countingmat = 0;
	while($countingmat <= 120){
	if(count(array_column($array_all_mat, $countingmat)) == 3){
	$matf2[] = round(array_sum(array_column($array_all_mat, $countingmat))/3);
	}
	else if(count(array_column($array_all_mat, $countingmat)) == 2){
	$matf2[] = round(array_sum(array_column($array_all_mat, $countingmat))/2);
	}
	else if(count(array_column($array_all_mat, $countingmat)) == 1){
	$matf2[] = round(array_sum(array_column($array_all_mat, $countingmat))/1);
	}
	else{
	$matf2[] = round(array_sum(array_column($array_all_mat, $countingmat))/3);	
	}
	$countingmat++;
	}
	$matf = implode("-",array_filter($matf2));
	$matmx2 = explode("-",$matf);
	$matmx = max(explode("-",$matf));
	$stnameandscoreMat = array_combine($acmatkeys,$matmx2);
	//print_r($stnameandscoreMat);
	//echo '<br>';
	$maxinallsub = $matmx;		
	}
	
	else if($su == 'French'){
	$resultmxbystunamefre1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='French' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefre1))
	{	
		$snm2fre1[] = $rsn['score'];
		$stin2fre[] = $rsn['student_name'];
	}
	$acfref = array_combine($stin2fre,$snm2fre1);
	$resultmxbystunamefre2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='French' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefre2))
	{	
		$snm2fre2[] = $rsn['score'];
	    $stin2fre2[] = $rsn['student_name'];
	}
	$acfres = array_combine($stin2fre2,$snm2fre2);
	$resultmxbystunamefre3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='French' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefre3))
	{	
		$snm2fre3[] = $rsn['score'];
		$stin2fre3[] = $rsn['student_name'];
	}
	$acfret = array_combine($stin2fre3,$snm2fre3);
	$arinall = array($acfref, $acfres, $acfret);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acfrekeys = (array_keys($largest_arr));
$forfre1 = 	array($snm2fre1[0], $snm2fre1[1], $snm2fre1[2], $snm2fre1[3], $snm2fre1[4], $snm2fre1[5], $snm2fre1[6], $snm2fre1[7], $snm2fre1[8], $snm2fre1[9], $snm2fre1[10], $snm2fre1[11], $snm2fre1[12], $snm2fre1[13], $snm2fre1[14], $snm2fre1[15], $snm2fre1[16], $snm2fre1[17], $snm2fre1[18], $snm2fre1[19], 
		  $snm2fre1[20], $snm2fre1[21], $snm2fre1[22], $snm2fre1[23], $snm2fre1[24], $snm2fre1[25], $snm2fre1[26], $snm2fre1[27], $snm2fre1[28], $snm2fre1[29], $snm2fre1[30], $snm2fre1[31], $snm2fre1[32], $snm2fre1[33], $snm2fre1[34], $snm2fre1[35], $snm2fre1[36], $snm2fre1[37], $snm2fre1[38], $snm2fre1[39], 
		  $snm2fre1[40], $snm2fre1[41], $snm2fre1[42], $snm2fre1[43], $snm2fre1[44], $snm2fre1[45], $snm2fre1[46], $snm2fre1[47], $snm2fre1[48], $snm2fre1[49], $snm2fre1[50], $snm2fre1[51], $snm2fre1[52], $snm2fre1[53], $snm2fre1[54], $snm2fre1[55], $snm2fre1[56], $snm2fre1[57], $snm2fre1[58], $snm2fre1[59], 
		  $snm2fre1[60], $snm2fre1[61], $snm2fre1[62], $snm2fre1[63], $snm2fre1[64], $snm2fre1[65], $snm2fre1[66], $snm2fre1[67], $snm2fre1[68], $snm2fre1[69], $snm2fre1[70], $snm2fre1[71], $snm2fre1[72], $snm2fre1[73], $snm2fre1[74], $snm2fre1[75], $snm2fre1[76], $snm2fre1[77], $snm2fre1[78], $snm2fre1[79], 
		  $snm2fre1[80], $snm2fre1[81], $snm2fre1[82], $snm2fre1[83], $snm2fre1[84], $snm2fre1[85], $snm2fre1[86], $snm2fre1[87], $snm2fre1[88], $snm2fre1[89], $snm2fre1[90], $snm2fre1[91], $snm2fre1[92], $snm2fre1[93], $snm2fre1[94], $snm2fre1[95], $snm2fre1[96], $snm2fre1[97], $snm2fre1[98], $snm2fre1[99], 
		  $snm2fre1[100], $snm2fre1[101], $snm2fre1[102], $snm2fre1[103], $snm2fre1[104], $snm2fre1[105], $snm2fre1[106], $snm2fre1[107], $snm2fre1[108], $snm2fre1[109], $snm2fre1[110], $snm2fre1[111], $snm2fre1[112], $snm2fre1[113], $snm2fre1[114], $snm2fre1[115], $snm2fre1[116], $snm2fre1[117], $snm2fre1[118], $snm2fre1[119],
		  $snm2fre1[120]);
$forfre2 = 	array($snm2fre2[0], $snm2fre2[1], $snm2fre2[2], $snm2fre2[3], $snm2fre2[4], $snm2fre2[5], $snm2fre2[6], $snm2fre2[7], $snm2fre2[8], $snm2fre2[9], $snm2fre2[10], $snm2fre2[11], $snm2fre2[12], $snm2fre2[13], $snm2fre2[14], $snm2fre2[15], $snm2fre2[16], $snm2fre2[17], $snm2fre2[18], $snm2fre2[19], 
		  $snm2fre2[20], $snm2fre2[21], $snm2fre2[22], $snm2fre2[23], $snm2fre2[24], $snm2fre2[25], $snm2fre2[26], $snm2fre2[27], $snm2fre2[28], $snm2fre2[29], $snm2fre2[30], $snm2fre2[31], $snm2fre2[32], $snm2fre2[33], $snm2fre2[34], $snm2fre2[35], $snm2fre2[36], $snm2fre2[37], $snm2fre2[38], $snm2fre2[39], 
		  $snm2fre2[40], $snm2fre2[41], $snm2fre2[42], $snm2fre2[43], $snm2fre2[44], $snm2fre2[45], $snm2fre2[46], $snm2fre2[47], $snm2fre2[48], $snm2fre2[49], $snm2fre2[50], $snm2fre2[51], $snm2fre2[52], $snm2fre2[53], $snm2fre2[54], $snm2fre2[55], $snm2fre2[56], $snm2fre2[57], $snm2fre2[58], $snm2fre2[59],
		  $snm2fre2[60], $snm2fre2[61], $snm2fre2[62], $snm2fre2[63], $snm2fre2[64], $snm2fre2[65], $snm2fre2[66], $snm2fre2[67], $snm2fre2[68], $snm2fre2[69], $snm2fre2[70], $snm2fre2[71], $snm2fre2[72], $snm2fre2[73], $snm2fre2[74], $snm2fre2[75], $snm2fre2[76], $snm2fre2[77], $snm2fre2[78], $snm2fre2[79],
		  $snm2fre2[80], $snm2fre2[81], $snm2fre2[82], $snm2fre2[83], $snm2fre2[84], $snm2fre2[85], $snm2fre2[86], $snm2fre2[87], $snm2fre2[88], $snm2fre2[89], $snm2fre2[90], $snm2fre2[91], $snm2fre2[92], $snm2fre2[93], $snm2fre2[94], $snm2fre2[95], $snm2fre2[96], $snm2fre2[97], $snm2fre2[98], $snm2fre2[99],
		   $snm2fre2[100], $snm2fre2[101], $snm2fre2[102], $snm2fre2[103], $snm2fre2[104], $snm2fre2[105], $snm2fre2[106], $snm2fre2[107], $snm2fre2[108], $snm2fre2[109], $snm2fre2[110], $snm2fre2[111], $snm2fre2[112], $snm2fre2[113], $snm2fre2[114], $snm2fre2[115], $snm2fre2[116], $snm2fre2[117], $snm2fre2[118], $snm2fre2[119],
		  $snm2fre2[120]);
$forfre3 = 	array($snm2fre3[0], $snm2fre3[1], $snm2fre3[2], $snm2fre3[3], $snm2fre3[4], $snm2fre3[5], $snm2fre3[6], $snm2fre3[7], $snm2fre3[8], $snm2fre3[9], $snm2fre3[10], $snm2fre3[11], $snm2fre3[12], $snm2fre3[13], $snm2fre3[14], $snm2fre3[15], $snm2fre3[16], $snm2fre3[17], $snm2fre3[18], $snm2fre3[19],
		  $snm2fre3[20], $snm2fre3[21], $snm2fre3[22], $snm2fre3[23], $snm2fre3[24], $snm2fre3[25], $snm2fre3[26], $snm2fre3[27], $snm2fre3[28], $snm2fre3[29], $snm2fre3[30], $snm2fre3[31], $snm2fre3[32], $snm2fre3[33], $snm2fre3[34], $snm2fre3[35], $snm2fre3[36], $snm2fre3[37], $snm2fre3[38], $snm2fre3[39],
		  $snm2fre3[40], $snm2fre3[41], $snm2fre3[42], $snm2fre3[43], $snm2fre3[44], $snm2fre3[45], $snm2fre3[46], $snm2fre3[47], $snm2fre3[48], $snm2fre3[49], $snm2fre3[50], $snm2fre3[51], $snm2fre3[52], $snm2fre3[53], $snm2fre3[54], $snm2fre3[55], $snm2fre3[56], $snm2fre3[57], $snm2fre3[58], $snm2fre3[59],
		  $snm2fre3[60], $snm2fre3[61], $snm2fre3[62], $snm2fre3[63], $snm2fre3[64], $snm2fre3[65], $snm2fre3[66], $snm2fre3[67], $snm2fre3[68], $snm2fre3[69], $snm2fre3[70], $snm2fre3[71], $snm2fre3[72], $snm2fre3[73], $snm2fre3[74], $snm2fre3[75], $snm2fre3[76], $snm2fre3[77], $snm2fre3[78], $snm2fre3[79],
		  $snm2fre3[80], $snm2fre3[81], $snm2fre3[82], $snm2fre3[83], $snm2fre3[84], $snm2fre3[85], $snm2fre3[86], $snm2fre3[87], $snm2fre3[88], $snm2fre3[89], $snm2fre3[90], $snm2fre3[91], $snm2fre3[92], $snm2fre3[93], $snm2fre3[94], $snm2fre3[95], $snm2fre3[96], $snm2fre3[97], $snm2fre3[98], $snm2fre3[99],
		  $snm2fre3[100], $snm2fre3[101], $snm2fre3[102], $snm2fre3[103], $snm2fre3[104], $snm2fre3[105], $snm2fre3[106], $snm2fre3[107], $snm2fre3[108], $snm2fre3[109], $snm2fre3[110], $snm2fre3[111], $snm2fre3[112], $snm2fre3[113], $snm2fre3[114], $snm2fre3[115], $snm2fre3[116], $snm2fre3[117], $snm2fre3[118], $snm2fre3[119],
		  $snm2fre3[120]);	  
	$array_all_fre = array(array_filter($forfre1), array_filter($forfre2), array_filter($forfre3));
	$countingfre = 0;
	while($countingfre <= 120){
	if(count(array_column($array_all_fre, $countingfre)) == 3){
	$fref2[] = round(array_sum(array_column($array_all_fre, $countingfre))/3);
	}
	else if(count(array_column($array_all_fre, $countingfre)) == 2){
	$fref2[] = round(array_sum(array_column($array_all_fre, $countingfre))/2);
	}
	else if(count(array_column($array_all_fre, $countingfre)) == 1){
	$fref2[] = round(array_sum(array_column($array_all_fre, $countingfre))/1);
	}
	else{
	$fref2[] = round(array_sum(array_column($array_all_fre, $countingfre))/3);	
	}
	$countingfre++;
	}
	$fref = implode("-",array_filter($fref2));
	$fremx2 = explode("-",$fref);
	$fremx = max(explode("-",$fref));
	$stnameandscoreFre = array_combine($acfrekeys,$fremx2);
	//print_r($stnameandscoreFre);
	//echo '<br>';
	$maxinallsub = $fremx;		
	}
	
	else if($su == 'Agricultural Science'){
		$resultmxbystunameagr1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Agricultural Science' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameagr1))
	{	
		$snm2agr1[] = $rsn['score'];
		$stin2agr[] = $rsn['student_name'];
	}
	$acagrf = array_combine($stin2agr,$snm2agr1);
	$resultmxbystunameagr2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Agricultural Science' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameagr2))
	{	
		$snm2agr2[] = $rsn['score'];
	    $stin2agr2[] = $rsn['student_name'];
	}
	$acagrs = array_combine($stin2agr2,$snm2agr2);
	$resultmxbystunameagr3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Agricultural Science' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameagr3))
	{	
		$snm2agr3[] = $rsn['score'];
		$stin2agr3[] = $rsn['student_name'];
	}
	$acagrt = array_combine($stin2agr3,$snm2agr3);
	$arinall = array($acagrf, $acagrs, $acagrt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acagrkeys = (array_keys($largest_arr));
$foragr1 = 	array($snm2agr1[0], $snm2agr1[1], $snm2agr1[2], $snm2agr1[3], $snm2agr1[4], $snm2agr1[5], $snm2agr1[6], $snm2agr1[7], $snm2agr1[8], $snm2agr1[9], $snm2agr1[10], $snm2agr1[11], $snm2agr1[12], $snm2agr1[13], $snm2agr1[14], $snm2agr1[15], $snm2agr1[16], $snm2agr1[17], $snm2agr1[18], $snm2agr1[19], 
		  $snm2agr1[20], $snm2agr1[21], $snm2agr1[22], $snm2agr1[23], $snm2agr1[24], $snm2agr1[25], $snm2agr1[26], $snm2agr1[27], $snm2agr1[28], $snm2agr1[29], $snm2agr1[30], $snm2agr1[31], $snm2agr1[32], $snm2agr1[33], $snm2agr1[34], $snm2fre1[35], $snm2agr1[36], $snm2agr1[37], $snm2agr1[38], $snm2agr1[39], 
		  $snm2agr1[40], $snm2agr1[41], $snm2agr1[42], $snm2agr1[43], $snm2agr1[44], $snm2agr1[45], $snm2agr1[46], $snm2agr1[47], $snm2agr1[48], $snm2agr1[49], $snm2agr1[50], $snm2agr1[51], $snm2agr1[52], $snm2agr1[53], $snm2agr1[54], $snm2fre1[55], $snm2agr1[56], $snm2agr1[57], $snm2agr1[58], $snm2agr1[59], 
		  $snm2agr1[60], $snm2agr1[61], $snm2agr1[62], $snm2agr1[63], $snm2agr1[64], $snm2agr1[65], $snm2agr1[66], $snm2agr1[67], $snm2agr1[68], $snm2agr1[69], $snm2agr1[70], $snm2agr1[71], $snm2agr1[72], $snm2agr1[73], $snm2agr1[74], $snm2fre1[75], $snm2agr1[76], $snm2agr1[77], $snm2agr1[78], $snm2agr1[79], 
		  $snm2agr1[80], $snm2agr1[81], $snm2agr1[82], $snm2agr1[83], $snm2agr1[84], $snm2agr1[85], $snm2agr1[86], $snm2agr1[87], $snm2agr1[88], $snm2agr1[89], $snm2agr1[90], $snm2agr1[91], $snm2agr1[92], $snm2agr1[93], $snm2agr1[94], $snm2fre1[95], $snm2agr1[96], $snm2agr1[97], $snm2agr1[98], $snm2agr1[99], 
		  $snm2agr1[100], $snm2agr1[101], $snm2agr1[102], $snm2agr1[103], $snm2agr1[104], $snm2agr1[105], $snm2agr1[106], $snm2agr1[107], $snm2agr1[108], $snm2agr1[109], $snm2agr1[110], $snm2agr1[111], $snm2agr1[112], $snm2agr1[113], $snm2agr1[114], $snm2agr1[115], $snm2agr1[116], $snm2agr1[117], $snm2agr1[118], $snm2agr1[119],
		  $snm2agr1[120]);
$foragr2 = 	array($snm2agr2[0], $snm2agr2[1], $snm2agr2[2], $snm2agr2[3], $snm2agr2[4], $snm2agr2[5], $snm2agr2[6], $snm2agr2[7], $snm2agr2[8], $snm2agr2[9], $snm2agr2[10], $snm2agr2[11], $snm2agr2[12], $snm2agr2[13], $snm2agr2[14], $snm2agr2[15], $snm2agr2[16], $snm2agr2[17], $snm2agr2[18], $snm2agr2[19], 
		  $snm2agr2[20], $snm2agr2[21], $snm2agr2[22], $snm2agr2[23], $snm2agr2[24], $snm2agr2[25], $snm2agr2[26], $snm2agr2[27], $snm2agr2[28], $snm2agr2[29], $snm2agr2[30], $snm2agr2[31], $snm2agr2[32], $snm2agr2[33], $snm2agr2[34], $snm2agr2[35], $snm2agr2[36], $snm2agr2[37], $snm2agr2[38], $snm2agr2[39], 
		  $snm2agr2[40], $snm2agr2[41], $snm2agr2[42], $snm2agr2[43], $snm2fre2[44], $snm2agr2[45], $snm2agr2[46], $snm2agr2[47], $snm2agr2[48], $snm2agr2[49], $snm2agr2[50], $snm2agr2[51], $snm2agr2[52], $snm2agr2[53], $snm2agr2[54], $snm2agr2[55], $snm2agr2[56], $snm2agr2[57], $snm2agr2[58], $snm2agr2[59],
		  $snm2agr2[60], $snm2agr2[61], $snm2agr2[62], $snm2agr2[63], $snm2fre2[64], $snm2agr2[65], $snm2agr2[66], $snm2agr2[67], $snm2agr2[68], $snm2agr2[69], $snm2agr2[70], $snm2agr2[71], $snm2agr2[72], $snm2agr2[73], $snm2agr2[74], $snm2agr2[75], $snm2agr2[76], $snm2agr2[77], $snm2agr2[78], $snm2agr2[79],
		  $snm2agr2[80], $snm2agr2[81], $snm2agr2[82], $snm2agr2[83], $snm2fre2[84], $snm2agr2[85], $snm2agr2[86], $snm2agr2[87], $snm2agr2[88], $snm2agr2[89], $snm2agr2[90], $snm2agr2[91], $snm2agr2[92], $snm2agr2[93], $snm2agr2[94], $snm2agr2[95], $snm2agr2[96], $snm2agr2[97], $snm2agr2[98], $snm2agr2[99],
		   $snm2agr2[100], $snm2agr2[101], $snm2agr2[102], $snm2agr2[103], $snm2agr2[104], $snm2agr2[105], $snm2agr2[106], $snm2agr2[107], $snm2agr2[108], $snm2agr2[109], $snm2agr2[110], $snm2agr2[111], $snm2agr2[112], $snm2agr2[113], $snm2agr2[114], $snm2agr2[115], $snm2agr2[116], $snm2agr2[117], $snm2agr2[118], $snm2agr2[119],
		  $snm2agr2[120]);
$foragr3 = 	array($snm2agr3[0], $snm2agr3[1], $snm2agr3[2], $snm2agr3[3], $snm2agr3[4], $snm2agr3[5], $snm2agr3[6], $snm2agr3[7], $snm2agr3[8], $snm2agr3[9], $snm2agr3[10], $snm2agr3[11], $snm2agr3[12], $snm2agr3[13], $snm2agr3[14], $snm2agr3[15], $snm2agr3[16], $snm2agr3[17], $snm2agr3[18], $snm2agr3[19],
		  $snm2agr3[20], $snm2agr3[21], $snm2agr3[22], $snm2agr3[23], $snm2agr3[24], $snm2agr3[25], $snm2agr3[26], $snm2agr3[27], $snm2agr3[28], $snm2agr3[29], $snm2agr3[30], $snm2agr3[31], $snm2agr3[32], $snm2agr3[33], $snm2agr3[34], $snm2agr3[35], $snm2agr3[36], $snm2agr3[37], $snm2agr3[38], $snm2agr3[39], 
		  $snm2agr3[41], $snm2agr3[41], $snm2agr3[42], $snm2agr3[43], $snm2agr3[44], $snm2agr3[45], $snm2agr3[46], $snm2agr3[47], $snm2agr3[48], $snm2agr3[49], $snm2agr3[50], $snm2agr3[51], $snm2agr3[52], $snm2agr3[53], $snm2agr3[54], $snm2agr3[55], $snm2agr3[56], $snm2agr3[57], $snm2agr3[58], $snm2agr3[59],
		  $snm2agr3[60], $snm2agr3[61], $snm2agr3[62], $snm2agr3[63], $snm2agr3[64], $snm2agr3[65], $snm2agr3[66], $snm2agr3[67], $snm2agr3[68], $snm2agr3[69], $snm2agr3[70], $snm2agr3[71], $snm2agr3[72], $snm2agr3[73], $snm2agr3[74], $snm2agr3[75], $snm2agr3[76], $snm2agr3[77], $snm2agr3[78], $snm2agr3[79],
		  $snm2agr3[80], $snm2agr3[81], $snm2agr3[82], $snm2agr3[83], $snm2agr3[84], $snm2agr3[85], $snm2agr3[86], $snm2agr3[87], $snm2agr3[88], $snm2agr3[89], $snm2agr3[90], $snm2agr3[91], $snm2agr3[92], $snm2agr3[93], $snm2agr3[94], $snm2agr3[95], $snm2agr3[96], $snm2agr3[97], $snm2agr3[98], $snm2agr3[99],
		  $snm2agr3[100], $snm2agr3[101], $snm2agr3[102], $snm2agr3[103], $snm2agr3[104], $snm2agr3[105], $snm2agr3[106], $snm2agr3[107], $snm2agr3[108], $snm2agr3[109], $snm2agr3[110], $snm2agr3[111], $snm2agr3[112], $snm2agr3[113], $snm2agr3[114], $snm2agr3[115], $snm2agr3[116], $snm2agr3[117], $snm2agr3[118], $snm2agr3[119],
		  $snm2agr3[120]);	  
	$array_all_agr = array(array_filter($foragr1), array_filter($foragr2), array_filter($foragr3));
	$countingagr = 0;
	while($countingagr <= 120){
	if(count(array_column($array_all_agr, $countingagr)) == 3){
	$agrf2[] = round(array_sum(array_column($array_all_agr, $countingagr))/3);
	}
	else if(count(array_column($array_all_agr, $countingagr)) == 2){
	$agrf2[] = round(array_sum(array_column($array_all_agr, $countingagr))/2);
	}
	else if(count(array_column($array_all_agr, $countingagr)) == 1){
	$agrf2[] = round(array_sum(array_column($array_all_agr, $countingagr))/1);
	}
	else{
	$agrf2[] = round(array_sum(array_column($array_all_agr, $countingagr))/3);	
	}
	$countingagr++;
	}
	$agrf = implode("-",array_filter($agrf2));
	$agrmx2 = explode("-",$agrf);
	$agrmx = max(explode("-",$agrf));
	$stnameandscoreAgr = array_combine($acagrkeys,$agrmx2);
	//print_r($stnameandscoreAgr);
	//echo '<br>';
	$maxinallsub = $agrmx;	
	}
	else if($su == 'Basic Science'){
		$resultmxbystunamebas1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Basic Science' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebas1))
	{	
		$snm2bas1[] = $rsn['score'];
		$stin2bas[] = $rsn['student_name'];
	}
	$acbasf = array_combine($stin2bas,$snm2bas1);
	$resultmxbystunamebas2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Basic Science' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebas2))
	{	
		$snm2bas2[] = $rsn['score'];
	    $stin2bas2[] = $rsn['student_name'];
	}
	$acbass = array_combine($stin2bas2,$snm2bas2);
	$resultmxbystunamebas3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Basic Science' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebas3))
	{	
		$snm2bas3[] = $rsn['score'];
		$stin2bas3[] = $rsn['student_name'];
	}
	$acbast = array_combine($stin2bas3,$snm2bas3);
	$arinall = array($acbasf, $acbass, $acbast);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acbaskeys = (array_keys($largest_arr));
$forbas1 = 	array($snm2bas1[0], $snm2bas1[1], $snm2bas1[2], $snm2bas1[3], $snm2bas1[4], $snm2bas1[5], $snm2bas1[6], $snm2bas1[7], $snm2bas1[8], $snm2bas1[9], $snm2bas1[10], $snm2bas1[11], $snm2bas1[12], $snm2bas1[13], $snm2bas1[14], $snm2bas1[15], $snm2bas1[16], $snm2bas1[17], $snm2bas1[18], $snm2bas1[19], 
		  $snm2bas1[20], $snm2bas1[21], $snm2bas1[22], $snm2bas1[23], $snm2bas1[24], $snm2bas1[25], $snm2bas1[26], $snm2bas1[27], $snm2bas1[28], $snm2bas1[29], $snm2bas1[30], $snm2bas1[31], $snm2bas1[32], $snm2bas1[33], $snm2bas1[34], $snm2bas1[35], $snm2bas1[36], $snm2bas1[37], $snm2bas1[38], $snm2bas1[39], 
		  $snm2bas1[40], $snm2bas1[41], $snm2bas1[42], $snm2bas1[43], $snm2bas1[44], $snm2bas1[45], $snm2bas1[46], $snm2bas1[47], $snm2bas1[48], $snm2bas1[49], $snm2bas1[50], $snm2bas1[51], $snm2bas1[52], $snm2bas1[53], $snm2bas1[54], $snm2bas1[55], $snm2bas1[56], $snm2bas1[57], $snm2bas1[58], $snm2bas1[59], 
		  $snm2bas1[60], $snm2bas1[61], $snm2bas1[62], $snm2bas1[63], $snm2bas1[64], $snm2bas1[65], $snm2bas1[66], $snm2bas1[67], $snm2bas1[68], $snm2bas1[69], $snm2bas1[70], $snm2bas1[71], $snm2bas1[72], $snm2bas1[73], $snm2bas1[74], $snm2bas1[75], $snm2bas1[76], $snm2bas1[77], $snm2bas1[78], $snm2bas1[79], 
		  $snm2bas1[80], $snm2bas1[81], $snm2bas1[82], $snm2bas1[83], $snm2bas1[84], $snm2bas1[85], $snm2bas1[86], $snm2bas1[87], $snm2bas1[88], $snm2bas1[89], $snm2bas1[90], $snm2bas1[91], $snm2bas1[92], $snm2bas1[93], $snm2bas1[94], $snm2bas1[95], $snm2bas1[96], $snm2bas1[97], $snm2bas1[98], $snm2bas1[99], 
		  $snm2bas1[100], $snm2bas1[101], $snm2bas1[102], $snm2bas1[103], $snm2bas1[104], $snm2bas1[105], $snm2bas1[106], $snm2bas1[107], $snm2bas1[108], $snm2bas1[109], $snm2bas1[110], $snm2bas1[111], $snm2bas1[112], $snm2bas1[113], $snm2bas1[114], $snm2bas1[115], $snm2bas1[116], $snm2bas1[117], $snm2bas1[118], $snm2bas1[119], 
		  $snm2bas1[120]);
$foragr2 = 	array($snm2bas2[0], $snm2bas2[1], $snm2bas2[2], $snm2bas2[3], $snm2bas2[4], $snm2bas2[5], $snm2bas2[6], $snm2bas2[7], $snm2bas2[8], $snm2bas2[9], $snm2bas2[10], $snm2bas2[11], $snm2bas1[12], $snm2bas2[13], $snm2bas2[14], $snm2bas2[15], $snm2bas2[16], $snm2bas2[17], $snm2bas2[18], $snm2bas2[19], 
		  $snm2bas2[20], $snm2bas2[21], $snm2bas2[22], $snm2bas2[23], $snm2bas2[24], $snm2bas2[25], $snm2bas2[26], $snm2bas2[27], $snm2bas2[28], $snm2bas2[29], $snm2bas2[30], $snm2bas2[31], $snm2bas2[32], $snm2bas2[33], $snm2bas2[34], $snm2bas2[35], $snm2bas2[36], $snm2bas2[37], $snm2bas2[38], $snm2bas2[39], 
		  $snm2bas2[40], $snm2bas2[41], $snm2bas2[42], $snm2bas2[43], $snm2bas2[44], $snm2bas2[45], $snm2bas2[46], $snm2bas2[47], $snm2bas2[48], $snm2bas2[49], $snm2bas2[50], $snm2bas2[51], $snm2bas2[52], $snm2bas2[53], $snm2bas2[54], $snm2bas2[55], $snm2bas2[56], $snm2bas2[57], $snm2bas2[58], $snm2bas2[59], 
		  $snm2bas2[60], $snm2bas2[61], $snm2bas2[62], $snm2bas2[63], $snm2bas2[64], $snm2bas2[65], $snm2bas2[66], $snm2bas2[67], $snm2bas2[68], $snm2bas2[69], $snm2bas2[70], $snm2bas2[71], $snm2bas2[72], $snm2bas2[73], $snm2bas2[74], $snm2bas2[75], $snm2bas2[76], $snm2bas2[77], $snm2bas2[78], $snm2bas2[79], 
		  $snm2bas2[80], $snm2bas2[81], $snm2bas2[82], $snm2bas2[83], $snm2bas2[84], $snm2bas2[85], $snm2bas2[86], $snm2bas2[87], $snm2bas2[88], $snm2bas2[89], $snm2bas2[90], $snm2bas2[91], $snm2bas2[92], $snm2bas2[93], $snm2bas2[94], $snm2bas2[95], $snm2bas2[96], $snm2bas2[97], $snm2bas2[98], $snm2bas2[99], 
		  $snm2bas2[100], $snm2bas2[101], $snm2bas2[102], $snm2bas2[103], $snm2bas2[104], $snm2bas2[105], $snm2bas2[106], $snm2bas2[107], $snm2bas2[108], $snm2bas2[109], $snm2bas2[110], $snm2bas2[111], $snm2bas2[112], $snm2bas2[113], $snm2bas2[114], $snm2bas2[115], $snm2bas2[116], $snm2bas2[117], $snm2bas2[118], $snm2bas2[119], 
		  $snm2bas2[120]);
$foragr3 = 	array($snm2bas3[0], $snm2bas3[1], $snm2bas3[2], $snm2bas3[3], $snm2bas3[4], $snm2bas3[5], $snm2bas3[6], $snm2bas3[7], $snm2bas3[8], $snm2bas3[9], $snm2bas3[10], $snm2bas3[11], $snm2bas3[12], $snm2bas3[13], $snm2bas3[14], $snm2bas3[15], $snm2bas3[16], $snm2bas3[17], $snm2bas3[18], $snm2bas3[19],
		  $snm2bas3[20], $snm2bas3[21], $snm2bas3[22], $snm2bas3[23], $snm2bas3[24], $snm2bas3[25], $snm2bas3[26], $snm2bas3[27], $snm2bas3[28], $snm2bas3[29], $snm2bas3[30], $snm2bas3[31], $snm2bas3[32], $snm2bas3[33], $snm2bas3[34], $snm2bas3[35], $snm2bas3[36], $snm2bas3[37], $snm2bas3[38], $snm2bas3[39], 
		  $snm2bas3[40], $snm2bas3[41], $snm2bas3[42], $snm2bas3[43], $snm2bas3[44], $snm2bas3[45], $snm2bas3[46], $snm2bas3[47], $snm2bas3[48], $snm2bas3[49], $snm2bas3[50], $snm2bas3[51], $snm2bas3[52], $snm2bas3[53], $snm2bas3[54], $snm2bas3[55], $snm2bas3[56], $snm2bas3[57], $snm2bas3[58], $snm2bas3[69], 
		  $snm2bas3[60], $snm2bas3[61], $snm2bas3[62], $snm2bas3[63], $snm2bas3[64], $snm2bas3[65], $snm2bas3[66], $snm2bas3[67], $snm2bas3[68], $snm2bas3[69], $snm2bas3[70], $snm2bas3[71], $snm2bas3[72], $snm2bas3[73], $snm2bas3[74], $snm2bas3[75], $snm2bas3[76], $snm2bas3[77], $snm2bas3[78], $snm2bas3[79], 
		  $snm2bas3[80], $snm2bas3[81], $snm2bas3[82], $snm2bas3[83], $snm2bas3[84], $snm2bas3[85], $snm2bas3[86], $snm2bas3[87], $snm2bas3[88], $snm2bas3[89], $snm2bas3[90], $snm2bas3[91], $snm2bas3[92], $snm2bas3[93], $snm2bas3[94], $snm2bas3[95], $snm2bas3[96], $snm2bas3[97], $snm2bas3[98], $snm2bas3[99], 
		  $snm2bas3[100], $snm2bas3[101], $snm2bas3[102], $snm2bas3[103], $snm2bas3[104], $snm2bas3[105], $snm2bas3[106], $snm2bas3[107], $snm2bas3[108], $snm2bas3[109], $snm2bas3[110], $snm2bas3[111], $snm2bas3[112], $snm2bas3[113], $snm2bas3[114], $snm2bas3[115], $snm2bas3[116], $snm2bas3[117], $snm2bas3[118], $snm2bas3[119], 
		  $snm2bas3[120]);	  
	$array_all_bas = array(array_filter($forbas1), array_filter($forbas2), array_filter($forbas3));
	$countingbas = 0;
	while($countingbas <= 120){
	if(count(array_column($array_all_bas, $countingbas)) == 3){
	$basf2[] = round(array_sum(array_column($array_all_bas, $countingbas))/3);
	}
	else if(count(array_column($array_all_bas, $countingbas)) == 2){
	$basf2[] = round(array_sum(array_column($array_all_bas, $countingbas))/2);
	}
	else if(count(array_column($array_all_bas, $countingbas)) == 1){
	$basf2[] = round(array_sum(array_column($array_all_bas, $countingbas))/1);
	}
	else{
	$basf2[] = round(array_sum(array_column($array_all_bas, $countingbas))/3);	
	}
	$countingbas++;
	}
	$basf = implode("-",array_filter($basf2));
	$basmx2 = explode("-",$basf);
	$basmx = max(explode("-",$basf));
	$stnameandscoreBas = array_combine($acbaskeys,$basmx2);
	$maxinallsub = $basmx;	
	}
		else if($su == 'Biology'){
		$resultmxbystunamebio1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Biology' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebio1))
	{	
		$snm2bio1[] = $rsn['score'];
		$stin2bio[] = $rsn['student_name'];
	}
	$acbiof = array_combine($stin2bio,$snm2bio1);
	$resultmxbystunamebio2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Biology' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebio2))
	{	
		$snm2bio2[] = $rsn['score'];
	    $stin2bio2[] = $rsn['student_name'];
	}
	$acbios = array_combine($stin2bio2,$snm2bio2);
	$resultmxbystunamebio3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Biology' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebio3))
	{	
		$snm2bio3[] = $rsn['score'];
		$stin2bio3[] = $rsn['student_name'];
	}
	$acbiot = array_combine($stin2bio3,$snm2bio3);
	$arinall = array($acbiof, $acbios, $acbiot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acbiokeys = (array_keys($largest_arr));
$forbio1 = 	array($snm2bio1[0], $snm2bio1[1], $snm2bio1[2], $snm2bio1[3], $snm2bio1[4], $snm2bio1[5], $snm2bio1[6], $snm2bio1[7], $snm2bio1[8], $snm2bio1[9], $snm2bio1[10], $snm2bio1[11], $snm2bio1[12], $snm2bio1[13], $snm2bio1[14], $snm2bio1[15], $snm2bio1[16], $snm2bio1[17], $snm2bio1[18], $snm2bio1[19], 
		$snm2bio1[20], $snm2bio1[21], $snm2bio1[22], $snm2bio1[23], $snm2bio1[24], $snm2bio1[25], $snm2bio1[26], $snm2bio1[27], $snm2bio1[28], $snm2bio1[29], $snm2bio1[30], $snm2bio1[31], $snm2bio1[32], $snm2bio1[33], $snm2bio1[34], $snm2bio1[35], $snm2bio1[36], $snm2bio1[37], $snm2bio1[38], $snm2bio1[39], 
		$snm2bio1[40], $snm2bio1[41], $snm2bio1[42], $snm2bio1[43], $snm2bio1[44], $snm2bio1[45], $snm2bio1[46], $snm2bio1[47], $snm2bio1[48], $snm2bio1[49], $snm2bio1[50], $snm2bio1[51], $snm2bio1[52], $snm2bio1[53], $snm2bio1[54], $snm2bio1[55], $snm2bio1[56], $snm2bio1[57], $snm2bio1[58], $snm2bio1[59], 
		$snm2bio1[60], $snm2bio1[61], $snm2bio1[62], $snm2bio1[63], $snm2bio1[64], $snm2bio1[65], $snm2bio1[66], $snm2bio1[67], $snm2bio1[68], $snm2bio1[69], $snm2bio1[70], $snm2bio1[71], $snm2bio1[72], $snm2bio1[73], $snm2bio1[74], $snm2bio1[75], $snm2bio1[76], $snm2bio1[77], $snm2bio1[78], $snm2bio1[79], 
		$snm2bio1[80], $snm2bio1[81], $snm2bio1[82], $snm2bio1[83], $snm2bio1[84], $snm2bio1[85], $snm2bio1[86], $snm2bio1[87], $snm2bio1[88], $snm2bio1[89], $snm2bio1[90], $snm2bio1[91], $snm2bio1[92], $snm2bio1[93], $snm2bio1[94], $snm2bio1[95], $snm2bio1[96], $snm2bio1[97], $snm2bio1[98], $snm2bio1[99], 
		$snm2bio1[100], $snm2bio1[101], $snm2bio1[102], $snm2bio1[103], $snm2bio1[104], $snm2bio1[105], $snm2bio1[106], $snm2bio1[107], $snm2bio1[108], $snm2bio1[109], $snm2bio1[110], $snm2bio1[111], $snm2bio1[112], $snm2bio1[113], $snm2bio1[114], $snm2bio1[115], $snm2bio1[116], $snm2bio1[117], $snm2bio1[118], $snm2bio1[119], 
		$snm2bio1[120]);
$forbio2 = 	array($snm2bio2[0], $snm2bio2[1], $snm2bio2[2], $snm2bio2[3], $snm2bio2[4], $snm2bio2[5], $snm2bio2[6], $snm2bio2[7], $snm2bio2[8], $snm2bio2[9], $snm2bio2[10], $snm2bio2[11], $snm2bio2[12], $snm2bio2[13], $snm2bio2[14], $snm2bio2[15], $snm2bio2[16], $snm2bio2[17], $snm2bio2[18], $snm2bio2[19], 
		$snm2bio2[20], $snm2bio2[21], $snm2bio2[22], $snm2bio2[23], $snm2bio2[24], $snm2bio2[25], $snm2bio2[26], $snm2bio2[27], $snm2bio2[28], $snm2bio2[29], $snm2bio2[30], $snm2bio2[31], $snm2bio2[32], $snm2bio2[33], $snm2bio2[34], $snm2bio2[35], $snm2bio2[36], $snm2bio2[37], $snm2bio2[38], $snm2bio2[39], 
		$snm2bio2[40], $snm2bio2[41], $snm2bio2[42], $snm2bio2[43], $snm2bio2[44], $snm2bio2[45], $snm2bio2[46], $snm2bio2[47], $snm2bio2[48], $snm2bio2[49], $snm2bio2[50], $snm2bio2[51], $snm2bio2[52], $snm2bio2[53], $snm2bio2[54], $snm2bio2[55], $snm2bio2[56], $snm2bio2[57], $snm2bio2[58], $snm2bio2[59], 
		$snm2bio2[60], $snm2bio2[61], $snm2bio2[62], $snm2bio2[63], $snm2bio2[64], $snm2bio2[65], $snm2bio2[66], $snm2bio2[67], $snm2bio2[68], $snm2bio2[69], $snm2bio2[70], $snm2bio2[71], $snm2bio2[72], $snm2bio2[73], $snm2bio2[74], $snm2bio2[75], $snm2bio2[76], $snm2bio2[77], $snm2bio2[78], $snm2bio2[79], 
		$snm2bio2[80], $snm2bio2[81], $snm2bio2[82], $snm2bio2[83], $snm2bio2[84], $snm2bio2[85], $snm2bio2[86], $snm2bio2[87], $snm2bio2[88], $snm2bio2[89], $snm2bio2[90], $snm2bio2[91], $snm2bio2[92], $snm2bio2[93], $snm2bio2[94], $snm2bio2[95], $snm2bio2[96], $snm2bio2[97], $snm2bio2[98], $snm2bio2[99], 
		$snm2bio2[100], $snm2bio2[101], $snm2bio2[102], $snm2bio2[103], $snm2bio2[104], $snm2bio2[105], $snm2bio2[106], $snm2bio2[107], $snm2bio2[108], $snm2bio2[109], $snm2bio2[110], $snm2bio2[111], $snm2bio2[112], $snm2bio2[113], $snm2bio2[114], $snm2bio2[115], $snm2bio2[116], $snm2bio2[117], $snm2bio2[118], $snm2bio2[119], 
		$snm2bio2[120]);
$forbio3 = 	array($snm2bio3[0], $snm2bio3[1], $snm2bio3[2], $snm2bio3[3], $snm2bio3[4], $snm2bio3[5], $snm2bio3[6], $snm2bio3[7], $snm2bio3[8], $snm2bio3[9], $snm2bio3[10], $snm2bio3[11], $snm2bio3[12], $snm2bio3[13], $snm2bio3[14], $snm2bio3[15], $snm2bio3[16], $snm2bio3[17], $snm2bio3[18], $snm2bio3[19], 
		$snm2bio3[20], $snm2bio3[21], $snm2bio3[22], $snm2bio3[23], $snm2bio3[24], $snm2bio3[25], $snm2bio3[26], $snm2bio3[27], $snm2bio3[28], $snm2bio3[29], $snm2bio3[30], $snm2bio3[31], $snm2bio3[32], $snm2bio3[33], $snm2bio3[34], $snm2bio3[35], $snm2bio3[36], $snm2bio3[37], $snm2bio3[38], $snm2bio3[39], 
		$snm2bio3[40], $snm2bio3[41], $snm2bio3[42], $snm2bio3[43], $snm2bio3[44], $snm2bio3[45], $snm2bio3[46], $snm2bio3[47], $snm2bio3[48], $snm2bio3[49], $snm2bio3[50], $snm2bio3[51], $snm2bio3[52], $snm2bio3[53], $snm2bio3[54], $snm2bio3[55], $snm2bio3[56], $snm2bio3[57], $snm2bio3[58], $snm2bio3[59], 
		$snm2bio3[60], $snm2bio3[61], $snm2bio3[62], $snm2bio3[63], $snm2bio3[64], $snm2bio3[65], $snm2bio3[66], $snm2bio3[67], $snm2bio3[68], $snm2bio3[69], $snm2bio3[70], $snm2bio3[71], $snm2bio3[72], $snm2bio3[73], $snm2bio3[74], $snm2bio3[75], $snm2bio3[76], $snm2bio3[77], $snm2bio3[78], $snm2bio3[79], 
		$snm2bio3[80], $snm2bio3[81], $snm2bio3[82], $snm2bio3[83], $snm2bio3[84], $snm2bio3[85], $snm2bio3[86], $snm2bio3[87], $snm2bio3[88], $snm2bio3[89], $snm2bio3[90], $snm2bio3[91], $snm2bio3[92], $snm2bio3[93], $snm2bio3[94], $snm2bio3[95], $snm2bio3[96], $snm2bio3[97], $snm2bio3[98], $snm2bio3[99], 
		$snm2bio3[100], $snm2bio3[101], $snm2bio3[102], $snm2bio3[103], $snm2bio3[104], $snm2bio3[105], $snm2bio3[106], $snm2bio3[107], $snm2bio3[108], $snm2bio3[109], $snm2bio3[110], $snm2bio3[111], $snm2bio3[112], $snm2bio3[113], $snm2bio3[114], $snm2bio3[115], $snm2bio3[116], $snm2bio3[117], $snm2bio3[118], $snm2bio3[119], 
		$snm2bio3[120]);
$array_all_bio = array(array_filter($forbio1), array_filter($forbio2), array_filter($forbio3));
	$countingbio = 0;
	while($countingbio <= 120){
	if(count(array_column($array_all_bio, $countingbio)) == 3){
	$biof2[] = round(array_sum(array_column($array_all_bio, $countingbio))/3);
	}
	else if(count(array_column($array_all_bio, $countingbio)) == 2){
	$biof2[] = round(array_sum(array_column($array_all_bio, $countingbio))/2);
	}
	else if(count(array_column($array_all_bio, $countingbio)) == 1){
	$biof2[] = round(array_sum(array_column($array_all_bio, $countingbio))/1);
	}
	else{
	$biof2[] = round(array_sum(array_column($array_all_bio, $countingbio))/3);	
	}
	$countingbio++;
	}
	$biof = implode("-",array_filter($biof2));
	$biomx2 = explode("-",$biof);
	$biomx = max(explode("-",$biof));
	$stnameandscoreBio = array_combine($acbiokeys,$biomx2);
	$maxinallsub = $biomx;				
	}
	else if($su == 'Business Studies'){
		$resultmxbystunamebus1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Business Studies' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebus1))
	{	
		$snm2bus1[] = $rsn['score'];
		$stin2bus[] = $rsn['student_name'];
	}
	$acbusf = array_combine($stin2bus,$snm2bus1);
	$resultmxbystunamebus2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Business Studies' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebus2))
	{	
		$snm2bus2[] = $rsn['score'];
	    $stin2bus2[] = $rsn['student_name'];
	}
	$acbuss = array_combine($stin2bus2,$snm2bus2);
	$resultmxbystunamebus3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Business Studies' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamebus3))
	{	
		$snm2bus3[] = $rsn['score'];
		$stin2bus3[] = $rsn['student_name'];
	}
	$acbust = array_combine($stin2bus3,$snm2bus3);
	$arinall = array($acbusf, $acbuss, $acbust);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acbuskeys = (array_keys($largest_arr));
$forbus1 = 	array($snm2bus1[0], $snm2bus1[1], $snm2bus1[2], $snm2bus1[3], $snm2bus1[4], $snm2bus1[5], $snm2bus1[6], $snm2bus1[7], $snm2bus1[8], $snm2bus1[9], $snm2bus1[10], $snm2bus1[11], $snm2bus1[12], $snm2bus1[13], $snm2bus1[14], $snm2bus1[15], $snm2bus1[16], $snm2bus1[17], $snm2bus1[18], $snm2bus1[19], 
		$snm2bus1[20], $snm2bus1[21], $snm2bus1[22], $snm2bus1[23], $snm2bus1[24], $snm2bus1[25], $snm2bus1[26], $snm2bus1[27], $snm2bus1[28], $snm2bus1[29], $snm2bus1[30], $snm2bus1[31], $snm2bus1[32], $snm2bus1[33], $snm2bus1[34], $snm2bus1[35], $snm2bus1[36], $snm2bus1[37], $snm2bus1[38], $snm2bus1[39], 
		$snm2bus1[40], $snm2bus1[41], $snm2bus1[42], $snm2bus1[43], $snm2bus1[44], $snm2bus1[45], $snm2bus1[46], $snm2bus1[47], $snm2bus1[48], $snm2bus1[49], $snm2bus1[50], $snm2bus1[51], $snm2bus1[52], $snm2bus1[53], $snm2bus1[54], $snm2bus1[55], $snm2bus1[56], $snm2bus1[57], $snm2bus1[58], $snm2bus1[59], 
		$snm2bus1[60], $snm2bio1[61], $snm2bus1[62], $snm2bus1[63], $snm2bus1[64], $snm2bus1[65], $snm2bus1[66], $snm2bus1[67], $snm2bus1[68], $snm2bus1[69], $snm2bus1[70], $snm2bus1[71], $snm2bus1[72], $snm2bus1[73], $snm2bus1[74], $snm2bus1[75], $snm2bus1[76], $snm2bus1[77], $snm2bus1[78], $snm2bus1[79], 
		$snm2bus1[80], $snm2bus1[81], $snm2bus1[82], $snm2bus1[83], $snm2bus1[84], $snm2bus1[85], $snm2bus1[86], $snm2bus1[87], $snm2bus1[88], $snm2bus1[89], $snm2bus1[90], $snm2bus1[91], $snm2bus1[92], $snm2bus1[93], $snm2bus1[94], $snm2bus1[95], $snm2bus1[96], $snm2bus1[97], $snm2bus1[98], $snm2bus1[99], 
		$snm2bus1[100], $snm2bus1[101], $snm2bus1[102], $snm2bus1[103], $snm2bus1[104], $snm2bus1[105], $snm2bus1[106], $snm2bus1[107], $snm2bus1[108], $snm2bus1[109], $snm2bus1[110], $snm2bus1[111], $snm2bus1[112], $snm2bus1[113], $snm2bus1[114], $snm2bus1[115], $snm2bus1[116], $snm2bus1[117], $snm2bus1[118], $snm2bus1[119], 
		$snm2bus1[120]);
$forbus2 = 	array($snm2bus2[0], $snm2bus2[1], $snm2bus2[2], $snm2bus2[3], $snm2bus2[4], $snm2bus2[5], $snm2bus2[6], $snm2bus2[7], $snm2bus2[8], $snm2bus2[9], $snm2bus2[10], $snm2bus2[11], $snm2bus2[12], $snm2bus2[13], $snm2bus2[14], $snm2bus2[15], $snm2bus2[16], $snm2bus2[17], $snm2bus2[18], $snm2bus2[19], 
		$snm2bus2[20], $snm2bus2[21], $snm2bus2[22], $snm2bus2[23], $snm2bus2[24], $snm2bus2[25], $snm2bus2[26], $snm2bus2[27], $snm2bus2[28], $snm2bus2[29], $snm2bus2[30], $snm2bus2[31], $snm2bus2[32], $snm2bus2[33], $snm2bus2[34], $snm2bus2[35], $snm2bus2[36], $snm2bus2[37], $snm2bus2[38], $snm2bus2[39], 
		$snm2bus2[40], $snm2bus2[41], $snm2bus2[42], $snm2bus2[43], $snm2bus2[44], $snm2bus2[45], $snm2bus2[46], $snm2bus2[47], $snm2bus2[48], $snm2bus2[49], $snm2bus2[50], $snm2bus2[51], $snm2bus2[52], $snm2bus2[53], $snm2bus2[54], $snm2bus2[55], $snm2bus2[56], $snm2bus2[57], $snm2bus2[58], $snm2bus2[59], 
		$snm2bus2[60], $snm2bus2[61], $snm2bus2[62], $snm2bus2[63], $snm2bus2[64], $snm2bus2[65], $snm2bus2[66], $snm2bus2[67], $snm2bus2[68], $snm2bus2[69], $snm2bus2[70], $snm2bus2[71], $snm2bus2[72], $snm2bus2[73], $snm2bus2[74], $snm2bus2[75], $snm2bus2[76], $snm2bus2[77], $snm2bus2[78], $snm2bus2[79], 
		$snm2bus2[80], $snm2bus2[81], $snm2bus2[82], $snm2bus2[83], $snm2bus2[84], $snm2bus2[85], $snm2bus2[86], $snm2bus2[87], $snm2bus2[88], $snm2bus2[89], $snm2bus2[90], $snm2bus2[91], $snm2bus2[92], $snm2bus2[93], $snm2bus2[94], $snm2bus2[95], $snm2bus2[96], $snm2bus2[97], $snm2bus2[98], $snm2bus2[99], 
		$snm2bus2[100], $snm2bus2[101], $snm2bus2[102], $snm2bus2[103], $snm2bus2[104], $snm2bus2[105], $snm2bus2[106], $snm2bus2[107], $snm2bus2[108], $snm2bus2[109], $snm2bus2[110], $snm2bus2[111], $snm2bus2[112], $snm2bus2[113], $snm2bus2[114], $snm2bus2[115], $snm2bus2[116], $snm2bus2[117], $snm2bus2[118], $snm2bus2[119], 
		$snm2bus2[120]);
$forbus3 = 	array($snm2bus3[0], $snm2bus3[1], $snm2bus3[2], $snm2bus3[3], $snm2bus3[4], $snm2bus3[5], $snm2bus3[6], $snm2bus3[7], $snm2bus3[8], $snm2bus3[9], $snm2bus3[10], $snm2bus3[11], $snm2bus3[12], $snm2bus3[13], $snm2bus3[14], $snm2bus3[15], $snm2bus3[16], $snm2bus3[17], $snm2bus3[18], $snm2bus3[19], 
		$snm2bus3[20], $snm2bus3[21], $snm2bus3[22], $snm2bus3[23], $snm2bus3[24], $snm2bus3[25], $snm2bus3[26], $snm2bus3[27], $snm2bus3[28], $snm2bus3[29], $snm2bus3[30], $snm2bus3[31], $snm2bus3[32], $snm2bus3[33], $snm2bus3[34], $snm2bus3[35], $snm2bus3[36], $snm2bus3[37], $snm2bus3[38], $snm2bus3[39], 
		$snm2bus3[40], $snm2bus3[41], $snm2bus3[42], $snm2bus3[43], $snm2bus3[44], $snm2bus3[45], $snm2bus3[46], $snm2bus3[47], $snm2bus3[48], $snm2bus3[49], $snm2bus3[50], $snm2bus3[51], $snm2bus3[52], $snm2bus3[53], $snm2bus3[54], $snm2bus3[55], $snm2bus3[56], $snm2bus3[57], $snm2bus3[58], $snm2bus3[59], 
		$snm2bus3[60], $snm2bus3[61], $snm2bus3[62], $snm2bus3[63], $snm2bus3[64], $snm2bus3[65], $snm2bus3[66], $snm2bus3[67], $snm2bus3[68], $snm2bus3[69], $snm2bus3[70], $snm2bus3[71], $snm2bus3[72], $snm2bus3[73], $snm2bus3[74], $snm2bus3[75], $snm2bus3[76], $snm2bus3[77], $snm2bus3[78], $snm2bus3[79], 
		$snm2bus3[80], $snm2bus3[81], $snm2bus3[82], $snm2bus3[83], $snm2bus3[84], $snm2bus3[85], $snm2bus3[86], $snm2bus3[87], $snm2bus3[88], $snm2bus3[89], $snm2bus3[90], $snm2bus3[91], $snm2bus3[92], $snm2bus3[93], $snm2bus3[94], $snm2bus3[95], $snm2bus3[96], $snm2bus3[97], $snm2bus3[98], $snm2bus3[99], 
		$snm2bus3[100], $snm2bus3[101], $snm2bus3[102], $snm2bus3[103], $snm2bus3[104], $snm2bus3[105], $snm2bus3[106], $snm2bus3[107], $snm2bus3[108], $snm2bus3[109], $snm2bus3[110], $snm2bus3[111], $snm2bus3[112], $snm2bus3[113], $snm2bus3[114], $snm2bus3[115], $snm2bus3[116], $snm2bus3[117], $snm2bus3[118], $snm2bus3[119], 
		$snm2bus3[120]);
	$array_all_bus = array(array_filter($forbus1), array_filter($forbus2), array_filter($forbus3));
	$countingbus = 0;
	while($countingbus <= 120){
	if(count(array_column($array_all_bus, $countingbus)) == 3){
	$busf2[] = round(array_sum(array_column($array_all_bus, $countingbus))/3);
	}
	else if(count(array_column($array_all_bus, $countingbus)) == 2){
	$busf2[] = round(array_sum(array_column($array_all_bus, $countingbus))/2);
	}
	else if(count(array_column($array_all_bus, $countingbus)) == 1){
	$busf2[] = round(array_sum(array_column($array_all_bus, $countingbus))/1);
	}
	else{
	$busf2[] = round(array_sum(array_column($array_all_bus, $countingbus))/3);	
	}
	$countingbus++;
	}
	$busf = implode("-",array_filter($busf2));
	$busmx2 = explode("-",$busf);
	$busmx = max(explode("-",$busf));
	$stnameandscoreBus = array_combine($acbuskeys,$busmx2);
	$maxinallsub = $busmx;			
	}
	else if($su == 'Catering'){
		$resultmxbystunamecat1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Catering' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecat1))
	{	
		$snm2cat1[] = $rsn['score'];
		$stin2cat[] = $rsn['student_name'];
	}
	$accatf = array_combine($stin2cat,$snm2cat1);
	$resultmxbystunamecat2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Catering' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecat2))
	{	
		$snm2cat2[] = $rsn['score'];
	    $stin2cat2[] = $rsn['student_name'];
	}
	$accats = array_combine($stin2cat2,$snm2cat2);
	$resultmxbystunamecat3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Catering' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecat3))
	{	
		$snm2cat3[] = $rsn['score'];
		$stin2cat3[] = $rsn['student_name'];
	}
	$accatt = array_combine($stin2cat3,$snm2cat3);
	$arinall = array($accatf, $accats, $accatt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$accatkeys = (array_keys($largest_arr));
	
$forcat1 = array();
for($v=0; $v<=120; $v++){
$forccat1[] = $snm2cat1[$v];
}
$forcat1 = $forccat1;

$forcat2 = array();
for($v=0; $v<=120; $v++){
$forccat2[] = $snm2cat2[$v];
}
$forcat2 = $forccat2;

$forcat3 = array();
for($v=0; $v<=120; $v++){
$forccat3[] = $snm2cat3[$v];
}
$forcat3 = $forccat3;

	$array_all_cat = array(array_filter($forcat1), array_filter($forcat2), array_filter($forcat3));
	$countingcat = 0;
	while($countingcat <= 120){
	if(count(array_column($array_all_cat, $countingcat)) == 3){
	$catf2[] = round(array_sum(array_column($array_all_cat, $countingcat))/3);
	}
	else if(count(array_column($array_all_cat, $countingcat)) == 2){
	$catf2[] = round(array_sum(array_column($array_all_cat, $countingcat))/2);
	}
	else if(count(array_column($array_all_cat, $countingcat)) == 1){
	$catf2[] = round(array_sum(array_column($array_all_cat, $countingcat))/1);
	}
	else{
	$catf2[] = round(array_sum(array_column($array_all_cat, $countingcat))/3);	
	}
	$countingcat++;
	}
	$catf = implode("-",array_filter($catf2));
	$catmx2 = explode("-",$catf);
	$catmx = max(explode("-",$catf));
	$stnameandscoreCat = array_combine($accatkeys,$catmx2);
	$maxinallsub = $catmx;			
	}
	else if($su == 'Chemistry'){
		$resultmxbystunameche1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Chemistry' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameche1))
	{	
		$snm2che1[] = $rsn['score'];
		$stin2che[] = $rsn['student_name'];
	}
	$acchef = array_combine($stin2che,$snm2che1);
	$resultmxbystunameche2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Chemistry' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameche2))
	{	
		$snm2che2[] = $rsn['score'];
	    $stin2che2[] = $rsn['student_name'];
	}
	$acches = array_combine($stin2che2,$snm2che2);
	$resultmxbystunameche3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Chemistry' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameche3))
	{	
		$snm2che3[] = $rsn['score'];
		$stin2che3[] = $rsn['student_name'];
	}
	$acchet = array_combine($stin2che3,$snm2che3);
	$arinall = array($acchef, $acches, $acchet);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acchekeys = (array_keys($largest_arr));
	
$forche1 = array();
for($v=0; $v<=120; $v++){
$forcche1[] = $snm2che1[$v];
}
$forche1 = $forcche1;

$forche2 = array();
for($v=0; $v<=120; $v++){
$forcche2[] = $snm2che2[$v];
}
$forche2 = $forcche2;

$forche3 = array();
for($v=0; $v<=120; $v++){
$forcche3[] = $snm2che3[$v];
}
$forche3 = $forcche3;

	$array_all_che = array(array_filter($forche1), array_filter($forche2), array_filter($forche3));
	$countingche = 0;
	while($countingche <= 120){
	if(count(array_column($array_all_che, $countingche)) == 3){
	$chef2[] = round(array_sum(array_column($array_all_che, $countingche))/3);
	}
	else if(count(array_column($array_all_che, $countingche)) == 2){
	$chef2[] = round(array_sum(array_column($array_all_che, $countingche))/2);
	}
	else if(count(array_column($array_all_che, $countingche)) == 1){
	$chef2[] = round(array_sum(array_column($array_all_che, $countingche))/1);
	}
	else{
	$chef2[] = round(array_sum(array_column($array_all_che, $countingche))/3);	
	}
	$countingche++;
	}
	$chef = implode("-",array_filter($chef2));
	$chemx2 = explode("-",$chef);
	$chemx = max(explode("-",$chef));
	$stnameandscoreChe = array_combine($acchekeys,$chemx2);
	$maxinallsub = $chemx;			
	}
	else if($su == 'Civic Education'){
		$resultmxbystunameciv1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Civic Education' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameciv1))
	{	
		$snm2civ1[] = $rsn['score'];
		$stin2civ[] = $rsn['student_name'];
	}
	$accivf = array_combine($stin2civ,$snm2civ1);
	$resultmxbystunameciv2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Civic Education' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameciv2))
	{	
		$snm2civ2[] = $rsn['score'];
	    $stin2civ2[] = $rsn['student_name'];
	}
	$accivs = array_combine($stin2civ2,$snm2civ2);
	$resultmxbystunameciv3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Civic Education' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameciv3))
	{	
		$snm2civ3[] = $rsn['score'];
		$stin2civ3[] = $rsn['student_name'];
	}
	$accivt = array_combine($stin2civ3,$snm2civ3);
	$arinall = array($accivf, $accivs, $accivt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$accivkeys = (array_keys($largest_arr));
	
$forciv1 = array();
for($v=0; $v<=120; $v++){
$forcciv1[] = $snm2civ1[$v];
}
$forciv1 = $forcciv1;

$forciv2 = array();
for($v=0; $v<=120; $v++){
$forcciv2[] = $snm2civ2[$v];
}
$forciv2 = $forcciv2;

$forciv3 = array();
for($v=0; $v<=120; $v++){
$forcciv3[] = $snm2civ3[$v];
}
$forciv3 = $forcciv3;

	$array_all_civ = array(array_filter($forciv1), array_filter($forciv2), array_filter($forciv3));
	$countingciv = 0;
	while($countingciv <= 120){
	if(count(array_column($array_all_civ, $countingciv)) == 3){
	$civf2[] = round(array_sum(array_column($array_all_civ, $countingciv))/3);
	}
	else if(count(array_column($array_all_civ, $countingciv)) == 2){
	$civf2[] = round(array_sum(array_column($array_all_civ, $countingciv))/2);
	}
	else if(count(array_column($array_all_civ, $countingciv)) == 1){
	$civf2[] = round(array_sum(array_column($array_all_civ, $countingciv))/1);
	}
	else{
	$civf2[] = round(array_sum(array_column($array_all_civ, $countingciv))/3);	
	}
	$countingciv++;
	}
	$civf = implode("-",array_filter($civf2));
	$civmx2 = explode("-",$civf);
	$civmx = max(explode("-",$civf));
	$stnameandscoreCiv = array_combine($accivkeys,$civmx2);
	$maxinallsub = $civmx;			
	}
	
	else if($su == 'Creative and Cultural Arts'){
		$resultmxbystunamecca1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Creative and Cultural Arts' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecca1))
	{	
		$snm2cca1[] = $rsn['score'];
		$stin2cca[] = $rsn['student_name'];
	}
	$acccaf = array_combine($stin2cca,$snm2cca1);
	$resultmxbystunamecca2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Creative and Cultural Arts' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecca2))
	{	
		$snm2cca2[] = $rsn['score'];
	    $stin2cca2[] = $rsn['student_name'];
	}
	$acccas = array_combine($stin2cca2,$snm2cca2);
	$resultmxbystunamecca3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Creative and Cultural Arts Studies' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecca3))
	{	
		$snm2cca3[] = $rsn['score'];
		$stin2cca3[] = $rsn['student_name'];
	}
	$acccat = array_combine($stin2cca3,$snm2cca3);
	$arinall = array($acccaf, $acccas, $acccat);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acccakeys = (array_keys($largest_arr));
	
$forcca1 = array();
$forcca2 = array();
$forcca3 = array();
for($v=0; $v<=120; $v++){
$forccca1[] = $snm2cca1[$v];
$forccca2[] = $snm2cca2[$v];
$forccca3[] = $snm2cca3[$v];
}
$forcca1 = $forccca1;
$forcca2 = $forccca2;
$forcca3 = $forccca3;

	$array_all_cca = array(array_filter($forcca1), array_filter($forcca2), array_filter($forcca3));
	$countingcca = 0;
	while($countingcca <= 120){
	if(count(array_column($array_all_cca, $countingcca)) == 3){
	$ccaf2[] = round(array_sum(array_column($array_all_cca, $countingcca))/3);
	}
	else if(count(array_column($array_all_cca, $countingcca)) == 2){
	$ccaf2[] = round(array_sum(array_column($array_all_cca, $countingcca))/2);
	}
	else if(count(array_column($array_all_cca, $countingcca)) == 1){
	$ccaf2[] = round(array_sum(array_column($array_all_cca, $countingcca))/1);
	}
	else{
	$ccaf2[] = round(array_sum(array_column($array_all_cca, $countingcca))/3);	
	}
	$countingcca++;
	}
	$ccaf = implode("-",array_filter($ccaf2));
	$ccamx2 = explode("-",$ccaf);
	$ccamx = max(explode("-",$ccaf));
	$stnameandscoreCca = array_combine($acccakeys,$ccamx2);
	$maxinallsub = $ccamx;			
	}
	
		else if($su == 'CRK'){
		$resultmxbystunamecrk1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='CRK' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecrk1))
	{	
		$snm2crk1[] = $rsn['score'];
		$stin2crk[] = $rsn['student_name'];
	}
	$accrkf = array_combine($stin2crk,$snm2crk1);
	$resultmxbystunamecrk2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='CRK' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecrk2))
	{	
		$snm2crk2[] = $rsn['score'];
	    $stin2crk2[] = $rsn['student_name'];
	}
	$accrks = array_combine($stin2crk2,$snm2crk2);
	$resultmxbystunamecrk3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='CRK' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamecRK3))
	{	
		$snm2crk3[] = $rsn['score'];
		$stin2crk3[] = $rsn['student_name'];
	}
	$accrkt = array_combine($stin2crk3,$snm2crk3);
	$arinall = array($accrkf, $accrks, $accrkt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$accrkkeys = (array_keys($largest_arr));
	
$forcrk1 = array();
for($v=0; $v<=120; $v++){
$forccrk1[] = $snm2crk1[$v];
}
$forcrk1 = $forccrk1;

$forcrk2 = array();
for($v=0; $v<=120; $v++){
$forccrk2[] = $snm2crk2[$v];
}
$forcrk2 = $forccrk2;

$forcrk3 = array();
for($v=0; $v<=120; $v++){
$forccrk3[] = $snm2crk3[$v];
}
$forcrk3 = $forccrk3;

	$array_all_crk = array(array_filter($forcrk1), array_filter($forcrk2), array_filter($forcrk3));
	$countingcrk = 0;
	while($countingcrk <= 120){
	if(count(array_column($array_all_crk, $countingcrk)) == 3){
	$crkf2[] = round(array_sum(array_column($array_all_crk, $countingcrk))/3);
	}
	else if(count(array_column($array_all_crk, $countingcrk)) == 2){
	$crkf2[] = round(array_sum(array_column($array_all_crk, $countingcrk))/2);
	}
	else if(count(array_column($array_all_crk, $countingcrk)) == 1){
	$crkf2[] = round(array_sum(array_column($array_all_crk, $countingcrk))/1);
	}
	else{
	$crkf2[] = round(array_sum(array_column($array_all_crk, $countingcrk))/3);	
	}
	$countingcrk++;
	}
	$crkf = implode("-",array_filter($crkf2));
	$crkmx2 = explode("-",$crkf);
	$crkmx = max(explode("-",$crkf));
	$stnameandscoreCrk = array_combine($accrkkeys,$crkmx2);
	$maxinallsub = $crkmx;			
	}
	else if($su == 'Economics'){
		$resultmxbystunameeco1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Economics' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeco1))
	{	
		$snm2eco1[] = $rsn['score'];
		$stin2eco[] = $rsn['student_name'];
	}
	$acecof = array_combine($stin2eco,$snm2eco1);
	$resultmxbystunameeco2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Economics' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeco2))
	{	
		$snm2eco2[] = $rsn['score'];
	    $stin2eco2[] = $rsn['student_name'];
	}
	$acecos = array_combine($stin2eco2,$snm2eco2);
	$resultmxbystunameeco3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Economics' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameeco3))
	{	
		$snm2eco3[] = $rsn['score'];
		$stin2eco3[] = $rsn['student_name'];
	}
	$acecot = array_combine($stin2eco3,$snm2eco3);
	$arinall = array($acecof, $acecos, $acecot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acecokeys = (array_keys($largest_arr));
	
$foreco1 = array();
$foreco2 = array();
$foreco3 = array();
for($v=0; $v<=120; $v++){
$foreeco1[] = $snm2eco1[$v];
$foreeco2[] = $snm2eco2[$v];
$foreeco3[] = $snm2eco3[$v];
}
$foreco1 = $foreeco1;
$foreco2 = $foreeco2;
$foreco3 = $foreeco3;

	$array_all_eco = array(array_filter($foreco1), array_filter($foreco2), array_filter($foreco3));
	$countingeco = 0;
	while($countingeco <= 120){
	if(count(array_column($array_all_eco, $countingeco)) == 3){
	$ecof2[] = round(array_sum(array_column($array_all_eco, $countingeco))/3);
	}
	else if(count(array_column($array_all_eco, $countingeco)) == 2){
	$ecof2[] = round(array_sum(array_column($array_all_eco, $countingeco))/2);
	}
	else if(count(array_column($array_all_eco, $countingeco)) == 1){
	$ecof2[] = round(array_sum(array_column($array_all_eco, $countingeco))/1);
	}
	else{
	$ecof2[] = round(array_sum(array_column($array_all_eco, $countingeco))/3);	
	}
	$countingeco++;
	}
	$ecof = implode("-",array_filter($ecof2));
	$ecomx2 = explode("-",$ecof);
	$ecomx = max(explode("-",$ecof));
	$stnameandscoreEco = array_combine($acecokeys,$ecomx2);
	$maxinallsub = $ecomx;			
	}
	else if($su == 'Financial Accounting'){
		$resultmxbystunamefin1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Financial Accounting' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefin1))
	{	
		$snm2fin1[] = $rsn['score'];
		$stin2fin[] = $rsn['student_name'];
	}
	$acfinf = array_combine($stin2fin,$snm2fin1);
	$resultmxbystunamefin2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Financial Accounting' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefin2))
	{	
		$snm2fin2[] = $rsn['score'];
	    $stin2fin2[] = $rsn['student_name'];
	}
	$acfins = array_combine($stin2fin2,$snm2fin2);
	$resultmxbystunamefin3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Financial Accounting' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefin3))
	{	
		$snm2fin3[] = $rsn['score'];
		$stin2fin3[] = $rsn['student_name'];
	}
	$acfint = array_combine($stin2fin3,$snm2fin3);
	$arinall = array($acfinf, $acfins, $acfint);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acfinkeys = (array_keys($largest_arr));
	
$forfin1 = array();
$forfin2 = array();
$forfin3 = array();
for($v=0; $v<=120; $v++){
$forffin1[] = $snm2fin1[$v];
$forffin2[] = $snm2fin2[$v];
$forffin3[] = $snm2fin3[$v];
}
$forfin1 = $forffin1;
$forfin2 = $forffin2;
$forfin3 = $forffin3;

	$array_all_fin = array(array_filter($forfin1), array_filter($forfin2), array_filter($forfin3));
	$countingfin = 0;
	while($countingfin <= 120){
	if(count(array_column($array_all_fin, $countingfin)) == 3){
	$finf2[] = round(array_sum(array_column($array_all_fin, $countingfin))/3);
	}
	else if(count(array_column($array_all_fin, $countingfin)) == 2){
	$finf2[] = round(array_sum(array_column($array_all_fin, $countingfin))/2);
	}
	else if(count(array_column($array_all_fin, $countingfin)) == 1){
	$finf2[] = round(array_sum(array_column($array_all_fin, $countingfin))/1);
	}
	else{
	$finf2[] = round(array_sum(array_column($array_all_fin, $countingfin))/3);	
	}
	$countingfin++;
	}
	$finf = implode("-",array_filter($finf2));
	$finmx2 = explode("-",$finf);
	$finmx = max(explode("-",$finf));
	$stnameandscoreFin = array_combine($acfinkeys,$finmx2);
	$maxinallsub = $finmx;			
	}
		else if($su == 'Food and Nutrition'){
		$resultmxbystunamefoo1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Food and Nutrition' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefoo1))
	{	
		$snm2foo1[] = $rsn['score'];
		$stin2foo[] = $rsn['student_name'];
	}
	$acfoof = array_combine($stin2foo,$snm2foo1);
	$resultmxbystunamefoo2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Food and Nutrition' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefoo2))
	{	
		$snm2foo2[] = $rsn['score'];
	    $stin2foo2[] = $rsn['student_name'];
	}
	$acfoos = array_combine($stin2foo2,$snm2foo2);
	$resultmxbystunamefoo3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Food and Nutrition' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamefoo3))
	{	
		$snm2foo3[] = $rsn['score'];
		$stin2foo3[] = $rsn['student_name'];
	}
	$acfoot = array_combine($stin2foo3,$snm2foo3);
	$arinall = array($acfoof, $acfoos, $acfoot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acfookeys = (array_keys($largest_arr));
	
$forfoo1 = array();
$forfoo2 = array();
$forfoo3 = array();
for($v=0; $v<=120; $v++){
$forffoo1[] = $snm2foo1[$v];
$forffoo2[] = $snm2foo2[$v];
$forffoo3[] = $snm2foo3[$v];
}
$forfoo1 = $forffoo1;
$forfoo2 = $forffoo2;
$forfoo3 = $forffoo3;

	$array_all_foo = array(array_filter($forfoo1), array_filter($forfoo2), array_filter($forfoo3));
	$countingfoo = 0;
	while($countingfoo <= 120){
	if(count(array_column($array_all_foo, $countingfoo)) == 3){
	$foof2[] = round(array_sum(array_column($array_all_foo, $countingfoo))/3);
	}
	else if(count(array_column($array_all_foo, $countingfoo)) == 2){
	$foof2[] = round(array_sum(array_column($array_all_foo, $countingfoo))/2);
	}
	else if(count(array_column($array_all_foo, $countingfoo)) == 1){
	$foof2[] = round(array_sum(array_column($array_all_foo, $countingfoo))/1);
	}
	else{
	$foof2[] = round(array_sum(array_column($array_all_foo, $countingfoo))/3);	
	}
	$countingfoo++;
	}
	$foof = implode("-",array_filter($foof2));
	$foomx2 = explode("-",$foof);
	$foomx = max(explode("-",$foof));
	$stnameandscoreFoo = array_combine($acfookeys,$foomx2);
	$maxinallsub = $foomx;			
	}
		else if($su == 'Music'){
		$resultmxbystunamemus1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Music' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemus1))
	{	
		$snm2mus1[] = $rsn['score'];
		$stin2mus[] = $rsn['student_name'];
	}
	$acmusf = array_combine($stin2mus,$snm2mus1);
	$resultmxbystunamemus2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Music' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemus2))
	{	
		$snm2mus2[] = $rsn['score'];
	    $stin2mus2[] = $rsn['student_name'];
	}
	$acmuss = array_combine($stin2mus2,$snm2mus2);
	$resultmxbystunamemus3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Music' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemus3))
	{	
		$snm2mus3[] = $rsn['score'];
		$stin2mus3[] = $rsn['student_name'];
	}
	$acmust = array_combine($stin2mus3,$snm2mus3);
	$arinall = array($acmusf, $acmuss, $acmust);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acmuskeys = (array_keys($largest_arr));
	
$formus1 = array();
$formus2 = array();
$formus3 = array();
for($v=0; $v<=120; $v++){
$formmus1[] = $snm2mus1[$v];
$formmus2[] = $snm2mus2[$v];
$formmus3[] = $snm2mus3[$v];
}
$formus1 = $formmus1;
$formus2 = $formmus2;
$formus3 = $formmus3;

	$array_all_mus = array(array_filter($formus1), array_filter($formus2), array_filter($formus3));
	$countingmus = 0;
	while($countingmus <= 120){
	if(count(array_column($array_all_mus, $countingmus)) == 3){
	$musf2[] = round(array_sum(array_column($array_all_mus, $countingmus))/3);
	}
	else if(count(array_column($array_all_mus, $countingmus)) == 2){
	$musf2[] = round(array_sum(array_column($array_all_mus, $countingmus))/2);
	}
	else if(count(array_column($array_all_mus, $countingmus)) == 1){
	$musf2[] = round(array_sum(array_column($array_all_mus, $countingmus))/1);
	}
	else{
	$musf2[] = round(array_sum(array_column($array_all_mus, $countingmus))/3);	
	}
	$countingmus++;
	}
	$musf = implode("-",array_filter($musf2));
	$musmx2 = explode("-",$musf);
	$musmx = max(explode("-",$musf));
	$stnameandscoreMus = array_combine($acmuskeys,$musmx2);
	$maxinallsub = $musmx;			
	}
	else if($su == 'Government'){
		$resultmxbystunamegov1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Government' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegov1))
	{	
		$snm2gov1[] = $rsn['score'];
		$stin2gov[] = $rsn['student_name'];
	}
	$acgovf = array_combine($stin2gov,$snm2gov1);
	$resultmxbystunamegov2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Government' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegov2))
	{	
		$snm2gov2[] = $rsn['score'];
	    $stin2gov2[] = $rsn['student_name'];
	}
	$acgovs = array_combine($stin2gov2,$snm2gov2);
	$resultmxbystunamegov3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Government' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegov3))
	{	
		$snm2gov3[] = $rsn['score'];
		$stin2gov3[] = $rsn['student_name'];
	}
	$acgovt = array_combine($stin2gov3,$snm2gov3);
	$arinall = array($acgovf, $acgovs, $acgovt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acgovkeys = (array_keys($largest_arr));
	
$forgov1 = array();
$forgov2 = array();
$forgov3 = array();
for($v=0; $v<=120; $v++){
$forggov1[] = $snm2gov1[$v];
$forggov2[] = $snm2gov2[$v];
$forggov3[] = $snm2gov3[$v];
}
$forgov1 = $forggov1;
$forgov2 = $forggov2;
$forgov3 = $forggov3;

	$array_all_gov = array(array_filter($forgov1), array_filter($forgov2), array_filter($forgov3));
	$countinggov = 0;
	while($countinggov <= 120){
	if(count(array_column($array_all_gov, $countinggov)) == 3){
	$govf2[] = round(array_sum(array_column($array_all_gov, $countinggov))/3);
	}
	else if(count(array_column($array_all_gov, $countinggov)) == 2){
	$govf2[] = round(array_sum(array_column($array_all_gov, $countinggov))/2);
	}
	else if(count(array_column($array_all_gov, $countinggov)) == 1){
	$govf2[] = round(array_sum(array_column($array_all_gov, $countinggov))/1);
	}
	else{
	$govf2[] = round(array_sum(array_column($array_all_gov, $countinggov))/3);	
	}
	$countinggov++;
	}
	$govf = implode("-",array_filter($govf2));
	$govmx2 = explode("-",$govf);
	$govmx = max(explode("-",$govf));
	$stnameandscoreGov = array_combine($acgovkeys,$govmx2);
	$maxinallsub = $govmx;			
	}
	else if($su == 'Hausa'){
		$resultmxbystunamehau1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Hausa' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehau1))
	{	
		$snm2hau1[] = $rsn['score'];
		$stin2hau[] = $rsn['student_name'];
	}
	$achauf = array_combine($stin2hau,$snm2hau1);
	$resultmxbystunamehau2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Hausa' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehau2))
	{	
		$snm2hau2[] = $rsn['score'];
	    $stin2hau2[] = $rsn['student_name'];
	}
	$achaus = array_combine($stin2hau2,$snm2hau2);
	$resultmxbystunamehau3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Hausa' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehau3))
	{	
		$snm2hau3[] = $rsn['score'];
		$stin2hau3[] = $rsn['student_name'];
	}
	$achaut = array_combine($stin2hau3,$snm2hau3);
	$arinall = array($achauf, $achaus, $achaut);
	//print_r($arinall);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$achaukeys = (array_keys($largest_arr));
	
$forhau1 = array();
$forhau2 = array();
$forhau3 = array();
for($v=0; $v<=120; $v++){
$forhhau1[] = $snm2hau1[$v];
$forhhau2[] = $snm2hau2[$v];
$forhhau3[] = $snm2hau3[$v];
}
$forhau1 = $forhhau1;
$forhau2 = $forhhau2;
$forhau3 = $forhhau3;
//print_r($array_all_irs);

	$array_all_hau = array(array_filter($forhau1), array_filter($forhau2), array_filter($forhau3));
	$countinghau = 0;
	while($countinghau <= 120){
	if(count(array_column($array_all_hau, $countinghau)) == 3){
	$hauf2[] = round(array_sum(array_column($array_all_hau, $countinghau))/3);
	}
	else if(count(array_column($array_all_hau, $countinghau)) == 2){
	$hauf2[] = round(array_sum(array_column($array_all_hau, $countinghau))/2);
	}
	else if(count(array_column($array_all_hau, $countinghau)) == 1){
	$hauf2[] = round(array_sum(array_column($array_all_hau, $countinghau))/1);
	}
	else{
	$hauf2[] = round(array_sum(array_column($array_all_hau, $countinghau))/3);	
	}
	$countinghau++;
	}
	$hauf = implode("-",array_filter($hauf2));
	$haumx2 = explode("-",$hauf);
	$haumx = max(explode("-",$hauf));
	$stnameandscoreHau = array_combine($achaukeys,$haumx2);
	$maxinallsub = $haumx;			
	}
	else if($su == 'History'){
		$resultmxbystunamehis1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='History' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehis1))
	{	
		$snm2his1[] = $rsn['score'];
		$stin2his[] = $rsn['student_name'];
	}
	$achisf = array_combine($stin2his,$snm2his1);
	$resultmxbystunamehis2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='History' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehis2))
	{	
		$snm2his2[] = $rsn['score'];
	    $stin2his2[] = $rsn['student_name'];
	}
	$achiss = array_combine($stin2his2,$snm2his2);
	$resultmxbystunamehis3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='History' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehis3))
	{	
		$snm2his3[] = $rsn['score'];
		$stin2his3[] = $rsn['student_name'];
	}
	$achist = array_combine($stin2his3,$snm2his3);
	$arinall = array($achisf, $achiss, $achist);
	//print_r($arinall);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$achiskeys = (array_keys($largest_arr));
	
$forhis1 = array();
$forhis2 = array();
$forhis3 = array();
for($v=0; $v<=120; $v++){
$forhhis1[] = $snm2his1[$v];
$forhhis2[] = $snm2his2[$v];
$forhhis3[] = $snm2his3[$v];
}
$forhis1 = $forhhis1;
$forhis2 = $forhhis2;
$forhis3 = $forhhis3;
//print_r($array_all_irs);

	$array_all_his = array(array_filter($forhis1), array_filter($forhis2), array_filter($forhis3));
	$countinghis = 0;
	while($countinghis <= 120){
	if(count(array_column($array_all_his, $countinghis)) == 3){
	$hisf2[] = round(array_sum(array_column($array_all_his, $countinghis))/3);
	}
	else if(count(array_column($array_all_his, $countinghis)) == 2){
	$hisf2[] = round(array_sum(array_column($array_all_his, $countinghis))/2);
	}
	else if(count(array_column($array_all_his, $countinghis)) == 1){
	$hisf2[] = round(array_sum(array_column($array_all_his, $countinghis))/1);
	}
	else{
	$hisf2[] = round(array_sum(array_column($array_all_his, $countinghis))/3);	
	}
	$countinghis++;
	}
	$hisf = implode("-",array_filter($hisf2));
	$hismx2 = explode("-",$hisf);
	$hismx = max(explode("-",$hisf));
	$stnameandscoreHis = array_combine($achiskeys,$hismx2);
	$maxinallsub = $hismx;			
	}
		else if($su == 'ICT'){
		$resultmxbystunameict1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='ICT' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameict1))
	{	
		$snm2ict1[] = $rsn['score'];
		$stin2ict[] = $rsn['student_name'];
	}
	$acictf = array_combine($stin2ict,$snm2ict1);
	$resultmxbystunameict2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='ICT' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameict2))
	{	
		$snm2ict2[] = $rsn['score'];
	    $stin2ict2[] = $rsn['student_name'];
	}
	$acicts = array_combine($stin2ict2,$snm2ict2);
	$resultmxbystunameict3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='ICT' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameict3))
	{	
		$snm2ict3[] = $rsn['score'];
		$stin2ict3[] = $rsn['student_name'];
	}
	$acictt = array_combine($stin2ict3,$snm2ict3);
	$arinall = array($acictf, $acicts, $acictt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acictkeys = (array_keys($largest_arr));
	
$forict1 = array();
$forict2 = array();
$forict3 = array();
for($v=0; $v<=120; $v++){
$foriict1[] = $snm2ict1[$v];
$foriict2[] = $snm2ict2[$v];
$foriict3[] = $snm2ict3[$v];
}
$forict1 = $foriict1;
$forict2 = $foriict2;
$forict3 = $foriict3;

	$array_all_ict = array(array_filter($forict1), array_filter($forict2), array_filter($forict3));
	$countingict = 0;
	while($countingict <= 120){
	if(count(array_column($array_all_ict, $countingict)) == 3){
	$ictf2[] = round(array_sum(array_column($array_all_ict, $countingict))/3);
	}
	else if(count(array_column($array_all_ict, $countingict)) == 2){
	$ictf2[] = round(array_sum(array_column($array_all_ict, $countingict))/2);
	}
	else if(count(array_column($array_all_ict, $countingict)) == 1){
	$ictf2[] = round(array_sum(array_column($array_all_ict, $countingict))/1);
	}
	else{
	$ictf2[] = round(array_sum(array_column($array_all_ict, $countingict))/3);	
	}
	$countingict++;
	}
	$ictf = implode("-",array_filter($ictf2));
	$ictmx2 = explode("-",$ictf);
	$ictmx = max(explode("-",$ictf));
	$stnameandscoreIct = array_combine($acictkeys,$ictmx2);
	$maxinallsub = $ictmx;			
	}
	else if($su == 'Igbo'){
		$resultmxbystunameigb1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Igbo' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameigb1))
	{	
		$snm2igb1[] = $rsn['score'];
		$stin2igb[] = $rsn['student_name'];
	}
	$acigbf = array_combine($stin2igb,$snm2igb1);
	$resultmxbystunameigb2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Igbo' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameigb2))
	{	
		$snm2igb2[] = $rsn['score'];
	    $stin2igb2[] = $rsn['student_name'];
	}
	$acigbs = array_combine($stin2igb2,$snm2igb2);
	$resultmxbystunameigb3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Igbo' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameigb3))
	{	
		$snm2igb3[] = $rsn['score'];
		$stin2igb3[] = $rsn['student_name'];
	}
	$acigbt = array_combine($stin2igb3,$snm2igb3);
	$arinall = array($acigbf, $acigbs, $acigbt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acigbkeys = (array_keys($largest_arr));
	
$forigb1 = array();
$forigb2 = array();
$forigb3 = array();
for($v=0; $v<=120; $v++){
$foriigb1[] = $snm2igb1[$v];
$foriigb2[] = $snm2igb2[$v];
$foriigb3[] = $snm2igb3[$v];
}
$forigb1 = $foriigb1;
$forigb2 = $foriigb2;
$forigb3 = $foriigb3;

	$array_all_igb = array(array_filter($forigb1), array_filter($forigb2), array_filter($forigb3));
	$countingigb = 0;
	while($countingigb <= 120){
	if(count(array_column($array_all_igb, $countingigb)) == 3){
	$igbf2[] = round(array_sum(array_column($array_all_igb, $countingigb))/3);
	}
	else if(count(array_column($array_all_igb, $countingigb)) == 2){
	$igbf2[] = round(array_sum(array_column($array_all_igb, $countingigb))/2);
	}
	else if(count(array_column($array_all_igb, $countingigb)) == 1){
	$igbf2[] = round(array_sum(array_column($array_all_igb, $countingigb))/1);
	}
	else{
	$igbf2[] = round(array_sum(array_column($array_all_igb, $countingigb))/3);	
	}
	$countingigb++;
	}
	$igbf = implode("-",array_filter($igbf2));
	$igbmx2 = explode("-",$igbf);
	$igbmx = max(explode("-",$igbf));
	$stnameandscoreIgb = array_combine($acigbkeys,$igbmx2);
	$maxinallsub = $igbmx;			
	}
	
	else if($su == 'Islamic Religious Studies'){
		$resultmxbystunameirs1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Islamic Religious Studies' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameirs1))
	{	
		$snm2irs1[] = $rsn['score'];
		$stin2irs[] = $rsn['student_name'];
	}
	$acirsf = array_combine($stin2irs,$snm2irs1);
	$resultmxbystunameirs2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Islamic Religious Studies' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameirs2))
	{	
		$snm2irs2[] = $rsn['score'];
	    $stin2irs2[] = $rsn['student_name'];
	}
	$acirss = array_combine($stin2irs2,$snm2irs2);
	$resultmxbystunameirs3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Islamic Religious Studies' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameirs3))
	{	
		$snm2irs3[] = $rsn['score'];
		$stin2irs3[] = $rsn['student_name'];
	}
	$acirst = array_combine($stin2irs3,$snm2irs3);
	$arinall = array($acirsf, $acirss, $acirst);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acirskeys = (array_keys($largest_arr));
	
$forirs1 = array();
$forirs2 = array();
$forirs3 = array();
for($v=0; $v<=120; $v++){
$foriirs1[] = $snm2irs1[$v];
$foriirs2[] = $snm2irs2[$v];
$foriirs3[] = $snm2irs3[$v];
}
$forirs1 = $forpiirs1;
$forirs2 = $forpiirs2;
$forirs3 = $forpiirs3;

	$array_all_irs = array(array_filter($forirs1), array_filter($forirs2), array_filter($forirs3));
	$countingirs = 0;
	while($countingirs <= 120){
	if(count(array_column($array_all_irs, $countingirs)) == 3){
	$irsf2[] = round(array_sum(array_column($array_all_irs, $countingirs))/3);
	}
	else if(count(array_column($array_all_irs, $countingirs)) == 2){
	$irsf2[] = round(array_sum(array_column($array_all_irs, $countingirs))/2);
	}
	else if(count(array_column($array_all_irs, $countingirs)) == 1){
	$irsf2[] = round(array_sum(array_column($array_all_irs, $countingirs))/1);
	}
	else{
	$irsf2[] = round(array_sum(array_column($array_all_irs, $countingirs))/3);	
	}
	$countingirs++;
	}
	$irsf = implode("-",array_filter($irsf2));
	$irsmx2 = explode("-",$irsf);
	$irsmx = max(explode("-",$irsf));
	$stnameandscoreIrs = array_combine($acirskeys,$irsmx2);
	$maxinallsub = $irsmx;			
	}
	else if($su == 'Literature in English'){
		$resultmxbystunamelit1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Literature in English' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamelit1))
	{	
		$snm2lit1[] = $rsn['score'];
		$stin2lit[] = $rsn['student_name'];
	}
	$aclitf = array_combine($stin2lit,$snm2lit1);
	$resultmxbystunamelit2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Literature in English' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamelit2))
	{	
		$snm2lit2[] = $rsn['score'];
	    $stin2lit2[] = $rsn['student_name'];
	}
	$aclits = array_combine($stin2lit2,$snm2lit2);
	$resultmxbystunamelit3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Literature in English' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamelit3))
	{	
		$snm2lit3[] = $rsn['score'];
		$stin2lit3[] = $rsn['student_name'];
	}
	$aclitt = array_combine($stin2lit3,$snm2lit3);
	$arinall = array($aclitf, $aclits, $aclitt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$aclitkeys = (array_keys($largest_arr));
	
$forlit1 = array();
$forlit2 = array();
$forlit3 = array();
for($v=0; $v<=120; $v++){
$forllit1[] = $snm2lit1[$v];
$forllit2[] = $snm2lit2[$v];
$forllit3[] = $snm2lit3[$v];
}
$forlit1 = $forllit1;
$forlit2 = $forllit2;
$forlit3 = $forllit3;

	$array_all_lit = array(array_filter($forlit1), array_filter($forlit2), array_filter($forlit3));
	$countinglit = 0;
	while($countinglit <= 120){
	if(count(array_column($array_all_lit, $countinglit)) == 3){
	$litf2[] = round(array_sum(array_column($array_all_lit, $countinglit))/3);
	}
	else if(count(array_column($array_all_lit, $countinglit)) == 2){
	$litf2[] = round(array_sum(array_column($array_all_lit, $countinglit))/2);
	}
	else if(count(array_column($array_all_lit, $countinglit)) == 1){
	$litf2[] = round(array_sum(array_column($array_all_lit, $countinglit))/1);
	}
	else{
	$litf2[] = round(array_sum(array_column($array_all_lit, $countinglit))/3);	
	}
	$countinglit++;
	}
	$litf = implode("-",array_filter($litf2));
	$litmx2 = explode("-",$litf);
	$litmx = max(explode("-",$litf));
	$stnameandscoreLit = array_combine($aclitkeys,$litmx2);
	$maxinallsub = $litmx;			
	}
		else if($su == 'Marketing'){
		$resultmxbystunamemar1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Marketing' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemar1))
	{	
		$snm2mar1[] = $rsn['score'];
		$stin2mar[] = $rsn['student_name'];
	}
	$acmarf = array_combine($stin2mar,$snm2mar1);
	$resultmxbystunamemar2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Marketing' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemar2))
	{	
		$snm2mar2[] = $rsn['score'];
	    $stin2mar2[] = $rsn['student_name'];
	}
	$acmars = array_combine($stin2mar2,$snm2mar2);
	$resultmxbystunamemar3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Marketing' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamemar3))
	{	
		$snm2mar3[] = $rsn['score'];
		$stin2mar3[] = $rsn['student_name'];
	}
	$acmart = array_combine($stin2mar3,$snm2mar3);
	$arinall = array($acmarf, $acmars, $acmart);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acmarkeys = (array_keys($largest_arr));
	
$formar1 = array();
$formar2 = array();
$formar3 = array();
for($v=0; $v<=120; $v++){
$formmar1[] = $snm2mar1[$v];
$formmar2[] = $snm2mar2[$v];
$formmar3[] = $snm2mar3[$v];
}
$formar1 = $formmar1;
$formar2 = $formmar2;
$formar3 = $formmar3;

	$array_all_mar = array(array_filter($formar1), array_filter($formar2), array_filter($formar3));
	$countingmar = 0;
	while($countingmar <= 120){
	if(count(array_column($array_all_mar, $countingmar)) == 3){
	$marf2[] = round(array_sum(array_column($array_all_mar, $countingmar))/3);
	}
	else if(count(array_column($array_all_mar, $countingmar)) == 2){
	$marf2[] = round(array_sum(array_column($array_all_mar, $countingmar))/2);
	}
	else if(count(array_column($array_all_mar, $countingmar)) == 1){
	$marf2[] = round(array_sum(array_column($array_all_mar, $countingmar))/1);
	}
	else{
	$marf2[] = round(array_sum(array_column($array_all_mar, $countingmar))/3);	
	}
	$countingmar++;
	}
	$marf = implode("-",array_filter($marf2));
	$marmx2 = explode("-",$marf);
	$marmx = max(explode("-",$marf));
	$stnameandscoreMar = array_combine($acmarkeys,$marmx2);
	$maxinallsub = $marmx;			
	}
		else if($su == 'PHE'){
		$resultmxbystunamephe1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='PHE' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephe1))
	{	
		$snm2phe1[] = $rsn['score'];
		$stin2phe[] = $rsn['student_name'];
	}
	$acphef = array_combine($stin2phe,$snm2phe1);
	$resultmxbystunamephe2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='PHE' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephe2))
	{	
		$snm2phe2[] = $rsn['score'];
	    $stin2phe2[] = $rsn['student_name'];
	}
	$acphes = array_combine($stin2phe2,$snm2phe2);
	$resultmxbystunamephe3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='PHE' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephe3))
	{	
		$snm2phe3[] = $rsn['score'];
		$stin2phe3[] = $rsn['student_name'];
	}
	$acphet = array_combine($stin2phe3,$snm2phe3);
	$arinall = array($acphef, $acphes, $acphet);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acphekeys = (array_keys($largest_arr));
	
$forphe1 = array();
$forphe2 = array();
$forphe3 = array();
for($v=0; $v<=120; $v++){
$forpphe1[] = $snm2phe1[$v];
$forpphe2[] = $snm2phe2[$v];
$forpphe3[] = $snm2phe3[$v];
}
$forphe1 = $forpphe1;
$forphe2 = $forpphe2;
$forphe3 = $forpphe3;

	$array_all_phe = array(array_filter($forphe1), array_filter($forphe2), array_filter($forphe3));
	$countingphe = 0;
	while($countingphe <= 120){
	if(count(array_column($array_all_phe, $countingphe)) == 3){
	$phef2[] = round(array_sum(array_column($array_all_phe, $countingphe))/3);
	}
	else if(count(array_column($array_all_phe, $countingphe)) == 2){
	$phef2[] = round(array_sum(array_column($array_all_phe, $countingphe))/2);
	}
	else if(count(array_column($array_all_phe, $countingphe)) == 1){
	$phef2[] = round(array_sum(array_column($array_all_phe, $countingphe))/1);
	}
	else{
	$phef2[] = round(array_sum(array_column($array_all_phe, $countingphe))/3);	
	}
	$countingphe++;
	}
	$phef = implode("-",array_filter($phef2));
	$phemx2 = explode("-",$phef);
	$phemx = max(explode("-",$phef));
	$stnameandscorePhe = array_combine($acphekeys,$phemx2);
	$maxinallsub = $phemx;			
	}
	
	
	else if($su[$i] == 'Phonics'){
		$resultmxbystunamepho1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Phonics' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamepho1))
	{	
		$snm2pho1[] = $rsn['score'];
		$stin2pho[] = $rsn['student_name'];
	}
	$acphof = array_combine($stin2pho,$snm2pho1);
	$resultmxbystunamepho2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Phonics' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamepho2))
	{	
		$snm2pho2[] = $rsn['score'];
	    $stin2pho2[] = $rsn['student_name'];
	}
	$acphos = array_combine($stin2pho2,$snm2pho2);
	$resultmxbystunamepho3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Phonics' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamepho3))
	{	
		$snm2pho3[] = $rsn['score'];
		$stin2pho3[] = $rsn['student_name'];
	}
	$acphot = array_combine($stin2pho3,$snm2pho3);
	$arinall = array($acphof, $acphos, $acphot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acphokeys = (array_keys($largest_arr));
	
$forpho1 = array();
$forpho2 = array();
$forpho3 = array();
for($v=0; $v<=120; $v++){
$forppho1[] = $snm2pho1[$v];
$forppho2[] = $snm2pho2[$v];
$forppho3[] = $snm2pho3[$v];
}
$forpho1 = $forppho1;
$forpho2 = $forppho2;
$forpho3 = $forppho3;

	$array_all_pho = array(array_filter($forpho1), array_filter($forpho2), array_filter($forpho3));
	$countingpho = 0;
	while($countingpho <= 120){
	if(count(array_column($array_all_pho, $countingpho)) == 3){
	$phof2[] = round(array_sum(array_column($array_all_pho, $countingpho))/3);
	}
	else if(count(array_column($array_all_pho, $countingpho)) == 2){
	$phof2[] = round(array_sum(array_column($array_all_pho, $countingpho))/2);
	}
	else if(count(array_column($array_all_pho, $countingpho)) == 1){
	$phof2[] = round(array_sum(array_column($array_all_pho, $countingpho))/1);
	}
	else{
	$phof2[] = round(array_sum(array_column($array_all_pho, $countingpho))/3);	
	}
	$countingpho++;
	}
	$phof = implode("-",array_filter($phof2));
	$phomx2 = explode("-",$phof);
	$phomx = max(explode("-",$phof));
	$stnameandscorePho = array_combine($acphokeys,$phomx2);
	$maxinallsub = $phomx;			
	}
	
	
	else if($su == 'Physics'){
		$resultmxbystunamephy1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Physics' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephy1))
	{	
		$snm2phy1[] = $rsn['score'];
		$stin2phy[] = $rsn['student_name'];
	}
	$acphyf = array_combine($stin2phy,$snm2phy1);
	$resultmxbystunamephy2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Physics' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephy2))
	{	
		$snm2phy2[] = $rsn['score'];
	    $stin2phy2[] = $rsn['student_name'];
	}
	$acphys = array_combine($stin2phy2,$snm2phy2);
	$resultmxbystunamephy3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Physics' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamephy3))
	{	
		$snm2phy3[] = $rsn['score'];
		$stin2phy3[] = $rsn['student_name'];
	}
	$acphyt = array_combine($stin2phy3,$snm2phy3);
	$arinall = array($acphyf, $acphys, $acphyt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acphykeys = (array_keys($largest_arr));
	
$forphy1 = array();
$forphy2 = array();
$forphy3 = array();
for($v=0; $v<=120; $v++){
$forpphy1[] = $snm2phy1[$v];
$forpphy2[] = $snm2phy2[$v];
$forpphy3[] = $snm2phy3[$v];
}
$forphy1 = $forpphy1;
$forphy2 = $forpphy2;
$forphy3 = $forpphy3;

	$array_all_phy = array(array_filter($forphy1), array_filter($forphy2), array_filter($forphy3));
	$countingphy = 0;
	while($countingphy <= 120){
	if(count(array_column($array_all_phy, $countingphy)) == 3){
	$phyf2[] = round(array_sum(array_column($array_all_phy, $countingphy))/3);
	}
	else if(count(array_column($array_all_phy, $countingphy)) == 2){
	$phyf2[] = round(array_sum(array_column($array_all_phy, $countingphy))/2);
	}
	else if(count(array_column($array_all_phy, $countingphy)) == 1){
	$phyf2[] = round(array_sum(array_column($array_all_phy, $countingphy))/1);
	}
	else{
	$phyf2[] = round(array_sum(array_column($array_all_phy, $countingphy))/3);	
	}
	$countingphy++;
	}
	$phyf = implode("-",array_filter($phyf2));
	$phymx2 = explode("-",$phyf);
	$phymx = max(explode("-",$phyf));
	$stnameandscorePhy = array_combine($acphykeys,$phymx2);
	$maxinallsub = $phymx;			
	}
	else if($su == 'Social Studies'){
		$resultmxbystunamesoc1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Social Studies' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesoc1))
	{	
		$snm2soc1[] = $rsn['score'];
		$stin2soc[] = $rsn['student_name'];
	}
	$acsocf = array_combine($stin2soc,$snm2soc1);
	$resultmxbystunamesoc2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Social Studies' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesoc2))
	{	
		$snm2soc2[] = $rsn['score'];
	    $stin2soc2[] = $rsn['student_name'];
	}
	$acsocs = array_combine($stin2soc2,$snm2soc2);
	$resultmxbystunamesoc3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Social Studies' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesoc3))
	{	
		$snm2soc3[] = $rsn['score'];
		$stin2soc3[] = $rsn['student_name'];
	}
	$acsoct = array_combine($stin2soc3,$snm2soc3);
	$arinall = array($acsocf, $acsocs, $acsoct);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acsockeys = (array_keys($largest_arr));
	
$forsoc1 = array();
$forsoc2 = array();
$forsoc3 = array();
for($v=0; $v<=120; $v++){
$forssoc1[] = $snm2soc1[$v];
$forssoc2[] = $snm2soc2[$v];
$forssoc3[] = $snm2soc3[$v];
}
$forsoc1 = $forssoc1;
$forsoc2 = $forssoc2;
$forsoc3 = $forssoc3;

	$array_all_soc = array(array_filter($forsoc1), array_filter($forsoc2), array_filter($forsoc3));
	$countingsoc = 0;
	while($countingsoc <= 120){
	if(count(array_column($array_all_soc, $countingsoc)) == 3){
	$socf2[] = round(array_sum(array_column($array_all_soc, $countingsoc))/3);
	}
	else if(count(array_column($array_all_soc, $countingsoc)) == 2){
	$socf2[] = round(array_sum(array_column($array_all_soc, $countingsoc))/2);
	}
	else if(count(array_column($array_all_soc, $countingsoc)) == 1){
	$socf2[] = round(array_sum(array_column($array_all_soc, $countingsoc))/1);
	}
	else{
	$socf2[] = round(array_sum(array_column($array_all_soc, $countingsoc))/3);	
	}
	$countingsoc++;
	}
	$socf = implode("-",array_filter($socf2));
	$socmx2 = explode("-",$socf);
	$socmx = max(explode("-",$socf));
	$stnameandscoreSoc = array_combine($acsockeys,$socmx2);
	$maxinallsub = $socmx;			
	}
		else if($su == 'Sociology'){
		$resultmxbystunamesocio1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Sociology' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesocio1))
	{	
		$snm2socio1[] = $rsn['score'];
		$stin2socio[] = $rsn['student_name'];
	}
	$acsociof = array_combine($stin2socio,$snm2socio1);
	$resultmxbystunamesocio2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Sociology' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesocio2))
	{	
		$snm2socio2[] = $rsn['score'];
	    $stin2socio2[] = $rsn['student_name'];
	}
	$acsocios = array_combine($stin2socio2,$snm2socio2);
	$resultmxbystunamesocio3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Sociology' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamesocio3))
	{	
		$snm2socio3[] = $rsn['score'];
		$stin2socio3[] = $rsn['student_name'];
	}
	$acsociot = array_combine($stin2socio3,$snm2socio3);
	$arinall = array($acsociof, $acsocios, $acsociot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acsociokeys = (array_keys($largest_arr));
	
$forsocio1 = array();
$forsocio2 = array();
$forsocio3 = array();
for($v=0; $v<=120; $v++){
$forssocio1[] = $snm2socio1[$v];
$forssocio2[] = $snm2socio2[$v];
$forssocio3[] = $snm2socio3[$v];
}
$forsocio1 = $forssocio1;
$forsocio2 = $forssocio2;
$forsocio3 = $forssocio3;

	$array_all_socio = array(array_filter($forsocio1), array_filter($forsocio2), array_filter($forsocio3));
	$countingsocio = 0;
	while($countingsocio <= 120){
	if(count(array_column($array_all_socio, $countingsocio)) == 3){
	$sociof2[] = round(array_sum(array_column($array_all_socio, $countingsocio))/3);
	}
	else if(count(array_column($array_all_socio, $countingsocio)) == 2){
	$sociof2[] = round(array_sum(array_column($array_all_socio, $countingsocio))/2);
	}
	else if(count(array_column($array_all_socio, $countingsocio)) == 1){
	$sociof2[] = round(array_sum(array_column($array_all_socio, $countingsocio))/1);
	}
	else{
	$sociof2[] = round(array_sum(array_column($array_all_socio, $countingsocio))/3);	
	}
	$countingsocio++;
	}
	$sociof = implode("-",array_filter($sociof2));
	$sociomx2 = explode("-",$sociof);
	$sociomx = max(explode("-",$sociof));
	$stnameandscoreSocio = array_combine($acsociokeys,$sociomx2);
	$maxinallsub = $sociomx;			
	}
	else if($su == 'TD'){
		$resultmxbystunametd1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='TD' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunametd1))
	{	
		$snm2td1[] = $rsn['score'];
		$stin2td[] = $rsn['student_name'];
	}
	$actdf = array_combine($stin2td,$snm2td1);
	$resultmxbystunametd2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='TD' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunametd2))
	{	
		$snm2td2[] = $rsn['score'];
	    $stin2td2[] = $rsn['student_name'];
	}
	$actds = array_combine($stin2td2,$snm2td2);
	$resultmxbystunametd3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='TD' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunametd3))
	{	
		$snm2td3[] = $rsn['score'];
		$stin2td3[] = $rsn['student_name'];
	}
	$actdt = array_combine($stin2td3,$snm2td3);
	$arinall = array($actdf, $actds, $actdt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$actdkeys = (array_keys($largest_arr));
	
$fortd1 = array();
$fortd2 = array();
$fortd3 = array();
for($v=0; $v<=120; $v++){
$forttd1[] = $snm2td1[$v];
$forttd2[] = $snm2td2[$v];
$forttd3[] = $snm2td3[$v];
}
$fortd1 = $forttd1;
$fortd2 = $forttd2;
$fortd3 = $forttd3;

	$array_all_td = array(array_filter($fortd1), array_filter($fortd2), array_filter($fortd3));
	$countingtd = 0;
	while($countingtd <= 120){
	if(count(array_column($array_all_td, $countingtd)) == 3){
	$tdf2[] = round(array_sum(array_column($array_all_td, $countingtd))/3);
	}
	else if(count(array_column($array_all_td, $countingtd)) == 2){
	$tdf2[] = round(array_sum(array_column($array_all_td, $countingtd))/2);
	}
	else if(count(array_column($array_all_td, $countingtd)) == 1){
	$tdf2[] = round(array_sum(array_column($array_all_td, $countingtd))/1);
	}
	else{
	$tdf2[] = round(array_sum(array_column($array_all_td, $countingtd))/3);	
	}
	$countingtd++;
	}
	$tdf = implode("-",array_filter($tdf2));
	$tdmx2 = explode("-",$tdf);
	$tdmx = max(explode("-",$tdf));
	$stnameandscoreTd = array_combine($actdkeys,$tdmx2);
	$maxinallsub = $tdmx;			
	}
	else if($su == 'VA'){
		$resultmxbystunameva1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='VA' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameva1))
	{	
		$snm2va1[] = $rsn['score'];
		$stin2va[] = $rsn['student_name'];
	}
	$acvaf = array_combine($stin2va,$snm2va1);
	$resultmxbystunameva2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='VA' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameva2))
	{	
		$snm2va2[] = $rsn['score'];
	    $stin2va2[] = $rsn['student_name'];
	}
	$acvas = array_combine($stin2va2,$snm2va2);
	$resultmxbystunameva3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='VA' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameva3))
	{	
		$snm2va3[] = $rsn['score'];
		$stin2va3[] = $rsn['student_name'];
	}
	$acvat = array_combine($stin2va3,$snm2va3);
	$arinall = array($acvaf, $acvas, $acvat);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acvakeys = (array_keys($largest_arr));
	
$forva1 = array();
$forva2 = array();
$forva3 = array();
for($v=0; $v<=120; $v++){
$forvva1[] = $snm2va1[$v];
$forvva2[] = $snm2va2[$v];
$forvva3[] = $snm2va3[$v];
}
$forva1 = $forvva1;
$forva2 = $forvva2;
$forva3 = $forvva3;

	$array_all_va = array(array_filter($forva1), array_filter($forva2), array_filter($forva3));
	$countingva = 0;
	while($countingva <= 120){
	if(count(array_column($array_all_va, $countingva)) == 3){
	$vaf2[] = round(array_sum(array_column($array_all_va, $countingva))/3);
	}
	else if(count(array_column($array_all_va, $countingva)) == 2){
	$vaf2[] = round(array_sum(array_column($array_all_va, $countingva))/2);
	}
	else if(count(array_column($array_all_va, $countingva)) == 1){
	$vaf2[] = round(array_sum(array_column($array_all_va, $countingva))/1);
	}
	else{
	$vaf2[] = round(array_sum(array_column($array_all_va, $countingva))/3);	
	}
	$countingva++;
	}
	$vaf = implode("-",array_filter($vaf2));
	$vamx2 = explode("-",$vaf);
	$vamx = max(explode("-",$vaf));
	$stnameandscoreVa = array_combine($acvakeys,$vamx2);
	$maxinallsub = $vamx;			
	}
	else if($su == 'Vocational Aptitude'){
		$resultmxbystunamevap1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Vocational Aptitude' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevap1))
	{	
		$snm2vap1[] = $rsn['score'];
		$stin2vap[] = $rsn['student_name'];
	}
	$acvapf = array_combine($stin2vap,$snm2vap1);
	$resultmxbystunamevap2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Vocational Aptitude' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevap2))
	{	
		$snm2vap2[] = $rsn['score'];
	    $stin2vap2[] = $rsn['student_name'];
	}
	$acvaps = array_combine($stin2vap2,$snm2vap2);
	$resultmxbystunamevap3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Vocational Aptitude' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevap3))
	{	
		$snm2vap3[] = $rsn['score'];
		$stin2vap3[] = $rsn['student_name'];
	}
	$acvapt = array_combine($stin2vap3,$snm2vap3);
	$arinall = array($acvapf, $acvaps, $acvapt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acvapkeys = (array_keys($largest_arr));
	//print_r($acvapkeys);
$forvap1 = array();
$forvap2 = array();
$forvap3 = array();
for($v=0; $v<=120; $v++){
$forvvap1[] = $snm2vap1[$v];
$forvvap2[] = $snm2vap2[$v];
$forvvap3[] = $snm2vap3[$v];
}
$forvap1 = $forvvap1;
$forvap2 = $forvvap2;
$forvap3 = $forvvap3;

	$array_all_vap = array(array_filter($forvap1), array_filter($forvap2), array_filter($forvap3));
	$countingvap = 0;
	while($countingvap <= 120){
	if(count(array_column($array_all_vap, $countingvap)) == 3){
	$vapf2[] = round(array_sum(array_column($array_all_vap, $countingvap))/3);
	}
	else if(count(array_column($array_all_vap, $countingvap)) == 2){
	$vapf2[] = round(array_sum(array_column($array_all_vap, $countingvap))/2);
	}
	else if(count(array_column($array_all_vap, $countingvap)) == 1){
	$vapf2[] = round(array_sum(array_column($array_all_vap, $countingvap))/1);
	}
	else{
	$vapf2[] = round(array_sum(array_column($array_all_vap, $countingvap))/3);	
	}
	$countingvap++;
	}
	$vapf = implode("-",array_filter($vapf2));
	//echo $vapf;
	$vapmx2 = explode("-",$vapf);
	$vapmx = max(explode("-",$vapf));
	$stnameandscoreVap = array_combine($acvapkeys,$vapmx2);
	$maxinallsub = $vapmx;			
	}
	else if($su == 'Yoruba'){
		$resultmxbystunameyor1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Yoruba' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameyor1))
	{	
		$snm2yor1[] = $rsn['score'];
		$stin2yor[] = $rsn['student_name'];
	}
	$acyorf = array_combine($stin2yor,$snm2yor1);
	$resultmxbystunameyor2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Yoruba' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameyor2))
	{	
		$snm2yor2[] = $rsn['score'];
	    $stin2yor2[] = $rsn['student_name'];
	}
	$acyors = array_combine($stin2yor2,$snm2yor2);
	$resultmxbystunameyor3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Yoruba' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameyor3))
	{	
		$snm2yor3[] = $rsn['score'];
		$stin2yor3[] = $rsn['student_name'];
	}
	$acyort = array_combine($stin2yor3,$snm2yor3);
	$arinall = array($acyorf, $acyors, $acyort);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acyorkeys = (array_keys($largest_arr));
	
$foryor1 = array();
$foryor2 = array();
$foryor3 = array();
for($v=0; $v<=120; $v++){
$foryyor1[] = $snm2yor1[$v];
$foryyor2[] = $snm2yor2[$v];
$foryyor3[] = $snm2yor3[$v];
}
$foryor1 = $foryyor1;
$foryor2 = $foryyor2;
$foryor3 = $foryyor3;

	$array_all_yor = array(array_filter($foryor1), array_filter($foryor2), array_filter($foryor3));
	$countingyor = 0;
	while($countingyor <= 120){
	if(count(array_column($array_all_yor, $countingyor)) == 3){
	$yorf2[] = round(array_sum(array_column($array_all_yor, $countingyor))/3);
	}
	else if(count(array_column($array_all_yor, $countingyor)) == 2){
	$yorf2[] = round(array_sum(array_column($array_all_yor, $countingyor))/2);
	}
	else if(count(array_column($array_all_yor, $countingyor)) == 1){
	$yorf2[] = round(array_sum(array_column($array_all_yor, $countingyor))/1);
	}
	else{
	$yorf2[] = round(array_sum(array_column($array_all_yor, $countingyor))/3);	
	}
	$countingyor++;
	}
	$yorf = implode("-",array_filter($yorf2));
	$yormx2 = explode("-",$yorf);
	$yormx = max(explode("-",$yorf));
	$stnameandscoreYor = array_combine($acyorkeys,$yormx2);
	$maxinallsub = $yormx;			
	}
		else if($su == 'Quantitative Reasoning'){
		$resultmxbystunameqr1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Quantitative Reasoning' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameqr1))
	{	
		$snm2qr1[] = $rsn['score'];
		$stin2qr[] = $rsn['student_name'];
	}
	$acqrf = array_combine($stin2qr,$snm2qr1);
	$resultmxbystunameqr2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Quantitative Reasoning' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameqr2))
	{	
		$snm2qr2[] = $rsn['score'];
	    $stin2qr2[] = $rsn['student_name'];
	}
	$acqrs = array_combine($stin2qr2,$snm2qr2);
	$resultmxbystunameqr3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Quantitative Reasoning' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunameqr3))
	{	
		$snm2qr3[] = $rsn['score'];
		$stin2qr3[] = $rsn['student_name'];
	}
	$acqrt = array_combine($stin2qr3,$snm2qr3);
	$arinall = array($acqrf, $acqrs, $acqrt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acqrkeys = (array_keys($largest_arr));
	
$forqr1 = array();
$forqr2 = array();
$forqr3 = array();
for($v=0; $v<=120; $v++){
$forqqr1[] = $snm2qr1[$v];
$forqqr2[] = $snm2qr2[$v];
$forqqr3[] = $snm2qr3[$v];
}
$forqr1 = $forqqr1;
$forqr2 = $forqqr2;
$forqr3 = $forqqr3;

	$array_all_qr = array(array_filter($forqr1), array_filter($forqr2), array_filter($forqr3));
	$countingqr = 0;
	while($countingqr <= 120){
	if(count(array_column($array_all_qr, $countingqr)) == 3){
	$qrf2[] = round(array_sum(array_column($array_all_qr, $countingqr))/3);
	}
	else if(count(array_column($array_all_qr, $countingqr)) == 2){
	$qrf2[] = round(array_sum(array_column($array_all_qr, $countingqr))/2);
	}
	else if(count(array_column($array_all_qr, $countingqr)) == 1){
	$qrf2[] = round(array_sum(array_column($array_all_qr, $countingqr))/1);
	}
	else{
	$qrf2[] = round(array_sum(array_column($array_all_qr, $countingqr))/3);	
	}
	$countingqr++;
	}
	$qrf = implode("-",array_filter($qrf2));
	$qrmx2 = explode("-",$qrf);
	$qrmx = max(explode("-",$qrf));
	$stnameandscoreQr = array_combine($acqrkeys,$qrmx2);
	$maxinallsub = $qrmx;			
	}
			else if($su == 'Verbal Reasoning'){
		$resultmxbystunamevr1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Verbal Reasoning' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevr1))
	{	
		$snm2vr1[] = $rsn['score'];
		$stin2vr[] = $rsn['student_name'];
	}
	$acvrf = array_combine($stin2vr,$snm2vr1);
	$resultmxbystunamevr2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Verbal Reasoning' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevr2))
	{	
		$snm2vr2[] = $rsn['score'];
	    $stin2vr2[] = $rsn['student_name'];
	}
	$acvrs = array_combine($stin2vr2,$snm2vr2);
	$resultmxbystunamevr3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Verbal Reasoning' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamevr3))
	{	
		$snm2vr3[] = $rsn['score'];
		$stin2vr3[] = $rsn['student_name'];
	}
	$acvrt = array_combine($stin2vr3,$snm2vr3);
	$arinall = array($acvrf, $acvrs, $acvrt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acvrkeys = (array_keys($largest_arr));
	
$forvr1 = array();
$forvr2 = array();
$forvr3 = array();
for($v=0; $v<=120; $v++){
$forvvr1[] = $snm2vr1[$v];
$forvvr2[] = $snm2vr2[$v];
$forvvr3[] = $snm2vr3[$v];
}
$forvr1 = $forvvr1;
$forvr2 = $forvvr2;
$forvr3 = $forvvr3;

	$array_all_vr = array(array_filter($forvr1), array_filter($forvr2), array_filter($forvr3));
	$countingvr = 0;
	while($countingvr <= 120){
	if(count(array_column($array_all_vr, $countingvr)) == 3){
	$vrf2[] = round(array_sum(array_column($array_all_vr, $countingvr))/3);
	}
	else if(count(array_column($array_all_vr, $countingvr)) == 2){
	$vrf2[] = round(array_sum(array_column($array_all_vr, $countingvr))/2);
	}
	else if(count(array_column($array_all_vr, $countingvr)) == 1){
	$vrf2[] = round(array_sum(array_column($array_all_vr, $countingvr))/1);
	}
	else{
	$vrf2[] = round(array_sum(array_column($array_all_vr, $countingvr))/3);	
	}
	$countingvr++;
	}
	$vrf = implode("-",array_filter($vrf2));
	$vrmx2 = explode("-",$vrf);
	$vrmx = max(explode("-",$vrf));
	$stnameandscoreVr = array_combine($acvrkeys,$vrmx2);
	$maxinallsub = $vrmx;			
	}
	
	else if($su == 'Geography'){
		$resultmxbystunamegeo1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Geography' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegeo1))
	{	
		$snm2geo1[] = $rsn['score'];
		$stin2geo[] = $rsn['student_name'];
	}
	$acgeof = array_combine($stin2geo,$snm2geo1);
	$resultmxbystunamegeo2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Geography' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegeo2))
	{	
		$snm2geo2[] = $rsn['score'];
	    $stin2geo2[] = $rsn['student_name'];
	}
	$acgeos = array_combine($stin2geo2,$snm2geo2);
	$resultmxbystunamegeo3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Geography' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamegeo3))
	{	
		$snm2geo3[] = $rsn['score'];
		$stin2geo3[] = $rsn['student_name'];
	}
	$acgeot = array_combine($stin2geo3,$snm2geo3);
	$arinall = array($acgeof, $acgeos, $acgeot);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$acgeokeys = (array_keys($largest_arr));
	
$forgeo1 = array();
$forgeo2 = array();
$forgeo3 = array();
for($v=0; $v<=120; $v++){
$forggeo1[] = $snm2geo1[$v];
$forggeo2[] = $snm2geo2[$v];
$forggeo3[] = $snm2geo3[$v];
}
$forgeo1 = $forggeo1;
$forgeo2 = $forggeo2;
$forgeo3 = $forggeo3;
		
$array_all_geo = array(array_filter($forgeo1), array_filter($forgeo2), array_filter($forgeo3));
	$countinggeo = 0;
	while($countinggeo <= 120){
	if(count(array_column($array_all_geo, $countinggeo)) == 3){
	$geof2[] = round(array_sum(array_column($array_all_geo, $countinggeo))/3);
	}
	else if(count(array_column($array_all_geo, $countinggeo)) == 2){
	$geof2[] = round(array_sum(array_column($array_all_geo, $countinggeo))/2);
	}
	else if(count(array_column($array_all_geo, $countinggeo)) == 1){
	$geof2[] = round(array_sum(array_column($array_all_geo, $countinggeo))/1);
	}
	else{
	$geof2[] = round(array_sum(array_column($array_all_geo, $countinggeo))/3);	
	}
	$countinggeo++;
	}
	$geof = implode("-",array_filter($geof2));
	$geomx2 = explode("-",$geof);
	$geomx = max(explode("-",$geof));
	$stnameandscoreGeo = array_combine($acgeokeys,$geomx2);
	$maxinallsub = $geomx;			
	}
	
	elseif($su[$i] == 'Handwriting'){							
	$resultmxbystunamehw1 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Handwriting' AND year='$year' AND term='First Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehw1))
	{	
		$snm2hw1[] = $rsn['score'];
		$stin2hw[] = $rsn['student_name'];
	}
	$achwf = array_combine($stin2hw,$snm2hw1);
	$resultmxbystunamehw2 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Handwriting' AND year='$year' AND term='Second Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehw2))
	{	
		$snm2hw2[] = $rsn['score'];
	    $stin2hw2[] = $rsn['student_name'];
	}
	$achws = array_combine($stin2hw2,$snm2hw2);
	$resultmxbystunamehw3 = mysqli_query($db, "SELECT * FROM scores WHERE class_name='$class_name' AND subject='Handwriting' AND year='$year' AND term='Third Term' AND school='".$_SESSION["school"]."'");
	while($rsn = mysqli_fetch_assoc($resultmxbystunamehw3))
	{	
		$snm2hw3[] = $rsn['score'];
		$stin2hw3[] = $rsn['student_name'];
	}
	$achwt = array_combine($stin2hw3,$snm2hw3);
	$arinall = array($achwf, $achws, $achwt);
	$count = array_map('count', $arinall);
	$min = array_keys($count, max($count))[0];
	$largest_arr = $arinall[$min];
	$achwkeys = (array_keys($largest_arr));
	
$forhw1 = array();
for($v=0; $v<=120; $v++){
$forhhw1[] = $snm2hw1[$v];
}
$forhw1 = $forhhw1;

$forhw2 = array();
for($v=0; $v<=120; $v++){
$forhhw2[] = $snm2hw2[$v];
}
$forhw2 = $forhhw2;

$forhw3 = array();
for($v=0; $v<=120; $v++){
$forhhw3[] = $snm2hw3[$v];
}
$forhw3 = $forhhw3;

$array_all_hw = array(array_filter($forhw1), array_filter($forhw2), array_filter($forhw3));
	$countinghw = 0;
	while($countinghw <= 120){
	if(count(array_column($array_all_hw, $countinghw)) == 3){
	$hwf2[] = round(array_sum(array_column($array_all_hw, $countinghw))/3);
	}
	else if(count(array_column($array_all_hw, $countinghw)) == 2){
	$hwf2[] = round(array_sum(array_column($array_all_hw, $countinghw))/2);
	}
	else if(count(array_column($array_all_hw, $countinghw)) == 1){
	$hwf2[] = round(array_sum(array_column($array_all_hw, $countinghw))/1);
	}
	else{
	$hwf2[] = round(array_sum(array_column($array_all_hw, $countinghw))/3);	
	}
	$countinghw++;
	}
	$hwf = implode("-",array_filter($hwf2));
	$hwmx2 = explode("-",$hwf);
	$hwmx = max(explode("-",$hwf));
	$stnameandscoreHw = array_combine($achwkeys,$hwmx2);
	$maxinallsub = $hwmx;	
	}
	
		else{	
			$maxinallsub = "-";	
		}
	
						echo '<tr><td>'.$su.'</td><td>'.$ct.'</td><td>'.$ex.'</td><td>'.$tt.'</td><td>'.$dd.'</td><td>'.$cc.'</td><td>'.$av.'</td><td>'.$maxinallsub.'</td><td id="mytd">'.round($ccav).'</td><td>'.$grade.'</td><td>'.$tn.'</td><td style="text-align: left;">'.$re.'</td></tr>';	
							$counted++;
							$arrsubj2[] = $su;
							$ca2[] = $ct;
							$exam2[] = $ex;
							$fir2[] = $cc;
							$sec2[] = $dd;
							$thir2[] = $tt;
							$av2[] = $av;
							$ccav2[] = round($ccav);
							$grad2[] = $grade;
							$teacher2[] = $tn;
							$remark2[] = $re;
							$maxinallsub2[] = $maxinallsub;
							}
							
							$arrsubj = $arrsubj2;
							$ca = $ca2;
							$exam = $exam2;
							$fir = $fir2;
							$sec = $sec2;
							$thir = $thir2;
							$avv = $av2;
							$ccavv = $ccav2;
							$grad = $grad2;
							$teacher = $teacher2;
							$remark = $remark2;						
							$hs = $maxinallsub2;
							//print_r($hs);
	}				
	else{
		echo '<tr id="heading"><td>SUBJECT</td><td>CA</td><td>EXAM</td><td>TOTAL</td><td>GRADE</td><td>TEACHER\'S NAME</td><td>REMARK</td></tr>';	
		$result = mysqli_query($db, "SELECT * FROM scores WHERE student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
						while($row = mysqli_fetch_assoc($result))
							{  
							$grbnt = mysqli_query($db, "SELECT grade FROM gradeband WHERE score='".$row["score"]."'");
							while($rowgrbnt = mysqli_fetch_assoc($grbnt))
							{
							$grade2	= $rowgrbnt['grade'];
							}
							$grade = $grade2;
								
							$row2subject[] = $row["subject"];	
							$row2ca[] = $row["ca"];	
							$row2exam[] = $row["exam"];
							$row2score[] = $row["score"];
							$row2teacher_name[] = $row["teacher_name"];
							$row2remark[] = $row["remark"];
							$grad2[] = $grade;
								echo '<tr><td>'.$row["subject"].'</td><td>'.$row["ca"].'</td><td>'.$row["exam"].'</td><td>'.$row["score"].'</td><td>'.$grade.'</td><td>'.$row["teacher_name"].'</td><td style="text-align: left;">'.$row["remark"].'</td></tr>';	
							}	
							$arrsubj = $row2subject;	
							$ca = $row2ca;	
							$exam = $row2exam;
							$tt = $row2score;
							$grad = $grad2;
							$teacher = $row2teacher_name;
							$remark = $row2remark;	
	}}					
							
?>
</table>
<hr style="width:80%;"/>

<table border="1" style="width:70%; border:1px solid black; margin:auto; padding:auto; text-align: center; font-size: 8px;">
<tr style="color: red;"><td>AFFECTIVE DOMAIN</td><td>RANK</td><td>GRADE</td><td>INTERPRETATION</td></tr>


<?php
if(isset($_POST['submit3']) OR isset($_POST['submittoresult']) OR isset($_POST['subbyclass3']) OR isset($_POST['subbyarm3']) OR isset($_POST['submit8'])){
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		
$resultaff = mysqli_query($db, "SELECT * FROM affective WHERE student_name='$student_name' AND class='$class_name' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
						while($rowaff = mysqli_fetch_assoc($resultaff))
							{
if($rowaff["firstname"] >= 5){
	$rank = "A";
	$inter = "Excellent";
}
else if($rowaff["firstname"] == 4){
	$rank = "B";
	$inter = "Very Good";
}
else if($rowaff["firstname"] == 3){
	$rank = "C";
	$inter = "Good";
}
else if($rowaff["firstname"] == 2){
	$rank = "D";
	$inter = "Fair";
}	
else if($rowaff["firstname"] == 1){
	$rank = "E";
	$inter = "Poor";
}
else if($rowaff["firstname"] == 0){
	$rank = "NA";
	$inter = "NA";
}
else{
	$rank = "";
}
if($rowaff["lastname"] >= 5){
	$rank2 = "A";
	$inter2 = "Excellent";
}
else if($rowaff["lastname"] == 4){
	$rank2 = "B";
	$inter2 = "Very Good";
}
else if($rowaff["lastname"] == 3){
	$rank2 = "C";
	$inter2 = "Good";
}
else if($rowaff["lastname"] == 2){
	$rank2 = "D";
	$inter2 = "Fair";
}	
else if($rowaff["lastname"] == 1){
	$rank2 = "E";
	$inter2 = "Poor";
	
}
else if($rowaff["lastname"] == 0){
	$rank2 = "NA";
	$inter2 = "NA";
}
else{
	$rank2 = "";
}
if($rowaff["midname"] >= 5){
	$rank3 = "A";
	$inter3 = "Excellent";
	
}
else if($rowaff["midname"] == 4){
	$rank3 = "B";
	$inter3 = "Very Good";
}
else if($rowaff["midname"] == 3){
	$rank3 = "C";
	$inter3 = "Good";
}
else if($rowaff["midname"] == 2){
	$rank3 = "D";
	$inter3 = "Fair";
}	
else if($rowaff["midname"] == 1){
	$rank3 = "E";
	$inter3 = "Poor";
}
else if($rowaff["midname"] == 0){
	$rank3 = "NA";
	$inter3 = "NA";
}
else{
	$rank3 = "";
}	
$rowhonesty1[] = $rowaff["firstname"];
$rowhonesty2[] = $rank;
$rowhonesty3[] = $inter;
$rowattend1[] = $rowaff["lastname"];
$rowattend2[] = $rank2;
$rowattend3[] = $inter2;
$rowcooperate1[] = $rowaff["midname"];
$rowcooperate2[] = $rank3;
$rowcooperate3[] = $inter3;
echo '<tr ><td>Honesty</td><td>'.$rowaff["firstname"].'</td><td>'.$rank.'</td><td>'.$inter.'</td></tr>';
echo '<tr ><td>Attentiveness</td><td>'.$rowaff["lastname"].'</td><td>'.$rank2.'</td><td>'.$inter2.'</td></tr>';
echo '<tr ><td>Cooperation</td><td>'.$rowaff["midname"].'</td><td>'.$rank3.'</td><td>'.$inter3.'</td></tr>';
}
$rh1 = current($rowhonesty1);
$rh2 = current($rowhonesty2);
$rh3 = current($rowhonesty3);
$ra1 = current($rowattend1);
$ra2 = current($rowattend2);
$ra3 = current($rowattend3);
$rc1 = current($rowcooperate1);
$rc2 = current($rowcooperate2);
$rc3 = current($rowcooperate3);
}
?>
<tr style="color: red;"><td>PSYCHOMOTOR DOMAIN</td><td>RANK</td><td>GRADE</td><td>INTERPRETATION</td></tr>
<?php
if(isset($_POST['submit3']) OR isset($_POST['submittoresult']) OR isset($_POST['subbyclass3']) OR isset($_POST['subbyarm3'])){
include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		
$resultp = mysqli_query($db, "SELECT * FROM affective WHERE student_name='$student_name' AND class='$class_name' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
						while($rowp = mysqli_fetch_assoc($resultp))
							{
if($rowp["pfirstname"] >= 5){
	$prank = "A";
	$pinter = "Excellent";
}
else if($rowp["pfirstname"] == 4){
	$prank = "B";
	$pinter = "Very Good";
}
else if($rowp["pfirstname"] == 3){
	$prank = "C";
	$pinter = "Good";
}
else if($rowp["pfirstname"] == 2){
	$prank = "D";
	$pinter = "Fair";
}	
else if($rowp["pfirstname"] == 1){
	$prank = "E";
	$pinter = "Poor";
}
else if($rowp["pfirstname"] == 0){
	$prank = "NA";
	$pinter = "NA";
}
else{
	$prank = "";
}
if($rowp["plastname"] >= 5){
	$prank2 = "A";
	$pinter2 = "Excellent";
}
else if($rowp["plastname"] == 4){
	$prank2 = "B";
	$pinter2 = "Very Good";
}
else if($rowp["plastname"] == 3){
	$prank2 = "C";
	$pinter2 = "Good";
}
else if($rowp["plastname"] == 2){
	$prank2 = "D";
	$pinter2 = "Fair";
}	
else if($rowp["plastname"] == 1){
	$prank2 = "E";
	$pinter2 = "Poor";
	
}
else if($rowp["plastname"] == 0){
	$prank2 = "NA";
	$pinter2 = "NA";
}
else{
	$prank2 = "";
}
if($rowp["pmidname"] >= 5){
	$prank3 = "A";
	$pinter3 = "Excellent";
	
}
else if($rowp["pmidname"] == 4){
	$prank3 = "B";
	$pinter3 = "Very Good";
}
else if($rowp["pmidname"] == 3){
	$prank3 = "C";
	$pinter3 = "Good";
}
else if($rowp["pmidname"] == 2){
	$prank3 = "D";
	$pinter3 = "Fair";
}	
else if($rowp["pmidname"] == 1){
	$prank3 = "E";
	$pinter3 = "Poor";
}
else if($rowp["pmidname"] == 0){
	$prank3 = "NA";
	$pinter3 = "NA";
}
else{
	$prank3 = "";
}	
$rowhr1[] = $rowp["pfirstname"];
$rowhr2[] = $prank;
$rowhr3[] = $pinter;
$rowpainting1[] = $rowp["plastname"];
$rowpainting2[] = $prank2;
$rowpainting3[] = $pinter2;
$rowath1[] = $rowp["pmidname"];
$rowath2[] = $prank3;
$rowath3[] = $pinter3;			
echo '<tr ><td>Handwriting</td><td>'.$rowp["pfirstname"].'</td><td>'.$prank.'</td><td>'.$pinter.'</td></tr>';
echo '<tr ><td>Painting</td><td>'.$rowp["plastname"].'</td><td>'.$prank2.'</td><td>'.$pinter2.'</td></tr>';
echo '<tr ><td>Athletics</td><td>'.$rowp["pmidname"].'</td><td>'.$prank3.'</td><td>'.$pinter3.'</td></tr>';
}
$rhr1 = current($rowhr1);
$rhr2 = current($rowhr2);
$rhr3 = current($rowhr3);
$rpainting1 = current($rowpainting1);
$rpainting2 = current($rowpainting2);
$rpainting3 = current($rowpainting3);
$rath = current($rowath1);
$rath2 = current($rowath2);
$rath3 = current($rowath3);
}
?>
</table>
<hr style="width:80%;"/>
<table style="width:80%; margin:auto; padding:auto; font-size: 10px;">
<tr>
<?php
if(isset($_POST['submit3']) OR isset($_POST['submittoresult']) OR isset($_POST['subbyclass3']) OR isset($_POST['subbyarm3']) OR isset($_POST['submit8'])){
include "connection.php";
		$student_name = $_POST['student_name'];
        $class = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
$tnames = mysqli_query($db, "SELECT studentsbyclass.hpcomment, studentsbyclass.prcomment, ftcomments.firstname FROM studentsbyclass INNER JOIN ftcomments ON studentsbyclass.student_name=ftcomments.student_name WHERE studentsbyclass.class='$class' AND studentsbyclass.student_name='$student_name' AND studentsbyclass.year='$year' AND studentsbyclass.term='$term' AND studentsbyclass.school='".$_SESSION["school"]."'");
while($rowtnames = mysqli_fetch_assoc($tnames))
{
$rowhpcomment62[] = $rowtnames['hpcomment'];
$rowftcomment62[] = $rowtnames['firstname'];
$rowprcomment62[] = $rowtnames['prcomment'];
}
$rowhpcomment = current($rowhpcomment62);
$rowftcomment = current($rowftcomment62);
$rowprcomment = current($rowprcomment62);
echo '<td style="text-align: left; font-size: 14px; width: 50%;"><span style="color: red;">Form Tutor\'s Comment:</span><br> <span style="text-decoration: none;">'.$rowftcomment.'</span></td>';
echo '<td style="text-align:right; font-size: 14px; width: 50%;"><span style="color: red;" >House Parent\'s Comment:</span><br> <span style="text-decoration: none;">'.$rowhpcomment.'</span></td>';
}
?>
</tr>
<tr>
<?php
$sig = $_POST['sig'];
$term = $_POST['term'];
$year = $_POST['year'];
$class = $_POST['class_name'];
$resultsig = mysqli_query($db, "SELECT * FROM principal where year='$year' AND school='".$_SESSION["school"]."'");
while($rowsig = mysqli_fetch_assoc($resultsig))
{
$sign2[] = $rowsig['sig'];
$imgpr2[] = $rowsig['img'];
}
$sign = current($sign2);
$imgpr = current($imgpr2);
if(($class=="Year 1")OR($class=="Year 2")OR($class=="Year 3")OR($class=="Year 4")OR($class=="Year 5")OR($class=="Year 6")){
echo '<td colspan="2" style="text-align:left; font-size: 14px; width: 50%;"><br><span style="color: red;" >Head Teacher\'s Comment:</span> <span style="text-decoration: none;">'.$rowhpcomment.'</span><br>';
}else{
echo '<td colspan="2" style="text-align:left; font-size: 14px; width: 50%;"><br><span style="color: red;" >Principal\'s Comment:</span> <span style="text-decoration: none;">'.$rowhpcomment.'</span><br>';	
}
if($sign == 1){
	if($sig==1){
echo '<span style="color: red;">Signature:</span> <img src="'.$imgpr.'" alt="" width="80" height="50" />'.date("d-m-Y").'</td>';
	}else{
echo '<br><span style="color: red;">Signature:</span> _______________________</td>';	
	}	
}else{
echo '<br><span style="color: red;">Signature:</span> _______________________</td>';	
}
?>
</tr>
</table>
</div>
<br><br><br><br><br>
<center>
<div id="loadit"></div>	
<div id="afterthis"><ul id="resultlist" style="list-style-type: none;" ></ul></div>
</center>
<?php
//include "connection.php";
$user=$_SESSION['username'];
$result3 = mysqli_query($db, "SELECT * FROM users2 where username='$user' AND school='".$_SESSION["school"]."'");
while($rowtid = mysqli_fetch_assoc($result3))
{
$trole[] = $rowtid['role'];
}
$trol = current($trole);
if($trol == 'teacher'){?>
<br><br><button class="pbutton" onclick="location.href='teagetresult.php';" style="float: left;">New Request</button>
<?php }
if(($trol == 'admin')||($trol == 'principal')){?>
<br><br><button class="pbutton" onclick="location.href='admgetresult.php';" style="float: left;">New Request</button>
<?php } ?>
<button class="pbutton" onclick="printDiv('printMe');" style="float: left;">Print</button>
<a class="pbutton" style="float: left;" href="index2.php">Index</a>
<?php
if(($term2 == 'Third Term') OR ($term == 'Third Term')){
if (isset($_POST['submittoresult']) OR isset($_POST['submit3']) OR isset($_POST['subbyarm3'])){
		$su1 = $_POST['su2'];
		$su = unserialize(base64_decode($su1));
		$cc1 = $_POST['cc2'];
		$cc = unserialize(base64_decode($cc1));
		$dd1 = $_POST['dd2'];
		$dd = unserialize(base64_decode($dd1));
		$ca1 = $_POST['ca2'];
		$ca = unserialize(base64_decode($ca1));
		$exam1 = $_POST['exam2'];
		$exam = unserialize(base64_decode($exam1));
		$tt1 = $_POST['tt2'];
		$tt = unserialize(base64_decode($tt1));
		$av1 = $_POST['av2'];
		$av = unserialize(base64_decode($av1));
		$ccav1 = $_POST['ccav2'];
		$ccav = unserialize(base64_decode($ccav1));
		$grade1 = $_POST['grade2'];
		$grade = unserialize(base64_decode($grade1));
		$tn1 = $_POST['tn2'];
		$tn = unserialize(base64_decode($tn1));
		$re1 = $_POST['re2'];
		$re = unserialize(base64_decode($re1));
		$hs1 = $_POST['hs2'];
		$hs = unserialize(base64_decode($hs1));
$student_name2 = $_POST['student_name'];
$class_name2 = $_POST['class_name'];
$year2 = $_POST['year'];
$term2 = $_POST['term'];
$term = $_POST['term'];
$arms2 = $_POST['arms'];
if(isset($_POST['submit3']) OR isset($_POST['submittoresult'])){
    echo "<br><br>";
echo '<form action="tochart.php" method="POST">';
if(isset($_POST['submit3'])){
echo '<input  style="display: none;" name="arrsubj" type="text" value="'.base64_encode(serialize($arrsubj)). '">';
echo '<input  style="display: none;" name="ca" type="text" value="'.base64_encode(serialize($caclass)). '">';
echo '<input  style="display: none;" name="exam" type="text" value="'.base64_encode(serialize($examclass)). '">';
echo '<input  style="display: none;" name="fir" type="text" value="'.base64_encode(serialize($fir)). '">';
echo '<input  style="display: none;" name="sec" type="text" value="'.base64_encode(serialize($sec)). '">';
echo '<input  style="display: none;" name="thir" type="text" value="'.base64_encode(serialize($thir)). '">';
echo '<input  style="display: none;" name="avv" type="text" value="'.base64_encode(serialize($avv)). '">';
echo '<input   style="display: none;" name="ccavv" type="text" value="'.base64_encode(serialize($ccavv)). '">';
echo '<input  style="display: none;" name="grad" type="text" value="'.base64_encode(serialize($grad)). '">';
echo '<input  style="display: none;" name="teacher" type="text" value="'.base64_encode(serialize($teacher)). '">';
echo '<input  style="display: none;" name="remark" type="text" value="'.base64_encode(serialize($remark)). '">';
echo '<input  style="display: none;" name="sig" type="text" value="'.base64_encode(serialize($sig)). '">';
}else{
echo '<input  style="display: none;" name="arrsubj" type="text" value="'.base64_encode(serialize($su)). '">';
echo '<input  style="display: none;" name="ca" type="text" value="'.base64_encode(serialize($ca)). '">';
echo '<input  style="display: none;" name="exam" type="text" value="'.base64_encode(serialize($exam)). '">';
echo '<input  style="display: none;" name="fir" type="text" value="'.base64_encode(serialize($cc)). '">';
echo '<input  style="display: none;" name="sec" type="text" value="'.base64_encode(serialize($dd)). '">';
echo '<input  style="display: none;" name="thir" type="text" value="'.base64_encode(serialize($tt)). '">';
echo '<input  style="display: none;" name="avv" type="text" value="'.base64_encode(serialize($av)). '">';
echo '<input  style="display: none;" name="ccavv" type="text" value="'.base64_encode(serialize($ccav)). '">';
echo '<input  style="display: none;" name="grad" type="text" value="'.base64_encode(serialize($grade)). '">';
echo '<input  style="display: none;" name="teacher" type="text" value="'.base64_encode(serialize($tn)). '">';
echo '<input  style="display: none;" name="remark" type="text" value="'.base64_encode(serialize($re)). '">';
}	
if(isset($_POST['submittoresult'])){
echo '<input  style="display: none;" name="hs" type="text" value="'.base64_encode(serialize($hs)). '">';	
}else{
echo '<input  style="display: none;" name="hs" type="text" value="'.base64_encode(serialize($hssnoarm)). '">';
}
echo '<input  style="display: none;" name="student_name" type="text" value="'.$student_name2. '">';
echo '<input  style="display: none;" name="class_name" type="text" value="'.$class_name2. '">';
echo '<input  style="display: none;" name="year" type="text" value="'.$year2. '">';
echo '<input  style="display: none;" style="display: none;" name="term" type="text" value="'.$term2. '">';
echo '<input   style="display: none;" name="arms" type="text" value="'.$arms2. '">';
echo '<input   style="display: none;" name="sig" type="text" value="'.$sig. '">';
echo '<input class="pbutton" style="float: left;" type="submit" name="submit" value="View Chart of '.$student_name.'\'s Performance in a Subject across Years" />';
echo '</form><br>';	
}

if(   (!isset($_POST['submit3']) && !isset($_POST['submittoresult'])) && !isset($_POST['subbyarm3'])    ){
     echo "<br><br>";
echo '<form name="maxform" action="maxscore.php" method="post">';
echo '<br><select style="width: 235px; height: auto; border-radius: 2px; border: 1px solid #CCC; color: #333;" name="subject" id="subject" required="" >';
	$result = mysqli_query($db, "SELECT * FROM subjects ORDER BY subject ASC");
						echo '<option value="" selected="selected" disabled="disabled">PICK A SUBJECT</option>';
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['subject'].'">';
								echo $row['subject'];
								echo '</option>';
							}
    echo '</select><br>';
foreach($stnameandscoreEng as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresEng2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreMat as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresMat2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreFre as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresFre2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreAgr as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresAgr2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreBas as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresBas2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreBus as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresBus2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreBio as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresBio2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreEco as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresEco2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreChe as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresChe2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreCat as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresCat2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreCiv as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresCiv2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreCrk as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresCrk2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreFoo as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresFoo2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreMus as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresMus2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreGov as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresGov2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreIct as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresIct2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreIgb as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresIgb2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreLit as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresLit2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreMar as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresMar2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscorePhe as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresPhe2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscorePhy as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresPhy2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreSoc as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresSoc2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreSocio as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresSocio2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreTd as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresTd2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreVa as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresVa2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreVap as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresVap2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreFur as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresFur2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreCom as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresCom2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreFin as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresFin2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreHau as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresHau2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreGeo as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresGeo2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreGer as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresGer2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreIsl as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresIsl2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreCca as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresCre2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreHis as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresHis2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreHea as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresHea2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreYor as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresYor2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreQr as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresQr2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreVr as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresVr2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreHw as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresHw2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscorePho as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresPho2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreAra as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresAra2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreIrs as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresIrs2[]" value="'.$key."-".$value. '">';
}
echo '<input   style="display: none;" name="student_name2" type="text" value="'.$student_name. '">';
echo '<input style="display: none;" name="class2" type="text" value="'.$class_name. '">';
echo '<input   style="display: none;" name="year2" type="text" value="'.$year. '">';
echo '<input  style="display: none;" name="term2" type="text" value="'.$term. '">';
echo '<input  style="display: none;" name="sig" type="text" value="'.$sig. '">';
echo '<input  style="display: none;" name="arms" type="text" valuer="'.$arms. '">';
echo '<input class="pbutton" style="float: left;" type="submit" name="submit" id="maxscoresubmit" value="View Performance Ranking" />';
echo '</form>';	
}

if(isset($_POST['submittoresult'])){
     echo "<br><br>";
echo '<form name="maxform" action="maxscore.php" method="post">';
echo '<br><select style="width: 235px; height: auto; border-radius: 2px; border: 1px solid #CCC; color: #333;" name="subject" id="subject" required="" >';
	$result = mysqli_query($db, "SELECT * FROM subjects ORDER BY subject ASC");
						echo '<option value="" selected="selected" disabled="disabled">PICK A SUBJECT</option>';
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['subject'].'">';
								echo $row['subject'];
								echo '</option>';
							}
    echo '</select><br>';
foreach($stnameandscoreEng as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresEng2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreMat as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresMat2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreFre as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresFre2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreAgr as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresAgr2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreBas as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresBas2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreBus as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresBus2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreBio as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresBio2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreEco as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresEco2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreChe as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresChe2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreCat as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresCat2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreCiv as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresCiv2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreCrk as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresCrk2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreFoo as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresFoo2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreMus as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresMus2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreGov as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresGov2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreIct as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresIct2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreIgb as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresIgb2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreLit as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresLit2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreMar as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresMar2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreGov as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresGov2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreIct as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresIct2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreIgb as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresIgb2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreLit as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresLit2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreMar as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresMar2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscorePhe as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresPhe2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscorePhy as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresPhy2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreSoc as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresSoc2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreSocio as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresSocio2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreTd as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresTd2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreVa as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresVa2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreVap as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresVap2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreFur as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresFur2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreCom as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresCom2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreFin as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresFin2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreHau as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresHau2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreGeo as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresGeo2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreGer as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresGer2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreIsl as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresIsl2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreCca as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresCre2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreHis as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresHis2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreHea as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresHea2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreYor as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresYor2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreQr as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresQr2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreVr as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresVr2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreHw as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresHw2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscorePho as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresPho2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreAra as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresAra2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreIrs as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresIrs2[]" value="'.$key."-".$value. '">';
}
echo '<input   style="display: none;" name="student_name2" type="text" value="'.$student_name. '">';
echo '<input style="display: none;" name="class2" type="text" value="'.$class_name. '">';
echo '<input   style="display: none;" name="year2" type="text" value="'.$year. '">';
echo '<input  style="display: none;" name="term2" type="text" value="'.$term. '">';
echo '<input  style="display: none;" name="arms" type="text" value="'.$arms. '">';
echo '<input  style="display: none;" name="sig" type="text" value="'.$sig. '">';
echo '<input class="pbutton" style="float: left;" type="submit" name="submit" id="maxscoresubmit" value="View Performance Ranking" />';
echo '</form>';	
}


		$su1 = $_POST['su2'];
		$su = unserialize(base64_decode($su1));
		//print_r($su);
		//echo '<br>';
		$cc1 = $_POST['cc2'];
		$cc = unserialize(base64_decode($cc1));
		//print_r($cc);
		//echo '<br>';
		$dd1 = $_POST['dd2'];
		$dd = unserialize(base64_decode($dd1));
		$tt1 = $_POST['tt2'];
		$tt = unserialize(base64_decode($tt1));
		//print_r($tt);
		//echo '<br>';
		$av1 = $_POST['av2'];
		$av = unserialize(base64_decode($av1));
		//print_r($av);
		//echo '<br>';
		$ccav1 = $_POST['ccav2'];
		$ccav = unserialize(base64_decode($ccav1));
		//print_r($ccav);
		//echo '<br>';
		$grade1 = $_POST['grade2'];
		$grade = unserialize(base64_decode($grade1));
		//print_r($grade);
		//echo '<br>';
		$tn1 = $_POST['tn2'];
		$tn = unserialize(base64_decode($tn1));
		//print_r($tn);
		//echo '<br>';
		$re1 = $_POST['re2'];
		$re = unserialize(base64_decode($re1));
		//print_r($re);
		//echo '<br>';
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		$arms = $_POST['arms'];
		
if (isset($_POST['submit3'])){
     echo "<br><br>";
echo '<form action="chart.js2.php" method="POST">';
echo '<input  style="display: none;" name="arsubj" value="'.base64_encode(serialize($arrsubj)). '">';
echo '<input  style="display: none;" name="ca2" type="text" value="'.base64_encode(serialize($caclass)). '">';
echo '<input  style="display: none;" name="exam2" type="text" value="'.base64_encode(serialize($examclass)). '">';
echo '<input  style="display: none;" name="fir2" type="text" value="'.base64_encode(serialize($fir)). '">';
echo '<input  style="display: none;" name="sec2" type="text" value="'.base64_encode(serialize($sec)). '">';
echo '<input  style="display: none;" name="thir2" type="text" value="'.base64_encode(serialize($thir)). '">';
echo '<input  style="display: none;" name="avv2" type="text" value="'.base64_encode(serialize($avv)). '">';
echo '<input  style="display: none;" name="ccavv2" type="text" value="'.base64_encode(serialize($ccavv)). '">';
echo '<input  style="display: none;" name="grad2" type="text" value="'.base64_encode(serialize($grad)). '">';
echo '<input  style="display: none;" name="teacher2" type="text" value="'.base64_encode(serialize($teacher)). '">';
echo '<input  style="display: none;" name="remark2" type="text" value="'.base64_encode(serialize($remark)). '">';
echo '<input  style="display: none;" name="hs222" type="text" value="'.base64_encode(serialize($hssnoarm)). '">';
echo '<input  style="display: none;" name="student_name2" type="text" value="'.$student_name. '">';
echo '<input  style="display: none;" name="class_name2" type="text" value="'.$class_name. '">';
echo '<input  style="display: none;" name="year2" type="text" value="'.$year. '">';
echo '<input   style="display: none;" name="term2" type="text" value="'.$term. '">';
echo '<input   style="display: none;" name="arms2" type="text" value="'.$arms. '">';
echo '<input  style="display: none;" name="sig" type="text" value="'.$sig. '">';
echo '<input class="pbutton" style="float: left; margin-top: -18px;" type="submit" name="submitit" value="View Chart of '.$student_name.'\'s Performance across Subjects" />';
echo '</form>';	
}
else if (isset($_POST['subbyarm3'])){
     echo "<br><br>";
echo '<form action="chart.js2.php" method="POST">';
echo '<input  style="display: none;" name="arsubj" value="'.base64_encode(serialize($arrsubj)). '">';
echo '<input  style="display: none;" name="ca2" type="text" value="'.base64_encode(serialize($casubarm)). '">';
echo '<input  style="display: none;" name="exam2" type="text" value="'.base64_encode(serialize($examsubarm)). '">';
echo '<input  style="display: none;" name="fir2" type="text" value="'.base64_encode(serialize($fir)). '">';
echo '<input  style="display: none;" name="sec2" type="text" value="'.base64_encode(serialize($sec)). '">';
echo '<input  style="display: none;" name="thir2" type="text" value="'.base64_encode(serialize($thir)). '">';
echo '<input  style="display: none;" name="avv2" type="text" value="'.base64_encode(serialize($avv)). '">';
echo '<input  style="display: none;" name="ccavv2" type="text" value="'.base64_encode(serialize($ccavv)). '">';
echo '<input  style="display: none;" name="grad2" type="text" value="'.base64_encode(serialize($grad)). '">';
echo '<input  style="display: none;" name="teacher2" type="text" value="'.base64_encode(serialize($teacher)). '">';
echo '<input  style="display: none;" name="remark2" type="text" value="'.base64_encode(serialize($remark)). '">';
echo '<input  style="display: none;" name="hssubarm" type="text" value="'.base64_encode(serialize($hssubarm)). '">';
echo '<input  style="display: none;" name="student_name2" type="text" value="'.$student_name. '">';
echo '<input  style="display: none;" name="class_name2" type="text" value="'.$class_name. '">';
echo '<input  style="display: none;" name="year2" type="text" value="'.$year. '">';
echo '<input  style="display: none;" name="term2" type="text" value="'.$term. '">';
echo '<input   style="display: none;" name="arms2" type="text" value="'.$arms. '">';
echo '<input  style="display: none;" name="sig" type="text" value="'.$sig. '">';
echo '<input class="pbutton" style="float: left;" type="submit" name="submitsubarm" value="View Chart of '.$student_name.'\'s Performance across Subjects" />';
echo '</form>';	
}
else{
$hs1 = $_POST['hs2'];
$hs = unserialize(base64_decode($hs1));	
$ca1 = $_POST['ca2'];
$ca = unserialize(base64_decode($ca1));
$exam1 = $_POST['exam2'];
$exam = unserialize(base64_decode($exam1));
echo '<form action="chart.js2.php" method="POST">';
echo '<input  style="display: none;" name="arsubj" value="'.base64_encode(serialize($su)). '">';
echo '<input  style="display: none;" name="ca2" type="text" value="'.base64_encode(serialize($ca)). '">';
echo '<input  style="display: none;" name="exam2" type="text" value="'.base64_encode(serialize($exam)). '">';
echo '<input  style="display: none;" name="fir2" type="text" value="'.base64_encode(serialize($cc)). '">';
echo '<input  style="display: none;" name="sec2" type="text" value="'.base64_encode(serialize($dd)). '">';
echo '<input  style="display: none;" name="thir2" type="text" value="'.base64_encode(serialize($tt)). '">';
echo '<input  style="display: none;" name="avv2" type="text" value="'.base64_encode(serialize($av)). '">';
echo '<input  style="display: none;" name="ccavv2" type="text" value="'.base64_encode(serialize($ccav)). '">';
echo '<input  style="display: none;" name="grad2" type="text" value="'.base64_encode(serialize($grade)). '">';
echo '<input  style="display: none;" name="teacher2" type="text" value="'.base64_encode(serialize($tn)). '">';
echo '<input  style="display: none;" name="remark2" type="text" value="'.base64_encode(serialize($re)). '">';
echo '<input  style="display: none;" name="hs32" type="text" value="'.base64_encode(serialize($hs)). '">';
echo '<input  style="display: none;" name="student_name2" type="text" value="'.$student_name. '">';
echo '<input  style="display: none;" name="class_name2" type="text" value="'.$class_name. '">';
echo '<input  style="display: none;" name="year2" type="text" value="'.$year. '">';
echo '<input  style="display: none;" name="term2" type="text" value="'.$term. '">';
echo '<input  style="display: none;" name="arms2" type="text" value="'.$arms. '">';
echo '<input  style="display: none;" name="sig" type="text" value="'.$sig. '">';
echo '<input class="pbutton" style="float: left;" type="submit" name="submit" value="View Chart of '.$student_name.'\'s Performance across Subjects" />';
echo '</form>';		
}
}

if (isset($_POST['subbyarm3'])){
$student_name2 = $_POST['student_name'];
$class_name2 = $_POST['class_name'];
$year2 = $_POST['year'];
$term2 = $_POST['term'];
$arms2 = $_POST['arms'];
$sig = $_POST['sig'];
//$ref = $_SERVER['HTTP_REFERER'];
 echo "<br><br>";
echo '<form action="tochart.php" method="POST">';
echo '<input  style="display: none;" name="arrsubj" type="text" value="'.base64_encode(serialize($arrsubj)). '">';
echo '<input  style="display: none;" name="ca" type="text" value="'.base64_encode(serialize($casubarm)). '">';
echo '<input  style="display: none;" name="exam" type="text" value="'.base64_encode(serialize($examsubarm)). '">';
echo '<input  style="display: none;" name="fir" type="text" value="'.base64_encode(serialize($fir)). '">';
echo '<input  style="display: none;" name="sec" type="text" value="'.base64_encode(serialize($sec)). '">';
echo '<input  style="display: none;" name="thir" type="text" value="'.base64_encode(serialize($thir)). '">';
echo '<input  style="display: none;" name="avv" type="text" value="'.base64_encode(serialize($avv)). '">';
echo '<input  style="display: none;" name="ccavv" type="text" value="'.base64_encode(serialize($ccavv)). '">';
echo '<input  style="display: none;" name="grad" type="text" value="'.base64_encode(serialize($grad)). '">';
echo '<input  style="display: none;" name="teacher" type="text" value="'.base64_encode(serialize($teacher)). '">';
echo '<input  style="display: none;" name="remark" type="text" value="'.base64_encode(serialize($remark)). '">';
echo '<input  style="display: none;" name="hs" type="text" value="'.base64_encode(serialize($hssubarm)). '">';
echo '<input  style="display: none;" name="student_name" type="text" value="'.$student_name2. '">';
echo '<input  style="display: none;" name="class_name" type="text" value="'.$class_name2. '">';
echo '<input  style="display: none;" name="year" type="text" value="'.$year2. '">';
echo '<input  style="display: none;" name="term" type="text" value="'.$term2. '">';
echo '<input  style="display: none;"  name="arms" type="text" value="'.$arms2. '">';
echo '<input  style="display: none;" name="sig" type="text" value="'.$sig. '">';
echo '<input class="pbutton" style="float: left;" type="submit" name="submit" value="View Chart of '.$student_name.'\'s Performance in a Subject across Years" />';
echo '</form><br>';	
}

if (isset($_POST['submit8'])){
$student_name2 = $_POST['student_name'];
$class_name2 = $_POST['class_name'];
$year2 = $_POST['year'];
$term2 = $_POST['term'];
$arms2 = $_POST['arms'];
 echo "<br><br>";
echo '<form action="tochart.php" method="POST">';
echo '<input  style="display: none;" name="arrsubj" type="text" value="'.base64_encode(serialize($arrsubj)). '">';
echo '<input  style="display: none;" name="ca" type="text" value="'.base64_encode(serialize($ca)). '">';
echo '<input  style="display: none;" name="exam" type="text" value="'.base64_encode(serialize($exam)). '">';
echo '<input  style="display: none;" name="fir" type="text" value="'.base64_encode(serialize($fir)). '">';
echo '<input  style="display: none;" name="sec" type="text" value="'.base64_encode(serialize($sec)). '">';
echo '<input  style="display: none;" name="thir" type="text" value="'.base64_encode(serialize($thir)). '">';
echo '<input  style="display: none;" name="avv" type="text" value="'.base64_encode(serialize($avv)). '">';
echo '<input  style="display: none;" name="ccavv" type="text" value="'.base64_encode(serialize($ccavv)). '">';
echo '<input  style="display: none;" name="grad" type="text" value="'.base64_encode(serialize($grad)). '">';
echo '<input  style="display: none;" name="teacher" type="text" value="'.base64_encode(serialize($teacher)). '">';
echo '<input  style="display: none;" name="remark" type="text" value="'.base64_encode(serialize($remark)). '">';
echo '<input  style="display: none;" name="hs" type="text" value="'.base64_encode(serialize($hssubmit8)). '">';
echo '<input  style="display: none;" style="display: none;" name="student_name" type="text" value="'.$student_name2. '">';
echo '<input  style="display: none;" name="class_name" type="text" value="'.$class_name2. '">';
echo '<input  style="display: none;" name="year" type="text" value="'.$year2. '">';
echo '<input  style="display: none;" style="display: none;" name="term" type="text" value="'.$term2. '">';
echo '<input   style="display: none;" name="arms" type="text" value="'.$arms2. '">';
echo '<input  style="display: none;" name="sig" type="text" value="'.$sig. '">';
echo '<input class="pbutton" style="float: left;" type="submit" name="submit" value="View Chart of '.$student_name.'\'s Performance in a Subject across Years" />';
echo '</form><br>';	


echo '<form name="maxform" action="maxscore.php" method="post">';
echo '<br><select style="width: 230px; height: auto; border-radius: 2px; border: 1px solid #CCC; color: #333;" name="subject" id="subject" required="" >';
	$result = mysqli_query($db, "SELECT * FROM subjects ORDER BY subject ASC");
						echo '<option value="" selected="selected" disabled="disabled">PICK A SUBJECT</option>';
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['subject'].'">';
								echo $row['subject'];
								echo '</option>';
							}
    echo '</select><br>';
foreach($stnameandscoreEng as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresEng2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreMat as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresMat2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreFre as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresFre2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreAgr as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresAgr2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreBas as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresBas2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreBus as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresBus2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreBio as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresBio2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreEco as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresEco2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreChe as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresChe2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreCat as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresCat2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreCiv as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresCiv2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreCrk as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresCrk2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreFoo as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresFoo2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreMus as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresMus2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreGov as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresGov2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreIct as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresIct2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreIgb as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresIgb2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreLit as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresLit2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreMar as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresMar2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscorePhe as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresPhe2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscorePhy as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresPhy2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreSoc as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresSoc2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreSocio as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresSocio2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreTd as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresTd2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreVa as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresVa2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreVap as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresVap2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreFur as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresFur2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreCom as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresCom2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreFin as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresFin2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreHau as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresHau2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreGeo as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresGeo2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreGer as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresGer2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreIsl as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresIsl2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreCca as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresCre2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreHis as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresHis2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreHea as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresHea2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreYor as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresYor2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreQr as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresQr2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreVr as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresVr2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreHw as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresHw2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscorePho as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresPho2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreAra as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresAra2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreIrs as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresIrs2[]" value="'.$key."-".$value. '">';
}
echo '<input   style="display: none;" name="student_name2" type="text" value="'.$student_name. '">';
echo '<input 	style="display: none;" name="class2" type="text" value="'.$class_name. '">';
echo '<input   style="display: none;" name="year2" type="text" value="'.$year. '">';
echo '<input   style="display: none;" name="term2" type="text" value="'.$term. '">';
echo '<input   style="display: none;" name="arms" type="text" value="'.$arms. '">';
echo '<input   style="display: none;" name="sig" type="text" value="'.$sig. '">';
echo '<input class="pbutton" style="float: left;" type="submit" name="submit" id="maxscoresubmit" value="View Performance Ranking" />';
echo '</form>';	
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		$arms = $_POST['arms'];
//echo "<br><br>";	
echo '<form action="chart.js2.php" method="POST">';
echo '<input  style="display: none;" name="arsubj" value="'.base64_encode(serialize($arrsubj)). '">';
echo '<input  style="display: none;" name="ca2" type="text" value="'.base64_encode(serialize($ca)). '">';
echo '<input  style="display: none;" name="exam2" type="text" value="'.base64_encode(serialize($exam)). '">';
echo '<input  style="display: none;" name="fir2" type="text" value="'.base64_encode(serialize($fir)). '">';
echo '<input  style="display: none;" name="sec2" type="text" value="'.base64_encode(serialize($sec)). '">';
echo '<input  style="display: none;" name="thir2" type="text" value="'.base64_encode(serialize($thir)). '">';
echo '<input  style="display: none;" name="avv2" type="text" value="'.base64_encode(serialize($avv)). '">';
echo '<input  style="display: none;" name="ccavv2" type="text" value="'.base64_encode(serialize($ccavv)). '">';
echo '<input  style="display: none;" name="grad2" type="text" value="'.base64_encode(serialize($grad)). '">';
echo '<input  style="display: none;" name="teacher2" type="text" value="'.base64_encode(serialize($teacher)). '">';
echo '<input  style="display: none;" name="remark2" type="text" value="'.base64_encode(serialize($remark)). '">';
echo '<input  style="display: none;" name="hs32" type="text" value="'.base64_encode(serialize($hssubmit8)). '">';
echo '<input  style="display: none;" name="student_name2" type="text" value="'.$student_name. '">';
echo '<input  style="display: none;" name="class_name2" type="text" value="'.$class_name. '">';
echo '<input  style="display: none;" name="year2" type="text" value="'.$year. '">';
echo '<input  style="display: none;" name="term2" type="text" value="'.$term. '">';
echo '<input  style="display: none;" name="arms2" type="text" value="'.$arms. '">';
echo '<input  style="display: none;" name="sig" type="text" value="'.$sig. '">';
echo '<input class="pbutton" style="float: left;" type="submit" name="submit" value="View Chart of '.$student_name.'\'s Performance across Subjects" />';
echo '</form>';	
}

else
{
	if(!isset($_POST['submittoresult'])){
	   // echo "<br><br>";
echo '<form name="maxform" action="maxscore.php" method="post">';
echo '<br><select style="width: 230px; height: auto; border-radius: 2px; border: 1px solid #CCC; color: #333;" name="subject" id="subject" required="" >';
	$result = mysqli_query($db, "SELECT * FROM subjects ORDER BY subject ASC");
						echo '<option value="" selected="selected" disabled="disabled">PICK A SUBJECT</option>';
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['subject'].'">';
								echo $row['subject'];
								echo '</option>';
							}
    echo '</select><br>';
foreach($stnameandscoreEng as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresEng2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreMat as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresMat2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreFre as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresFre2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreAgr as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresAgr2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreBas as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresBas2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreBus as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresBus2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreBio as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresBio2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreEco as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresEco2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreChe as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresChe2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreCat as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresCat2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreCiv as $key=>$value)
{
  echo '<input type="text" name="maxscoresCiv2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreCrk as $key=>$value)
{
  echo '<input  style="display: none;" type="text" name="maxscoresCrk2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreFoo as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresFoo2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreMus as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresMus2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreGov as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresGov2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreIct as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresIct2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreIgb as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresIgb2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreLit as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresLit2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreMar as $key=>$value)
{
  echo '<input  style="display: none;" style="display: none;" type="text" name="maxscoresMar2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscorePhe as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresPhe2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscorePhy as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresPhy2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreSoc as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresSoc2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreSocio as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresSocio2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreTd as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresTd2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreVa as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresVa2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreVap as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresVap2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreFur as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresFur2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreCom as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresCom2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreFin as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresFin2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreHau as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresHau2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreGeo as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresGeo2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreGer as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresGer2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreIsl as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresIsl2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreCca as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresCre2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreHis as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresHis2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreHea as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresHea2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreYor as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresYor2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreQr as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresQr2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreVr as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresVr2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreHw as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresHw2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscorePho as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresPho2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreAra as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresAra2[]" value="'.$key."-".$value. '">';
}
foreach($stnameandscoreIrs as $key=>$value)
{
  echo '<input style="display: none;" type="text" name="maxscoresIrs2[]" value="'.$key."-".$value. '">';
}
echo '<input   style="display: none;" name="student_name2" type="text" value="'.$student_name. '">';
echo '<input style="display: none;" name="class2" type="text" value="'.$class_name. '">';
echo '<input   style="display: none;" name="year2" type="text" value="'.$year. '">';
echo '<input  style="display: none;" name="term2" type="text" value="'.$term. '">';
echo '<input  style="display: none;" name="arms" type="text" value="'.$arms. '">';
echo '<input  style="display: none;" name="sig" type="text" value="'.$sig. '">';
echo '<input class="pbutton" style="float: left;" type="submit" name="submit" id="maxscoresubmit" value="View Performance Ranking" />';
echo '</form>';	
	}
}
}

if(isset($_POST['submit3'])){
    echo "<br><br>";
echo '<form id="resultpdf">';
foreach($arrsubj as $arrsubj2)
{
  echo '<input style="display: none;"  type="text" name="arsubj[]" value="'. $arrsubj2. '">';
}
foreach($caclass as $caloop)
{
  echo '<input style="display: none;" type="text" name="ca2[]" value="'. $caloop. '">';
}
foreach($examclass as $examloop)
{
  echo '<input style="display: none;" type="text" name="exam2[]" value="'. $examloop. '">';
}
foreach($fir as $firloop)
{
  echo '<input style="display: none;" type="text" name="cc2[]" value="'. $firloop. '">';
}
foreach($sec as $secloop)
{
  echo '<input style="display: none;" type="text" name="dd2[]" value="'. $secloop. '">';
}
foreach($thir as $thirloop)
{
  echo '<input style="display: none;" type="text" name="tt2[]" value="'. $thirloop. '">';
}
foreach($avv as $avvloop)
{
  echo '<input style="display: none;" type="text" name="av2[]" value="'. $avvloop. '">';
}
foreach($ccavv as $ccavvloop)
{
  echo '<input style="display: none;" type="text" name="ccav2[]" value="'. $ccavvloop. '">';
}
foreach($grad as $gradloop)
{
  echo '<input style="display: none;" type="text" name="grad2[]" value="'. $gradloop. '">';
}
foreach($teacher as $teacherloop)
{
  echo '<input style="display: none;" type="text" name="teacher2[]" value="'. $teacherloop. '">';
}
foreach($remark as $remarkloop)
{
  echo '<input style="display: none;" type="text" name="remark2[]" value="'. $remarkloop. '">';
}
foreach($score as $scoreloop)
{
  echo '<input style="display: none;" type="text" name="score2[]" value="'. $scoreloop. '">';
}
}//end of submit3 form
if(isset($_POST['submittoresult'])){
echo '<form id="resultpdf">';
foreach($su as $arrsubj2)
{
  echo '<input style="display: none;"  type="text" name="arsubj[]" value="'. $arrsubj2. '">';
}
foreach($ca as $caloop)
{
  echo '<input style="display: none;" type="text" name="ca2[]" value="'. $caloop. '">';
}
foreach($exam as $examloop)
{
  echo '<input style="display: none;" type="text" name="exam2[]" value="'. $examloop. '">';
}
foreach($cc as $firloop)
{
  echo '<input style="display: none;" type="text" name="cc2[]" value="'. $firloop. '">';
}
foreach($dd as $secloop)
{
  echo '<input style="display: none;" type="text" name="dd2[]" value="'. $secloop. '">';
}
foreach($tt as $thirloop)
{
  echo '<input style="display: none;" type="text" name="tt2[]" value="'. $thirloop. '">';
}
foreach($av as $avvloop)
{
  echo '<input style="display: none;" type="text" name="av2[]" value="'. $avvloop. '">';
}
foreach($ccav as $ccavvloop)
{
  echo '<input style="display: none;" type="text" name="ccav2[]" value="'. $ccavvloop. '">';
}
foreach($grade as $gradloop)
{
  echo '<input style="display: none;" type="text" name="grad2[]" value="'. $gradloop. '">';
}
foreach($tn as $teacherloop)
{
  echo '<input style="display: none;" type="text" name="teacher2[]" value="'. $teacherloop. '">';
}
foreach($re as $remarkloop)
{
  echo '<input style="display: none;" type="text" name="remark2[]" value="'. $remarkloop. '">';
}
foreach($hs as $hsloop)
{
  echo '<input style="display: none;" type="text" name="hs2[]" value="'. $hsloop. '">';
}
}//end of submittoresult form
if(isset($_POST['submit8'])){
    echo "<br><br>";
echo '<form id="resultpdf">';
foreach($arrsubj as $arrsubj2)
{
  echo '<input style="display: none;"  type="text" name="arsubj[]" value="'. $arrsubj2. '">';
}
foreach($ca as $caloop)
{
  echo '<input style="display: none;" type="text" name="ca2[]" value="'. $caloop. '">';
}
foreach($exam as $examloop)
{
  echo '<input style="display: none;" type="text" name="exam2[]" value="'. $examloop. '">';
}
foreach($fir as $firloop)
{
  echo '<input style="display: none;" type="text" name="cc2[]" value="'. $firloop. '">';
}
foreach($sec as $secloop)
{
  echo '<input style="display: none;" type="text" name="dd2[]" value="'. $secloop. '">';
}
foreach($thir as $thirloop)
{
  echo '<input style="display: none;" type="text" name="tt2[]" value="'. $thirloop. '">';
}
foreach($avv as $avvloop)
{
  echo '<input style="display: none;" type="text" name="av2[]" value="'. $avvloop. '">';
}
foreach($ccavv as $ccavvloop)
{
  echo '<input style="display: none;" type="text" name="ccav2[]" value="'. $ccavvloop. '">';
}
foreach($grad as $gradloop)
{
  echo '<input style="display: none;" type="text" name="grad2[]" value="'. $gradloop. '">';
}
foreach($teacher as $teacherloop)
{
  echo '<input style="display: none;" type="text" name="teacher2[]" value="'. $teacherloop. '">';
}
foreach($remark as $remarkloop)
{
  echo '<input style="display: none;" type="text" name="remark2[]" value="'. $remarkloop. '">';
}
foreach($hssubmit8 as $hsloop)
{
  echo '<input style="display: none;" type="text" name="hs2[]" value="'. $hsloop. '">';
}
}
echo '<input   style="display: none;" name="student_name2[]" type="text" value="'.$student_name. '">';
echo '<input style="display: none;" name="class_name2[]" type="text" value="'.$class_name. '">';
echo '<input   style="display: none;" name="year2[]" type="text" value="'.$year. '">';
echo '<input   style="display: none;" name="term2[]" type="text" value="'.$term. '">';
echo '<input   style="display: none;" name="schooll2[]" type="text" value="'.$schooll. '">';
echo '<input   style="display: none;" name="address2[]" type="text" value="'.$address. '">';
echo '<input   style="display: none;" name="tel2[]" type="text" value="'.$tel. '">';
echo '<input   style="display: none;" name="fax2[]" type="text" value="'.$fax. '">';
echo '<input   style="display: none;" name="email2[]" type="text" value="'.$email. '">';
echo '<input   style="display: none;" name="img2[]" type="text" value="'.$img. '">';
echo '<input   style="display: none;" name="rpic2[]" type="text" value="'.$rpic2. '">';
echo '<input   style="display: none;" name="termbegin2[]" type="text" value="'.$termbegin. '">';
echo '<input   style="display: none;" name="atall2[]" type="text" value="'.$atall2. '">';
echo '<input   style="display: none;" name="rsex2[]" type="text" value="'.$rsex2. '">';
echo '<input   style="display: none;" name="rdob2[]" type="text" value="'.$rdob2. '">';
echo '<input   style="display: none;" name="admno2[]" type="text" value="'.$admno2. '">';
echo '<input   style="display: none;" name="att2[]" type="text" value="'.$att. '">';
echo '<input   style="display: none;" name="rh1[]" type="text" value="'.$rh1. '">';
echo '<input   style="display: none;" name="rh2[]" type="text" value="'.$rh2. '">';
echo '<input   style="display: none;" name="rh3[]" type="text" value="'.$rh3. '">';
echo '<input   style="display: none;" name="ra1[]" type="text" value="'.$ra1. '">';
echo '<input   style="display: none;" name="ra2[]" type="text" value="'.$ra2. '">';
echo '<input   style="display: none;" name="ra3[]" type="text" value="'.$ra3. '">';
echo '<input   style="display: none;" name="rc1[]" type="text" value="'.$rc1. '">';
echo '<input   style="display: none;" name="rc2[]" type="text" value="'.$rc2. '">';
echo '<input   style="display: none;" name="rc3[]" type="text" value="'.$rc3. '">';
echo '<input   style="display: none;" name="rhr1[]" type="text" value="'.$rhr1. '">';
echo '<input   style="display: none;" name="rhr2[]" type="text" value="'.$rhr2. '">';
echo '<input   style="display: none;" name="rhr3[]" type="text" value="'.$rhr3. '">';
echo '<input   style="display: none;" name="rpainting1[]" type="text" value="'.$rpainting1. '">';
echo '<input   style="display: none;" name="rpainting2[]" type="text" value="'.$rpainting2. '">';
echo '<input   style="display: none;" name="rpainting3[]" type="text" value="'.$rpainting3. '">';
echo '<input   style="display: none;" name="rath1[]" type="text" value="'.$rath. '">';
echo '<input   style="display: none;" name="rath2[]" type="text" value="'.$rath2. '">';
echo '<input   style="display: none;" name="rath3[]" type="text" value="'.$rath3. '">';
echo '<input   style="display: none;" name="rowhpcomment[]" type="text" value="'.$rowhpcomment. '">';
echo '<input   style="display: none;" name="rowftcomment[]" type="text" value="'.$rowftcomment. '">';
echo '<input   style="display: none;" name="rowhpcomment[]" type="text" value="'.$rowhpcomment. '">';
echo '<input   style="display: none;" name="rowprcomment[]" type="text" value="'.$rowprcomment. '">';
echo '<input   style="display: none;" name="sign[]" type="text" value="'.$sign. '">';
echo '<input   style="display: none;" name="sig[]" type="text" value="'.$sig. '">';
echo '<input   style="display: none;" name="imgpr[]" type="text" value="'.$imgpr. '">';
echo '<input class="pbutton" style="float: left;" type="submit" name="submit" id="resultpdfsubmit" value="Make Downloadable" />';
echo '</form>';	
 echo "<br><br>";
?>
<a class="pbutton" style="float: left;" href="logout.php">Logout</a>
<?php
}else{
echo "<div style='color:red; width:100%; text-align: center;'>RESULT REQUESTED IS TEMPORARILY UNAVAILABLE</div>";
$user=$_SESSION['username'];
$resultrol = mysqli_query($db, "SELECT * FROM users2 where username='$user' AND school='".$_SESSION["school"]."'");
while($rowrol = mysqli_fetch_assoc($resultrol))
{
$rol2[] = $rowrol['role'];
}
$rol = current($rol2);
	if($rol == 'teacher'){?>
<meta content="2;teagetresult.php" http-equiv="refresh" />
<?php }
if(($rol == 'admin')||($rol == 'principal')){?>
<meta content="2;admgetresult.php" http-equiv="refresh" />
<?php }
}
?>
</body>