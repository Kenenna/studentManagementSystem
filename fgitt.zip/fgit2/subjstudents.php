<?php 
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Enrol Subject Students</title>
<link rel="stylesheet" href="style.css" type="text/css" />
<script src="table/js/jquery.js" type="text/javascript"></script>

<script>
		$(document).ready(function() {	
		$("#formid").submit(function( event ) {
			event.preventDefault();	
$.ajax({
type: "POST",
url: "studentbyclass.php",
data: $("#formid").serialize(),	
success: function(response){
 if(response==1) { 
		event.preventDefault();
		$(".success").fadeIn();
		setTimeout(function() { $(".success").fadeOut(); }, 2000); 
    } else {
		 $(".error").show();
		setTimeout(function() { $(".error").fadeOut(); }, 2000);
		}
		}
});	
});


$("#select_all").change(function(){  //"select all" change 
    $(".checkboxx").prop('checked', $(this).prop("checked")); //change all ".checkbox" checked status
});

//".checkbox" change 
$('.checkboxx').change(function(){ 
    //uncheck "select all", if one of the listed checkbox item is unchecked
    if(false == $(this).prop("checked")){ //if this item is unchecked
        $("#select_all").prop('checked', false); //change "select all" checked status to false
    }
    //check "select all" if all checkbox items are checked
    if ($('.checkboxx:checked').length == $('.checkboxx').length ){
        $("#select_all").prop('checked', true);
    }
});


});
</script>
<style>
	/* info (hed, dek, source, credit) */
.rg-container {
	font-family: 'Lato', Helvetica, Arial, sans-serif;
	font-size: 16px;
	line-height: 1.4;
	margin: 0;
	padding: 1em 0.5em;
	color: #222;
}
.rg-header {
	margin-bottom: 1em;
	text-align: left;
}

.rg-header > * {
	display: block;
}
.rg-hed {
	font-weight: bold;
	font-size: 1.4em;
}
.rg-dek {
	font-size: 1em;
}

.rg-source {
	margin: 0;
	font-size: 0.75em;
	text-align: right;
}
.rg-source .pre-colon {
	text-transform: uppercase;
}

.rg-source .post-colon {
	font-weight: bold;
}

/* table */
table.rg-table {
	width: 100%;
	margin-bottom: 0.5em;
	font-size: 1em;
	border-collapse: collapse;
	border-spacing: 0;
}
table.rg-table tr {
	-moz-box-sizing: border-box;
	box-sizing: border-box;
	margin: 0;
	padding: 0;
	border: 0;
	font-size: 100%;
	font: inherit;
	vertical-align: baseline;
	text-align: left;
	color: #333;
}
table.rg-table thead {
	border-bottom: 3px solid #ddd;
}
table.rg-table tr {
	border-bottom: 1px solid #ddd;
	color: #222;
}
table.rg-table tr.highlight {
	background-color: #dcf1f0 !important;
}
table.rg-table.zebra tr:nth-child(even) {
	background-color: #f6f6f6;
}
table.rg-table th {
	font-weight: bold;
	padding: 0.35em;
	font-size: 0.9em;
}
table.rg-table td {
	padding: 0.35em;
	font-size: 0.9em;
}
table.rg-table .highlight td {
	font-weight: bold;
}
table.rg-table th.number, td.number {
	text-align: right;
}

/* media queries */
@media screen and (max-width: 600px) {
.rg-container {
	max-width: 600px;
	margin: 0 auto;
}
table.rg-table {
	width: 100%;
}
table.rg-table tr.hide-mobile, table.rg-table th.hide-mobile, table.rg-table td.hide-mobile {
	display: none;
}
table.rg-table thead {
	display: none;
}
table.rg-table tbody {
	width: 100%;
}
table.rg-table tr, table.rg-table th, table.rg-table td {
	display: block;
	padding: 0;
}
table.rg-table tr {
	border-bottom: none;
	margin: 0 0 1em 0;
	padding: 0.5em;
}
table.rg-table tr.highlight {
	background-color: inherit !important;
}
table.rg-table.zebra tr:nth-child(even) {
	background-color: none;
}
table.rg-table.zebra td:nth-child(even) {
	background-color: #f6f6f6;
}
table.rg-table tr:nth-child(even) {
	background-color: none;
}
table.rg-table td {
	padding: 0.5em 0 0.25em 0;
	border-bottom: 1px dotted #ccc;
	text-align: right;
}
table.rg-table td[data-title]:before {
	content: attr(data-title);
	font-weight: bold;
	display: inline-block;
	content: attr(data-title);
	float: left;
	margin-right: 0.5em;
	font-size: 0.95em;
}
table.rg-table td:last-child {
	padding-right: 0;
	border-bottom: 2px solid #ccc;
}
table.rg-table td:empty {
	display: none;
}
table.rg-table .highlight td {
	background-color: inherit;
	font-weight: normal;
}
}
</style>
<style>
ul.topnav {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}
ul.topnav li {float: left;}
ul.topnav li a {
    display: inline-block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    transition: 0.3s;
    font-size: 17px;
}
ul.topnav li a:hover {background-color: #555;}
ul.topnav li.icon {display: none;}

@media screen and (max-width:680px) {
  ul.topnav li:not(:first-child) {display: none;}
  ul.topnav li.icon {
    float: right;
    display: inline-block;
  }
}
@media screen and (max-width:680px) {
  ul.topnav.responsive {position: relative;}
  ul.topnav.responsive li.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  ul.topnav.responsive li {
    float: none;
    display: inline;
  }
  ul.topnav.responsive li a {
    display: block;
    text-align: left;
  }
}
</style>
<link rel="stylesheet" href="css/styles.css">
   <script src="js/scriptmenu.js"></script>
   
   <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
	$('#footer').css('height', '140px');  
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>

</head>

<body>
<?php
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");
}
else{ header("location: logout.php");}
?>
<?php
$user=$_SESSION['username'];
?>

<?php
//if(isset($_POST['btn-upload'])){	
$class = $_POST['class'];
if($class=="Year 1"){
	if($ctype=="Js"){
	$cl = "JS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 1";
}else{
	$cl = "Year 1";
}
}
elseif($class=="Year 2"){
	if($ctype=="Js"){
	$cl = "JS2";
}elseif($ctype=="Primary"){
	$cl = "Primary 2";
}else{
	$cl = "Year 2";
}
}
elseif($class=="Year 3"){
	if($ctype=="Js"){
	$cl = "JS3";
}elseif($ctype=="Primary"){
	$cl = "Primary 3";
}else{
	$cl = "Year 3";
}
}
elseif($class=="Year 4"){
	if($ctype=="Js"){
	$cl = "SS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 4";
}else{
	$cl = "Year 4";
}
}
elseif($class=="Year 5"){
	if($ctype=="Js"){
	$cl = "SS2";
}elseif($ctype=="Primary"){
	$cl = "Primary 5";
}else{
	$cl = "Year 5";
}
}
elseif($class=="Year 6"){
	if($ctype=="Js"){
	$cl = "SS3";
}elseif($ctype=="Primary"){
	$cl = "Primary 6";
}else{
	$cl = "Year 6";
}
}
elseif($class=="Year 7"){
	if($ctype=="Js"){
	$cl = "JS1";
}else{
	$cl = "Year 7";
}
}
else if($class=="Year 8"){
	if($ctype=="Js"){
	$cl = "JS2";
}else{
	$cl = "Year 8";
}
}else if($class=="Year 9"){
	if($ctype=="Js"){
	$cl = "JS3";
}else{
	$cl = "Year 9";
}
}else if($class=="Year 10"){
	if($ctype=="Js"){
	$cl = "SS1";
}else{
	$cl = "Year 10";
}
}else if($class=="Year 11"){
	if($ctype=="Js"){
	$cl = "SS2";
}else{
	$cl = "Year 11";
}
}else if($class=="Year 12"){
	if($ctype=="Js"){
	$cl = "SS3";
}else{
	$cl = "Year 12";
}
}else{
	$cl = "NOT APPLICABLE";
}
$year = $_POST['year'];
$term = $_POST['term'];
$subject = $_POST['subject'];
$teacher_id = $_POST['teacher_id'];
$arms = $_POST['arms'];

include "connection.php";
$result = mysqli_query($db, "SELECT * FROM studentsbyclass where arms='$arms' AND class='$class' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$result2 = mysqli_query($db, "SELECT * FROM students where arms='$arms' AND class_name='$class' AND year='$year' AND term='$term' AND teacher_id='$teacher_id' AND subject='$subject' AND school='".$_SESSION["school"]."'");
$values = array();
$values2= array();

while($row2 = mysqli_fetch_assoc($result2))
{  						
$values2[] = $row2['student_name'];
}
echo '<br>';
while($row = mysqli_fetch_assoc($result))
{  						
$values[] = $row['student_name'];
}

$r = array_diff($values, $values2); 
echo "<br><br>";
if(count($r) < 1){
	echo "<br><br><span style='color:red;'>There are no students in your class for the selected criteria!</span><br>";
	echo '<meta content="2;index.php" http-equiv="refresh" />';
}
else{
echo '<div style="color: red; font-size: 18px;"><strong>These are the students in '.$cl.$arms. ' this '.$term.', '.$year.'. Select the ones you wish to enrol in your '.$subject.' class.</strong></div><br />';	
echo '<br>';

echo "<div class='rg-container'>";
echo "<div class='rg-content'>";
 echo '<input type="checkbox" class="checkboxx" id="select_all"/> Select All';
echo "<table class='rg-table zebra' summary='Hed'>";
echo "<caption class='rg-header'>";
//echo "<span class='rg-hed'>Hed</span>";
echo "</caption>";
echo "<thead>";
echo "<tr>";
echo "<th class='text '>Name</th>";
echo "<th class='text ' style='display: none;' >Teacher ID</th>";
echo "<th class='text ' style='display: none;' >Class</th>";
echo "<th class='text ' style='display: none;'>Arm</th>";
echo "<th class='text ' style='display: none;' >Subject</th>";
echo "<th class='text ' style='display: none;' >Year</th>";
echo "<th class='text ' style='display: none;'>Term</th>";
echo "</tr>";
echo "</thead>";
echo "<tbody>";
echo '<form id="formid">';
//echo '<form action="studentbyclass.php" method="post">';
foreach ($r as $key => $student_name) {
echo "<tr class=''>";
echo '<td class="text" data-title="Name"><input type="checkbox" class="checkboxx" name="student_name[]" value="'.$student_name.'" />'.$student_name.'</td>';
echo '<td class="text" data-title="teacher_id" style="display: none;" ><input type="hidden" name="teacher_id" value="'.$teacher_id.'" /></td>';
echo '<td class="text" data-title="class" style="display: none;" ><input type="hidden" name="class" value="'.$class.'" /></td>';
echo '<td class="text" data-title="arms" style="display: none;" ><input type="hidden" name="arms" value="'.$arms.'" /></td>';
echo '<td class="text" data-title="subject" style="display: none;" ><input type="hidden" name="subject" value="'.$subject.'" /></td>';
echo '<td class="text" data-title="year" style="display: none;" ><input type="hidden" name="year" value="'.$year.'" /></td>';
echo '<td class="text" data-title="term" style="display: none;" ><input type="hidden" name="term" value="'.$term.'" /></td>';
echo "</tr>";
}
echo "<tr class=''>";
echo '<td class="text" data-title="submit" colspan="6"><input style="background-color: green; color: white; width: 100px;" type="submit" name="submit" value="Submit" /></td>';
echo '</form>';
echo "</tr>";
echo "</tbody>";
echo "</table>";
echo "</div>";


echo '<span class="error" style="display:none; color: red;"><img src="table/del.jpg" width="60" height="60"/>Insertion could not be made.</span><span class="success" style="display:none; color: green;"><img src="table/492.png" width="60" height="60"/> student inserted successfully.</span>';

echo "</div>";
}
?>
<?php
include("footer.php");
?>

</body>
</html>