<?php
include("db.php");

if($_POST['id'])
{
$id=mysql_escape_String($_POST['id']);
$caname=mysql_escape_String($_POST['caname']);
$examname=mysql_escape_String($_POST['examname']);
$sql = "update maxes set caname='$caname',examname='$examname' where id='$id'";
mysql_query($sql);
}
?>