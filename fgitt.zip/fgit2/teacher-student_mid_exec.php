<?php
	session_start();
	include("auth.php");		
	include 'connection.php';
//$score = $_POST['score'];
$teacher_id = $_POST['teacher_id'];
$student_name = $_POST['student_name'];
$subject = $_POST['subject'];
$remark = $_POST['remark'];
$teacher_name = $_POST['teacher'];
$class_name = $_POST['class_name'];
$year = $_POST['year'];
$arms = $_POST['arms'];
$term = $_POST['term'];
$arms = $_POST['arms'];
$testmax = $_POST['testmax'];
$cwmax = $_POST['cwmax'];
$hwmax = $_POST['hwmax'];

$test2 = $_POST['test'];	
$cw2 = $_POST['cw'];
$hw2 = $_POST['hw'];


for ($i = 0; $i <= (count($student_name)-1); $i++){
	$scoreraw[$i] = $test2[$i]+$cw2[$i]+$hw2[$i];
    $t = mysqli_query($db,"INSERT INTO scoresmid(score,scoreraw,hwraw,cwraw,testraw,hw,cw,test,teacher_id,student_name,subject,remark,teacher_name,class_name,arms,year,term,hwmaxname,cwmaxname,testmaxname,school) VALUES(((('$hw2[$i]'/'$hwmax[$i]')*30)+(('$cw2[$i]'/'$cwmax[$i]')*30)+(('$test2[$i]'/'$testmax[$i]')*40)),'$scoreraw[$i]','$hw2[$i]','$cw2[$i]','$test2[$i]',(('$hw2[$i]'/'$hwmax[$i]')*30),(('$cw2[$i]'/'$cwmax[$i]')*30),(('$test2[$i]'/'$testmax[$i]')*40),'$teacher_id[$i]','$student_name[$i]','".ucfirst($subject[$i])."','$remark[$i]','$teacher_name[$i]','$class_name[$i]','$arms[$i]','$year[$i]','$term[$i]','$hwmax[$i]','$cwmax[$i]','$testmax[$i]','".$_SESSION["school"]."')");
    //$t = mysqli_query($db,"INSERT INTO scores(score,ca,exam,teacher_id,student_name,subject,remark,teacher_name,class_name,year,term,camaxname, exammaxname) VALUES('$score[$i]','$ca[$i]','$exam[$i]','$teacher_id[$i]','$student_name[$i]','".ucfirst($subject[$i])."','$remark[$i]','$teacher_name[$i]','$class_name[$i]','$year[$i]','$term[$i]','$camax[$i]','$exammax[$i]')");
}	
if($t){
echo 1;
}	
else{
echo 0;
}
?>

