<?php
include "connection.php";

$query = mysqli_query($db, "SELECT * FROM subjects ORDER BY subject ASC");
while($sql=mysqli_fetch_assoc($query)){
	echo $sql['subject'];
	echo "<br>";
}
?>