<?php
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
include('db.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Manage Admins</title>
<link rel="stylesheet" href="css/style.css" />
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
<script src="table/js/jquery.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js" type="text/javascript"></script>
<link rel="stylesheet" href="css/demo.css">
<link rel="stylesheet" href="css/footer-distributed.css">
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">


 <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
 <script type="text/javascript">
$(document).ready(function()
{
$(".edit_tr").click(function()
{
var ID=$(this).attr('id');
$("#status_"+ID).hide();
$("#status_input_"+ID).show();
}).change(function()
{
var ID=$(this).attr('id');
var status=$("#status_input_"+ID).val();
if(status>1){
	alert("enter a number 0 - 1");
	$("#status_input_"+ID).val("");
}
var dataString = 'teacher_id='+ ID +'&status='+status;
$("#status_"+ID).html('<img src="load.gif" />');
if(status.length>0)
{
$.ajax({
type: "POST",
url: "table_edit_ajax_admin.php",
data: dataString,
cache: false,
success: function(html)
{
$("#status_"+ID).html(status);
}
});
}
else
{
alert('Enter something.');
}
});
$(".editbox").mouseup(function() 
{
return false
});
$(document).mouseup(function()
{
$(".editbox").hide();
$(".text").show();
});
});
</script>

<script type="text/javascript">
$(document).ready(function(){
 $(".editbox").keypress(function (e) {
if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
	alert("Make sure it is a digit within the stipulated bounds.");
	return false;
}
});
});
</script>
<style>
body
{
font-family:Arial, Helvetica, sans-serif;
font-size:14px;
}
.editbox
{
display:none
}
td
{
padding:7px;
}
.editbox
{
font-size:14px;
width:80px;
background-color:#ffffcc;

border:solid 1px #000;
padding:4px;
}
.edit_tr:hover
{
background:url(edit.png) right no-repeat #80C8E5;
cursor:pointer;
}
th
{
font-weight:bold;
text-align:left;
padding:4px;
}
.head
{
background-color:#333;
color:#FFFFFF
}
</style>
</head>

<body>
<?php
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
elseif($_SESSION['role'] == 'student'){
include("headerstudent.php");
}
else{
header("location: logout.php");
}
?>
<center>
 <br><br><br><br>   
<div style="margin:0 auto; padding:10px; background-color:#fff; height: auto; width: 70%;">
<div style="width: 100%; color: red;">Manage Admins</div>
<?php
        $teacher_id = $_POST['teacher_id'];
		$role = $_POST['teacher'];
		$status = $_POST['status'];
//include "db.php";
$user = $_SESSION['username'];
$result11 = mysql_query("SELECT * FROM users2 where username='$user'");
while ($row11 = mysql_fetch_assoc($result11)) {
	$a[] = $rowt11['teacher_id'];
	$tname[] = $row11['teacher'];
}
$tid =  current($a);
$tna = current($tname);
$sqll = mysql_query("SELECT * FROM users2 where role='admin' AND school='".$_SESSION["school"]."' AND teacher!='$tna'");	
?>
<br><br>


<?php 
if(mysql_num_rows($sqll)>0){
?>
<span>Set status to 0 to deny access and 1 to allow access.</span>
<table style="width: 50%;">
<tr class="head">
<th>Admin Name</th><th>Status</th>
</tr>
<?php		
$i=1;
while($row=mysql_fetch_array($sqll))
{
$id=$row['teacher_id'];
$teacher=$row['teacher'];
$status=$row['status'];
if($i%2)
{
?>
<tr id="<?php echo $id; ?>" class="edit_tr">
<?php } else { ?>
<tr id="<?php echo $id; ?>" bgcolor="#f2f2f2" class="edit_tr">
<?php } ?>
<td width="10%" class="edit_td">
<span id="stu_<?php echo $id; ?>" class="text"><?php echo $teacher; ?></span>
<input type="text" value="<?php echo $teacher; ?>" class="editbox" id="stu_input_<?php echo $id; ?>" />
</td>
<td width="10%" class="edit_td">
<span id="status_<?php echo $id; ?>" class="text"><?php echo $status; ?></span>
<input type="text" value="<?php echo $status; ?>" class="editbox" id="status_input_<?php echo $id; ?>" />
</td>
</tr>
<?php
$i++;
}
?>
</table>
<?php
} //end of if sqll for updating
?>
</table>	
</center>
</div>
<br><br><br><br><br><br><br><br><br><br>
<?php
include("footer.php");
?>
</body>
</html>
