<?php
session_start();
include("auth.php");
include('db.php');
include("connection.php");
$resultsch = mysqli_query($db,"SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Edit FT Comment</title>
<style>
.pbutton {
	background-color:#44c767;
	-moz-border-radius:28px;
	-webkit-border-radius:28px;
	border-radius:2px;
	border:1px solid #18ab29;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:15px;
	padding:6px 12px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
	margin: auto;
	margin: auto;
}
.pbutton:hover {
	background-color:#5cbf2a;
}
.pbutton:active {
	position:relative;
	top:1px;
}
</style>
  <script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>
<script type="text/javascript" src="edittablejs.js"></script>

<script type="text/javascript">
$(document).ready(function()
{
$(".edit_tr").click(function()
{
var ID=$(this).attr('id');
$("#first_"+ID).hide();
$("#first_input_"+ID).show();
}).change(function()
{
var ID=$(this).attr('id');
var first=$("#first_input_"+ID).val();
var dataString = 'id='+ ID +'&firstname='+first;
$("#first_"+ID).html('<img src="load.gif" />');


if(first.length>0)
{
$.ajax({
type: "POST",
url: "table_edit_ajaxcomm.php",
data: dataString,
cache: false,
success: function(html)
{

$("#first_"+ID).html(first);
}
});
}
else
{
alert('Enter something.');
}

});

$(".editbox").mouseup(function() 
{
return false
});

$(document).mouseup(function()
{
$(".editbox").hide();
$(".text").show();
});
});
</script>
<style>
body
{
font-family:Arial, Helvetica, sans-serif;
font-size:14px;
}
.editbox
{
display:none
}
td
{
padding:2px;
}
.editbox
{
font-size:14px;
width:70%;
background-color:#ffffcc;
border:solid 1px #000;
padding: 0;
height: 100px;
}
.edit_tr:hover
{
background:url(edit.png) right no-repeat #80C8E5;
cursor:pointer;
}
th
{
font-weight:bold;
text-align:left;
padding:4px;
}
.head
{
background-color:#333;
color:#FFFFFF
}
  nav ul li ul li{
           float: left;   
        }
</style>
     
   <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
</head>

<body>
<?php
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
else{header("location: logout.php");}
?>
<br>
<center><br><br><br><br>
<div style='width: 100%; color: red; font-size: 16px; text-align: center;'>&nbsp;&nbsp;&nbsp;&nbsp;FORM TUTOR'S REMARKS</div>
<div style="margin:0 auto; padding:10px; background-color:#fff; height: auto; width: 100%;">
<?php
        $teacher_id = $_POST['teacher_id'];
		$teacher = $_POST['teacher'];
        $class = $_POST['class'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		$arms = $_POST['arms'];
		
		
//echo $teacher."-".$term."-".$class."-".$year."-".$arms;		
		
		
$user = $_SESSION['username'];
$result11 = mysqli_query($db,"SELECT * FROM users2 where username='$user' AND school='".$_SESSION["school"]."'");
while ($row11 = mysqli_fetch_assoc($result11)) {
	$a[] = $rowt11['teacher_id'];
	$tname[] = $row11['teacher'];
}
$tid =  current($a);
$tna = current($tname);
//echo $tna;

$resulttnamm = mysqli_query($db, "SELECT DISTINCT(formt) FROM attend where class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."' LIMIT 1");
while($rowtnamm = mysqli_fetch_assoc($resulttnamm))
{
$tnamm2 = $rowtnamm['formt'];
}
$tna = $teacher;
//echo $tna;

$sql2 = mysqli_query($db,"SELECT * FROM ftcomments where class='$class' AND year='$year' AND term='$term' AND formt='$tna' AND ppfirstname='$arms' AND school='".$_SESSION["school"]."' ORDER BY student_name ASC");
$sql1 = mysqli_query($db,"SELECT * FROM studentsbyclass where class='$class' AND year='$year' AND term='$term' AND formt='$tna' AND arms='$arms' AND school='".$_SESSION["school"]."' ORDER BY student_name ASC");

if($class=="Year 1"){
	if($ctype=="Js"){
	$cl = "JS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 1";
}else{
	$cl = "Year 1";
}
}
elseif($class=="Year 2"){
	if($ctype=="Js"){
	$cl = "JS2";
}elseif($ctype=="Primary"){
	$cl = "Primary 2";
}else{
	$cl = "Year 2";
}
}
elseif($class=="Year 3"){
	if($ctype=="Js"){
	$cl = "JS3";
}elseif($ctype=="Primary"){
	$cl = "Primary 3";
}else{
	$cl = "Year 3";
}
}
elseif($class=="Year 4"){
	if($ctype=="Js"){
	$cl = "SS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 4";
}else{
	$cl = "Year 4";
}
}
elseif($class=="Year 5"){
	if($ctype=="Js"){
	$cl = "SS2";
}elseif($ctype=="Primary"){
	$cl = "Primary 5";
}else{
	$cl = "Year 5";
}
}
elseif($class=="Year 6"){
	if($ctype=="Js"){
	$cl = "SS3";
}elseif($ctype=="Primary"){
	$cl = "Primary 6";
}else{
	$cl = "Year 6";
}
}
elseif($class=="Year 7"){
	if($ctype=="Js"){
	$cl = "JS1";
}else{
	$cl = "Year 7";
}
}
else if($class=="Year 8"){
	if($ctype=="Js"){
	$cl = "JS2";
}else{
	$cl = "Year 8";
}
}else if($class=="Year 9"){
	if($ctype=="Js"){
	$cl = "JS3";
}else{
	$cl = "Year 9";
}
}else if($class=="Year 10"){
	if($ctype=="Js"){
	$cl = "SS1";
}else{
	$cl = "Year 10";
}
}else if($class=="Year 11"){
	if($ctype=="Js"){
	$cl = "SS2";
}else{
	$cl = "Year 11";
}
}else if($class=="Year 12"){
	if($ctype=="Js"){
	$cl = "SS3";
}else{
	$cl = "Year 12";
}
}else{
	$cl = "NOT APPLICABLE";
}
echo "<br><div style='width: 100%; color: red; font-size: 16px;'>Comments for ".$cl." ".$arms." students in ".$term." of ".$year."/".($year+1)." session</div>";		
?>


<?php 
while($row2 = mysqli_fetch_assoc($sql2))
{  						
$valuesstname2[] = $row2['student_name']; //for the ftcomments table
}
//print_r($valuesstname2);
echo "<br>";
$countstnameftcomment = count($valuesstname2); //equiv of vtu
while($row2 = mysqli_fetch_assoc($sql1))
{  						
$valuesstname2stbyclass[] = $row2['student_name']; //for the studentsbyclass table
}
//print_r($valuesstname2stbyclass);
$countstnamestudentsbyclass = count($valuesstname2stbyclass); //equiv of vtuu


$r = array_diff($valuesstname2stbyclass, $valuesstname2); 
$vtuuu = $countstnamestudentsbyclass - $countstnameftcomment;

	if($countstnamestudentsbyclass == 0 && $countstnameftcomment == 0){
	echo "<span style='color:red; font-size:16px; text-decoration: underline;'>NO DATA!</span><br>";
}
else if($countstnameftcomment == 0){
$valuesstname2[] = "nothingham";
echo '<form action="tableeditajaxcomm2.php" method="post">';
echo '<table style="text-align: center; width: 66%;"><thead style="text-align: center;">';
echo '<tr style="text-align: center;">';
echo '<th style="text-align: center; width: 8%;">Student</th>';
echo '<th style="text-align: center; width: 20%;">Comment</th>';
echo '<th style="text-align: center; width: 8%; display: none;">Tutor</th>';
echo '<th style="text-align: center; width: 8%; display: none;">Class</th>';
echo '<th style="text-align: center; width: 8%; display: none;">Year</th>';
echo '<th style="text-align: center; width: 8%; display: none;">Term</th>';
echo '<th style="text-align: center; width: 8%; display: none;">Arm</th>';
echo '</tr></thead>';
$r = array_diff($valuesstname2stbyclass, $valuesstname2); 
foreach ($r as $key => $r['student_name']) {
echo '<tr style="border: 1px solid black;">';
echo '<td style="text-align: center; width: 8%;" class="suname"><input class="tdinput" style="display: none;" type="hidden" name="student_name[]" value="'.$r['student_name'].'" />'.$r['student_name'].'</td>';
echo '<td style="text-align: center; width: 20%;"><textarea class="tdinput" type="text"  name="firstname[]" id="firstname" ></textarea>';
echo '<td style="text-align: center; width: 8%; display: none;"><input class="tdinput" type="text"  name="formt[]" id="formt" value="'.$tna.'" />';
echo '<td style="text-align: center; width: 8%; display: none;"><input class="tdinput" type="text"  name="class[]" id="class" value="'.$class.'" /></td>';
echo '<td style="text-align: center; width: 8%; display: none;"><input class="tdinput" type="text"  name="year[]" id="year" value="'.$year.'" /></td>';
echo '<td style="text-align: center; width: 8%; display: none;"><input class="tdinput" type="text"  name="term[]" id="term" value="'.$term.'" /></td>';
echo '<td style="text-align: center; width: 8%; display: none;"><input class="tdinput" type="text"  name="arm[]" id="arm" value="'.$arms.'" /></td>';
echo '</tr>';
}
echo '<tr>';
echo '<td colspan="12"><input  name="submitftcomment" class="pbutton" type="submit" value="Submit Comments" /><a class="pbutton" href="ftcomments.php">back</a></td>';
echo '</tr>';
echo '</table>';
echo '</form>';		
}
else{	
?>	
<?php
//include("connection.php");	
$sql3 = mysqli_query($db,"SELECT * FROM ftcomments where class='$class' AND year='$year' AND term='$term' AND formt='$tna' AND ppfirstname='$arms' AND school='".$_SESSION["school"]."' ORDER BY student_name ASC");
while($rowin=mysqli_fetch_assoc($sql3))
{
$stname[]=$rowin['student_name'];
}
$a = count($valuesstname2stbyclass);
$b = count($stname);
$v = array_diff($valuesstname2stbyclass, $stname); 
if(count($v)>0){
echo '<form action="tableeditajaxcomm2.php" method="post">';
echo '<table style="text-align: center; width: 66%;"><thead style="text-align: center;">';
echo '<tr style="text-align: center;">';
echo '<th style="text-align: center; width: 8%;">Student</th>';
echo '<th style="text-align: center; width: 20%;">Comment</th>';
echo '<th style="text-align: center; width: 8%; display: none;">Tutor</th>';
echo '<th style="text-align: center; width: 8%; display: none;">Class</th>';
echo '<th style="text-align: center; width: 8%; display: none;">Year</th>';
echo '<th style="text-align: center; width: 8%; display: none;">Term</th>';
echo '<th style="text-align: center; width: 8%; display: none;">Arm</th>';
echo '</tr></thead>';
foreach ($v as $key => $v['student_name']) {
echo '<tr style="border: 1px solid black;">';
echo '<td style="text-align: center; width: 8%;" class="suname"><input class="tdinput" style="display: none;" type="hidden" name="student_name[]" value="'.$v['student_name'].'" />'.$v['student_name'].'</td>';
echo '<td style="text-align: center; width: 20%; height: 100px;"><textarea style="width: 100%; height: 100%;" class="tdinput" type="text"  name="firstname[]" id="firstname"></textarea>';
echo '<td style="text-align: center; width: 8%; display: none;"><input class="tdinput" type="text"  name="formt[]" id="formt" value="'.$tna.'" />';
echo '<td style="text-align: center; width: 8%; display: none;"><input class="tdinput" type="text"  name="class[]" id="class" value="'.$class.'" /></td>';
echo '<td style="text-align: center; width: 8%; display: none;"><input class="tdinput" type="text"  name="year[]" id="year" value="'.$year.'" /></td>';
echo '<td style="text-align: center; width: 8%; display: none;"><input class="tdinput" type="text"  name="term[]" id="term" value="'.$term.'" /></td>';
echo '<td style="text-align: center; width: 8%; display: none;"><input class="tdinput" type="text"  name="arm[]" id="arm" value="'.$arms.'" /></td>';
echo '</tr>';
}
echo '<tr>';
echo '<td colspan="12"><input  class="pbutton" type="submit" name="submitftcomment" value="Submit Comments" /></td>';
echo '</tr>';
echo '</table>';
echo '</form>';	
	}
else{
?>
<span>Click on a rectangle to input comment.</span>
<table style="width: 70%;">
<tr class="head">
<th>Student's Name</th><th>Comment</th>
</tr>
<?php	
$sql4 = mysqli_query($db,"SELECT * FROM ftcomments where class='$class' AND year='$year' AND term='$term' AND formt='$tna' AND ppfirstname='$arms' AND school='".$_SESSION["school"]."' ORDER BY student_name ASC");
$i=1;
while($rows=mysqli_fetch_array($sql4))
{
$id=$rows['id'];
$firstname=$rows['firstname'];
$stuname=$rows['student_name'];
if($i%2)
{
?>
<tr id="<?php echo $id; ?>" class="edit_tr">
<?php } else { ?>
<tr id="<?php echo $id; ?>" bgcolor="#f2f2f2" class="edit_tr">
<?php } ?>
<td width="10%" class="edit_td">
<span id="stu_<?php echo $id; ?>" class="text"><?php echo $stuname; ?></span>
<input type="text" value="<?php echo $stuname; ?>" class="editbox" id="stu_input_<?php echo $id; ?>" />
</td>
<td width="10%" class="edit_td">
<span id="first_<?php echo $id; ?>" class="text"><?php echo $firstname; ?></span>
<textarea style="width: 100%;" type="text" value="<?php echo $firstname; ?>" style="" class="editbox" id="first_input_<?php echo $id; ?>" /><?php echo $firstname; ?></textarea>
</td>
</tr>
<?php
$i++;
}
?>
</table>	
<?php	
}	
echo "<br><a class='pbutton' href='ftcomments.php'>back</a>";
}

?>
<?php
include("footer.php");
?>
</body>
</html>
