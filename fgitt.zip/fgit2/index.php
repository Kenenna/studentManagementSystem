<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start(); // this MUST be called prior to any output including whitespaces and line breaks!

$GLOBALS['DEBUG_MODE'] = 1;
// CHANGE TO 0 TO TURN OFF DEBUG MODE
// IN DEBUG MODE, ONLY THE CAPTCHA CODE IS VALIDATED, AND NO EMAIL IS SENT

$GLOBALS['ct_recipient']   = 'YOU@EXAMPLE.COM'; // Change to your email address!  Make sure DEBUG_MODE above is 0 for mail to send!
$GLOBALS['ct_msg_subject'] = 'Securimage Test Contact Form';

$GLOBALS['errmsg'] = " ";

process_si_contact_form(); // Process the form, if it was submitted
if (isset($_SESSION['ctform']['error']) &&  $_SESSION['ctform']['error'] == true): /* The last form submission had 1 or more errors */ ?>
<div class="error">There was a problem with your submission.  Errors are displayed below.</div><br>
<?php elseif (isset($_SESSION['ctform']['success']) && $_SESSION['ctform']['success'] == true): /* form was processed successfully */ ?>
<div class="success">The captcha was correct!</div><br />
<?php endif; ?>

<?php
function process_si_contact_form()
{
  $_SESSION['ctform'] = array(); // re-initialize the form session data

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  	// if the form has been submitted

    foreach($_POST as $key => $value) {
      if (!is_array($key)) {
      	// sanitize the input data
        if ($key != 'ct_message') $value = strip_tags($value);
        $_POST[$key] = htmlspecialchars(stripslashes(trim($value)));
      }
    }
    $captcha = @$_POST['ct_captcha']; // the user's entry for the captcha code
    $errors = array();  // initialize empty error array

    if (isset($GLOBALS['DEBUG_MODE']) && $GLOBALS['DEBUG_MODE'] == false) {
      // only check for errors if the form is not in debug mode
    }

    // Only try to validate the captcha if the form has no errors
    // This is especially important for ajax calls
    if (sizeof($errors) == 0) {
      require_once dirname(__FILE__) . '/securimage.php';
      $securimage = new Securimage();
      if ($securimage->check($captcha) == false) {
        $errors['captcha_error'] = 'Incorrect security code entered<br />';
      }
    }

    if (sizeof($errors) == 0) {
include("connection.php");
	    $role = $_POST['role'];
		//$teacher = $_POST['teacher'];
        $username = $_POST['username'];
        $password = $_POST['password'];
		$password = $password;
        $query = "SELECT * FROM `users2` WHERE role='$role' and username='$username' and password='".md5($password)."'";
		$result = mysqli_query($db,$query);
		$rows = mysqli_num_rows($result);
		if($rows==0){
		  $status = "none";  
		}else{
		  while($row = mysqli_fetch_assoc($result)){
			$status2[] = $row["status"];
		}
		$status = current($status2);  
		}
		
		if($status=="none"){
		  $rows==0;  
		}
	
        if($rows>=1){
			$_SESSION['username'] = $username;
			$_SESSION['role'] = $role;
			if(($role!="admin" && $role!="principal") || (($role=="admin" || $role=="principal")&& $status!=0)){
		header("Location: chooseschool.php"); // Redirect user to index
			}else{
			    $GLOBALS['errmsg'] = "account not approved";
			    //global $errmsg;
			    //$errmsg = "wrong username/password/role";
			   //header("Location: index.php"); // Redirect user to index 
			}
			}else{
			       $GLOBALS['errmsg'] = "wrong username/password/role"; 
			     //  global $errmsg2; 
			     //  $errmsg2 = "account not approved";
			 // header("Location: index.php"); // Redirect user to index  
			}

    } else {
      foreach($errors as $key => $error) {
      	// set up error messages to display with each field
        $_SESSION['ctform'][$key] = "<span class=\"error\">$error</span>";
      }
      $_SESSION['ctform']['error'] = false; // set error floag
    }
  } // POST
}
//$_SESSION['ctform']['success'] = false; // clear success value after running
?>

<!DOCTYPE html>
<html>
<head>
    <!-- ****** faviconit.com favicons ****** -->
	<link rel="shortcut icon" href="/favicon.ico">
	<link rel="icon" sizes="16x16 32x32 64x64" href="/favicon.ico">
	<link rel="icon" type="image/png" sizes="196x196" href="/favicon-192.png">
	<link rel="icon" type="image/png" sizes="160x160" href="/favicon-160.png">
	<link rel="icon" type="image/png" sizes="96x96" href="/favicon-96.png">
	<link rel="icon" type="image/png" sizes="64x64" href="/favicon-64.png">
	<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32.png">
	<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16.png">
	<link rel="apple-touch-icon" href="/favicon-57.png">
	<link rel="apple-touch-icon" sizes="114x114" href="/favicon-114.png">
	<link rel="apple-touch-icon" sizes="72x72" href="/favicon-72.png">
	<link rel="apple-touch-icon" sizes="144x144" href="/favicon-144.png">
	<link rel="apple-touch-icon" sizes="60x60" href="/favicon-60.png">
	<link rel="apple-touch-icon" sizes="120x120" href="/favicon-120.png">
	<link rel="apple-touch-icon" sizes="76x76" href="/favicon-76.png">
	<link rel="apple-touch-icon" sizes="152x152" href="/favicon-152.png">
	<link rel="apple-touch-icon" sizes="180x180" href="/favicon-180.png">
	<meta name="msapplication-TileColor" content="#FFFFFF">
	<meta name="msapplication-TileImage" content="/favicon-144.png">
	<meta name="msapplication-config" content="/browserconfig.xml">
	<!-- ****** faviconit.com favicons ****** -->
  <link rel="stylesheet" href="securimage.css" media="screen">   
<link href="table/css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
<link rel="stylesheet" type="text/css" href="table/css/DT_bootstrap.css">
<script src="table/js/jquery.js" type="text/javascript"></script>
<script src="table/js/bootstrap.js" type="text/javascript"></script>
<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/jquery.dataTables.js"></script>
<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/DT_bootstrap.js"></script>
 <link rel="stylesheet" href="css/style.css" />   
   <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>
<style>
ul.topnav {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}
ul.topnav li {float: left;}
ul.topnav li a {
    display: inline-block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    transition: 0.3s;
    font-size: 17px;
}
ul.topnav li a:hover {background-color: #555;}
ul.topnav li.icon {display: none;}

@media screen and (max-width:680px) {
  ul.topnav li:not(:first-child) {display: none;}
  ul.topnav li.icon {
    float: right;
    display: inline-block;
  }
}
@media screen and (max-width:680px) {
  ul.topnav.responsive {position: relative;}
  ul.topnav.responsive li.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  ul.topnav.responsive li {
    float: none;
    display: inline;
  }
  ul.topnav.responsive li a {
    display: block;
    text-align: left;
  }
}
</style>

<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>
</head>
<body>
 <ul class="topnav" id="myTopnav">
<li><a href="Registration.php">Sign Up</a></li>
<li class="icon">
<a href="javascript:void(0);" onclick="myFunction()">&#9776;</a>
</li>
</ul>  
<div class="form">
<h3>Log In</h3>
<?php
   echo $errmsg; 
?>
<form action="<?php echo htmlspecialchars($_SERVER['REQUEST_URI'] . $_SERVER['QUERY_STRING']) ?>" method="post" name="login">
    <input type="hidden" name="do" value="contact">
<select type="text" name="role"  required="" style="height: auto;" />
<option value="" disabled="disabled" selected="selected" >Pick A Role</option>
<option value="student" >student</option>
<option value="teacher" >teacher</option>
<option value="admin" >admin</option>
<option value="principal" >principal / head teacher</option>
</select><br>
<input type="text" name="username" placeholder="Username" required />
<input type="password" name="password" placeholder="Password" required />
<div>
    <?php
      // show captcha HTML using Securimage::getCaptchaHtml()
      require_once 'securimage.php';
      $options = array();
      $options['input_name'] = 'ct_captcha'; // change name of input element for form post
      $options['disable_flash_fallback'] = false; // allow flash fallback

      if (!empty($_SESSION['ctform']['captcha_error'])) {
        // error html to show in captcha output
        $options['error_html'] = '<div style="color: red;">'.$_SESSION['ctform']['captcha_error'].'</div>';
      }

      echo "<div id='captcha_container_1'>\n";
      echo Securimage::getCaptchaHtml($options);
      echo "\n</div>\n";
    ?>
  </div>
<input name="submit" type="submit" value="Login" />
</form>
<p>Not registered yet? <a href='registration.php'>Register Here</a></p>
<p>Forgot password? <a href='resetpass.php'>Get a new one</a></p>
</div>
<?php
include("footer.php");
?>
</body>
</html>
