<?php 
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
if(isset($_POST['submitnewft'])){
$classnewft = $_POST['classnew'];
$teacher_name_newft = $_POST['teacher_name_new'];
$yearnewft = $_POST['yearnew'];
$termnewft = $_POST['termnew'];
$armsnewft = $_POST['armsnew'];

$checkteachst = mysqli_query($db, "SELECT formt FROM subformt where formt='$teacher_name_newft' AND term='$termnewft' AND class='$classnewft' AND year='$yearnewft' AND arms='$armsnewft' AND school='".$_SESSION["school"]."'");
    if(mysqli_num_rows($checkteachst)==0){
	$querynewft = ("INSERT into `subformt`(class, arms, year, term, formt, school) VALUES ('$classnewft', '$armsnewft', '$yearnewft', '$termnewft', '$teacher_name_newft', '".$_SESSION["school"]."')");
        $resultnewft = mysqli_query($db,$querynewft);
        if($resultnewft){
            $msg = "<center><h3>Form Tutor was enrolled successfully.</h3></center>";
			$refres = '<meta content="2;adminaddformt.php" http-equiv="refresh" />';
        }else{
			$msg = "<center><h3>Form Tutor was NOT enrolled successfully.</h3></center>";
			$refres = '<meta content="2;adminaddformt.php" http-equiv="refresh" />';
		}
    }else{
        	$msg = "<center><h3>could NOT be enrolled because ".$teacher_name_newft." has already been enrolled.</h3></center>";
			$refres = '<meta content="2;adminaddformt.php" http-equiv="refresh" />';
    }
}

if(isset($_POST['submitnewno'])){
$refres = '<meta content="2;adminaddformt.php" http-equiv="refresh" />';
}


if(isset($_POST['submit2'])){
        $teacher_id = $_POST['teacher_id'];
		$teacher_name = $_POST['teacher_name'];
		$caaz = $_POST['class'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		$arms = $_POST['arms'];
		
		$class_name = $caaz;
		$caa2 = $caaz;
if($ctype=="Js"){
if($caa2 == "Year 7"){ $caa2 = "JS1";}
else if($caa2 == "Year 8"){ $caa2 = "JS2";}
else if($caa2 == "Year 9"){ $caa2 = "JS3";}
else if($caa2 == "Year 10"){ $caa2 = "SS1";}
else if($caa2 == "Year 11"){ $caa2 = "SS2";}
else if($caa2 == "Year 12"){ $caa2 = "SS3";}
else{}
}elseif($ctype=="Primary"){
if($caa2 == "Year 1"){ $caa2 = "Primary 1";}
else if($caa2 == "Year 2"){ $caa2 = "Primary 2";}
else if($caa2 == "Year 3"){ $caa2 = "Primary 3";}
else if($caa2 == "Year 4"){ $caa2 = "Primary 4";}
else if($caa2 == "Year 5"){ $caa2 = "Primary 5";}
else if($caa2 == "Year 6"){ $caa2 = "Primary 6";}
else{}
}else{
if($caa2 == "Year 7"){ $caa2 = "Year 7";}	
else if($caa2 == "Year 8"){ $caa2 = "Year 8";}
else if($caa2 == "Year 9"){ $caa2 = "Year 9";}
else if($caa2 == "Year 10"){ $caa2 = "Year 10";}
else if($caa2 == "Year 11"){ $caa2 = "Year 11";}
else if($caa2 == "Year 12"){ $caa2 = "Year 12";}
else{}
}
		
	$checkteach = mysqli_query($db, "SELECT * FROM formt where teacher_name='$teacher_name' AND term='$term' AND class_name='$class_name' AND year='$year' AND arms='$arms' AND school='".$_SESSION["school"]."'");
	$checkteach2 = mysqli_query($db, "SELECT * FROM formt where term='$term' AND class_name='$class_name' AND year='$year' AND arms='$arms' AND school='".$_SESSION["school"]."'");
	while($rowyr = mysqli_fetch_assoc($checkteach2))
							{ 
								$rowtutor2[] = $rowyr['teacher_name'];
							}
							$rowtutor = current($rowtutor2);
	
	$countteach = mysqli_num_rows($checkteach);
	$countteach2 = mysqli_num_rows($checkteach2);
	
	if($teacher_name == $rowtutor){
	  $msg = strtoupper($rowtutor)."HAS ALREADY BEEN ENROLLED AS FORM TUTOR FOR ".strtoupper($term).", ".strtoupper($caa2)." ".strtoupper($arms).", ".strtoupper($year)."-".($year+1)." SESSION";  
	}
	elseif($teacher_name != $rowtutor && $rowtutor!=""){
	$msg = strtoupper($rowtutor)."HAS ALREADY BEEN ENROLLED AS FORM TUTOR
		  FOR ".strtoupper($term).", ".strtoupper($caa2)." ".strtoupper($arms).
		  ", ".strtoupper($year)."-".($year+1)." SESSION<br><br>You can still enrol ".$teacher_name." as supplementary Form Tutor<br><br>"; 
		$msg .= "<form method='POST' action='' >";  
	   $msg .= "<input  style='display: none;' type='text' name='classnew' value='".$caaz."' />$caa2<br>";
		 $msg .= "<input style='display: none;' type='text' name='teacher_name_new' value='".$teacher_name."' />$teacher_name<br>";
		 $msg .= "<input style='display: none;' type='text' name='yearnew' value='".$year."' />$year<br>";
		 $msg .= "<input style='display: none;' type='text' name='termnew' value='".$term."' />$term<br>";
		 $msg .= "<input style='display: none;' type='text' name='armsnew' value='".$arms."' />$arms<br>";
		 $msg .= "<input type='submit' name='submitnewft' value='YES' />";
		 $msg .= "</form>";
		$msg .= "<form method='POST' action='' >";
		 $msg .= "<input type='submit' name='submitnewno' value='NO' />";
		 $msg .= "</form>";
	}
	elseif($countteach < 1){
	$query = ("INSERT into `formt` (teacher_id, teacher_name, class_name, year, term, arms, school) VALUES ('$teacher_id', '$teacher_name', '$class_name', '$year', '$term', '$arms', '".$_SESSION["school"]."')");
        $result = mysqli_query($db,$query);
        if($result){
            $msg = "<center><h3>Form Tutor was enrolled successfully.</h3></center>";
			$refres = '<meta content="2;adminaddformt.php" http-equiv="refresh" />';
        }
	}else{
	    $msg = "<center><h3>Form Tutor was NOT enrolled.</h3></center>";
	    $refres = '<meta content="2;adminaddformt.php" http-equiv="refresh" />'; }  
	}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Add Form Tutor</title>
<link rel="stylesheet" href="css/style.css" />
<link rel="stylesheet" href="css/style.css" />
	
        <link rel="stylesheet" type="text/css" href="table/css/DT_bootstrap.css">

	<script src="table/js/jquery.js" type="text/javascript"></script>
<script src="table/js/bootstrap.js" type="text/javascript"></script>
	
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/jquery.dataTables.js"></script>
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/DT_bootstrap.js"></script>
   
   <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
$("#class option").eq(7).css("display","none");
$("#subdbutton").on("click",function(){
var bb = $("#class").find(":selected").text();
var b = null;
if(bb=="Primary 1"){
	b = "Year 1";
}
else if(bb=="Primary 2"){
	b = "Year 2";
}
else if(bb=="Primary 3"){
	b = "Year 3";
}
else if(bb=="Primary 4"){
	b = "Year 4";
}
else if(bb=="Primary 5"){
	b = "Year 5";
}
else if(bb=="Primary 6"){
	b = "Year 6";
}
else if(bb=="JS1"){
	b = "Year 7";
}
else if(bb=="JS2"){
	b = "Year 8";
}
else if(bb=="JS3"){
	b = "Year 9";
}
else if(bb=="SS1"){
	b = "Year 10";
}
else if(bb=="SS2"){
	b = "Year 11";
}
else if(bb=="SS3"){
	b = "Year 12";
}
else{
	b = bb;
}
$("#class").find(":selected").val(b);
var c = $("#class").find(":selected").val();
//alert(c);
  });  
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>
   <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
</head>
<body>
<?php
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
else{header("location: logout.php");}
echo '<br>';
echo '<br>';
echo "<center>".$msg."</center>";
echo '<br>';
echo $refres;
?>
<br>

<?php
echo '<center>';
echo '<h5>CHECK IF FORM TUTOR IS REGISTERED</h5>';
echo '<form name="registration" action="" method="post">';
echo '<input type="text" name="teacher" placeholder="Teacher\'s Name" required />';
echo '<br><input type="submit" name="submit1" value="Check" />';
echo '</form>';
echo '</center>';
echo '<hr />';
if(isset($_POST['submit1'])){

$teacher = $_POST['teacher'];
$coun= "SELECT * FROM users2 WHERE teacher='$teacher' AND school='".$_SESSION["school"]."'";
if ($result=mysqli_query($db, $coun)){
$rowcount=mysqli_num_rows($result);
if($rowcount == 1){	
echo '<center><h5>Assign A Class To This Form Tutor</h5>';
echo '<form name="registration" action="" method="post">';
while($row = mysqli_fetch_assoc($result)){
echo '<input type="hidden" name="teacher_id" value="'.$row['teacher_id'].'" required />';
echo '<input type="text" style="display: none;" name="teacher_name" value="'.$row['teacher'].'" required /><span style="font-weight: bold; color: red; text-transform: uppercase;">'.$row['teacher'].'</span><br>';
}
?>
	<select style="width:210px;" name="class" id="class" required ><br>
                   
                    <?php
	$cccc = 0;
	$cccc2 = 0;	
	$result = mysqli_query($db, "SELECT * FROM classes");
						while($row = mysqli_fetch_assoc($result))
							{  
									echo '<option>';
								if($ctype=="Js"){
								if($cccc == 0){	
									$cccc++;
									echo 'SELECT A CLASS';
									continue;
									}		
								if($cccc <= 3){
								echo 'JS'.$cccc;	
								}
								elseif($cccc >= 4 && $cccc <= 6){
									if($cccc == 4){	
									$cccc++;
									echo 'SS'.($cccc2 - 2);	
									continue;
									}
									if($cccc == 5){	
									$cccc++;
									echo 'SS'.($cccc2 - 1);	
									continue;
									}
									if($cccc == 6){	
									$cccc++;
									echo 'SS'.($cccc2 - 0);	
									continue;
									}
								}else{
									break;
								}
								$cccc++;	
								$cccc2++;
									}
								else{	
								if($ctype=="Primary"){
									if($cccc == 0){	
									$cccc++;
									echo 'SELECT A CLASS';
									continue;
									}
								echo 'Primary '.$cccc;
								if($cccc > 5){
									break;
								}
								$cccc++;	
								}
								else{
								echo 'Year '.$cccc;
								if($cccc > 11){
									break;
								}
								$cccc++;	
								}
								}//end of else
								echo '</option>';
							}
						?>
      </select><br>
  <?php                 
echo '<select style="width: 210px; border-radius: 2px; height: auto; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="arms" class="arms" id="arms" required ><br>';


$resultarm = mysqli_query($db,"SELECT * FROM school where school='".$_SESSION["school"]."'");
				while($rowarm = mysqli_fetch_assoc($resultarm)){
					$arrr2[] = $rowarm["arms"];
				}
				$a = implode(',',$arrr2);
				$b = explode(',',$a);
				$f = (array_filter($b));

	for($i = 0; $i <= (count($f)-1); $i++){
								echo '<option value="'.$f[$i].'">';
								echo $f[$i];
								echo '</option>';
							}
echo '</select><br>';
echo '<select style="width: 210px; border-radius: 2px; height: auto; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="year" class="year" id="year" required >';

	$resultyr = mysqli_query($db, "SELECT * FROM years");
						while($rowyr = mysqli_fetch_assoc($resultyr))
							{  
								echo '<option value="'.$rowyr['year'].'">';
								echo $rowyr['year'];
								echo '</option>';
							}
echo '</select><br>';
echo '<select style="width: 210px; border-radius: 2px; height: auto; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="term" class="term" id="term" required >';

	$resulttm = mysqli_query($db, "SELECT * FROM terms");
						while($rowtm = mysqli_fetch_assoc($resulttm))
							{  
								echo '<option value="'.$rowtm['term'].'">';
								echo $rowtm['term'];
								echo '</option>';
							}
echo '</select>';
echo '<br><input type="submit" id="subdbutton" name="submit2" value="Assign" />';
echo '</form><br><br>';
echo '<br></center>';
}
else{
	echo "Teacher not registered yet.<br><br>";
}
}
}
include("footer.php");
?>
</body>