<?php
session_start();
include("auth.php"); 
include('db.php');
include("auth.php");
include "connection.php";
require 'class/ChartJS.php';
require 'class/ChartJS_Line.php';
require 'class/ChartJS_Bar.php';
require 'class/ChartJS_Radar.php';
require 'class/ChartJS_PolarArea.php';
require 'class/ChartJS_Pie.php';
require 'class/ChartJS_Doughnut.php';

$resultc = mysqli_query($db, "SELECT classtype FROM school where school='".$_SESSION["school"]."'");
						while($rowc = mysqli_fetch_assoc($resultc))
							{  
								$ctype2[] = $rowc['classtype'];
							}
							$ctype = current($ctype2);

ChartJS::addDefaultColor(array('fill' => '#f2b21a', 'stroke' => '#e5801d', 'point' => '#e5801d', 'pointStroke' => '#e5801d'));
ChartJS::addDefaultColor(array('fill' => 'rgba(28,116,190,.8)', 'stroke' => '#1c74be', 'point' => '#1c74be', 'pointStroke' => '#1c74be'));
ChartJS::addDefaultColor(array('fill' => 'rgba(212,41,31,.7)', 'stroke' => '#d4291f', 'point' => '#d4291f', 'pointStroke' => '#d4291f'));
ChartJS::addDefaultColor(array('fill' => '#dc693c', 'stroke' => '#ff0000', 'point' => '#ff0000', 'pointStroke' => '#ff0000'));
ChartJS::addDefaultColor(array('fill' => 'rgba(46,204,113,.8)', 'stroke' => '#2ecc71', 'point' => '#2ecc71', 'pointStroke' => '#2ecc71'));

$class = $_POST['class'];
$student_name = $_POST['student_name'];
$arms = $_POST['arms'];
$year = $_POST['year'];
$term = $_POST['term'];

//echo $ctype;
//echo $class;

if($ctype == "Js"){
 if($class=="Year 7"){ $clnamee="JS1"; }
 else if($class=="Year 8"){ $clnamee="JS2"; }
 else if($class=="Year 9"){ $clnamee="JS3"; }
 else if($class=="Year 10"){ $clnamee="SS1"; }
 else if($class=="Year 11"){ $clnamee="SS2"; }
 else{ $clnamee="SS3"; }
}elseif($ctype == "Primary"){
 if($class=="Year 1"){ $clnamee="Primary 1"; }
 else if($class=="Year 2"){ $clnamee="Primary 2"; }
 else if($class=="Year 3"){ $clnamee="Primary 3"; }
 else if($class=="Year 4"){ $clnamee="Primary 4"; }
 else if($class=="Year 5"){ $clnamee="Primary 5"; }
 else{ $clnamee="Primary 6"; }	
}
else{
	$clnamee = $class;
}
$array_values = array(array($_POST['redate'], $_POST['redate7'], $_POST["redate9"], $_POST["redate11"], $_POST["redate13"], $_POST["redate15"], $_POST["redate17"], $_POST["redate19"], $_POST["redate21"], $_POST["redate23"], $_POST["redate25"], $_POST["redate27"], $_POST["redate29"], $_POST["redate31"]), 
array($_POST["att1"], $_POST["att2"], $_POST["att3"], $_POST["att4"], $_POST["att5"], $_POST["att6"], $_POST["att7"], $_POST["att8"], $_POST["att9"], $_POST["att10"], $_POST["att11"], $_POST["att12"], $_POST["att13"], $_POST["att14"]));
$array_labels = array("WK1", "WK2", "WK3", "WK4", "WK5", "WK6", "WK7", "WK8", "WK9", "WK10", "WK11", "WK12", "WK13", "WK14");

$Line = new ChartJS_Line('example_line', 500, 500);
$Line->addLine($array_values[0]);
$Line->addLine($array_values[1]);
$Line->addLabels($array_labels);

$Bar = new ChartJS_Bar('example_bar', 1200, 470);
$Bar->addBars($array_values[0]);
$Bar->addBars($array_values[1]);
$Bar->addLabels($array_labels);


$Pie = new ChartJS_Pie('example_pie', 500, 500);
$Pie->addPart(65);
$Pie->addPart(59);
$Pie->addPart(80);
$Pie->addPart(81);
$Pie->addLabels($array_labels);

$Doughnut = new ChartJS_Doughnut('example_doughnut', 500, 500);
$Doughnut->addPart(65);
$Doughnut->addPart(59);
$Doughnut->addPart(80);
$Doughnut->addPart(81);
$Doughnut->addLabels($array_labels);

?>
<!DOCTYPE html>
<html>
<head>
    <title>Individual Attendance</title>
<style>
.myButton {
	background-color:#44c767;
	-moz-border-radius:28px;
	-webkit-border-radius:28px;
	border-radius:2px;
	border:1px solid #18ab29;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:14px;
	padding:4px 15px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
}
.myButton:hover {
	background-color:#5cbf2a;
}
.myButton:active {
	position:relative;
	top:1px;
}
</style>
<style>
ul.topnav {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}
ul.topnav li {float: left;}
ul.topnav li a {
    display: inline-block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    transition: 0.3s;
    font-size: 17px;
}
ul.topnav li a:hover {background-color: #555;}
ul.topnav li.icon {display: none;}

@media screen and (max-width:680px) {
  ul.topnav li:not(:first-child) {display: none;}
  ul.topnav li.icon {
    float: right;
    display: inline-block;
  }
}
@media screen and (max-width:680px) {
  ul.topnav.responsive {position: relative;}
  ul.topnav.responsive li.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  ul.topnav.responsive li {
    float: none;
    display: inline;
  }
  ul.topnav.responsive li a {
    display: block;
    text-align: left;
  }
}
</style>
  
   <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>

 <script src="gr2/js/jquery.js"></script>
    <script src="gr2/js/highchart.js"></script>
    <script src="gr2/js/exporting.js"></script>
    <script src="gr2/js/jspdf.js"></script>
    <script src="gr2/js/rgbcolor.js"></script>
    <script src="gr2/js/canvg.js"></script>
	
	 <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
</head>
<body>
<?php
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
elseif($_SESSION['role'] == 'student'){
include("headerstudent.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");
}
else{header("location: logout.php");}
?>
<br><br><br>
<h6><table style="width: 20%;"><tr>
<td style="background-color: #f2b21a;">NO OF TIMES <?php echo strtoupper($_POST['student_name']);  ?> WAS PRESENT</td><td style="background-color: rgba(61, 138, 190, 1); color: white;">NO OF TIMES SCH. WAS OPEN PER WEEK</td>
</tr></table></h6>
<?php
echo $Bar;
?>

<script src="Chart.js"></script>
<script src="chart.js-php.js"></script>
<script>
    (function () {
        loadChartJsPhp();
    })();
</script>
<br><br>
<form  style="margin: auto; float: left;" action="viewindatt.php" method="POST">
<input style="display: none;" type="text" name="student_name" value="<?php echo $_POST["student_name"]; ?>" />
<input style="display: none;" type="text" name="redate" value="<?php echo $_POST["redate"]; ?>" />
<input style="display: none;" type="text" name="att1" value="<?php echo $_POST["att1"]; ?>" />
<input style="display: none;" type="text" name="chmida" value="<?php echo $_POST["chmida"]; ?>" />
<input style="display: none;" type="text" name="redate7" value="<?php echo $_POST["redate7"]; ?>" />
<input style="display: none;" type="text" name="att2" value="<?php echo $_POST["att2"]; ?>" />
<input style="display: none;" type="text" name="chmidb" value="<?php echo $_POST["chmidb"]; ?>" />
<input style="display: none;" type="text" name="redate9" value="<?php echo $_POST["redate9"]; ?>" />
<input style="display: none;" type="text" name="att3" value="<?php echo $_POST["att3"]; ?>" />
<input style="display: none;" type="text" name="chmidc" value="<?php echo $_POST["chmidc"]; ?>" />
<input style="display: none;" type="text" name="redate11" value="<?php echo $_POST["redate11"]; ?>" />
<input style="display: none;" type="text" name="att4" value="<?php echo $_POST["att4"]; ?>" />
<input style="display: none;" type="text" name="chmidd" value="<?php echo $_POST["chmidd"]; ?>" />
<input style="display: none;" type="text" name="redate13" value="<?php echo $_POST["redate13"]; ?>" />
<input style="display: none;" type="text" name="att5" value="<?php echo $_POST["att5"]; ?>" />
<input style="display: none;" type="text" name="chmide" value="<?php echo $_POST["chmide"]; ?>" />
<input style="display: none;" type="text" name="redate15" value="<?php echo $_POST["redate15"]; ?>" />
<input style="display: none;" type="text" name="att6" value="<?php echo $_POST["att6"]; ?>" />
<input style="display: none;" type="text" name="chmidf" value="<?php echo $_POST["chmidf"]; ?>" />
<input style="display: none;" type="text" name="redate17" value="<?php echo $_POST["redate17"]; ?>" />
<input style="display: none;" type="text" name="att7" value="<?php echo $_POST["att7"]; ?>" />
<input style="display: none;" type="text" name="chmidg" value="<?php echo $_POST["chmidg"]; ?>" />
<input style="display: none;" type="text" name="redate19" value="<?php echo $_POST["redate19"]; ?>" />
<input style="display: none;" type="text" name="att8" value="<?php echo $_POST["att8"]; ?>" />
<input style="display: none;" type="text" name="chmidh" value="<?php echo $_POST["chmidh"]; ?>" />
<input style="display: none;" type="text" name="redate21" value="<?php echo $_POST["redate21"]; ?>" />
<input style="display: none;" type="text" name="att9" value="<?php echo $_POST["att9"]; ?>" />
<input style="display: none;" type="text" name="chmidi" value="<?php echo $_POST["chmidi"]; ?>" />
<input style="display: none;" type="text" name="redate23" value="<?php echo $_POST["redate23"]; ?>" />
<input style="display: none;" type="text" name="att10" value="<?php echo $_POST["att10"]; ?>" />
<input style="display: none;" type="text" name="chmidj" value="<?php echo $_POST["chmidj"]; ?>" />
<input style="display: none;" type="text" name="redate25" value="<?php echo $_POST["redate25"]; ?>" />
<input style="display: none;" type="text" name="att11" value="<?php echo $_POST["att11"]; ?>" />
<input style="display: none;" type="text" name="chmidk" value="<?php echo $_POST["chmidk"]; ?>" />
<input style="display: none;" type="text" name="redate27" value="<?php echo $_POST["redate27"]; ?>" />
<input style="display: none;" type="text" name="att12" value="<?php echo $_POST["att12"]; ?>" />
<input style="display: none;" type="text" name="chmidl" value="<?php echo $_POST["chmidl"]; ?>" />
<input style="display: none;" type="text" name="redate29" value="<?php echo $_POST["redate29"]; ?>" />
<input style="display: none;" type="text" name="att13" value="<?php echo $_POST["att13"]; ?>" />
<input style="display: none;" type="text" name="chmidm" value="<?php echo $_POST["chmidm"]; ?>" />
<input style="display: none;" type="text" name="redate31" value="<?php echo $_POST["redate31"]; ?>" />
<input style="display: none;" type="text" name="att14" value="<?php echo $_POST["att14"]; ?>" />
<input style="display: none;" type="text" name="chmidn" value="<?php echo $_POST["chmidn"]; ?>" />
<input style="display: none;" type="text" name="class" value="<?php echo $_POST['class']; ?>" />
<input style="display: none;" type="text" name="arms" value="<?php echo $_POST['arms']; ?>" />
<input style="display: none;" type="text" name="year" value="<?php echo $_POST['year']; ?>" />
<input style="display: none;" type="text" name="term" value="<?php echo $_POST['term']; ?>" />
<input style="display: none;" type="text" name="formt" value="<?php echo $_POST['formt']; ?>" />
<input style="display: none;" type="text" name="termbegin" value="<?php echo $_POST['termbegin']; ?>" />
<input class="myButton" type="submit" name="submit" value="Back" />
</form>
<button id="export_all" class="myButton" >Save as PDF</button>





<?php
$arrweekssss = array($_POST["att1"], $_POST["att2"], $_POST["att3"], $_POST["att4"], $_POST["att5"], $_POST["att6"], $_POST["att7"], $_POST["att8"], $_POST["att9"], $_POST["att10"], $_POST["att11"], $_POST["att12"], $_POST["att13"], $_POST["att14"]);
$arrmids = array($_POST["chmida"], $_POST["chmidb"], $_POST["chmidc"], $_POST["chmidd"], $_POST["chmide"], $_POST["chmidf"], $_POST["chmidg"], $_POST["chmidh"], $_POST["chmidi"], $_POST["chmidj"], $_POST["chmidk"], $_POST["chmidl"], $_POST["chmidm"], $_POST["chmidn"]);
$amid = (array_unique($arrmids));
unset($amid[0]);
foreach( $amid as $key => $valuemid){
	$k = $key;
	//$vmid = $valuemid;
}
$arrweekssss[$k] = 2020;
$arrweeks = $arrweekssss;

for ($i = 0; $i <= (count($arrweeks)-1); $i++){
	if($arrweeks[$i]==0){
	$arweeks[] = $i.":".$arrweeks[$i]; // the zeros
	}
	if($arrweeks[$i]!=0){
		if($arrweeks[$i]==2020){ $arrweeks[$i]=0; }
	$arweeks2[] = $arrweeks[$i];
	$arweeks22[] = $arrweeks[$i];	// the not zeros
	}
}
$arsweeks = $arweeks2;  // the not zeros
$arssweeks = $arweeks22;

$studattendddd = array($_POST['redate'], $_POST['redate7'], $_POST["redate9"], $_POST["redate11"], $_POST["redate13"], $_POST["redate15"], $_POST["redate17"], $_POST["redate19"], $_POST["redate21"], $_POST["redate23"], $_POST["redate25"], $_POST["redate27"], $_POST["redate29"], $_POST["redate31"]);
$studattendddd[$k] = 2020;
$studattend = $studattendddd;

for ($i = 0; $i <= (count($studattend)-1); $i++){
	if($studattend[$i]==0){
	$sweeks[] = $studattend[$i]; // the zeros
	}
	if($studattend[$i]!=0){
		if($studattend[$i]==2020){ $studattend[$i]=0; }
	$sweeks2[] = $studattend[$i]; // the not zeros
	}
}
$sweeks = $sweeks2;
$wkcount = count($arrweeks) - count($arweeks);

if($wkcount == 1){
	$wcount = array("WK1 (".$arssweeks[0]." )");
}
if($wkcount == 2){
	$wcount = array("WK1 (".$arssweeks[0]." )","WK2 (".$arssweeks[1]." )");
}
if($wkcount == 3){
	$wcount = array("WK1 (".$arssweeks[0]." )","WK2 (".$arssweeks[1]." )","WK3 (".$arssweeks[2]." )");
}
if($wkcount == 4){
	$wcount = array("WK1 (".$arssweeks[0]." )","WK2 (".$arssweeks[1]." )","WK3 (".$arssweeks[2]." )","WK4 (".$arssweeks[3]." )");
}
if($wkcount == 5){
	$wcount = array("WK1 (".$arssweeks[0]." )","WK2 (".$arssweeks[1]." )","WK3 (".$arssweeks[2]." )","WK4 (".$arssweeks[3]." )","WK5 (".$arssweeks[4]." )");
	}
if($wkcount == 6){
	$wcount = array("WK1 (".$arssweeks[0]." )","WK2 (".$arssweeks[1]." )","WK3 (".$arssweeks[2]." )","WK4 (".$arssweeks[3]." )","WK5 (".$arssweeks[4]." )","WK6 (".$arssweeks[5]." )");
}
if($wkcount == 7){
	$wcount = array("WK1 (".$arssweeks[0]." )","WK2 (".$arssweeks[1]." )","WK3 (".$arssweeks[2]." )","WK4 (".$arssweeks[3]." )","WK5 (".$arssweeks[4]." )","WK6 (".$arssweeks[5]." )","WK7 (".$arssweeks[6]." )");
}
if($wkcount == 8){
	$wcount = array("WK1 (".$arssweeks[0]." )","WK2 (".$arssweeks[1]." )","WK3 (".$arssweeks[2]." )","WK4 (".$arssweeks[3]." )","WK5 (".$arssweeks[4]." )","WK6 (".$arssweeks[5]." )","WK7 (".$arssweeks[6]." )","WK8 (".$arssweeks[7]." )");
}
if($wkcount == 9){
	$wcount = array("WK1 (".$arssweeks[0]." )","WK2 (".$arssweeks[1]." )","WK3 (".$arssweeks[2]." )","WK4 (".$arssweeks[3]." )","WK5 (".$arssweeks[4]." )","WK6 (".$arssweeks[5]." )","WK7 (".$arssweeks[6]." )","WK8 (".$arssweeks[7]." )","WK9 (".$arssweeks[8]." )");
}
if($wkcount == 10){
	$wcount = array("WK1 (".$arssweeks[0]." )","WK2 (".$arssweeks[1]." )","WK3 (".$arssweeks[2]." )","WK4 (".$arssweeks[3]." )","WK5 (".$arssweeks[4]." )","WK6 (".$arssweeks[5]." )","WK7 (".$arssweeks[6]." )","WK8 (".$arssweeks[7]." )","WK9 (".$arssweeks[8]." )","WK10 (".$arssweeks[9]." )");
}
if($wkcount == 11){
	$wcount = array("WK1 (".$arssweeks[0]." )","WK2 (".$arssweeks[1]." )","WK3 (".$arssweeks[2]." )","WK4 (".$arssweeks[3]." )","WK5 (".$arssweeks[4]." )","WK6 (".$arssweeks[5]." )","WK7 (".$arssweeks[6]." )","WK8 (".$arssweeks[7]." )","WK9 (".$arssweeks[8]." )","WK10 (".$arssweeks[9]." )","WK11 (".$arssweeks[10]." )");
}
if($wkcount == 12){
	$wcount = array("WK1 (".$arssweeks[0]." )","WK2 (".$arssweeks[1]." )","WK3 (".$arssweeks[2]." )","WK4 (".$arssweeks[3]." )","WK5 (".$arssweeks[4]." )","WK6 (".$arssweeks[5]." )","WK7 (".$arssweeks[6]." )","WK8 (".$arssweeks[7]." )","WK9 (".$arssweeks[8]." )","WK10 (".$arssweeks[9]." )","WK11 (".$arssweeks[10]." )","WK12 (".$arssweeks[11]." )");
}
if($wkcount == 13){
	$wcount = array("WK1 (".$arssweeks[0]." )","WK2 (".$arssweeks[1]." )","WK3 (".$arssweeks[2]." )","WK4 (".$arssweeks[3]." )","WK5 (".$arssweeks[4]." )","WK6 (".$arssweeks[5]." )","WK7 (".$arssweeks[6]." )","WK8 (".$arssweeks[7]." )","WK9 (".$arssweeks[8]." )","WK10 (".$arssweeks[9]." )","WK11 (".$arssweeks[10]." )","WK12 (".$arssweeks[11]." )","WK13 (".$arssweeks[12]." )");
}
if($wkcount == 14){
	$wcount = array("WK1 (".$arssweeks[0]." )","WK2 (".$arssweeks[1]." )","WK3 (".$arssweeks[2]." )","WK4 (".$arssweeks[3]." )","WK5 (".$arssweeks[4]." )","WK6 (".$arssweeks[5]." )","WK7 (".$arssweeks[6]." )","WK8 (".$arssweeks[7]." )","WK9 (".$arssweeks[8]." )","WK10 (".$arssweeks[9]." )","WK11 (".$arssweeks[10]." )","WK12 (".$arssweeks[11]." )","WK13 (".$arssweeks[12]." )","WK14 (".$arssweeks[13]." )");
}

$classs = $_POST['class'];
$arms = $_POST['arms'];
$term = $_POST['term'];
$year = $_POST['year'];
$year2 = $year+1;
if($ctype == "Js"){
 if($classs=="Year 7"){ $clnamee="JS1"; }
 else if($classs=="Year 8"){ $clnamee="JS2"; }
 else if($classs=="Year 9"){ $clnamee="JS3"; }
 else if($classs=="Year 10"){ $clnamee="SS1"; }
 else if($classs=="Year 11"){ $clnamee="SS2"; }
 else{ $clnamee="SS3"; }
}
if($ctype == "Primary"){
 if($classs=="Year 1"){ $clnamee="Primary 1"; }
 else if($classs=="Year 2"){ $clnamee="Primary 2"; }
 else if($classs=="Year 3"){ $clnamee="Primary 3"; }
 else if($classs=="Year 4"){ $clnamee="Primary 4"; }
 else if($classs=="Year 5"){ $clnamee="Primary 5"; }
 else{ $clnamee="Primary 6"; }
}
else{
	$clnamee = $classs;
}
?>

<div id="chart1" class="myChart" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
<script>
    $(document).ready(function() {
        // create canvas function from highcharts example http://jsfiddle.net/highcharts/PDnmQ/
        (function(H) {
            H.Chart.prototype.createCanvas = function(divId) {
                var svg = this.getSVG(),
                    width = parseInt(svg.match(/width="([0-9]+)"/)[1]),
                    height = parseInt(svg.match(/height="([0-9]+)"/)[1]),
                    canvas = document.createElement('canvas');

                canvas.setAttribute('width', width);
                canvas.setAttribute('height', height);

                if (canvas.getContext && canvas.getContext('2d')) {

                    canvg(canvas, svg);

                    return canvas.toDataURL("image/jpeg");

                } 
                else {
                    alert("Your browser doesn't support this feature, please use a modern browser");
                    return false;
                }

            }
        }(Highcharts));

        $('#export_all').click(function() {
            var doc = new jsPDF();

            // chart height defined here so each chart can be palced
            // in a different position
            var chartHeight = 80;

            // All units are in the set measurement for the document
            // This can be changed to "pt" (points), "mm" (Default), "cm", "in"
            doc.setFontSize(40);
            doc.text(35, 25, "");

            //loop through each chart
            $('.myChart').each(function(index) {
                var imageData = $(this).highcharts().createCanvas();

                // add image to doc, if you have lots of charts,
                // you will need to check if you have gone bigger 
                // than a page and do doc.addPage() before adding 
                // another image.
                doc.addImage(imageData, 'JPEG', 45, (index * chartHeight) + 40, 120, chartHeight);
            });


            //save with name
            doc.save('attendance.pdf');
        });
		var ctype = <?php echo json_encode($ctype); ?>;
		var rweek = <?php echo json_encode($wkcount); ?>;
		var classs = <?php echo json_encode($clnamee); ?>;
		var arms = <?php echo json_encode($arms); ?>;
		var year = <?php echo json_encode($year); ?>;
		var year2 = <?php echo json_encode($year2); ?>;
		var term = <?php echo json_encode($term); ?>;
		var schoool = <?php echo json_encode($_SESSION['school']); ?>;
		//alert(year+year2);
		//alert(ctype+"-"+classs);
		var clnamee = "";
		if(ctype=="Js"){
 if(classs=="Year 7"){ clnamee="JS1"; }
 else if(classs=="Year 8"){ clnamee="JS2"; }
 else if(classs=="Year 9"){ clnamee="JS3"; }
 else if(classs=="Year 10"){ clnamee="SS1"; }
 else if(classs=="Year 11"){ clnamee="SS2"; }
 else{clnamee="SS3";}	
		}
else if(ctype == "Primary"){
 if(classs=="Year 1"){ clnamee="Primary 1"; }
 else if(classs=="Year 2"){ clnamee="Primary 2"; }
 else if(classs=="Year 3"){ clnamee="Primary 3"; }
 else if(classs=="Year 4"){ clnamee="Primary 4"; }
 else if(classs=="Year 5"){ clnamee="Primary 5"; }
 else{ clnamee="Primary 6"; }
}
else{
clnamee=classs;	
}
		var student_name = <?php echo json_encode($student_name); ?>;
		if(rweek == 1){
		var w = <?php echo json_encode($wcount); ?>;
		}
		if(rweek == 2){
		var w = <?php echo json_encode($wcount); ?>;
		}
		if(rweek == 3){
		var w = <?php echo json_encode($wcount); ?>;
		}
		if(rweek == 4){
		var w = <?php echo json_encode($wcount); ?>;
		}
		if(rweek == 5){
		var w = <?php echo json_encode($wcount); ?>;
		}
		if(rweek == 6){
		var w = <?php echo json_encode($wcount); ?>;
		}
		if(rweek == 7){
		var w = <?php echo json_encode($wcount); ?>;
		}
		if(rweek == 8){
		var w = <?php echo json_encode($wcount); ?>;
		}
		if(rweek == 9){
		var w = <?php echo json_encode($wcount); ?>;
		}
		if(rweek == 10){
		var w = <?php echo json_encode($wcount); ?>;
		}
		if(rweek == 11){
		var w = <?php echo json_encode($wcount); ?>;
		}
		if(rweek == 12){
		var w = <?php echo json_encode($wcount); ?>;
		}
		if(rweek == 13){
		var w = <?php echo json_encode($wcount); ?>;
		}
		if(rweek == 14){
		var w = <?php echo json_encode($wcount); ?>;
		}
		var getthevalues = <?php echo json_encode($sweeks); ?>;
		var getthetots = <?php echo json_encode($arssweeks); ?>;
		var arvals = JSON.parse("[" + getthevalues + "]");
		
        $('#chart1').highcharts({
            navigation: {
                buttonOptions: {
                    enabled: false
                }
            },
            title: {
                text: 'ATTENDANCE CHART FOR '+student_name.toUpperCase()+' OF '+clnamee.toUpperCase()+' '+arms.toUpperCase(),
                x: -20 //center
            },
            subtitle: {
                text: term.toUpperCase()+', '+year+'/'+year2+' SESSION',
                x: -20
            },
            xAxis: {
                categories: w
            },
            yAxis: {
                title: {
                    text: 'attendance (no of times per week)'
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                valueSuffix: ''
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle',
                borderWidth: 0
            },
            series: [{
					  name: student_name,
					  data: arvals
					}]
        });
		});
		 </script>
		 <?php
		 include("footer.php");
		 ?>
</body>
</html>
