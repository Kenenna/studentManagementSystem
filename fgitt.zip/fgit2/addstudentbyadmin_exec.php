<?php
session_start();
include("auth.php"); //include auth.php file on all secure pages
        $student_name = $_POST['student_name'];
        $sex = $_POST['sex'];
		$caaz = $_POST['caa'];
		$yoa = $_POST['yoa'];
		$admno = $_POST['admno'];
		$reason = $_POST['reason'];
		$dob = $_POST['dob'];
		$house = $_POST['house'];
		
	if($caaz=='Primary 1'){
		$caa = 'Year 1';
	}
	elseif($caaz=='Primary 2'){
		$caa = 'Year 2';
	}
	elseif($caaz=='Primary 3'){
		$caa = 'Year 3';
	}
	elseif($caaz=='Primary 4'){
		$caa = 'Year 4';
	}
	elseif($caaz=='Primary 5'){
		$caa = 'Year 5';
	}	
	elseif($caaz=='Primary 6'){
		$caa = 'Year 6';
	}	
	else{
		$caa = $caaz;
	}	
		
		
  include "connection.php";
  
  $checkstu = mysqli_query($db, "SELECT * FROM regstu WHERE student_name='$student_name' AND sex='$sex' AND caa='$caa' AND yoa='$yoa' AND school='".$_SESSION["school"]."'");
  $countstu = mysqli_num_rows($checkstu);
  if($countstu < 1){
 $sql= mysqli_query($db,"INSERT INTO regstu(student_name, sex, caa, yoa, admno, reason, dob, house, school) VALUES('$student_name', '$sex', '$caa', '$yoa', '$admno', '$reason', '$dob', '$house', '".$_SESSION["school"]."')");
 $sql2=mysqli_query($db,"INSERT INTO img(student_name,img,house,school) VALUES('$student_name','images/av.jpg','$house','".$_SESSION["school"]."')"); 
	 echo 1;
	 }
	 else{
		 echo 0;
	 }
	//echo $student_name."-".$sex."-".$caa."-".$yoa."-".$admno."-".$reason."-".$dob."-".$house;
  //echo $student_name."-".$sex;
?>