<?php
$year = $_POST['year'];
$teacher_name = $_POST['teacher_name'];
$house = $_POST['house'];
$class = $_POST['classs'];
$school = $_POST['school'];
include "connection.php";

$result = mysqli_query($db, "SELECT * FROM studentsbyclass where year='$year'");

echo "<div class='rg-container'>";
echo "<div class='rg-content'>";
echo "<table class='rg-table zebra' summary='Hed'>";
echo "<caption class='rg-header'>";
//echo "<span class='rg-hed'>Hed</span>";
echo "</caption>";
echo "<thead>";
echo "<tr>";
echo "<th class='text' style='display: none;'>id</th>";
echo "<th class='text' >Student Name</th>";
echo "<th class='text' style='display: none;'>House Parent Name</th>";
echo "<th class='text' style='display: none;'>Class</th>";
echo "<th class='text' >Year</th>";
echo "<th class='text' >Term</th>";
echo "<th class='text' style='display: none;'>House</th>";
echo "</tr>";
echo "</thead>";
echo "<tbody>";
echo '<form id="formid">';
while($rowtid = mysqli_fetch_assoc($result))
{
echo "<tr class=''>";
echo '<td class="text" style="display: none;" data-title="id" ><input name="id" value="'.$rowtid['id'].'" /></td>';
echo '<td class="text" data-title="Name"><input type="text" name="student_name[]" value="'.$rowtid['student_name'].'" /></td>';
echo '<td class="text" style="display: none;" data-title="houseparent" ><input name="houseparent" value="'.$teacher_name.'" /></td>';
echo '<td class="text" style="display: none;" data-title="class" ><input name="class" value="'.$rowtid['class'].'" /></td>';
echo '<td class="text" data-title="year" ><input name="year" value="'.$rowtid['year'].'" /></td>';
echo '<td class="text" data-title="term"  ><input name="term" value="'.$rowtid['term'].'" /></td>';
echo '<td class="text" style="display: none;" data-title="house" ><input name="house" value="'.$rowtid['house'].'" /></td>';
echo '<td class="text" data-title="hpcomment"  ><textarea name="hpcomment" value="'.$rowtid['hpcomment'].'" />'.$rowtid['hpcomment'].'</textarea></td>';
echo "</tr>";
}
echo "<tr class=''>";
echo '<td class="text" data-title="submit" colspan="4"><input style="background-color: green; color: white; width: 100px;" type="submit" name="submit" value="Submit" /></td>';
echo "</tr>";
echo '</form>';
echo "</tbody>";
echo "</table>";
echo "</div>";
echo "</div>";
?>