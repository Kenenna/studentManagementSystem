<?php 
include("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
<link href="table/css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
<link rel="stylesheet" type="text/css" href="table/css/DT_bootstrap.css">
<script src="table/js/jquery.js" type="text/javascript"></script>
<script src="table/js/bootstrap.js" type="text/javascript"></script>
<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/jquery.dataTables.js"></script>
<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/DT_bootstrap.js"></script>


 <script>
function confirmationDelete(anchor)
{
   var conf = confirm('Are you sure want to delete this record?');
   if(conf)
      window.location=anchor.attr("href");
}
</script> 



 <style>
form {
  background: -webkit-linear-gradient(bottom, #CCCCCC, #EEEEEE 175px);
  background: -moz-linear-gradient(bottom, #CCCCCC, #EEEEEE 175px);
  background: linear-gradient(bottom, #CCCCCC, #EEEEEE 175px);
  margin: auto;
  position: relative;
  width: 60%;
  height: 350px;
  font-family: Tahoma, Geneva, sans-serif;
  font-size: 12px;
  font-style: italic;
  line-height: 24px;
  font-weight: bold;
  color: #09C;
  text-decoration: none;
  border-radius: 10px;
  padding: 10px;
  border: 1px solid #999;
  border: inset 1px solid #333;
  -webkit-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  -moz-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
}


input {
  width: 50%;
  display: block;
  border: 1px solid #999;
  height: 20px;
  -webkit-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  -moz-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
}

select {
  width: 50%;
  display: block;
  border: 1px solid #999;
  height: 30px;
  -webkit-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  -moz-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
}

select#upload {
  width: 140px;
  height: 30px;
  display: block;
}

.button {
  width: 100px;
  position: absolute;
  right: 20px;
  bottom: 20px;
  background: #09C;
  color: #fff;
  font-family: Tahoma, Geneva, sans-serif;
  height: 30px;
  border-radius: 15px;
  border: 1p solid #999;
}

input.button:hover {
  background: #fff;
  color: #09C;
}

select:focus, input:focus {
  border: 1px solid #09C;
}
</style>     
        






</head>
<body>
<p>Welcome <?php echo $_SESSION['username']; ?>!</p>





<div class="row-fluid" style="width:100%;">
	        <div class="span12">
	            <div class="container" style="width:100%;">
				
		<table style="width:100%; float:left;"cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
				
			<thead><tr>
			<th>Student</th><th>Honesty</th><th>Attentiveness</th><th>Cooperation</th><th>Edit</th><th>Delete</th>
			</thead></tr>
<?php
include "connection.php";
$user = $_SESSION['username'];
$result1 = mysqli_query($db, "SELECT * FROM users2 where username='$user'");
while ($row1 = mysqli_fetch_assoc($result1)) {
	$valteacher[] = $row1['teacher'];
}
$valteach = current($valteacher);




if(isset($_POST['btn-upload'])){
        $teacher_id = $_POST['teacher_id'];
		$teacher = $_POST['teacher'];
        $class = $_POST['class'];
		$year = $_POST['year'];
		$term = $_POST['term'];

$result = mysqli_query($db, "SELECT * FROM affective where class='$class' AND year='$year' AND term='$term' AND formt='$valteach'");
while ($row = mysqli_fetch_assoc($result)) {
	echo '<tr>';
echo '<td><input readonly="readonly" type="text" id="student_name" name="student_name[]" value="'.$row['student_name'].'" /></td>';	
echo '<td><input readonly="readonly" type="text" id="honesty" name="honesty[]" value="'.$row['Honesty'].'" /></td>';
echo '<td><input readonly="readonly" type="text" id="attentiveness" name="attentiveness[]" value="'.$row['Attentiveness'].'" /></td>';
echo '<td><input readonly="readonly" type="text" id="cooperation" name="cooperation[]" value="'.$row['Cooperation'].'" /></td>';
echo '<td><a href="updateaffective.php?id='.$row['id'].'">EDIT</a></td>';
echo '<td><a onClick="javascript:confirmationDelete($(this));return false;" href="delclass.php?id='.$row['id'].'">DELETE</a></td>';
'</tr>';
}
}
?>
</table>
</div></div></div>
<br>
<a href="teacher-student.php">Add scores</a><br>
<a href="update-score.php">Update scores</a><br>
<a href="index.php">Classes you teach</a><br>
<a href="formclasses.php">See the classes you are form tutor for</a><br>
<a href="logout.php">Logout</a><br>
 </body>
</html>
