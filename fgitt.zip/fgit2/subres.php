<?php
require 'class/ChartJS.php';
require 'class/ChartJS_Line.php';
require 'class/ChartJS_Bar.php';
require 'class/ChartJS_Radar.php';
require 'class/ChartJS_PolarArea.php';
require 'class/ChartJS_Pie.php';
require 'class/ChartJS_Doughnut.php';

$su = $_POST['arsubj'];
$cc = $_POST['fir2'];
$dd = $_POST['sec2'];
$tt = $_POST['thir2'];
$av = $_POST['avv2'];
$ccav = $_POST['ccavv2'];
$grade = $_POST['grad2'];
$tn = $_POST['teacher2'];
$re = $_POST['remark2'];
$student_name = $_POST['student_name2'];
$class_name = $_POST['class_name2'];
$year = $_POST['year2'];
$term = $_POST['term2'];

ChartJS::addDefaultColor(array('fill' => '#f2b21a', 'stroke' => '#e5801d', 'point' => '#e5801d', 'pointStroke' => '#e5801d'));
ChartJS::addDefaultColor(array('fill' => 'rgba(28,116,190,.8)', 'stroke' => '#1c74be', 'point' => '#1c74be', 'pointStroke' => '#1c74be'));
ChartJS::addDefaultColor(array('fill' => 'rgba(212,41,31,.7)', 'stroke' => '#d4291f', 'point' => '#d4291f', 'pointStroke' => '#d4291f'));
ChartJS::addDefaultColor(array('fill' => '#dc693c', 'stroke' => '#ff0000', 'point' => '#ff0000', 'pointStroke' => '#ff0000'));
ChartJS::addDefaultColor(array('fill' => 'rgba(46,204,113,.8)', 'stroke' => '#2ecc71', 'point' => '#2ecc71', 'pointStroke' => '#2ecc71'));

$array_values = array($cc, $dd, $av, $ccav);
$array_labels = $su;

$Bar = new ChartJS_Bar('example_bar', 1100, 500);
$Bar->addBars($array_values[0]);
$Bar->addBars($array_values[1]);
$Bar->addBars($array_values[2]);
$Bar->addBars($array_values[3]);
$Bar->addLabels($array_labels);

?>
<!DOCTYPE html>
<html>
<head>
    <title>Chart.js-PHP</title>
</head>
<body>
<h6><table style="width: 20%;"><tr>
<td style="background-color: #f2b21a;">1st Term Score</td><td style="background-color: rgba(61, 138, 190, 1); color: white;">2nd Term Score</td>
<td style="background-color: rgba(212,41,31,.7); color: white;">3rd Term Score (Cumulative)</td>
<td style="background-color: #dc693c; color: white;">Average Score of Students in Class</td>
</tr></table></h6>
<?php
echo $Bar
?>
<script src="Chart.js"></script>
<script src="chart.js-php.js"></script>
<script>
    (function () {
        loadChartJsPhp();
    })();
</script>

<form action="getresult.php" method="POST">
<?php
$i = 0;
foreach($su as $su2)
{
  echo '<input  name="su2[]" value="'.$su2.'">';
  $i++;
}
?>
<?php
$i = 0;
foreach($cc as $cc2)
{
  echo '<input  name="cc2[]" value="'.$cc2.'">';
  $i++;
}
?>
<?php
$i = 0;
foreach($dd as $dd2)
{
  echo '<input  name="dd2[]" value="'.$dd2.'">';
  $i++;
}
?>
<?php
$i = 0;
foreach($tt as $tt2)
{
  echo '<input  name="tt2[]" value="'.$tt2.'">';
  $i++;
}
?>
<?php
$i = 0;
foreach($av as $av2)
{
  echo '<input  name="av2[]" value="'.$av2.'">';
  $i++;
}
?>
<?php
$i = 0;
foreach($ccav as $ccav2)
{
  echo '<input  name="ccav2[]" value="'.$ccav2.'">';
  $i++;
}
?>
<?php
$i = 0;
foreach($grade as $grade2)
{
  echo '<input  name="grade2[]" value="'.$grade2.'">';
  $i++;
}
?>
<?php
$i = 0;
foreach($tn as $tn2)
{
  echo '<input  name="tn2[]" value="'.$tn2.'">';
  $i++;
}
?>
<?php
$i = 0;
foreach($re as $re2)
{
  echo '<input  name="re2[]" value="'.$re2.'">';
  $i++;
}
echo '<input  name="student_name" type="text" value="'.$student_name.'">';
echo '<input  name="class_name" type="text" value="'.$class_name.'">';
echo '<input  name="year" type="text" value="'.$year.'">';
echo '<input  name="term" type="text" value="'.$term.'">';
?>
<input class="myButton" type="submit" name="submittoresult" value="Back" />
</form>
</body>
</html>
