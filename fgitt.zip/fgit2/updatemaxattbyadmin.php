<?php 
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Update Teacher</title>
<link rel="stylesheet" href="css/style.css" />
        <link rel="stylesheet" type="text/css" href="table/css/DT_bootstrap.css">

	<script src="table/js/jquery.js" type="text/javascript"></script>
<script src="table/js/bootstrap.js" type="text/javascript"></script>
	
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/jquery.dataTables.js"></script>
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/DT_bootstrap.js"></script>
   
   <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>
<style>
select{
	height: auto;
}
</style>
 <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
<style>
form {
  background: -webkit-linear-gradient(bottom, #CCCCCC, #EEEEEE 175px);
  background: -moz-linear-gradient(bottom, #CCCCCC, #EEEEEE 175px);
  background: linear-gradient(bottom, #CCCCCC, #EEEEEE 175px);
  position: relative;
  width: 380px;
  height: 400px;
  font-family: Tahoma, Geneva, sans-serif;
  font-size: 16px;
  font-style: italic;
  line-height: 24px;
  font-weight: bold;
  color: #09C;
  text-decoration: none;
  border-radius: 10px;
  padding: 10px;
  border: 1px solid #999;
  border: inset 1px solid #333;
  -webkit-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  -moz-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
}


input {
  width: 30%;
  display: block;
  border: 1px solid #999;
  height: 15px;
  -webkit-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  -moz-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  text-align: center; 
}

select#upload {
  width: 140px;
  height: 30px;
  display: block;
}

.button {
  width: 200px;
  bottom: 10px;
  top: 180px;
  background: #09C;
  float: center;
  color: #fff;
  font-family: Tahoma, Geneva, sans-serif;
  height: 50px;
  border-radius: 15px;
  border: 1p solid #999;
}

input.button:hover {
  background: #fff;
  color: #09C;
}

select:focus, input:focus {
  border: 1px solid #09C;
}
</style> 
</head>
<body>
<?php
$resultrole2 = mysqli_query($db, "SELECT role, adminlevel FROM users2 where username='".$_SESSION['username']."'");
while($rowrole2 = mysqli_fetch_assoc($resultrole2))
{
	$arole[] = $rowrole2['role'];
	$adminlevel2[] = $rowrole2['adminlevel'];
}
$_SESSION['role'] =  current($arole);
$_SESSION['adminlevel'] =  current($adminlevel2);
if($_SESSION['role'] == 'teacher'){
	?>
<?php
include("header.php");
?>
<?php
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");
}
elseif($_SESSION['role'] == 'student'){
include("headerstudent.php");
}
else{header("location: logout.php");}
?>
<?php
include "connection.php";
$id = $_GET['id'];
$query1 = mysqli_query($db, "select * from maxattname where id=$id");
while ($row1 = mysqli_fetch_array($query1)) {
echo '<center><br><br><br>';
echo '<br><br><form action="updatemaxattbyadmin_exec.php" method="post" enctype="multipart/form-data">';
echo '<div>';
echo '<h5>Edit Max Attendance Figure :</h5>';
echo '<label>';
echo  '<input id="id" type="hidden" name="id" value="'.$row1['id'].'" />';
echo  '</label>';
  echo '<label>';
echo  '<input id="maxattname" type="text" name="maxattname" value="'.$row1['maxattname'].'" />';
echo '</label>';
 echo '<label>';
echo  '<input id="year" type="text" name="year" value="'.$row1['year'].'" />';
echo '</label>';
 echo '<label>';
echo  '<input id="term" type="text" name="term" value="'.$row1['term'].'" />';
echo '</label>';
echo '<label>';
 echo   '<input type="submit" class="button" name="btn-upload" value="Submit Form" />';
  echo  '</label>';
echo '</div>';
echo '</form><br>';
}
echo '</center>';
include("footer.php");
?>

</body>
</html>