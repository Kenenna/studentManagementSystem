<?php 
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Pincipal students</title>
<link rel="stylesheet" href="style.css" type="text/css" />
 <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
	<script src="table/js/jquery.js" type="text/javascript"></script>
<style>
select{
	height: auto;
}
nav li ul li{
    z-index: 1000;
    float: left;
}
#example{
    text-align: center;
}
</style>
  <script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>
<script>
		$(document).ready(function() {	
		$("#formid").submit(function( event ) {
			event.preventDefault();	
$.ajax({
type: "POST",
url: "addprcomment_exec.php",
data: $("#formid").serializeArray(),	
success: function(response){
 if(response==1) { 
		event.preventDefault();
		$(".success").fadeIn();
		setTimeout(function() { $(".success").fadeOut(); }, 2000);
		$("#backtogetclass").fadeIn();	
    } else {
		 $(".error").show();
		setTimeout(function() { $(".error").fadeOut(); }, 2000);
		$("#backtogetclass").fadeIn();
		}
		}
});	
});	 
});
</script>
<script>
$(document).ready(function() {
 $( ".checkSingle" ).click(function(ee){
	 ee.preventDefault();	
	   var chatt = this.id;
	var student_name = $('[id=sn_'+chatt+']').val();  
	var classs = $('[id=cl_'+chatt+']').val(); 
	var year = $('[id=yr_'+chatt+']').val();
	var term = $('[id=tm_'+chatt+']').val();
	var prc = $('[id=pr_'+chatt+']').val();
	if ($('[id=pr_'+chatt+']').hasClass("prclass")) {
	$('[id=pr_'+chatt+']').text(prc);
	 }
	 else if ($('[id=pr_'+chatt+']').hasClass("prclass2")) {
	$('[id=pr_'+chatt+']').text(prc);
	 }
	var ttt = $('[id=pr_'+chatt+']').toggleClass('prclass prclass2').val();
	//alert(ttt);
	$('.fullcommspan').text(student_name);
	$('.fullcomm').val(ttt);
	$('.fullcommid').val(chatt);
	$(".fullcommdiv").fadeIn();
	$('[id=pr_'+chatt+']').hide();
	dataString = 'student_name='+student_name+'&class='+classs+'&year='+year+'&term='+term;
$.ajax({
type: "POST",
url: "resultsforprcomment.php",
data:  dataString,
success: function(response){
	$("#leftcolumn").html(response);
}
});
 });
 
 $( ".inscomm" ).click(function(eee){
	 eee.preventDefault();	
	  var fullcomm = $(".fullcomm").val();
	  var fullcommid = $(".fullcommid").val();
	  $('[id=pr_'+fullcommid+']').val(fullcomm);
	  $(".fullcommdiv").fadeOut();
  });
 
 
}); 
</script>

<style>
a, #savebutton{
 text-decoration:none;
 color:#cc0000;
}
a#backtogetclass, #savebutton{
 float:left;
 margin-top:0;
}
a#backtogetclass, #savebutton, .inscomm{
 background-color:green;
 border:1px solid #660000;
 border-radius:5px;
 color:#fff;
 display: block;
  width: 6em;  
  padding: 0.1em;
  line-height: 1.4;
  text-align: center;
}

</style>
<style>
#wrapper {
    width: 100%;
    margin: 0 auto;
    position: relative;
}
#leftcolumn, #rightcolumn {
    color: white;
}
#leftcolumn {
    width: 68%;
    background-color: #111;
    position: fixed;
	text-align: center;
	margin-right: 1%;
}
@media only screen and (max-width: 600px) {
    #leftcolumn {
       position: static;
        width: 70%;
    }
}
#rightcolumn {
    width: 30%;
    float: right;
	margin-top: -40px;
}
@media only screen and (max-width: 600px) {
    #rightcolumn {
        width: 28%;
        margin-top: -500px;
    }
}
#rsn {
    text-align: center;
    color: white;
}
#tbn {
	width: 100%;
    text-align: center;
}
table#tbn td {
	text-align: center;
    border: 1px solid white;
	font-size: 12px;
}
.checkSingle, #thestud, #thecomm {
	cursor: pointer;
	color: black;
	font-size: 14px;
	text-align: left;
}
.fullcommspan{
color: white;
font-size: 14px;
font-weight: bold;
background-color: black;	
}
.prclass {
	display: none;
}
.prclass2 {
	display: inline;
}
.text2 {
	width: 300px;
	height: 35px;
}
</style>
 <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
</head>

<body>
<?php
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
else{echo "";}
?>
<?php
$user=$_SESSION['username'];
?><br>
<a href="princicomments.php" id="backtogetclass" >BACK</a>
<?php
$year = $_POST['year'];
$teacher_name = $_POST['teacher_name'];
$class = $_POST['class_name'];
$term = $_POST['term'];

  if($ctype=="Js"){
if($class == "Year 7"){ $caa2 = "JS1";}
else if($class == "Year 8"){ $caa2 = "JS2";}
else if($class == "Year 9"){ $caa2 = "JS3";}
else if($class == "Year 10"){ $caa2 = "SS1";}
else if($class == "Year 11"){ $caa2 = "SS2";}
else if($class == "Year 12"){ $caa2 = "SS3";}
else{}
}elseif($ctype=="Primary"){
if($class == "Year 1"){ $caa2 = "Primary 1";}
else if($class == "Year 2"){ $caa2 = "Primary 2";}
else if($class == "Year 3"){ $caa2 = "Primary 3";}
else if($class == "Year 4"){ $caa2 = "Primary 4";}
else if($class == "Year 5"){ $caa2 = "Primary 5";}
else if($class == "Year 6"){ $caa2 = "Primary 6";}
else{}
}else{
if($class == "Year 7"){ $caa2 = "Year 7";}	
else if($class == "Year 8"){ $caa2 = "Year 8";}
else if($class == "Year 9"){ $caa2 = "Year 9";}
else if($class == "Year 10"){ $caa2 = "Year 10";}
else if($class == "Year 11"){ $caa2 = "Year 11";}
else if($class == "Year 12"){ $caa2 = "Year 12";}
else{}
}

echo '<div style="text-align: center; margin: auto; padding: auto; color: red; width: 100%; font-weight: bold;">Performance of Students in '.$caa2.' for '.$term.', '.$year.'/'.($year+1).' Session</div>';
echo '<div id="rload" style="float: left; width: 100%;">';
$result = mysqli_query($db, "SELECT * FROM studentsbyclass where year='$year' AND class='$class' AND term='$term' AND school='".$_SESSION["school"]."' ORDER BY student_name ASC");
echo "<br><br>";
echo '<div id="wrapper">';
echo '<div id="leftcolumn">';
echo '<h3 id="hideprompt" >Click on a student\'s name to get the result displayed here.</h3>';
echo '</div>';
echo '<div id="rightcolumn">';
echo '<div class="fullcommdiv" style="display: none;" ><span class="fullcommspan"></span><input style="display: none;" class="fullcommid" /></span><br><textarea class="fullcomm" style="width: 100%; height: 180px;" /></textarea><br><button class="inscomm">insert</button></div>';
echo "<div class='rg-container'>";
echo "<div class='rg-content'>";
echo "<table class='rg-table zebra' summary='Hed'>";
echo "<caption class='rg-header'>";
//echo "<span class='rg-hed'>Hed</span>";
echo "</caption>";
echo "<thead>";
echo "<tr>";
echo "<th class='text' style='display: none;'>id</th>";
echo "<th class='text' id='thestud' >Student</th>";
echo "<th class='text' style='display: none;'>Principal\'s Name</th>";
echo "<th class='text' style='display: none;'>Class</th>";
echo "<th class='text' style='display: none;'>Year</th>";
echo "<th class='text' style='display: none;'>Term</th>";
echo "<th class='text' style='display: none;' id='thecomm' >Comment</th>";
echo "</tr>";
echo "</thead>";
echo "<tbody>";
echo '<form id="formid" >';
$counter = 0;
while($rowtid = mysqli_fetch_assoc($result))
{
echo "<tr class='sec'>";
echo '<td class="text" style="display: none;" data-title="id" ><input name="id[]" value="'.$rowtid['id'].'" /></td>';
echo '<td data-title="Name" class="checkSingle" id="'.$counter.'"><input type="text" style="display: none;" id="sn_'.$counter.'" name="student_name[]" value="'.$rowtid['student_name'].'" />'.$rowtid['student_name'].'</td>';
echo '<td class="text" style="display: none;" data-title="principal" ><input name="principal" value="'.$teacher_name.'" /></td>';
echo '<td class="text" style="display: none;" data-title="class" ><input name="class" id="cl_'.$counter.'" value="'.$rowtid['class'].'" /></td>';
echo '<td class="text" style="display: none;" data-title="year" ><input style="display: none;" name="year" id="yr_'.$counter.'" value="'.$rowtid['year'].'" />'.$rowtid['year'].'</td>';
echo '<td class="text" style="display: none;" data-title="term"  ><input style="display: none;" name="term" id="tm_'.$counter.'" value="'.$rowtid['term'].'" />'.$rowtid['term'].'</td>';
echo '<td class="text2" id="pr2_'.$counter.'" data-title="prcomment"  ><textarea style="width: 100%; height: 100%;" class="prclass" name="prcomment[]" id="pr_'.$counter.'" value="'.$rowtid['prcomment'].'" />'.$rowtid['prcomment'].'</textarea></td>';
echo "</tr>";
$counter++;
}
echo "<tr class=''>";
echo '<td class="text" data-title="submit" colspan="4"><input id="savebutton" color: white; width: 100px;" type="submit" name="submit" value="save" /></td>';
echo "</tr>";
echo '</form>';
echo "</tbody>";
echo "</table>";
echo '<div class="error" style="display:none; color: red;"><img src="table/del.jpg" width="60" height="60"/>An update error has just occurred.</div><div class="success" style="display:none; color: green;"><img src="table/492.png" width="60" height="60"/> Comments added/updated successfully.</div>';
echo "</div>";
echo "<br><br><br><br><br><br>";
echo "</div>";
echo "</div>";
echo "</div>";
echo "<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>";
include("footer.php");
//echo "</div>";
?>
</body>
</html>