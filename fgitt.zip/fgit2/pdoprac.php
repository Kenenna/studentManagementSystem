<?php
if(isset($_POST['submit'])){
$student_name = $_POST['student_name'];
$db = new PDO("mysql:host=localhost;dbname=sms", "root", "kenenna12");
//$newRow = $db->prepare("INSERT INTO studentsbyclass(student_name, class, year, term, formt, arms) VALUES('Jenny','Year 8','2015','First Term','Ezike','Red')");
//$newRow->execute();
$getRow = $db->prepare("SELECT * FROM studentsbyclass WHERE student_name='%$student_name%'");
$getRow->execute();
echo "<table style='border: solid 1px red;'><tr><td>Name</td><td>Class</td><td>Year</td></tr>";
while($row = $getRow->fetch(PDO::FETCH_ASSOC)){
echo '<tr>';
echo '<td>'.$row['student_name'].'</td>';
echo '<td>'.$row['class'].'</td>';
echo '<td>'.$row['year'].'</td>';
echo "</tr>";
}
echo "</table>";
//$getRowCount = $getRow->rowCount();
//echo $getRowCount;
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">

</head>
<body>
<form method="POST" action="pdoprac.php">
<input type="text" name="student_name"/>
<input type="submit" name="submit" value="search"/>
</form>
</body>