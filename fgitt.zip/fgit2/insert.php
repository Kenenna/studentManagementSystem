<?php
session_start();
include("auth.php");
include('connection.php');
include('database.php');
include('function.php');
if(isset($_POST["operation"]))
{
 if($_POST["operation"] == "Add")
 {
	$i = $_POST['id'];
	$y = $_POST['year'];
	$c = $_POST['class']; 
	$t = $_POST['term'];
	$a = $_POST['arms'];
	$f = $_POST['formt'];
	$h = $_POST['house'];
	
 $sql = "SELECT * FROM studentsbyclass WHERE student_name = :student_name AND year = :year AND class = :cla AND term = :term AND formt = :formt AND arms = :arms AND house = :house AND school = :school";
 $statement = $connection->prepare($sql);
 $stuname = $_POST["student_name"];
 $stuyear = $_POST["year"];
 $stuclass = $_POST["cla"];
 $stuterm = $_POST["term"];
 $stuformt = $_POST["formt"];
 $stuarms = $_POST["arms"];
 $stuhouse = $_POST["house"];
 $stuschool = $_SESSION["school"];
 
/* $resulttnamm = mysqli_query($db, "SELECT formt FROM studentsbyclass where class='$stuclass' AND arms='$stuarms' AND year='$stuyear' AND term='$stuterm' AND school='".$_SESSION["school"]."' LIMIT 1");
while($rowtnamm = mysqli_fetch_assoc($resulttnamm))
{
$tnameee2 = $rowtnamm['formt'];
}
 if($tnameee2 !=  $stuformt){
	$stuformt =  $tnameee2;
	$_POST["formt"] = $tnameee2;
 }
 */
 
 $statement->bindValue(':student_name', $stuname);
 $statement->bindValue(':year', $stuyear);
 $statement->bindValue(':cla', $stuclass);
 $statement->bindValue(':term', $stuterm);
 $statement->bindValue(':formt', $stuformt);
 $statement->bindValue(':arms', $stuarms);
 $statement->bindValue(':house', $stuhouse);
 $statement->bindValue(':school', $stuschool);
$statement->execute();
$r = $statement->fetch(PDO::FETCH_ASSOC);

$counting = $statement->rowCount();
if($counting < 1){
	$image = '';
  if($_FILES["user_image"]["name"] != '')
  {
   $image = upload_image();
  }
  $statement = $connection->prepare("
   INSERT INTO studentsbyclass (student_name, class, year, term, formt, arms, image, house, school) 
   VALUES (:student_name, :cla, :year, :term, :formt, :arms, :image, :house, :school)
  ");
  $result = $statement->execute(
   array(
    ':student_name' => $_POST["student_name"],
    ':cla' => $_POST["cla"],
	':year' => $_POST["year"],
	':term' => $_POST["term"],
	':formt' => $_POST["formt"],
	':arms' => $_POST["arms"],
	':house' => $_POST["house"],
	':school' => $_SESSION["school"],
    ':image'  => $image
   )
  );
  if(!empty($result))
  {
   echo 'Data Successfully Inserted';
  }	
} //end of if for counting less than 1
else{
	echo "You attempted to add ".strtoupper($_POST["student_name"])." to ".$_POST["cla"].$_POST["arms"]." in ".$_POST["term"]." of ".$_POST["year"]." with ".$_POST["formt"]." as form tutor. Unfortunately a student matching those criteria already exists.";
} //end of else for counting less than 1	
	
 } // end of if for operation equal to add
 
 
 
 
 if($_POST["operation"] == "Edit")
 {
  $image = '';
  if($_FILES["user_image"]["name"] != '')
  {
   $image = upload_image();
  }
  else
  {
   $image = $_POST["hidden_user_image"];
  }
  $statement = $connection->prepare(
   "UPDATE studentsbyclass 
   SET student_name = :student_name, class = :cla, year = :year, term = :term, formt = :formt, arms = :arms, house = :house, image = :image  
   WHERE id = :id
   "
  );
  $result = $statement->execute(
   array(
    ':student_name' => $_POST["student_name"],
    ':cla' => $_POST["cla"],
	':year' => $_POST["year"],
	':term' => $_POST["term"],
	':formt' => $_POST["formt"],
	':arms' => $_POST["arms"],
	':house' => $_POST["house"],
    ':image'  => $image,
    ':id'   => $_POST["user_id"]
   )
  );
  if(!empty($result))
  {
   echo 'Data Successfully Updated';
  }
 }
}
?>