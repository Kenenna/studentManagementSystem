<?php
	include("check.php");	
	
	include 'connection.php';
$score_id = $_POST['score_id'];	
$student_name = $_POST['student_name'];
$class_name = $_POST['class_name'];
$year = $_POST['year'];
$term = $_POST['term'];
$subject = $_POST['subject'];
$teacher_id = $_POST['teacher_id'];
$score2 = $_POST['score'];
$scoremid2 = $_POST['scoremid'];
$scoremidraw2 = $_POST['scoremidraw'];

$hwraw2 = $_POST['hwraw'];
$cwraw2 = $_POST['cwraw'];
$testraw2 = $_POST['testraw'];
$examraw2 = $_POST['examraw'];

//$hw2 = $_POST['hw'];
//$cw2 = $_POST['cw'];
//$test2 = $_POST['test'];
//$exam2 = $_POST['exam'];
$remark = $_POST['remark'];
$hwmaxname = $_POST['hwmaxname'];
$cwmaxname = $_POST['cwmaxname'];
$testmaxname = $_POST['testmaxname'];
$exammaxname = $_POST['exammaxname'];


for ($i = 0; $i <= (count($score_id)-1); $i++){
	$hw[$i] = round(($hwraw2[$i]/$hwmaxname[$i])*30);
	$cw[$i] = round(($cwraw2[$i]/$cwmaxname[$i])*30);
	$test[$i] = round((($testraw2[$i]/$testmaxname[$i])*40));
	$caraw[$i] = round(($hwraw2[$i])+($cwraw2[$i])+($testraw2[$i]))+($scoremidraw2[$i]);
	$ca[$i] = (round(((($hw[$i])+($cw[$i])+($test[$i]))/100)*20))+(round($scoremid2[$i]/5));
	$exam[$i] = round(($examraw2[$i]/$exammaxname[$i])*60);
	$score[$i] = round(($ca[$i])+(($exam2[$i]/$exammaxname[$i])*60));
$sql1=mysqli_query($db,"UPDATE scores SET score='$score[$i]', scoremid='$scoremid2[$i]', scoremidraw='$scoremidraw2[$i]', hwraw='$hwraw2[$i]', cwraw='$cwraw2[$i]', testraw='$testraw2[$i]', caraw='$caraw[$i]', examraw='$examraw2[$i]', hw='$hw[$i]', cw='$cw[$i]', test='$test[$i]', ca='$ca[$i]', exam='$exam[$i]', student_name='$student_name[$i]', remark='$remark[$i]', hwmaxname='$hwmaxname[$i]', cwmaxname='$cwmaxname[$i]', testmaxname='$testmaxname[$i]', exammaxname='$exammaxname[$i]' WHERE score_id='$score_id[$i]'");
}

if($sql1){
	echo "scores updated successfully";
	echo '<meta content="2;update-score.php" http-equiv="refresh" />';
}	
else{
	echo "not updated";
	echo '<meta content="2;update-score.php" http-equiv="refresh" />';
}
?>