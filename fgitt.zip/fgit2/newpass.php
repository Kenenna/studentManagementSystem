<?php
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>New Pass</title>
<link rel="stylesheet" href="css/style.css" />
	
        <link rel="stylesheet" type="text/css" href="table/css/DT_bootstrap.css">

	<script src="table/js/jquery.js" type="text/javascript"></script>

	
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/jquery.dataTables.js"></script>
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/DT_bootstrap.js"></script>
<script>
		$(document).ready(function() {	
		$("#resetpass").submit(function( event ) {
			event.preventDefault();	
var newp= $("#newp").val();
var confp= $("#confp").val();
if(newp != confp){
	alert("New Password and Confirm Passwords Do Not Match.");
}else{
$.ajax({
type: "POST",
url: "newpass_exec.php",
data: $("#resetpass").serialize(),	
success: function(response){
 if(response==1) { 
		event.preventDefault();
	$("#newp").val("");
	$("#oldp").val("");
	$("#confp").val("");	
		$(".success").fadeIn();
		setTimeout(function() { $(".success").fadeOut(); }, 5000); 
    } else {
		 $(".error").show();
		setTimeout(function() { $(".error").fadeOut(); }, 5000);
		}
		}
});	
} //end of if conf pw
});	 
});
</script>	
	
<script>
$(document).ready(function(){
 $("#toggle").change(function(){
  if($(this).is(':checked')){
   $("#newp").prop('type', 'text');
   $("#toggleText").text("hide password");
  }else{
   $("#newp").prop('type', 'password');
   $("#toggleText").text("show password");
  }
 
 });
});
</script> 
   <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>
  <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
</head>
<body>
<?php
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
elseif($_SESSION['role'] == 'student'){
include("headerstudent.php");
}
else{echo "";}

$resultrole2 = mysqli_query($db, "SELECT * FROM users2 where username='".$_SESSION['username']."' AND school='".$_SESSION["school"]."'");
while($rowrole2 = mysqli_fetch_assoc($resultrole2))
{
	$arole[] = $rowrole2['role'];
}
$_SESSION['role'] =  current($arole);
?>
<br><br>
<?php
if($_SESSION['role'] == 'teacher'){
echo '<div class="form">';
echo '<br><br><h5>CHANGE PASS</h5>';
echo '<div class="success" style="display: none;" >Password Updated Successfully</div>';
echo '<div class="error" style="display: none;" >The old password given does not match the one on record.</div>';
echo '<form id="resetpass">';
echo '<input id="username" style="display: none;" type="text" name="username" value="'.$_SESSION['username'].'" />';
echo '<input id="oldp" placeholder="Current Password" type="password" name="oldp" required/>';
echo '<input id="newp" placeholder="New Password" class="newpt" type="password" name="password" required/><br>';
echo "<span id='toggleText' style='color: red; font-size: 12px;' >show password</span>&nbsp;&nbsp;&nbsp;&nbsp;<input type='checkbox' id='toggle' value='0'>";
echo '<br><input id="confp" placeholder="Confirm New Password" type="password" name="confp" required/>';
echo '<input type="submit" name="submit8" value="Change Password" />';
echo '</form>';	
echo '</div>';
echo '<hr />';


}
else if($_SESSION['role'] == 'student'){
echo '<div class="form">';
echo '<br><br><br>';
echo '<br><br><h5>CHANGE PASS</h5>';
echo '<div class="success" style="display: none;" >Password Updated Successfully</div>';
echo '<div class="error" style="display: none;" >Old and new passwords do not match</div>';
echo '<form id="resetpass">';
echo '<input id="username" style="display: none;" type="text" name="username" value="'.$_SESSION['username'].'" />';
echo '<input id="oldp" placeholder="Current Password" type="password" name="oldp" required/>';
echo '<input id="newp" placeholder="New Password" class="newpt" type="password" name="password" required/><br>';
echo "<span id='toggleText' style='color: red; font-size: 12px;' >show password</span>&nbsp;&nbsp;&nbsp;&nbsp;<input type='checkbox' id='toggle' value='0'>";
echo '<input id="confp" placeholder="Confirm New Password" type="password" name="confp" required/>';
echo '<input type="submit" name="submit8" value="Change Pawword" />';
echo '</form>';	
echo '</div>';
//echo '<hr />';

}
else{
echo '<div class="form">';
echo '<br><br><h5>CHANGE PASS</h5>';
echo '<div class="success" style="display: none;" >Password Updated Successfully</div>';
echo '<div class="error" style="display: none;" >Old and new passwords do not match</div>';
echo '<form id="resetpass">';
echo '<input id="username" style="display: none;" type="text" name="username" value="'.$_SESSION['username'].'" />';
echo '<input id="oldp" placeholder="Current Password" type="password" name="oldp" required/>';
echo '<input id="newp" placeholder="New Password" class="newpt" type="password" name="password" required/><br>';
echo "<span id='toggleText' style='color: red; font-size: 12px;' >show password</span>&nbsp;&nbsp;&nbsp;&nbsp;<input type='checkbox' id='toggle' value='0'>";
echo '<input id="confp" placeholder="Confirm New Password" type="password" name="confp" required/>';
echo '<input type="submit" name="submit8" value="Change Password" />';
echo '</form>';	
echo '</div><br><br>';
echo '<hr />';
}
?>
<?php
include("footer.php");
?>
</body>