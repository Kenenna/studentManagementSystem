<?php
$getsubject = $_POST['subject'];
echo $getsubject;
?>