<?php
session_start();
include("auth.php"); 
include "connection.php";
$randId3 = $_POST['randid'];
$result2 = mysqli_query($db, "SELECT * FROM answer WHERE randId='$randId3' AND answer1=ans");
$result3 = mysqli_query($db, "SELECT * FROM answer WHERE randId='$randId3'");
$result4 = mysqli_query($db, "SELECT answer.ans, answer.answer1, answer.randId, answer.cat, answer.timetaken, questions.question_name FROM answer INNER JOIN questions ON answer.quiz_name=questions.quiz_name WHERE answer.randId='$randId3' AND answer.answer1 !=answer.ans");
$result5 = mysqli_query($db, "SELECT DISTINCT(timetaken) FROM answer WHERE randId='$randId3'");

$num = mysqli_num_rows($result2);
$num2 = mysqli_num_rows($result3);
echo 'You got '.$num.' questions correct, out of '.$num2.'.<br><br>To check your scores for the quiz you have just taken, store the quiz idendifier: <span style="color:red;">'.$randId3.'. </span><br><br>';

$values = array();
while($row = mysqli_fetch_assoc($result4))
{
	if(substr($row['question_name'],-3)!="jpg") {
echo '<div style="font-weight:bold; color: blue;">For the question:</div>'.$row['question_name'].'<br>';
	}
	else{
echo '<div style="font-weight:bold; color: blue;">For the question:</div><img src="images/'.$row['question_name'].'" width="150"height="150"><br>';
	}
echo 'You chose:<span style="color:red"> '.$row["answer1"].'.</span> BUT the answer is<span style="color:green"> '.$row["ans"].'</span><br><br>';	

}
?>
<br>