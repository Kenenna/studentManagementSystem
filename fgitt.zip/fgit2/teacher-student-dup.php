echo 'Select Students<br />';	
echo '<br>';
echo '<form action="teacher-student_exec.php" method="post">';
foreach ($r as $key => $r['student_name']) {	
echo '<input type="hidden" name="student_name[]" value="'.$r['student_name'].'" />'.$r['student_name'].':&nbsp; <input type="text" placeholder="Total" name="score[]" id="score" />&nbsp; <input type="text" placeholder="CA" name="ca[]" id="ca" />&nbsp; <input type="text" placeholder="Exam" name="exam[]" id="exam" />';
echo '<input type="text"  name="teacher_id[]" id="teacher_id" value="'.$tid.'" /><input type="text"  name="remark[]" id="remark" placeholder="Remark" />';
echo '<input type="text"  name="teacher[]" id="teacher" value="'.$tna.'" /><input type="text"  name="class_name[]" id="class_name" value="'.current($valuesclass).'" />';
echo '<input type="text"  name="year[]" id="year" value="'.current($valuesyear).'" /><input type="text"  name="term[]" id="term" value="'.current($valuesterm).'" /><input type="text"  name="subject[]" id="subject" value="'.$b.'" /><br />';	
}
echo '<input type="submit" class="submit_button" name="submit" value="Submit Scores" />';
echo '</form>';