<?php
include "connection.php";
$shuff = $_POST['shuffle_questions'];
$class = $_POST['classs'];
$year = $_POST['year'];
$term = $_POST['term'];
$arm = $_POST['arm'];
$subject = $_POST['subject'];
$quiz_name = $_POST['quiz_name'];
$school = $_POST['school'];
$teacher = $_POST['teacher_name'];
$result = mysqli_query($db, "UPDATE teacher_quiz_shuffle SET shuffle_questions='$shuff' WHERE class='$class' AND year='$year' AND term='$term' AND subject='$subject' AND teacher_name='$teacher' AND arm='$arm' AND school='$school' AND quiz_name='$quiz_name'");
//echo $shuff.$class.$year.$term.$arm.$subject.$quiz_name.$school.$teacher;
if($result){
	echo $shuff;
}else{
	echo $shuff;
}
?>