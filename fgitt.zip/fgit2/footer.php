<style>
a:hover{
	color: orange;
}
</style>
<footer id="footer" class="footer-distributed">
			<div class="footer-right">

				<a href="#"><i class="fa fa-facebook"></i></a>
				<a href="#"><i class="fa fa-twitter"></i></a>
				<a href="#"><i class="fa fa-linkedin"></i></a>
				<a href="#"><i class="fa fa-github"></i></a>

			</div>

			<div class="footer-left">

				<p class="footer-links">
				 <?php
					$url = $_SERVER['REQUEST_URI'];
					$ur = substr($url, 0, strrpos($url, "?"));
					if(substr($url,0,-72)=='/loginsms/quiz/showquizresult.php'){
					$url = '/loginsms/quiz/showquizresult.php';
						}
					if(substr($url,0,-78)=='/loginsms/quiz/quiz.php'){
					$url = '/loginsms/quiz/quiz.php';
						}
					if((substr($url,0,-78) == '/loginsms/quiz/quizshowansaft.php')){
					$url = '/loginsms/quiz/quizshowansaft.php';
					}	
					if(($url == '/loginsms/quiz/imgques.php') || ($url == '/loginsms/quiz/indexquiz.php')
					|| ($url == '/loginsms/quiz/showquizresult.php')
					|| ($url == '/loginsms/quiz/showquizresulttea.php')
					|| ($url == '/loginsms/quiz/myquiz.php')
					 || ($url == '/loginsms/quiz/quizshowansaft.php')
					|| ($url == '/loginsms/quiz/quiz.php')
					|| ($url == '/loginsms/quiz/teacher_quiz.php')
					|| ($url == '/loginsms/quiz/myquiztea.php')
					|| ($url == '/loginsms/quiz/teacher_quiz2.php')
					|| ($ur == '/loginsms/quiz/teacher_quiz2.php')
					|| ($url == '/loginsms/quiz/teastudentquiz.php')
					|| ($url == '/loginsms/quiz/teastudentquiz2.php')
					){
					?>
					<a class="foolinks" href="../index2.php"><span><img src="../kt.png" height="100px" width="100px;" /></span></a>
					·
					<a class="foolinks" href="#">Privacy Policy</a>
					·
					<a class="foolinks" href="#">Terms of Use</a>
					·
					<a class="foolinks" href="#">About</a>
					·
					<a class="foolinks" href="#">Faq</a>
					·
					<a class="foolinks" href="#">Contact</a>
					<?php }else{ ?>
					<a class="foolinks" href="index2.php"><span><img src="kt.png" height="100px" width="100px;" /></span></a>
					·
					<a class="foolinks" href="#">Privacy Policy</a>
					·
					<a class="foolinks" href="#">Terms of Use</a>
					·
					<a class="foolinks" href="#">About</a>
					·
					<a class="foolinks" href="#">Faq</a>
					·
					<a class="foolinks" href="#">Contact</a>
					<?php } ?>
				</p>

				<p>KeneTech &copy; 2017</p>
			</div>

		</footer>