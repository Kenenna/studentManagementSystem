<html>
 <head>
  <title>Add Student to Class</title>
  <script src="table/crud/jq.js" type="text/javascript"></script>
  <script src="table/crud/dt.js" type="text/javascript"></script>
  <script src="table/crud/dt2.js" type="text/javascript"></script>
  <link rel="stylesheet" type="text/css" href="table/crud/csboot.css">
 <link rel="stylesheet" type="text/css" href="table/crud/csboot2.css">
 <script src="table/crud/dt3.js" type="text/javascript"></script>
  <link rel="stylesheet" href="css/style.css" />
  
  <style>
   body
   {
    margin:0;
    padding:0;
    background-color:#f1f1f1;
   }
   .box
   {
    width:1270px;
    padding:20px;
    background-color:#fff;
    border:1px solid #f80;
    border-radius:5px;
    margin-top:25px;
   }
  </style>

 </head>
 <body>
<br>
  <div class="container box">
   <h3 align="center">Add Student to Class</h3>
   <div class="table-responsive">
    <div align="right">
     <button type="button" id="add_button" data-toggle="modal" data-target="#userModal" class="btn btn-info btn-lg">Add</button>
    </div>
    <br />
    <table id="user_data" class="table table-bordered table-striped">
     <thead>
      <tr>
	   <th width="35%">Image</th>
       <th width="10%">Name</th>
       <th width="35%">Class</th>
       <th width="35%">Year</th>
	   <th width="35%">Term</th>
       <th width="35%">Tutor</th>
	   <th width="35%">Arm</th>
       <th width="10%">Edit</th>
       <th width="10%">Delete</th>
      </tr>
     </thead>
    </table>
    
   </div>
  </div>
 </body>
</html>

<div id="userModal" class="modal fade">
 <div class="modal-dialog">
  <form method="post" id="user_form" enctype="multipart/form-data">
   <div class="modal-content">
    <div class="modal-header">
     <button type="button" class="close" data-dismiss="modal">&times;</button>
     <h4 class="modal-title">Add User</h4>
    </div>
    <div class="modal-body">
     <label></label>
     <input type="text" name="student_name" id="student_name" class="form-control" />
     <br />
     <label>Class</label>
     <input type="text" name="cla" id="cla" value="<?php echo $_POST['class'] ?>" class="form-control" readonly />
     <br />
	  <label>Year</label>
     <input type="text" name="year" id="year" value="<?php echo $_POST['year'] ?>" class="form-control" readonly />
     <br />
	  <label>Term</label>
     <input type="text" name="term" id="term" value="<?php echo $_POST['term'] ?>" class="form-control" readonly />
     <br />
	  <label>Tutor</label>
     <input type="text" name="formt" id="formt" value="<?php echo $_POST['formt'] ?>" class="form-control" readonly />
     <br />
	  <label>Arm</label>
     <input type="text" name="arms" id="arms" value="<?php echo $_POST['arms'] ?>" class="form-control" readonly />
     <br />
     <label>Select Image</label>
     <input type="file" name="user_image" id="user_image" />
     <span id="user_uploaded_image"></span>
    </div>
    <div class="modal-footer">
     <input type="hidden" name="user_id" id="user_id" value="<?php echo $_POST['id'] ?>" />
	  <input type="hidden" name="class_user_id" id="class_user_id" value="<?php echo $_POST['class'] ?>" />
	   <input type="hidden" value="<?php echo $_POST['year'] ?>" name="year_user_id" id="year_user_id" />
	    <input type="hidden" name="term_user_id" id="term_user_id" value="<?php echo $_POST['term'] ?>" />
		 <input type="hidden" name="formt_user_id" id="formt_user_id" value="<?php echo $_POST['formt'] ?>" />
		  <input type="hidden" name="arms_user_id" id="arms_user_id" value="<?php echo $_POST['arms'] ?>" />
     <input type="hidden" name="operation" id="operation" />
     <input type="submit" name="action" id="action" class="btn btn-success" value="Add" />
     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    </div>
   </div>
  </form>
 </div>
</div>
<p id="p"></p>
<script type="text/javascript" language="javascript" >
$(document).ready(function(){
 $('#add_button').click(function(){
  $('#user_form')[0].reset();
  $('.modal-title').text("Add User");
  $('#action').val("Add");
  $('#operation').val("Add");
  $('#user_uploaded_image').html('');
 });
 
 var dataTable = $('#user_data').DataTable({
  "processing":true,
  "serverSide":true,
  "order":[],
  "ajax":{
   url:"fetch.php",
   type:"POST"
  },
  "columnDefs":[
   {
    "targets":[0, 3, 4],
    "orderable":false,
   },
  ],

 });

 $(document).on('submit', '#user_form', function(event){
  event.preventDefault();
  var student_name = $('#student_name').val();
  var cla = $('#cla').val();
  var year = $('#year').val();
  var term = $('#term').val();
  var formt = $('#formt').val();
  var arms = $('#arms').val();
  var extension = $('#user_image').val().split('.').pop().toLowerCase();
  if(extension != '')
  {
   if(jQuery.inArray(extension, ['gif','png','jpg','jpeg']) == -1)
   {
    alert("Invalid Image File");
    $('#user_image').val('');
    return false;
   }
  } 
  if(student_name != '' && cla != '')
  {
   $.ajax({
    url:"insert.php",
    method:'POST',
    data:new FormData(this),
    contentType:false,
    processData:false,
    success:function(data)
    {
     alert(data);
     $('#user_form')[0].reset();
     $('#userModal').modal('hide');
     dataTable.ajax.reload();
    }
   });
  }
  else
  {
   alert("All fields are required");
  }
 });
 
 $(document).on('click', '.update', function(){
	 
  var user_id = $(this).attr("id");
  
  $.ajax({
   url:"fetch_single.php",
   method:"POST",
   data:{user_id:user_id},
   dataType:"json",
   success:function(data)
   {
    $('#userModal').modal('show');
    $('#student_name').val(data.student_name);
    $('#cla').val(data.cla);
	$('#year').val(data.year);
	$('#term').val(data.term);
	$('#formt').val(data.formt);
	$('#arms').val(data.arms);
    $('.modal-title').text("Edit User");
    $('#user_id').val(user_id);
	var yt = $('#year').val();
	var yt2 = <?php echo json_encode($_POST['year'], JSON_HEX_TAG); ?>; 
	var ar = $('#arms').val();
	var ar2 = <?php echo json_encode($_POST['arms'], JSON_HEX_TAG); ?>; 
	var cl = $('#cla').val();
	var cl2 = <?php echo json_encode($_POST['class'], JSON_HEX_TAG); ?>; 
	var tm = $('#term').val();
	var tm2 = <?php echo json_encode($_POST['term'], JSON_HEX_TAG); ?>;
	var ft = $('#formt').val();
	var ft2 = <?php echo json_encode($_POST['formt'], JSON_HEX_TAG); ?>;
	if((yt == yt2 && yt2 != "") && (ar == ar2 && ar2 != "") && (cl == cl2 && cl2 != "") && (tm == tm2 && tm2 != "") && (ft == ft2 && ft2 != "")){
    $('#user_uploaded_image').html(data.user_image);
    $('#action').val("Edit");
    $('#operation').val("Edit");
	}else{
		alert("You selected students in "+cl2+ar2+" in "+yt2+" with "+ft2+" as form tutor. You can therefore edit profile of only students meeting those criteria.");
		window.location.href = "formclasses.php";
		$('#userModal').modal('hide');
	}
   }
  })
 });
 
 $(document).on('click', '.delete', function(){
  var user_id = $(this).attr("id");
  //var year_user_id = $('[id=year'+user_id+']').val();
  var year_user_id = <?php echo json_encode($_POST['year'], JSON_HEX_TAG); ?>;
  var class_user_id = <?php echo json_encode($_POST['class'], JSON_HEX_TAG); ?>;
  var term_user_id = <?php echo json_encode($_POST['term'], JSON_HEX_TAG); ?>;
  var formt_user_id = <?php echo json_encode($_POST['formt'], JSON_HEX_TAG); ?>;
  var arms_user_id = <?php echo json_encode($_POST['arms'], JSON_HEX_TAG); ?>;
  if(confirm("Are you sure you want to delete this?"))
  {
   $.ajax({
    url:"delete.php",
    method:"POST",
    data:{user_id:user_id, year_user_id:year_user_id, class_user_id:class_user_id, term_user_id:term_user_id, formt_user_id:formt_user_id, arms_user_id:arms_user_id},
    success:function(data)
    {	
     alert(data);
     dataTable.ajax.reload();
    }
   });
  }
  else
  {
   return false; 
  }
 });
 
});
</script>
