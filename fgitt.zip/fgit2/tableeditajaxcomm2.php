<?php
	session_start();
	 ob_start();
	include("auth.php");	
	include 'connection.php';
$student_name = $_POST['student_name'];
$firstname = $_POST['firstname'];
$formt = $_POST['formt'];
$arm = $_POST['arm'];
$class = $_POST['class'];
$year = $_POST['year'];
$term = $_POST['term'];


for ($i = 0; $i <= (count($student_name)-1); $i++){
    $t = mysqli_query($db,"INSERT INTO ftcomments(student_name,class,year,term,formt,firstname,ppfirstname,school) VALUES('$student_name[$i]','$class[$i]','$year[$i]','$term[$i]','$formt[$i]','$firstname[$i]','$arm[$i]','".$_SESSION["school"]."')");
    }	
if($t){
header("location: ftcomments.php");
}	
else{
header("location: ftcomments.php");
}
?>

