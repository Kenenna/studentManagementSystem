<?php
include "connection.php";
//$query =("UPDATE attend SET sex='Male' WHERE student_name='John' OR student_name='Muri' OR student_name='Bola Bello' OR student_name='Edwin' OR student_name='Lekan'");
//$query =("UPDATE attend SET student_name='Princess' WHERE student_name='Princes'");
/*$query =("UPDATE students SET arms='Kehinde' WHERE school='Louisville Girls High School'");
if (!mysqli_query ($db,$query) )
			{
			echo '<img src="table/del.jpg" /> &nbsp;! attendance not updated';
			echo '<meta content="2;attend.php" http-equiv="refresh" />';	
			die (mysqli_error());
			}else{
		echo '<img src="table/492.png" /> &nbsp;! attendance updated successfully';
		echo '<meta content="2;attend.php" http-equiv="refresh" />';
			}
			*/
$query = mysqli_query($db,"DELETE FROM attend WHERE (datename >= '2017-09-25') AND (datename <= DATE_ADD('2017-09-25', INTERVAL 4 DAY ))");
if($query){
	echo "yes";
}
		
?>
