<?php
	include("check.php");	
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Home</title>
<link rel="stylesheet" href="style.css" type="text/css" />

</head>

<body>
<h1 class="hello">Hello, <em><?php echo $login_user;?>!</em></h1>

Select Class, Year and Term to enrol students in.

<form action="" method="post" enctype="multipart/form-data">
<center>
 <div>
   
	<label><select style="width:15%;" name="class_name" id="class_name" required ><br>
                   
                    <?php
	include "connection.php";
	$result = mysqli_query($db, "SELECT * FROM classes");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['class_name'].'">';
								echo $row['class_name'];
								echo '</option>';
							}
						?>
      </select>
	  
	  <br><br>
	  <select style="width:15%;" name="year" id="year" required ><br>
                   
                    <?php
	include "connection.php";
	$result = mysqli_query($db, "SELECT * FROM years");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['year'].'">';
								echo $row['year'];
								echo '</option>';
							}
						?>
      </select>
	  
	  
	   <br><br>
	  <select style="width:15%;" name="term" id="term" required ><br>
                   
                    <?php
	include "connection.php";
	$result = mysqli_query($db, "SELECT * FROM terms");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['term'].'">';
								echo $row['term'];
								echo '</option>';
							}
						?>
      </select>
	   <br><br>
	 
	
	  
  <label><br><br>
      <input type="submit" class="button" name="btn-upload" value="Submit Form" />
    </label>

  </div>
  </center><BR><BR>
</form><br>

