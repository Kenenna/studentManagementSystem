<?php
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
$user=$_SESSION['username'];
$resultrole2 = mysqli_query($db, "SELECT role, adminlevel, img FROM users2 where username='".$_SESSION['username']."' AND school='".$_SESSION['school']."'");
while($rowrole2 = mysqli_fetch_assoc($resultrole2))
{
	$arole[] = $rowrole2['role'];
	$img[] = $rowrole2['img'];
	$adminlevel2[] = $rowrole2['adminlevel'];
}
$_SESSION['role'] =  current($arole);
$_SESSION['imgg'] =  current($img);
$_SESSION['adminlevel'] =  current($adminlevel2);
?>

 <nav>
        <div class="menu-toggle">
            <h3>Menu</h3>
            <button type="button" id="menu-btn">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
          <ul id="respMenu" class="ace-responsive-menu" data-menu-style="horizontal">
              <li>
                <a href='index2.php'>
                    <i class="fa fa-home" aria-hidden="true"></i>
                    <span>Home</span>
                </a>
            </li>
             <li>
                <a href="javascript:;">
                    <!--<i class="fa fa-crop" aria-hidden="true"></i>-->
                    <span class="title">Result</span>
                </a>
                <!-- Level Two-->
                <ul>
                    <li>
                        <a href="teagetresultmid.php">
                            <!--<i class="fa fa-graduation-cap" aria-hidden="true"></i>-->
                            Midterm Result						
                        </a>
                    </li>
                    <li>
                        <a href="teagetresult.php">
                           <!--<i class="fa fa-database" aria-hidden="true"></i>-->
                           Term Result
                        </a>
                    </li>
                </ul>
            </li>
             <li class="last">
                <a href="javascript:;">
                    <!--<i class="fa fa-crop" aria-hidden="true"></i>-->
                    <span class="title">User</span>
                </a>
                <!-- Level Two-->
                <ul>
                        <?php
	  $url = $_SERVER['REQUEST_URI'];
	  if($url == '/index2.php'){
	  echo '<li><a href="#" id="imghref">Change Profile Pic</a></li>';
	  }
	   ?>
                    <li>
                        <a href="newpass.php">
                            <!--<i class="fa fa-graduation-cap" aria-hidden="true"></i>-->
                           Alter Pass						
                        </a>
                    </li>
                    <li>
                        <a href="chooseschool.php">
                           <!--<i class="fa fa-database" aria-hidden="true"></i>-->
                          School
                        </a>
                    </li>
                     <li>
                        <a href="logout.php">
                           <!--<i class="fa fa-database" aria-hidden="true"></i>-->
                          Logout
                        </a>
                    </li>
                </ul>
            </li>
            <li class="last" style="float: right;" ><img id="photo" src="<?php echo $_SESSION['imgg'] ?>" width="60" height="60" /><a style="float: left;" href="index2.php" style="color: gold;" ><?php echo $user; ?></a></li>
        </ul>
    </nav>
    <!-- End of Responsive Menu -->