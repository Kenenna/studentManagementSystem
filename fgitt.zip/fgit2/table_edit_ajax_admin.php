<?php
include("db.php");
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
if($_POST['teacher_id'])
{
$id=mysql_escape_String($_POST['teacher_id']);
$firstname=mysql_escape_String($_POST['status']);
$sql = "update users2 set status='$firstname' where teacher_id='$id'";
mysql_query($sql);
}
?>