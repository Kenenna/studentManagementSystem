<?php
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
include('database.php');
include('function.php');
$yy = $_POST["year"];
if(isset($_POST["user_id"]))
{
 $output = array();
 $statement = $connection->prepare(
  "SELECT * FROM studentsbyclass 
  WHERE id = '".$_POST["user_id"]."'
  LIMIT 1"
 );
 $statement->execute();
 $result = $statement->fetchAll();
 foreach($result as $row)
 {
  $output["student_name"] = $row["student_name"];
  $output["cla"] = $row["class"];
  $output["year"] = $row["year"];
  $output["term"] = $row["term"];
  $output["formt"] = $row["formt"];
  $output["arms"] = $row["arms"];
  $output["house"] = $row["house"];
  if($row["image"] != '')
  {
   $output['user_image'] = '<img src="upload/'.$row["image"].'" class="img-thumbnail" width="50" height="35" /><input type="hidden" name="hidden_user_image" value="'.$row["image"].'" />';
  }
  else
  {
   $output['user_image'] = '<input type="hidden" name="hidden_user_image" value="" />';
  }
 }
echo json_encode($output);
}
?>