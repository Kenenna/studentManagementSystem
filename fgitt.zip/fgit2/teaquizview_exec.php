<?php
session_start();
include("auth.php");
include("db.php");
if($_POST['id'])
{
$id=mysql_escape_String($_POST['id']);
$sourcePath = $_FILES['question_name']['tmp_name'];
$targetPath = "images/".$_FILES['question_name']['name'];
move_uploaded_file($sourcePath,$targetPath);
$question_name=mysql_escape_String($_POST['question_name']);
$answer1=mysql_escape_String($_POST['answer1']);
$answer2=mysql_escape_String($_POST['answer2']);
$answer3=mysql_escape_String($_POST['answer3']);
$answer4=mysql_escape_String($_POST['answer4']);
$ans=mysql_escape_String($_POST['ans']);
$section_ref=mysql_escape_String($_POST['section_ref']);
$sql = "update teacher_quiz set question_name='$question_name', answer1='$answer1', answer2='$answer2', answer3='$answer3', answer4='$answer4', ans='$ans', section_ref='$section_ref' where id='$id' AND school='".$_SESSION["school"]."'";
mysql_query($sql);
}
?>