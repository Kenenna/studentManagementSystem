<?php
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
$id=$_REQUEST['id']; 
$query = "DELETE FROM houseparent WHERE id='$id'";

		if (!mysqli_query ($db,$query) )
			{
			echo '<img src="table/del.jpg" /> &nbsp;! house parent details not deleted';
			echo '<meta content="2;admviewhp.php" http-equiv="refresh" />';	
			die (mysqli_error());
			}else{
	
		echo '<img src="table/492.png" /> &nbsp;! house parent details deleted successfully';
		echo '<meta content="2;admviewhp.php" http-equiv="refresh" />';
			}
?>
