<?php 
session_start();
include("auth.php");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Update Student Attendance</title>
<link rel="stylesheet" href="css/style.css" />
		<!--<link href="table/css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">-->
        <link rel="stylesheet" type="text/css" href="table/css/DT_bootstrap.css">

	<script src="table/js/jquery.js" type="text/javascript"></script>
<script src="table/js/bootstrap.js" type="text/javascript"></script>
	
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/jquery.dataTables.js"></script>
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/DT_bootstrap.js"></script>
  
   <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script> 
<style>
select{
	height: auto;
}
nav ul{
    z-index: 1000;
}
</style>
<style>
form {
  background: -webkit-linear-gradient(bottom, #CCCCCC, #EEEEEE 175px);
  background: -moz-linear-gradient(bottom, #CCCCCC, #EEEEEE 175px);
  background: linear-gradient(bottom, #CCCCCC, #EEEEEE 175px);
  margin: auto;
  position: relative;
  width: 60%;
  height: 200px;
  font-family: Tahoma, Geneva, sans-serif;
  font-size: 12px;
  font-style: italic;
  line-height: 24px;
  font-weight: bold;
  color: #09C;
  text-decoration: none;
  border-radius: 10px;
  padding: 10px;
  border: 1px solid #999;
  border: inset 1px solid #333;
  -webkit-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  -moz-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
}


input {
  width: 30%;
  display: block;
  border: 1px solid #999;
  height: 20px;
  -webkit-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  -moz-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
}

select#upload {
  width: 140px;
  height: 30px;
  display: block;
}

.button {
  width: 150px;
  position: absolute;
  right: 5px;
  bottom: 5px;
  background: #09C;
  color: #fff;
  font-family: Tahoma, Geneva, sans-serif;
  height: 30px;
  border-radius: 15px;
  border: 1p solid #999;
  margin-right: 40%;
  
}

input.button:hover {
  background: #fff;
  color: #09C;
}

select:focus, input:focus {
  border: 1px solid #09C;
}
</style> 
 <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
</head>
<body>
<?php
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");
}
else{header("location: logout.php");}
?>
<br><br>
<?php
include "connection.php";
$id = $_GET['id'];
$query1 = mysqli_query($db, "select * from attend where id=$id AND school='".$_SESSION["school"]."'");
while ($row1 = mysqli_fetch_array($query1)) {
echo '<center>';
echo '<br><br><form action="updatestudentsatt_exec.php" method="post" enctype="multipart/form-data">';
echo '<div>';
echo '<h2>Edit Student\'s Attendance Info :</h2><br>';
echo '<label>';
echo  '<input id="id" type="hidden" name="id" value="'.$row1['id'].'" />';
echo  '</label>';
echo '<label>';
echo  '<input id="id" type="readonly" readonly="readonly" name="student_name" value="'.$row1['student_name'].'" required/>';
echo  '</label>';
echo '<label>';
echo  '<input id="id" type="text" name="attend" value="'.$row1['attend'].'" required/>';
echo  '</label>';
echo '<label>';
echo  '<input style="display: none;" id="id" type="text" name="class" value="'.$row1['class'].'" required/>';
echo  '</label>';
echo '<label>';
echo  '<input style="display: none;" id="id" type="text" name="arms" value="'.$row1['arms'].'" required/>';
echo  '</label>';
echo '<label>';
echo  '<input style="display: none;" id="id" type="text" name="year" value="'.$row1['year'].'" required/>';
echo  '</label>';
echo '<label>';
echo  '<input style="display: none;" id="id" type="text" name="term" value="'.$row1['term'].'" required/>';
echo  '</label>';
echo '<label>';
echo  '<input style="display: none;" id="id" type="text" name="formt" value="'.$row1['formt'].'" required/>';
echo  '</label>';
echo '<label>';
 echo   '<input type="submit" class="button" name="btn-upload" value="Submit Form" />';
  echo  '</label>';
echo '</div>';
echo '</form><br>';
}
echo '</center>';
?>
<?php
include("footer.php");
?>
</body>
</html>