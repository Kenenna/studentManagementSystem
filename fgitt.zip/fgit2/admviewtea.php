<?php 
session_start();
include("auth.php");
include "connection.php";
$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>View Teachers</title>
<link rel="stylesheet" href="css/style.css" />
	
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">

	<script src="table/js/jquery.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js" type="text/javascript"></script>

<style>
select{
	height: auto;
}
nav li ul li{
    z-index: 1000;
    float: left;
}
#example{
    text-align: center;
}
</style>
   <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
      $('#example').DataTable( {
        "scrollY":        "550px",
        "scrollCollapse": true,
        "paging":         false
    } ); 
      
      
      
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>
 <script>
function confirmationDelete(anchor)
{
   var conf = confirm('Are you sure want to delete this record?');
   if(conf)
      window.location=anchor.attr("href");
}
</script> 
 <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
</head>
<body>
<?php
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
else{echo "";}
?>

<div class="row-fluid" style="width:100%;">
	        <div class="span12"><br><br><br><br>
	            <div class="container" style="width:100%;">			
				
					
		<table style="width:100%; float:left;" cellpadding="0" cellspacing="0" border="0" class="display" id="example">
				
			<thead><tr>
			<th style="display: none;">Teacher ID</th><th>Teacher</th><th style="display: none;">Class ID</th><th>Session Commencing</th><th>Term</th><th style="display: none;">Subject ID</th><th>Class</th><th>Subject</th><th>Edit</th><th>Delete</th>
			</thead></tr>
<?php
$result = mysqli_query($db, "SELECT * FROM teachers WHERE school='".$_SESSION["school"]."' ORDER BY teacher_name");
while ($row = mysqli_fetch_assoc($result)) {
	$term_id = $row['term_id'];
	if($term_id == 1){$term = 'First Term';}
	elseif($term_id == 2){$term = 'Second Term';}
	elseif($term_id == 3){$term = 'Third Term';}
	else{'';}
	
	
$class = $row['class_name'];
if($class=="Year 1"){
	if($ctype=="Js"){
	$cl = "JS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 1";
}
else{
	$cl = "Year 7";
}
}
elseif($class=="Year 2"){
	if($ctype=="Js"){
	$cl = "JS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 2";
}
else{
	$cl = "Year 2";
}
}
elseif($class=="Year 3"){
	if($ctype=="Js"){
	$cl = "JS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 3";
}
else{
	$cl = "Year 3";
}
}
elseif($class=="Year 4"){
	if($ctype=="Js"){
	$cl = "JS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 4";
}
else{
	$cl = "Year 4";
}
}
elseif($class=="Year 5"){
	if($ctype=="Js"){
	$cl = "JS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 5";
}
else{
	$cl = "Year 5";
}
}
elseif($class=="Year 6"){
	if($ctype=="Js"){
	$cl = "JS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 6";
}
else{
	$cl = "Year 6";
}
}
elseif($class=="Year 7"){
	if($ctype=="Js"){
	$cl = "JS1";
}else{
	$cl = "Year 7";
}
}else if($class=="Year 8"){
	if($ctype=="Js"){
	$cl = "JS2";
}else{
	$cl = "Year 8";
}
}else if($class=="Year 9"){
	if($ctype=="Js"){
	$cl = "JS3";
}else{
	$cl = "Year 9";
}
}else if($class=="Year 10"){
	if($ctype=="Js"){
	$cl = "SS1";
}else{
	$cl = "Year 10";
}
}else if($class=="Year 11"){
	if($ctype=="Js"){
	$cl = "SS2";
}else{
	$cl = "Year 11";
}
}else if($class=="Year 12"){
	if($ctype=="Js"){
	$cl = "SS3";
}else{
	$cl = "Year 12";
}
}else{
	$cl = "NOT APPLICABLE";
}
	
	
	$year_id = $row['year_id'];
	if($year_id == 1){$year = '2012';}
	elseif($year_id == 2){$year = '2013';}
	elseif($year_id == 3){$year = '2014';}
	elseif($year_id == 4){$year = '2015';}
	elseif($year_id == 5){$year = '2016';}
	elseif($year_id == 6){$year = '2017';}
	elseif($year_id == 7){$year = '2018';}
	elseif($year_id == 8){$year = '2019';}
	elseif($year_id == 9){$year = '2020';}
	elseif($year_id == 10){$year = '2021';}
	elseif($year_id == 11){$year = '2022';}
	elseif($year_id == 12){$year = '2023';}
	elseif($year_id == 13){$year = '2024';}
	elseif($year_id == 14){$year = '2025';}
	elseif($year_id == 15){$year = '2026';}
	elseif($year_id == 16){$year = '2027';}
	elseif($year_id == 17){$year = '2028';}
	elseif($year_id == 18){$year = '2029';}
	elseif($year_id == 19){$year = '2030';}
	elseif($year_id == 20){$year = '2031';}
	elseif($year_id == 21){$year = '2032';}
	elseif($year_id == 22){$year = '2033';}
	elseif($year_id == 23){$year = '2034';}
	elseif($year_id == 24){$year = '2035';}
	elseif($year_id == 25){$year = '2036';}
	elseif($year_id == 26){$year = '2037';}
	elseif($year_id == 27){$year = '2038';}
	elseif($year_id == 28){$year = '2039';}
	elseif($year_id == 29){$year = '2040';}
	elseif($year_id == 30){$year = '2041';}
	elseif($year_id == 31){$year = '2042';}
	elseif($year_id == 32){$year = '2043';}
	elseif($year_id == 33){$year = '2044';}
	elseif($year_id == 34){$year = '2045';}
	elseif($year_id == 35){$year = '2046';}
	else{'';}
echo '<tr>';
echo '<td style="display: none;"><inputtype="text" id="teacher_id" name="teacher_id" value="'.$row['teacher_id'].'" /></td>';		
echo '<td><input style="display: none;" type="text" id="teacher_name" name="teacher_name" value="'.$row['teacher_name'].'" />'.$row['teacher_name'].'</td>';	
echo '<td style="display: none;"><input readonly="readonly" type="text" id="class_id" name="class_id" value="'.$row['class_id'].'" /></td>';
echo '<td><input style="display: none;" type="text" id="year_id" name="year_id" value="'.$row['year_id'].'" />'.$year.'</td>';
echo '<td><input style="display: none;" type="hidden" id="term_id" name="term_id" value="'.$row['term_id'].'" />'.$term.'</td>';
echo '<td style="display: none;"><input readonly="readonly" type="text" id="subject_id" name="subject_id" value="'.$row['subject_id'].'" /></td>';
echo '<td><input style="display: none;" type="text" id="class_name" name="class_name" value="'.$row['class_name'].'" />'.$cl.'</td>';	
echo '<td><input style="display: none;" type="text" id="subject" name="subject" value="'.$row['subject'].'" />'.$row['subject'].'</td>';	
echo '<td><a href="updateteabyadmin.php?id='.$row['id'].'"><img src="table/edit-icon.png" alt="no image" height="30" width="30" /></a></td>';
echo '<td><a onClick="javascript:confirmationDelete($(this));return false;" href="delteabyadmin.php?id='.$row['id'].'"><img src="table/deletee.png" alt="no image" height="30" width="30" /></a></td>';
'</tr>';
}
?>
</table>
</div></div></div><br><br><br>
<?php
include("footer.php");
?>
 </body>
</html>
