<?php
session_start();
include("auth.php"); //include auth.php file on all secure pages
include ("connection.php");
if (isset($_REQUEST['btn-upload'])) {
$id = $_REQUEST['id'];
$teacher_name = $_REQUEST['teacher_name'];
$year = $_REQUEST['year'];
$term = $_REQUEST['term'];
$class_name2 = $_REQUEST['class_name2'];
$subject = $_REQUEST['subject'];

$b = "";
if($class_name2=="Primary 1"){
	$class_name = "Year 1";
}
else if($class_name2=="Primary 2"){
	$class_name = "Year 2";
}
else if($class_name2=="Primary 3"){
	$class_name = "Year 3";
}
else if($class_name2=="Primary 4"){
	$class_name = "Year 4";
}
else if($class_name2=="Primary 5"){
	$class_name = "Year 5";
}
else if($class_name2=="Primary 6"){
	$class_name = "Year 6";
}
else if($class_name2=="JS1"){
	$class_name = "Year 7";
}
else if($class_name2=="JS2"){
	$class_name = "Year 8";
}
else if($class_name2=="JS3"){
	$class_name = "Year 9";
}
else if($class_name2=="SS1"){
	$class_name = "Year 10";
}
else if($class_name2=="SS2"){
	$class_name = "Year 11";
}
else if($class_name2=="SS3"){
	$class_name = "Year 12";
}
else{
	$class_name = $class_name2;
}

$result = mysqli_query($db, "SELECT * FROM teachers where teacher_name='$teacher_name' AND school='".$_SESSION["school"]."'");
while ($row = mysqli_fetch_assoc($result)) {
	$teacher_id2[] = $row['teacher_id'];
}
$teacher_id = current($teacher_id2);

$result2 = mysqli_query($db, "SELECT * FROM teachers where class_name='$class_name' AND school='".$_SESSION["school"]."'");
while ($row2 = mysqli_fetch_assoc($result2)) {
	$class_id2[] = $row2['class_id'];
}
$class_id = current($class_id2);

$result3 = mysqli_query($db, "SELECT * FROM teachers where subject='$subject' AND school='".$_SESSION["school"]."'");
while ($row3 = mysqli_fetch_assoc($result3)) {
	$subject_id3[] = $row3['subject_id'];
}
$subject_id = current($subject_id3);

$year;
	if($year == '2012'){$yr = 1;}
	elseif($year == '2013'){$yr = 2;}
	elseif($year == '2014'){$yr = 3;}
	elseif($year == '2015'){$yr = 4;}
	elseif($year == '2016'){$yr = 5;}
	elseif($year == '2017'){$yr = 6;}
	elseif($year == '2018'){$yr = 7;}
	elseif($year == '2019'){$yr = 8;}
	elseif($year == '2020'){$yr = 9;}
	elseif($year == '2021'){$yr = 10;}
	elseif($year == '2022'){$yr = 11;}
	elseif($year == '2023'){$yr = 12;}
	elseif($year == '2024'){$yr = 13;}
	elseif($year == '2025'){$yr = 14;}
	elseif($year == '2026'){$yr = 15;}
	elseif($year == '2027'){$yr = 16;}
	elseif($year == '2028'){$yr = 17;}
	elseif($year == '2029'){$yr = 18;}
	elseif($year == '2030'){$yr = 19;}
	elseif($year == '2031'){$yr = 20;}
	elseif($year == '2032'){$yr = 21;}
	elseif($year == '2033'){$yr = 22;}
	elseif($year == '2034'){$yr = 23;}
	elseif($year == '2035'){$yr = 24;}
	elseif($year == '2036'){$yr = 25;}
	elseif($year == '2037'){$yr = 26;}
	elseif($year == '2038'){$yr = 27;}
	elseif($year == '2039'){$yr = 28;}
	elseif($year == '2040'){$yr = 29;}
	else{'';}

$term;
	if($term == 'First Term'){$t = 1;}
	elseif($term == 'Second Term'){$t = 2;}
	elseif($term == 'Third Term'){$t = 3;}
	else{'';}

$checktea = mysqli_query($db, "SELECT * FROM teachers where teacher_id='$teacher_id' AND teacher_name='$teacher_name' AND class_id='$class_id' AND year_id='$yr' AND term_id='$t' AND subject_id='$subject_id' AND class_name='$class_name' AND subject='$subject' AND school='".$_SESSION["school"]."'");
  $counttea = mysqli_num_rows($checktea);
  if($counttea < 1){	
//echo $counttea;  
 $query =mysqli_query($db, "UPDATE teachers SET teacher_id='$teacher_id', teacher_name='$teacher_name', class_id='$class_id', year_id='$yr', term_id='$t', subject_id='$subject_id', class_name='$class_name', subject='$subject', school='".$_SESSION["school"]."' WHERE id='$id'");
echo '<img src="../images/492.png" /> &nbsp;! data updated successfully';
		echo '<meta content="2;admviewtea.php" http-equiv="refresh" />';
 /**
if (!mysqli_query ($db,$query) )
			{
			echo '<img src="../images/492.png" /> &nbsp;! data not updated';
			echo '<meta content="2;admviewtea.php" http-equiv="refresh" />';	
			die (mysqli_error());
			}else{
	
		echo '<img src="../images/492.png" /> &nbsp;! data updated successfully';
		echo '<meta content="2;admviewtea.php" http-equiv="refresh" />';
			}
**/
  }else{
	echo "<center><div class='form'><h5 style='color: red;'>A teacher with the given name teaching the given class for that term and year already exists.</h5></div></center>";
	echo '<meta content="2;admviewtea.php" http-equiv="refresh" />';
  }
}
?>