<?php
	session_start();
	include("auth.php"); 
	include('db.php');
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>General Attendance</title>

<script type="text/javascript" src="js/jquery-2.1.4.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script>
$(document).ready(function() {
			var arrp = [];
   $( ".redat" ).each(function( index ){
	   var schopenval = this.id;
	   var ar = $('[id='+schopenval+']').html();
	   $('[id='+schopenval+']').html(ar.replace(/,\s*$/,""));
	  // arrp.push(ar);
	});
});
</script>
<style>
.myButton {
	background-color:#44c767;
	-moz-border-radius:28px;
	-webkit-border-radius:28px;
	border-radius:5px;
	border:1px solid #18ab29;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:15px;
	padding:6px 24px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
	float: left;
}
.myButton:hover {
	background-color:#5cbf2a;
}
.myButton:active {
	position:relative;
	top:1px;
}
</style>
<style>
ul.topnav {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}
ul.topnav li {float: left;}
ul.topnav li a {
    display: inline-block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    transition: 0.3s;
    font-size: 17px;
}
ul.topnav li a:hover {background-color: #555;}
ul.topnav li.icon {display: none;}

@media screen and (max-width:680px) {
  ul.topnav li:not(:first-child) {display: none;}
  ul.topnav li.icon {
    float: right;
    display: inline-block;
  }
}
@media screen and (max-width:680px) {
  ul.topnav.responsive {position: relative;}
  ul.topnav.responsive li.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  ul.topnav.responsive li {
    float: none;
    display: inline;
  }
  ul.topnav.responsive li a {
    display: block;
    text-align: left;
  }
}
</style>

  
   <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>


<script>
$(document).ready(function() {	
$("#genattpdf").submit(function( evt ) {
			evt.preventDefault();
var countlist = $("#resultlist li").length;	
if(countlist > 0){
$(".liresultlist").fadeOut(500); 	
}		
$.ajax({
type: "POST",
url: "pdf4/examples/viewgenattpdf.php",
cache: false,
data: $("#genattpdf").serializeArray(),
beforeSend: function(){
	$("#loadit").addClass("loader");
	$("#loadit").after("<label id='forremoval' style='color: red;' >We are preparing your download. Please wait...</label>");
	$('#attpdfsubmit').attr( 'onClick', 'return false' );
	},
success: function(response){
$("#resultlist").append("<li class='liresultlist'><a class='myButton' style='margin: auto; text-align: id='forresult' center;' href='pdf4/examples/"+response+"' download>download attendance record</a></li>");	
},
complete: function(){
$("#loadit").removeClass("loader");	
$("#forremoval").remove();
$('#attpdfsubmit').attr( 'onClick', 'return true' );
}
});			
});
});
</script>


<script>
$(document).ready(function() {	
$("#genattpdfemail").submit(function( evt ) {
			evt.preventDefault();		
$.ajax({
type: "POST",
url: "pdf4/examples/viewgenattpdfemail.php",
cache: false,
data: $("#genattpdfemail").serializeArray(),
success: function(responseemail){
$("#pdfatt").val(responseemail);	
$("#formforemaill").show();	
}
});			
});
});
</script>

<script>
$(document).ready(function() {	
$("#formforemaill").submit(function( evtt ) {
evtt.preventDefault();	
$.ajax({
type: "POST",
url: "pdf4/examples/mailer/examples/genattpdfemail.php",
cache: false,
data: $("#formforemaill").serialize(),
beforeSend: function(){
	$("#loadit").addClass("loader");
	$("#loadit").after("<label id='forremoval' style='color: red;' >We are preparing your data for emailng</label>");
	$('#attpdfsubmit').attr( 'onClick', 'return false' );
	},
success: function(msent){
alert(msent);
},
complete: function(){
$("#loadit").removeClass("loader");	
$("#forremoval").remove();
$('#attpdfsubmit').attr( 'onClick', 'return true' );
}
	
});			
});
});
</script>


<style>
.loader {
  border: 8px solid #f3f3f3;
  border-radius: 50%;
  border-top: 8px solid blue;
  border-right: 8px solid green;
  border-bottom: 8px solid red;
  width: 20px;
  height: 20px;
  -webkit-animation: spin 2s linear infinite;
  animation: spin 2s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.dnone{
	display: none;
}
</style>



<style>
table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    border: 1px solid #ddd;
}

th, td {
    border: none;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
 <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
</head>

<body>
<?php
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'admin'){
include("header.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");
}
elseif($_SESSION['role'] == 'student'){
include("headerstudent.php");
}
else{ header("location: logout.php");}
?>
				
<?php
include "connection.php";
$class = $_POST['class'];
$year = $_POST['year'];
$term = $_POST['term'];
$student_name = $_POST['student_name'];
$formt = $_POST['formt'];
$arms = $_POST['arms'];

echo '<div style="width:100%; text-align:center; color: red;"><b>NUMBER OF TIMES IN '.strtoupper($term).', '.$year.'/'.($year+1).' SESSION EACH STUDENT IN '.strtoupper($class).' '.strtoupper($arms).' WAS PRESENT PER WEEK</b></div>';

$result3 = mysqli_query($db, "SELECT * FROM maxattname WHERE year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($row3 = mysqli_fetch_assoc($result3)) {
$termbegin1[] = $row3['termbegin'];	
}
$termbegin = current($termbegin1);



$result6a = mysqli_query($db, "SELECT * FROM attend where (datename >= '$termbegin') AND (datename <= DATE_ADD( '$termbegin', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND attend='midterm' AND school='".$_SESSION["school"]."'");
$chmida = mysqli_num_rows($result6a);
$tb = (round(abs(strtotime($termbegin) + 604800)));
$tb1 = date("Y-m-d", $tb);
$result6b = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND attend='midterm' AND school='".$_SESSION["school"]."'");
$chmidb = mysqli_num_rows($result6b);
$tb2 = (round(abs(strtotime($tb1) + 604800)));
$tb3 = date("Y-m-d", $tb2);
$result6c = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb3') AND (datename <= DATE_ADD( '$tb3', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND attend='midterm' AND school='".$_SESSION["school"]."'");
$chmidc = mysqli_num_rows($result6c);
$tb4 = (round(abs(strtotime($tb3) + 604800)));
$tb5 = date("Y-m-d", $tb4);
$result6d = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb5') AND (datename <= DATE_ADD( '$tb5', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND attend='midterm' AND school='".$_SESSION["school"]."'");
$chmidd = mysqli_num_rows($result6d);
$tb6 = (round(abs(strtotime($tb5) + 604800)));
$tb7 = date("Y-m-d", $tb6);
$result6e = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb7') AND (datename <= DATE_ADD( '$tb7', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND attend='midterm' AND school='".$_SESSION["school"]."'");
$chmide = mysqli_num_rows($result6e);
$tb8 = (round(abs(strtotime($tb7) + 604800)));
$tb9 = date("Y-m-d", $tb8);
$result6f = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb9') AND (datename <= DATE_ADD( '$tb9', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND attend='midterm' AND school='".$_SESSION["school"]."'");
$chmidf = mysqli_num_rows($result6f);
$tb10 = (round(abs(strtotime($tb9) + 604800)));
$tb11 = date("Y-m-d", $tb10);
$result6g = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb11') AND (datename <= DATE_ADD( '$tb11', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND attend='midterm' AND school='".$_SESSION["school"]."'");
$chmidg = mysqli_num_rows($result6g);
$tb12 = (round(abs(strtotime($tb11) + 604800)));
$tb13 = date("Y-m-d", $tb12);
$result6h = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb13') AND (datename <= DATE_ADD( '$tb13', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND attend='midterm' AND school='".$_SESSION["school"]."'");
$chmidh = mysqli_num_rows($result6h);
$tb14 = (round(abs(strtotime($tb13) + 604800)));
$tb15 = date("Y-m-d", $tb14);
$result6i = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb15') AND (datename <= DATE_ADD( '$tb15', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND attend='midterm' AND school='".$_SESSION["school"]."'");
$chmidi = mysqli_num_rows($result6i);
$tb16 = (round(abs(strtotime($tb15) + 604800)));
$tb17 = date("Y-m-d", $tb16);
$result6j = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb15') AND (datename <= DATE_ADD( '$tb15', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND attend='midterm' AND school='".$_SESSION["school"]."'");
$chmidj = mysqli_num_rows($result6j);
$tb18 = (round(abs(strtotime($tb17) + 604800)));
$tb19 = date("Y-m-d", $tb18);
$result6k = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb19') AND (datename <= DATE_ADD( '$tb19', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND attend='midterm' AND school='".$_SESSION["school"]."'");
$chmidk = mysqli_num_rows($result6k);
$tb20 = (round(abs(strtotime($tb19) + 604800)));
$tb21 = date("Y-m-d", $tb20);
$result6l = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb21') AND (datename <= DATE_ADD( '$tb21', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND attend='midterm' AND school='".$_SESSION["school"]."'");
$chmidl = mysqli_num_rows($result6l);
$tb22 = (round(abs(strtotime($tb21) + 604800)));
$tb23 = date("Y-m-d", $tb22);
$result6m = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb23') AND (datename <= DATE_ADD( '$tb23', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND attend='midterm' AND school='".$_SESSION["school"]."'");
$chmidm = mysqli_num_rows($result6m);
$tb24 = (round(abs(strtotime($tb23) + 604800)));
$tb25 = date("Y-m-d", $tb24);
$result6n = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb25') AND (datename <= DATE_ADD( '$tb25', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND attend='midterm' AND school='".$_SESSION["school"]."'");
$chmidn = mysqli_num_rows($result6n);





$date = DateTime::createFromFormat("Y-m-d", $termbegin);
$l = $date->format("l");
if($l == "Monday"){
$termbegin2 = (round(abs(strtotime($termbegin))));
$termbegin = date("Y-m-d", $termbegin2);	
$sd = strtotime($termbegin);
$sd2 = $sd + 345600;
$sd3 = date("Y-m-d", $sd2);
$resultformid5aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row5 = mysqli_fetch_assoc($resultformid5aa)) {
$resultformid5bb[] = $row5['dt'];	
}
$resultformid5cc = current($resultformid5bb);
$resultmid36 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$termbegin') AND (datename <= DATE_ADD( '$termbegin', INTERVAL 4 DAY )) AND datename < '$resultformid5cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND (formt='$formt' OR formt!='$formt') AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid1 = mysqli_num_rows($resultmid36);
$result36 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$termbegin') AND (datename <= DATE_ADD( '$termbegin', INTERVAL 4 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND (formt='$formt' OR formt!='$formt') AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att1 = mysqli_num_rows($result36);

$resultmornmon = mysqli_query($db, "SELECT student_name FROM attend where (datename = '$termbegin') AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND (formt='$formt' OR formt!='$formt') AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornmon36 = mysqli_fetch_assoc($resultmornmon)) {
	$wmorn111[] = $rowmornmon36['student_name'];
}
$monmorn = count($wmorn111);
$resultaftmon = mysqli_query($db, "SELECT student_name FROM attend where (datename = '$termbegin') AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND (formt='$formt' OR formt!='$formt') AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftmon36 = mysqli_fetch_assoc($resultaftmon)) {
	$waft111[] = $rowaftmon['student_name'];
}
$monaft = count($waft111);
$resultmorntue = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$termbegin', INTERVAL 1 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND (formt='$formt' OR formt!='$formt') AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmorntue = mysqli_fetch_assoc($resultmorntue)) {
	$wmorntue111[] = $rowmorntue['student_name'];
}
$tuemorn = count($wmorntue111);
$resultafttue = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$termbegin', INTERVAL 1 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND (formt='$formt' OR formt!='$formt') AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowafttue = mysqli_fetch_assoc($resultafttue)) {
	$wafttue111[] = $rowafttue['student_name'];
}
$tueaft = count($wafttue111);
$monaft = count($waft111);
$resultmornwed = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$termbegin', INTERVAL 2 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND (formt='$formt' OR formt!='$formt') AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornwed = mysqli_fetch_assoc($resultmornwed)) {
	$wmornwed111[] = $rowmornwed['student_name'];
}
$wedmorn = count($wmornwed111);
$resultaftwed = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$termbegin', INTERVAL 2 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND (formt='$formt' OR formt!='$formt') AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftwed = mysqli_fetch_assoc($resultaftwed)) {
	$waftwed111[] = $rowaftwed['student_name'];
}
$wedaft = count($waftwed111);
$resultmornthur = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$termbegin', INTERVAL 3 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND (formt='$formt' OR formt!='$formt') AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornthur = mysqli_fetch_assoc($resultmornthur)) {
	$wmornthur111[] = $rowmornthur['student_name'];
}
$thurmorn = count($wmornthur111);
$resultaftthur = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$termbegin', INTERVAL 3 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND (formt='$formt' OR formt!='$formt') AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftthur = mysqli_fetch_assoc($resultaftthur)) {
	$waftthur111[] = $rowaftthur['student_name'];
}
$thuraft = count($waftthur111);
$resultmornfri = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$termbegin', INTERVAL 4 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND (formt='$formt' OR formt!='$formt') AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornfri = mysqli_fetch_assoc($resultmornfri)) {
	$wmornfri111[] = $rowmornfri['student_name'];
}
$frimorn = count($wmornfri111);
$resultaftfri = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$termbegin', INTERVAL 4 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND (formt='$formt' OR formt!='$formt') AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftfri = mysqli_fetch_assoc($resultaftfri)) {
	$waftfri111[] = $rowaftfri['student_name'];
}
$friaft = count($waftfri111);
$resultmale36 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND (datename >= '$termbegin') AND (datename <= DATE_ADD( '$termbegin', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale36 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$termbegin') AND (datename <= DATE_ADD( '$termbegin', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale36 = mysqli_fetch_assoc($resultmale36)) {
	$wmale111[] = $rowmale36['student_name'];
}
$wmale = $wmale111;
$wkmale11 = mysqli_num_rows($resultmale36);
while ($rowfemale36 = mysqli_fetch_assoc($resultfemale36)) {
	$wfemale111[] = $rowfemale36['student_name'];
}
$wfemale = $wfemale111;
$wkfemale11 = mysqli_num_rows($resultfemale36);
}
elseif($l == "Tuesday"){
$sd = strtotime($termbegin);
$sd2 = $sd + 259200;
$sd3 = date("Y-m-d", $sd2);
$resultformid5aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND (formt='$formt' OR formt!='$formt') AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row5 = mysqli_fetch_assoc($resultformid5aa)) {
$resultformid5bb[] = $row5['dt'];	
}
$resultformid5cc = current($resultformid5bb);
$resultmid36 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$termbegin') AND (datename <= DATE_ADD( '$termbegin', INTERVAL 3 DAY )) AND datename < '$resultformid5cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND (formt='$formt' OR formt!='$formt') AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid1 = mysqli_num_rows($resultmid36);
$result36 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$termbegin') AND (datename <= DATE_ADD( '$termbegin', INTERVAL 3 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND (formt='$formt' OR formt!='$formt') AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att1 = mysqli_num_rows($result36);
$resultmale36 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$termbegin' AND (datename <= $sd3) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale36 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$termbegin') AND (datename <= $sd3) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale36 = mysqli_fetch_assoc($resultmale36)) {
	$wmale111[] = $rowmale36['student_name'];
}
$wmale = $wmale111;
$wkmale11 = mysqli_num_rows($resultmale36);
while ($rowfemale36 = mysqli_fetch_assoc($resultfemale36)) {
	$wfemale111[] = $rowfemale36['student_name'];
}
$wfemale = $wfemale111;
$wkfemale11 = mysqli_num_rows($resultfemale36);
}
elseif($l == "Wednesday"){
$sd = strtotime($termbegin);
$sd2 = $sd + 345600;
$sd3 = date("Y-m-d", $sd2);
$resultformid5aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND (formt='$formt' OR formt!='$formt') AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row5 = mysqli_fetch_assoc($resultformid5aa)) {
$resultformid5bb[] = $row5['dt'];	
}
$resultformid5cc = current($resultformid5bb);
$resultmid36 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$termbegin') AND (datename <= DATE_ADD( '$termbegin', INTERVAL 2 DAY )) AND datename < '$resultformid5cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND (formt='$formt' OR formt!='$formt') AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid1 = mysqli_num_rows($resultmid36);
$result36 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$termbegin') AND (datename <= DATE_ADD( '$termbegin', INTERVAL 2 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND (formt='$formt' OR formt!='$formt') AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att1 = mysqli_num_rows($result36);
$resultmale36 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$termbegin' AND (datename <= DATE_ADD( '$termbegin', INTERVAL 2 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale36 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$termbegin') AND (datename <= DATE_ADD( '$termbegin', INTERVAL 2 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale36 = mysqli_fetch_assoc($resultmale36)) {
	$wmale111[] = $rowmale36['student_name'];
}
$wmale = $wmale111;
$wkmale11 = mysqli_num_rows($resultmale36);
while ($rowfemale36 = mysqli_fetch_assoc($resultfemale36)) {
	$wfemale111[] = $rowfemale36['student_name'];
}
$wfemale = $wfemale111;
$wkfemale11 = mysqli_num_rows($resultfemale36);
}
elseif($l == "Thursday"){
$sd = strtotime($termbegin);
$sd2 = $sd + 345600;
$sd3 = date("Y-m-d", $sd2);
$resultformid5aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND (formt='$formt' OR formt!='$formt') AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row5 = mysqli_fetch_assoc($resultformid5aa)) {
$resultformid5bb[] = $row5['dt'];	
}
$resultformid5cc = current($resultformid5bb);
$resultmid36 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$termbegin') AND (datename <= DATE_ADD( '$termbegin', INTERVAL 1 DAY )) AND datename < '$resultformid5cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND (formt='$formt' OR formt!='$formt') AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid1 = mysqli_num_rows($resultmid36);
$result36 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$termbegin') AND (datename <= DATE_ADD( '$termbegin', INTERVAL 1 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND (formt='$formt' OR formt!='$formt') AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att1 = mysqli_num_rows($result36);
$resultmale36 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$termbegin' AND (datename <= DATE_ADD( '$termbegin', INTERVAL 1 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale36 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$termbegin') AND (datename <= DATE_ADD( '$termbegin', INTERVAL 1 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale36 = mysqli_fetch_assoc($resultmale36)) {
	$wmale111[] = $rowmale36['student_name'];
}
$wmale = $wmale111;
$wkmale11 = mysqli_num_rows($resultmale36);
while ($rowfemale36 = mysqli_fetch_assoc($resultfemale36)) {
	$wfemale111[] = $rowfemale36['student_name'];
}
$wfemale = $wfemale111;
$wkfemale11 = mysqli_num_rows($resultfemale36);
}
else{
$sd = strtotime($termbegin);
$sd2 = $sd + 345600;
$sd3 = date("Y-m-d", $sd2);
$resultformid5aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row5 = mysqli_fetch_assoc($resultformid5aa)) {
$resultformid5bb[] = $row5['dt'];	
}
$resultformid5cc = current($resultformid5bb);
$resultmid36 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$termbegin') AND (datename <= DATE_ADD( '$termbegin', INTERVAL 0 DAY )) AND datename < '$resultformid5cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND (formt='$formt' OR formt!='$formt') AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid1 = mysqli_num_rows($resultmid36);
$result36 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$termbegin') AND (datename <= DATE_ADD( '$termbegin', INTERVAL 0 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND (formt='$formt' OR formt!='$formt') AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att1 = mysqli_num_rows($result36);
$resultmale36 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$termbegin' AND (datename <= DATE_ADD( '$termbegin', INTERVAL 0 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale36 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$termbegin') AND (datename <= DATE_ADD( '$termbegin', INTERVAL 0 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale36 = mysqli_fetch_assoc($resultmale36)) {
	$wmale111[] = $rowmale36['student_name'];
}
$wmale = $wmale111;
$wkmale11 = mysqli_num_rows($resultmale36);
while ($rowfemale36 = mysqli_fetch_assoc($resultfemale36)) {
	$wfemale111[] = $rowfemale36['student_name'];
}
$wfemale = $wfemale111;
$wkfemale11 = mysqli_num_rows($resultfemale36);
}







if($l == "Monday"){
$tb = (round(abs(strtotime($termbegin) + 604800)));
$tb1 = date("Y-m-d", $tb);
$resultformid7aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row7 = mysqli_fetch_assoc($resultformid7aa)) {
$resultformid7bb[] = $row7['dt'];	
}
$resultformid7cc = current($resultformid7bb);
$resultmid7ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 4 DAY )) AND datename < '$resultformid7cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid2 = mysqli_num_rows($resultmid7ccc);
$result8 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 4 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att2 = mysqli_num_rows($result8);
$resultmornmon2 = mysqli_query($db, "SELECT student_name FROM attend where (datename = '$tb1') AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornmon362 = mysqli_fetch_assoc($resultmornmon2)) {
	$wmorn1112[] = $rowmornmon362['student_name'];
}
$monmorn2 = count($wmorn1112);
$resultaftmon2 = mysqli_query($db, "SELECT student_name FROM attend where (datename = '$tb1') AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftmon362 = mysqli_fetch_assoc($resultaftmon2)) {
	$waft1112[] = $rowaftmon2['student_name'];
}
$monaft2 = count($waft1112);
$resultmorntue2 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb1', INTERVAL 1 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmorntue2 = mysqli_fetch_assoc($resultmorntue2)) {
	$wmorntue1112[] = $rowmorntue2['student_name'];
}
$tuemorn2 = count($wmorntue1112);
$resultafttue2 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb1', INTERVAL 1 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowafttue2 = mysqli_fetch_assoc($resultafttue2)) {
	$wafttue1112[] = $rowafttue2['student_name'];
}
$tueaft2 = count($wafttue1112);
$monaft2 = count($waft1112);
$resultmornwed2 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb1', INTERVAL 2 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornwed2 = mysqli_fetch_assoc($resultmornwed2)) {
	$wmornwed1112[] = $rowmornwed2['student_name'];
}
$wedmorn2 = count($wmornwed1112);
$resultaftwed2 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb1', INTERVAL 2 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftwed2 = mysqli_fetch_assoc($resultaftwed2)) {
	$waftwed1112[] = $rowaftwed2['student_name'];
}
$wedaft2 = count($waftwed1112);
$resultmornthur2 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb1', INTERVAL 3 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornthur2 = mysqli_fetch_assoc($resultmornthur2)) {
	$wmornthur1112[] = $rowmornthur2['student_name'];
}
$thurmorn2 = count($wmornthur1112);
$resultaftthur2 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb1', INTERVAL 3 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftthur2 = mysqli_fetch_assoc($resultaftthur2)) {
	$waftthur1112[] = $rowaftthur2['student_name'];
}
$thuraft2 = count($waftthur1112);
$resultmornfri2 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb1', INTERVAL 4 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornfri2 = mysqli_fetch_assoc($resultmornfri2)) {
	$wmornfri1112[] = $rowmornfri2['student_name'];
}
$frimorn2 = count($wmornfri1112);
$resultaftfri2 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb1', INTERVAL 4 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftfri2 = mysqli_fetch_assoc($resultaftfri2)) {
	$waftfri1112[] = $rowaftfri2['student_name'];
}
$friaft2 = count($waftfri1112);
$resultmale8 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb1' AND (datename <= DATE_ADD( '$tb1', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale8 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale8 = mysqli_fetch_assoc($resultmale8)) {
	$wmale222[] = $rowmale8['student_name'];
}
$wmale2 = $wmale222;
$wkmale22 = mysqli_num_rows($resultmale8);
while ($rowfemale8 = mysqli_fetch_assoc($resultfemale8)) {
	$wfemale222[] = $rowfemale8['student_name'];
}
$wfemale2 = $wfemale222;
$wkfemale22 = mysqli_num_rows($resultfemale8);
}
elseif($l == "Tuesday"){
$tb = (round(abs(strtotime($termbegin) + 604800)));
$tb1 = date("Y-m-d", $tb);
$resultformid7aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row7 = mysqli_fetch_assoc($resultformid7aa)) {
$resultformid7bb[] = $row7['dt'];	
}
$resultformid7cc = current($resultformid7bb);
$resultmid7ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 3 DAY )) AND datename < '$resultformid7cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid2 = mysqli_num_rows($resultmid7ccc);
$result8 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 3 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att2 = mysqli_num_rows($result8);
$resultmale8 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb1' AND (datename <= DATE_ADD( '$tb1', INTERVAL 3 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale8 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 3 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale8 = mysqli_fetch_assoc($resultmale8)) {
	$wmale222[] = $rowmale8['student_name'];
}
$wmale2 = $wmale222;
$wkmale22 = mysqli_num_rows($resultmale8);
while ($rowfemale8 = mysqli_fetch_assoc($resultfemale8)) {
	$wfemale222[] = $rowfemale8['student_name'];
}
$wfemale2 = $wfemale222;
$wkfemale22 = mysqli_num_rows($resultfemale8);
}
elseif($l == "Wednesday"){
$tb = (round(abs(strtotime($termbegin) + 604800)));
$tb1 = date("Y-m-d", $tb);
$resultformid7aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row7 = mysqli_fetch_assoc($resultformid7aa)) {
$resultformid7bb[] = $row7['dt'];	
}
$resultformid7cc = current($resultformid7bb);
$resultmid7ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 2 DAY )) AND datename < '$resultformid7cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid2 = mysqli_num_rows($resultmid7ccc);
$result8 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 2 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att2 = mysqli_num_rows($result8);
$resultmale8 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb1' AND (datename <= DATE_ADD( '$tb1', INTERVAL 2 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale8 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 2 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale8 = mysqli_fetch_assoc($resultmale8)) {
	$wmale222[] = $rowmale8['student_name'];
}
$wmale2 = $wmale222;
$wkmale22 = mysqli_num_rows($resultmale8);
while ($rowfemale8 = mysqli_fetch_assoc($resultfemale8)) {
	$wfemale222[] = $rowfemale8['student_name'];
}
$wfemale2 = $wfemale222;
$wkfemale22 = mysqli_num_rows($resultfemale8);
}
elseif($l == "Tuesday"){
$tb = (round(abs(strtotime($termbegin) + 604800)));
$tb1 = date("Y-m-d", $tb);
$resultformid7aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row7 = mysqli_fetch_assoc($resultformid7aa)) {
$resultformid7bb[] = $row7['dt'];	
}
$resultformid7cc = current($resultformid7bb);
$resultmid7ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 3 DAY )) AND datename < '$resultformid7cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid2 = mysqli_num_rows($resultmid7ccc);
$result8 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 3 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att2 = mysqli_num_rows($result8);
$resultmale8 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb1' AND (datename <= DATE_ADD( '$tb1', INTERVAL 3 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale8 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 3 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale8 = mysqli_fetch_assoc($resultmale8)) {
	$wmale222[] = $rowmale8['student_name'];
}
$wmale2 = $wmale222;
$wkmale22 = mysqli_num_rows($resultmale8);
while ($rowfemale8 = mysqli_fetch_assoc($resultfemale8)) {
	$wfemale222[] = $rowfemale8['student_name'];
}
$wfemale2 = $wfemale222;
$wkfemale22 = mysqli_num_rows($resultfemale8);
}
elseif($l == "Wednesay"){
$tb = (round(abs(strtotime($termbegin) + 604800)));
$tb1 = date("Y-m-d", $tb);
$resultformid7aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row7 = mysqli_fetch_assoc($resultformid7aa)) {
$resultformid7bb[] = $row7['dt'];	
}
$resultformid7cc = current($resultformid7bb);
$resultmid7ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 2 DAY )) AND datename < '$resultformid7cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid2 = mysqli_num_rows($resultmid7ccc);
$result8 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 2 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att2 = mysqli_num_rows($result8);
$resultmale8 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb1' AND (datename <= DATE_ADD( '$tb1', INTERVAL 2 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale8 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 2 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale8 = mysqli_fetch_assoc($resultmale8)) {
	$wmale222[] = $rowmale8['student_name'];
}
$wmale2 = $wmale222;
$wkmale22 = mysqli_num_rows($resultmale8);
while ($rowfemale8 = mysqli_fetch_assoc($resultfemale8)) {
	$wfemale222[] = $rowfemale8['student_name'];
}
$wfemale2 = $wfemale222;
$wkfemale22 = mysqli_num_rows($resultfemale8);
}
elseif($l == "Thursday"){
$tb = (round(abs(strtotime($termbegin) + 604800)));
$tb1 = date("Y-m-d", $tb);
$resultformid7aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row7 = mysqli_fetch_assoc($resultformid7aa)) {
$resultformid7bb[] = $row7['dt'];	
}
$resultformid7cc = current($resultformid7bb);
$resultmid7ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 1 DAY )) AND datename < '$resultformid7cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid2 = mysqli_num_rows($resultmid7ccc);
$result8 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 1 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att2 = mysqli_num_rows($result8);
$resultmale8 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb1' AND (datename <= DATE_ADD( '$tb1', INTERVAL 1 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale8 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 1 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale8 = mysqli_fetch_assoc($resultmale8)) {
	$wmale222[] = $rowmale8['student_name'];
}
$wmale2 = $wmale222;
$wkmale22 = mysqli_num_rows($resultmale8);
while ($rowfemale8 = mysqli_fetch_assoc($resultfemale8)) {
	$wfemale222[] = $rowfemale8['student_name'];
}
$wfemale2 = $wfemale222;
$wkfemale22 = mysqli_num_rows($resultfemale8);
}
else{
$tb = (round(abs(strtotime($termbegin) + 604800)));
$tb1 = date("Y-m-d", $tb);
$resultformid7aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row7 = mysqli_fetch_assoc($resultformid7aa)) {
$resultformid7bb[] = $row7['dt'];	
}
$resultformid7cc = current($resultformid7bb);
$resultmid7ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 3 DAY )) AND datename < '$resultformid7cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid2 = mysqli_num_rows($resultmid7ccc);
$result8 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 3 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att2 = mysqli_num_rows($result8);
$resultmale8 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb1' AND (datename <= DATE_ADD( '$tb1', INTERVAL 3 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale8 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 3 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale8 = mysqli_fetch_assoc($resultmale8)) {
	$wmale222[] = $rowmale8['student_name'];
}
$wmale2 = $wmale222;
$wkmale22 = mysqli_num_rows($resultmale8);
while ($rowfemale8 = mysqli_fetch_assoc($resultfemale8)) {
	$wfemale222[] = $rowfemale8['student_name'];
}
$wfemale2 = $wfemale222;
$wkfemale22 = mysqli_num_rows($resultfemale8);
}









if($l == "Monday"){
$tb2 = (round(abs(strtotime($tb1) + 604800)));
$tb3 = date("Y-m-d", $tb2);
$resultformid9aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row9 = mysqli_fetch_assoc($resultformid9aa)) {
$resultformid9bb[] = $row9['dt'];	
}
$resultformid9cc = current($resultformid9bb);
$resultmid9ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb3') AND (datename <= DATE_ADD( '$tb3', INTERVAL 4 DAY )) AND datename < '$resultformid9cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid3 = mysqli_num_rows($resultmid9ccc);
$result10 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb3') AND (datename <= DATE_ADD( '$tb3', INTERVAL 4 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att3 = mysqli_num_rows($result10);
$resultmornmon3 = mysqli_query($db, "SELECT student_name FROM attend where (datename = '$tb3') AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornmon363 = mysqli_fetch_assoc($resultmornmon3)) {
	$wmorn1113[] = $rowmornmon363['student_name'];
}
$monmorn3 = count($wmorn1113);
$resultaftmon3 = mysqli_query($db, "SELECT student_name FROM attend where (datename = '$tb3') AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftmon363 = mysqli_fetch_assoc($resultaftmon3)) {
	$waft1113[] = $rowaftmon3['student_name'];
}
$monaft3 = count($waft1113);
$resultmorntue3 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb3', INTERVAL 1 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmorntue3 = mysqli_fetch_assoc($resultmorntue3)) {
	$wmorntue1113[] = $rowmorntue3['student_name'];
}
$tuemorn3 = count($wmorntue1113);
$resultafttue3 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb3', INTERVAL 1 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowafttue3 = mysqli_fetch_assoc($resultafttue3)) {
	$wafttue1113[] = $rowafttue3['student_name'];
}
$tueaft3 = count($wafttue1113);
$monaft3 = count($waft1113);
$resultmornwed3 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb3', INTERVAL 2 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornwed3 = mysqli_fetch_assoc($resultmornwed3)) {
	$wmornwed1113[] = $rowmornwed3['student_name'];
}
$wedmorn3 = count($wmornwed1113);
$resultaftwed3 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb3', INTERVAL 2 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftwed3 = mysqli_fetch_assoc($resultaftwed3)) {
	$waftwed1113[] = $rowaftwed3['student_name'];
}
$wedaft3 = count($waftwed1113);
$resultmornthur3 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb3', INTERVAL 3 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornthur3 = mysqli_fetch_assoc($resultmornthur3)) {
	$wmornthur1113[] = $rowmornthur3['student_name'];
}
$thurmorn3 = count($wmornthur1113);
$resultaftthur3 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb3', INTERVAL 3 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftthur3 = mysqli_fetch_assoc($resultaftthur3)) {
	$waftthur1113[] = $rowaftthur3['student_name'];
}
$thuraft3 = count($waftthur1113);
$resultmornfri3 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb3', INTERVAL 4 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornfri3 = mysqli_fetch_assoc($resultmornfri3)) {
	$wmornfri1113[] = $rowmornfri3['student_name'];
}
$frimorn3 = count($wmornfri1113);
$resultaftfri3 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb3', INTERVAL 4 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftfri3 = mysqli_fetch_assoc($resultaftfri3)) {
	$waftfri1113[] = $rowaftfri3['student_name'];
}
$friaft3 = count($waftfri1113);
$resultmale10 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb3' AND (datename <= DATE_ADD( '$tb3', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale10 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb3') AND (datename <= DATE_ADD( '$tb3', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale10 = mysqli_fetch_assoc($resultmale10)) {
	$wmale333[] = $rowmale10['student_name'];
}
$wmale3 = $wmale333;
$wkmale33 = mysqli_num_rows($resultmale10);
while ($rowfemale10 = mysqli_fetch_assoc($resultfemale10)) {
	$wfemale333[] = $rowfemale10['student_name'];
}
$wfemale3 = $wfemale333;
$wkfemale33 = mysqli_num_rows($resultfemale10);
}
elseif($l == "Tuesday"){
$tb2 = (round(abs(strtotime($tb1) + 604800)));
$tb3 = date("Y-m-d", $tb2);
$resultformid9aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row9 = mysqli_fetch_assoc($resultformid9aa)) {
$resultformid9bb[] = $row9['dt'];	
}
$resultformid9cc = current($resultformid9bb);
$resultmid9ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb3') AND (datename <= DATE_ADD( '$tb3', INTERVAL 3 DAY )) AND datename < '$resultformid9cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid3 = mysqli_num_rows($resultmid9ccc);
$result10 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb3') AND (datename <= DATE_ADD( '$tb3', INTERVAL 3 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att3 = mysqli_num_rows($result10);
$resultmale10 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb3' AND (datename <= DATE_ADD( '$tb3', INTERVAL 3 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale10 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb3') AND (datename <= DATE_ADD( '$tb3', INTERVAL 3 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale10 = mysqli_fetch_assoc($resultmale10)) {
	$wmale333[] = $rowmale10['student_name'];
}
$wmale3 = $wmale333;
$wkmale33 = mysqli_num_rows($resultmale10);
while ($rowfemale10 = mysqli_fetch_assoc($resultfemale10)) {
	$wfemale333[] = $rowfemale10['student_name'];
}
$wfemale3 = $wfemale333;
$wkfemale33 = mysqli_num_rows($resultfemale10);
}
elseif($l == "Wednesday"){
$tb2 = (round(abs(strtotime($tb1) + 604800)));
$tb3 = date("Y-m-d", $tb2);
$resultformid9aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row9 = mysqli_fetch_assoc($resultformid9aa)) {
$resultformid9bb[] = $row9['dt'];	
}
$resultformid9cc = current($resultformid9bb);
$resultmid9ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb3') AND (datename <= DATE_ADD( '$tb3', INTERVAL 2 DAY )) AND datename < '$resultformid9cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid3 = mysqli_num_rows($resultmid9ccc);
$result10 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb3') AND (datename <= DATE_ADD( '$tb3', INTERVAL 2 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att3 = mysqli_num_rows($result10);
$resultmale10 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb3' AND (datename <= DATE_ADD( '$tb3', INTERVAL 2 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale10 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb3') AND (datename <= DATE_ADD( '$tb3', INTERVAL 2 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale10 = mysqli_fetch_assoc($resultmale10)) {
	$wmale333[] = $rowmale10['student_name'];
}
$wmale3 = $wmale333;
$wkmale33 = mysqli_num_rows($resultmale10);
while ($rowfemale10 = mysqli_fetch_assoc($resultfemale10)) {
	$wfemale333[] = $rowfemale10['student_name'];
}
$wfemale3 = $wfemale333;
$wkfemale33 = mysqli_num_rows($resultfemale10);
}
elseif($l == "Thursday"){
$tb2 = (round(abs(strtotime($tb1) + 604800)));
$tb3 = date("Y-m-d", $tb2);
$resultformid9aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row9 = mysqli_fetch_assoc($resultformid9aa)) {
$resultformid9bb[] = $row9['dt'];	
}
$resultformid9cc = current($resultformid9bb);
$resultmid9ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb3') AND (datename <= DATE_ADD( '$tb3', INTERVAL 1 DAY )) AND datename < '$resultformid9cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid3 = mysqli_num_rows($resultmid9ccc);
$result10 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb3') AND (datename <= DATE_ADD( '$tb3', INTERVAL 1 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att3 = mysqli_num_rows($result10);
$resultmale10 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb3' AND (datename <= DATE_ADD( '$tb3', INTERVAL 1 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale10 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb3') AND (datename <= DATE_ADD( '$tb3', INTERVAL 1 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale10 = mysqli_fetch_assoc($resultmale10)) {
	$wmale333[] = $rowmale10['student_name'];
}
$wmale3 = $wmale333;
$wkmale33 = mysqli_num_rows($resultmale10);
while ($rowfemale10 = mysqli_fetch_assoc($resultfemale10)) {
	$wfemale333[] = $rowfemale10['student_name'];
}
$wfemale3 = $wfemale333;
$wkfemale33 = mysqli_num_rows($resultfemale10);
}
else{
$tb2 = (round(abs(strtotime($tb1) + 604800)));
$tb3 = date("Y-m-d", $tb2);
$resultformid9aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row9 = mysqli_fetch_assoc($resultformid9aa)) {
$resultformid9bb[] = $row9['dt'];	
}
$resultformid9cc = current($resultformid9bb);
$resultmid9ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb3') AND (datename <= DATE_ADD( '$tb3', INTERVAL 0 DAY )) AND datename < '$resultformid9cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid3 = mysqli_num_rows($resultmid9ccc);
$result10 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb3') AND (datename <= DATE_ADD( '$tb3', INTERVAL 0 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att3 = mysqli_num_rows($result10);
$resultmale10 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb3' AND (datename <= DATE_ADD( '$tb3', INTERVAL 0 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale10 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb3') AND (datename <= DATE_ADD( '$tb3', INTERVAL 0 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale10 = mysqli_fetch_assoc($resultmale10)) {
	$wmale333[] = $rowmale10['student_name'];
}
$wmale3 = $wmale333;
$wkmale33 = mysqli_num_rows($resultmale10);
while ($rowfemale10 = mysqli_fetch_assoc($resultfemale10)) {
	$wfemale333[] = $rowfemale10['student_name'];
}
$wfemale3 = $wfemale333;
$wkfemale33 = mysqli_num_rows($resultfemale10);
}





if($l == "Monday"){
$tb4 = (round(abs(strtotime($tb3) + 604800)));
$tb5 = date("Y-m-d", $tb4);
$resultformid10aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row10 = mysqli_fetch_assoc($resultformid10aa)) {
$resultformid10bb[] = $row10['dt'];	
}
$resultformid10cc = current($resultformid10bb);
$resultmid10ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb5') AND (datename <= DATE_ADD( '$tb5', INTERVAL 4 DAY )) AND datename < '$resultformid10cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid4 = mysqli_num_rows($resultmid10ccc);
$result12 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb5') AND (datename <= DATE_ADD( '$tb5', INTERVAL 4 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att4 = mysqli_num_rows($result12);
$resultmornmon4 = mysqli_query($db, "SELECT student_name FROM attend where (datename = '$tb5') AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornmon4 = mysqli_fetch_assoc($resultmornmon4)) {
	$wmorn1114[] = $rowmornmon4['student_name'];
}
$monmorn4 = count($wmorn1114);
$resultaftmon4 = mysqli_query($db, "SELECT student_name FROM attend where (datename = '$tb5') AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftmon4 = mysqli_fetch_assoc($resultaftmon4)) {
	$waft1114[] = $rowaftmon4['student_name'];
}
$monaft4 = count($waft1114);
$resultmorntue4 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb5', INTERVAL 1 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmorntue4 = mysqli_fetch_assoc($resultmorntue4)) {
	$wmorntue1114[] = $rowmorntue4['student_name'];
}
$tuemorn4 = count($wmorntue1114);
$resultafttue4 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb5', INTERVAL 1 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowafttue4 = mysqli_fetch_assoc($resultafttue4)) {
	$wafttue1114[] = $rowafttue4['student_name'];
}
$tueaft4 = count($wafttue1114);
$resultmornwed4 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb5', INTERVAL 2 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornwed4 = mysqli_fetch_assoc($resultmornwed4)) {
	$wmornwed1114[] = $rowmornwed4['student_name'];
}
$wedmorn4 = count($wmornwed1114);
$resultaftwed4 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb5', INTERVAL 2 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftwed4 = mysqli_fetch_assoc($resultaftwed4)) {
	$waftwed1114[] = $rowaftwed4['student_name'];
}
$wedaft4 = count($waftwed1114);
$resultmornthur4 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb5', INTERVAL 3 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornthur4 = mysqli_fetch_assoc($resultmornthur4)) {
	$wmornthur1114[] = $rowmornthur4['student_name'];
}
$thurmorn4 = count($wmornthur1114);
$resultaftthur4 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb5', INTERVAL 3 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftthur4 = mysqli_fetch_assoc($resultaftthur4)) {
	$waftthur1114[] = $rowaftthur4['student_name'];
}
$thuraft4 = count($waftthur1114);
$resultmornfri4 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb5', INTERVAL 4 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornfri4 = mysqli_fetch_assoc($resultmornfri4)) {
	$wmornfri1114[] = $rowmornfri4['student_name'];
}
$frimorn4 = count($wmornfri1114);
$resultaftfri4 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb5', INTERVAL 4 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftfri4 = mysqli_fetch_assoc($resultaftfri4)) {
	$waftfri1114[] = $rowaftfri4['student_name'];
}
$friaft4 = count($waftfri1114);
$resultmale12 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb5' AND (datename <= DATE_ADD( '$tb5', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale12 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb5') AND (datename <= DATE_ADD( '$tb5', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale12 = mysqli_fetch_assoc($resultmale12)) {
	$wmale444[] = $rowmale12['student_name'];
}
$wmale4 = $wmale444;
$wkmale44 = mysqli_num_rows($resultmale12);
while ($rowfemale12 = mysqli_fetch_assoc($resultfemale12)) {
	$wfemale444[] = $rowfemale12['student_name'];
}
$wfemale4 = $wfemale444;
$wkfemale44 = mysqli_num_rows($resultfemale12);
}
elseif($l == "Thursday"){
$tb4 = (round(abs(strtotime($tb3) + 604800)));
$tb5 = date("Y-m-d", $tb4);
$resultformid10aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row10 = mysqli_fetch_assoc($resultformid10aa)) {
$resultformid10bb[] = $row10['dt'];	
}
$resultformid10cc = current($resultformid10bb);
$resultmid10ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb5') AND (datename <= DATE_ADD( '$tb5', INTERVAL 1 DAY )) AND datename < '$resultformid10cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid4 = mysqli_num_rows($resultmid10ccc);
$result12 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb5') AND (datename <= DATE_ADD( '$tb5', INTERVAL 1 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att4 = mysqli_num_rows($result12);
$resultmale12 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb5' AND (datename <= DATE_ADD( '$tb5', INTERVAL 1 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale12 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb5') AND (datename <= DATE_ADD( '$tb5', INTERVAL 1 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale12 = mysqli_fetch_assoc($resultmale12)) {
	$wmale444[] = $rowmale12['student_name'];
}
$wmale4 = $wmale444;
$wkmale44 = mysqli_num_rows($resultmale12);
while ($rowfemale12 = mysqli_fetch_assoc($resultfemale12)) {
	$wfemale444[] = $rowfemale12['student_name'];
}
$wfemale4 = $wfemale444;
$wkfemale44 = mysqli_num_rows($resultfemale12);
}
else{
$tb4 = (round(abs(strtotime($tb3) + 604800)));
$tb5 = date("Y-m-d", $tb4);
$resultformid10aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row10 = mysqli_fetch_assoc($resultformid10aa)) {
$resultformid10bb[] = $row10['dt'];	
}
$resultformid10cc = current($resultformid10bb);
$resultmid10ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb5') AND (datename <= DATE_ADD( '$tb5', INTERVAL 0 DAY )) AND datename < '$resultformid10cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid4 = mysqli_num_rows($resultmid10ccc);
$result12 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb5') AND (datename <= DATE_ADD( '$tb5', INTERVAL 0 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att4 = mysqli_num_rows($result12);
$resultmale12 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb5' AND (datename <= DATE_ADD( '$tb5', INTERVAL 0 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale12 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb5') AND (datename <= DATE_ADD( '$tb5', INTERVAL 0 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale12 = mysqli_fetch_assoc($resultmale12)) {
	$wmale444[] = $rowmale12['student_name'];
}
$wmale4 = $wmale444;
$wkmale44 = mysqli_num_rows($resultmale12);
while ($rowfemale12 = mysqli_fetch_assoc($resultfemale12)) {
	$wfemale444[] = $rowfemale12['student_name'];
}
$wfemale4 = $wfemale444;
$wkfemale44 = mysqli_num_rows($resultfemale12);
}



if($l == "Monday"){
$tb6 = (round(abs(strtotime($tb5) + 604800)));
$tb7 = date("Y-m-d", $tb6);
$resultformid11aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row11 = mysqli_fetch_assoc($resultformid11aa)) {
$resultformid11bb[] = $row11['dt'];	
}
$resultformid11cc = current($resultformid11bb);
$resultmid11ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb7') AND (datename <= DATE_ADD( '$tb7', INTERVAL 4 DAY )) AND datename < '$resultformid11cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid5 = mysqli_num_rows($resultmid11ccc);
$result14 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb7') AND (datename <= DATE_ADD( '$tb7', INTERVAL 4 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att5 = mysqli_num_rows($result14);
$resultmornmon5 = mysqli_query($db, "SELECT student_name FROM attend where (datename = '$tb7') AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornmon5 = mysqli_fetch_assoc($resultmornmon5)) {
	$wmorn1115[] = $rowmornmon5['student_name'];
}
$monmorn5 = count($wmorn1115);
$resultaftmon5 = mysqli_query($db, "SELECT student_name FROM attend where (datename = '$tb7') AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftmon5 = mysqli_fetch_assoc($resultaftmon5)) {
	$waft1115[] = $rowaftmon5['student_name'];
}
$monaft5 = count($waft1115);
$resultmorntue5 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb7', INTERVAL 1 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmorntue5 = mysqli_fetch_assoc($resultmorntue5)) {
	$wmorntue1115[] = $rowmorntue5['student_name'];
}
$tuemorn5 = count($wmorntue1115);
$resultafttue5 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb7', INTERVAL 1 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowafttue5 = mysqli_fetch_assoc($resultafttue5)) {
	$wafttue1115[] = $rowafttue5['student_name'];
}
$tueaft5 = count($wafttue1115);
$resultmornwed5 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb7', INTERVAL 2 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornwed5 = mysqli_fetch_assoc($resultmornwed5)) {
	$wmornwed1115[] = $rowmornwed5['student_name'];
}
$wedmorn5 = count($wmornwed1115);
$resultaftwed5 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb7', INTERVAL 2 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftwed5 = mysqli_fetch_assoc($resultaftwed5)) {
	$waftwed1115[] = $rowaftwed5['student_name'];
}
$wedaft5 = count($waftwed1115);
$resultmornthur5 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb7', INTERVAL 3 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornthur5 = mysqli_fetch_assoc($resultmornthur5)) {
	$wmornthur1115[] = $rowmornthur5['student_name'];
}
$thurmorn5 = count($wmornthur1115);
$resultaftthur5 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb7', INTERVAL 3 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftthur5 = mysqli_fetch_assoc($resultaftthur5)) {
	$waftthur1115[] = $rowaftthur5['student_name'];
}
$thuraft5 = count($waftthur1115);
$resultmornfri5 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb7', INTERVAL 4 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornfri5 = mysqli_fetch_assoc($resultmornfri5)) {
	$wmornfri1115[] = $rowmornfri5['student_name'];
}
$frimorn5 = count($wmornfri1115);
$resultaftfri5 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb7', INTERVAL 4 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftfri5 = mysqli_fetch_assoc($resultaftfri5)) {
	$waftfri1115[] = $rowaftfri5['student_name'];
}
$friaft5 = count($waftfri1115);
$resultmale14 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb7' AND (datename <= DATE_ADD( '$tb7', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale14 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb7') AND (datename <= DATE_ADD( '$tb7', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale14 = mysqli_fetch_assoc($resultmale14)) {
	$wmale555[] = $rowmale14['student_name'];
}
$wmale5 = $wmale555;
$wkmale55 = mysqli_num_rows($resultmale14);
while ($rowfemale14 = mysqli_fetch_assoc($resultfemale14)) {
	$wfemale555[] = $rowfemale14['student_name'];
}
$wfemale5 = $wfemale555;
$wkfemale55 = mysqli_num_rows($resultfemale14);
}
elseif($l == "Tuesday"){
$tb6 = (round(abs(strtotime($tb5) + 604800)));
$tb7 = date("Y-m-d", $tb6);
$resultformid11aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row11 = mysqli_fetch_assoc($resultformid11aa)) {
$resultformid11bb[] = $row11['dt'];	
}
$resultformid11cc = current($resultformid11bb);
$resultmid11ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb7') AND (datename <= DATE_ADD( '$tb7', INTERVAL 3 DAY )) AND datename < '$resultformid11cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid5 = mysqli_num_rows($resultmid11ccc);
$result14 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb7') AND (datename <= DATE_ADD( '$tb7', INTERVAL 3 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att5 = mysqli_num_rows($result14);
$resultmale14 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb7' AND (datename <= DATE_ADD( '$tb7', INTERVAL 3 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale14 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb7') AND (datename <= DATE_ADD( '$tb7', INTERVAL 3 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale14 = mysqli_fetch_assoc($resultmale14)) {
	$wmale555[] = $rowmale14['student_name'];
}
$wmale5 = $wmale555;
$wkmale55 = mysqli_num_rows($resultmale14);
while ($rowfemale14 = mysqli_fetch_assoc($resultfemale14)) {
	$wfemale555[] = $rowfemale14['student_name'];
}
$wfemale5 = $wfemale555;
$wkfemale55 = mysqli_num_rows($resultfemale14);
}
elseif($l == "Wednesday"){
$tb6 = (round(abs(strtotime($tb5) + 604800)));
$tb7 = date("Y-m-d", $tb6);
$resultformid11aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row11 = mysqli_fetch_assoc($resultformid11aa)) {
$resultformid11bb[] = $row11['dt'];	
}
$resultformid11cc = current($resultformid11bb);
$resultmid11ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb7') AND (datename <= DATE_ADD( '$tb7', INTERVAL 2 DAY )) AND datename < '$resultformid11cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid5 = mysqli_num_rows($resultmid11ccc);
$result14 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb7') AND (datename <= DATE_ADD( '$tb7', INTERVAL 2 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att5 = mysqli_num_rows($result14);
$resultmale14 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb7' AND (datename <= DATE_ADD( '$tb7', INTERVAL 2 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale14 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb7') AND (datename <= DATE_ADD( '$tb7', INTERVAL 2 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale14 = mysqli_fetch_assoc($resultmale14)) {
	$wmale555[] = $rowmale14['student_name'];
}
$wmale5 = $wmale555;
$wkmale55 = mysqli_num_rows($resultmale14);
while ($rowfemale14 = mysqli_fetch_assoc($resultfemale14)) {
	$wfemale555[] = $rowfemale14['student_name'];
}
$wfemale5 = $wfemale555;
$wkfemale55 = mysqli_num_rows($resultfemale14);
}
elseif($l == "Thursday"){
$tb6 = (round(abs(strtotime($tb5) + 604800)));
$tb7 = date("Y-m-d", $tb6);
$resultformid11aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row11 = mysqli_fetch_assoc($resultformid11aa)) {
$resultformid11bb[] = $row11['dt'];	
}
$resultformid11cc = current($resultformid11bb);
$resultmid11ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb7') AND (datename <= DATE_ADD( '$tb7', INTERVAL 1 DAY )) AND datename < '$resultformid11cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid5 = mysqli_num_rows($resultmid11ccc);
$result14 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb7') AND (datename <= DATE_ADD( '$tb7', INTERVAL 1 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att5 = mysqli_num_rows($result14);
$resultmale14 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb7' AND (datename <= DATE_ADD( '$tb7', INTERVAL 1 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale14 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb7') AND (datename <= DATE_ADD( '$tb7', INTERVAL 1 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale14 = mysqli_fetch_assoc($resultmale14)) {
	$wmale555[] = $rowmale14['student_name'];
}
$wmale5 = $wmale555;
$wkmale55 = mysqli_num_rows($resultmale14);
while ($rowfemale14 = mysqli_fetch_assoc($resultfemale14)) {
	$wfemale555[] = $rowfemale14['student_name'];
}
$wfemale5 = $wfemale555;
$wkfemale55 = mysqli_num_rows($resultfemale14);
}
elseif($l == "Friday"){
$tb6 = (round(abs(strtotime($tb5) + 604800)));
$tb7 = date("Y-m-d", $tb6);
$resultformid11aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row11 = mysqli_fetch_assoc($resultformid11aa)) {
$resultformid11bb[] = $row11['dt'];	
}
$resultformid11cc = current($resultformid11bb);
$resultmid11ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb7') AND (datename <= DATE_ADD( '$tb7', INTERVAL 0 DAY )) AND datename < '$resultformid11cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid5 = mysqli_num_rows($resultmid11ccc);
$result14 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb7') AND (datename <= DATE_ADD( '$tb7', INTERVAL 0 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att5 = mysqli_num_rows($result14);
$resultmale14 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb7' AND (datename <= DATE_ADD( '$tb7', INTERVAL 0 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale14 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb7') AND (datename <= DATE_ADD( '$tb7', INTERVAL 0 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale14 = mysqli_fetch_assoc($resultmale14)) {
	$wmale555[] = $rowmale14['student_name'];
}
$wmale5 = $wmale555;
$wkmale55 = mysqli_num_rows($resultmale14);
while ($rowfemale14 = mysqli_fetch_assoc($resultfemale14)) {
	$wfemale555[] = $rowfemale14['student_name'];
}
$wfemale5 = $wfemale555;
$wkfemale55 = mysqli_num_rows($resultfemale14);
}






if($l == "Monday"){
$tb8 = (round(abs(strtotime($tb7) + 604800)));
$tb9 = date("Y-m-d", $tb8);
$resultformid12aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row12 = mysqli_fetch_assoc($resultformid12aa)) {
$resultformid12bb[] = $row12['dt'];	
}
$resultformid12cc = current($resultformid12bb);
$resultmid12ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb9') AND (datename <= DATE_ADD( '$tb9', INTERVAL 4 DAY )) AND datename < '$resultformid12cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid6 = mysqli_num_rows($resultmid12ccc);
$result16 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb9') AND (datename <= DATE_ADD( '$tb9', INTERVAL 4 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att6 = mysqli_num_rows($result16);

$resultmornmon6 = mysqli_query($db, "SELECT student_name FROM attend where (datename = '$tb9') AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornmon6 = mysqli_fetch_assoc($resultmornmon6)) {
	$wmorn1116[] = $rowmornmon6['student_name'];
}
$monmorn6 = count($wmorn1116);
$resultaftmon6 = mysqli_query($db, "SELECT student_name FROM attend where (datename = '$tb9') AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftmon6 = mysqli_fetch_assoc($resultaftmon6)) {
	$waft1116[] = $rowaftmon6['student_name'];
}
$monaft6 = count($waft1116);
$resultmorntue6 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb9', INTERVAL 1 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmorntue6 = mysqli_fetch_assoc($resultmorntue6)) {
	$wmorntue1116[] = $rowmorntue6['student_name'];
}
$tuemorn6 = count($wmorntue1116);
$resultafttue6 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb9', INTERVAL 1 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowafttue6 = mysqli_fetch_assoc($resultafttue6)) {
	$wafttue1116[] = $rowafttue6['student_name'];
}
$tueaft6 = count($wafttue1116);
$resultmornwed6 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb9', INTERVAL 2 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornwed6 = mysqli_fetch_assoc($resultmornwed6)) {
	$wmornwed1116[] = $rowmornwed6['student_name'];
}
$wedmorn6 = count($wmornwed1116);
$resultaftwed6 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb9', INTERVAL 2 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftwed6 = mysqli_fetch_assoc($resultaftwed6)) {
	$waftwed1116[] = $rowaftwed6['student_name'];
}
$wedaft6 = count($waftwed1116);
$resultmornthur6 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb9', INTERVAL 3 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornthur6 = mysqli_fetch_assoc($resultmornthur6)) {
	$wmornthur1116[] = $rowmornthur6['student_name'];
}
$thurmorn6 = count($wmornthur1116);
$resultaftthur6 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb9', INTERVAL 3 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftthur6 = mysqli_fetch_assoc($resultaftthur6)) {
	$waftthur1116[] = $rowaftthur6['student_name'];
}
$thuraft6 = count($waftthur1116);
$resultmornfri6 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb9', INTERVAL 4 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornfri6 = mysqli_fetch_assoc($resultmornfri6)) {
	$wmornfri1116[] = $rowmornfri6['student_name'];
}
$frimorn6 = count($wmornfri1116);
$resultaftfri6 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb9', INTERVAL 4 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftfri6 = mysqli_fetch_assoc($resultaftfri6)) {
	$waftfri1116[] = $rowaftfri6['student_name'];
}
$friaft6 = count($waftfri1116);
$resultmale16 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb9' AND (datename <= DATE_ADD( '$tb9', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale16 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb9') AND (datename <= DATE_ADD( '$tb9', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale16 = mysqli_fetch_assoc($resultmale16)) {
	$wmale666[] = $rowmale16['student_name'];
}
$wmale6 = $wmale666;
$wkmale66 = mysqli_num_rows($resultmale16);
while ($rowfemale16 = mysqli_fetch_assoc($resultfemale16)) {
	$wfemale666[] = $rowfemale16['student_name'];
}
$wfemale6 = $wfemale666;
$wkfemale66 = mysqli_num_rows($resultfemale16);
}
elseif($l == "Tuesday"){
$tb8 = (round(abs(strtotime($tb7) + 604800)));
$tb9 = date("Y-m-d", $tb8);
$resultformid12aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row12 = mysqli_fetch_assoc($resultformid12aa)) {
$resultformid12bb[] = $row12['dt'];	
}
$resultformid12cc = current($resultformid12bb);
$resultmid12ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb9') AND (datename <= DATE_ADD( '$tb9', INTERVAL 3 DAY )) AND datename < '$resultformid12cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid6 = mysqli_num_rows($resultmid12ccc);
$result16 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb9') AND (datename <= DATE_ADD( '$tb9', INTERVAL 3 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att6 = mysqli_num_rows($result16);
$resultmale16 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb9' AND (datename <= DATE_ADD( '$tb9', INTERVAL 3 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale16 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb9') AND (datename <= DATE_ADD( '$tb9', INTERVAL 3 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale16 = mysqli_fetch_assoc($resultmale16)) {
	$wmale666[] = $rowmale16['student_name'];
}
$wmale6 = $wmale666;
$wkmale66 = mysqli_num_rows($resultmale16);
while ($rowfemale16 = mysqli_fetch_assoc($resultfemale16)) {
	$wfemale666[] = $rowfemale16['student_name'];
}
$wfemale6 = $wfemale666;
$wkfemale66 = mysqli_num_rows($resultfemale16);
}
elseif($l == "Wednesday"){
$tb8 = (round(abs(strtotime($tb7) + 604800)));
$tb9 = date("Y-m-d", $tb8);
$resultformid12aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row12 = mysqli_fetch_assoc($resultformid12aa)) {
$resultformid12bb[] = $row12['dt'];	
}
$resultformid12cc = current($resultformid12bb);
$resultmid12ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb9') AND (datename <= DATE_ADD( '$tb9', INTERVAL 2 DAY )) AND datename < '$resultformid12cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid6 = mysqli_num_rows($resultmid12ccc);
$result16 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb9') AND (datename <= DATE_ADD( '$tb9', INTERVAL 2 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att6 = mysqli_num_rows($result16);
$resultmale16 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb9' AND (datename <= DATE_ADD( '$tb9', INTERVAL 2 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale16 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb9') AND (datename <= DATE_ADD( '$tb9', INTERVAL 2 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale16 = mysqli_fetch_assoc($resultmale16)) {
	$wmale666[] = $rowmale16['student_name'];
}
$wmale6 = $wmale666;
$wkmale66 = mysqli_num_rows($resultmale16);
while ($rowfemale16 = mysqli_fetch_assoc($resultfemale16)) {
	$wfemale666[] = $rowfemale16['student_name'];
}
$wfemale6 = $wfemale666;
$wkfemale66 = mysqli_num_rows($resultfemale16);
}
elseif($l == "Thursday"){
$tb8 = (round(abs(strtotime($tb7) + 604800)));
$tb9 = date("Y-m-d", $tb8);
$resultformid12aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row12 = mysqli_fetch_assoc($resultformid12aa)) {
$resultformid12bb[] = $row12['dt'];	
}
$resultformid12cc = current($resultformid12bb);
$resultmid12ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb9') AND (datename <= DATE_ADD( '$tb9', INTERVAL 1 DAY )) AND datename < '$resultformid12cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid6 = mysqli_num_rows($resultmid12ccc);
$result16 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb9') AND (datename <= DATE_ADD( '$tb9', INTERVAL 1 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att6 = mysqli_num_rows($result16);
$resultmale16 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb9' AND (datename <= DATE_ADD( '$tb9', INTERVAL 1 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale16 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb9') AND (datename <= DATE_ADD( '$tb9', INTERVAL 1 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale16 = mysqli_fetch_assoc($resultmale16)) {
	$wmale666[] = $rowmale16['student_name'];
}
$wmale6 = $wmale666;
$wkmale66 = mysqli_num_rows($resultmale16);
while ($rowfemale16 = mysqli_fetch_assoc($resultfemale16)) {
	$wfemale666[] = $rowfemale16['student_name'];
}
$wfemale6 = $wfemale666;
$wkfemale66 = mysqli_num_rows($resultfemale16);
}
else{
$tb8 = (round(abs(strtotime($tb7) + 604800)));
$tb9 = date("Y-m-d", $tb8);
$resultformid12aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row12 = mysqli_fetch_assoc($resultformid12aa)) {
$resultformid12bb[] = $row12['dt'];	
}
$resultformid12cc = current($resultformid12bb);
$resultmid12ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb9') AND (datename <= DATE_ADD( '$tb9', INTERVAL 0 DAY )) AND datename < '$resultformid12cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid6 = mysqli_num_rows($resultmid12ccc);
$result16 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb9') AND (datename <= DATE_ADD( '$tb9', INTERVAL 0 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att6 = mysqli_num_rows($result16);
$resultmale16 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb9' AND (datename <= DATE_ADD( '$tb9', INTERVAL 0 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale16 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb9') AND (datename <= DATE_ADD( '$tb9', INTERVAL 0 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale16 = mysqli_fetch_assoc($resultmale16)) {
	$wmale666[] = $rowmale16['student_name'];
}
$wmale6 = $wmale666;
$wkmale66 = mysqli_num_rows($resultmale16);
while ($rowfemale16 = mysqli_fetch_assoc($resultfemale16)) {
	$wfemale666[] = $rowfemale16['student_name'];
}
$wfemale6 = $wfemale666;
$wkfemale66 = mysqli_num_rows($resultfemale16);
}





if($l == "Monday"){
$tb10 = (round(abs(strtotime($tb9) + 604800)));
$tb11 = date("Y-m-d", $tb10);
$resultformid13aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row13 = mysqli_fetch_assoc($resultformid13aa)) {
$resultformid13bb[] = $row13['dt'];	
}
$resultformid13cc = current($resultformid13bb);
$resultmid13ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb11') AND (datename <= DATE_ADD( '$tb11', INTERVAL 4 DAY )) AND datename < '$resultformid13cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid7 = mysqli_num_rows($resultmid13ccc);
$result18 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb11') AND (datename <= DATE_ADD( '$tb11', INTERVAL 4 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att7 = mysqli_num_rows($result18);
$resultmornmon7 = mysqli_query($db, "SELECT student_name FROM attend where (datename = '$tb11') AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornmon7 = mysqli_fetch_assoc($resultmornmon7)) {
	$wmorn1117[] = $rowmornmon7['student_name'];
}
$monmorn7 = count($wmorn1117);
$resultaftmon7 = mysqli_query($db, "SELECT student_name FROM attend where (datename = '$tb11') AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftmon7 = mysqli_fetch_assoc($resultaftmon7)) {
	$waft1117[] = $rowaftmon7['student_name'];
}
$monaft7 = count($waft1117);
$resultmorntue7 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb11', INTERVAL 1 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmorntue7 = mysqli_fetch_assoc($resultmorntue7)) {
	$wmorntue1117[] = $rowmorntue7['student_name'];
}
$tuemorn7 = count($wmorntue1117);
$resultafttue7 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb11', INTERVAL 1 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowafttue7 = mysqli_fetch_assoc($resultafttue7)) {
	$wafttue1117[] = $rowafttue7['student_name'];
}
$tueaft7 = count($wafttue1117);
$resultmornwed7 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb11', INTERVAL 2 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornwed7 = mysqli_fetch_assoc($resultmornwed7)) {
	$wmornwed1117[] = $rowmornwed7['student_name'];
}
$wedmorn7 = count($wmornwed1117);
$resultaftwed7 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb11', INTERVAL 2 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftwed7 = mysqli_fetch_assoc($resultaftwed7)) {
	$waftwed1117[] = $rowaftwed7['student_name'];
}
$wedaft7 = count($waftwed1117);
$resultmornthur7 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb11', INTERVAL 3 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornthur7 = mysqli_fetch_assoc($resultmornthur7)) {
	$wmornthur1117[] = $rowmornthur7['student_name'];
}
$thurmorn7 = count($wmornthur1117);
$resultaftthur7 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb11', INTERVAL 3 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftthur7 = mysqli_fetch_assoc($resultaftthur7)) {
	$waftthur1117[] = $rowaftthur7['student_name'];
}
$thuraft7 = count($waftthur1117);
$resultmornfri7 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb11', INTERVAL 4 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornfri7 = mysqli_fetch_assoc($resultmornfri7)) {
	$wmornfri1117[] = $rowmornfri7['student_name'];
}
$frimorn7 = count($wmornfri1117);
$resultaftfri7 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb11', INTERVAL 4 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftfri7 = mysqli_fetch_assoc($resultaftfri7)) {
	$waftfri1117[] = $rowaftfri7['student_name'];
}
$friaft7 = count($waftfri1117);

$resultmale18 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb11' AND (datename <= DATE_ADD( '$tb11', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale18 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb11') AND (datename <= DATE_ADD( '$tb11', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale18 = mysqli_fetch_assoc($resultmale18)) {
	$wmale777[] = $rowmale18['student_name'];
}
$wmale7 = $wmale777;
$wkmale77 = mysqli_num_rows($resultmale18);
while ($rowfemale18 = mysqli_fetch_assoc($resultfemale18)) {
	$wfemale777[] = $rowfemale18['student_name'];
}
$wfemale7 = $wfemale777;
$wkfemale77 = mysqli_num_rows($resultfemale18);
}
elseif($l == "Tuesday"){
$tb10 = (round(abs(strtotime($tb9) + 604800)));
$tb11 = date("Y-m-d", $tb10);
$resultformid13aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row13 = mysqli_fetch_assoc($resultformid13aa)) {
$resultformid13bb[] = $row13['dt'];	
}
$resultformid13cc = current($resultformid13bb);
$resultmid13ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb11') AND (datename <= DATE_ADD( '$tb11', INTERVAL 3 DAY )) AND datename < '$resultformid13cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid7 = mysqli_num_rows($resultmid13ccc);
$result18 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb11') AND (datename <= DATE_ADD( '$tb11', INTERVAL 3 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att7 = mysqli_num_rows($result18);
$resultmale18 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb11' AND (datename <= DATE_ADD( '$tb11', INTERVAL 3 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale18 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb11') AND (datename <= DATE_ADD( '$tb11', INTERVAL 3 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale18 = mysqli_fetch_assoc($resultmale18)) {
	$wmale777[] = $rowmale18['student_name'];
}
$wmale7 = $wmale777;
$wkmale77 = mysqli_num_rows($resultmale18);
while ($rowfemale18 = mysqli_fetch_assoc($resultfemale18)) {
	$wfemale777[] = $rowfemale18['student_name'];
}
$wfemale7 = $wfemale777;
$wkfemale77 = mysqli_num_rows($resultfemale18);
}
elseif($l == "Wednesday"){
$tb10 = (round(abs(strtotime($tb9) + 604800)));
$tb11 = date("Y-m-d", $tb10);
$resultformid13aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row13 = mysqli_fetch_assoc($resultformid13aa)) {
$resultformid13bb[] = $row13['dt'];	
}
$resultformid13cc = current($resultformid13bb);
$resultmid13ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb11') AND (datename <= DATE_ADD( '$tb11', INTERVAL 2 DAY )) AND datename < '$resultformid13cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid7 = mysqli_num_rows($resultmid13ccc);
$result18 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb11') AND (datename <= DATE_ADD( '$tb11', INTERVAL 2 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att7 = mysqli_num_rows($result18);
$resultmale18 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb11' AND (datename <= DATE_ADD( '$tb11', INTERVAL 2 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale18 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb11') AND (datename <= DATE_ADD( '$tb11', INTERVAL 2 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale18 = mysqli_fetch_assoc($resultmale18)) {
	$wmale777[] = $rowmale18['student_name'];
}
$wmale7 = $wmale777;
$wkmale77 = mysqli_num_rows($resultmale18);
while ($rowfemale18 = mysqli_fetch_assoc($resultfemale18)) {
	$wfemale777[] = $rowfemale18['student_name'];
}
$wfemale7 = $wfemale777;
$wkfemale77 = mysqli_num_rows($resultfemale18);
}
elseif($l == "Thursday"){
$tb10 = (round(abs(strtotime($tb9) + 604800)));
$tb11 = date("Y-m-d", $tb10);
$resultformid13aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row13 = mysqli_fetch_assoc($resultformid13aa)) {
$resultformid13bb[] = $row13['dt'];	
}
$resultformid13cc = current($resultformid13bb);
$resultmid13ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb11') AND (datename <= DATE_ADD( '$tb11', INTERVAL 1 DAY )) AND datename < '$resultformid13cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid7 = mysqli_num_rows($resultmid13ccc);
$result18 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb11') AND (datename <= DATE_ADD( '$tb11', INTERVAL 1 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att7 = mysqli_num_rows($result18);
$resultmale18 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb11' AND (datename <= DATE_ADD( '$tb11', INTERVAL 1 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale18 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb11') AND (datename <= DATE_ADD( '$tb11', INTERVAL 1 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale18 = mysqli_fetch_assoc($resultmale18)) {
	$wmale777[] = $rowmale18['student_name'];
}
$wmale7 = $wmale777;
$wkmale77 = mysqli_num_rows($resultmale18);
while ($rowfemale18 = mysqli_fetch_assoc($resultfemale18)) {
	$wfemale777[] = $rowfemale18['student_name'];
}
$wfemale7 = $wfemale777;
$wkfemale77 = mysqli_num_rows($resultfemale18);
}
else{
$tb10 = (round(abs(strtotime($tb9) + 604800)));
$tb11 = date("Y-m-d", $tb10);
$resultformid13aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row13 = mysqli_fetch_assoc($resultformid13aa)) {
$resultformid13bb[] = $row13['dt'];	
}
$resultformid13cc = current($resultformid13bb);
$resultmid13ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb11') AND (datename <= DATE_ADD( '$tb11', INTERVAL 0 DAY )) AND datename < '$resultformid13cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid7 = mysqli_num_rows($resultmid13ccc);
$result18 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb11') AND (datename <= DATE_ADD( '$tb11', INTERVAL 0 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att7 = mysqli_num_rows($result18);
$resultmale18 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb11' AND (datename <= DATE_ADD( '$tb11', INTERVAL 0 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale18 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb11') AND (datename <= DATE_ADD( '$tb11', INTERVAL 0 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale18 = mysqli_fetch_assoc($resultmale18)) {
	$wmale777[] = $rowmale18['student_name'];
}
$wmale7 = $wmale777;
$wkmale77 = mysqli_num_rows($resultmale18);
while ($rowfemale18 = mysqli_fetch_assoc($resultfemale18)) {
	$wfemale777[] = $rowfemale18['student_name'];
}
$wfemale7 = $wfemale777;
$wkfemale77 = mysqli_num_rows($resultfemale18);
}





if($l == "Monday"){
$tb12 = (round(abs(strtotime($tb11) + 604800)));
$tb13 = date("Y-m-d", $tb12);
$resultformid14aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row14 = mysqli_fetch_assoc($resultformid14aa)) {
$resultformid14bb[] = $row14['dt'];	
}
$resultformid14cc = current($resultformid14bb);
$resultmid14ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb13') AND (datename <= DATE_ADD( '$tb13', INTERVAL 4 DAY )) AND datename < '$resultformid14cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid8 = mysqli_num_rows($resultmid14ccc);
$result20 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb13') AND (datename <= DATE_ADD( '$tb13', INTERVAL 4 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att8 = mysqli_num_rows($result20);

$resultmornmon8 = mysqli_query($db, "SELECT student_name FROM attend where (datename = '$tb13') AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornmon8 = mysqli_fetch_assoc($resultmornmon8)) {
	$wmorn1118[] = $rowmornmon8['student_name'];
}
$monmorn8 = count($wmorn1118);
$resultaftmon8 = mysqli_query($db, "SELECT student_name FROM attend where (datename = '$tb13') AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftmon8 = mysqli_fetch_assoc($resultaftmon8)) {
	$waft1118[] = $rowaftmon8['student_name'];
}
$monaft8 = count($waft1118);
$resultmorntue8 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb13', INTERVAL 1 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmorntue8 = mysqli_fetch_assoc($resultmorntue8)) {
	$wmorntue1118[] = $rowmorntue8['student_name'];
}
$tuemorn8 = count($wmorntue1118);
$resultafttue8 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb13', INTERVAL 1 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowafttue8 = mysqli_fetch_assoc($resultafttue8)) {
	$wafttue1118[] = $rowafttue8['student_name'];
}
$tueaft8 = count($wafttue1118);
$resultmornwed8 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb13', INTERVAL 2 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornwed8 = mysqli_fetch_assoc($resultmornwed8)) {
	$wmornwed1118[] = $rowmornwed8['student_name'];
}
$wedmorn8 = count($wmornwed1118);
$resultaftwed8 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb13', INTERVAL 2 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftwed8 = mysqli_fetch_assoc($resultaftwed8)) {
	$waftwed1118[] = $rowaftwed8['student_name'];
}
$wedaft8 = count($waftwed1118);
$resultmornthur8 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb13', INTERVAL 3 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornthur8 = mysqli_fetch_assoc($resultmornthur8)) {
	$wmornthur1118[] = $rowmornthur8['student_name'];
}
$thurmorn8 = count($wmornthur1118);
$resultaftthur8 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb13', INTERVAL 3 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftthur8 = mysqli_fetch_assoc($resultaftthur8)) {
	$waftthur1118[] = $rowaftthur8['student_name'];
}
$thuraft8 = count($waftthur1118);
$resultmornfri8 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb13', INTERVAL 4 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornfri8 = mysqli_fetch_assoc($resultmornfri8)) {
	$wmornfri1118[] = $rowmornfri8['student_name'];
}
$frimorn8 = count($wmornfri1118);
$resultaftfri8 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb13', INTERVAL 4 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftfri8 = mysqli_fetch_assoc($resultaftfri8)) {
	$waftfri1118[] = $rowaftfri8['student_name'];
}
$friaft8 = count($waftfri1118);
$resultmale20 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb13' AND (datename <= DATE_ADD( '$tb13', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale20 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb13') AND (datename <= DATE_ADD( '$tb13', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale20 = mysqli_fetch_assoc($resultmale20)) {
	$wmale888[] = $rowmale20['student_name'];
}
$wmale8 = $wmale888;
$wkmale88 = mysqli_num_rows($resultmale20);
while ($rowfemale20 = mysqli_fetch_assoc($resultfemale20)) {
	$wfemale888[] = $rowfemale20['student_name'];
}
$wfemale8 = $wfemale888;
$wkfemale88 = mysqli_num_rows($resultfemale20);
}
elseif($l == "Tuesday"){
$tb12 = (round(abs(strtotime($tb11) + 604800)));
$tb13 = date("Y-m-d", $tb12);
$resultformid14aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row14 = mysqli_fetch_assoc($resultformid14aa)) {
$resultformid14bb[] = $row14['dt'];	
}
$resultformid14cc = current($resultformid14bb);
$resultmid14ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb13') AND (datename <= DATE_ADD( '$tb13', INTERVAL 3 DAY )) AND datename < '$resultformid14cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid8 = mysqli_num_rows($resultmid14ccc);
$result20 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb13') AND (datename <= DATE_ADD( '$tb13', INTERVAL 3 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att8 = mysqli_num_rows($result20);
$resultmale20 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb13' AND (datename <= DATE_ADD( '$tb13', INTERVAL 3 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale20 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb13') AND (datename <= DATE_ADD( '$tb13', INTERVAL 3 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale20 = mysqli_fetch_assoc($resultmale20)) {
	$wmale888[] = $rowmale20['student_name'];
}
$wmale8 = $wmale888;
$wkmale88 = mysqli_num_rows($resultmale20);
while ($rowfemale20 = mysqli_fetch_assoc($resultfemale20)) {
	$wfemale888[] = $rowfemale20['student_name'];
}
$wfemale8 = $wfemale888;
$wkfemale88 = mysqli_num_rows($resultfemale20);
}
elseif($l == "Wednesday"){
$tb12 = (round(abs(strtotime($tb11) + 604800)));
$tb13 = date("Y-m-d", $tb12);
$resultformid14aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row14 = mysqli_fetch_assoc($resultformid14aa)) {
$resultformid14bb[] = $row14['dt'];	
}
$resultformid14cc = current($resultformid14bb);
$resultmid14ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb13') AND (datename <= DATE_ADD( '$tb13', INTERVAL 2 DAY )) AND datename < '$resultformid14cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid8 = mysqli_num_rows($resultmid14ccc);
$result20 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb13') AND (datename <= DATE_ADD( '$tb13', INTERVAL 2 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att8 = mysqli_num_rows($result20);
$resultmale20 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb13' AND (datename <= DATE_ADD( '$tb13', INTERVAL 2 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale20 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb13') AND (datename <= DATE_ADD( '$tb13', INTERVAL 2 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale20 = mysqli_fetch_assoc($resultmale20)) {
	$wmale888[] = $rowmale20['student_name'];
}
$wmale8 = $wmale888;
$wkmale88 = mysqli_num_rows($resultmale20);
while ($rowfemale20 = mysqli_fetch_assoc($resultfemale20)) {
	$wfemale888[] = $rowfemale20['student_name'];
}
$wfemale8 = $wfemale888;
$wkfemale88 = mysqli_num_rows($resultfemale20);
}
elseif($l == "Thursday"){
$tb12 = (round(abs(strtotime($tb11) + 604800)));
$tb13 = date("Y-m-d", $tb12);
$resultformid14aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row14 = mysqli_fetch_assoc($resultformid14aa)) {
$resultformid14bb[] = $row14['dt'];	
}
$resultformid14cc = current($resultformid14bb);
$resultmid14ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb13') AND (datename <= DATE_ADD( '$tb13', INTERVAL 1 DAY )) AND datename < '$resultformid14cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid8 = mysqli_num_rows($resultmid14ccc);
$result20 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb13') AND (datename <= DATE_ADD( '$tb13', INTERVAL 1 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att8 = mysqli_num_rows($result20);
$resultmale20 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb13' AND (datename <= DATE_ADD( '$tb13', INTERVAL 1 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale20 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb13') AND (datename <= DATE_ADD( '$tb13', INTERVAL 1 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale20 = mysqli_fetch_assoc($resultmale20)) {
	$wmale888[] = $rowmale20['student_name'];
}
$wmale8 = $wmale888;
$wkmale88 = mysqli_num_rows($resultmale20);
while ($rowfemale20 = mysqli_fetch_assoc($resultfemale20)) {
	$wfemale888[] = $rowfemale20['student_name'];
}
$wfemale8 = $wfemale888;
$wkfemale88 = mysqli_num_rows($resultfemale20);
}
else{
$tb12 = (round(abs(strtotime($tb11) + 604800)));
$tb13 = date("Y-m-d", $tb12);
$resultformid14aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row14 = mysqli_fetch_assoc($resultformid14aa)) {
$resultformid14bb[] = $row14['dt'];	
}
$resultformid14cc = current($resultformid14bb);
$resultmid14ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb13') AND (datename <= DATE_ADD( '$tb13', INTERVAL 0 DAY )) AND datename < '$resultformid14cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid8 = mysqli_num_rows($resultmid14ccc);
$result20 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb13') AND (datename <= DATE_ADD( '$tb13', INTERVAL 0 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att8 = mysqli_num_rows($result20);
$resultmale20 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb13' AND (datename <= DATE_ADD( '$tb13', INTERVAL 0 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale20 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb13') AND (datename <= DATE_ADD( '$tb13', INTERVAL 0 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale20 = mysqli_fetch_assoc($resultmale20)) {
	$wmale888[] = $rowmale20['student_name'];
}
$wmale8 = $wmale888;
$wkmale88 = mysqli_num_rows($resultmale20);
while ($rowfemale20 = mysqli_fetch_assoc($resultfemale20)) {
	$wfemale888[] = $rowfemale20['student_name'];
}
$wfemale8 = $wfemale888;
$wkfemale88 = mysqli_num_rows($resultfemale20);
}







if($l == "Monday"){
$tb14 = (round(abs(strtotime($tb13) + 604800)));
$tb15 = date("Y-m-d", $tb14);
$resultformid15aa = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row15 = mysqli_fetch_assoc($resultformid15aa)) {
$resultformid15bb[] = $row15['dt'];	
}
$resultformid15cc = current($resultformid15bb);
$resultmid15ccc = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb15') AND (datename <= DATE_ADD( '$tb15', INTERVAL 4 DAY )) AND datename < '$resultformid11cc' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$attmid9 = mysqli_num_rows($resultmid15ccc);
$result22 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb15') AND (datename <= DATE_ADD( '$tb15', INTERVAL 4 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att9 = mysqli_num_rows($result22);
$resultmornmon9 = mysqli_query($db, "SELECT student_name FROM attend where (datename = '$tb15') AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornmon9 = mysqli_fetch_assoc($resultmornmon9)) {
	$wmorn1119[] = $rowmornmon9['student_name'];
}
$monmorn9 = count($wmorn1119);
$resultaftmon9 = mysqli_query($db, "SELECT student_name FROM attend where (datename = '$tb15') AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftmon9 = mysqli_fetch_assoc($resultaftmon9)) {
	$waft1119[] = $rowaftmon9['student_name'];
}
$monaft9 = count($waft1119);
$resultmorntue9 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb15', INTERVAL 1 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmorntue9 = mysqli_fetch_assoc($resultmorntue9)) {
	$wmorntue1119[] = $rowmorntue9['student_name'];
}
$tuemorn9 = count($wmorntue1119);
$resultafttue9 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb15', INTERVAL 1 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowafttue9 = mysqli_fetch_assoc($resultafttue9)) {
	$wafttue1119[] = $rowafttue9['student_name'];
}
$tueaft9 = count($wafttue1119);
$resultmornwed9 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb15', INTERVAL 2 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornwed9 = mysqli_fetch_assoc($resultmornwed9)) {
	$wmornwed1119[] = $rowmornwed9['student_name'];
}
$wedmorn9 = count($wmornwed1119);
$resultaftwed9 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb15', INTERVAL 2 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftwed9 = mysqli_fetch_assoc($resultaftwed9)) {
	$waftwed1119[] = $rowaftwed9['student_name'];
}
$wedaft9 = count($waftwed1119);
$resultmornthur9 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb15', INTERVAL 3 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornthur9 = mysqli_fetch_assoc($resultmornthur9)) {
	$wmornthur1119[] = $rowmornthur9['student_name'];
}
$thurmorn9 = count($wmornthur1119);
$resultaftthur9 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb15', INTERVAL 3 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftthur9 = mysqli_fetch_assoc($resultaftthur9)) {
	$waftthur1119[] = $rowaftthur9['student_name'];
}
$thuraft9 = count($waftthur1119);
$resultmornfri9 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb15', INTERVAL 4 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornfri9 = mysqli_fetch_assoc($resultmornfri9)) {
	$wmornfri1119[] = $rowmornfri9['student_name'];
}
$frimorn9 = count($wmornfri1119);
$resultaftfri9 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb15', INTERVAL 4 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftfri9 = mysqli_fetch_assoc($resultaftfri9)) {
	$waftfri1119[] = $rowaftfri9['student_name'];
}
$friaft9 = count($waftfri1119);
$resultmale22 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb15' AND (datename <= DATE_ADD( '$tb15', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale22 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb15') AND (datename <= DATE_ADD( '$tb15', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale22 = mysqli_fetch_assoc($resultmale22)) {
	$wmale999[] = $rowmale22['student_name'];
}
$wmale9 = $wmale999;
$wkmale99 = mysqli_num_rows($resultmale22);
while ($rowfemale22 = mysqli_fetch_assoc($resultfemale22)) {
	$wfemale999[] = $rowfemale22['student_name'];
}
$wfemale9 = $wfemale999;
$wkfemale99 = mysqli_num_rows($resultfemale22);
}







if($l == "Monday"){
$tb16 = (round(abs(strtotime($tb15) + 604800)));
$tb17 = date("Y-m-d", $tb16);
$result24 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb17') AND (datename <= DATE_ADD( '$tb17', INTERVAL 4 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att10 = mysqli_num_rows($result24);
$resultmornmon10 = mysqli_query($db, "SELECT student_name FROM attend where (datename = '$tb17') AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornmon10 = mysqli_fetch_assoc($resultmornmon10)) {
	$wmorn11110[] = $rowmornmon10['student_name'];
}
$monmorn10 = count($wmorn11110);
$resultaftmon10 = mysqli_query($db, "SELECT student_name FROM attend where (datename = '$tb17') AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftmon10 = mysqli_fetch_assoc($resultaftmon10)) {
	$waft11110[] = $rowaftmon10['student_name'];
}
$monaft10 = count($waft11110);
$resultmorntue10 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb17', INTERVAL 1 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmorntue10 = mysqli_fetch_assoc($resultmorntue10)) {
	$wmorntue11110[] = $rowmorntue10['student_name'];
}
$tuemorn10 = count($wmorntue11110);
$resultafttue10 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb17', INTERVAL 1 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowafttue10 = mysqli_fetch_assoc($resultafttue10)) {
	$wafttue11110[] = $rowafttue10['student_name'];
}
$tueaft10 = count($wafttue11110);
$resultmornwed10 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb17', INTERVAL 2 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornwed10 = mysqli_fetch_assoc($resultmornwed10)) {
	$wmornwed11110[] = $rowmornwed10['student_name'];
}
$wedmorn10 = count($wmornwed11110);
$resultaftwed10 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb17', INTERVAL 2 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftwed10 = mysqli_fetch_assoc($resultaftwed10)) {
	$waftwed11110[] = $rowaftwed10['student_name'];
}
$wedaft10 = count($waftwed11110);
$resultmornthur10 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb17', INTERVAL 3 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornthur10 = mysqli_fetch_assoc($resultmornthur10)) {
	$wmornthur11110[] = $rowmornthur10['student_name'];
}
$thurmorn10 = count($wmornthur11110);
$resultaftthur10 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb17', INTERVAL 3 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftthur10 = mysqli_fetch_assoc($resultaftthur10)) {
	$waftthur11110[] = $rowaftthur10['student_name'];
}
$thuraft10 = count($waftthur11110);
$resultmornfri10 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb17', INTERVAL 4 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornfri10 = mysqli_fetch_assoc($resultmornfri10)) {
	$wmornfri11110[] = $rowmornfri10['student_name'];
}
$frimorn10 = count($wmornfri11110);
$resultaftfri10 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb17', INTERVAL 4 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftfri10 = mysqli_fetch_assoc($resultaftfri10)) {
	$waftfri11110[] = $rowaftfri10['student_name'];
}
$friaft10 = count($waftfri11110);
$resultmale24 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb17' AND (datename <= DATE_ADD( '$tb17', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale24 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb17') AND (datename <= DATE_ADD( '$tb17', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale24 = mysqli_fetch_assoc($resultmale24)) {
	$wmale1010[] = $rowmale24['student_name'];
}
$wmale10 = $wmale1010;
$wkmale1010 = mysqli_num_rows($resultmale24);
while ($rowfemale24 = mysqli_fetch_assoc($resultfemale24)) {
	$wfemale1010[] = $rowfemale24['student_name'];
}
$wfemale10 = $wfemale1010;
$wkfemale1010 = mysqli_num_rows($resultfemale24);
}






if($l == "Monday"){
$tb18 = (round(abs(strtotime($tb17) + 604800)));
$tb19 = date("Y-m-d", $tb18);
$result26 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb19') AND (datename <= DATE_ADD( '$tb19', INTERVAL 4 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att11 = mysqli_num_rows($result26);
$resultmornmon11 = mysqli_query($db, "SELECT student_name FROM attend where (datename = '$tb19') AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornmon11 = mysqli_fetch_assoc($resultmornmon11)) {
	$wmorn11111[] = $rowmornmon11['student_name'];
}
$monmorn11 = count($wmorn11111);
$resultaftmon11 = mysqli_query($db, "SELECT student_name FROM attend where (datename = '$tb19') AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftmon11 = mysqli_fetch_assoc($resultaftmon11)) {
	$waft11111[] = $rowaftmon11['student_name'];
}
$monaft11 = count($waft11111);
$resultmorntue11 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb19', INTERVAL 1 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmorntue11 = mysqli_fetch_assoc($resultmorntue11)) {
	$wmorntue11111[] = $rowmorntue11['student_name'];
}
$tuemorn11 = count($wmorntue11111);
$resultafttue11 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb19', INTERVAL 1 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowafttue11 = mysqli_fetch_assoc($resultafttue11)) {
	$wafttue11111[] = $rowafttue11['student_name'];
}
$tueaft11 = count($wafttue11111);
$resultmornwed11 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb19', INTERVAL 2 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornwed11 = mysqli_fetch_assoc($resultmornwed11)) {
	$wmornwed11111[] = $rowmornwed11['student_name'];
}
$wedmorn11 = count($wmornwed11111);
$resultaftwed11 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb19', INTERVAL 2 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftwed11 = mysqli_fetch_assoc($resultaftwed11)) {
	$waftwed11111[] = $rowaftwed11['student_name'];
}
$wedaft11 = count($waftwed11111);
$resultmornthur11 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb19', INTERVAL 3 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornthur11 = mysqli_fetch_assoc($resultmornthur11)) {
	$wmornthur11111[] = $rowmornthur11['student_name'];
}
$thurmorn11 = count($wmornthur11111);
$resultaftthur11 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb19', INTERVAL 3 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftthur11 = mysqli_fetch_assoc($resultaftthur11)) {
	$waftthur11111[] = $rowaftthur11['student_name'];
}
$thuraft11 = count($waftthur11111);
$resultmornfri11 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb19', INTERVAL 4 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornfri11 = mysqli_fetch_assoc($resultmornfri11)) {
	$wmornfri11111[] = $rowmornfri11['student_name'];
}
$frimorn11 = count($wmornfri11111);
$resultaftfri11 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb19', INTERVAL 4 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftfri11 = mysqli_fetch_assoc($resultaftfri11)) {
	$waftfri11111[] = $rowaftfri11['student_name'];
}
$friaft11 = count($waftfri11111);
$resultmale26 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb19' AND (datename <= DATE_ADD( '$tb19', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale26 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb19') AND (datename <= DATE_ADD( '$tb19', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale26 = mysqli_fetch_assoc($resultmale26)) {
	$wmale1111[] = $rowmale26['student_name'];
}
$wmale11 = $wmale1111;
$wkmale1111 = mysqli_num_rows($resultmale26);
while ($rowfemale26 = mysqli_fetch_assoc($resultfemale26)) {
	$wfemale1111[] = $rowfemale26['student_name'];
}
$wfemale11 = $wfemale1111;
$wkfemale1111 = mysqli_num_rows($resultfemale26);
}





if($l == "Monday"){
$tb20 = (round(abs(strtotime($tb19) + 604800)));
$tb21 = date("Y-m-d", $tb20);
$result28 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb21') AND (datename <= DATE_ADD( '$tb21', INTERVAL 4 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att12 = mysqli_num_rows($result28);
$resultmornmon12 = mysqli_query($db, "SELECT student_name FROM attend where (datename = '$tb21') AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornmon12 = mysqli_fetch_assoc($resultmornmon12)) {
	$wmorn11112[] = $rowmornmon12['student_name'];
}
$monmorn12 = count($wmorn11112);
$resultaftmon12 = mysqli_query($db, "SELECT student_name FROM attend where (datename = '$tb21') AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftmon12 = mysqli_fetch_assoc($resultaftmon12)) {
	$waft11112[] = $rowaftmon12['student_name'];
}
$monaft12 = count($waft11112);
$resultmorntue12 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb21', INTERVAL 1 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmorntue12 = mysqli_fetch_assoc($resultmorntue12)) {
	$wmorntue11112[] = $rowmorntue12['student_name'];
}
$tuemorn12 = count($wmorntue11112);
$resultafttue12 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb21', INTERVAL 1 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowafttue12 = mysqli_fetch_assoc($resultafttue12)) {
	$wafttue11112[] = $rowafttue12['student_name'];
}
$tueaft12 = count($wafttue11112);
$resultmornwed12 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb21', INTERVAL 2 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornwed11 = mysqli_fetch_assoc($resultmornwed12)) {
	$wmornwed11112[] = $rowmornwed12['student_name'];
}
$wedmorn12 = count($wmornwed11112);
$resultaftwed12 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb21', INTERVAL 2 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftwed12 = mysqli_fetch_assoc($resultaftwed12)) {
	$waftwed11112[] = $rowaftwed12['student_name'];
}
$wedaft12 = count($waftwed11112);
$resultmornthur12 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb21', INTERVAL 3 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornthur12 = mysqli_fetch_assoc($resultmornthur12)) {
	$wmornthur11112[] = $rowmornthur12['student_name'];
}
$thurmorn12 = count($wmornthur11112);
$resultaftthur12 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb21', INTERVAL 3 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftthur12 = mysqli_fetch_assoc($resultaftthur12)) {
	$waftthur11112[] = $rowaftthur12['student_name'];
}
$thuraft12 = count($waftthur11112);
$resultmornfri12 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb21', INTERVAL 4 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornfri12 = mysqli_fetch_assoc($resultmornfri12)) {
	$wmornfri11112[] = $rowmornfri12['student_name'];
}
$frimorn12 = count($wmornfri11112);
$resultaftfri12 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb21', INTERVAL 4 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftfri12 = mysqli_fetch_assoc($resultaftfri12)) {
	$waftfri11112[] = $rowaftfri12['student_name'];
}
$friaft12 = count($waftfri11112);
$resultmale28 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb21' AND (datename <= DATE_ADD( '$tb21', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale28 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb21') AND (datename <= DATE_ADD( '$tb21', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale28 = mysqli_fetch_assoc($resultmale28)) {
	$wmale1212[] = $rowmale28['student_name'];
}
$wmale12 = $wmale1212;
$wkmale1212 = mysqli_num_rows($resultmale28);
while ($rowfemale28 = mysqli_fetch_assoc($resultfemale28)) {
	$wfemale1212[] = $rowfemale28['student_name'];
}
$wfemale12 = $wfemale1212;
$wkfemale1212 = mysqli_num_rows($resultfemale28);
}



if($l == "Monday"){
$tb22 = (round(abs(strtotime($tb21) + 604800)));
$tb23 = date("Y-m-d", $tb22);
$result30 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb23') AND (datename <= DATE_ADD( '$tb23', INTERVAL 4 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att13 = mysqli_num_rows($result30);
$resultmornmon13 = mysqli_query($db, "SELECT student_name FROM attend where (datename = '$tb23') AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornmon13 = mysqli_fetch_assoc($resultmornmon13)) {
	$wmorn11113[] = $rowmornmon13['student_name'];
}
$monmorn13 = count($wmorn11113);
$resultaftmon13 = mysqli_query($db, "SELECT student_name FROM attend where (datename = '$tb23') AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftmon13 = mysqli_fetch_assoc($resultaftmon13)) {
	$waft11113[] = $rowaftmon13['student_name'];
}
$monaft13 = count($waft11113);
$resultmorntue13 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb23', INTERVAL 1 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmorntue13 = mysqli_fetch_assoc($resultmorntue13)) {
	$wmorntue11113[] = $rowmorntue13['student_name'];
}
$tuemorn13 = count($wmorntue11113);
$resultafttue13 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb23', INTERVAL 1 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowafttue13 = mysqli_fetch_assoc($resultafttue13)) {
	$wafttue11113[] = $rowafttue13['student_name'];
}
$tueaft13 = count($wafttue11113);
$resultmornwed13 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb23', INTERVAL 2 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornwed13 = mysqli_fetch_assoc($resultmornwed13)) {
	$wmornwed11113[] = $rowmornwed13['student_name'];
}
$wedmorn13 = count($wmornwed11113);
$resultaftwed13 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb23', INTERVAL 2 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftwed13 = mysqli_fetch_assoc($resultaftwed13)) {
	$waftwed11113[] = $rowaftwed13['student_name'];
}
$wedaft13 = count($waftwed11113);
$resultmornthur13 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb23', INTERVAL 3 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornthur13 = mysqli_fetch_assoc($resultmornthur13)) {
	$wmornthur11113[] = $rowmornthur13['student_name'];
}
$thurmorn13 = count($wmornthur11113);
$resultaftthur13 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb23', INTERVAL 3 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftthur13 = mysqli_fetch_assoc($resultaftthur13)) {
	$waftthur11113[] = $rowaftthur13['student_name'];
}
$thuraft13 = count($waftthur11113);
$resultmornfri13 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb23', INTERVAL 4 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornfri13 = mysqli_fetch_assoc($resultmornfri13)) {
	$wmornfri11113[] = $rowmornfri13['student_name'];
}
$frimorn13 = count($wmornfri11113);
$resultaftfri13 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb23', INTERVAL 4 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftfri13 = mysqli_fetch_assoc($resultaftfri13)) {
	$waftfri11113[] = $rowaftfri13['student_name'];
}
$friaft13 = count($waftfri11113);
$resultmale30 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb23' AND (datename <= DATE_ADD( '$tb23', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale30 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb23') AND (datename <= DATE_ADD( '$tb23', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale30 = mysqli_fetch_assoc($resultmale30)) {
	$wmale1313[] = $rowmale30['student_name'];
}
$wmale13 = $wmale1313;
$wkmale1313 = mysqli_num_rows($resultmale30);

while ($rowfemale30 = mysqli_fetch_assoc($resultfemale30)) {
	$wfemale1313[] = $rowfemale30['student_name'];
}
$wfemale13 = $wfemale1313;
$wkfemale1313 = mysqli_num_rows($resultfemale30);
}




if($l == "Monday"){
$tb24 = (round(abs(strtotime($tb23) + 604800)));
$tb25 = date("Y-m-d", $tb24);
$result32 = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$tb25') AND (datename <= DATE_ADD( '$tb25', INTERVAL 4 DAY )) AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$att14 = mysqli_num_rows($result32);
$resultmornmon14 = mysqli_query($db, "SELECT student_name FROM attend where (datename = '$tb25') AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornmon14 = mysqli_fetch_assoc($resultmornmon14)) {
	$wmorn11114[] = $rowmornmon14['student_name'];
}
$monmorn14 = count($wmorn11114);
$resultaftmon14 = mysqli_query($db, "SELECT student_name FROM attend where (datename = '$tb25') AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftmon14 = mysqli_fetch_assoc($resultaftmon14)) {
	$waft11114[] = $rowaftmon14['student_name'];
}
$monaft14 = count($waft11114);
$resultmorntue14 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb25', INTERVAL 1 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmorntue14 = mysqli_fetch_assoc($resultmorntue14)) {
	$wmorntue11114[] = $rowmorntue14['student_name'];
}
$tuemorn14 = count($wmorntue11114);
$resultafttue14 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb25', INTERVAL 1 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowafttue14 = mysqli_fetch_assoc($resultafttue14)) {
	$wafttue11114[] = $rowafttue14['student_name'];
}
$tueaft14 = count($wafttue11114);
$resultmornwed14 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb25', INTERVAL 2 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornwed14 = mysqli_fetch_assoc($resultmornwed14)) {
	$wmornwed11114[] = $rowmornwed14['student_name'];
}
$wedmorn14 = count($wmornwed11114);
$resultaftwed14 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb25', INTERVAL 2 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftwed14 = mysqli_fetch_assoc($resultaftwed14)) {
	$waftwed11114[] = $rowaftwed14['student_name'];
}
$wedaft14 = count($waftwed11114);
$resultmornthur14 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb25', INTERVAL 3 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornthur14 = mysqli_fetch_assoc($resultmornthur14)) {
	$wmornthur11114[] = $rowmornthur14['student_name'];
}
$thurmorn14 = count($wmornthur11114);
$resultaftthur14 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb25', INTERVAL 3 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftthur14 = mysqli_fetch_assoc($resultaftthur14)) {
	$waftthur11114[] = $rowaftthur14['student_name'];
}
$thuraft14 = count($waftthur11114);
$resultmornfri14 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb25', INTERVAL 4 DAY )) AND dtime='Morning' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowmornfri14 = mysqli_fetch_assoc($resultmornfri14)) {
	$wmornfri11114[] = $rowmornfri14['student_name'];
}
$frimorn14 = count($wmornfri11114);
$resultaftfri14 = mysqli_query($db, "SELECT student_name FROM attend where (datename = DATE_ADD( '$tb25', INTERVAL 4 DAY )) AND dtime='Afternnon' AND attend='present' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($rowaftfri14 = mysqli_fetch_assoc($resultaftfri14)) {
	$waftfri11114[] = $rowaftfri14['student_name'];
}
$friaft14 = count($waftfri11114);
$resultmale32 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Male' AND datename >= '$tb25' AND (datename <= DATE_ADD( '$tb25', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$resultfemale32 = mysqli_query($db, "SELECT * FROM attend where attend='present' AND sex='Female' AND (datename >= '$tb25') AND (datename <= DATE_ADD( '$tb25', INTERVAL 4 DAY )) AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($rowmale32 = mysqli_fetch_assoc($resultmale32)) {
	$wmale1414[] = $rowmale32['student_name'];
}
$wmale14 = $wmale1414;
$wkmale1414 = mysqli_num_rows($resultmale32);

while ($rowfemale32 = mysqli_fetch_assoc($resultfemale32)) {
	$wfemale1414[] = $rowfemale32['student_name'];
}
$wfemale14 = $wfemale1414;
$wkfemale1414 = mysqli_num_rows($resultfemale32);
}

$date = DateTime::createFromFormat("Y-m-d", $termbegin);
	$l = $date->format("l");
	if($l == "Tuesday"){ $termbeginit = date('Y-m-d', strtotime($termbegin. ' - 1 days')); }
	else if($l == "Wednesday"){ $termbeginit = date('Y-m-d', strtotime($termbegin. ' - 2 days')); }
	else if($l == "Thursday"){ $termbeginit = date('Y-m-d', strtotime($termbegin. ' - 3 days')); }
	else if($l == "Friday"){ $termbeginit = date('Y-m-d', strtotime($termbegin. ' - 4 days')); }
	else{ $termbeginit = date('Y-m-d', strtotime($termbegin. ' - 0 days')); }
echo "<br><br>";	
echo '<table table style="width:100%;" cellpadding="1" cellspacing="1" border="1" class="table table-striped table-bordered" id="mytable">';
echo '<thead><tr style="font-size: 11px;">';
echo '<th style="text-align:center;">NAME</th>';
echo '<th style="text-align:center;">SEX</th>';
echo '<th style="text-align:center;">ABSENT<br>Morning;&nbsp; Afternoon</th>';
echo '<th style="text-align:center;">WK 01 <br>ending: '.date('d/m/Y', strtotime($termbeginit. ' + 4 days')).'</th>';
echo '<th style="text-align:center;">WK 02 <br>ending: '.date('d/m/Y', strtotime($termbeginit. ' + 11 days')).'</th>';
echo '<th style="text-align:center;">WK 03 <br>ending: '.date('d/m/Y', strtotime($termbeginit. ' + 18 days')).'</th>';
echo '<th style="text-align:center;">WK 04 <br>ending: '.date('d/m/Y', strtotime($termbeginit. ' + 25 days')).'</th>';
echo '<th style="text-align:center;">WK 05 <br>ending: '.date('d/m/Y', strtotime($termbeginit. ' + 32 days')).'</th>';
echo '<th style="text-align:center;">WK 06 <br>ending: '.date('d/m/Y', strtotime($termbeginit. ' + 39 days')).'</th>';
echo '<th style="text-align:center;">WK 07 <br>ending: '.date('d/m/Y', strtotime($termbeginit. ' + 46 days')).'</th>';
echo '<th style="text-align:center;">WK 08 <br>ending: '.date('d/m/Y', strtotime($termbeginit. ' + 53 days')).'</th>';
echo '<th style="text-align:center;">WK 09 <br>ending: '.date('d/m/Y', strtotime($termbeginit. ' + 60 days')).'</th>';
echo '<th style="text-align:center;">WK 10 <br>ending: '.date('d/m/Y', strtotime($termbeginit. ' + 67 days')).'</th>';
echo '<th style="text-align:center;">WK 11 <br>ending: '.date('d/m/Y', strtotime($termbeginit. ' + 74 days')).'</th>';
echo '<th style="text-align:center;">WK 12 <br>ending: '.date('d/m/Y', strtotime($termbeginit. ' + 81 days')).'</th>';
echo '<th style="text-align:center;">WK 13 <br>ending: '.date('d/m/Y', strtotime($termbeginit. ' + 88 days')).'</th>';
echo '<th style="text-align:center;">WK 14 <br>ending: '.date('d/m/Y', strtotime($termbeginit. ' + 95 days')).'</th>';
echo '<th style="text-align:center;">MID TOT.</th>';
echo '<th style="text-align:center;">TOT.</th>';
echo '</tr></thead>';

$wk1end = date('d/m/Y', strtotime($termbeginit. ' + 4 days'));
$wk2end = date('d/m/Y', strtotime($termbeginit. ' + 11 days'));
$wk3end = date('d/m/Y', strtotime($termbeginit. ' + 18 days'));
$wk4end = date('d/m/Y', strtotime($termbeginit. ' + 25 days'));
$wk5end = date('d/m/Y', strtotime($termbeginit. ' + 32 days'));
$wk6end = date('d/m/Y', strtotime($termbeginit. ' + 39 days'));
$wk7end = date('d/m/Y', strtotime($termbeginit. ' + 46 days'));
$wk8end = date('d/m/Y', strtotime($termbeginit. ' + 53 days'));
$wk9end = date('d/m/Y', strtotime($termbeginit. ' + 60 days'));
$wk10end = date('d/m/Y', strtotime($termbeginit. ' + 67 days'));
$wk11end = date('d/m/Y', strtotime($termbeginit. ' + 74 days'));
$wk12end = date('d/m/Y', strtotime($termbeginit. ' + 81 days'));
$wk13end = date('d/m/Y', strtotime($termbeginit. ' + 88 days'));
$wk14end = date('d/m/Y', strtotime($termbeginit. ' + 95days'));

$result2 = mysqli_query($db, "SELECT * FROM studentsbyclass where class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
while ($row6 = mysqli_fetch_assoc($result2)) {
	$w1[] = $row6['student_name'];
	$ww = $row6['student_name'];
	$result52 = mysqli_query($db, "SELECT * FROM regstu where student_name='$ww' AND school='".$_SESSION["school"]."'");
while ($row56 = mysqli_fetch_assoc($result52)) {
	$ss1[] = $row56['sex'];
}	
}
$w2 = $w1;
$counted = count($w2);
$s = $ss1;
$countsex = count($s);
//$countsex;
$counsex = 0;
$ccount = 0;

//print_r($ss1);

foreach ($w2 as $value) {
$result3 = mysqli_query($db, "SELECT * FROM maxattname WHERE year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($row3 = mysqli_fetch_assoc($result3)) {
$termbegin1[] = $row3['termbegin'];	
}
$termbegin = current($termbegin1);



$result2 = mysqli_query($db, "SELECT * FROM attend where student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$result = mysqli_query($db, "SELECT DISTINCT(student_name) FROM attend where student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");

$date = DateTime::createFromFormat("Y-m-d", $termbegin);
$l = $date->format("l");
if($l == "Monday"){
$result5 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$termbegin') AND (datename <= DATE_ADD( '$termbegin', INTERVAL 4 DAY )) AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$redate = mysqli_num_rows($result5);
$resultformid5a = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row5 = mysqli_fetch_assoc($resultformid5a)) {
$resultformid5b[] = $row5['dt'];	
}
$resultformid5c = current($resultformid5b);
$resultformid5d = mysqli_query($db, "SELECT * FROM attend where (datename >= '$termbegin') AND (datename <= DATE_ADD( '$termbegin', INTERVAL 4 DAY )) AND datename < '$resultformid5c' AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$resultformid5e = mysqli_num_rows($resultformid5d);
}
elseif($l == "Tuesday"){
$result5 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$termbegin') AND (datename <= DATE_ADD( '$termbegin', INTERVAL 3 DAY )) AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$redate = mysqli_num_rows($result5);
}
elseif($l == "Wednesday"){
$result5 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$termbegin') AND (datename <= DATE_ADD( '$termbegin', INTERVAL 2 DAY )) AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$redate = mysqli_num_rows($result5);
}
elseif($l == "Thursday"){
$result5 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$termbegin') AND (datename <= DATE_ADD( '$termbegin', INTERVAL 1 DAY )) AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$redate = mysqli_num_rows($result5);
}
elseif($l == "Friday"){
$result5 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$termbegin') AND (datename <= DATE_ADD( '$termbegin', INTERVAL 0 DAY )) AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$redate = mysqli_num_rows($result5);
}


$date = DateTime::createFromFormat("Y-m-d", $termbegin);
$l = $date->format("l");
if($l == "Monday"){
$tb = (round(abs(strtotime($termbegin) + 604800)));
$tb1 = date("Y-m-d", $tb);
$result7 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 4 DAY )) AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$redate7 = mysqli_num_rows($result7);
$resultformid7a = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row7 = mysqli_fetch_assoc($resultformid7a)) {
$resultformid7b[] = $row7['dt'];	
}
$resultformid7c = current($resultformid7b);
$resultformid7d = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 4 DAY )) AND datename < '$resultformid7c' AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$resultformid7e = mysqli_num_rows($resultformid7d);
}
elseif($l == "Tuesday"){
$tb = (round(abs(strtotime($termbegin) + 518400)));
$tb1 = date("Y-m-d", $tb);
$result7 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 3 DAY )) AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$redate7 = mysqli_num_rows($result7);	
}
elseif($l == "Wednesday"){
$tb = (round(abs(strtotime($termbegin) + 432000)));
$tb1 = date("Y-m-d", $tb);
$result7 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 2 DAY )) AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$redate7 = mysqli_num_rows($result7);	
}
elseif($l == "Thursday"){
$tb = (round(abs(strtotime($termbegin) + 345600)));
$tb1 = date("Y-m-d", $tb);
$result7 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 1 DAY )) AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$redate7 = mysqli_num_rows($result7);	
}
elseif($l == "Friday"){
$tb = (round(abs(strtotime($termbegin) + 259200)));
$tb1 = date("Y-m-d", $tb);
$result7 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 0 DAY )) AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$redate7 = mysqli_num_rows($result7);	
}
else{
$tb = (round(abs(strtotime($termbegin) + 259200)));
$tb1 = date("Y-m-d", $tb);
$result7 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb1') AND (datename <= DATE_ADD( '$tb1', INTERVAL 0 DAY )) AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$redate7 = mysqli_num_rows($result7);	
}



$tb2 = (round(abs(strtotime($tb1) + 604800)));
$tb3 = date("Y-m-d", $tb2);
$result9 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb3') AND (datename <= DATE_ADD( '$tb3', INTERVAL 4 DAY )) AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$redate9 = mysqli_num_rows($result9);
$resultformid9a = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row9 = mysqli_fetch_assoc($resultformid9a)) {
$resultformid9b[] = $row9['dt'];	
}
$resultformid9c = current($resultformid9b);
$resultformid9d = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb3') AND (datename <= DATE_ADD( '$tb3', INTERVAL 4 DAY )) AND datename < '$resultformid9c' AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$resultformid9e = mysqli_num_rows($resultformid9d);



$tb4 = (round(abs(strtotime($tb3) + 604800)));
$tb5 = date("Y-m-d", $tb4);
$result11 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb5') AND (datename <= DATE_ADD( '$tb5', INTERVAL 4 DAY )) AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$redate11 = mysqli_num_rows($result11);
$resultformid11a = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row11 = mysqli_fetch_assoc($resultformid11a)) {
$resultformid11b[] = $row11['dt'];	
}
$resultformid11c = current($resultformid11b);
$resultformid11d = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb5') AND (datename <= DATE_ADD( '$tb5', INTERVAL 4 DAY )) AND datename < '$resultformid11c' AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$resultformid11e = mysqli_num_rows($resultformid11d);


$tb6 = (round(abs(strtotime($tb5) + 604800)));
$tb7 = date("Y-m-d", $tb6);
$result13 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb7') AND (datename <= DATE_ADD( '$tb7', INTERVAL 4 DAY )) AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$redate13 = mysqli_num_rows($result13);
$resultformid13a = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row13 = mysqli_fetch_assoc($resultformid13a)) {
$resultformid13b[] = $row13['dt'];	
}
$resultformid13c = current($resultformid13b);
$resultformid13d = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb7') AND (datename <= DATE_ADD( '$tb7', INTERVAL 4 DAY )) AND datename < '$resultformid13c' AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$resultformid13e = mysqli_num_rows($resultformid13d);


$tb8 = (round(abs(strtotime($tb7) + 604800)));
$tb9 = date("Y-m-d", $tb8);
$result15 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb9') AND (datename <= DATE_ADD( '$tb9', INTERVAL 4 DAY )) AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$redate15 = mysqli_num_rows($result15);
$resultformid15a = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms'");
while ($row15 = mysqli_fetch_assoc($resultformid15a)) {
$resultformid15b[] = $row15['dt'];	
}
$resultformid15c = current($resultformid15b);
$resultformid15d = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb9') AND (datename <= DATE_ADD( '$tb9', INTERVAL 4 DAY )) AND datename < '$resultformid15c' AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$resultformid15e = mysqli_num_rows($resultformid15d);



$tb10 = (round(abs(strtotime($tb9) + 604800)));
$tb11 = date("Y-m-d", $tb10);
$result17 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb11') AND (datename <= DATE_ADD( '$tb11', INTERVAL 4 DAY )) AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$redate17 = mysqli_num_rows($result17);
$resultformid17a = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row17 = mysqli_fetch_assoc($resultformid17a)) {
$resultformid17b[] = $row17['dt'];	
}
$resultformid17c = current($resultformid17b);
$resultformid17d = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb11') AND (datename <= DATE_ADD( '$tb11', INTERVAL 4 DAY )) AND datename < '$resultformid17c' AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$resultformid17e = mysqli_num_rows($resultformid17d);


$tb12 = (round(abs(strtotime($tb11) + 604800)));
$tb13 = date("Y-m-d", $tb12);
$result19 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb13') AND (datename <= DATE_ADD( '$tb13', INTERVAL 4 DAY )) AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$redate19 = mysqli_num_rows($result19);
$resultformid19a = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row19 = mysqli_fetch_assoc($resultformid19a)) {
$resultformid19b[] = $row19['dt'];	
}
$resultformid19c = current($resultformid19b);
$resultformid19d = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb13') AND (datename <= DATE_ADD( '$tb13', INTERVAL 4 DAY )) AND datename < '$resultformid19c' AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$resultformid19e = mysqli_num_rows($resultformid19d);


$tb14 = (round(abs(strtotime($tb13) + 604800)));
$tb15 = date("Y-m-d", $tb14);
$result21 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb15') AND (datename <= DATE_ADD( '$tb15', INTERVAL 4 DAY )) AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$redate21 = mysqli_num_rows($result21);
$resultformid21a = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row21 = mysqli_fetch_assoc($resultformid21a)) {
$resultformid21b[] = $row21['dt'];	
}
$resultformid21c = current($resultformid21b);
$resultformid21d = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb15') AND (datename <= DATE_ADD( '$tb15', INTERVAL 4 DAY )) AND datename < '$resultformid21c' AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$resultformid21e = mysqli_num_rows($resultformid21d);


$tb16 = (round(abs(strtotime($tb15) + 604800)));
$tb17 = date("Y-m-d", $tb16);
$result23 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb17') AND (datename <= DATE_ADD( '$tb17', INTERVAL 4 DAY )) AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$redate23 = mysqli_num_rows($result23);
$resultformid23a = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row23 = mysqli_fetch_assoc($resultformid23a)) {
$resultformid23b[] = $row23['dt'];	
}
$resultformid23c = current($resultformid23b);
$resultformid23d = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb17') AND (datename <= DATE_ADD( '$tb17', INTERVAL 4 DAY )) AND datename < '$resultformid23c' AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$resultformid23e = mysqli_num_rows($resultformid23d);



$tb18 = (round(abs(strtotime($tb17) + 604800)));
$tb19 = date("Y-m-d", $tb18);
$result25 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb19') AND (datename <= DATE_ADD( '$tb19', INTERVAL 4 DAY )) AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$redate25 = mysqli_num_rows($result25);
$resultformid25a = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row25 = mysqli_fetch_assoc($resultformid25a)) {
$resultformid25b[] = $row25['dt'];	
}
$resultformid25c = current($resultformid25b);
$resultformid25d = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb19') AND (datename <= DATE_ADD( '$tb19', INTERVAL 4 DAY )) AND datename < '$resultformid25c' AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$resultformid25e = mysqli_num_rows($resultformid25d);



$tb20 = (round(abs(strtotime($tb19) + 604800)));
$tb21 = date("Y-m-d", $tb20);
$result27 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb21') AND (datename <= DATE_ADD( '$tb21', INTERVAL 4 DAY )) AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$redate27 = mysqli_num_rows($result27);
$resultformid27a = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms'");
while ($row27 = mysqli_fetch_assoc($resultformid27a)) {
$resultformid27b[] = $row27['dt'];	
}
$resultformid27c = current($resultformid27b);
$resultformid27d = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb21') AND (datename <= DATE_ADD( '$tb21', INTERVAL 4 DAY )) AND datename < '$resultformid27c' AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$resultformid27e = mysqli_num_rows($resultformid27d);



$tb22 = (round(abs(strtotime($tb21) + 604800)));
$tb23 = date("Y-m-d", $tb22);
$result29 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb23') AND (datename <= DATE_ADD( '$tb23', INTERVAL 4 DAY )) AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$redate29 = mysqli_num_rows($result29);
$resultformid29a = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row29 = mysqli_fetch_assoc($resultformid29a)) {
$resultformid29b[] = $row29['dt'];	
}
$resultformid29c = current($resultformid29b);
$resultformid29d = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb23') AND (datename <= DATE_ADD( '$tb23', INTERVAL 4 DAY )) AND datename < '$resultformid29c' AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$resultformid29e = mysqli_num_rows($resultformid29d);



$tb24 = (round(abs(strtotime($tb23) + 604800)));
$tb25 = date("Y-m-d", $tb24);
$result31 = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb25') AND (datename <= DATE_ADD( '$tb25', INTERVAL 4 DAY )) AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$redate31 = mysqli_num_rows($result31);
$resultformid31a = mysqli_query($db, "SELECT MIN(datename) AS dt FROM attend where attend='midterm' AND class='$class' AND year='$year' AND term='$term' AND formt='$formt' AND arms='$arms' AND school='".$_SESSION["school"]."'");
while ($row31 = mysqli_fetch_assoc($resultformid31a)) {
$resultformid31b[] = $row31['dt'];	
}
$resultformid31c = current($resultformid31b);
$resultformid31d = mysqli_query($db, "SELECT * FROM attend where (datename >= '$tb25') AND (datename <= DATE_ADD( '$tb25', INTERVAL 4 DAY )) AND datename < '$resultformid31c' AND student_name='$value' AND attend='present' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$resultformid31e = mysqli_num_rows($resultformid31d);

$redatetotal = $redate + $redate7 + $redate9 + $redate11 + $redate13 + $redate15  + $redate17 + $redate19 + $redate21  + $redate23 + $redate25 + $redate27 + $redate29  + $redate31;
$redatetotalmid = $resultformid5e + $resultformid7e + $resultformid9e + $resultformid11e + $resultformid13e + $resultformid15e + $resultformid17e + $resultformid19e + $resultformid21e + $resultformid23e + $resultformid25e + $resultformid27e + $resultformid29e + $resultformid31e;
$atttotalalmid = $attmid1 + $attmid2 + $attmid3 + $attmid4 + $attmid5 + $attmid6 + $attmid7 + $attmid8 + $attmid9 + $attmid10 + $attmid11 + $attmid12 + $attmid13 + $attmid14;
$atttotalal = $att1 + $att2 + $att3 + $att4 + $att5 + $att6 + $att7 + $att8 + $att9 + $att10 + $att11 + $att12 + $att13 + $att14;

$atttotalallmid = $atttotalalmid * ($counted*2);
$atttotalall = $atttotalal * ($counted*2);

echo '<tr>';
echo '<td style="text-align:center;">'.$value.'</td>'; // for students names
$getsex = $s[$counsex++];
if($getsex == "female"){
	$getsexfemale[] = $getsex;
echo '<td class="sexcell" style="text-align:center; color: red;">'.$getsex.'</td>';
}else{
	$getsexmale[] = $getsex;
echo '<td class="sexcell" style="text-align:center; color: blue;">'.$getsex.'</td>';	
}
$getsexall[] = $getsex;
$date = DateTime::createFromFormat("Y-m-d", $termbegin);
$d = $date->format("d");
if($l == "Tuesday"){ $termbegin = date('Y-m-d', strtotime($termbegin. ' - 1 days')); }
	else if($l == "Wednesday"){ $termbegin = date('Y-m-d', strtotime($termbegin. ' - 2 days')); }
	else if($l == "Thursday"){ $termbegin = date('Y-m-d', strtotime($termbegin. ' - 3 days')); }
	else if($l == "Friday"){ $termbegin = date('Y-m-d', strtotime($termbegin. ' - 4 days')); }
	else{ $termbegin = date('Y-m-d', strtotime($termbegin. ' - 0 days')); }
$resultab5 = mysqli_query($db, "SELECT datename, dtime FROM attend where (datename >= '$termbegin') AND (datename <= DATE_ADD( '$termbegin', INTERVAL 95 DAY )) AND student_name='$value' AND attend='absent' AND class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND formt='$formt' AND school='".$_SESSION["school"]."'");
$stri = "";
$strin="";
while ($rrr5 = mysqli_fetch_assoc($resultab5)) {
$date = DateTime::createFromFormat("Y-m-d", $rrr5['datename']);
$dtm = $rrr5['dtime'];
if($dtm == 'Morning'){
	$dtm2 = '(M)';
}else{
	$dtm2 = '(A)';
}
$d = $date->format("d/m");
$stri .= $d.'&nbsp;'.$dtm2.', ';
}
echo '<td class="redat" id="'.$ccount.'" style="text-align:center; background-color: black; color: white; font-size: 10px;">'.$stri.'</td>';	
echo '<td class="redate" style="text-align:center;">'.$redate.'</td>';
echo '<td class="redate7" style="text-align:center;">'.$redate7.'</td>';
echo '<td class="redate9" style="text-align:center;">'.$redate9.'</td>';
echo '<td class="redate11" style="text-align:center;">'.$redate11.'</td>';
echo '<td class="redate13" style="text-align:center;">'.$redate13.'</td>';
echo '<td class="redate15" style="text-align:center;">'.$redate15.'</td>';
echo '<td class="redate17" style="text-align:center;">'.$redate17.'</td>';
echo '<td class="redate19" style="text-align:center;">'.$redate19.'</td>';
echo '<td class="redate21" style="text-align:center;">'.$redate21.'</td>';
echo '<td class="redate23" style="text-align:center;">'.$redate23.'</td>';
echo '<td class="redate25" style="text-align:center;">'.$redate25.'</td>';
echo '<td class="redate27" style="text-align:center;">'.$redate27.'</td>';
echo '<td class="redate29" style="text-align:center;">'.$redate29.'</td>';
echo '<td class="redate31" style="text-align:center;">'.$redate31.'</td>';
echo '<td class="redate31" style="text-align:center;">'.$redatetotalmid.'</td>';
echo '<td class="redatetotal" style="text-align:center;">'.$redatetotal.'</td>';
echo '</tr>';
$ccount++;
$valuestudents2[] = $value;
$getsexit2= $getsexall;
$gredate[] = $redate;
$gredate2[] = $redate7;
$gredate3[] = $redate9;
$gredate4[] = $redate11;
$gredate5[] = $redate13;
$gredate6[] = $redate15;
$gredate7[] = $redate17;
$gredate8[] = $redate19;
$gredate9[] = $redate21;
$gredate10[] = $redate23;
$gredate11[] = $redate25;
$gredate12[] = $redate27;
$gredate13[] = $redate29;
$gredate14[] = $redate31;
$gredatetotalmid[] = $redatetotalmid;
$gredatetotal[] = $redatetotal;
$striarray[] = $stri;
}

$ggetsexfemale = count($getsexfemale);
$ggetsexmale = count($getsexmale);

$grredate = ARRAY_SUM($gredate);
$grredate2 = ARRAY_SUM($gredate2);
$grredate3 = ARRAY_SUM($gredate3);
$grredate4 = ARRAY_SUM($gredate4);
$grredate5 = ARRAY_SUM($gredate5);
$grredate6 = ARRAY_SUM($gredate6);
$grredate7 = ARRAY_SUM($gredate7);
$grredate8 = ARRAY_SUM($gredate8);
$grredate9 = ARRAY_SUM($gredate9);
$grredate10 = ARRAY_SUM($gredate10);
$grredate11 = ARRAY_SUM($gredate11);
$grredate12 = ARRAY_SUM($gredate12);
$grredate13 = ARRAY_SUM($gredate13);
$grredate14 = ARRAY_SUM($gredate14);
$grredatetotalmid = ARRAY_SUM($gredatetotalmid);
$grredatetotal = ARRAY_SUM($gredatetotal);
$valuestudents = $valuestudents2;
$getsexit = $getsexit2;
$mmm = "male";
$fff = "female";
$ggetsexmale = 0;
$ggetsexfemale = 0;
for($hc=0; $hc<=(count($ss1)-1); $hc++){
	if(strtoupper($ss1[$hc])==strtoupper($mmm)){
	$ggetsexmale++;
	}else{
	$ggetsexfemale++;	
	}
}

echo '<tr>';
echo '<td style="text-align:center;">TOTAL</td>';
echo '<td style="text-align:center;"><span style="color: blue;">M: '.$ggetsexmale.' </span><br><span style="color: red;">F: '.$ggetsexfemale.'</span></td>';
echo '<td style="text-align:center;">-</td>';
echo '<td style="text-align:center;">'.$grredate.'</td>';
echo '<td style="text-align:center;">'.$grredate2.'</td>';
echo '<td style="text-align:center;">'.$grredate3.'</td>';
echo '<td style="text-align:center;">'.$grredate4.'</td>';
echo '<td style="text-align:center;">'.$grredate5.'</td>';
echo '<td style="text-align:center;">'.$grredate6.'</td>';
echo '<td style="text-align:center;">'.$grredate7.'</td>';
echo '<td style="text-align:center;">'.$grredate8.'</td>';
echo '<td style="text-align:center;">'.$grredate9.'</td>';
echo '<td style="text-align:center;">'.$grredate10.'</td>';
echo '<td style="text-align:center;">'.$grredate11.'</td>';
echo '<td style="text-align:center;">'.$grredate12.'</td>';
echo '<td style="text-align:center;">'.$grredate13.'</td>';
echo '<td style="text-align:center;">'.$grredate14.'</td>';
echo '<td style="text-align:center;">'.$grredatetotalmid.'</td>';
echo '<td style="text-align:center;">'.$grredatetotal.'</td>';
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;">PERCENT</td>';
echo '<td style="text-align:center; font-size: 12px;">M: '.round(($ggetsexmale*100)/$counted).'%<br>F: '.round(($ggetsexfemale*100)/$counted).'%</td>';
echo '<td style="text-align:center;">-</td>';
echo '<td style="text-align:center;"> '.$att1.' days '.round(($grredate*100)/($att1*($counted*2))).'%</td>';
echo '<td style="text-align:center;"> '.$att2.' days '.round(($grredate2*100)/($att2*($counted*2))).'%</td>';
echo '<td style="text-align:center;"> '.$att3.' days '.round(($grredate3*100)/($att3*($counted*2))).'%</td>';
echo '<td style="text-align:center;"> '.$att4.' days '.round(($grredate4*100)/($att4*($counted*2))).'%</td>';
echo '<td style="text-align:center;"> '.$att5.' days '.round(($grredate5*100)/($att5*($counted*2))).'%</td>';
echo '<td style="text-align:center;"> '.$att6.' days '.round(($grredate6*100)/($att6*($counted*2))).'%</td>';
echo '<td style="text-align:center;"> '.$att7.' days '.round(($grredate7*100)/($att7*($counted*2))).'%</td>';
echo '<td style="text-align:center;"> '.$att8.' days '.round(($grredate8*100)/($att8*($counted*2))).'%</td>';
echo '<td style="text-align:center;"> '.$att9.' days '.round(($grredate9*100)/($att9*($counted*2))).'%</td>';
echo '<td style="text-align:center;"> '.$att10.' days '.round(($grredate10*100)/($att10*($counted*2))).'%</td>';
echo '<td style="text-align:center;"> '.$att11.' days '.round(($grredate11*100)/($att11*($counted*2))).'%</td>';
echo '<td style="text-align:center;"> '.$att12.' days '.round(($grredate12*100)/($att12*($counted*2))).'%</td>';
echo '<td style="text-align:center;"> '.$att13.' days '.round(($grredate13*100)/($att13*($counted*2))).'%</td>';
echo '<td style="text-align:center;"> '.$att14.' days '.round(($grredate14*100)/($att14*($counted*2))).'%</td>';
echo '<td style="text-align:center;">'.$counted.' members in '.$atttotalalmid.' days is '.round(($grredatetotalmid * 100)/ ($atttotalalmid * 2 * $counted)).'%</td>';
echo '<td style="text-align:center;">'.$counted.' members in '.$atttotalal.' days is '.round(($grredatetotal * 100)/ ($atttotalal * 2 * $counted)).'%</td>';
echo '</tr>';

echo '<tr>';
echo '<td style="text-align:center;" colspan="3" >-</td>';
echo '<td style="text-align:center;">M A</td>';
echo '<td style="text-align:center;">M A</td>';
echo '<td style="text-align:center;">M A</td>';
echo '<td style="text-align:center;">M A</td>';
echo '<td style="text-align:center;">M A</td>';
echo '<td style="text-align:center;">M A</td>';
echo '<td style="text-align:center;">M A</td>';
echo '<td style="text-align:center;">M A</td>';
echo '<td style="text-align:center;">M A</td>';
echo '<td style="text-align:center;">M A</td>';
echo '<td style="text-align:center;">M A</td>';
echo '<td style="text-align:center;">M A</td>';
echo '<td style="text-align:center;">M A</td>';
echo '<td style="text-align:center;">M A</td>';
echo '<td style="text-align:center;" colspan="2" ></td>';
echo '</tr>';

echo '<tr>';
echo '<td style="text-align:center;" colspan="3" >MONDAY</td>';
echo '<td style="text-align:center;"><table><tr><td>'.$monmorn.'</td><td>'.$monaft.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$monmorn2.'</td><td>'.$monaft2.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$monmorn3.'</td><td>'.$monaft3.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$monmorn4.'</td><td>'.$monaft4.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$monmorn5.'</td><td>'.$monaft5.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$monmorn6.'</td><td>'.$monaft6.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$monmorn7.'</td><td>'.$monaft7.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$monmorn8.'</td><td>'.$monaft8.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$monmorn9.'</td><td>'.$monaft9.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$monmorn10.'</td><td>'.$monaft10.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$monmorn11.'</td><td>'.$monaft11.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$monmorn12.'</td><td>'.$monaft12.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$monmorn13.'</td><td>'.$monaft13.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$monmorn14.'</td><td>'.$monaft14.'</td></tr></table></td>';
echo '<td style="text-align:center;"></td>';
echo '<td style="text-align:center;"></td>';
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;" colspan="3" >TUESDAY</td>';
echo '<td style="text-align:center;"><table><tr><td>'.$tuemorn.'</td><td>'.$tueaft.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$tuemorn2.'</td><td>'.$tueaft2.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$tuemorn3.'</td><td>'.$tueaft3.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$tuemorn4.'</td><td>'.$tueaft4.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$tuemorn5.'</td><td>'.$tueaft5.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$tuemorn6.'</td><td>'.$tueaft6.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$tuemorn7.'</td><td>'.$tueaft7.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$tuemorn8.'</td><td>'.$tueaft8.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$tuemorn9.'</td><td>'.$tueaft9.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$tuemorn10.'</td><td>'.$tueaft10.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$tuemorn11.'</td><td>'.$tueaft11.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$tuemorn12.'</td><td>'.$tueaft12.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$tuemorn13.'</td><td>'.$tueaft13.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$tuemorn14.'</td><td>'.$tueaft14.'</td></tr></table></td>';
echo '<td style="text-align:center;"></td>';
echo '<td style="text-align:center;"></td>';
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;" colspan="3" >WEDNESDAY</td>';
echo '<td style="text-align:center;"><table><tr><td>'.$wedmorn.'</td><td>'.$wedaft.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$wedmorn2.'</td><td>'.$wedaft2.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$wedmorn3.'</td><td>'.$wedaft3.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$wedmorn4.'</td><td>'.$wedaft4.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$wedmorn5.'</td><td>'.$wedaft5.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$wedmorn6.'</td><td>'.$wedaft6.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$wedmorn7.'</td><td>'.$wedaft7.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$wedmorn8.'</td><td>'.$wedaft8.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$wedmorn9.'</td><td>'.$wedaft9.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$wedmorn10.'</td><td>'.$wedaft10.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$wedmorn11.'</td><td>'.$wedaft11.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$wedmorn12.'</td><td>'.$wedaft12.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$wedmorn13.'</td><td>'.$wedaft13.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$wedmorn14.'</td><td>'.$wedaft14.'</td></tr></table></td>';
echo '<td style="text-align:center;"></td>';
echo '<td style="text-align:center;"></td>';
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;" colspan="3" >THURSDAY</td>';
echo '<td style="text-align:center;"><table><tr><td>'.$thurmorn.'</td><td>'.$thuraft.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$thurmorn2.'</td><td>'.$thuraft2.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$thurmorn3.'</td><td>'.$thuraft3.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$thurmorn4.'</td><td>'.$thuraft4.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$thurmorn5.'</td><td>'.$thuraft5.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$thurmorn6.'</td><td>'.$thuraft6.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$thurmorn7.'</td><td>'.$thuraft7.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$thurmorn8.'</td><td>'.$thuraft8.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$thurmorn9.'</td><td>'.$thuraft9.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$thurmorn10.'</td><td>'.$thuraft10.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$thurmorn11.'</td><td>'.$thuraft11.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$thurmorn12.'</td><td>'.$thuraft12.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$thurmorn13.'</td><td>'.$thuraft13.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$thurmorn14.'</td><td>'.$thuraft14.'</td></tr></table></td>';
echo '<td style="text-align:center;"></td>';
echo '<td style="text-align:center;"></td>';
echo '</tr>';
echo '<tr>';
echo '<td style="text-align:center;" colspan="3" >FRIDAY</td>';
echo '<td style="text-align:center;"><table><tr><td>'.$frimorn.'</td><td>'.$friaft.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$frimorn2.'</td><td>'.$friaft2.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$frimorn3.'</td><td>'.$friaft3.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$frimorn4.'</td><td>'.$friaft4.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$frimorn5.'</td><td>'.$friaft5.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$frimorn6.'</td><td>'.$friaft6.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$frimorn7.'</td><td>'.$friaft7.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$frimorn8.'</td><td>'.$friaft8.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$frimorn9.'</td><td>'.$friaft9.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$frimorn10.'</td><td>'.$friaft10.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$frimorn11.'</td><td>'.$friaft11.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$frimorn12.'</td><td>'.$friaft12.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$frimorn13.'</td><td>'.$friaft13.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$frimorn14.'</td><td>'.$friaft14.'</td></tr></table></td>';
echo '<td style="text-align:center;"></td>';
echo '<td style="text-align:center;"></td>';
echo '</tr>';

$wemorn1 = $monmorn+$tuemorn+$wedmorn+$thurmorn+$frimorn;
$weaft1 = $monaft+$tueaft+$wedaft+$thuraft+$friaft;
$wemorn2 = $monmorn2+$tuemorn2+$wedmorn2+$thurmorn2+$frimorn2;
$weaft2 = $monaft2+$tueaft2+$wedaft2+$thuraft2+$friaft2; 
$wemorn3 = $monmorn3+$tuemorn3+$wedmorn3+$thurmorn3+$frimorn3;
$weaft3 = $monaft3+$tueaft3+$wedaft3+$thuraft3+$friaft3; 
$wemorn4 = $monmorn4+$tuemorn4+$wedmorn4+$thurmorn4+$frimorn4;
$weaft4 = $monaft4+$tueaft4+$wedaft4+$thuraft4+$friaft4; 
$wemorn5 = $monmorn5+$tuemorn5+$wedmorn5+$thurmorn5+$frimorn5;
$weaft5 = $monaft5+$tueaft5+$wedaft5+$thuraft5+$friaft5; 
$wemorn6 = $monmorn6+$tuemorn6+$wedmorn6+$thurmorn6+$frimorn6;
$weaft6 = $monaft6+$tueaft6+$wedaft6+$thuraft6+$friaft6;
$wemorn7 = $monmorn7+$tuemorn7+$wedmorn7+$thurmorn7+$frimorn7;
$weaft7 = $monaft7+$tueaft7+$wedaft7+$thuraft7+$friaft7;  
$wemorn8 = $monmorn8+$tuemorn8+$wedmorn8+$thurmorn8+$frimorn8;
$weaft8 = $monaft8+$tueaft8+$wedaft8+$thuraft8+$friaft8; 
$wemorn9 = $monmorn9+$tuemorn9+$wedmorn9+$thurmorn9+$frimorn9;
$weaft9 = $monaft9+$tueaft9+$wedaft9+$thuraft9+$friaft9; 
$wemorn10 = $monmorn10+$tuemorn10+$wedmorn10+$thurmorn10+$frimorn10;
$weaft10 = $monaft10+$tueaft10+$wedaft10+$thuraft10+$friaft10; 
$wemorn11 = $monmorn11+$tuemorn11+$wedmorn11+$thurmorn11+$frimorn11;
$weaft11 = $monaft11+$tueaft11+$wedaft11+$thuraft11+$friaft11;
$wemorn12 = $monmorn12+$tuemorn12+$wedmorn12+$thurmorn12+$frimorn12;
$weaft12 = $monaft12+$tueaft12+$wedaft12+$thuraft12+$friaft12; 
$wemorn13 = $monmorn13+$tuemorn13+$wedmorn13+$thurmorn13+$frimorn13;
$weaft13 = $monaft13+$tueaft13+$wedaft13+$thuraft13+$friaft13;
$wemorn14 = $monmorn14+$tuemorn14+$wedmorn14+$thurmorn14+$frimorn14;
$weaft14 = $monaft14+$tueaft14+$wedaft14+$thuraft14+$friaft14; 
echo '<tr style="color: red;">';
echo '<td style="text-align:center;" colspan="3" >WEEKLY TOTALS</td>';
echo '<td style="text-align:center;"><table><tr><td>'.$wemorn1.'</td><td>'.$weaft1.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$wemorn2.'</td><td>'.$weaft2.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$wemorn3.'</td><td>'.$weaft3.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$wemorn4.'</td><td>'.$weaft4.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$wemorn5.'</td><td>'.$weaft5.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$wemorn6.'</td><td>'.$weaft6.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$wemorn7.'</td><td>'.$weaft7.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$wemorn8.'</td><td>'.$weaft8.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$wemorn9.'</td><td>'.$weaft9.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$wemorn10.'</td><td>'.$weaft10.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$wemorn11.'</td><td>'.$weaft11.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$wemorn12.'</td><td>'.$weaft12.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$wemorn13.'</td><td>'.$weaft13.'</td></tr></table></td>';
echo '<td style="text-align:center;"><table><tr><td>'.$wemorn14.'</td><td>'.$weaft14.'</td></tr></table></td>';
echo '<td style="text-align:center;"></td>';
echo '<td style="text-align:center;"></td>';
echo '</tr>';

echo '<tr>';
echo '<td style="text-align:center;" colspan="3" >TOTALS BY GENDER</td>';
echo '<td style="text-align:center; font-size: 12px;"><table><tr><td>M</td><td>F</td></tr><tr><td style="text-align:center;">'.$wkmale11.'</td><td style="text-align:center; font-size: 12px;">'.$wkfemale11.'</td></tr></table></td>';
echo '<td style="text-align:center; font-size: 12px;"><table><tr><td>M</td><td>F</td></tr><tr><td style="text-align:center;">'.$wkmale22.'</td><td style="text-align:center; font-size: 12px;">'.$wkfemale22.'</td></tr></table></td>';
echo '<td style="text-align:center; font-size: 12px;"><table><tr><td>M</td><td>F</td></tr><tr><td style="text-align:center;">'.$wkmale33.'</td><td style="text-align:center;">'.$wkfemale33.'</td></tr></table></td>';
echo '<td style="text-align:center; font-size: 12px;"><table><tr><td>M</td><td>F</td></tr><tr><td style="text-align:center;">'.$wkmale44.'</td><td style="text-align:center;">'.$wkfemale44.'</td></tr></table></td>';
echo '<td style="text-align:center; font-size: 12px;"><table><tr><td>M</td><td>F</td></tr><tr><td style="text-align:center;">'.$wkmale55.'</td><td style="text-align:center;">'.$wkfemale55.'</td></tr></table></td>';
echo '<td style="text-align:center; font-size: 12px;"><table><tr><td>M</td><td>F</td></tr><tr><td style="text-align:center;">'.$wkmale66.'</td><td style="text-align:center;">'.$wkfemale66.'</td></tr></table></td>';
echo '<td style="text-align:center; font-size: 12px;"><table><tr><td>M</td><td>F</td></tr><tr><td style="text-align:center;">'.$wkmale77.'</td><td style="text-align:center;">'.$wkfemale77.'</td></tr></table></td>';
echo '<td style="text-align:center; font-size: 12px;"><table><tr><td>M</td><td>F</td></tr><tr><td style="text-align:center;">'.$wkmale88.'</td><td style="text-align:center;">'.$wkfemale88.'</td></tr></table></td>';
echo '<td style="text-align:center; font-size: 12px;"><table><tr><td>M</td><td>F</td></tr><tr><td style="text-align:center;">'.$wkmale99.'</td><td style="text-align:center;">'.$wkfemale99.'</td></tr></table></td>';
echo '<td style="text-align:center; font-size: 12px;"><table><tr><td>M</td><td>F</td></tr><tr><td style="text-align:center;">'.$wkmale1010.'</td><td style="text-align:center;">'.$wkfemale1010.'</td></tr></table></td>';
echo '<td style="text-align:center; font-size: 12px;"><table><tr><td>M</td><td>F</td></tr><tr><td style="text-align:center;">'.$wkmale1111.'</td><td style="text-align:center;">'.$wkfemale1111.'</td></tr></table></td>';
echo '<td style="text-align:center; font-size: 12px;"><table><tr><td>M</td><td>F</td></tr><tr><td style="text-align:center;">'.$wkmale1212.'</td><td style="text-align:center;">'.$wkfemale1212.'</td></tr></table></td>';
echo '<td style="text-align:center; font-size: 12px;"><table><tr><td>M</td><td>F</td></tr><tr><td style="text-align:center;">'.$wkmale1313.'</td><td style="text-align:center;">'.$wkfemale1313.'</td></tr></table></td>';
echo '<td style="text-align:center; font-size: 12px;"><table><tr><td>M</td><td>F</td></tr><tr><td style="text-align:center;">'.$wkmale1414.'</td><td style="text-align:center;">'.$wkfemale1414.'</td></tr></table></td>';
echo '<td style="text-align:center; font-size: 12px;">-</td>';
$wkmaletotal = $wkmale11+$wkmale22+$wkmale33+$wkmale44+$wkmale55+$wkmale66+$wkmale77+$wkmale88+$wkmale99+$wkmale1010+$wkmale1111+$wkmale1212+$wkmale1313+$wkmale1414;
$wkfemaletotal = $wkfemale11+$wkfemale22+$wkfemale33+$wkfemale44+$wkfemale55+$wkfemale66+$wkfemale77+$wkfemale88+$wkfemale99+$wkfemale1010+$wkfemale1111+$wkfemale1212+$wkfemale1313+$wkfemale1414;
echo '<td style="text-align:center; font-size: 12px;"><table><tr><td style="text-align:center;">M</td><td style="text-align:center;">F</td></tr><tr><td style="text-align:center;">'.$wkmaletotal.'</td><td style="text-align:center; font-size: 12px;">'.$wkfemaletotal.'</td></tr></table></td>';
echo '</tr>';

echo '</table>';
echo '</center>';
?>
<center>
<div id="loadit"></div>	
<div id="afterthis"><ul id="resultlist" style="list-style-type: none;" ></ul></div>
</center>
<form action="upatt.php" method="POST">
<input style="display: none;" type="text" name="class" value="<?php echo $class; ?>" />
<input style="display: none;" type="text" name="arms" value="<?php echo $arms; ?>" />
<input style="display: none;" type="text" name="year" value="<?php echo $year; ?>" />
<input style="display: none;" type="text" name="term" value="<?php echo $term; ?>" />
<input class="myButton" type="submit" name="submit" value="Back" />
</form>


<form action="chart.js1.php" method="POST">
<input type="text" style="display: none;" name="grredatetotal" value="<?php echo $atttotalal; ?>" />
<?php
$i = 0;
foreach($w2 as $ww2)
{
  echo '<input  style="display: none;" name="nam[]" value="'. $ww2. '">';
  echo '<input style="display: none;"  type="text" name="grredate[]" value="'.$gredatetotal[$i].'">';
  $i++;
}
?>
<input style="display: none;" type="text" name="formt" value="<?php echo $formt; ?>" />
<input style="display: none;" type="text" name="class" value="<?php echo $class; ?>" />
<input style="display: none;" type="text" name="arms" value="<?php echo $arms; ?>" />
<input style="display: none;" type="text" name="year" value="<?php echo $year; ?>" />
<input style="display: none;" type="text" name="term" value="<?php echo $term; ?>" />
<input style="display: none;" type="text" name="formt" value="<?php echo $formt; ?>" />
<input style="display: none;" type="text" name="wkmale11" value="<?php echo $wkmale11; ?>" />
<input style="display: none;" type="text" name="wkmale22" value="<?php echo $wkmale22; ?>" />
<input style="display: none;" type="text" name="wkmale33" value="<?php echo $wkmale33; ?>" />
<input style="display: none;" type="text" name="wkmale44" value="<?php echo $wkmale44; ?>" />
<input style="display: none;" type="text" name="wkmale55" value="<?php echo $wkmale55; ?>" />
<input style="display: none;" type="text" name="wkmale66" value="<?php echo $wkmale66; ?>" />
<input style="display: none;" type="text" name="wkmale77" value="<?php echo $wkmale77; ?>" />
<input style="display: none;" type="text" name="wkmale88" value="<?php echo $wkmale88; ?>" />
<input style="display: none;" type="text" name="wkmale99" value="<?php echo $wkmale99; ?>" />
<input style="display: none;" type="text" name="wkmale1010" value="<?php echo $wkmale1010; ?>" />
<input style="display: none;" type="text" name="wkmale1111" value="<?php echo $wkmale1111; ?>" />
<input style="display: none;" type="text" name="wkmale1212" value="<?php echo $wkmale1212; ?>" />
<input style="display: none;" type="text" name="wkmale1313" value="<?php echo $wkmale99; ?>" />
<input style="display: none;" type="text" name="wkmale1414" value="<?php echo $wkmale1414; ?>" />
<input style="display: none;" type="text" name="wkmaletotal" value="<?php echo $wkmaletotal; ?>" />
<input style="display: none;" type="text" name="wkfemale11" value="<?php echo $wkfemale11; ?>" />
<input style="display: none;" type="text" name="wkfemale22" value="<?php echo $wkfemale22; ?>" />
<input style="display: none;" type="text" name="wkfemale33" value="<?php echo $wkfemale33; ?>" />
<input style="display: none;" type="text" name="wkfemale44" value="<?php echo $wkfemale44; ?>" />
<input style="display: none;" type="text" name="wkfemale55" value="<?php echo $wkfemale55; ?>" />
<input style="display: none;" type="text" name="wkfemale66" value="<?php echo $wkfemale66; ?>" />
<input style="display: none;" type="text" name="wkfemale77" value="<?php echo $wkfemale77; ?>" />
<input style="display: none;" type="text" name="wkfemale88" value="<?php echo $wkfemale88; ?>" />
<input style="display: none;" type="text" name="wkfemale99" value="<?php echo $wkfemale99; ?>" />
<input style="display: none;" type="text" name="wkfemale1010" value="<?php echo $wkfemale1010; ?>" />
<input style="display: none;" type="text" name="wkfemale1111" value="<?php echo $wkfemale1111; ?>" />
<input style="display: none;" type="text" name="wkfemale1212" value="<?php echo $wkfemale1212; ?>" />
<input style="display: none;" type="text" name="wkfemale1313" value="<?php echo $wkfemale1313; ?>" />
<input style="display: none;" type="text" name="wkfemale1414" value="<?php echo $wkfemale1414; ?>" />
<input style="display: none;" type="text" name="wkfemaletotal" value="<?php echo $wkfemaletotal; ?>" />
<input style="display: none;" type="text" name="chmida" value="<?php echo $chmida; ?>" />
<input style="display: none;" type="text" name="chmidb" value="<?php echo $chmidb; ?>" />
<input style="display: none;" type="text" name="chmidc" value="<?php echo $chmidc; ?>" />
<input style="display: none;" type="text" name="chmidd" value="<?php echo $chmidd; ?>" />
<input style="display: none;" type="text" name="chmide" value="<?php echo $chmide; ?>" />
<input style="display: none;" type="text" name="chmidf" value="<?php echo $chmidf; ?>" />
<input style="display: none;" type="text" name="chmidg" value="<?php echo $chmidg; ?>" />
<input style="display: none;" type="text" name="chmidh" value="<?php echo $chmidh; ?>" />
<input style="display: none;" type="text" name="chmidi" value="<?php echo $chmidi; ?>" />
<input style="display: none;" type="text" name="chmidj" value="<?php echo $chmidj; ?>" />
<input style="display: none;" type="text" name="chmidk" value="<?php echo $chmidk; ?>" />
<input style="display: none;" type="text" name="chmidl" value="<?php echo $chmidl; ?>" />
<input style="display: none;" type="text" name="chmidm" value="<?php echo $chmidm; ?>" />
<input style="display: none;" type="text" name="chmidn" value="<?php echo $chmidn; ?>" />
<input  style="display: none;" type="text" name="termbegin" value="<?php echo $termbegin; ?>" />
<?php
foreach($valuestudents as $valuestudent)
{
  echo '<input  type="text" style="display: none;" name="student_name[]" value="'.$valuestudent.'">';
}
foreach($getsexit as $sex)
{
  echo '<input  type="text" style="display: none;" name="sex[]" value="'.$sex.'">';
}
foreach($gredate as $redateit)
{
  echo '<input  type="text" style="display: none;" name="redateit[]" value="'.$redateit.'">';
}
foreach($gredate2 as $redateit2)
{
  echo '<input  type="text" style="display: none;" name="redateit2[]" value="'.$redateit2.'">';
}
foreach($gredate3 as $redateit3)
{
  echo '<input  type="text" style="display: none;" name="redateit3[]" value="'.$redateit3.'">';
}
foreach($gredate4 as $redateit4)
{
  echo '<input  type="text" style="display: none;" name="redateit4[]" value="'.$redateit4.'">';
}
foreach($gredate5 as $redateit5)
{
  echo '<input  type="text" style="display: none;" name="redateit5[]" value="'.$redateit5.'">';
}
foreach($gredate5 as $redateit6)
{
  echo '<input  type="text" style="display: none;" name="redateit6[]" value="'.$redateit6.'">';
}
foreach($gredate7 as $redateit7)
{
  echo '<input  type="text" style="display: none;" name="redateit7[]" value="'.$redateit7.'">';
}
foreach($gredate8 as $redateit8)
{
  echo '<input  type="text" style="display: none;" name="redateit8[]" value="'.$redateit8.'">';
}
foreach($gredate9 as $redateit9)
{
  echo '<input  type="text" style="display: none;" name="redateit9[]" value="'.$redateit9.'">';
}
foreach($gredate10 as $redateit10)
{
  echo '<input  type="text" style="display: none;" name="redateit10[]" value="'.$redateit10.'">';
}
foreach($gredate11 as $redateit11)
{
  echo '<input  type="text" style="display: none;" name="redateit11[]" value="'.$redateit11.'">';
}
foreach($gredate12 as $redateit12)
{
  echo '<input  type="text" style="display: none;" name="redateit12[]" value="'.$redateit12.'">';
}
foreach($gredate13 as $redateit13)
{
  echo '<input  type="text" style="display: none;" name="redateit13[]" value="'.$redateit13.'">';
}
foreach($gredate14 as $redateit14)
{
  echo '<input  type="text" style="display: none;" name="redateit14[]" value="'.$redateit14.'">';
}
foreach($gredatetotalmid as $stmid)
{
  echo '<input  style="display: none;" type="text" name="stmid[]" value="'.$stmid.'">';
}
foreach($gredatetotal as $sttotal)
{
  echo '<input  style="display: none;" type="text" name="sttotal[]" value="'.$sttotal.'">';
}
echo '<input   style="display: none;" type="text" name="att1" value="'.$att1.'">';
echo '<input   style="display: none;" type="text" name="att2" value="'.$att2.'">';
echo '<input   style="display: none;" type="text" name="att3" value="'.$att3.'">';
echo '<input   style="display: none;" type="text" name="att4" value="'.$att4.'">';
echo '<input   style="display: none;" type="text" name="att5" value="'.$att5.'">';
echo '<input   style="display: none;" type="text" name="att6" value="'.$att6.'">';
echo '<input   style="display: none;" type="text" name="att7" value="'.$att7.'">';
echo '<input   style="display: none;" type="text" name="att8" value="'.$att8.'">';
echo '<input   style="display: none;" type="text" name="att9" value="'.$att9.'">';
echo '<input   style="display: none;" type="text" name="att10" value="'.$att10.'">';
echo '<input   style="display: none;" type="text" name="att11" value="'.$att11.'">';
echo '<input   style="display: none;" type="text" name="att12" value="'.$att12.'">';
echo '<input   style="display: none;" type="text" name="att13" value="'.$att13.'">';
echo '<input   style="display: none;" type="text" name="att14" value="'.$att14.'">';

?>
<input class="myButton" type="submit" name="submit" value="View Chart" />
</form>



<?php
echo '<form id="genattpdf">';
foreach($striarray as $striarray2)
{
  echo '<input  style="display: none;" type="text" name="absents[]" value="'.$striarray2.'">';
}
foreach($valuestudents as $valuestudent)
{
  echo '<input  type="text" style="display: none;" name="student_name[]" value="'.$valuestudent.'">';
}
foreach($getsexit as $sex)
{
  echo '<input  type="text" style="display: none;" name="sex[]" value="'.$sex.'">';
}
foreach($gredate as $redateit)
{
  echo '<input  type="text" style="display: none;" name="redateit[]" value="'.$redateit.'">';
}
foreach($gredate2 as $redateit2)
{
  echo '<input  type="text" style="display: none;" name="redateit2[]" value="'.$redateit2.'">';
}
foreach($gredate3 as $redateit3)
{
  echo '<input  type="text" style="display: none;" name="redateit3[]" value="'.$redateit3.'">';
}
foreach($gredate4 as $redateit4)
{
  echo '<input  type="text" style="display: none;" name="redateit4[]" value="'.$redateit4.'">';
}
foreach($gredate5 as $redateit5)
{
  echo '<input  type="text" style="display: none;" name="redateit5[]" value="'.$redateit5.'">';
}
foreach($gredate5 as $redateit6)
{
  echo '<input  type="text" style="display: none;" name="redateit6[]" value="'.$redateit6.'">';
}
foreach($gredate7 as $redateit7)
{
  echo '<input  type="text" style="display: none;" name="redateit7[]" value="'.$redateit7.'">';
}
foreach($gredate8 as $redateit8)
{
  echo '<input  type="text" style="display: none;" name="redateit8[]" value="'.$redateit8.'">';
}
foreach($gredate9 as $redateit9)
{
  echo '<input  type="text" style="display: none;" name="redateit9[]" value="'.$redateit9.'">';
}
foreach($gredate10 as $redateit10)
{
  echo '<input  type="text" style="display: none;" name="redateit10[]" value="'.$redateit10.'">';
}
foreach($gredate11 as $redateit11)
{
  echo '<input  type="text" style="display: none;" name="redateit11[]" value="'.$redateit11.'">';
}
foreach($gredate12 as $redateit12)
{
  echo '<input  type="text" style="display: none;" name="redateit12[]" value="'.$redateit12.'">';
}
foreach($gredate13 as $redateit13)
{
  echo '<input  type="text" style="display: none;" name="redateit13[]" value="'.$redateit13.'">';
}
foreach($gredate14 as $redateit14)
{
  echo '<input  type="text" style="display: none;" name="redateit14[]" value="'.$redateit14.'">';
}
foreach($gredatetotalmid as $stmid)
{
  echo '<input  style="display: none;" type="text" name="stmid[]" value="'.$stmid.'">';
}
foreach($gredatetotal as $sttotal)
{
  echo '<input  style="display: none;" type="text" name="sttotal[]" value="'.$sttotal.'">';
}
echo '<input   style="display: none;" type="text" name="termbegin" value="'.$termbegin.'">';
echo '<input   style="display: none;" type="text" name="ftotal" value="'.$ggetsexfemale.'">';
echo '<input   style="display: none;" type="text" name="mtotal" value="'.$ggetsexmale.'">';
echo '<input   style="display: none;" type="text" name="grredate" value="'.$grredate.'">';
echo '<input   style="display: none;" type="text" name="grredate2" value="'.$grredate2.'">';
echo '<input   style="display: none;" type="text" name="grredate3" value="'.$grredate3.'">';
echo '<input   style="display: none;" type="text" name="grredate4" value="'.$grredate4.'">';
echo '<input   style="display: none;" type="text" name="grredate5" value="'.$grredate5.'">';
echo '<input   style="display: none;" type="text" name="grredate6" value="'.$grredate6.'">';
echo '<input   style="display: none;" type="text" name="grredate7" value="'.$grredate7.'">';
echo '<input   style="display: none;" type="text" name="grredate8" value="'.$grredate8.'">';
echo '<input   style="display: none;" type="text" name="grredate9" value="'.$grredate9.'">';
echo '<input   style="display: none;" type="text" name="grredate10" value="'.$grredate10.'">';
echo '<input   style="display: none;" type="text" name="grredate11" value="'.$grredate11.'">';
echo '<input   style="display: none;" type="text" name="grredate12" value="'.$grredate12.'">';
echo '<input   style="display: none;" type="text" name="grredate13" value="'.$grredate13.'">';
echo '<input   style="display: none;" type="text" name="grredate14" value="'.$grredate14.'">';
echo '<input   style="display: none;" type="text" name="grredatetotalmid" value="'.$grredatetotalmid.'">';
echo '<input   style="display: none;" type="text" name="grredatetotal" value="'.$grredatetotal.'">';
echo '<input   style="display: none;" type="text" name="counted" value="'.$counted.'">';
echo '<input   style="display: none;" type="text" name="att1" value="'.$att1.'">';
echo '<input   style="display: none;" type="text" name="att2" value="'.$att2.'">';
echo '<input   style="display: none;" type="text" name="att3" value="'.$att3.'">';
echo '<input   style="display: none;" type="text" name="att4" value="'.$att4.'">';
echo '<input   style="display: none;" type="text" name="att5" value="'.$att5.'">';
echo '<input   style="display: none;" type="text" name="att6" value="'.$att6.'">';
echo '<input   style="display: none;" type="text" name="att7" value="'.$att7.'">';
echo '<input   style="display: none;" type="text" name="att8" value="'.$att8.'">';
echo '<input   style="display: none;" type="text" name="att9" value="'.$att9.'">';
echo '<input   style="display: none;" type="text" name="att10" value="'.$att10.'">';
echo '<input   style="display: none;" type="text" name="att11" value="'.$att11.'">';
echo '<input   style="display: none;" type="text" name="att12" value="'.$att12.'">';
echo '<input   style="display: none;" type="text" name="att13" value="'.$att13.'">';
echo '<input   style="display: none;" type="text" name="att14" value="'.$att14.'">';
echo '<input   style="display: none;" type="text" name="redatetotalmid" value="'.$redatetotalmid.'">';
echo '<input   style="display: none;" type="text" name="atttotalalmid" value="'.$atttotalalmid.'">';
echo '<input   style="display: none;" type="text" name="atttotalal" value="'.$atttotalal.'">';
echo '<input   style="display: none;" type="text" name="atttotalallmid" value="'.$atttotalallmid.'">';
echo '<input   style="display: none;" type="text" name="atttotalall" value="'.$atttotalall.'">';
echo '<input   style="display: none;" type="text" name="monmorn" value="'.$monmorn.'">';
echo '<input   style="display: none;" type="text" name="monaft" value="'.$monaft.'">';
echo '<input   style="display: none;" type="text" name="monmorn2" value="'.$monmorn2.'">';
echo '<input   style="display: none;" type="text" name="monaft2" value="'.$monaft2.'">';
echo '<input   style="display: none;" type="text" name="monmorn3" value="'.$monmorn3.'">';
echo '<input   style="display: none;" type="text" name="monaft3" value="'.$monaft3.'">';
echo '<input   style="display: none;" type="text" name="monmorn4" value="'.$monmorn4.'">';
echo '<input   style="display: none;" type="text" name="monaft4" value="'.$monaft4.'">';
echo '<input   style="display: none;" type="text" name="monmorn5" value="'.$monmorn5.'">';
echo '<input   style="display: none;" type="text" name="monaft5" value="'.$monaft5.'">';
echo '<input   style="display: none;" type="text" name="monmorn6" value="'.$monmorn6.'">';
echo '<input   style="display: none;" type="text" name="monaft6" value="'.$monaft6.'">';
echo '<input   style="display: none;" type="text" name="monmorn7" value="'.$monmorn7.'">';
echo '<input   style="display: none;" type="text" name="monaft7" value="'.$monaft7.'">';
echo '<input   style="display: none;" type="text" name="monmorn8" value="'.$monmorn8.'">';
echo '<input   style="display: none;" type="text" name="monaft8" value="'.$monaft8.'">';
echo '<input   style="display: none;" type="text" name="monmorn9" value="'.$monmorn9.'">';
echo '<input   style="display: none;" type="text" name="monaft9" value="'.$monaft9.'">';
echo '<input   style="display: none;" type="text" name="monmorn10" value="'.$monmorn10.'">';
echo '<input   style="display: none;" type="text" name="monaft10" value="'.$monaft10.'">';
echo '<input   style="display: none;" type="text" name="monmorn11" value="'.$monmorn11.'">';
echo '<input   style="display: none;" type="text" name="monaft11" value="'.$monaft11.'">';
echo '<input   style="display: none;" type="text" name="monmorn12" value="'.$monmorn12.'">';
echo '<input   style="display: none;" type="text" name="monaft12" value="'.$monaft12.'">';
echo '<input   style="display: none;" type="text" name="monmorn13" value="'.$monmorn13.'">';
echo '<input   style="display: none;" type="text" name="monaft13" value="'.$monaft13.'">';
echo '<input   style="display: none;" type="text" name="monmorn14" value="'.$monmorn14.'">';
echo '<input   style="display: none;" type="text" name="monaft14" value="'.$monaft14.'">';
echo '<input   style="display: none;" type="text" name="tuemorn" value="'.$tuemorn.'">';
echo '<input   style="display: none;" type="text" name="tueaft" value="'.$tueaft.'">';
echo '<input   style="display: none;" type="text" name="tuemorn2" value="'.$tuemorn2.'">';
echo '<input   style="display: none;" type="text" name="tueaft2" value="'.$tueaft2.'">';
echo '<input   style="display: none;" type="text" name="tuemorn3" value="'.$tuemorn3.'">';
echo '<input   style="display: none;" type="text" name="tueaft3" value="'.$tueaft3.'">';
echo '<input   style="display: none;" type="text" name="tuemorn4" value="'.$tuemorn4.'">';
echo '<input   style="display: none;" type="text" name="tueaft4" value="'.$tueaft4.'">';
echo '<input   style="display: none;" type="text" name="tuemorn5" value="'.$tuemorn5.'">';
echo '<input   style="display: none;" type="text" name="tueaft5" value="'.$tueaft5.'">';
echo '<input   style="display: none;" type="text" name="tuemorn6" value="'.$tuemorn6.'">';
echo '<input   style="display: none;" type="text" name="tueaft6" value="'.$tueaft6.'">';
echo '<input   style="display: none;" type="text" name="tuemorn7" value="'.$tuemorn7.'">';
echo '<input   style="display: none;" type="text" name="tueaft7" value="'.$tueaft7.'">';
echo '<input   style="display: none;" type="text" name="tuemorn8" value="'.$tuemorn8.'">';
echo '<input   style="display: none;" type="text" name="tueaft8" value="'.$tueaft8.'">';
echo '<input   style="display: none;" type="text" name="tuemorn9" value="'.$tuemorn9.'">';
echo '<input   style="display: none;" type="text" name="tueaft9" value="'.$tueaft9.'">';
echo '<input   style="display: none;" type="text" name="tuemorn10" value="'.$tuemorn10.'">';
echo '<input   style="display: none;" type="text" name="tueaft10" value="'.$tueaft10.'">';
echo '<input   style="display: none;" type="text" name="tuemorn11" value="'.$tuemorn11.'">';
echo '<input   style="display: none;" type="text" name="tueaft11" value="'.$tueaft11.'">';
echo '<input   style="display: none;" type="text" name="tuemorn12" value="'.$tuemorn12.'">';
echo '<input   style="display: none;" type="text" name="tueaft12" value="'.$tueaft12.'">';
echo '<input   style="display: none;" type="text" name="tuemorn13" value="'.$tuemorn13.'">';
echo '<input   style="display: none;" type="text" name="tueaft13" value="'.$tueaft13.'">';
echo '<input   style="display: none;" type="text" name="tuemorn14" value="'.$tuemorn14.'">';
echo '<input   style="display: none;" type="text" name="tueaft14" value="'.$tueaft14.'">';
echo '<input   style="display: none;" type="text" name="wedmorn" value="'.$wedmorn.'">';
echo '<input   style="display: none;" type="text" name="wedaft" value="'.$wedaft.'">';
echo '<input   style="display: none;" type="text" name="wedmorn2" value="'.$wedmorn2.'">';
echo '<input   style="display: none;" type="text" name="wedaft2" value="'.$wedaft2.'">';
echo '<input   style="display: none;" type="text" name="wedmorn3" value="'.$wedmorn3.'">';
echo '<input   style="display: none;" type="text" name="wedaft3" value="'.$wedaft3.'">';
echo '<input   style="display: none;" type="text" name="wedmorn4" value="'.$wedmorn4.'">';
echo '<input   style="display: none;" type="text" name="wedaft4" value="'.$wedaft4.'">';
echo '<input   style="display: none;" type="text" name="wedmorn5" value="'.$wedmorn5.'">';
echo '<input   style="display: none;" type="text" name="wedaft5" value="'.$wedaft5.'">';
echo '<input   style="display: none;" type="text" name="wedmorn6" value="'.$wedmorn6.'">';
echo '<input   style="display: none;" type="text" name="wedaft6" value="'.$wedaft6.'">';
echo '<input   style="display: none;" type="text" name="wedmorn7" value="'.$wedmorn7.'">';
echo '<input   style="display: none;" type="text" name="wedaft7" value="'.$wedaft7.'">';
echo '<input   style="display: none;" type="text" name="wedmorn8" value="'.$wedmorn8.'">';
echo '<input   style="display: none;" type="text" name="wedaft8" value="'.$wedaft8.'">';
echo '<input   style="display: none;" type="text" name="wedmorn9" value="'.$wedmorn9.'">';
echo '<input   style="display: none;" type="text" name="wedaft9" value="'.$wedaft9.'">';
echo '<input   style="display: none;" type="text" name="wedmorn10" value="'.$wedmorn10.'">';
echo '<input   style="display: none;" type="text" name="wedaft10" value="'.$wedaft10.'">';
echo '<input   style="display: none;" type="text" name="wedmorn11" value="'.$wedmorn11.'">';
echo '<input   style="display: none;" type="text" name="wedaft11" value="'.$wedaft11.'">';
echo '<input   style="display: none;" type="text" name="wedmorn12" value="'.$wedmorn12.'">';
echo '<input   style="display: none;" type="text" name="wedaft12" value="'.$wedaft12.'">';
echo '<input   style="display: none;" type="text" name="wedmorn13" value="'.$wedmorn13.'">';
echo '<input   style="display: none;" type="text" name="wedaft13" value="'.$wedaft13.'">';
echo '<input   style="display: none;" type="text" name="wedmorn14" value="'.$wedmorn14.'">';
echo '<input   style="display: none;" type="text" name="wedaft14" value="'.$wedaft14.'">';
echo '<input   style="display: none;" type="text" name="thurmorn" value="'.$thurmorn.'">';
echo '<input   style="display: none;" type="text" name="thuraft" value="'.$thuraft.'">';
echo '<input   style="display: none;" type="text" name="thurmorn2" value="'.$thurmorn2.'">';
echo '<input   style="display: none;" type="text" name="thuraft2" value="'.$thuraft2.'">';
echo '<input   style="display: none;" type="text" name="thurmorn3" value="'.$thurmorn3.'">';
echo '<input   style="display: none;" type="text" name="thuraft3" value="'.$thuraft3.'">';
echo '<input   style="display: none;" type="text" name="thurmorn4" value="'.$thurmorn4.'">';
echo '<input   style="display: none;" type="text" name="thuraft4" value="'.$thuraft4.'">';
echo '<input   style="display: none;" type="text" name="thurmorn5" value="'.$thurmorn5.'">';
echo '<input   style="display: none;" type="text" name="thuraft5" value="'.$thuraft5.'">';
echo '<input   style="display: none;" type="text" name="thurmorn6" value="'.$thurmorn6.'">';
echo '<input   style="display: none;" type="text" name="thuraft6" value="'.$thuraft6.'">';
echo '<input   style="display: none;" type="text" name="thurmorn7" value="'.$thurmorn7.'">';
echo '<input   style="display: none;" type="text" name="thuraft7" value="'.$thuraft7.'">';
echo '<input   style="display: none;" type="text" name="thurmorn8" value="'.$thurmorn8.'">';
echo '<input   style="display: none;" type="text" name="thuraft8" value="'.$thuraft8.'">';
echo '<input   style="display: none;" type="text" name="thurmorn9" value="'.$thurmorn9.'">';
echo '<input   style="display: none;" type="text" name="thuraft9" value="'.$thuraft9.'">';
echo '<input   style="display: none;" type="text" name="thurmorn10" value="'.$thurmorn10.'">';
echo '<input   style="display: none;" type="text" name="thuraft10" value="'.$thuraft10.'">';
echo '<input   style="display: none;" type="text" name="thurmorn11" value="'.$thurmorn11.'">';
echo '<input   style="display: none;" type="text" name="thuraft11" value="'.$thuraft11.'">';
echo '<input   style="display: none;" type="text" name="thurmorn12" value="'.$thurmorn12.'">';
echo '<input   style="display: none;" type="text" name="thuraft12" value="'.$thuraft12.'">';
echo '<input   style="display: none;" type="text" name="thurmorn13" value="'.$thurmorn13.'">';
echo '<input   style="display: none;" type="text" name="thuraft13" value="'.$thuraft13.'">';
echo '<input   style="display: none;" type="text" name="thurmorn14" value="'.$thurmorn14.'">';
echo '<input   style="display: none;" type="text" name="thuraft14" value="'.$thuraft14.'">';
echo '<input   style="display: none;" type="text" name="frimorns" value="'.$frimorn.'">';
echo '<input   style="display: none;" type="text" name="friaft" value="'.$friaft.'">';
echo '<input   style="display: none;" type="text" name="frimorn2" value="'.$frimorn2.'">';
echo '<input   style="display: none;" type="text" name="friaft2" value="'.$friaft2.'">';
echo '<input   style="display: none;" type="text" name="frimorn3" value="'.$frimorn3.'">';
echo '<input   style="display: none;" type="text" name="friaft3" value="'.$friaft3.'">';
echo '<input   style="display: none;" type="text" name="frimorn4" value="'.$frimorn4.'">';
echo '<input   style="display: none;" type="text" name="friaft4" value="'.$friaft4.'">';
echo '<input   style="display: none;" type="text" name="frimorn5" value="'.$frimorn5.'">';
echo '<input   style="display: none;" type="text" name="friaft5" value="'.$friaft5.'">';
echo '<input   style="display: none;" type="text" name="frimorn6" value="'.$frimorn6.'">';
echo '<input   style="display: none;" type="text" name="friaft6" value="'.$friaft6.'">';
echo '<input   style="display: none;" type="text" name="frimorn7" value="'.$frimorn7.'">';
echo '<input   style="display: none;" type="text" name="friaft7" value="'.$friaft7.'">';
echo '<input   style="display: none;" type="text" name="frimorn8" value="'.$frimorn8.'">';
echo '<input   style="display: none;" type="text" name="friaft8" value="'.$friaft8.'">';
echo '<input   style="display: none;" type="text" name="frimorn9" value="'.$frimorn9.'">';
echo '<input   style="display: none;" type="text" name="friaft9" value="'.$friaft9.'">';
echo '<input   style="display: none;" type="text" name="frimorn10" value="'.$frimorn10.'">';
echo '<input   style="display: none;" type="text" name="friaft10" value="'.$friaft10.'">';
echo '<input   style="display: none;" type="text" name="frimorn11" value="'.$frimorn11.'">';
echo '<input   style="display: none;" type="text" name="friaft11" value="'.$friaft11.'">';
echo '<input   style="display: none;" type="text" name="frimorn12" value="'.$frimorn12.'">';
echo '<input   style="display: none;" type="text" name="friaft12" value="'.$friaft12.'">';
echo '<input   style="display: none;" type="text" name="frimorn13" value="'.$frimorn13.'">';
echo '<input   style="display: none;" type="text" name="friaft13" value="'.$friaft13.'">';
echo '<input   style="display: none;" type="text" name="frimorn14" value="'.$frimorn14.'">';
echo '<input   style="display: none;" type="text" name="friaft14" value="'.$friaft14.'">';
echo '<input   style="display: none;" type="text" name="wemorn1" value="'.$wemorn1.'">';
echo '<input   style="display: none;" type="text" name="weaft1" value="'.$weaft1.'">';
echo '<input   style="display: none;" type="text" name="wemorn2" value="'.$wemorn2.'">';
echo '<input   style="display: none;" type="text" name="weaft2" value="'.$weaft2.'">';
echo '<input   style="display: none;" type="text" name="wemorn3" value="'.$wemorn3.'">';
echo '<input   style="display: none;" type="text" name="weaft3" value="'.$weaft3.'">';
echo '<input   style="display: none;" type="text" name="wemorn4" value="'.$wemorn4.'">';
echo '<input   style="display: none;" type="text" name="weaft4" value="'.$weaft4.'">';
echo '<input   style="display: none;" type="text" name="wemorn5" value="'.$wemorn5.'">';
echo '<input   style="display: none;" type="text" name="weaft5" value="'.$weaft5.'">';
echo '<input   style="display: none;" type="text" name="wemorn6" value="'.$wemorn6.'">';
echo '<input   style="display: none;" type="text" name="weaft6" value="'.$weaft6.'">';
echo '<input   style="display: none;" type="text" name="wemorn7" value="'.$wemorn7.'">';
echo '<input   style="display: none;" type="text" name="weaft7" value="'.$weaft7.'">';
echo '<input   style="display: none;" type="text" name="wemorn8" value="'.$wemorn8.'">';
echo '<input   style="display: none;" type="text" name="weaft8" value="'.$weaft8.'">';
echo '<input   style="display: none;" type="text" name="wemorn9" value="'.$wemorn9.'">';
echo '<input   style="display: none;" type="text" name="weaft9" value="'.$weaft9.'">';
echo '<input   style="display: none;" type="text" name="wemorn10" value="'.$wemorn10.'">';
echo '<input   style="display: none;" type="text" name="weaft10" value="'.$weaft10.'">';
echo '<input   style="display: none;" type="text" name="wemorn11" value="'.$wemorn11.'">';
echo '<input   style="display: none;" type="text" name="weaft11" value="'.$weaft11.'">';
echo '<input   style="display: none;" type="text" name="wemorn12" value="'.$wemorn12.'">';
echo '<input   style="display: none;" type="text" name="weaft12" value="'.$weaft12.'">';
echo '<input   style="display: none;" type="text" name="wemorn13" value="'.$wemorn13.'">';
echo '<input   style="display: none;" type="text" name="weaft13" value="'.$weaft13.'">';
echo '<input   style="display: none;" type="text" name="wemorn14" value="'.$wemorn14.'">';
echo '<input   style="display: none;" type="text" name="weaft14" value="'.$weaft14.'">';
echo '<input   style="display: none;" type="text" name="year" value="'.$year.'">';
echo '<input   style="display: none;" type="term" name="term" value="'.$term.'">';
echo '<input   style="display: none;" type="text" name="arms" value="'.$arms.'">';
echo '<input   style="display: none;" type="text" name="class" value="'.$class.'">';
echo '<input   style="display: none;" type="text" name="wkfemaletotal" value="'.$wkfemaletotal.'">';
echo '<input   style="display: none;" type="text" name="wkmaletotal" value="'.$wkmaletotal.'">';
echo '<input   style="display: none;" type="text" name="wkmale11" value="'.$wkmale11.'">';
echo '<input   style="display: none;" type="text" name="wkfemale11" value="'.$wkfemale11.'">';
echo '<input   style="display: none;" type="text" name="wkmale22" value="'.$wkmale22.'">';
echo '<input   style="display: none;" type="text" name="wkfemale22" value="'.$wkfemale22.'">';
echo '<input   style="display: none;" type="text" name="wkmale33" value="'.$wkmale33.'">';
echo '<input   style="display: none;" type="text" name="wkfemale33" value="'.$wkfemale33.'">';
echo '<input   style="display: none;" type="text" name="wkmale44" value="'.$wkmale44.'">';
echo '<input   style="display: none;" type="text" name="wkfemale44" value="'.$wkfemale44.'">';
echo '<input   style="display: none;" type="text" name="wkmale55" value="'.$wkmale55.'">';
echo '<input   style="display: none;" type="text" name="wkfemale55" value="'.$wkfemale55.'">';
echo '<input   style="display: none;" type="text" name="wkmale66" value="'.$wkmale66.'">';
echo '<input   style="display: none;" type="text" name="wkfemale66" value="'.$wkfemale66.'">';
echo '<input   style="display: none;" type="text" name="wkmale77" value="'.$wkmale77.'">';
echo '<input   style="display: none;" type="text" name="wkfemale77" value="'.$wkfemale77.'">';
echo '<input   style="display: none;" type="text" name="wkmale88" value="'.$wkmale88.'">';
echo '<input   style="display: none;" type="text" name="wkfemale88" value="'.$wkfemale88.'">';
echo '<input   style="display: none;" type="text" name="wkmale99" value="'.$wkmale99.'">';
echo '<input   style="display: none;" type="text" name="wkfemale99" value="'.$wkfemale99.'">';
echo '<input   style="display: none;" type="text" name="wkmale1010" value="'.$wkmale1010.'">';
echo '<input   style="display: none;" type="text" name="wkfemale1010" value="'.$wkfemale1010.'">';
echo '<input   style="display: none;" type="text" name="wkmale1111" value="'.$wkmale1111.'">';
echo '<input   style="display: none;" type="text" name="wkfemale1111" value="'.$wkfemale1111.'">';
echo '<input   style="display: none;" type="text" name="wkmale1212" value="'.$wkmale1212.'">';
echo '<input   style="display: none;" type="text" name="wkfemale1212" value="'.$wkfemale1212.'">';
echo '<input   style="display: none;" type="text" name="wkmale1313" value="'.$wkmale1313.'">';
echo '<input   style="display: none;" type="text" name="wkfemale1313" value="'.$wkfemale1313.'">';
echo '<input   style="display: none;" type="text" name="wkmale1414" value="'.$wkmale1414.'">';
echo '<input   style="display: none;" type="text" name="wkfemale1414" value="'.$wkfemale1414.'">';
echo '<input   style="display: none;" type="text" name="wk1end" value="'.$wk1end.'">';
echo '<input   style="display: none;" type="text" name="wk2end" value="'.$wk2end.'">';
echo '<input   style="display: none;" type="text" name="wk3end" value="'.$wk3end.'">';
echo '<input   style="display: none;" type="text" name="wk4end" value="'.$wk4end.'">';
echo '<input   style="display: none;" type="text" name="wk5end" value="'.$wk5end.'">';
echo '<input   style="display: none;" type="text" name="wk6end" value="'.$wk6end.'">';
echo '<input   style="display: none;" type="text" name="wk7end" value="'.$wk7end.'">';
echo '<input   style="display: none;" type="text" name="wk8end" value="'.$wk8end.'">';
echo '<input   style="display: none;" type="text" name="wk9end" value="'.$wk9end.'">';
echo '<input   style="display: none;" type="text" name="wk10end" value="'.$wk10end.'">';
echo '<input   style="display: none;" type="text" name="wk11end" value="'.$wk11end.'">';
echo '<input   style="display: none;" type="text" name="wk12end" value="'.$wk12end.'">';
echo '<input   style="display: none;" type="text" name="wk13end" value="'.$wk13end.'">';
echo '<input   style="display: none;" type="text" name="wk14end" value="'.$wk14end.'">';
echo '<input class="myButton" style="float: left;" type="submit" name="submit" id="attpdfsubmit" value="Make Downloadable" />';
echo '</form>';	




echo '<form id="genattpdfemail">';
foreach($striarray as $striarray2)
{
  echo '<input  style="display: none;" type="text" name="absents[]" value="'.$striarray2.'">';
}
foreach($valuestudents as $valuestudent)
{
  echo '<input  type="text" style="display: none;" name="student_name[]" value="'.$valuestudent.'">';
}
foreach($getsexit as $sex)
{
  echo '<input  type="text" style="display: none;" name="sex[]" value="'.$sex.'">';
}
foreach($gredate as $redateit)
{
  echo '<input  type="text" style="display: none;" name="redateit[]" value="'.$redateit.'">';
}
foreach($gredate2 as $redateit2)
{
  echo '<input  type="text" style="display: none;" name="redateit2[]" value="'.$redateit2.'">';
}
foreach($gredate3 as $redateit3)
{
  echo '<input  type="text" style="display: none;" name="redateit3[]" value="'.$redateit3.'">';
}
foreach($gredate4 as $redateit4)
{
  echo '<input  type="text" style="display: none;" name="redateit4[]" value="'.$redateit4.'">';
}
foreach($gredate5 as $redateit5)
{
  echo '<input  type="text" style="display: none;" name="redateit5[]" value="'.$redateit5.'">';
}
foreach($gredate5 as $redateit6)
{
  echo '<input  type="text" style="display: none;" name="redateit6[]" value="'.$redateit6.'">';
}
foreach($gredate7 as $redateit7)
{
  echo '<input  type="text" style="display: none;" name="redateit7[]" value="'.$redateit7.'">';
}
foreach($gredate8 as $redateit8)
{
  echo '<input  type="text" style="display: none;" name="redateit8[]" value="'.$redateit8.'">';
}
foreach($gredate9 as $redateit9)
{
  echo '<input  type="text" style="display: none;" name="redateit9[]" value="'.$redateit9.'">';
}
foreach($gredate10 as $redateit10)
{
  echo '<input  type="text" style="display: none;" name="redateit10[]" value="'.$redateit10.'">';
}
foreach($gredate11 as $redateit11)
{
  echo '<input  type="text" style="display: none;" name="redateit11[]" value="'.$redateit11.'">';
}
foreach($gredate12 as $redateit12)
{
  echo '<input  type="text" style="display: none;" name="redateit12[]" value="'.$redateit12.'">';
}
foreach($gredate13 as $redateit13)
{
  echo '<input  type="text" style="display: none;" name="redateit13[]" value="'.$redateit13.'">';
}
foreach($gredate14 as $redateit14)
{
  echo '<input  type="text" style="display: none;" name="redateit14[]" value="'.$redateit14.'">';
}
foreach($gredatetotalmid as $stmid)
{
  echo '<input  style="display: none;" type="text" name="stmid[]" value="'.$stmid.'">';
}
foreach($gredatetotal as $sttotal)
{
  echo '<input  style="display: none;" type="text" name="sttotal[]" value="'.$sttotal.'">';
}
echo '<input   style="display: none;" type="text" name="termbegin" value="'.$termbegin.'">';
echo '<input   style="display: none;" type="text" name="ftotal" value="'.$ggetsexfemale.'">';
echo '<input   style="display: none;" type="text" name="mtotal" value="'.$ggetsexmale.'">';
echo '<input   style="display: none;" type="text" name="grredate" value="'.$grredate.'">';
echo '<input   style="display: none;" type="text" name="grredate2" value="'.$grredate2.'">';
echo '<input   style="display: none;" type="text" name="grredate3" value="'.$grredate3.'">';
echo '<input   style="display: none;" type="text" name="grredate4" value="'.$grredate4.'">';
echo '<input   style="display: none;" type="text" name="grredate5" value="'.$grredate5.'">';
echo '<input   style="display: none;" type="text" name="grredate6" value="'.$grredate6.'">';
echo '<input   style="display: none;" type="text" name="grredate7" value="'.$grredate7.'">';
echo '<input   style="display: none;" type="text" name="grredate8" value="'.$grredate8.'">';
echo '<input   style="display: none;" type="text" name="grredate9" value="'.$grredate9.'">';
echo '<input   style="display: none;" type="text" name="grredate10" value="'.$grredate10.'">';
echo '<input   style="display: none;" type="text" name="grredate11" value="'.$grredate11.'">';
echo '<input   style="display: none;" type="text" name="grredate12" value="'.$grredate12.'">';
echo '<input   style="display: none;" type="text" name="grredate13" value="'.$grredate13.'">';
echo '<input   style="display: none;" type="text" name="grredate14" value="'.$grredate14.'">';
echo '<input   style="display: none;" type="text" name="grredatetotalmid" value="'.$grredatetotalmid.'">';
echo '<input   style="display: none;" type="text" name="grredatetotal" value="'.$grredatetotal.'">';
echo '<input   style="display: none;" type="text" name="counted" value="'.$counted.'">';
echo '<input   style="display: none;" type="text" name="att1" value="'.$att1.'">';
echo '<input   style="display: none;" type="text" name="att2" value="'.$att2.'">';
echo '<input   style="display: none;" type="text" name="att3" value="'.$att3.'">';
echo '<input   style="display: none;" type="text" name="att4" value="'.$att4.'">';
echo '<input   style="display: none;" type="text" name="att5" value="'.$att5.'">';
echo '<input   style="display: none;" type="text" name="att6" value="'.$att6.'">';
echo '<input   style="display: none;" type="text" name="att7" value="'.$att7.'">';
echo '<input   style="display: none;" type="text" name="att8" value="'.$att8.'">';
echo '<input   style="display: none;" type="text" name="att9" value="'.$att9.'">';
echo '<input   style="display: none;" type="text" name="att10" value="'.$att10.'">';
echo '<input   style="display: none;" type="text" name="att11" value="'.$att11.'">';
echo '<input   style="display: none;" type="text" name="att12" value="'.$att12.'">';
echo '<input   style="display: none;" type="text" name="att13" value="'.$att13.'">';
echo '<input   style="display: none;" type="text" name="att14" value="'.$att14.'">';
echo '<input   style="display: none;" type="text" name="redatetotalmid" value="'.$redatetotalmid.'">';
echo '<input   style="display: none;" type="text" name="atttotalalmid" value="'.$atttotalalmid.'">';
echo '<input   style="display: none;" type="text" name="atttotalal" value="'.$atttotalal.'">';
echo '<input   style="display: none;" type="text" name="atttotalallmid" value="'.$atttotalallmid.'">';
echo '<input   style="display: none;" type="text" name="atttotalall" value="'.$atttotalall.'">';
echo '<input   style="display: none;" type="text" name="monmorn" value="'.$monmorn.'">';
echo '<input   style="display: none;" type="text" name="monaft" value="'.$monaft.'">';
echo '<input   style="display: none;" type="text" name="monmorn2" value="'.$monmorn2.'">';
echo '<input   style="display: none;" type="text" name="monaft2" value="'.$monaft2.'">';
echo '<input   style="display: none;" type="text" name="monmorn3" value="'.$monmorn3.'">';
echo '<input   style="display: none;" type="text" name="monaft3" value="'.$monaft3.'">';
echo '<input   style="display: none;" type="text" name="monmorn4" value="'.$monmorn4.'">';
echo '<input   style="display: none;" type="text" name="monaft4" value="'.$monaft4.'">';
echo '<input   style="display: none;" type="text" name="monmorn5" value="'.$monmorn5.'">';
echo '<input   style="display: none;" type="text" name="monaft5" value="'.$monaft5.'">';
echo '<input   style="display: none;" type="text" name="monmorn6" value="'.$monmorn6.'">';
echo '<input   style="display: none;" type="text" name="monaft6" value="'.$monaft6.'">';
echo '<input   style="display: none;" type="text" name="monmorn7" value="'.$monmorn7.'">';
echo '<input   style="display: none;" type="text" name="monaft7" value="'.$monaft7.'">';
echo '<input   style="display: none;" type="text" name="monmorn8" value="'.$monmorn8.'">';
echo '<input   style="display: none;" type="text" name="monaft8" value="'.$monaft8.'">';
echo '<input   style="display: none;" type="text" name="monmorn9" value="'.$monmorn9.'">';
echo '<input   style="display: none;" type="text" name="monaft9" value="'.$monaft9.'">';
echo '<input   style="display: none;" type="text" name="monmorn10" value="'.$monmorn10.'">';
echo '<input   style="display: none;" type="text" name="monaft10" value="'.$monaft10.'">';
echo '<input   style="display: none;" type="text" name="monmorn11" value="'.$monmorn11.'">';
echo '<input   style="display: none;" type="text" name="monaft11" value="'.$monaft11.'">';
echo '<input   style="display: none;" type="text" name="monmorn12" value="'.$monmorn12.'">';
echo '<input   style="display: none;" type="text" name="monaft12" value="'.$monaft12.'">';
echo '<input   style="display: none;" type="text" name="monmorn13" value="'.$monmorn13.'">';
echo '<input   style="display: none;" type="text" name="monaft13" value="'.$monaft13.'">';
echo '<input   style="display: none;" type="text" name="monmorn14" value="'.$monmorn14.'">';
echo '<input   style="display: none;" type="text" name="monaft14" value="'.$monaft14.'">';
echo '<input   style="display: none;" type="text" name="tuemorn" value="'.$tuemorn.'">';
echo '<input   style="display: none;" type="text" name="tueaft" value="'.$tueaft.'">';
echo '<input   style="display: none;" type="text" name="tuemorn2" value="'.$tuemorn2.'">';
echo '<input   style="display: none;" type="text" name="tueaft2" value="'.$tueaft2.'">';
echo '<input   style="display: none;" type="text" name="tuemorn3" value="'.$tuemorn3.'">';
echo '<input   style="display: none;" type="text" name="tueaft3" value="'.$tueaft3.'">';
echo '<input   style="display: none;" type="text" name="tuemorn4" value="'.$tuemorn4.'">';
echo '<input   style="display: none;" type="text" name="tueaft4" value="'.$tueaft4.'">';
echo '<input   style="display: none;" type="text" name="tuemorn5" value="'.$tuemorn5.'">';
echo '<input   style="display: none;" type="text" name="tueaft5" value="'.$tueaft5.'">';
echo '<input   style="display: none;" type="text" name="tuemorn6" value="'.$tuemorn6.'">';
echo '<input   style="display: none;" type="text" name="tueaft6" value="'.$tueaft6.'">';
echo '<input   style="display: none;" type="text" name="tuemorn7" value="'.$tuemorn7.'">';
echo '<input   style="display: none;" type="text" name="tueaft7" value="'.$tueaft7.'">';
echo '<input   style="display: none;" type="text" name="tuemorn8" value="'.$tuemorn8.'">';
echo '<input   style="display: none;" type="text" name="tueaft8" value="'.$tueaft8.'">';
echo '<input   style="display: none;" type="text" name="tuemorn9" value="'.$tuemorn9.'">';
echo '<input   style="display: none;" type="text" name="tueaft9" value="'.$tueaft9.'">';
echo '<input   style="display: none;" type="text" name="tuemorn10" value="'.$tuemorn10.'">';
echo '<input   style="display: none;" type="text" name="tueaft10" value="'.$tueaft10.'">';
echo '<input   style="display: none;" type="text" name="tuemorn11" value="'.$tuemorn11.'">';
echo '<input   style="display: none;" type="text" name="tueaft11" value="'.$tueaft11.'">';
echo '<input   style="display: none;" type="text" name="tuemorn12" value="'.$tuemorn12.'">';
echo '<input   style="display: none;" type="text" name="tueaft12" value="'.$tueaft12.'">';
echo '<input   style="display: none;" type="text" name="tuemorn13" value="'.$tuemorn13.'">';
echo '<input   style="display: none;" type="text" name="tueaft13" value="'.$tueaft13.'">';
echo '<input   style="display: none;" type="text" name="tuemorn14" value="'.$tuemorn14.'">';
echo '<input   style="display: none;" type="text" name="tueaft14" value="'.$tueaft14.'">';
echo '<input   style="display: none;" type="text" name="wedmorn" value="'.$wedmorn.'">';
echo '<input   style="display: none;" type="text" name="wedaft" value="'.$wedaft.'">';
echo '<input   style="display: none;" type="text" name="wedmorn2" value="'.$wedmorn2.'">';
echo '<input   style="display: none;" type="text" name="wedaft2" value="'.$wedaft2.'">';
echo '<input   style="display: none;" type="text" name="wedmorn3" value="'.$wedmorn3.'">';
echo '<input   style="display: none;" type="text" name="wedaft3" value="'.$wedaft3.'">';
echo '<input   style="display: none;" type="text" name="wedmorn4" value="'.$wedmorn4.'">';
echo '<input   style="display: none;" type="text" name="wedaft4" value="'.$wedaft4.'">';
echo '<input   style="display: none;" type="text" name="wedmorn5" value="'.$wedmorn5.'">';
echo '<input   style="display: none;" type="text" name="wedaft5" value="'.$wedaft5.'">';
echo '<input   style="display: none;" type="text" name="wedmorn6" value="'.$wedmorn6.'">';
echo '<input   style="display: none;" type="text" name="wedaft6" value="'.$wedaft6.'">';
echo '<input   style="display: none;" type="text" name="wedmorn7" value="'.$wedmorn7.'">';
echo '<input   style="display: none;" type="text" name="wedaft7" value="'.$wedaft7.'">';
echo '<input   style="display: none;" type="text" name="wedmorn8" value="'.$wedmorn8.'">';
echo '<input   style="display: none;" type="text" name="wedaft8" value="'.$wedaft8.'">';
echo '<input   style="display: none;" type="text" name="wedmorn9" value="'.$wedmorn9.'">';
echo '<input   style="display: none;" type="text" name="wedaft9" value="'.$wedaft9.'">';
echo '<input   style="display: none;" type="text" name="wedmorn10" value="'.$wedmorn10.'">';
echo '<input   style="display: none;" type="text" name="wedaft10" value="'.$wedaft10.'">';
echo '<input   style="display: none;" type="text" name="wedmorn11" value="'.$wedmorn11.'">';
echo '<input   style="display: none;" type="text" name="wedaft11" value="'.$wedaft11.'">';
echo '<input   style="display: none;" type="text" name="wedmorn12" value="'.$wedmorn12.'">';
echo '<input   style="display: none;" type="text" name="wedaft12" value="'.$wedaft12.'">';
echo '<input   style="display: none;" type="text" name="wedmorn13" value="'.$wedmorn13.'">';
echo '<input   style="display: none;" type="text" name="wedaft13" value="'.$wedaft13.'">';
echo '<input   style="display: none;" type="text" name="wedmorn14" value="'.$wedmorn14.'">';
echo '<input   style="display: none;" type="text" name="wedaft14" value="'.$wedaft14.'">';
echo '<input   style="display: none;" type="text" name="thurmorn" value="'.$thurmorn.'">';
echo '<input   style="display: none;" type="text" name="thuraft" value="'.$thuraft.'">';
echo '<input   style="display: none;" type="text" name="thurmorn2" value="'.$thurmorn2.'">';
echo '<input   style="display: none;" type="text" name="thuraft2" value="'.$thuraft2.'">';
echo '<input   style="display: none;" type="text" name="thurmorn3" value="'.$thurmorn3.'">';
echo '<input   style="display: none;" type="text" name="thuraft3" value="'.$thuraft3.'">';
echo '<input   style="display: none;" type="text" name="thurmorn4" value="'.$thurmorn4.'">';
echo '<input   style="display: none;" type="text" name="thuraft4" value="'.$thuraft4.'">';
echo '<input   style="display: none;" type="text" name="thurmorn5" value="'.$thurmorn5.'">';
echo '<input   style="display: none;" type="text" name="thuraft5" value="'.$thuraft5.'">';
echo '<input   style="display: none;" type="text" name="thurmorn6" value="'.$thurmorn6.'">';
echo '<input   style="display: none;" type="text" name="thuraft6" value="'.$thuraft6.'">';
echo '<input   style="display: none;" type="text" name="thurmorn7" value="'.$thurmorn7.'">';
echo '<input   style="display: none;" type="text" name="thuraft7" value="'.$thuraft7.'">';
echo '<input   style="display: none;" type="text" name="thurmorn8" value="'.$thurmorn8.'">';
echo '<input   style="display: none;" type="text" name="thuraft8" value="'.$thuraft8.'">';
echo '<input   style="display: none;" type="text" name="thurmorn9" value="'.$thurmorn9.'">';
echo '<input   style="display: none;" type="text" name="thuraft9" value="'.$thuraft9.'">';
echo '<input   style="display: none;" type="text" name="thurmorn10" value="'.$thurmorn10.'">';
echo '<input   style="display: none;" type="text" name="thuraft10" value="'.$thuraft10.'">';
echo '<input   style="display: none;" type="text" name="thurmorn11" value="'.$thurmorn11.'">';
echo '<input   style="display: none;" type="text" name="thuraft11" value="'.$thuraft11.'">';
echo '<input   style="display: none;" type="text" name="thurmorn12" value="'.$thurmorn12.'">';
echo '<input   style="display: none;" type="text" name="thuraft12" value="'.$thuraft12.'">';
echo '<input   style="display: none;" type="text" name="thurmorn13" value="'.$thurmorn13.'">';
echo '<input   style="display: none;" type="text" name="thuraft13" value="'.$thuraft13.'">';
echo '<input   style="display: none;" type="text" name="thurmorn14" value="'.$thurmorn14.'">';
echo '<input   style="display: none;" type="text" name="thuraft14" value="'.$thuraft14.'">';
echo '<input   style="display: none;" type="text" name="frimorns" value="'.$frimorn.'">';
echo '<input   style="display: none;" type="text" name="friaft" value="'.$friaft.'">';
echo '<input   style="display: none;" type="text" name="frimorn2" value="'.$frimorn2.'">';
echo '<input   style="display: none;" type="text" name="friaft2" value="'.$friaft2.'">';
echo '<input   style="display: none;" type="text" name="frimorn3" value="'.$frimorn3.'">';
echo '<input   style="display: none;" type="text" name="friaft3" value="'.$friaft3.'">';
echo '<input   style="display: none;" type="text" name="frimorn4" value="'.$frimorn4.'">';
echo '<input   style="display: none;" type="text" name="friaft4" value="'.$friaft4.'">';
echo '<input   style="display: none;" type="text" name="frimorn5" value="'.$frimorn5.'">';
echo '<input   style="display: none;" type="text" name="friaft5" value="'.$friaft5.'">';
echo '<input   style="display: none;" type="text" name="frimorn6" value="'.$frimorn6.'">';
echo '<input   style="display: none;" type="text" name="friaft6" value="'.$friaft6.'">';
echo '<input   style="display: none;" type="text" name="frimorn7" value="'.$frimorn7.'">';
echo '<input   style="display: none;" type="text" name="friaft7" value="'.$friaft7.'">';
echo '<input   style="display: none;" type="text" name="frimorn8" value="'.$frimorn8.'">';
echo '<input   style="display: none;" type="text" name="friaft8" value="'.$friaft8.'">';
echo '<input   style="display: none;" type="text" name="frimorn9" value="'.$frimorn9.'">';
echo '<input   style="display: none;" type="text" name="friaft9" value="'.$friaft9.'">';
echo '<input   style="display: none;" type="text" name="frimorn10" value="'.$frimorn10.'">';
echo '<input   style="display: none;" type="text" name="friaft10" value="'.$friaft10.'">';
echo '<input   style="display: none;" type="text" name="frimorn11" value="'.$frimorn11.'">';
echo '<input   style="display: none;" type="text" name="friaft11" value="'.$friaft11.'">';
echo '<input   style="display: none;" type="text" name="frimorn12" value="'.$frimorn12.'">';
echo '<input   style="display: none;" type="text" name="friaft12" value="'.$friaft12.'">';
echo '<input   style="display: none;" type="text" name="frimorn13" value="'.$frimorn13.'">';
echo '<input   style="display: none;" type="text" name="friaft13" value="'.$friaft13.'">';
echo '<input   style="display: none;" type="text" name="frimorn14" value="'.$frimorn14.'">';
echo '<input   style="display: none;" type="text" name="friaft14" value="'.$friaft14.'">';
echo '<input   style="display: none;" type="text" name="wemorn1" value="'.$wemorn1.'">';
echo '<input   style="display: none;" type="text" name="weaft1" value="'.$weaft1.'">';
echo '<input   style="display: none;" type="text" name="wemorn2" value="'.$wemorn2.'">';
echo '<input   style="display: none;" type="text" name="weaft2" value="'.$weaft2.'">';
echo '<input   style="display: none;" type="text" name="wemorn3" value="'.$wemorn3.'">';
echo '<input   style="display: none;" type="text" name="weaft3" value="'.$weaft3.'">';
echo '<input   style="display: none;" type="text" name="wemorn4" value="'.$wemorn4.'">';
echo '<input   style="display: none;" type="text" name="weaft4" value="'.$weaft4.'">';
echo '<input   style="display: none;" type="text" name="wemorn5" value="'.$wemorn5.'">';
echo '<input   style="display: none;" type="text" name="weaft5" value="'.$weaft5.'">';
echo '<input   style="display: none;" type="text" name="wemorn6" value="'.$wemorn6.'">';
echo '<input   style="display: none;" type="text" name="weaft6" value="'.$weaft6.'">';
echo '<input   style="display: none;" type="text" name="wemorn7" value="'.$wemorn7.'">';
echo '<input   style="display: none;" type="text" name="weaft7" value="'.$weaft7.'">';
echo '<input   style="display: none;" type="text" name="wemorn8" value="'.$wemorn8.'">';
echo '<input   style="display: none;" type="text" name="weaft8" value="'.$weaft8.'">';
echo '<input   style="display: none;" type="text" name="wemorn9" value="'.$wemorn9.'">';
echo '<input   style="display: none;" type="text" name="weaft9" value="'.$weaft9.'">';
echo '<input   style="display: none;" type="text" name="wemorn10" value="'.$wemorn10.'">';
echo '<input   style="display: none;" type="text" name="weaft10" value="'.$weaft10.'">';
echo '<input   style="display: none;" type="text" name="wemorn11" value="'.$wemorn11.'">';
echo '<input   style="display: none;" type="text" name="weaft11" value="'.$weaft11.'">';
echo '<input   style="display: none;" type="text" name="wemorn12" value="'.$wemorn12.'">';
echo '<input   style="display: none;" type="text" name="weaft12" value="'.$weaft12.'">';
echo '<input   style="display: none;" type="text" name="wemorn13" value="'.$wemorn13.'">';
echo '<input   style="display: none;" type="text" name="weaft13" value="'.$weaft13.'">';
echo '<input   style="display: none;" type="text" name="wemorn14" value="'.$wemorn14.'">';
echo '<input   style="display: none;" type="text" name="weaft14" value="'.$weaft14.'">';
echo '<input   style="display: none;" type="text" name="year" value="'.$year.'">';
echo '<input   style="display: none;" type="term" name="term" value="'.$term.'">';
echo '<input   style="display: none;" type="text" name="arms" value="'.$arms.'">';
echo '<input   style="display: none;" type="text" name="class" value="'.$class.'">';
echo '<input   style="display: none;" type="text" name="wkfemaletotal" value="'.$wkfemaletotal.'">';
echo '<input   style="display: none;" type="text" name="wkmaletotal" value="'.$wkmaletotal.'">';
echo '<input   style="display: none;" type="text" name="wkmale11" value="'.$wkmale11.'">';
echo '<input   style="display: none;" type="text" name="wkfemale11" value="'.$wkfemale11.'">';
echo '<input   style="display: none;" type="text" name="wkmale22" value="'.$wkmale22.'">';
echo '<input   style="display: none;" type="text" name="wkfemale22" value="'.$wkfemale22.'">';
echo '<input   style="display: none;" type="text" name="wkmale33" value="'.$wkmale33.'">';
echo '<input   style="display: none;" type="text" name="wkfemale33" value="'.$wkfemale33.'">';
echo '<input   style="display: none;" type="text" name="wkmale44" value="'.$wkmale44.'">';
echo '<input   style="display: none;" type="text" name="wkfemale44" value="'.$wkfemale44.'">';
echo '<input   style="display: none;" type="text" name="wkmale55" value="'.$wkmale55.'">';
echo '<input   style="display: none;" type="text" name="wkfemale55" value="'.$wkfemale55.'">';
echo '<input   style="display: none;" type="text" name="wkmale66" value="'.$wkmale66.'">';
echo '<input   style="display: none;" type="text" name="wkfemale66" value="'.$wkfemale66.'">';
echo '<input   style="display: none;" type="text" name="wkmale77" value="'.$wkmale77.'">';
echo '<input   style="display: none;" type="text" name="wkfemale77" value="'.$wkfemale77.'">';
echo '<input   style="display: none;" type="text" name="wkmale88" value="'.$wkmale88.'">';
echo '<input   style="display: none;" type="text" name="wkfemale88" value="'.$wkfemale88.'">';
echo '<input   style="display: none;" type="text" name="wkmale99" value="'.$wkmale99.'">';
echo '<input   style="display: none;" type="text" name="wkfemale99" value="'.$wkfemale99.'">';
echo '<input   style="display: none;" type="text" name="wkmale1010" value="'.$wkmale1010.'">';
echo '<input   style="display: none;" type="text" name="wkfemale1010" value="'.$wkfemale1010.'">';
echo '<input   style="display: none;" type="text" name="wkmale1111" value="'.$wkmale1111.'">';
echo '<input   style="display: none;" type="text" name="wkfemale1111" value="'.$wkfemale1111.'">';
echo '<input   style="display: none;" type="text" name="wkmale1212" value="'.$wkmale1212.'">';
echo '<input   style="display: none;" type="text" name="wkfemale1212" value="'.$wkfemale1212.'">';
echo '<input   style="display: none;" type="text" name="wkmale1313" value="'.$wkmale1313.'">';
echo '<input   style="display: none;" type="text" name="wkfemale1313" value="'.$wkfemale1313.'">';
echo '<input   style="display: none;" type="text" name="wkmale1414" value="'.$wkmale1414.'">';
echo '<input   style="display: none;" type="text" name="wkfemale1414" value="'.$wkfemale1414.'">';
echo '<input   style="display: none;" type="text" name="wk1end" value="'.$wk1end.'">';
echo '<input   style="display: none;" type="text" name="wk2end" value="'.$wk2end.'">';
echo '<input   style="display: none;" type="text" name="wk3end" value="'.$wk3end.'">';
echo '<input   style="display: none;" type="text" name="wk4end" value="'.$wk4end.'">';
echo '<input   style="display: none;" type="text" name="wk5end" value="'.$wk5end.'">';
echo '<input   style="display: none;" type="text" name="wk6end" value="'.$wk6end.'">';
echo '<input   style="display: none;" type="text" name="wk7end" value="'.$wk7end.'">';
echo '<input   style="display: none;" type="text" name="wk8end" value="'.$wk8end.'">';
echo '<input   style="display: none;" type="text" name="wk9end" value="'.$wk9end.'">';
echo '<input   style="display: none;" type="text" name="wk10end" value="'.$wk10end.'">';
echo '<input   style="display: none;" type="text" name="wk11end" value="'.$wk11end.'">';
echo '<input   style="display: none;" type="text" name="wk12end" value="'.$wk12end.'">';
echo '<input   style="display: none;" type="text" name="wk13end" value="'.$wk13end.'">';
echo '<input   style="display: none;" type="text" name="wk14end" value="'.$wk14end.'">';
echo '<input class="myButton" style="float: left;" type="submit" name="submit" id="attpdfsubmitemail" value="Email Attendance Data" />';
echo '</form>';	

echo "<form style='display: none;' id='formforemaill'>";
echo "<input type='text' name='yemail' id='yemail' placeholder='recipient\'s email' /><input style='display: none;' name='pdfatt' id='pdfatt' type='text' />";
echo "<input class='myButton' name='submitattpdf' id='submitattpdf' type='submit' value='send email' />";
echo "</form>";
?>
<?php
include("footer.php");
?>
</body>
</html>