<?php
	session_start();
	include "connection.php";
	include("auth.php"); 
	include('db.php');
	
	$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Result Visibility</title>
<link rel="stylesheet" href="style.css" type="text/css" />
<link rel="stylesheet" href="css/style.css" />
	<script src="table/js/jquery.js" type="text/javascript"></script>
	<script src="datatablejs.js" type="text/javascript"></script>
	<link rel="stylesheet" type="text/css" href="datatablecss.css">
	 <link rel="stylesheet" type="text/css" href="datatablebuttoncss.css">
<script>
	$(document).ready(function() {
    $('#example').DataTable( {
        "paging":   false,
        "ordering": true,
        "info":     false,
		"scrollY":  "1000px",
        "scrollCollapse": true
    });	
});
</script>
<script>
$(document).ready(function() {
$("#class_name option").eq(7).css("display","none");
$("#class_name").on("change",function(){
var bb = $("#class_name").find(":selected").text();
var b = null;
if(bb=="Primary 1"){
	b = "Year 1";
}
else if(bb=="Primary 2"){
	b = "Year 2";
}
else if(bb=="Primary 3"){
	b = "Year 3";
}
else if(bb=="Primary 4"){
	b = "Year 4";
}
else if(bb=="Primary 5"){
	b = "Year 5";
}
else if(bb=="Primary 6"){
	b = "Year 6";
}
else if(bb=="JS1"){
	b = "Year 7";
}
else if(bb=="JS2"){
	b = "Year 8";
}
else if(bb=="JS3"){
	b = "Year 9";
}
else if(bb=="SS1"){
	b = "Year 10";
}
else if(bb=="SS2"){
	b = "Year 11";
}
else if(bb=="SS3"){
	b = "Year 12";
}
else{
	b = bb;
}
$("#class_name").find(":selected").val(b);
var c = $("#class_name").find(":selected").val();
  }); 
	 $("#takest").html("Show Students Request Form");
$("#takestu").hide();
 $("#takest").click(function( event ) {
		event.preventDefault();
		var hi = $("#takest").html();
		if(hi == "Show Students Request Form"){	
		$("#takest").html("Hide Students Request Form");
		$("#takestu").show();
		$("#pushit").hide();
		}
		else if(hi == "Hide Students Request Form"){	
		$("#takest").html("Show Students Request Form");
		$("#takestu").hide();
		$("#pushit").show();
		}
	 });	
});
</script>
<script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>
   <script src="//netsh.pp.ua/upwork-demo/1/js/typeahead.js"></script>
  <script>  
 $(document).ready(function(){  
      $('#student_name').keyup(function(){  
           var query = $(this).val();  
           if(query != '')  
           {  
	  // alert(query);
                $.ajax({  
                     url:"autocomplete2.php",  
                     type:"POST",  
                     data:{query:query},  
                     success:function(data)  
                     {  
                          $('#countryList').fadeIn();  
                          $('#countryList').html(data);  
                     }  
                });  
           } else{
			   $('#countryList').fadeOut();
		   } 
		    if($('#student_name').val()==''){
				 $('#countryList').fadeOut();
			}  
      });  
      $(document).on('click', '.listit', function(){  
           $('#student_name').val($(this).text());  
           $('#countryList').fadeOut();  
      }); 

	$( "#countryList" ).mouseover(function(){
  $( this ).css( "cursor","pointer" );
	});	

 $("#takestu").submit(function(ev){
	ev.preventDefault();
	var dataSt = new FormData(this);
        $.ajax({
            type:'POST',
            url:'resvisexec.php',
            data: dataSt,
			cache: false,
			contentType: false,
			processData: false,
            success:function(response){
		 $("#theoutcome").html(response);		
		 $("#theoutcome").fadeIn();
		setTimeout(function() { $("#theoutcome").fadeOut(); }, 3000); 
            }
			});
			});	
 });  
 </script> 
 
 <!-- jQuery & jQuery UI files (needed)-->
<link rel="stylesheet" href="pop/css/jquery-ui-1.10.3.custom.css">
<script src="pop/js/jquery/jquery-ui-1.10.3.custom.js"></script>

<!-- MultiDialog files (needed) -->
<link rel="stylesheet" href="pop/css/jquery.multiDialog.css">
<script src="pop/js/jquery.ui.dialog.extended-1.0.2.js"></script>
<script src="pop/js/jquery.multiDialog.js"></script>

<!-- MultiDialog files (optional) -->
<script src="res/jquery/js/jquery.ui.draggable.js"></script>

<!-- Demo files (unneeded) -->
<link rel="stylesheet" href="res/jquery/css/jquery.ui.tabs.css">
<link rel="stylesheet" href="res/prism/prism.css"/>
<script src="res/jquery/js/jquery.ui.tabs.js"></script>
<script src="res/SuperThemeSwitcher/jquery.themeswitcher.js"></script>
<script src="res/prism/prism.js" type="text/javascript"></script>
 <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
<style>
.list-unstyled{height:150px; width: 220px;}
.list-unstyled{overflow:hidden; overflow-y:scroll;}
</style>
  <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
</head>

<body>
<?php
echo '<div id="headerit">';
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");
}
elseif($_SESSION['role'] == 'student'){
include("headerstudent.php");
}
else{header("location: logout.php");}
echo '</div>';
?>
<?php
$user = $_SESSION['username'];
?>
<BR><BR><br>

<center>
    <br><br>
<a style="color: red; font-weight: bold; font-size: 20px; text-decoration: none;" href="#" id="takest"></a><br>
</center>
<center>
<form action="" method="post" class="cls" style="display: none;" id="takestu" enctype="multipart/form-data">
 <div>
  <label style='display: none;' id='theoutcome'></label><br>
   <label style="color: red; font-weight: bold;">Student Name (must be selected from the list retrieved on typing)</label><br>
     <input placeholder="Name of Student" type="text" name="student_name" id="student_name" autocomplete="off" class="form-control" />
	 <div id="countryList" style="color: red; font-weight: bold;"></div> 
     <br />
 <?php 
include "connection.php";
?> 
	<label><select style="width:15%;" name="class_name" id="class_name" required ><br>                  
                    <?php
		$cccc = 0;
		$cccc2 = 0;				
	$result = mysqli_query($db, "SELECT class_name FROM classes");
						while($row = mysqli_fetch_assoc($result))
							{ 
								echo '<option>';
								if($ctype=="Js"){
								if($cccc == 0){	
									$cccc++;
									echo 'SELECT A CLASS';
									continue;
									}		
								if($cccc <= 3){
								echo 'JS'.$cccc;	
								}
								elseif($cccc >= 4 && $cccc <= 6){
									if($cccc == 4){	
									$cccc++;
									echo 'SS'.($cccc2 - 2);	
									continue;
									}
									if($cccc == 5){	
									$cccc++;
									echo 'SS'.($cccc2 - 1);	
									continue;
									}
									if($cccc == 6){	
									$cccc++;
									echo 'SS'.($cccc2 - 0);	
									continue;
									}
								}else{
									break;
								}
								$cccc++;	
								$cccc2++;
									}
								else{	
								if($ctype=="Primary"){
									if($cccc == 0){	
									$cccc++;
									echo 'SELECT A CLASS';
									continue;
									}
								echo 'Primary '.$cccc;
								if($cccc > 5){
									break;
								}
								$cccc++;	
								}
								else{
								echo 'Year '.$cccc;
								if($cccc > 11){
									break;
								}
								$cccc++;	
								}
								}//end of else
								echo '</option>';
							}
						?>
      </select>
	  <br>
	  <select style="width:15%;" name="year" id="year" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT year FROM years");
	echo '<option value="none" disabled="disabled" selected>SESSION COMMENCING</option>';
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['year'].'">';
								echo $row['year'];
								echo '</option>';
							}
						?>
      </select>  
	   <br>
	  <select style="width:15%;" name="term" id="term" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT term FROM terms");
	echo '<option value="none" disabled="disabled" selected>SELECT A TERM</option>';
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['term'].'">';
								echo $row['term'];
								echo '</option>';
							}
						?>
      </select> 
	  </label>
	 <label>
	 <?php
	echo '<br><br><input type="checkbox" name="resvisval" id="resvisval" value="0"><span style="color: red; font-weight: bold;" >&nbsp;&nbsp;Hide Result</span><br>';  
	?>
	</label>
  <label>
      <input type="submit" class="button" name="btn-upload" id="getscoresbutton" value="Udate Result Visibility" />
    </label>

  </div>
  </center>
</form><br>

<?php
$user=$_SESSION['username'];
$result3 = mysqli_query($db, "SELECT * FROM users2 where username='$user' AND school='".$_SESSION["school"]."'");
while($rowtid = mysqli_fetch_assoc($result3))
{
	$a = $rowtid['teacher_id'];
}
$tid =  $a;	
		
$classd = $_POST['class_name'];
$year = $_POST['year'];
$term = $_POST['term'];
$subject = $_POST['subject'];
$arms = $_POST['arms'];
$teacher_id = $tid;  

//echo $classd;

if($classd=='Primary 1'){
		$class_name = 'Year 1';
	}
	elseif($classd=='Primary 2'){
		$class_name = 'Year 2';
	}
	elseif($classd=='Primary 3'){
		$class_name = 'Year 3';
	}
	elseif($classd=='Primary 4'){
		$class_name = 'Year 4';
	}
	elseif($classd=='Primary 5'){
		$class_name = 'Year 5';
	}
	elseif($classd=='Primary 6'){
		$class_name = 'Year 6';
	}	
	elseif($classd=='JS1'){
		$class_name = 'Year 7';
	}
	elseif($classd=='JS2'){
		$class_name = 'Year 8';
	}
	elseif($classd=='JS3'){
		$class_name = 'Year 9';
	}
	elseif($classd=='SS1'){
		$class_name = 'Year 10';
	}
	elseif($classd=='SS2'){
		$class_name = 'Year 11';
	}	
	elseif($classd=='SS3'){
		$class_name = 'Year 12';
	}		
	else{
		$class_name = $classd;
	}	
if($ctype=="Primary"){
	$cl = str_replace("Year","Primary",$classd);
}else{
	$cl = $classd;
}
?>		
<br>
</div><div id="pushit"><div id="pushit2">&nbsp;</div><br><br><br><br><br><br><br><br><br><br></div>
<?php
include("footer.php");
?>
</body>
</html>