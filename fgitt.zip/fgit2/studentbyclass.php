<?php
session_start();
include("auth.php");
include "connection.php";

$student_name = $_POST['student_name'];
$teacher_id = $_POST['teacher_id'];
$class = $_POST['class'];
$year = $_POST['year'];
$term = $_POST['term'];
$subject = $_POST['subject'];
$arms = $_POST['arms'];

$result = mysqli_query($db, "SELECT * FROM students where arms='$arms' AND teacher_id='$teacher_id' AND class_name='$class' AND year='$year' AND term='$term' AND subject='$subject' AND school='".$_SESSION["school"]."'");
while($sl3 = mysqli_fetch_assoc($result)){
		  $sl2[] = $sl3['student_name'];
		  }
		  $sl = $sl2;

for ($i = 0; $i <= (count($student_name)-1); $i++){
	if(!in_array($student_name[$i], $sl)){
  $t = mysqli_query($db,"INSERT INTO students(student_name, teacher_id, class_name, arms, year, term, subject, school) VALUES('$student_name[$i]','$teacher_id','$class', '$arms', '$year', '$term', '$subject', '".$_SESSION["school"]."')");
}
}	

if($t){
	//echo "students saved successfully";
	//echo '<meta content="2;index.php" http-equiv="refresh" />';
	echo 1;
}	
else{
	//echo "List of students not saved";
	//echo '<meta content="2;index.php" http-equiv="refresh" />';
	echo 0;
}
	
?>

<?php
// close connection
mysql_close();
?>