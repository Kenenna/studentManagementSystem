<?php
session_start();
include("auth.php");
include "connection.php";
$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
							?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
	<style>
.pbutton {
	background-color:#44c767;
	-moz-border-radius:28px;
	-webkit-border-radius:28px;
	border-radius:5px;
	border:1px solid #18ab29;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:15px;
	padding:6px 24px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
	float: left;
}
.pbutton:hover {
	background-color:#5cbf2a;
}
.pbutton:active {
	position:relative;
	top:1px;
}
</style>
<link rel="stylesheet" href="css/styles.css">
<script src="Chart.js"></script>
<script src="chart.js-php.js"></script>
	
     <script src="gr2/js/jquery.js"></script>
    <script src="gr2/js/highchart.js"></script>
    <script src="gr2/js/exporting.js"></script>
    <script src="gr2/js/jspdf.js"></script>
    <script src="gr2/js/rgbcolor.js"></script>
    <script src="gr2/js/canvg.js"></script>

    <script type="text/javascript">
    </script>
	  
   <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>
  <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
</head>
<body>
<?php
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
elseif($_SESSION['role'] == 'student'){
echo '<ul class="topnav" id="myTopnav">';
echo '<li><a href="teagetresultmid.php">Midterm Result</a></li>';
echo '<li><a href="teagetresult.php">Term Result</a></li>';
echo '<li><a href="newpass.php">Change Pass</a></li>';
echo '<li><a href="logout.php">Logout</a></li>';
echo '<li class="icon">';
echo '<a href="javascript:void(0);" onclick="myFunction()">&#9776;</a>';
echo '</li>';
echo '</ul>';
}
else{ header("location: logout.php");}
?>
    <br><br><br>
    <div id="chart1" class="myChart" style="min-width: 310px; height: 500px; margin: 0 auto"></div>
	<button id="export_all" class="pbutton" >Download</button>
<?php
$class = $_POST['class'];
$year = $_POST['year'];
$term = $_POST['term'];
$student_name = $_POST['student_name'];
$formt = $_POST['formt'];
$arms = $_POST['arms'];
echo '<form action="viewgenatt.php" method="post" style="float: left;">';
echo '<input style="display: none;" readonly="readonly" type="text" id="formt" name="formt" value="'.$formt.'" />';
echo '<input style="display: none;" readonly="readonly" type="text" id="class" name="class" value="'.$class.'" />';
echo '<input style="display: none;" readonly="readonly" type="text" id="arms" name="arms" value="'.$arms.'" />';
echo '<input style="display: none;" readonly="readonly" type="text" id="year" name="year" value="'.$year.'" />'; 
echo '<input style="display: none;" readonly="readonly" type="text" id="term" name="term" value="'.$term.'" />';
echo '<input type="submit" class="pbutton" name="btn-upload2" value="back" />';
echo '</form>';
?>
<?php
$student_name = $_POST['student_name'];
$sex = $_POST['sex'];
$class = $_POST['class'];
$student_name = $_POST['student_name'];
$arms = $_POST['arms'];
$year = $_POST['year'];
$yr = ($year + 1);
$term = $_POST['term'];
	$class_name = $_POST['class'];
	$redateit = $_POST['redateit'];
	$redateit2 = $_POST['redateit2'];
	$redateit3 = $_POST['redateit3'];
	$redateit4 = $_POST['redateit4'];
	$redateit5 = $_POST['redateit5'];
	$redateit6 = $_POST['redateit6'];
	$redateit7 = $_POST['redateit7'];
	$redateit8 = $_POST['redateit8'];
	$redateit9 = $_POST['redateit9'];
	$redateit10 = $_POST['redateit10'];
	$redateit11 = $_POST['redateit11'];
	$redateit12 = $_POST['redateit12'];
	$redateit13 = $_POST['redateit13'];
	$redateit14 = $_POST['redateit14'];
	$stmid = $_POST['stmid'];
	$sttotal = $_POST['sttotal'];

if($class_name=="Year 1"){
		if($ctype=="Primary"){
		$classs = "Primary 1";
		}
		elseif($ctype=="Js"){
		$classs = "JS1";
		}else{
		$classs = "Year 1";
}}	
if($class_name=="Year 2"){
		if($ctype=="Primary"){
		$classs = "Primary 2";
		}
		elseif($ctype=="Js"){
		$classs = "JS2";
		}else{
		$classs = "Year 2";
}}	
if($class_name=="Year 3"){
		if($ctype=="Primary"){
		$classs = "Primary 3";
		}
		elseif($ctype=="Js"){
		$classs = "JS3";
		}else{
		$classs = "Year 3";
}}
if($class_name=="Year 4"){
		if($ctype=="Primary"){
		$classs = "Primary 4";
		}
		elseif($ctype=="Js"){
		$classs = "SS1";
		}else{
		$classs = "Year 4";
}}
if($class_name=="Year 5"){
		if($ctype=="Primary"){
		$classs = "Primary 5";
		}
		elseif($ctype=="Js"){
		$classs = "SS2";
		}else{
		$classs = "Year 5";
}}	
if($class_name=="Year 6"){
		if($ctype=="Primary"){
		$classs = "Primary 6";
		}
		elseif($ctype=="Js"){
		$classs = "SS3";
		}else{
		$classs = "Year 6";
}}			
if($class_name=="Year 7"){
		if($ctype=="Js"){
		$classs = "JS1";
	}else{
		$classs = "Year 7";
}}
if($class_name=="Year 8"){
		if($ctype=="Js"){
		$classs = "JS2";
	}else{
		$classs = "Year 8";
}}
if($class_name=="Year 9"){
		if($ctype=="Js"){
		$classs = "JS3";
	}else{
		$classs = "Year 9";
}}
if($class_name=="Year 10"){
		if($ctype=="Js"){
		$classs = "SS1";
	}else{
		$classs = "Year 10";
}}
if($class_name=="Year 11"){
		if($ctype=="Js"){
		$classs = "SS2";
	}else{
		$classs = "Year 11";
}}
if($class_name=="Year 12"){
		if($ctype=="Js"){
		$classs = "SS3";
	}else{
		$classs = "Year 12";
}}
	
	for($i=0; $i<=(count($student_name)-1); $i++){
	$stu[] = $redateit[$i].",".$redateit2[$i].",".$redateit3[$i].",".$redateit4[$i].",".$redateit5[$i].",".$redateit6[$i].",".$redateit7[$i].",".$redateit8[$i].",".$redateit9[$i].",".$redateit10[$i].",".$redateit11[$i].",".$redateit12[$i].",".$redateit13[$i].",".$redateit14[$i];
	}
	$subit1 = explode(",", $stu[0]);
	$subit2 = explode(",", $stu[1]);
	$subit3 = explode(",", $stu[2]);
	$subit4 = explode(",", $stu[3]);
	$subit5 = explode(",", $stu[4]);
	$subit6 = explode(",", $stu[5]);
	$subit7 = explode(",", $stu[6]);
	$subit8 = explode(",", $stu[7]);
	$subit9 = explode(",", $stu[8]);
	$subit10 = explode(",", $stu[9]);
	$subit11 = explode(",", $stu[10]);
	$subit12 = explode(",", $stu[11]);
	$subit13 = explode(",", $stu[12]);
	$subit14 = explode(",", $stu[13]);
	$subit15 = explode(",", $stu[14]);
	$subit16 = explode(",", $stu[15]);
	$subit17 = explode(",", $stu[16]);
	$subit18 = explode(",", $stu[17]);
	$subit19 = explode(",", $stu[18]);
	$subit20 = explode(",", $stu[19]);
	$subit21 = explode(",", $stu[20]);
	$subit22 = explode(",", $stu[21]);
	$subit23 = explode(",", $stu[22]);
	$subit24 = explode(",", $stu[23]);
	$subit25 = explode(",", $stu[24]);
	$subit26 = explode(",", $stu[25]);
	$subit27 = explode(",", $stu[26]);
	$subit28 = explode(",", $stu[27]);
	$subit29 = explode(",", $stu[28]);
	$subit30 = explode(",", $stu[29]);
	$subit31 = explode(",", $stu[30]);
	$subit32 = explode(",", $stu[31]);
	$subit33 = explode(",", $stu[32]);
	$subit34 = explode(",", $stu[33]);
	$subit35 = explode(",", $stu[34]);
	$subit36 = explode(",", $stu[35]);
	$subit37 = explode(",", $stu[36]);
	$subit38 = explode(",", $stu[37]);
	$subit39 = explode(",", $stu[38]);
	$subit40 = explode(",", $stu[39]);
	$subit41 = explode(",", $stu[40]);
	
$arrweekssss = array($_POST["att1"], $_POST["att2"], $_POST["att3"], $_POST["att4"], $_POST["att5"], $_POST["att6"], $_POST["att7"], $_POST["att8"], $_POST["att9"], $_POST["att10"], $_POST["att11"], $_POST["att12"], $_POST["att13"], $_POST["att14"]);
$arrmids = array($_POST["chmida"], $_POST["chmidb"], $_POST["chmidc"], $_POST["chmidd"], $_POST["chmide"], $_POST["chmidf"], $_POST["chmidg"], $_POST["chmidh"], $_POST["chmidi"], $_POST["chmidj"], $_POST["chmidk"], $_POST["chmidl"], $_POST["chmidm"], $_POST["chmidn"]);
$amid = (array_unique($arrmids));
unset($amid[0]);
foreach( $amid as $key => $valuemid){
	$k = $key;
}
$arrweekssss[$k] = 2020;
$arrweeks = $arrweekssss;

for ($i = 0; $i <= (count($arrweeks)-1); $i++){
	if($arrweeks[$i]==0){
	$arweeks[] = $i.":".$arrweeks[$i]; // the zeros
	}
	if($arrweeks[$i]!=0){
		if($arrweeks[$i]==2020){ $arrweeks[$i]=0; }
	$arweeks2[] = $arrweeks[$i];
	$arweeks22[] = $arrweeks[$i];	// the not zeros
	}
}
$arsweeks = $arweeks2;  // the not zeros
$arssweeks = $arweeks22;

$wkcount = count($arrweeks) - count($arweeks);

$sub1 = array_slice($subit1, 0, $wkcount, true);
$sub2 = array_slice($subit2, 0, $wkcount, true);
$sub3 = array_slice($subit3, 0, $wkcount, true);
$sub4 = array_slice($subit4, 0, $wkcount, true);
$sub5 = array_slice($subit5, 0, $wkcount, true);
$sub6 = array_slice($subit6, 0, $wkcount, true);
$sub7 = array_slice($subit7, 0, $wkcount, true);
$sub8 = array_slice($subit8, 0, $wkcount, true);
$sub9 = array_slice($subit9, 0, $wkcount, true);
$sub10 = array_slice($subit10, 0, $wkcount, true);
$sub11 = array_slice($subit11, 0, $wkcount, true);
$sub12 = array_slice($subit12, 0, $wkcount, true);
$sub13 = array_slice($subit13, 0, $wkcount, true);
$sub14 = array_slice($subit14, 0, $wkcount, true);
$sub15 = array_slice($subit15, 0, $wkcount, true);
$sub16 = array_slice($subit16, 0, $wkcount, true);
$sub17 = array_slice($subit17, 0, $wkcount, true);
$sub18 = array_slice($subit18, 0, $wkcount, true);
$sub19 = array_slice($subit19, 0, $wkcount, true);
$sub20 = array_slice($subit20, 0, $wkcount, true);
$sub21 = array_slice($subit21, 0, $wkcount, true);
$sub22 = array_slice($subit22, 0, $wkcount, true);
$sub23 = array_slice($subit23, 0, $wkcount, true);
$sub24 = array_slice($subit24, 0, $wkcount, true);
$sub25 = array_slice($subit25, 0, $wkcount, true);
$sub26 = array_slice($subit26, 0, $wkcount, true);
$sub27 = array_slice($subit27, 0, $wkcount, true);
$sub28 = array_slice($subit28, 0, $wkcount, true);
$sub29 = array_slice($subit29, 0, $wkcount, true);
$sub30 = array_slice($subit30, 0, $wkcount, true);
$sub31 = array_slice($subit31, 0, $wkcount, true);
$sub32 = array_slice($subit32, 0, $wkcount, true);
$sub33 = array_slice($subit33, 0, $wkcount, true);
$sub34 = array_slice($subit34, 0, $wkcount, true);
$sub35 = array_slice($subit35, 0, $wkcount, true);
$sub36 = array_slice($subit36, 0, $wkcount, true);
$sub37 = array_slice($subit37, 0, $wkcount, true);
$sub38 = array_slice($subit38, 0, $wkcount, true);
$sub39 = array_slice($subit39, 0, $wkcount, true);
$sub40 = array_slice($subit40, 0, $wkcount, true);
$sub41 = array_slice($subit41, 0, $wkcount, true);

if($wkcount == 1){
	$wcount = array("WK1 (".$arssweeks[0]." )");
}
if($wkcount == 2){
	$wcount = array("WK1 (".$arssweeks[0]." )","WK2 (".$arssweeks[1]." )");
}
if($wkcount == 3){
	$wcount = array("WK1 (".$arssweeks[0]." )","WK2 (".$arssweeks[1]." )","WK3 (".$arssweeks[2]." )");
}
if($wkcount == 4){
	$wcount = array("WK1 (".$arssweeks[0]." )","WK2 (".$arssweeks[1]." )","WK3 (".$arssweeks[2]." )","WK4 (".$arssweeks[3]." )");
}
if($wkcount == 5){
	$wcount = array("WK1 (".$arssweeks[0]." )","WK2 (".$arssweeks[1]." )","WK3 (".$arssweeks[2]." )","WK4 (".$arssweeks[3]." )","WK5 (".$arssweeks[4]." )");
	}
if($wkcount == 6){
	$wcount = array("WK1 (".$arssweeks[0]." )","WK2 (".$arssweeks[1]." )","WK3 (".$arssweeks[2]." )","WK4 (".$arssweeks[3]." )","WK5 (".$arssweeks[4]." )","WK6 (".$arssweeks[5]." )");
}
if($wkcount == 7){
	$wcount = array("WK1 (".$arssweeks[0]." )","WK2 (".$arssweeks[1]." )","WK3 (".$arssweeks[2]." )","WK4 (".$arssweeks[3]." )","WK5 (".$arssweeks[4]." )","WK6 (".$arssweeks[5]." )","WK7 (".$arssweeks[6]." )");
}
if($wkcount == 8){
	$wcount = array("WK1 (".$arssweeks[0]." )","WK2 (".$arssweeks[1]." )","WK3 (".$arssweeks[2]." )","WK4 (".$arssweeks[3]." )","WK5 (".$arssweeks[4]." )","WK6 (".$arssweeks[5]." )","WK7 (".$arssweeks[6]." )","WK8 (".$arssweeks[7]." )");
}
if($wkcount == 9){
	$wcount = array("WK1 (".$arssweeks[0]." )","WK2 (".$arssweeks[1]." )","WK3 (".$arssweeks[2]." )","WK4 (".$arssweeks[3]." )","WK5 (".$arssweeks[4]." )","WK6 (".$arssweeks[5]." )","WK7 (".$arssweeks[6]." )","WK8 (".$arssweeks[7]." )","WK9 (".$arssweeks[8]." )");
}
if($wkcount == 10){
	$wcount = array("WK1 (".$arssweeks[0]." )","WK2 (".$arssweeks[1]." )","WK3 (".$arssweeks[2]." )","WK4 (".$arssweeks[3]." )","WK5 (".$arssweeks[4]." )","WK6 (".$arssweeks[5]." )","WK7 (".$arssweeks[6]." )","WK8 (".$arssweeks[7]." )","WK9 (".$arssweeks[8]." )","WK10 (".$arssweeks[9]." )");
}
if($wkcount == 11){
	$wcount = array("WK1 (".$arssweeks[0]." )","WK2 (".$arssweeks[1]." )","WK3 (".$arssweeks[2]." )","WK4 (".$arssweeks[3]." )","WK5 (".$arssweeks[4]." )","WK6 (".$arssweeks[5]." )","WK7 (".$arssweeks[6]." )","WK8 (".$arssweeks[7]." )","WK9 (".$arssweeks[8]." )","WK10 (".$arssweeks[9]." )","WK11 (".$arssweeks[10]." )");
}
if($wkcount == 12){
	$wcount = array("WK1 (".$arssweeks[0]." )","WK2 (".$arssweeks[1]." )","WK3 (".$arssweeks[2]." )","WK4 (".$arssweeks[3]." )","WK5 (".$arssweeks[4]." )","WK6 (".$arssweeks[5]." )","WK7 (".$arssweeks[6]." )","WK8 (".$arssweeks[7]." )","WK9 (".$arssweeks[8]." )","WK10 (".$arssweeks[9]." )","WK11 (".$arssweeks[10]." )","WK12 (".$arssweeks[11]." )");
}
if($wkcount == 13){
	$wcount = array("WK1 (".$arssweeks[0]." )","WK2 (".$arssweeks[1]." )","WK3 (".$arssweeks[2]." )","WK4 (".$arssweeks[3]." )","WK5 (".$arssweeks[4]." )","WK6 (".$arssweeks[5]." )","WK7 (".$arssweeks[6]." )","WK8 (".$arssweeks[7]." )","WK9 (".$arssweeks[8]." )","WK10 (".$arssweeks[9]." )","WK11 (".$arssweeks[10]." )","WK12 (".$arssweeks[11]." )","WK13 (".$arssweeks[12]." )");
}
if($wkcount == 14){
	$wcount = array("WK1 (".$arssweeks[0]." )","WK2 (".$arssweeks[1]." )","WK3 (".$arssweeks[2]." )","WK4 (".$arssweeks[3]." )","WK5 (".$arssweeks[4]." )","WK6 (".$arssweeks[5]." )","WK7 (".$arssweeks[6]." )","WK8 (".$arssweeks[7]." )","WK9 (".$arssweeks[8]." )","WK10 (".$arssweeks[9]." )","WK11 (".$arssweeks[10]." )","WK12 (".$arssweeks[11]." )","WK13 (".$arssweeks[12]." )","WK14 (".$arssweeks[13]." )");
}
if($wkcount == 15){
	$wcount = array("WK1 (".$arssweeks[0]." )","WK2 (".$arssweeks[1]." )","WK3 (".$arssweeks[2]." )","WK4 (".$arssweeks[3]." )","WK5 (".$arssweeks[4]." )","WK6 (".$arssweeks[5]." )","WK7 (".$arssweeks[6]." )","WK8 (".$arssweeks[7]." )","WK9 (".$arssweeks[8]." )","WK10 (".$arssweeks[9]." )","WK11 (".$arssweeks[10]." )","WK12 (".$arssweeks[11]." )","WK13 (".$arssweeks[12]." )","WK14 (".$arssweeks[13]." )","WK15 (".$arssweeks[14]." )");
}

$su = $student_name;
//print_r($student_name);

?>
    <script>
    $(document).ready(function() {
        // create canvas function from highcharts example http://jsfiddle.net/highcharts/PDnmQ/
        (function(H) {
            H.Chart.prototype.createCanvas = function(divId) {
                var svg = this.getSVG(),
                    width = parseInt(svg.match(/width="([0-9]+)"/)[1]),
                    height = parseInt(svg.match(/height="([0-9]+)"/)[1]),
                    canvas = document.createElement('canvas');

                canvas.setAttribute('width', width);
                canvas.setAttribute('height', height);

                if (canvas.getContext && canvas.getContext('2d')) {

                    canvg(canvas, svg);

                    return canvas.toDataURL("image/jpeg");

                } 
                else {
                    alert("Your browser doesn't support this feature, please use a modern browser");
                    return false;
                }

            }
        }(Highcharts));

        $('#export_all').click(function() {
            var doc = new jsPDF();

            // chart height defined here so each chart can be palced
            // in a different position
            var chartHeight = 80;

            // All units are in the set measurement for the document
            // This can be changed to "pt" (points), "mm" (Default), "cm", "in"
            doc.setFontSize(40);
            doc.text(35, 25, "Attendance");

            //loop through each chart
            $('.myChart').each(function(index) {
                var imageData = $(this).highcharts().createCanvas();

                // add image to doc, if you have lots of charts,
                // you will need to check if you have gone bigger 
                // than a page and do doc.addPage() before adding 
                // another image.

                /**
                 * addImage(imagedata, type, x, y, width, height)
                 */
                doc.addImage(imageData, 'JPEG', 45, (index * chartHeight) + 40, 120, chartHeight);
            });


            //save with name
            doc.save('attendance.pdf');
        });

		var rweek = <?php echo json_encode($wkcount); ?>;
		var classs = <?php echo json_encode($classs); ?>;
		var arms = <?php echo json_encode($arms); ?>;
		var year = <?php echo json_encode($year); ?>;
		var yr = <?php echo json_encode($yr); ?>;
		var term = <?php echo json_encode($term); ?>;
		var countstud = <?php echo json_encode(count($student_name)); ?>;
		var schoool = <?php echo json_encode($_SESSION['school']); ?>;
		if(rweek == 1){
		var w = <?php echo json_encode($wcount); ?>;
		}
		if(rweek == 2){
		var w = <?php echo json_encode($wcount); ?>;
		}
		if(rweek == 3){
		var w = <?php echo json_encode($wcount); ?>;
		}
		if(rweek == 4){
		var w = <?php echo json_encode($wcount); ?>;
		}
		if(rweek == 5){
		var w = <?php echo json_encode($wcount); ?>;
		}
		if(rweek == 6){
		var w = <?php echo json_encode($wcount); ?>;
		}
		if(rweek == 7){
		var w = <?php echo json_encode($wcount); ?>;
		}
		if(rweek == 8){
		var w = <?php echo json_encode($wcount); ?>;
		}
		if(rweek == 9){
		var w = <?php echo json_encode($wcount); ?>;
		}
		if(rweek == 10){
		var w = <?php echo json_encode($wcount); ?>;
		}
		if(rweek == 11){
		var w = <?php echo json_encode($wcount); ?>;
		}
		if(rweek == 12){
		var w = <?php echo json_encode($wcount); ?>;
		}
		if(rweek == 13){
		var w = <?php echo json_encode($wcount); ?>;
		}
		if(rweek == 14){
		var w = <?php echo json_encode($wcount); ?>;
		}
		if(rweek == 15){
		var w = <?php echo json_encode($wcount); ?>;
		}
		var sublab1 = <?php echo json_encode($su[0]); ?>;
		var sublab2 = <?php echo json_encode($su[1]); ?>;
		var sublab3 = <?php echo json_encode($su[2]); ?>;
		var sublab4 = <?php echo json_encode($su[3]); ?>;	
		var sublab5 = <?php echo json_encode($su[4]); ?>;
		var sublab6 = <?php echo json_encode($su[5]); ?>;
		var sublab7 = <?php echo json_encode($su[6]); ?>;
		var sublab8 = <?php echo json_encode($su[7]); ?>;
		var sublab9 = <?php echo json_encode($su[8]); ?>;
		var sublab10 = <?php echo json_encode($su[9]); ?>;
		var sublab11 = <?php echo json_encode($su[10]); ?>;
		var sublab12 = <?php echo json_encode($su[11]); ?>;	
		var sublab13 = <?php echo json_encode($su[12]); ?>;
		var sublab14 = <?php echo json_encode($su[13]); ?>;
		var sublab15 = <?php echo json_encode($su[14]); ?>;
		var sublab16 = <?php echo json_encode($su[15]); ?>;
		var sublab17 = <?php echo json_encode($su[16]); ?>;	
		var sublab18 = <?php echo json_encode($su[17]); ?>;
		var sublab19 = <?php echo json_encode($su[18]); ?>;
		var sublab20 = <?php echo json_encode($su[19]); ?>;
		var sublab21 = <?php echo json_encode($su[20]); ?>;
		var sublab22 = <?php echo json_encode($su[21]); ?>;
		var sublab23 = <?php echo json_encode($su[22]); ?>;
		var sublab24 = <?php echo json_encode($su[23]); ?>;
		var sublab25 = <?php echo json_encode($su[24]); ?>;
		var sublab26 = <?php echo json_encode($su[25]); ?>;
		var sublab27 = <?php echo json_encode($su[26]); ?>;	
		var sublab28 = <?php echo json_encode($su[27]); ?>;
		var sublab29 = <?php echo json_encode($su[28]); ?>;
		var sublab30 = <?php echo json_encode($su[29]); ?>;
		var sublab31 = <?php echo json_encode($su[30]); ?>;
        
		var s1 = <?php echo json_encode($sub1); ?>;	
		var s2 = <?php echo json_encode($sub2); ?>;	
		var s3 = <?php echo json_encode($sub3); ?>;	
		var s4 = <?php echo json_encode($sub4); ?>;	
		var s5 = <?php echo json_encode($sub5); ?>;	
		var s6 = <?php echo json_encode($sub6); ?>;	
		var s7 = <?php echo json_encode($sub7); ?>;	
		var s8 = <?php echo json_encode($sub8); ?>;	
		var s9 = <?php echo json_encode($sub9); ?>;	
		var s10 = <?php echo json_encode($sub10); ?>;	
		var s11 = <?php echo json_encode($sub11); ?>;	
		var s12 = <?php echo json_encode($sub12); ?>;	
		var s13 = <?php echo json_encode($sub13); ?>;	
		var s14 = <?php echo json_encode($sub14); ?>;	
		var s15 = <?php echo json_encode($sub15); ?>;	
		var s16 = <?php echo json_encode($sub16); ?>;	
		var s17 = <?php echo json_encode($sub17); ?>;	
		var s18 = <?php echo json_encode($sub18); ?>;	
		var s19 = <?php echo json_encode($sub19); ?>;	
		var s20 = <?php echo json_encode($sub20); ?>;	
		var s21 = <?php echo json_encode($sub21); ?>;	
		var s22 = <?php echo json_encode($sub22); ?>;
		var s23 = <?php echo json_encode($sub23); ?>;	
		var s24 = <?php echo json_encode($sub24); ?>;	
		var s25 = <?php echo json_encode($sub25); ?>;
		var s26 = <?php echo json_encode($sub26); ?>;	
		var s27 = <?php echo json_encode($sub27); ?>;
		var s28 = <?php echo json_encode($sub28); ?>;	
		var s29 = <?php echo json_encode($sub29); ?>;	
		var s30 = <?php echo json_encode($sub30); ?>;
		var s31 = <?php echo json_encode($sub31); ?>;		
		
		var array1 = JSON.parse("[" + s1 + "]");
		var array2 = JSON.parse("[" + s2 + "]");
		var array3 = JSON.parse("[" + s3 + "]");
		var array4 = JSON.parse("[" + s4 + "]");
		var array5 = JSON.parse("[" + s5 + "]");
		var array6 = JSON.parse("[" + s6 + "]");
		var array7 = JSON.parse("[" + s7 + "]");
		var array8 = JSON.parse("[" + s8 + "]");
		var array9 = JSON.parse("[" + s9 + "]");
		var array10 = JSON.parse("[" + s10 + "]");
		var array11 = JSON.parse("[" + s11 + "]");
		var array12 = JSON.parse("[" + s12 + "]");
		var array13 = JSON.parse("[" + s13 + "]");
		var array14 = JSON.parse("[" + s14 + "]");
		var array15 = JSON.parse("[" + s15 + "]");
		var array16 = JSON.parse("[" + s16 + "]");
		var array17 = JSON.parse("[" + s17 + "]");
		var array18 = JSON.parse("[" + s18 + "]");
		var array19 = JSON.parse("[" + s19 + "]");
		var array20 = JSON.parse("[" + s20 + "]");
		var array21 = JSON.parse("[" + s21 + "]");
		var array22 = JSON.parse("[" + s22 + "]");
		var array23 = JSON.parse("[" + s23 + "]");
		var array24 = JSON.parse("[" + s24 + "]");
		var array25 = JSON.parse("[" + s25 + "]");
		var array26 = JSON.parse("[" + s26 + "]");
		var array27 = JSON.parse("[" + s27 + "]");
		var array28 = JSON.parse("[" + s28 + "]");
		var array29 = JSON.parse("[" + s29 + "]");
		var array30 = JSON.parse("[" + s30 + "]");
		
		if(countstud == 1){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }];
		};
		if(countstud == 2){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }];
		};
		if(countstud == 3){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }];
		};
		if(countstud == 4){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }];
		};
		if(countstud == 5){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }];
		};
		if(countstud == 6){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }];
		};
		if(countstud == 7){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }];
		};
		if(countstud == 8){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }, {
                name: sublab8,
                data: array8
            }];
		};
		if(countstud == 9){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }, {
                name: sublab8,
                data: array8
            }, {
                name: sublab9,
                data: array9
            }];
		};
		if(countstud == 10){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }, {
                name: sublab8,
                data: array8
            }, {
                name: sublab9,
                data: array9
            }, {
                name: sublab10,
                data: array10
            }];
		};
		if(countstud == 11){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }, {
                name: sublab8,
                data: array8
            }, {
                name: sublab9,
                data: array9
            }, {
                name: sublab10,
                data: array10
            }, {
                name: sublab11,
                data: array11
            }];
		};
		if(countstud == 12){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }, {
                name: sublab8,
                data: array8
            }, {
                name: sublab9,
                data: array9
            }, {
                name: sublab10,
                data: array10
            }, {
                name: sublab11,
                data: array11
            }, {
                name: sublab12,
                data: array12
            }];
		};
		if(countstud == 13){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }, {
                name: sublab8,
                data: array8
            }, {
                name: sublab9,
                data: array9
            }, {
                name: sublab10,
                data: array10
            }, {
                name: sublab11,
                data: array11
            }, {
                name: sublab12,
                data: array12
            }, {
                name: sublab13,
                data: array13
            }];
		};
		if(countstud == 14){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }, {
                name: sublab8,
                data: array8
            }, {
                name: sublab9,
                data: array9
            }, {
                name: sublab10,
                data: array10
            }, {
                name: sublab11,
                data: array11
            }, {
                name: sublab12,
                data: array12
            }, {
                name: sublab13,
                data: array13
            }, {
                name: sublab14,
                data: array14
            }];
		};
		if(countstud == 15){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }, {
                name: sublab8,
                data: array8
            }, {
                name: sublab9,
                data: array9
            }, {
                name: sublab10,
                data: array10
            }, {
                name: sublab11,
                data: array11
            }, {
                name: sublab12,
                data: array12
            }, {
                name: sublab13,
                data: array13
            }, {
                name: sublab14,
                data: array14
            }, {
                name: sublab15,
                data: array15
            }];
		};
		if(countstud == 16){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }, {
                name: sublab8,
                data: array8
            }, {
                name: sublab9,
                data: array9
            }, {
                name: sublab10,
                data: array10
            }, {
                name: sublab11,
                data: array11
            }, {
                name: sublab12,
                data: array12
            }, {
                name: sublab13,
                data: array13
            }, {
                name: sublab14,
                data: array14
            }, {
                name: sublab15,
                data: array15
            }, {
                name: sublab16,
                data: array16
            }];
		};
		if(countstud == 17){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }, {
                name: sublab8,
                data: array8
            }, {
                name: sublab9,
                data: array9
            }, {
                name: sublab10,
                data: array10
            }, {
                name: sublab11,
                data: array11
            }, {
                name: sublab12,
                data: array12
            }, {
                name: sublab13,
                data: array13
            }, {
                name: sublab14,
                data: array14
            }, {
                name: sublab15,
                data: array15
            }, {
                name: sublab16,
                data: array16
            }, {
                name: sublab17,
                data: array17
            }];
		};
		if(countstud == 18){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }, {
                name: sublab8,
                data: array8
            }, {
                name: sublab9,
                data: array9
            }, {
                name: sublab10,
                data: array10
            }, {
                name: sublab11,
                data: array11
            }, {
                name: sublab12,
                data: array12
            }, {
                name: sublab13,
                data: array13
            }, {
                name: sublab14,
                data: array14
            }, {
                name: sublab15,
                data: array15
            }, {
                name: sublab16,
                data: array16
            }, {
                name: sublab17,
                data: array17
            }, {
                name: sublab18,
                data: array18
            }];
		};
		if(countstud == 19){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }, {
                name: sublab8,
                data: array8
            }, {
                name: sublab9,
                data: array9
            }, {
                name: sublab10,
                data: array10
            }, {
                name: sublab11,
                data: array11
            }, {
                name: sublab12,
                data: array12
            }, {
                name: sublab13,
                data: array13
            }, {
                name: sublab14,
                data: array14
            }, {
                name: sublab15,
                data: array15
            }, {
                name: sublab16,
                data: array16
            }, {
                name: sublab17,
                data: array17
            }, {
                name: sublab18,
                data: array18
            }, {
                name: sublab19,
                data: array19
            }];
		};
		if(countstud == 20){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }, {
                name: sublab8,
                data: array8
            }, {
                name: sublab9,
                data: array9
            }, {
                name: sublab10,
                data: array10
            }, {
                name: sublab11,
                data: array11
            }, {
                name: sublab12,
                data: array12
            }, {
                name: sublab13,
                data: array13
            }, {
                name: sublab14,
                data: array14
            }, {
                name: sublab15,
                data: array15
            }, {
                name: sublab16,
                data: array16
            }, {
                name: sublab17,
                data: array17
            }, {
                name: sublab18,
                data: array18
            }, {
                name: sublab19,
                data: array19
            }, {
                name: sublab20,
                data: array20
            }];
		};
		if(countstud == 21){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }, {
                name: sublab8,
                data: array8
            }, {
                name: sublab9,
                data: array9
            }, {
                name: sublab10,
                data: array10
            }, {
                name: sublab11,
                data: array11
            }, {
                name: sublab12,
                data: array12
            }, {
                name: sublab13,
                data: array13
            }, {
                name: sublab14,
                data: array14
            }, {
                name: sublab15,
                data: array15
            }, {
                name: sublab16,
                data: array16
            }, {
                name: sublab17,
                data: array17
            }, {
                name: sublab18,
                data: array18
            }, {
                name: sublab19,
                data: array19
            }, {
                name: sublab20,
                data: array20
            }, {
                name: sublab21,
                data: array21
            }];
		};
		if(countstud == 22){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }, {
                name: sublab8,
                data: array8
            }, {
                name: sublab9,
                data: array9
            }, {
                name: sublab10,
                data: array10
            }, {
                name: sublab11,
                data: array11
            }, {
                name: sublab12,
                data: array12
            }, {
                name: sublab13,
                data: array13
            }, {
                name: sublab14,
                data: array14
            }, {
                name: sublab15,
                data: array15
            }, {
                name: sublab16,
                data: array16
            }, {
                name: sublab17,
                data: array17
            }, {
                name: sublab18,
                data: array18
            }, {
                name: sublab19,
                data: array19
            }, {
                name: sublab20,
                data: array20
            }, {
                name: sublab21,
                data: array21
            }, {
                name: sublab22,
                data: array22
            }];
		};
		if(countstud == 23){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }, {
                name: sublab8,
                data: array8
            }, {
                name: sublab9,
                data: array9
            }, {
                name: sublab10,
                data: array10
            }, {
                name: sublab11,
                data: array11
            }, {
                name: sublab12,
                data: array12
            }, {
                name: sublab13,
                data: array13
            }, {
                name: sublab14,
                data: array14
            }, {
                name: sublab15,
                data: array15
            }, {
                name: sublab16,
                data: array16
            }, {
                name: sublab17,
                data: array17
            }, {
                name: sublab18,
                data: array18
            }, {
                name: sublab19,
                data: array19
            }, {
                name: sublab20,
                data: array20
            }, {
                name: sublab21,
                data: array21
            }, {
                name: sublab22,
                data: array22
            }, {
                name: sublab23,
                data: array23
            }];
		};
		if(countstud == 24){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }, {
                name: sublab8,
                data: array8
            }, {
                name: sublab9,
                data: array9
            }, {
                name: sublab10,
                data: array10
            }, {
                name: sublab11,
                data: array11
            }, {
                name: sublab12,
                data: array12
            }, {
                name: sublab13,
                data: array13
            }, {
                name: sublab14,
                data: array14
            }, {
                name: sublab15,
                data: array15
            }, {
                name: sublab16,
                data: array16
            }, {
                name: sublab17,
                data: array17
            }, {
                name: sublab18,
                data: array18
            }, {
                name: sublab19,
                data: array19
            }, {
                name: sublab20,
                data: array20
            }, {
                name: sublab21,
                data: array21
            }, {
                name: sublab22,
                data: array22
            }, {
                name: sublab23,
                data: array23
            }, {
                name: sublab24,
                data: array24
            }];
		};
		if(countstud == 25){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }, {
                name: sublab8,
                data: array8
            }, {
                name: sublab9,
                data: array9
            }, {
                name: sublab10,
                data: array10
            }, {
                name: sublab11,
                data: array11
            }, {
                name: sublab12,
                data: array12
            }, {
                name: sublab13,
                data: array13
            }, {
                name: sublab14,
                data: array14
            }, {
                name: sublab15,
                data: array15
            }, {
                name: sublab16,
                data: array16
            }, {
                name: sublab17,
                data: array17
            }, {
                name: sublab18,
                data: array18
            }, {
                name: sublab19,
                data: array19
            }, {
                name: sublab20,
                data: array20
            }, {
                name: sublab21,
                data: array21
            }, {
                name: sublab22,
                data: array22
            }, {
                name: sublab23,
                data: array23
            }, {
                name: sublab24,
                data: array24
            }, {
                name: sublab25,
                data: array25
            }];
		};
		if(countstud == 26){
		var varseries =	[{
				name: sublab1,
                data:  array1					
            }, {
                name: sublab2,
                data: array2
            }, {
                name: sublab3,
                data: array3
            }, {
                name: sublab4,
                data: array4
            }, {
                name: sublab5,
                data: array5
            }, {
                name: sublab6,
                data: array6
            }, {
                name: sublab7,
                data: array7
            }, {
                name: sublab8,
                data: array8
            }, {
                name: sublab9,
                data: array9
            }, {
                name: sublab10,
                data: array10
            }, {
                name: sublab11,
                data: array11
            }, {
                name: sublab12,
                data: array12
            }, {
                name: sublab13,
                data: array13
            }, {
                name: sublab14,
                data: array14
            }, {
                name: sublab15,
                data: array15
            }, {
                name: sublab16,
                data: array16
            }, {
                name: sublab17,
                data: array17
            }, {
                name: sublab18,
                data: array18
            }, {
                name: sublab19,
                data: array19
            }, {
                name: sublab20,
                data: array20
            }, {
                name: sublab21,
                data: array21
            }, {
                name: sublab22,
                data: array22
            }, {
                name: sublab23,
                data: array23
            }, {
                name: sublab24,
                data: array24
            }, {
                name: sublab25,
                data: array25
            }, {
                name: sublab26,
                data: array26
            }];
		};
        $('#chart1').highcharts({
            navigation: {
                buttonOptions: {
                    enabled: false
                }
            },
            title: {
				text: 'ATTENDANCE CHART OF STUDENTS IN '+classs.toUpperCase()+' '+arms.toUpperCase()+', '+term.toUpperCase()+' '+year+'/'+yr+' SESSION',
				x: -20 //center
            },
            subtitle: {
                text: '',
                x: -20
            },
            xAxis: {
              categories: w
            },
            yAxis: {
                title: {
                    text: 'no of times present'
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                valueSuffix: ''
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle',
                borderWidth: 0
            },
         series: varseries
        });
    });
    </script>
	<?php
	include("footer.php");
	?>
</body>

</html>
