<?php
	session_start();
	include("check.php");	
	include 'connection.php';
$score_id = $_POST['score_id'];	
$student_name = $_POST['student_name'];
$class_name = $_POST['class_name'];
$year = $_POST['year'];
$term = $_POST['term'];
$subject = $_POST['subject'];
$teacher_id = $_POST['teacher_id'];
$scoremid2 = $_POST['scoremid'];
$scoremidraw2 = $_POST['scoremidraw'];


$class_names = $_POST['class_name'][0];
$years = $_POST['year'][0];
$armss = $_POST['arms'][0];
$terms = $_POST['term'][0];
$subjects = $_POST['subject'][0];
$teacher_ids = $_POST['teacher_id'][0];


$hwraw2 = $_POST['hwraw'];
$cwraw2 = $_POST['cwraw'];
$testraw2 = $_POST['testraw'];
$examraw2 = $_POST['examraw'];

$remark = $_POST['remark'];
$hwmaxname = $_POST['hwmaxname'];
$cwmaxname = $_POST['cwmaxname'];
$testmaxname = $_POST['testmaxname'];
$exammaxname = $_POST['exammaxname'];


for ($i = 0; $i <= (count($score_id)-1); $i++){
	$hw[$i] = round(($hwraw2[$i]/$hwmaxname[$i])*30);
	$cw[$i] = round(($cwraw2[$i]/$cwmaxname[$i])*30);
	$test[$i] = round((($testraw2[$i]/$testmaxname[$i])*40));
	if($scoremid2!=null AND $scoremidraw2!=null){
	$caraw[$i] = ((($hwraw2[$i])+($cwraw2[$i])+($testraw2[$i]))+($scoremidraw2[$i]));
	$ca[$i] = round((($hw[$i]+$cw[$i]+$test[$i]+$scoremid2[$i])/200)*40);
	}
	else{
	$caraw[$i] = ((($hwraw2[$i])+($cwraw2[$i])+($testraw2[$i])));
	$ca[$i] = round((($hw[$i]+$cw[$i]+$test[$i])/100)*40);	
	}
	$exam[$i] = round(($examraw2[$i]/$exammaxname[$i])*60);
	$score[$i] = round(($ca[$i])+($exam[$i]));
$sql1=mysqli_query($db,"UPDATE scores SET score='$score[$i]', scoremid='$scoremid2[$i]', scoremidraw='$scoremidraw2[$i]', hwraw='$hwraw2[$i]', cwraw='$cwraw2[$i]', testraw='$testraw2[$i]', caraw='$caraw[$i]', examraw='$examraw2[$i]', hw='$hw[$i]', cw='$cw[$i]', test='$test[$i]', ca='$ca[$i]', exam='$exam[$i]', student_name='$student_name[$i]', remark='$remark[$i]', hwmaxname='$hwmaxname[$i]', cwmaxname='$cwmaxname[$i]', testmaxname='$testmaxname[$i]', exammaxname='$exammaxname[$i]' WHERE score_id='$score_id[$i]' AND school='".$_SESSION["school"]."'");
}

if($sql1){
$resultcheck = mysqli_query($db, "SELECT * FROM scores where arms='$armss' AND class_name='$class_names' AND year='$years' AND term='$terms' AND subject='$subjects' AND teacher_id='$teacher_ids' AND school='".$_SESSION["school"]."' ORDER BY student_name ASC");
		$idstr="";
		$totstr = "";
		$midtotstr = "";
		$midrawstr="";
		$carawstr="";
		$hwstr="";
		$cwstr="";
		$teststr="";
		$castr="";
		$examstr="";
		$stunamestr="";
		while($rowcheck = mysqli_fetch_assoc($resultcheck))
							{  
								$id2[] = $rowcheck['score_id'];
								$tot2[] = $rowcheck['score'];
								$midtot2[] = $rowcheck['scoremid'];
								$midraw2[] = $rowcheck['scoremidraw'];
								$caraw2[] = $rowcheck['caraw'];
								$hw2[] = $rowcheck['hw'];
								$cw2[] = $rowcheck['cw'];
								$test2[] = $rowcheck['test'];
								$ca2[] = $rowcheck['ca'];
								$exam2[] = $rowcheck['exam'];
								$student_name2[] = $rowcheck['student_name'];
							}					
							
for ($x = 0; $x <= (count($id2)-1); $x++){
	if($x==(count($id2)-1)){
$idstr .= $id2[$x];	
$totstr .= $tot2[$x];
$midtotstr .= $midtot2[$x];
$midrawstr .= $midraw2[$x];
$carawstr .= $caraw2[$x];
$hwstr .= $hw2[$x];
$cwstr .= $cw2[$x];
$teststr .= $test2[$x];
$castr .= $ca2[$x];
$examstr .= $exam2[$x];
$stunamestr .= $student_name2[$x];
	}else{
$idstr .= $id2[$x]."-";	
$totstr .= $tot2[$x]."-";
$midtotstr .= $midtot2[$x]."-";
$midrawstr .= $midraw2[$x]."-";
$carawstr .= $caraw2[$x]."-";
$hwstr .= $hw2[$x]."-";
$cwstr .= $cw2[$x]."-";
$teststr .= $test2[$x]."-";
$castr .= $ca2[$x]."-";
$examstr .= $exam2[$x]."-";
$stunamestr .= $student_name2[$x]."-";	
	}
}	
	echo $idstr."|".$totstr."|".$midtotstr."|".$midrawstr."|".$carawstr."|".$hwstr."|".$cwstr."|".$teststr."|".$castr."|".$examstr."|".$stunamestr."|"."1";	
}	
else{
	//echo "not updated";
	//echo '<meta content="2;update-score.php" http-equiv="refresh" />';
	echo 0;
}
?>