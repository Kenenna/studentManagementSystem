<?php
session_start();
	include("auth.php");
	include("connection.php");
 if(isset($_POST["query"]))  
 {  
      $output = '';  	  
      $query = "SELECT regstu.student_name, img.img FROM regstu INNER JOIN img ON regstu.student_name=img.student_name WHERE regstu.student_name LIKE '%".$_POST["query"]."%' AND regstu.school='".$_SESSION["school"]."'";  
      $result = mysqli_query($db, $query);  
      $output = '<ul class="list-unstyled">'; 
	  
      if(mysqli_num_rows($result) > 0)  
      {  
           while($row = mysqli_fetch_array($result))  
           {  
                $output .= '<li style="width: 100%; list-style-type: none;" class="listit">'.$row["student_name"].'<img src="'.$row['img'].'" height="50" weight="55" /></li>';  
           }  
      }  
      else  
      {  
           $output .= '<li class="listit">Student not on record</li>';  
      }  
      $output .= '</ul>';  
      echo $output;  
 }  
?>