<?php
	include("check.php");	
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Home</title>
<link rel="stylesheet" href="style.css" type="text/css" />

<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript">
$(function() {
$(".submit_button").click(function() {
var student_id = $("#student_id").val();
var student_name = $("#student_name").val();
var class_id = $("#class_id").val();
var year_id = $("#year_id").val();
var term_id = $("#term_id").val();
var subject_id = $("#subject_id").val();
var score = $("#score").val();
var dataString[] = 'student_id='+ student_id[]+'student_name='+ student_name[]+'class_id='+ class_id[]+'year_id='+ year_id[]+'term_id='+ term_id[]+'subject_id='+ subject_id[]+'score='+ score[];
if(score=='')
{
alert("Enter a score");
$("#score").focus();
}
else
{
$("#flash").show();
$("#flash").fadeIn(400).html('<span class="load">Loading..</span>');
$.ajax({
type: "POST",
url: "teacher-student_exec.php",
data: dataString[],
cache: true,
success: function(html){
$("#show").after(html);
document.getElementById('student_id').value='';
document.getElementById('student_name').value='';
document.getElementById('class_id').value='';
document.getElementById('year_id').value='';
document.getElementById('term_id').value='';
document.getElementById('subject_id').value='';
document.getElementById('score').value='';
$("#flash").hide();
$("#student_id").focus();
$("#student_name").focus();
$("#class_id").focus();
$("#year_id").focus();
$("#term_id").focus();
$("#subject_id").focus();
$("#score").focus();
}  
});
}
return false;
});
});
</script>


</head>

<body>
<h1 class="hello">Hello, <em><?php echo $login_user;?>!</em></h1>



<form action="" method="post" enctype="multipart/form-data">
<center>
 <div>
   
	<label><select style="width:15%;" name="class" id="class" required ><br>
                   
                    <?php
	include "connection.php";
	$result = mysqli_query($db, "SELECT * FROM classes");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['class_name'].'">';
								echo $row['class_name'];
								echo '</option>';
							}
						?>
      </select>
	  
	  <br><br>
	  <select style="width:15%;" name="year" id="year" required ><br>
                   
                    <?php
	include "connection.php";
	$result = mysqli_query($db, "SELECT * FROM years");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['year'].'">';
								echo $row['year'];
								echo '</option>';
							}
						?>
      </select>
	  
	  
	   <br><br>
	  <select style="width:15%;" name="term" id="term" required ><br>
                   
                    <?php
	include "connection.php";
	$result = mysqli_query($db, "SELECT * FROM terms");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['term'].'">';
								echo $row['term'];
								echo '</option>';
							}
						?>
      </select>
	   <br><br>
	  <select style="width:15%;" name="subject" id="subject" required ><br>
                   
                    <?php
	include "connection.php";
	$result = mysqli_query($db, "SELECT * FROM subjects");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['subject'].'">';
								echo $row['subject'];
								echo '</option>';
							}
						?>
      </select>
	  </label>
	  
  <label><br><br>
      <input type="submit" class="button" name="btn-upload" value="Submit Form" />
    </label>

  </div>
  </center><BR><BR>
</form><br>



<?php
if(isset($_POST['btn-upload'])){
$class = $_POST['class'];
$year = $_POST['year'];
$term = $_POST['term'];
$subject = $_POST['subject'];
$teacher_id = $_POST['teacher_id'];
echo '<div class="container">';
'<div class="main">';
echo '<form method="POST" action="teacher-student_exec.php" id="myform">';
echo '<center>';
 echo '<div>';
 echo  '<h1>Collect teacher\'s students :</h1>';
   
echo '<label><span>Enter Scores</span><br><br>';            
	include "connection.php";
	$result = mysqli_query($db, "SELECT * FROM students where class_name='$class' AND year='$year' AND term='$term' AND subject='$subject' AND teacher_id='1'");
						echo '<form method="POST" name="form" action="">';
						echo '<table><tr><td>Students Names</td><td>Scores</td></tr>';
						while($row = mysqli_fetch_assoc($result))
							{  
							 echo '<input type="hidden" name="student_id[]" id="student_id" value="'.$row['student_id'].'">';
							 echo '<tr><td><input type="text" name="student_name[]" id="student_name" value="'.$row['student_name'].'"></td><td><input type="text" name="score[]" id="score" /></td></tr>';
							 echo '<input type="hidden" name="class_id[]" id="class_id" value="'.$row['class_id'].'">';
							 echo '<input type="hidden" name="year_id[]" id="year_id" value="'.$row['year_id'].'">';
							 echo '<input type="hidden" name="term_id[]" id="term_id" value="'.$row['term_id'].'">';
							 echo '<input type="hidden" name="subject_id[]" id="subject_id" value="'.$row['subject_id'].'">';
							 echo '<input type="hidden" name="teacher_id[]" id="teacher_id" value="'.$row['teacher_id'].'">';
							 //echo '<input type="text" name="score[]" id="score" />';
							//echo  '<br>';
							
							}
		
	
	 echo '</label>';
	  
  echo '<label><br>';
   echo   '<tr><td></td><td><input type="submit" class="submit_button" name="submit" value="Submit Scores" /></td></tr></table>';
  echo '</label></div></center></form></div>';
echo '<div class="space"></div>';
echo '<div id="flash"></div>';
echo '<div id="show"></div></div><br>';
}

?>




<a href="logout.php" style="font-size:18px">Logout?</a>
</body>
</html>