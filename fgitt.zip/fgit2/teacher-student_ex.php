<center>
<br><br>
<?php
include "db.php";
if(isset($_POST['btn-upload'])){
$class = $_POST['class'];
$year = $_POST['year'];
$term = $_POST['term'];
$subject = $_POST['subject'];

$user=$_SESSION['username'];
$result3 = mysqli_query($db, "SELECT * FROM users2 where username='$user'");
while($rowtid = mysqli_fetch_assoc($result3))
{
	$a = $rowtid['teacher_id'];
	$tname = $rowtid['teacher'];
}
$tid =  $a;
$tna = $tname;

include("connection.php");
$sql = mysql_query("SELECT * FROM maxes where subjectname='$subject' AND classname='$class' AND yearname='$year' AND termname='$term' AND teachername='$tna' AND teacheridname='$tid' ORDER BY teachername");
$sql2 = mysqli_query($db, "SELECT * FROM maxes where subjectname='$subject' AND classname='$class' AND yearname='$year' AND termname='$term' AND teachername='$tna' AND teacheridname='$tid' ORDER BY teachername");


$sql22 = mysqli_num_rows($sql2);
if($sql22 < 1){
	$canam = 0;
	$examnam = 0;
$inssql="INSERT INTO maxes(caname, examname, teacheridname, subjectname, teachername, classname, yearname, termname) VALUES('$canam', '$examnam', '$tid', '$subject', '$tna', '$class', '$year', '$term')";
 mysqli_query($db, $inssql); 
 echo '<meta content="2;teacher-student.php" http-equiv="refresh" />';
}
else{
echo '<table style="width: 70%;">';
echo '<tr class="head">';
echo '<th colspan="3" style="text-align: center;">Enter max ca score and exam score for '.$class.', '.$term.' '.$year.'</th>';
echo '</tr>';
echo '<tr class="head">';
echo '<th>SUBJECT</th><th>CA TOTAL</th><th>EXAM TOTAL</th>';
echo '</tr>';

$i=1;
while($row=mysql_fetch_array($sql))
{
$id=$row['id'];
$caname=$row['caname'];
$examname=$row['examname'];
//$teachername = $row['teachername'];
$subjectname = $row['subjectname'];
//$classname = $row['classname'];

if($i%2)
{
?>
<tr id="<?php echo $id; ?>" class="edit_tr">
<?php } else { ?>
<tr id="<?php echo $id; ?>" bgcolor="#f2f2f2" class="edit_tr">
<?php } ?>
<td width="10%" class="edit_td">
<span id="subject_<?php echo $id; ?>" class="text"><?php echo $subjectname; ?></span>
<input type="text" value="<?php echo $subjectname; ?>" class="editbox" id="subject_input_<?php echo $id; ?>" />
</td>
<td width="10%" class="edit_td">
<span id="ca_<?php echo $id; ?>" class="text"><?php echo $caname; ?></span>
<input type="text" value="<?php echo $caname; ?>" class="editbox" id="ca_input_<?php echo $id; ?>" />
</td>
<td width="10%" class="edit_td">
<span id="exam_<?php echo $id; ?>" class="text"><?php echo $examname; ?></span> 
<input type="text" value="<?php echo $examname; ?>"  class="editbox" id="exam_input_<?php echo $id; ?>"/>
</td>
</tr>

<?php
$i++;
}}}
?>
</table></center>




<?php
if(isset($_POST['btn-upload'])){	
$class = $_POST['class'];
$year = $_POST['year'];
$term = $_POST['term'];
$subject = $_POST['subject'];


$user=$_SESSION['username'];
$result3 = mysqli_query($db, "SELECT * FROM users2 where username='$user'");
while($rowtid = mysqli_fetch_assoc($result3))
{
	$a = $rowtid['teacher_id'];
	$tname = $rowtid['teacher'];
}
$tid =  $a;
$tna = $tname;


$result = mysqli_query($db, "SELECT * FROM students where class_name='$class' AND year='$year' AND term='$term' AND subject='$subject' AND teacher_id='$tid'");
$result2 = mysqli_query($db, "SELECT * FROM scores where class_name='$class' AND year='$year' AND term='$term' AND subject='$subject' AND teacher_id='$tid'");


while($row2 = mysqli_fetch_assoc($result2))
{  						
$values2[] = $row2['student_name'];
$values2subject[] = $row2['subject']; //for the scores table
}
$values22 =($values2);
$valsubject = ($values2subject);
//print_r($values2);
$vtu = count($values22);
//echo $vtu;
echo '<br>';
//print_r($values22);
while($row = mysqli_fetch_assoc($result))
{  						
$values[] = $row['student_name']; 
$valuessubject[] = $row['subject']; 
$valuesclass[] = $row['class_name']; 
$valuesyear[] = $row['year']; 
$valuesterm[] = $row['term']; 
//for the students table
}
//print_r($values);
//print_r($valuessubject);
$vtuu = count($values);
//echo $vtuu;
echo '<br>';
$vallue = $values;
current($valuessubject);

$b = current($valuessubject);
if($b == 'CRK'){
$b = "Crk";
}

current($valuesclass);
current($valuesyear);
current($valuesterm);
echo '<br>';
//print_r($vallue);
$r = array_diff($vallue, $values22); 
echo '<br>';
//print_r($vallue);
//print_r($values22);
//print_r($r);
//echo $r;
$vtuuu = $vtuu - $vtu;
//echo $vtuuu;

if($vtuuu < 1){
	
	echo "<span style='color:red; font-size:16px; text-decoration: underline;'>Either you have no students currently enrolled, or you have already inputed the scores for the students enrolled in your class under the selected criteria!</span><br>";
}
else if($vtu == 0){
	//$valllue = current($vallue);
	//echo $valllue;
	$values22[] = "nothingham";
	//print_r($values22);
	$r = array_diff($vallue, $values22); 
echo 'Select Students<br />';	
echo '<br>';
echo '<form action="teacher-student_exec.php" method="post">';
echo '<table><thead><tr><th>Student Name</th><th>Total</th><th>CA</th><th>Exam</th><th>Teacher ID</th><th>Remark</th><th>Teachers\'s Name</th><th>Class</th><th>Year</th><th>Term</th><th>Subject</th></tr></thead>';
echo '<tr>';
foreach ($r as $key => $r['student_name']) {
echo '<td class="stname"><input type="hidden" name="student_name[]" value="'.$r['student_name'].'" />'.$r['student_name'].'</td>';
echo '<td><input type="text" placeholder="Total" name="score[]" id="score" /></td>'; 
echo '<td><input type="text" placeholder="CA" name="ca[]" id="ca" /></td>';
echo '<td><input type="text" placeholder="Exam" name="exam[]" id="exam" /></td>';
echo '<td><input type="text"  name="teacher_id[]" id="teacher_id" value="'.$tid.'" /></td>';
echo '<td><input type="text"  name="remark[]" id="remark" placeholder="Remark" /></td>';
echo '<td><input type="text"  name="teacher[]" id="teacher" value="'.$tna.'" />';
echo '<td><input type="text"  name="class_name[]" id="class_name" value="'.current($valuesclass).'" /></td>';
echo '<td><input type="text"  name="year[]" id="year" value="'.current($valuesyear).'" /></td>';
echo '<td><input type="text"  name="term[]" id="term" value="'.current($valuesterm).'" /></td>';
echo '<td><input type="text"  name="subject[]" id="subject" value="'.$b.'" /></td>';	
}
echo '</tr>';
echo '<tr>';
echo '<td colspan="11"><input class="subname" type="submit" class="submit_button" name="submit" value="Submit Scores" /></td>';
echo '</tr>';
echo '</table>';
echo '</form>';		
}
else{
echo '<center>';
echo '<span style="color: green; font-size: 16px;">Add Scores of '.$b.' Students in '.current($valuesclass).' for '.current($valuesterm).', '.current($valuesyear).'</span><br />';	
echo '<form action="teacher-student_exec.php" method="post">';
echo '<table style="text-align: center;"><thead style="text-align: center;"><tr style="text-align: center;"><th style="text-align: center;">Student</th><th style="text-align: center;">Total</th><th style="text-align: center;">CA</th><th style="text-align: center;">Exam</th><th style="display: none;">Teacher ID</th><th style="text-align: center;">Remark</th><th style="display: none;">Teachers\'s Name</th><th style="display: none;">Class</th><th style="display: none;">Year</th><th style="display: none;">Term</th><th style="display: none;">Subject</th><th>CA Max</th></tr></thead>';
foreach ($r as $key => $r['student_name']) {
echo '<tr>';
echo '<td class="suname"><input style="display: none;" type="hidden" name="student_name[]" value="'.$r['student_name'].'" />'.$r['student_name'].'</td>';
echo '<td><input type="text" placeholder="Total" name="score[]" id="score" /></td>'; 
echo '<td><input type="text" placeholder="CA" name="ca[]" id="ca" /></td>';
echo '<td><input type="text" placeholder="Exam" name="exam[]" id="exam" /></td>';
echo '<td style="display: none;"><input type="text"  name="teacher_id[]" id="teacher_id" value="'.$tid.'" /></td>';
echo '<td><input type="text"  name="remark[]" id="remark" placeholder="Remark" /></td>';
echo '<td style="display: none;"><input type="text"  name="teacher[]" id="teacher" value="'.$tna.'" />';
echo '<td style="display: none;"><input type="text"  name="class_name[]" id="class_name" value="'.current($valuesclass).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="year[]" id="year" value="'.current($valuesyear).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="term[]" id="term" value="'.current($valuesterm).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="subject[]" id="subject" value="'.$b.'" /></td>';
echo '<td><input type="text"  name="camax[]" id="subject" value="" /></td>';
echo '</tr>';
}
}
echo '<tr>';
echo '<td colspan="11"><input style="float: right;" class="subname" type="submit" class="submit_button" name="submit" value="Submit Scores" /></td>';
echo '</tr>';
echo '</table>';
echo '</form>';	
echo '</center>';

}
?>

