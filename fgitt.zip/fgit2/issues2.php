<?php
session_start();
include("auth.php");
include('db.php');
include("connection.php");
$resultsch = mysqli_query($db,"SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Edit Subj Techer Challenges Comment</title>
 <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>
 <link rel="stylesheet" href="css/styles.css">
<script type="text/javascript" src="edittablejs.js"></script>
 <script type="text/javascript">
$(document).ready(function()
{
$(".edit_tr").click(function()
{
var ID=$(this).attr('id');
$("#first_"+ID).hide();
$("#first_input_"+ID).show();
$("#pfirst_"+ID).hide();
$("#pfirst_input_"+ID).show();
$("#sfirst_"+ID).hide();
$("#sfirst_input_"+ID).show();
}).change(function()
{
var ID=$(this).attr('id');
var first=$("#first_input_"+ID).val();
var pfirst=$("#pfirst_input_"+ID).val();
var sfirst=$("#sfirst_input_"+ID).val();
var dataString = 'id='+ ID +'&firstname='+first +'&pfirstname='+pfirst +'&sfirstname='+sfirst;
$("#first_"+ID).html('<img src="load.gif" />');


if(first.length>0)
{
$.ajax({
type: "POST",
url: "issues_exec.php",
data: dataString,
cache: false,
success: function(html)
{
$("#first_"+ID).html(first);
$("#pfirst_"+ID).html(pfirst);
$("#sfirst_"+ID).html(sfirst);
}
});
}
else
{
alert('Enter something.');
}

});

$(".editbox").mouseup(function() 
{
return false
});

$(document).mouseup(function()
{
$(".editbox").hide();
$(".text").show();
});
});
</script>
<style>
.pbutton {
	background-color:#44c767;
	-moz-border-radius:28px;
	-webkit-border-radius:28px;
	border-radius:2px;
	border:1px solid #18ab29;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:15px;
	padding:6px 12px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
	margin: auto;
}
.pbutton:hover {
	background-color:#5cbf2a;
}
.pbutton:active {
	position:relative;
	top:1px;
}
  nav ul li ul li{
           float: left;   
        }
</style>

<style>
body
{
font-family:Arial, Helvetica, sans-serif;
font-size:14px;
}
.editbox
{
display:none
}
td
{
padding:2px;
height:60px;
vertical-align: top;
text-align: left;
}
.editbox
{
font-size:14px;
width:100%;
background-color:#ffffcc;
border:solid 1px #000;
padding: 0;
}
.editbox{
	height:100%;
}
.edit_tr:hover
{
background:url(edit.png) right no-repeat #80C8E5;
cursor:pointer;
}
th
{
font-weight:bold;
text-align:left;
padding:4px;
}
.head
{
background-color:#333;
color:#FFFFFF
}
</style>
 <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
 
</head>

<body>
<?php
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'admin'){
echo '<ul class="topnav" id="myTopnav">';
echo '<li><a href="adstuadmin.php">Add Student</a></li>';
echo '<li><a href="adminaddformt.php">Add Form Tutor</a></li>';
echo '<li><a href="admgetresult.php">Student\'s Result</a></li>';
echo '<li><a href="admviewtea.php">View Teachers</a></li>';
echo '<li><a href="admviewtutor.php">View Tutors</a></li>';
echo '<li><a href="viewmaxatt.php">View Max Attendance</a></li>';
echo '<li><a href="logout.php">Logout</a></li>';
echo '<li class="icon">';
echo '<a href="javascript:void(0);" onclick="myFunction()">&#9776;</a>';
echo '</li>';
echo '</ul>';
}
else{echo "";}
?>
<br>
<center><br><br><br>
<div style="margin:0 auto; padding:10px; background-color:#fff; height: auto; width: 100%;">
<div style="width: 100%;">SUBJECT TEACHER'S CHALLENGES, ASSISTANCE STRATEGIES &amp; INTERVENTIONS
<?php
        $teacher_id = $_POST['teacher_id'];
		$teacher = $_POST['teacher'];
        $class = $_POST['class'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		$subject = $_POST['subject'];
		$arms = $_POST['arms'];
		
if($ctype=="Js"){
$checkclass2 = mysqli_query($db, "SELECT * FROM classes where class_name='$class'");
while($rowcla2 = mysqli_fetch_assoc($checkclass2)){
$cll4[] = $rowcla2['class_name2'];
}
$cl = current($cll4);
}else{
$cl = $_POST['class_name'];	
}
?>
<br><span style="color: red;">
<?php echo strtoupper($cl)." ".strtoupper($arms)." STUDENTS OF ".strtoupper($subject)." IN ".$year."/".($year+1)." SESSION"; ?></span></div>
<span>Click on a rectangle to input comment.</span>
<table style="width: 80%;">
<tr class="head">
<th>Student's Name</th><th>Challenge</th><th>Intervention</th><th>Recommendation</th>
</tr>
<?php	
$sql4 = mysqli_query($db,"SELECT score_id, student_name, firstname, pfirstname, sfirstname FROM scores where class_name='$class' AND year='$year' AND term='$term' AND teacher_name='$teacher' AND arms='$arms' AND school='".$_SESSION["school"]."' ORDER BY student_name ASC");
$i=1;
while($rows=mysqli_fetch_array($sql4))
{
$id=$rows['score_id'];
$stuname=$rows['student_name'];
$firstname=$rows['firstname'];
$pfirstname=$rows['pfirstname'];
$sfirstname=$rows['sfirstname'];
if($i%2)
{
?>
<tr id="<?php echo $id; ?>" class="edit_tr">
<?php } else { ?>
<tr id="<?php echo $id; ?>" bgcolor="#f2f2f2" class="edit_tr">
<?php } ?>
<td width="10%" class="edit_td">
<span id="stu_<?php echo $id; ?>" class="text"><?php echo $stuname; ?></span>
<input type="text" value="<?php echo $stuname; ?>" class="editbox" id="stu_input_<?php echo $id; ?>" />
</td>
<td width="10%" class="edit_td">
<span id="first_<?php echo $id; ?>" class="text"><?php echo $firstname; ?></span>
<textarea type="text" value="<?php echo $firstname; ?>" style="" class="editbox" id="first_input_<?php echo $id; ?>" /><?php echo $firstname; ?></textarea>
</td>
<td width="10%" class="edit_td">
<span id="pfirst_<?php echo $id; ?>" class="text"><?php echo $pfirstname; ?></span>
<textarea type="text" value="<?php echo $pfirstname; ?>" style="" class="editbox" id="pfirst_input_<?php echo $id; ?>" /><?php echo $pfirstname; ?></textarea>
</td>
<td width="10%" class="edit_td">
<span id="sfirst_<?php echo $id; ?>" class="text"><?php echo $sfirstname; ?></span>
<textarea type="text" value="<?php echo $sfirstname; ?>" style="" class="editbox" id="sfirst_input_<?php echo $id; ?>" /><?php echo $sfirstname; ?></textarea>
</td>
</tr>
<?php
$i++;
}
?>
</table>
<br><a class='pbutton' href='issues.php'>back</a>
</center>	
<?php
include("footer.php");
?>
</body>
</html>
