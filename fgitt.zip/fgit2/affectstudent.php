<?php
include("connection.php");
$del = mysqli_query($db, "DELETE FROM students WHERE student_name='Kenny'");
if($del){
	echo "success";
}
?>