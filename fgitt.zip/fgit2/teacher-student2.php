<?php
	session_start();
	include("auth.php"); //include auth.php file on all secure pages
	include "connection.php";
	include('db.php');
	$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Insert Scores</title>

<link rel="stylesheet" href="style.css" type="text/css" />
<link rel="stylesheet" href="css/style.css" />
	<script src="table/js/jquery.js" type="text/javascript"></script>
	<script src="datatablejs.js" type="text/javascript"></script>
	<link rel="stylesheet" type="text/css" href="datatablecss.css">
	 <link rel="stylesheet" type="text/css" href="datatablebuttoncss.css">
<script>
	$(document).ready(function() {
    $('#example').DataTable( {
        "paging":   false,
        "ordering": true,
        "info":     false
    } );
} );
</script>
<script>
$(document).ready(function(){
	$( ".tdinput" ).prop( "disabled", true );
	var aa = $(".clas").val();
	$("td.mxname").click(function(){
	if((!$(".hwmax").length) || (!$(".cwmax").length) || (!$(".testmax").length) || (!$(".exammax").length)){	
		alert("You must first input max scores");
		$( "#subm" ).prop( "disabled", true );
		return false;
	}
		});
		
	$("#subm").click(function(){
	if($(".hwmax").val()=="" || $(".cwmax").val()=="" || $(".testmax").val()==""  || $(".exammax").val()==""){	
		$( "#subm" ).prop( "disabled", true );
		return false;
	}
		});
	
	var valueit = $("#txtFirstName").val();
	var valueit1 = $("#txtFirstName1").val();
	var valueit2 = $("#txtFirstName2").val();
	var valueit3 = $("#txtFirstName3").val();
	$('#resetmaxes').hide();
	
	if((valueit2!="") && (valueit3!="")){
		$("#txtFirstName").replaceWith('<input type="text" class="txtFirstName" id="txtFirstName" value="'+valueit+'" readonly />');
		$("#txtFirstName1").replaceWith('<input type="text" class="txtFirstName1" id="txtFirstName1" value="'+valueit1+'" readonly />');
		$("#txtFirstName2").replaceWith('<input type="text" class="txtFirstName2" id="txtFirstName2" value="'+valueit2+'" readonly />');
		$("#txtFirstName3").replaceWith('<input type="text" class="txtFirstName3" id="txtFirstName3" value="'+valueit3+'" readonly />');
	}
	if((valueit!="") && (valueit1!="")){
		$( "#dosomething" ).prop( "disabled", true );
		$( ".tdinput" ).prop( "disabled", false );
		$( ".submit_button" ).prop( "disabled", false );
	}
	
	$("#dosomething").click(function(){	
	//var valueit22=$.trim($(".camax").val());
	//var valueit11=$.trim($(".exammax").val());
	var valit = $("#txtFirstName").val();
	var valit1 = $("#txtFirstName1").val();
	var valit2 = $("#txtFirstName2").val();
	var valit3 = $("#txtFirstName3").val();
	$(".addafter2").after('<th class="newadded" style="text-align: center; width: 5%; ">HW Max</th>');
	$(".newadded").after('<th class="newaddedcw" style="text-align: center; width: 5%;">CW Max</th>');
	$(".newaddedcw").after('<th class="newaddedtest" style="text-align: center; width: 5%;">Test Max</th>');
	$(".newaddedtest").after('<th style="text-align: center; width: 5%;">Exam Max</th>');
	$(".addafter").after('<td style="text-align: center; width: 5%;" class="addafterhw"><input style="text-align: center; width: 90%;" class="hwmax" type="text"  name="hwmax[]" id="hwmax" readonly/></td>');
	$(".addafterhw").after('<td style="text-align: center; width: 5%;" class="addaftercw"><input style="text-align: center; width: 90%;" class="cwmax" type="text"  name="cwmax[]" id="cwmax" readonly/></td>');
	$(".addaftercw").after('<td class="addaftertest" style="text-align: center; width: 5%;"><input style="text-align: center; width: 90%;" class="testmax" type="text"  name="testmax[]" id="testmax" readonly/></td>');
	$(".addaftertest").after('<td style="text-align: center; width: 5%;"><input style="text-align: center; width: 90%;" class="exammax" type="text"  name="exammax[]" id="exammax" readonly/></td>');
	$(".hwmax").val(valit);
	$(".cwmax").val(valit1);
	$(".testmax").val(valit2);
	$(".exammax").val(valit3);
	$( "#txtFirstNameall" ).fadeOut( 2000, function() {
    $('#txtFirstNameall').hide();
    });
	$( "#resetmaxes" ).show();
	$( ".tdinput" ).prop( "disabled", false );
});
	$("#resetmaxes").click(function(){	
	location.reload(true);
	});
});
</script>

<script>
		$(document).ready(function() {	
		$("#formid").submit(function( event ) {
			event.preventDefault();	
$.ajax({
type: "POST",
url: "teacher-student_exec.php",
data: $("#formid").serializeArray(),	
success: function(response){
 if(response==1) { 
		event.preventDefault();
		$("#subm").remove();
		$(".getprogress").html('<div><a href="update-score.php" style="float: left;" >Update Term Scores</a><a href="update-score-mid.php" style="float: right;">Update Mid Scores</a></div>');
		$(".success").fadeIn();
		setTimeout(function() { $(".success").fadeOut(); }, 2000); 
    } else {
		 $(".error").show();
		setTimeout(function() { $(".error").fadeOut(); }, 2000);
		}
		}
});	
});	 
});
</script>
<style>
.submit_button {
	background-color:#44c767;
	-moz-border-radius:28px;
	-webkit-border-radius:28px;
	border-radius:28px;
	border:1px solid #18ab29;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:15px;
	padding:6px 24px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
}
.submit_button:hover {
	background-color:#5cbf2a;
}
.submit_button:active {
	position:relative;
	top:1px;
}
</style>
 <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
<script>
$(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>
  <link rel="stylesheet" href="css/styles.css">
   <script src="js/scriptmenu.js"></script>
</head>

<body>
<?php
echo '<div id="headerit">';
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");
}
elseif($_SESSION['role'] == 'student'){
include("headerstudent.php");
}
else{header("location: logout.php");}
echo '</div>';
?>
<?php
$user = $_SESSION['username'];
include "connection.php";
?>
<br><br><br>
<form action="" method="post" enctype="multipart/form-data">
<center>
 <div>
   
	<label><select style="width:15%;" name="class" id="class" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM classes");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['class_name'].'">';
								if($ctype=="Js"){
								echo $row['class_name2'];
												}
								else{
								echo $row['class_name'];	
								}
								echo '</option>';
							}
						?>
      </select>
	   <br><br>
	  <?php
	  echo '<select style="width: 210px; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="arms" id="arms" required >';
	 $result = mysqli_query($db,"SELECT * FROM school where school='".$_SESSION["school"]."'");
				while($row = mysqli_fetch_assoc($result)){
					$arrr2[] = $row["arms"];
				}
				$a = implode(',',$arrr2);
				$b = explode(',',$a);
				$f = (array_filter($b));
				
						for($i=0; $i<=(count($f)-1); $i++)
							{  
								echo '<option value="'.$f[$i].'">';
								echo $f[$i];
								echo '</option>';
							}
    echo '</select>';
?>
	  <br><br>
	  
	  
	  <select style="width:15%;" name="year" id="year" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM years");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['year'].'">';
								echo $row['year'];
								echo '</option>';
							}
						?>
      </select>
	  
	  
	   <br><br>
	  <select style="width:15%;" name="term" id="term" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM terms");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['term'].'">';
								echo $row['term'];
								echo '</option>';
							}
						?>
      </select>
	   <br><br>
	  <select style="width:15%;" name="subject" id="subject" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM subjects");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['subject'].'">';
								echo $row['subject'];
								echo '</option>';
							}
						?>
      </select>
	  </label>
	  
  <label><br><br>
      <input type="submit" class="submit_button" style="background-color: green; color: white;" name="btn-upload" value="Submit Form" />
    </label>

  </div>
  </center>
</form>
<center>
<?php
if(isset($_POST['btn-upload'])){
$class = $_POST['class'];
$year = $_POST['year'];
$term = $_POST['term'];
$subject = $_POST['subject'];
$arms = $_POST['arms'];

$user=$_SESSION['username'];
$result3 = mysqli_query($db, "SELECT * FROM users2 where username='$user' AND school='".$_SESSION["school"]."'");
while($rowtid = mysqli_fetch_assoc($result3))
{
	$a = $rowtid['teacher_id'];
	$tname = $rowtid['teacher'];
}
$tid =  $a;
$tna = $tname;


$result = mysqli_query($db, "SELECT * FROM students where arms='$arms' AND class_name='$class' AND year='$year' AND term='$term' AND subject='$subject' AND teacher_id='$tid' AND school='".$_SESSION["school"]."'");
$result2 = mysqli_query($db, "SELECT * FROM scores where arms='$arms' AND class_name='$class' AND year='$year' AND term='$term' AND subject='$subject' AND teacher_id='$tid' AND school='".$_SESSION["school"]."'");

while($row2 = mysqli_fetch_assoc($result2))
{  						
$values2[] = $row2['student_name'];
$values2subject[] = $row2['subject']; //for the scores table
}
$values22 =($values2);
$valsubject = ($values2subject);
$vtu = count($values22);
echo '<br>';
while($row = mysqli_fetch_assoc($result))
{  						
$values[] = $row['student_name']; 
$valuessubject[] = $row['subject']; 
$valuesclass[] = $row['class_name']; 
$valuesyear[] = $row['year']; 
$valuesterm[] = $row['term']; 
$valuesarms[] = $row['arms']; 
}
$vtuu = count($values);
echo '<br>';
$vallue = $values;
current($valuessubject);

$b = current($valuessubject);
if($b == 'CRK'){
$b = "Crk";
}

current($valuesclass);
current($valuesyear);
current($valuesterm);
current($valuesarms);
$r = array_diff($vallue, $values22); 
echo '<br>';
$vtuuu = $vtuu - $vtu;

if($vtuuu < 1){
	echo "<span style='color:red; font-size:16px; text-decoration: underline;'>Either you have no students currently enrolled, or you have already inputed the scores for the students enrolled in your class under the selected criteria!</span><br>";
}
else if($vtu == 0){
$resultmaxes = mysqli_query($db, "SELECT DISTINCT camaxname, exammaxname FROM scores WHERE subject='$subject' AND arms='$arms' AND teacher_name='$tna' AND class_name='$class' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
$countresultmaxes = mysqli_num_rows($resultmaxes);
if($countresultmaxes<1){
echo '<div id="txtFirstNameall">';
echo '<input type="text" class="txtFirstName" placeholder="HOMEWORK MAX SCORES" id="txtFirstName"><br><br>';
echo '<input type="text" class="txtFirstName1" placeholder="CLASSWORK MAX SCORES" id="txtFirstName1"> <br><br>';
echo '<input type="text" class="txtFirstName2" placeholder="TEST MAX SCORES" id="txtFirstName2"> <br><br>';
echo '<input type="text" class="txtFirstName3" placeholder="EXAM MAX SCORES" id="txtFirstName3"> <br><br>';
echo '<button class="submit_button" style="background-color: green; color: white;" id="dosomething">Set Max Scores</button>';
echo '</div>';
echo '<button class="submit_button" style="background-color: green; color: white;" id="resetmaxes">Reset Max Scores</button>';
echo '<br>';
}
	$values22[] = "nothingham";
	$r = array_diff($vallue, $values22); 


	
echo '<form class="formid" id="formid">';
echo '<table id="example" class="display" cellspacing="0" width="100%">';
echo '<thead>';
echo '<tr>';
echo '<th>Student</th>';
echo '<th>Total</th>';
echo '<th>Homework</th>';
echo '<th>Classwork</th>';
echo '<th>Test</th>';
echo '<th>Exam</th>';
echo '<th>Mid Score</th>';
echo '<th>Raw MidScore</th>';
echo '<th>Mid HWMAX</th>';
echo '<th>Mid CWMAX</th>';
echo '<th>Mid TestMax</th>';
echo '<th>Teacher ID</th>';
echo '<th>Remark</th>';
echo '<th>Teachers\'s Name</th>';
echo '<th>Class</th>';
echo '<th>Year</th>';
echo '<th>Arm</th>';
echo '<th>Term</th>';
echo '<th class="addafter2" style="display: none;">Subject</th>';
echo '</tr>';
echo '</thead>';
$countscore = 0;
$r2 = count($r);
for($ccount = 0; $ccount<=$r2; $ccount++)
{
$resultmid = mysqli_query($db, "SELECT * FROM scoresmid WHERE student_name='$r[$ccount]' AND class_name='$class' AND year='$year' AND term='$term' AND subject='$subject' AND teacher_id='$tid' AND school='".$_SESSION["school"]."'");	
while($rowmid = mysqli_fetch_assoc($resultmid))
{ 
$scor2[] = $rowmid['score'];
$scor2raw[] = $rowmid['scoreraw'];
$hwmaxname2[] = $rowmid['hwmaxname'];
$cwmaxname2[] = $rowmid['cwmaxname'];
$testmaxname2[] = $rowmid['testmaxname'];
break;
}
}
$scor = $scor2;
$scorraw = $scor2raw;
$hwmaxname = $hwmaxname2;
$cwmaxname = $cwmaxname2;
$testmaxname = $testmaxname2;
echo '<tbody>';
foreach ($r as $key => $r['student_name']) {
echo '<tr>';
echo '<td class="suname" style="text-align: center; width: 5%;"><input style="text-align: center; width: 90%; display: none;" class="tdinput" type="hidden" name="student_name[]" value="'.$r['student_name'].'" />'.$r['student_name'].'</td>';
echo '<td style="display: none; width: 5%;"><input style="text-align: center; width: 90%;" class="tdinput" type="text" placeholder="Total" name="score[]" id="score" /></td>';
echo '<td class="mxname" style="text-align: center; width: 5%;"><input style="text-align: center; width: 90%;" class="tdinput" type="text" placeholder="Homework" name="hw[]" id="hw" /></td>';
echo '<td class="mxname" style="text-align: center; width: 5%;"><input style="text-align: center; width: 90%;" class="tdinput" type="text" placeholder="Classwork" name="cw[]" id="cw" /></td>';
echo '<td class="mxname" style="text-align: center; width: 5%;"><input style="text-align: center; width: 90%;" class="tdinput" type="text" placeholder="Test" name="test[]" id="test" /></td>';
echo '<td class="mxname" style="text-align: center; width: 5%;"><input style="text-align: center; width: 90%;" class="tdinput" type="text" placeholder="Exam" name="exam[]" id="exam" /></td>';
echo '<td style="text-align: center; width: 5%;"><input style="text-align: center; width: 90%;" class="tdinput" type="text"  name="scoremid[]" id="scoremid"  value="'.$scor[$countscore].'" readonly/></td>';
echo '<td style="text-align: center; width: 5%;"><input style="text-align: center; width: 90%;" class="tdinput" type="text"  name="scoremidraw[]" id="scoremidraw"  value="'.$scorraw[$countscore].'" readonly/></td>';
echo '<td style="text-align: center; width: 5%;"><input style="text-align: center; width: 90%;" class="tdinput" type="text"  name="hwmaxname[]" id="hwmaxname"  value="'.$hwmaxname[$countscore].'" readonly/></td>';
echo '<td style="text-align: center; width: 5%;"><input style="text-align: center; width: 90%;" class="tdinput" type="text"  name="cwmaxname[]" id="cwmaxname"  value="'.$cwmaxname[$countscore].'" readonly/></td>';
echo '<td style="text-align: center; width: 5%;"><input style="text-align: center; width: 90%;" class="tdinput" type="text"  name="testmaxname[]" id="testmaxname"  value="'.$testmaxname[$countscore].'" readonly/></td>';
echo '<td style="text-align: center; width: 5%; display: none;"><input class="tdinput" type="text"  name="teacher_id[]" id="teacher_id" value="'.$tid.'" /></td>';
echo '<td style="text-align: center; width: 5%;"><input style="text-align: center; width: 100%;" class="tdinput" type="text"  name="remark[]" id="remark" placeholder="Remark" /></td>';
echo '<td style="display: none; width: 5%;"><input class="tdinput" type="text"  name="teacher[]" id="teacher" value="'.$tna.'" />';
echo '<td style="display: none; width: 5%;"><input class="tdinput" type="text"  name="class_name[]" id="class_name" value="'.current($valuesclass).'" /></td>';
echo '<td style="display: none; width: 5%;"><input class="tdinput" type="text"  name="year[]" id="year" value="'.current($valuesyear).'" /></td>';
echo '<td style="display: none;"><input class="tdinput" type="text"  name="arms[]" id="arms" value="'.current($valuesarms).'" /></td>';
echo '<td style="display: none; width: 5%;"><input class="tdinput" type="text"  name="term[]" id="term" value="'.current($valuesterm).'" /></td>';
echo '<td class="addafter" style="display: none; width: 5%;"><input type="text"  name="subject[]" id="subject" value="'.$b.'" /></td>';
echo '</tr>';
$countscore++;
}
echo '</tbody>';
echo '</table>';
echo '<div style="border: 0;">';
echo '<input type="submit" class="submit_button" name="submit" value="Submit Scores" />';
echo '<label style="border: 0;">';
echo '<span class="error" style="display:none; color: red;"><img src="table/del.jpg" width="60" height="60"/>A submission error has just occurred.</span>';
echo '<span class="success" style="display:none; color: green;"><img src="table/492.png" width="60" height="60"/> Scores submitted successfully.</span>';
echo '</label>';
echo '</div>';
echo '</form>';		
}





else{
	
	
echo '<center>';
echo '<span style="color: green; font-size: 16px;">Add Scores of '.$b.' Students in '.current($valuesclass).current($valuesarms).' for '.current($valuesterm).', '.current($valuesyear).'</span><br />';	

$resultmaxes = mysqli_query($db, "SELECT DISTINCT hwmaxname, cwmaxname, testmaxname, exammaxname FROM scores WHERE subject='$subject' AND arms='$arms' AND teacher_name='$tna' AND class_name='$class' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while($rowmaxes = mysqli_fetch_assoc($resultmaxes))
{ 
echo '<div id="txtFirstNameall">';
echo '<input type="text" class="txtFirstName" id="txtFirstName" value="'.$rowmaxes['hwmaxname'].'"><br>';
echo '<input type="text" class="txtFirstName1" id="txtFirstName1" value="'.$rowmaxes['cwmaxname'].'"><br>';
echo '<input type="text" class="txtFirstName2" id="txtFirstName2" value="'.$rowmaxes['testmaxname'].'"><br>';
echo '<input type="text" class="txtFirstName3" id="txtFirstName3" value="'.$rowmaxes['exammaxname'].'"> <br><br>';
echo '<button class="submit_button" style="background-color: green; color: white;" id="dosomething">Set Max Scores</button>';
echo '</div>';
echo '<button class="submit_button" style="background-color: green; color: white;" id="resetmaxes">Reset Max Scores</button>';
echo '<br>';
}
echo '<form id="formid">';
echo '<table style="text-align: center; width: 100%;">';
echo '<thead style="text-align: center;">';
echo '<tr style="text-align: center;">';
echo '<th style="text-align: center;">Student</th>';
echo '<th style="display: none;">Total</th>';
echo '<th style="text-align: center;">Homework</th>';
echo '<th style="text-align: center;">Classwork</th>';
echo '<th style="text-align: center;">Test</th>';
echo '<th style="text-align: center;">Exam</th>';
echo '<th style="text-align: center;">Mid Score</th>';
echo '<th style="text-align: center;">Raw MidScore</th>';
echo '<th>Mid HWMAX</th>';
echo '<th>Mid CWMAX</th>';
echo '<th>Mid TestMax</th>';
echo '<th style="display: none;">Teacher ID</th>';
echo '<th style="text-align: center;">Remark</th>';
echo '<th style="display: none;">Teachers\'s Name</th>';
echo '<th style="display: none;">Class</th>';
echo '<th style="display: none;">Year</th>';
echo '<th style="display: none;">Term</th>';
echo '<th class="addafter2" style="display: none; width: 5%;">Subject</th>';
echo '</tr>';
echo '</thead>';

$r = array_diff($vallue, $values22); 
$countscore2 = 0;

$keycount = array_pop(array_keys($r));

while($countscore2<=($keycount))
{
$resultmid = mysqli_query($db, "SELECT * FROM scoresmid WHERE student_name='$r[$countscore2]' AND arms='$arms' AND class_name='$class' AND year='$year' AND term='$term' AND subject='$subject' AND teacher_id='$tid' AND school='".$_SESSION["school"]."'");	
while($rowmid = mysqli_fetch_assoc($resultmid))
{ 
$scor2[] = $rowmid['score'];
$scor2raw[] = $rowmid['scoreraw'];
$hwmaxname2[] = $rowmid['hwmaxname'];
$cwmaxname2[] = $rowmid['cwmaxname'];
$testmaxname2[] = $rowmid['testmaxname'];
break;
}
$countscore2++;
}
$scor = $scor2;
$scorraw = $scor2raw;
$hwmaxname = $hwmaxname2;
$cwmaxname = $cwmaxname2;
$testmaxname = $testmaxname2;

$countscore = 0;
foreach ($r as $key => $r['student_name']) {
echo '<tr>';
echo '<td class="suname" style="text-align: center;"><input style="text-align: center; width: 90%; display: none;" class="tdinput" type="hidden" name="student_name[]" value="'.$r['student_name'].'" />'.$r['student_name'].'</td>';
echo '<td style="display: none;"><input style="text-align: center; width: 90%;" class="tdinput" type="text" placeholder="Total" name="score[]" id="score" /></td>';
echo '<td style="text-align: center;"><input style="text-align: center; width: 90%;" class="tdinput" type="text" placeholder="Homework" name="hw[]" id="hw" /></td>';
echo '<td style="text-align: center;"><input style="text-align: center; width: 90%;" class="tdinput" type="text" placeholder="Classwork" name="cw[]" id="cw" /></td>';
echo '<td style="text-align: center;"><input style="text-align: center; width: 90%;" class="tdinput" type="text" placeholder="Test" name="test[]" id="test" /></td>';
echo '<td style="text-align: center;"><input style="text-align: center; width: 90%;" class="tdinput" type="text" placeholder="Exam" name="exam[]" id="exam" /></td>';
echo '<td style="text-align: center;"><input style="text-align: center; width: 90%;" class="tdinput" type="text"  name="scoremid[]" id="scoremid"  value="'.$scor[$countscore].'" readonly/></td>';
echo '<td style="text-align: center;"><input style="text-align: center; width: 90%;" class="tdinput" type="text"  name="scoremidraw[]" id="scoremidraw"  value="'.$scorraw[$countscore].'" readonly/></td>';
echo '<td style="text-align: center;"><input style="text-align: center; width: 90%;" class="tdinput" type="text"  name="hwmaxname[]" id="hwmaxname"  value="'.$hwmaxname[$countscore].'" readonly/></td>';
echo '<td style="text-align: center;"><input style="text-align: center; width: 90%;" class="tdinput" type="text"  name="cwmaxname[]" id="cwmaxname"  value="'.$cwmaxname[$countscore].'" readonly/></td>';
echo '<td style="text-align: center;"><input style="text-align: center; width: 90%;" class="tdinput" type="text"  name="testmaxname[]" id="testmaxname"  value="'.$testmaxname[$countscore].'" readonly/></td>';
echo '<td style="display: none;"><input class="tdinput" type="text"  name="teacher_id[]" id="teacher_id" value="'.$tid.'" /></td>';
echo '<td style="text-align: center;"><input style="text-align: center; width: 100%;" class="remark" type="text"  name="remark[]" id="remark_'.$countscore.'" placeholder="Remark" /></td>';
echo '<td style="display: none;"><input class="tdinput" type="text"  name="teacher[]" id="teacher" value="'.$tna.'" />';
echo '<td style="display: none;"><input class="tdinput" type="text"  name="class_name[]" id="class_name" value="'.current($valuesclass).'" /></td>';
echo '<td style="display: none;"><input class="tdinput" type="text"  name="year[]" id="year" value="'.current($valuesyear).'" /></td>';
echo '<td style="display: none;"><input class="tdinput" type="text"  name="arms[]" id="arms" value="'.current($valuesarms).'" /></td>';
echo '<td style="display: none;"><input class="tdinput" type="text"  name="term[]" id="term" value="'.current($valuesterm).'" /></td>';
echo '<td class="addafter" style="display: none;"><input type="text"  name="subject[]" id="subject" value="'.$b.'" /></td>';
echo '</tr>';
$countscore++;
}
echo '</tbody>';
echo '</table>';
echo '<div style="border: 0;">';
echo '<input type="submit" class="submit_button" name="submit" value="Submit Scores" />';
echo '<label style="border: 0;">';
echo '<span class="error" style="display:none; color: red;"><img src="table/del.jpg" width="60" height="60"/>A submission error has just occurred.</span>';
echo '<span class="success" style="display:none; color: green;"><img src="table/492.png" width="60" height="60"/> Scores submitted successfully.</span>';
echo '</label>';
echo '</div>';
echo '</form>';	
}
echo '</center>';

}
?>


<br>
<?php
include("footer.php");
?>
</body>
</html>