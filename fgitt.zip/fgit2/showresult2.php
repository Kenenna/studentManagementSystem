<html>
<head>
<style>
section {
    width: 70%;  
    margin: auto;
    padding: 10px;
}
div#one {
    width: 80%; 
    float: left;
}
div#two {
    margin-left: 5%;  
}
#section2 {
    width: 70%;  
    margin: auto;
    padding: 10px;
}
div#one2 {
    width: 50%; 
    float: left;
}
div#two2 {
    margin-left: 5%;  
}
#section3 {
    width: 70%;  
    margin: auto;
    padding: 10px;
}
div#one3 {
    width: 50%; 
    float: left;
}
</style>
</head>
<body>
<?php
if(isset($_POST['btn-upload'])){
$class_name = $_POST['class_name'];
$year = $_POST['year'];
$term = $_POST['term'];
$student_name = $_POST['student_name'];
   echo '<table style="width:70%; border-top:0; border-bottom: 1px solid red; margin:auto; padding:auto;"><tr>';
   echo '<td style="font-size:18px;"><img src="images/6.png" align="left" height="100" width="100" />ONWARD SECONDARY SCHOOL<br>24 BROWN ROAD,<br> ALIMOSHO, LAGOS<br>TEL: 07060980133<br>FAX: 557688966858844<span style="float:right;">'.date("d-m-Y").'</span></td></tr></table>';
   echo '<table style="width:100%; text-align:center; font-weight:bold; font-size:22px;"><tr><td>RESULT SHEET FOR THIRD TERM, 2015/2016</td></tr></table>';
   echo '<section>';
	echo '<div id="one">';
	echo '<table style="width: 100%; border-top:0;  margin:auto; padding:auto;">';
	include "connection.php";
	$resulta = mysqli_query($db, "SELECT DISTINCT(student_name) FROM students where student_name='$student_name'");
	while($rowa = mysqli_fetch_assoc($resulta)){
		echo '<tr><td>Student Name: '.$rowa['student_name'].'</td>';
	} 
	$resultb = mysqli_query($db, "SELECT ad_no FROM ad_no where student_name='$student_name'");
	while($rowb = mysqli_fetch_assoc($resultb)){
	echo '<td>Admission No: '.$rowb['ad_no'].'</td></tr>';
	}
	$resultc = mysqli_query($db, "SELECT DISTINCT(year) FROM students where year='$year'");
	while($rowc = mysqli_fetch_assoc($resultc)){
		echo '<tr><td>Year: '.$rowc['year'].'</td>';
	} 
	$resultd = mysqli_query($db, "SELECT DISTINCT(term) FROM students where term='$term'");
	while($rowd = mysqli_fetch_assoc($resultd)){
		echo '<td>Term: '.$rowd['term'].'</td>';
	} 
	$resulte = mysqli_query($db, "SELECT class_name FROM classes where class_name='$class_name'");
	while($rowe = mysqli_fetch_assoc($resulte)){
		echo '<td>Class: '.$rowe['class_name'].'</td></tr>';
	} 
	
	echo '<tr><td>No of Present: 45</td><td>No of Times School Open: 50</td>';
	
	$resultf = mysqli_query($db, "SELECT dob FROM dob where student_name='$student_name'");
	while($rowf = mysqli_fetch_assoc($resultf)){
		echo '<td>Date of Birth: '.date("d-m-Y", strtotime($rowf['dob'])).'</td></tr>';
	} 
	echo '</table>';
	echo '</div>';
	echo '<div id="two">';
	echo '<table><tr><td>';
 
	$resultimg = mysqli_query($db, "SELECT img FROM img where student_name='$student_name'");
	while($rowimg = mysqli_fetch_assoc($resultimg)){
	echo '<img style="float:right;" src="'.$rowimg['img'].'" height="80" width="100"/>';
	}
	echo '</td></tr></table>';
	echo '</div>';
	echo '</section>';
	echo '<div style="color:red; font-size:20px; text-align:center;">CONGNITIVE ASSESSMENT</div>';
	echo '<table style="width:70%; border: 1px solid black; margin:auto; padding:auto; text-align:center;" border="1">';
	echo '<tr><td>SUBJECT</td><td>CA.</td><td>EXAM</td><td>TOTAL</td><td>GRADE</td><td>CLASS MAX</td><td>REMARKS</td><td>TEACHER</td></tr>';
	$resultg = mysqli_query($db, "SELECT * FROM scores where class_name='$class_name' AND year='$year' AND term='$term' AND student_name='$student_name'");
	while($rowg = mysqli_fetch_assoc($resultg)){
		echo '<tr><td>'.$rowg['subject'].'</td><td>'.$rowg['ca'].'</td><td>'.$rowg['exam'].'</td><td>'.$rowg['score'].'</td><td>A1</td><td>'.$rowg['max'].'</td><td>'.$rowg['remark'].'</td><td>'.$rowg['teacher_name'].'</td></tr>';
	} 
	
	
	
	
}
?>
</body>
</html>
