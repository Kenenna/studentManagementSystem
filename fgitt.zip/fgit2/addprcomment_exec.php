<?php
	session_start();
	include("auth.php"); //include auth.php file on all secure pages
	include "connection.php";
	include("auth.php");
	include('db.php');	
$id = $_POST['id'];	
$prcomment = $_POST['prcomment'];
for ($i = 0; $i <= (count($id)-1); $i++){
$sql1=mysqli_query($db,"UPDATE studentsbyclass SET prcomment='$prcomment[$i]' WHERE id='$id[$i]' AND school='".$_SESSION["school"]."'");
}
if($sql1){
echo 1;
}	
else{
echo 0;
}
?>