<?php
	session_start();
	include("auth.php"); 
	include('db.php');
	include "connection.php";
	$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Insert Attendance</title>
<link rel="stylesheet" href="css/style.css" />
	
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">

	<script src="table/js/jquery.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script>
$(document).ready(function() {
$("#class option").eq(7).css("display","none");
$("#ssub").on("click",function(){
var bb = $("#class").find(":selected").text();
var b = null;
if(bb=="Primary 1"){
	b = "Year 1";
}
else if(bb=="Primary 2"){
	b = "Year 2";
}
else if(bb=="Primary 3"){
	b = "Year 3";
}
else if(bb=="Primary 4"){
	b = "Year 4";
}
else if(bb=="Primary 5"){
	b = "Year 5";
}
else if(bb=="Primary 6"){
	b = "Year 6";
}
else if(bb=="JS1"){
	b = "Year 7";
}
else if(bb=="JS2"){
	b = "Year 8";
}
else if(bb=="JS3"){
	b = "Year 9";
}
else if(bb=="SS1"){
	b = "Year 10";
}
else if(bb=="SS2"){
	b = "Year 11";
}
else if(bb=="SS3"){
	b = "Year 12";
}
else{
	b = bb;
}
$("#class").find(":selected").val(b);
var c = $("#class").find(":selected").val();
//alert(c);
  }); 

  
$("[data-opt=dop] option").eq(7).css("display","none");
$("#btit").on("click",function(){
//var bb = $("[data-opt=dop] option").find(":selected").text();
var bb = $("[data-opt=dop]").find(":selected").text();
var b = null;
if(bb=="Primary 1"){
	b = "Year 1";
}
else if(bb=="Primary 2"){
	b = "Year 2";
}
else if(bb=="Primary 3"){
	b = "Year 3";
}
else if(bb=="Primary 4"){
	b = "Year 4";
}
else if(bb=="Primary 5"){
	b = "Year 5";
}
else if(bb=="Primary 6"){
	b = "Year 6";
}
else if(bb=="JS1"){
	b = "Year 7";
}
else if(bb=="JS2"){
	b = "Year 8";
}
else if(bb=="JS3"){
	b = "Year 9";
}
else if(bb=="SS1"){
	b = "Year 10";
}
else if(bb=="SS2"){
	b = "Year 11";
}
else if(bb=="SS3"){
	b = "Year 12";
}
else{
	b = bb;
}
$("[data-opt=dop]").find(":selected").val(b);
var c = $("[data-opt=dop]").find(":selected").val();
//alert(c);
  }); 	
  
	var wid = $(window).width();
	if(wid<400){
		//alert("less than 400");
		$("#takeitdown").hide();
	}else{
		//alert("more than 400");
		$("#takeitdown").show();
	}
	
	$(window).on('resize', function(){
	var wid = $(window).width();
	if(wid<400){
		//alert("less than 400");
		$("#takeitdown").hide();
	}else{
		//alert("more than 400");
		$("#takeitdown").show();
	}
	});
	var rowCount = $('.checkSingles').length;
	$("input.checkSingleaft").slice( 0, (rowCount/2) ).val( "Morning" ).css("background-color", "green").css("color", "white");
	$("input.checkSingleaft").slice((rowCount/2), rowCount).val( "Afternnon" ).css("background-color", "blue").css("color", "white");
	$(".checkSingles").slice( 0, (rowCount/2) ).css("background-color", "green").css("color", "white");
	$(".checkSingles").slice((rowCount/2), rowCount).css("background-color", "blue").css("color", "white");
	
	var arrp = [];
	var arrp2 = [];
   $( ".checkSingle" ).each(function( index ){
	   var chattt = this.id;
	   arrp.push(chattt);
	   arrp2.push(index+1);
	});
	 $( ".checkSingle" ).each(function( index ){
		var chatttt = (this.id).substring(3);
		var iNum = parseInt(chatttt);
		if((iNum+1)%2 == 0){
		$(this).css( "background-color", "green" );
		$(this).css( "color", "white" );
		$('[id=sn_'+chatttt+']').css("color", "white").css("background-color", "green");
		$('[id=dt_'+chatttt+']').val('morning').css("color", "white").css("background-color", "green");
		}
		else{
		$(this).css( "background-color", "blue" );	
		$(this).css( "color", "white" );
		$('[id=sn_'+chatttt+']').css("color", "white").css("background-color", "blue");
		$('[id=dt_'+chatttt+']').val('afternnon').css("color", "white").css("background-color", "blue");
		}
	});
  
  $(".checkSingle").click(function() {
    var chatt = this.id;
	//alert(chatt);
	var $ss = $('[id='+chatt+']').val();
	if($ss == 'absent'){
	 $('[id='+chatt+']').val("present");
	}
	else if($ss == 'present'){
	$('[id='+chatt+']').val("midterm");
	}
	else if($ss == 'midterm'){
	$('[id='+chatt+']').val("absent");
	}
	else{
	$('[id='+chatt+']').val("present");	
	}
	return false;
});
	$(".txtFirstName1").hide();
	$(".txtFirstName2").hide();
	$(".txtFirstName3").hide();
	var pr = $(".txtFirstName1").val("present");
    $("#dosomething1").click(function(){
	$(".checkSingle").val("present");
	});
   var abs = $(".txtFirstName2").val("absent");
    $("#dosomething2").click(function(){
	$(".checkSingle").val("absent");
	});
	var mterm = $(".txtFirstName3").val("midterm");
	$("#dosomething3").click(function(){
	$(".checkSingle").val("midterm");
	});
	var prsec = $(".txtFirstName1").val("present");
    $("#dosomething1").click(function(){
	$(".checkSingle").val("present");
	return false;
	});
   var abssec = $(".txtFirstName2").val("absent");
    $("#dosomething2").click(function(){
	$(".checkSingle").val("absent");
	return false;
	});
	var mtermsec = $(".txtFirstName3").val("midterm");
	$("#dosomething3").click(function(){
	$(".checkSingle").val("midterm");
	return false;
	});
});
</script>

<script>
		$(document).ready(function() {


 $("#sbutt").on("click",function(){
var b = $("#class").find(":selected").text();
$("#class").find(":selected").val(b);
var c = $("#class").find(":selected").val();
//($.trim(c).length);
  }); 	

		
		$("#formid").submit(function( event ) {
			event.preventDefault();	
			
			var arrp = [];
   $( ".checkSingle" ).each(function( index ){
	   var schopenval = this.id;
	   var ar = $('[id='+schopenval+']').val();
	   arrp.push(ar);
	});
	var arrpp = arrp;
	
	var ab = [];
jQuery.each(arrp, function(index, item){
if(item == 'absent'){
	ab.push(item);
}	
});
var abb = ab;

if(arrpp.length == abb.length){
	var chek = prompt("Is school open on this day? Input 'yes' or 'no'" );
	if(chek=='yes'){
		$(".schopen").val("yes");
	}else if(chek=='no'){
		$(".schopen").val("");
	}
	else{
		alert("Input 'yes' or 'no'");
		return false;
	}
}
			
			
$.ajax({
type: "POST",
url: "attend_exec.php",
data: $("#formid").serializeArray(),	
success: function(response){
 if(response==1) { 
		event.preventDefault();
		$(".success").fadeIn();
		setTimeout(function() { $(".success").fadeOut(); }, 2000); 
		//$('#rload').load("rload.php");
		var cj = $("#classj").val();
		var yj = $("#yearj").val();
		var tj = $("#termj").val();
		var armj = $("#armsj").val();
		var dnj = $("#datenamej").val();
		var tnj = $("#tnaj").val();
		//alert(cj);
		//alert(yj);
		//alert(tj);
		//alert(dnj);
		<?php $ddnn = $_POST['datename']; ?>
		var dnjj = <?php echo json_encode($ddnn, JSON_HEX_TAG); ?>;
		<?php $clnn = $_POST['class']; ?>
		var cljj = <?php echo json_encode($clnn, JSON_HEX_TAG); ?>;
		<?php $yrnn = $_POST['year']; ?>
		var yrjj = <?php echo json_encode($yrnn, JSON_HEX_TAG); ?>;
		<?php $ternn = $_POST['term']; ?>
		var terjj = <?php echo json_encode($ternn, JSON_HEX_TAG); ?>;
		<?php $arnn = $_POST['arms']; ?>
		var arjj = <?php echo json_encode($arnn, JSON_HEX_TAG); ?>;
		window.location = "attend.php?class="+cljj+"&year="+yrjj+"&term="+terjj+"&arms="+arjj+"&datename="+dnjj+"&tna="+tnj;
    } else {
		 $(".error").show();
		setTimeout(function() { $(".error").fadeOut(); }, 2000);
		}
		}
});	
});

$("#viewst").html("View Attendance");
$("#viewstu").hide();
 $("#viewst").click(function( event ) {
		event.preventDefault();
		var hi = $("#viewst").html();
		if(hi == "View Attendance"){	
		$("#viewst").html("Hide Attendance");
		$("#viewstu").show();
		}
		else if(hi == "Hide Attendance"){	
		$("#viewst").html("View Attendance");
		$("#viewstu").hide();
		}
	 });
 
 $("#takest").html("Show Take-Attendance Form");
$("#takestu").hide();
 $("#takest").click(function( event ) {
		event.preventDefault();
		var hi = $("#takest").html();
		if(hi == "Show Take-Attendance Form"){	
		$("#takest").html("Hide Take-Attendance Form");
		$("#takestu").show();
		}
		else if(hi == "Hide Take-Attendance Form"){	
		$("#takest").html("Show Take-Attendance Form");
		$("#takestu").hide();
		}
	 });
 
 
 $("#formidupdate").submit(function( event ) {
			event.preventDefault();	
$.ajax({
type: "POST",
url: "update_attend_exec.php",
data: $("#formidupdate").serializeArray(),	
success: function(response){
 if(response==1) { 
		event.preventDefault();
		$(".success").fadeIn();
		setTimeout(function() { $(".success").fadeOut(); }, 2000); 
    } else {
		 $(".error").show();
		setTimeout(function() { $(".error").fadeOut(); }, 2000);
		}
		}
});	
});
 
});
</script>
<style>
ul.topnav {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}
ul.topnav li {float: left;}
ul.topnav li a {
    display: inline-block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    transition: 0.3s;
    font-size: 17px;
}
ul.topnav li a:hover {background-color: #555;}
ul.topnav li.icon {display: none;}

@media screen and (max-width:680px) {
  ul.topnav li:not(:first-child) {display: none;}
  ul.topnav li.icon {
    float: right;
    display: inline-block;
  }
}
@media screen and (max-width:680px) {
  ul.topnav.responsive {position: relative;}
  ul.topnav.responsive li.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  ul.topnav.responsive li {
    float: none;
    display: inline;
  }
  ul.topnav.responsive li a {
    display: block;
    text-align: left;
  }
}
input.checkSingle{
	cursor: pointer;
}
  nav ul li ul li{
           float: left;   
        }
</style>

<style>
.myButton {
	background-color:#44c767;
	-moz-border-radius:28px;
	-webkit-border-radius:28px;
	border-radius:28px;
	border:1px solid #18ab29;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:15px;
	padding:6px 24px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
	float: left;
}
.myButton:hover {
	background-color:#5cbf2a;
}
.myButton:active {
	position:relative;
	top:1px;
}
</style>
  
   <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>
  <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
</head>

<body>
<?php
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
elseif($_SESSION['student'] == 'student'){
include("headerstudent.php");
}
else{ header("location: logout.php");}
?>
<?php
$user = $_SESSION['username'];
?>
<?php
if($_SESSION['role'] == 'admin'){
?>
<center>
<div id="takeitdown" style="display: none;">&nbsp;<br><br></div>
<a style="color: red; font-weight: bold; font-size: 20px; text-decoration: none;" href="#" id="takest"></a><br>
<form action="" method="post" id="takestu" enctype="multipart/form-data">
 <div>
  <?php include "connection.php"; ?>
	<label>
	<select style="width:210px;" name="class" id="class" required ><br>
                   
                    <?php
	$cccc = 0;
	$cccc2 = 0;	
	$result = mysqli_query($db, "SELECT * FROM classes");
						while($row = mysqli_fetch_assoc($result))
							{  
									echo '<option>';
								if($ctype=="Js"){
								if($cccc == 0){	
									$cccc++;
									echo 'SELECT A CLASS';
									continue;
									}		
								if($cccc <= 3){
								echo 'JS'.$cccc;	
								}
								elseif($cccc >= 4 && $cccc <= 6){
									if($cccc == 4){	
									$cccc++;
									echo 'SS'.($cccc2 - 2);	
									continue;
									}
									if($cccc == 5){	
									$cccc++;
									echo 'SS'.($cccc2 - 1);	
									continue;
									}
									if($cccc == 6){	
									$cccc++;
									echo 'SS'.($cccc2 - 0);	
									continue;
									}
								}else{
									break;
								}
								$cccc++;	
								$cccc2++;
									}
								else{	
								if($ctype=="Primary"){
									if($cccc == 0){	
									$cccc++;
									echo 'SELECT A CLASS';
									continue;
									}
								echo 'Primary '.$cccc;
								if($cccc > 5){
									break;
								}
								$cccc++;	
								}
								else{
								echo 'Year '.$cccc;
								if($cccc > 11){
									break;
								}
								$cccc++;	
								}
								}//end of else
								echo '</option>';
							}
						?>
      </select><br>
	  <select style="width:150px;" name="arms" id="arms" required >
                   
                    <?php
	$resultarm = mysqli_query($db,"SELECT arms FROM school where school='".$_SESSION["school"]."'");
				while($rowarm = mysqli_fetch_assoc($resultarm)){
					$arrr2[] = $rowarm["arms"];
				}
				$a = implode(',',$arrr2);
				$b = explode(',',$a);
				$f = (array_filter($b));

	for($i = 0; $i <= (count($f)-1); $i++){
								echo '<option value="'.$f[$i].'">';
								echo $f[$i];
								echo '</option>';
							}
						?>
      </select>
	  
	  <br>
	  <select style="width:150px;" name="year" id="year" required ><br>
                   
                    <?php
	echo '<option value="none" disabled="disabled" selected>SESSION COMMENCING</option>';				
	$result = mysqli_query($db, "SELECT year FROM years");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['year'].'">';
								echo $row['year'];
								echo '</option>';
							}
						?>
      </select>
	  
	  
	   <br>
	  <select style="width:150px;" name="term" id="term" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT term FROM terms");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['term'].'">';
								echo $row['term'];
								echo '</option>';
							}
						?>
      </select>

	
<br><br>
      <input type="date"  style="width:150px;" name="datename" />
    </label>
	
  <br>
      <input type="submit" style="background-color: green; color: white;" id="ssub" class="button" name="btn-upload" value="Get Students" />
   

  </div>
</form>
<br>
<hr />
<br>
</center>    
<?php 
}else{ ?>
<center>
<div id="takeitdown" style="display: none;">&nbsp;<br><br><br></div>
<a style="color: red; font-weight: bold; font-size: 20px; text-decoration: none;" href="#" id="takest"></a><br>
<form action="" method="post" id="takestu" enctype="multipart/form-data">
 <div>
  <?php include "connection.php"; ?>
	<label>
	<select style="width:15%;" name="class" id="class" required ><br>
                   
                    <?php
	$cccc = 0;
	$cccc2 = 0;	
	$result = mysqli_query($db, "SELECT * FROM classes");
						while($row = mysqli_fetch_assoc($result))
							{  
									echo '<option>';
								if($ctype=="Js"){
								if($cccc == 0){	
									$cccc++;
									echo 'SELECT A CLASS';
									continue;
									}		
								if($cccc <= 3){
								echo 'JS'.$cccc;	
								}
								elseif($cccc >= 4 && $cccc <= 6){
									if($cccc == 4){	
									$cccc++;
									echo 'SS'.($cccc2 - 2);	
									continue;
									}
									if($cccc == 5){	
									$cccc++;
									echo 'SS'.($cccc2 - 1);	
									continue;
									}
									if($cccc == 6){	
									$cccc++;
									echo 'SS'.($cccc2 - 0);	
									continue;
									}
								}else{
									break;
								}
								$cccc++;	
								$cccc2++;
									}
								else{	
								if($ctype=="Primary"){
									if($cccc == 0){	
									$cccc++;
									echo 'SELECT A CLASS';
									continue;
									}
								echo 'Primary '.$cccc;
								if($cccc > 5){
									break;
								}
								$cccc++;	
								}
								else{
								echo 'Year '.$cccc;
								if($cccc > 11){
									break;
								}
								$cccc++;	
								}
								}//end of else
								echo '</option>';
							}
						?>
      </select><br>
	  <select style="width:15%;" name="arms" id="arms" required >
                   
                    <?php
	$resultarm = mysqli_query($db,"SELECT arms FROM school where school='".$_SESSION["school"]."'");
				while($rowarm = mysqli_fetch_assoc($resultarm)){
					$arrr2[] = $rowarm["arms"];
				}
				$a = implode(',',$arrr2);
				$b = explode(',',$a);
				$f = (array_filter($b));

	for($i = 0; $i <= (count($f)-1); $i++){
								echo '<option value="'.$f[$i].'">';
								echo $f[$i];
								echo '</option>';
							}
						?>
      </select>
	  
	  <br>
	  <select style="width:15%;" name="year" id="year" required ><br>
                   
                    <?php
	echo '<option value="none" disabled="disabled" selected>SESSION COMMENCING</option>';				
	$result = mysqli_query($db, "SELECT year FROM years");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['year'].'">';
								echo $row['year'];
								echo '</option>';
							}
						?>
      </select>
	  
	  
	   <br>
	  <select style="width:20%;" name="term" id="term" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT term FROM terms");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['term'].'">';
								echo $row['term'];
								echo '</option>';
							}
						?>
      </select>

	
<br><br>
      <input type="date"  style="width:20%;" name="datename" />
    </label>
	
  <br>
      <input type="submit" style="background-color: green; color: white;" id="ssub" class="button" name="btn-upload" value="Get Students" />
   

  </div>
</form>
<br>
<hr />
<br>
</center>
<?php } ?>
<br><br>
<center>
<a style="color: red; font-weight: bold; font-size: 20px; text-decoration: none;" href="#" id="viewst"></a><br>
<form action="upatt.php" method="post" id="viewstu" enctype="multipart/form-data">
 <div>
	<label><select style="width:15%;" name="class" id="class" data-opt="dop" required ><br>
                   
                    <?php
	$cccc = 0;
	$cccc2 = 0;
					$result = mysqli_query($db, "SELECT * FROM classes");
						while($row = mysqli_fetch_assoc($result))
							{
								echo '<option>';
								if($ctype=="Js"){
								if($cccc == 0){	
									$cccc++;
									echo 'SELECT A CLASS';
									continue;
									}		
								if($cccc <= 3){
								echo 'JS'.$cccc;	
								}
								elseif($cccc >= 4 && $cccc <= 6){
									if($cccc == 4){	
									$cccc++;
									echo 'SS'.($cccc2 - 2);	
									continue;
									}
									if($cccc == 5){	
									$cccc++;
									echo 'SS'.($cccc2 - 1);	
									continue;
									}
									if($cccc == 6){	
									$cccc++;
									echo 'SS'.($cccc2 - 0);	
									continue;
									}
								}else{
									break;
								}
								$cccc++;	
								$cccc2++;
									}
								else{	
								if($ctype=="Primary"){
									if($cccc == 0){	
									$cccc++;
									echo 'SELECT A CLASS';
									continue;
									}
								echo 'Primary '.$cccc;
								if($cccc > 5){
									break;
								}
								$cccc++;	
								}
								else{
								echo 'Year '.($cccc+1);
								if($cccc > 11){
									break;
								}
								$cccc++;	
								}
								}//end of else
								echo '</option>';
							}
						?>
      </select>
	  
	  <br>
	  <select style="width:15%;" name="arms" id="arms" required ><br>
                   
                    <?php
	$resultarm2 = mysqli_query($db,"SELECT arms FROM school where school='".$_SESSION["school"]."'");
				while($rowarm2 = mysqli_fetch_assoc($resultarm2)){
					$arrr4[] = $rowarm2["arms"];
				}
				$aa = implode(',',$arrr4);
				$bb = explode(',',$aa);
				$ff = (array_filter($bb));

	for($i = 0; $i <= (count($ff)-1); $i++){
								echo '<option value="'.$ff[$i].'">';
								echo $ff[$i];
								echo '</option>';
							}
						?>
      </select>
	  
	  <br>
	  <select style="width:15%;" name="year" id="year" required ><br>
                   
                    <?php
	echo '<option value="none" disabled="disabled" selected>SESSION COMMENCING</option>';					
	$result = mysqli_query($db, "SELECT year FROM years");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['year'].'">';
								echo $row['year'];
								echo '</option>';
							}
						?>
      </select>
	  
	  
	   <br>
	  <select style="width:15%;" name="term" id="term" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM terms");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['term'].'">';
								echo $row['term'];
								echo '</option>';
							}
						?>
      </select>
	  </label>
<br><br>
      <input type="submit" id="btit" style="background-color: green; color: white;" class="button" name="btn-upload2" value="View Students" />

  </div>
  </center>
</form>
<center>
<br>
<!--<form action="upit.php" method="POST">
  <input type="submit" style="background-color: green; color: white;" class="button" name="btn-uploadup" value="View Students" />
  </form>-->
<div id="rload">
<?php
//if(isset($_POST['btn-upload'])){	
if($_POST['class']==""){
	$classd = $_GET['class'];
}else{
	$classd = $_POST['class'];
}
if($classd=='Primary 1'){
		$class = 'Year 1';
	}
	elseif($classd=='Primary 2'){
		$class = 'Year 2';
	}
	elseif($classd=='Primary 3'){
		$class = 'Year 3';
	}
	elseif($classd=='Primary 4'){
		$class = 'Year 4';
	}
	elseif($classd=='Primary 5'){
		$class = 'Year 5';
	}	
	elseif($classd=='Primary 6'){
		$class = 'Year 6';
	}
	elseif($classd=='JS1'){
		$class = 'Year 7';
	}
	elseif($classd=='JS2'){
		$class = 'Year 8';
	}
	elseif($classd=='JS3'){
		$class = 'Year 9';
	}
	elseif($classd=='SS1'){
		$class = 'Year 10';
	}
	elseif($classd=='SS2'){
		$class = 'Year 11';
	}	
	elseif($classd=='SS3'){
		$class = 'Year 12';
	}		
	else{
		$class = $classd;
	}	


if($_POST['year']==""){
	$year = $_GET['year'];
}else{
	$year = $_POST['year'];
}

if($_POST['term']==""){
	$term = $_GET['term'];
}else{
	$term = $_POST['term'];
}

if($_POST['arms']==""){
	$arms = $_GET['arms'];
}else{
	$arms = $_POST['arms'];
}

if($_POST['datename']==""){
	$datename = $_GET['datename'];
}else{
	$datename = $_POST['datename'];
}

$user=$_SESSION['username'];
$result3 = mysqli_query($db, "SELECT * FROM users2 where username='$user' AND school='".$_SESSION["school"]."'");
while($rowtid = mysqli_fetch_assoc($result3))
{
	$tname = $rowtid['teacher'];
}
$tna = $tname;

$resulttnam = mysqli_query($db, "SELECT DISTINCT(formt) FROM attend where class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while($rowtnam = mysqli_fetch_assoc($resulttnam))
{
$tnamee2[] = $rowtnam['formt'];
}
$ttnamee2 = current($tnamee2);


$resulttnamm = mysqli_query($db, "SELECT formt FROM attend where class='$class' AND arms='$arms' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."' LIMIT 1");
while($rowtnamm = mysqli_fetch_assoc($resulttnamm))
{
$tnameee2 = $rowtnamm['formt'];
}


if(count($tnamee2)==1){
$tna = $ttnamee2;   
}
elseif(count($tnamee2)>1){
$tna = $tnameee2;
}else{
$tna = $tnameee2;    
}

echo '<form style="display: none;" >';
echo '<input id="classj" value="'.$class.'" />';
echo '<input id="yearj" value="'.$year.'" />';
echo '<input id="termj" value="'.$term.'" />';
echo '<input id="armsj" value="'.$arms.'" />';
echo '<input id="datenamej" value="'.$datename.'" />';
echo '<input id="tnaj" value="'.$tna.'" />';
echo '</form>';

echo '<form style="display: none;" >';
echo '<input id="classj2" value="'.$_GET['class'].'" />';
echo '<input id="yearj2" value="'.$_GET['year'].'" />';
echo '<input id="termj2" value="'.$_GET['term'].'" />';
echo '<input id="armsj2" value="'.$_GET['arms'].'" />';
echo '<input id="datenamej2" value="'.$_GET['datename'].'" />';
echo '<input id="tnaj2" value="'.$_GET['tna'].'" />';
echo '</form>';



if($_SESSION['role'] == 'admin'){
$result = mysqli_query($db, "SELECT * FROM studentsbyclass where class='$class' AND year='$year' AND term='$term' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$result2 = mysqli_query($db, "SELECT * FROM attend where class='$class' AND year='$year' AND term='$term' AND datename='$datename' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$resultdistinctstudent = mysqli_query($db, "SELECT DISTINCT(student_name) FROM studentsbyclass where class='$class' AND year='$year' AND term='$term' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$resultdistinctstudentattend = mysqli_query($db, "SELECT DISTINCT(student_name) FROM attend where class='$class' AND year='$year' AND term='$term' AND arms='$arms' AND datename='$datename' AND school='".$_SESSION["school"]."'");    
}else{
$result = mysqli_query($db, "SELECT * FROM studentsbyclass where class='$class' AND year='$year' AND term='$term' AND formt='$tna' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$result2 = mysqli_query($db, "SELECT * FROM attend where class='$class' AND year='$year' AND term='$term' AND formt='$tna' AND datename='$datename' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$resultdistinctstudent = mysqli_query($db, "SELECT DISTINCT(student_name) FROM studentsbyclass where class='$class' AND year='$year' AND term='$term' AND formt='$tna' AND arms='$arms' AND school='".$_SESSION["school"]."'");
$resultdistinctstudentattend = mysqli_query($db, "SELECT DISTINCT(student_name) FROM attend where class='$class' AND year='$year' AND term='$term' AND formt='$tna' AND arms='$arms' AND datename='$datename' AND school='".$_SESSION["school"]."'");
}

while($rowds = mysqli_fetch_assoc($resultdistinctstudent))
{ 
 $valuesds2[] = $rowds['student_name'];	
}
$valuesds3 = array_merge($valuesds2, $valuesds2);

while($rowdsa = mysqli_fetch_assoc($resultdistinctstudentattend))
{ 
 $valuesdsa2[] = $rowdsa['student_name'];	
}
$valuesdsa3 = array_merge($valuesdsa2, $valuesdsa2);

$sd = array_diff($valuesds3,$valuesdsa3);
//print_r($sd);
$sd2 = count($sd);

$countresult2 = mysqli_num_rows($result2);
while($row2 = mysqli_fetch_assoc($result2))
{  						
$values2[] = $row2['student_name'];
$values2attend[] = $row2['attend']; //for the attendance table
}
$values2 = array_merge($values2, $values2);
$values22 =($values2);
$valattend = ($values2attend);
$vtu = count($values22);

while($row = mysqli_fetch_assoc($result))
{  						
$values[] = $row['student_name']; 
$valuesclass[] = $row['class']; 
$valuesyear[] = $row['year']; 
$valuesterm[] = $row['term'];
$valuesarms[] = $row['arms']; 
}
$values = array_merge($values, $values);
$vallue = $values;

$vtuu = count($values);

$valuesclasss = current($valuesclass);
current($valuesclass);
current($valuesyear);
current($valuesterm);
current($valuesarms);

if($valuesclasss=="Year 1"){
	if($ctype=="Js"){
	$cl = "JS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 1";
}else{
	$cl = "Year 1";
}
}
elseif($valuesclasss=="Year 2"){
	if($ctype=="Js"){
	$cl = "JS2";
}elseif($ctype=="Primary"){
	$cl = "Primary 2";
}else{
	$cl = "Year 2";
}
}
elseif($valuesclasss=="Year 3"){
	if($ctype=="Js"){
	$cl = "JS3";
}elseif($ctype=="Primary"){
	$cl = "Primary 3";
}else{
	$cl = "Year 3";
}
}
elseif($valuesclasss=="Year 4"){
	if($ctype=="Js"){
	$cl = "SS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 4";
}else{
	$cl = "Year 4";
}
}
elseif($valuesclasss=="Year 5"){
	if($ctype=="Js"){
	$cl = "SS2";
}elseif($ctype=="Primary"){
	$cl = "Primary 5";
}else{
	$cl = "Year 5";
}
}
elseif($valuesclasss=="Year 6"){
	if($ctype=="Js"){
	$cl = "SS3";
}elseif($ctype=="Primary"){
	$cl = "Primary 6";
}else{
	$cl = "Year 6";
}
}
elseif($valuesclasss=="Year 7"){
	if($ctype=="Js"){
	$cl = "JS1";
}else{
	$cl = "Year 7";
}
}
else if($valuesclasss=="Year 8"){
	if($ctype=="Js"){
	$cl = "JS2";
}else{
	$cl = "Year 8";
}
}else if($valuesclasss=="Year 9"){
	if($ctype=="Js"){
	$cl = "JS3";
}else{
	$cl = "Year 9";
}
}else if($valuesclasss=="Year 10"){
	if($ctype=="Js"){
	$cl = "SS1";
}else{
	$cl = "Year 10";
}
}else if($valuesclasss=="Year 11"){
	if($ctype=="Js"){
	$cl = "SS2";
}else{
	$cl = "Year 11";
}
}else if($valuesclasss=="Year 12"){
	if($ctype=="Js"){
	$cl = "SS3";
}else{
	$cl = "Year 12";
}
}else{
	$cl = "NOT APPLICABLE";
}



$r = array_diff($vallue, $values22); 
echo '<br>';
$vtuuu = $vtuu - $vtu;

$result3 = mysqli_query($db, "SELECT * FROM maxattname WHERE year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($row3 = mysqli_fetch_assoc($result3)) {
$termbegin1[] = $row3['termbegin'];	
}
$termbegin = current($termbegin1);


if($vtuuu < 1){
	if($countresult2 <= 0){
		if(isset($_POST["btn-upload"])){echo "<span style='color:red; font-size:16px; text-decoration: underline;'>You have not inputed the attendance for students enrolled in your class under the selected criteria for: ".strtoupper(date("l, jS \of F Y", strtotime($datename)))."</span><br>" ; }
	}else{
	   if($sd2 > 0){	   
echo '<span style="color: green; font-size: 16px;">Take attendance of Students in '.$cl.' for '.current($valuesterm).', '.current($valuesyear).'/'.(current($valuesyear)+1).' Session</span><br />';	
echo '<br>';
echo '<span style="color: green; font-size: 16px;">Attendance is for '.strtoupper(date("l, jS \of F Y", strtotime($datename))).'</span><br />';	
echo '<br>';
echo '<input type="text" class="txtFirstName1" id="txtFirstName1">';
echo '<button id="dosomething1" style="background-color: green; color: white;">Set All TO PRESENT</button>';
echo '<input type="text" class="txtFirstName2" id="txtFirstName2">';
echo '<button id="dosomething2" style="background-color: green; color: white;">Set All TO ABSENT</button>';
echo '<input type="text" class="txtFirstName3" id="txtFirstName3"><br>';
echo '<button id="dosomething3" style="background-color: green; color: white;">Set All TO MIDTERM</button>';
echo '<br>';
echo '<br>';
//echo '<form action="attend_exec.php" method="post">';
echo '<form id="formid" class="formidd">';
echo '<table id="fhalf"><thead><tr><th colspan="6"></th><tr></thead>';
echo '<tr><td style="text-align:center; font-weight: bold;">Student Name</td><td style="text-align:center; font-weight: bold;">Present</td><td style="display: none;">Class</td><td style="display: none;">Arm</td><td style="display: none;">Year</td><td style="display: none;">Term</td><td style="display: none;">Date</td><td style="font-weight: bold;"style="display: none;" >Day Period</td><th style="display: none;">Is School Open</th></tr>';		
$counter = 0;
foreach ($sd as $key => $sd['student_name']) {
echo '<tr class="checkSingles">';
echo '<td style="text-align:center;"><input type="hidden" name="student_name[]" value="'.$sd['student_name'].'" /><span>'.$sd['student_name'].'</span></td>';
echo '<td style="text-align:center;"><input style="width: 50%;" id="in_'.$counter.'" class="checkSingle" readonly="readonly" type="text" name="attend[]" /></td>';
echo '<td style="display: none;"><input type="text"  name="class[]" id="class_name" value="'.current($valuesclass).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="arms[]" id="arms" value="'.current($valuesarms).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="year[]" id="year" value="'.current($valuesyear).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="term[]" id="term" value="'.current($valuesterm).'" /></td>';
echo '<td style="display: none;"><input type="text" name="datename[]" id="datename" value="'.$datename.'"/></td>';
echo '<td style="display: none;"><input type="text" name="formt[]" id="formt" value="'.$tna.'"/></td>';
echo '<td style="display: none;"><input readonly="readonly" style="width: 50%;" class="checkSingleaft" type="text" name="dtime[]" id="dtime" /></td>';
echo '<td style="display: none;"><input readonly="readonly" style="width: 50%;" type="text" name="schopen[]" class="schopen" /></td>';
echo '</tr>';
$counter++;	
}
echo '<tr style="border: 0;">';
echo '<td colspan="1" style="border: 0;" class="getprogress"><input style="float: left;" type="submit" class="submit_button" name="submit" value="Submit Attendance" /></td><td colspan="3" style="border: 0;"><span class="error" style="display:none; color: red;"><img src="table/del.jpg" width="60" height="60"/>ERROR! You may be attempting to take the class attendance twice for the same day.</span><span class="success" style="display:none; color: green;"><img src="table/492.png" width="60" height="60"/> Attendance taken successfully.</span></td>';
echo '<td colspan="1" style="border: 0; display: none;" class="getfulllist"><a href="#" id="getfulllistbutton">Get Full Class</a></td>';
echo '</tr>';
echo '</table>';
echo '</form>';		
echo '</center><br>';	   	   
	   } 
	   else{
	$resultforupdate = mysqli_query($db, "SELECT * FROM attend WHERE class='$class' AND year='$year' AND arms='$arms' AND term='$term' AND datename='$datename' AND school='".$_SESSION["school"]."' ORDER BY student_name ASC");
	echo "<span style='color:red; font-size:16px; text-decoration: underline;'>You may have already inputed the attendance for the students enrolled in your class under the selected criteria for: ".strtoupper(date("l, jS \of F Y", strtotime($datename)))."</span><br>";
	echo "<span style='color:red; font-size:16px; text-decoration: underline;'>You can update student's attendance status!</span><br>";
	echo '<center>';
	echo '<br>';
	echo '<span style="color: green; font-size: 16px;">Attendance is for '.strtoupper(date("D jS \of F Y", strtotime($datename))).'</span><br />';	
	echo '<br>';
echo '<input type="text" class="txtFirstName1" id="txtFirstName1">';
echo '<button id="dosomething1" style="background-color: green; color: white;">Set All TO PRESENT</button>';
echo '<input type="text" class="txtFirstName2" id="txtFirstName2">';
echo '<button id="dosomething2" style="background-color: green; color: white;">Set All TO ABSENT</button>';
echo '<input type="text" class="txtFirstName3" id="txtFirstName3"><br>';
echo '<button id="dosomething3" style="background-color: green; color: white;">Set All TO MIDTERM</button>';
echo '<br>';
echo '<form id="formidupdate">';
echo '<table><thead><tr><th colspan="6"></th><tr></thead>';
echo '<tr><td style="text-align:center; font-weight: bold; display: none;">ID</td><td style="text-align:center; font-weight: bold;">Student Name</td><td style="text-align:center; font-weight: bold;">Status</td><td style="text-align:center; font-weight: bold; display: none;">Day Period</td></tr>';		
$counter = 0;
while ($resultforupdateit = mysqli_fetch_assoc($resultforupdate)) {
echo '<tr class="checkSingles">';
echo '<td style="display: none;"><input type="text" style="width:80%; display: none;" name="id[]" id="id" value="'.$resultforupdateit["id"].'" readonly="readonly" /></td>';	
echo '<td style="text-align:center;"><input style="text-align:center;" type="text" name="student_name[]" value="'.$resultforupdateit["student_name"].'" id="sn_'.$counter.'" readonly/></td>';
echo '<td style="text-align:center; height: 60px;"><input style="width: 60%; text-align:center; height: 50%;" type="text" name="attend[]" class="checkSingle" readonly="readonly" value="'.$resultforupdateit["attend"].'" id="in_'.$counter.'" /></td>';
echo '<td style="display: none;"><input readonly="readonly" style="width: 80%; text-align:center; height: 50%;" class="checkSingleaft" type="text" name="dtime[]" id="dt_'.$counter.'" /></td>';
echo '</tr>';
$counter++;
}
echo '<tr style="border: 0;">';
echo '<td colspan="2" style="border: 0;" class="getprogress"><input style="left: right;" type="submit" class="submit_button" name="submit" value="Submit Attendance" /></td><td colspan="2" style="border: 0;"><span class="error" style="display:none; color: red;"><img src="table/del.jpg" width="60" height="60"/>Updates could not be made.</span><span class="success" style="display:none; color: green;"><img src="table/492.png" width="60" height="60"/> Attendance updated successfully.</span></td>';
echo '</tr>';
echo '</table>';
echo '</form>';	
echo '</center>';
}
}
}
else if($vtu == 0){
	$values22[] = "nothingham";
	$r = array_diff($vallue, $values22);
echo '<span style="color: green; font-size: 16px;">Take attendance of Students in '.$cl.''.current($valuesarms).' for '.current($valuesterm).', '.current($valuesyear).'/'.(current($valuesyear)+1).' Session</span><br />';		
echo '<span style="color: green; font-size: 16px;">Attendance is for '.strtoupper(date("l, jS \of F Y", strtotime($datename))).'</span><br />';	
echo '<br>';
echo '<center>';
echo '<input type="text" class="txtFirstName1" id="txtFirstName1">';
echo '<button id="dosomething1" style="background-color: green; color: white;">Set All TO PRESENT</button>';
echo '<input type="text" class="txtFirstName2" id="txtFirstName2">';
echo '<button id="dosomething2" style="background-color: green; color: white;">Set All TO ABSENT</button>';
echo '<input type="text" class="txtFirstName3" id="txtFirstName3"><br>';
echo '<button id="dosomething3" style="background-color: green; color: white;">Set All TO MIDTERM</button>';
echo '</center><br>';
echo '<br>';
echo '<form id="formid" class="formid">';
echo '<table id="fhalf"><thead><tr><th colspan="6"></th><tr></thead>';
echo '<tr><td style="text-align:center; font-weight: bold;">Student Name</td><td style="text-align:center; font-weight: bold;">Present</td><td style="display: none;">Class</td><td style="display: none;">Arm</td><td style="display: none;">Year</td><td style="display: none;">Term</td><td style="display: none;">Date</td><td style="font-weight: bold; display: none;">Day Period</td><td style="display: none;">Is School Open</td></tr>';		
$counter = 0;
foreach ($r as $key => $r['student_name']) {
echo '<tr class="checkSingles">';	
echo '<td style="text-align:center; width: 200px;"><input type="hidden" name="student_name[]" value="'.$r['student_name'].'" />'.$r['student_name'].'</td>';
echo '<td style="text-align:center; height: 60px;"><input style="width: 50%;" id="in_'.$counter.'" class="checkSingle" readonly="readonly" type="text" name="attend[]" value="absent" /></td>';
echo '<td style="display: none;"><input type="text"  name="class[]" id="class_name" value="'.current($valuesclass).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="arms[]" id="arms" value="'.current($valuesarms).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="year[]" id="year" value="'.current($valuesyear).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="term[]" id="term" value="'.current($valuesterm).'" /></td>';
echo '<td style="display: none;"><input type="text" name="datename[]" id="datename" value="'.$datename.'"/></td>';
echo '<td style="display: none;"><input type="text" name="formt[]" id="formt" value="'.$tna.'"/></td>';
echo '<td style="display: none;"><input readonly="readonly" style="width: 50%;" class="checkSingleaft" type="text" name="dtime[]" id="dtime" /></td>';
echo '<td style="display: none;"><input readonly="readonly" style="width: 50%;" type="text" name="schopen[]" class="schopen" /></td>';
echo '</tr>';
$counter++;	
}
echo '<tr style="border: 0;">';
echo '<td colspan="2" style="border: 0;" class="getprogress"><input style="float: left;" type="submit" class="submit_button" name="submit" value="Submit Attendance" /></td><td colspan="3" style="border: 0;"><span class="error" style="display:none; color: red;"><img src="table/del.jpg" width="60" height="60"/>ERROR! You may be attempting to take the class attendance twice for the same day.</span><span class="success" style="display:none; color: green;"><img src="table/492.png" width="60" height="60"/> Attendance taken successfully.</span></td>';
echo '</tr>';
echo '</table>';
echo '</form>';		
}
else{
echo '<span style="color: green; font-size: 16px;">Take attendance of Students in '.$cl.''.current($valuesarms).' for '.current($valuesterm).', '.current($valuesyear).'/'.(current($valuesyear)+1).' Session</span><br />';		
echo '<span style="color: green; font-size: 16px;">Attendance is for '.strtoupper(date("l, jS \of F Y", strtotime($datename))).'</span><br />';	
echo '<br>';
echo '<center>';
echo '<input type="text" class="txtFirstName1" id="txtFirstName1">';
echo '<button id="dosomething1" style="background-color: green; color: white;">Set All TO PRESENT</button>';
echo '<input type="text" class="txtFirstName2" id="txtFirstName2">';
echo '<button id="dosomething2" style="background-color: green; color: white;">Set All TO ABSENT</button>';
echo '<input type="text" class="txtFirstName3" id="txtFirstName3"><br>';
echo '<button id="dosomething3" style="background-color: green; color: white;">Set All TO MIDTERM</button>';
echo '</center><br>';
echo '<br>';
echo '<form id="formid" class="formid">';
echo '<table id="fhalf"><thead><tr><th colspan="6"></th><tr></thead>';
echo '<tr><td style="text-align:center; font-weight: bold;">Student Name</td><td style="text-align:center; font-weight: bold;">Present</td><td style="display: none;">Class</td><td style="display: none;">Arm</td><td style="display: none;">Year</td><td style="display: none;">Term</td><td style="display: none;">Date</td><td style="font-weight: bold; display: none;">Day Period</td><td style="display: none;">Is School Open</td></tr>';		
$counter = 0;
foreach ($r as $key => $r['student_name']) {
echo '<tr class="checkSingles">';	
echo '<td style="text-align:center; height: 60px; width: 90px;"><input type="hidden" name="student_name[]" value="'.$r['student_name'].'" />'.$r['student_name'].'</td>';
echo '<td style="text-align:center; height: 60px;"><input style="width: 50%;" id="in_'.$counter.'" class="checkSingle" readonly="readonly" type="text" name="attend[]" value="absent" /></td>';
echo '<td style="display: none;"><input type="text"  name="class[]" id="class_name" value="'.current($valuesclass).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="arms[]" id="arms" value="'.current($valuesarms).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="year[]" id="year" value="'.current($valuesyear).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="term[]" id="term" value="'.current($valuesterm).'" /></td>';
echo '<td style="display: none;"><input type="text" name="datename[]" id="datename" value="'.$datename.'"/></td>';
echo '<td style="display: none;"><input type="text" name="formt[]" id="formt" value="'.$tna.'"/></td>';
echo '<td style="display: none;"><input readonly="readonly" style="width: 50%;" class="checkSingleaft" type="text" name="dtime[]" id="dtime" /></td>';
echo '<td style="display: none;"><input readonly="readonly" style="width: 50%;" type="text" name="schopen[]" class="schopen" /></td>';
echo '</tr>';
$counter++;	
}
echo '<tr style="border: 0;">';
echo '<td colspan="2" style="border: 0;" class="getprogress"><input style="float: left;" type="submit" class="submit_button" name="submit" value="Submit Attendance" /></td><td colspan="3" style="border: 0;"><span class="error" style="display:none; color: red;"><img src="table/del.jpg" width="60" height="60"/>ERROR! You may be attempting to take the class attendance twice for the same day.</span><span class="success" style="display:none; color: green;"><img src="table/492.png" width="60" height="60"/> Attendance taken successfully.</span></td>';
echo '</tr>';
echo '</table>';
echo '</form>';	
}
//}
?>
<br><br><br><br>
</div>
<?php
include("footer.php");
?>
</body>
</html>