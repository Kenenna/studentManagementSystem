<?php
	session_start();
	include("auth.php"); //include auth.php file on all secure pages
	include "connection.php";
	include("auth.php");
	include('db.php');	
$score_id = $_POST['score_id'];	
$student_name = $_POST['student_name'];
$class_name = $_POST['class_name'];
$year = $_POST['year'];
$arms = $_POST['arms'];
$term = $_POST['term'];
$subject = $_POST['subject'];
$teacher_id = $_POST['teacher_id'];
$score2 = $_POST['score'];
$scoreraw2 = $_POST['scoreraw'];

$class_names = $_POST['class_name'][0];
$years = $_POST['year'][0];
$armss = $_POST['arms'][0];
$terms = $_POST['term'][0];
$subjects = $_POST['subject'][0];
$teacher_ids = $_POST['teacher_id'][0];

$hwraw2 = $_POST['hwraw'];
$cwraw2 = $_POST['cwraw'];
$testraw2 = $_POST['testraw'];

$remark = $_POST['remark'];
$hwmaxname = $_POST['hwmaxname'];
$cwmaxname = $_POST['cwmaxname'];
$testmaxname = $_POST['testmaxname'];



for ($i = 0; $i <= (count($score_id)-1); $i++){
	$hw[$i] = round(($hwraw2[$i]/$hwmaxname[$i])*30);
	$cw[$i] = round(($cwraw2[$i]/$cwmaxname[$i])*30);
	$test[$i] = round((($testraw2[$i]/$testmaxname[$i])*40));
	$scoreraw[$i] = $hwraw2[$i]+$cwraw2[$i]+$testraw2[$i];
	$score[$i] = round((($hwraw2[$i]+$cwraw2[$i]+$testraw2[$i])*100)/($hwmaxname[$i]+$cwmaxname[$i]+$testmaxname[$i]));
	//echo $score[$i]."--".$scoreraw[$i];
	//echo "<br>";
$sql1=mysqli_query($db,"UPDATE scoresmid SET score='$score[$i]', scoreraw='$scoreraw[$i]', hwraw='$hwraw2[$i]', cwraw='$cwraw2[$i]', testraw='$testraw2[$i]', hw='$hw[$i]', cw='$cw[$i]', test='$test[$i]', student_name='$student_name[$i]', remark='$remark[$i]', hwmaxname='$hwmaxname[$i]', cwmaxname='$cwmaxname[$i]', testmaxname='$testmaxname[$i]' WHERE score_id='$score_id[$i]' AND school='".$_SESSION["school"]."'");
}

if($sql1){
$resultcheck = mysqli_query($db, "SELECT * FROM scoresmid where arms='$armss' AND class_name='$class_names' AND year='$years' AND term='$terms' AND subject='$subjects' AND teacher_id='$teacher_ids' AND school='".$_SESSION["school"]."' ORDER BY student_name ASC");
		$totstr = "";
		$scorerawstr="";
		$idstr="";
		$hwrawstr="";
		$hwstr="";
		$cwstr="";
		$teststr="";
		while($rowcheck = mysqli_fetch_assoc($resultcheck))
							{  
								$id2[] = $rowcheck['score_id'];
								$tot2[] = $rowcheck['score'];
								$scoreraw3[] = $rowcheck['scoreraw'];
								$hwraw2[] = $rowcheck['hwraw'];
								$cwraw2[] = $rowcheck['cwraw'];
								$testraw2[] = $rowcheck['testraw'];
								$hw2[] = $rowcheck['hw'];
								$cw2[] = $rowcheck['cw'];
								$test2[] = $rowcheck['test'];
							}					
							
for ($x = 0; $x <= (count($id2)-1); $x++){
	if($x==(count($id2)-1)){
$idstr .= $id2[$x];	
$totstr .= $tot2[$x];
$hwrawstr .= $hwraw2[$x];
$scorerawstr .= $scoreraw3[$x];
$hwstr .= $hw2[$x];
$cwstr .= $cw2[$x];
$teststr .= $test2[$x];
	}else{
$idstr .= $id2[$x]."-";	
$totstr .= $tot2[$x]."-";
$hwrawstr .= $hwraw2[$x]."-";
$scorerawstr .= $scoreraw3[$x]."-";	
$hwstr .= $hw2[$x]."-";
$cwstr .= $cw2[$x]."-";
$teststr .= $test2[$x]."-";	
	}
}	
	echo $idstr."|".$scorerawstr."|".$totstr."|".$hwrawstr."|".$hwstr."|".$cwstr."|".$teststr."|"."1";	
}	
else{
echo 0;
}
?>