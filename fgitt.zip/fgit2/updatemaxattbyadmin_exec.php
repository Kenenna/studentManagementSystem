<?php
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
if (isset($_REQUEST['btn-upload'])) {
$id = $_REQUEST['id'];
$maxattname = $_REQUEST['maxattname'];
$year = $_REQUEST['year'];
$term = $_REQUEST['term'];

$checktea = mysqli_query($db, "SELECT * FROM maxattname where year='$year' AND term='$term' AND maxattname='$maxattname' AND school='".$_SESSION["school"]."'");
  $counttea = mysqli_num_rows($checktea);
  if($counttea < 1){ 
$query =("UPDATE maxattname SET year='$year', term='$term', maxattname='$maxattname' WHERE id='$id' AND school='".$_SESSION["school"]."'");

if (!mysqli_query ($db,$query) )
			{
			echo '<img src="table/del.jpg" /> &nbsp;! data not updated';
			echo '<meta content="2;viewmaxatt.php" http-equiv="refresh" />';	
			die (mysqli_error());
			}else{
		echo '<img src="table/492.png" /> &nbsp;! data updated successfully';
		echo '<meta content="2;viewmaxatt.php" http-equiv="refresh" />';
			}
  }else{
	echo "<center><div class='form'><h2 style='color: red;'>The update made matches a record already in the database.</h2></div></center>";
	echo '<meta content="2;viewmaxatt.php" http-equiv="refresh" />';
  }
}
?>