<?php
session_start();
include("auth.php");
include "connection.php";
$regstu_id=$_REQUEST['regstu_id']; 


 $checkimg = mysqli_query($db, "SELECT student_name FROM regstu where regstu_id='$regstu_id'");
		while($rowimg = mysqli_fetch_assoc($checkimg))
							{
								$im2[] = $rowimg['student_name'];
							}
							$im = current($im2);
							

$query = mysqli_query($db,"DELETE FROM regstu WHERE regstu_id='$regstu_id' AND school='".$_SESSION['school']."'");
$query2 = mysqli_query($db,"DELETE FROM img WHERE student_name='$im' AND school='".$_SESSION['school']."'");

		if (!$query)
			{
			echo '<img src="../images/492.png" /> &nbsp;! student not deleted';
			echo '<meta content="2;index.php" http-equiv="refresh" />';	
			die (mysqli_error());
			}else{
			echo '<img src="../images/492.png" /> &nbsp;! student deleted successfully';
			echo '<meta content="2;index.php" http-equiv="refresh" />';
			}
?>
