<?php
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
$id=$_REQUEST['id']; 
$query = "DELETE FROM formt WHERE id='$id'";

		if (!mysqli_query ($db,$query) )
			{
			echo '<img src="table/del.jpg" /> &nbsp;! tutor details not deleted';
			echo '<meta content="2;admviewtutor.php" http-equiv="refresh" />';	
			die (mysqli_error());
			}else{
	
		echo '<img src="table/492.png" /> &nbsp;! tutor details deleted successfully';
		echo '<meta content="2;admviewtutor.php" http-equiv="refresh" />';
			}
?>
