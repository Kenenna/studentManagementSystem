<?php
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
if (isset($_REQUEST['btn-upload'])) {
$id = $_REQUEST['id'];
$attend = $_REQUEST['attend'];
$class = $_REQUEST['class'];
$year = $_REQUEST['year'];
$term = $_REQUEST['term'];
$arms = $_REQUEST['arms'];
$formt = $_REQUEST['formt'];
$query =("UPDATE attend SET attend='$attend' WHERE id='$id' AND school='".$_SESSION["school"]."'");

if (!mysqli_query ($db,$query) )
			{
			echo '<img src="table/del.jpg" /> &nbsp;! attendance not updated';
			echo '<meta content="2;attend.php" http-equiv="refresh" />';	
			die (mysqli_error());
			}else{
				echo '<center><div>';
		echo '<img src="table/492.png" /> &nbsp;! attendance updated successfully';
		//echo '<meta content="2;attend.php" http-equiv="refresh" />';
		echo '<form action="upatt.php" method="post">';
echo '<input style="display: none;" readonly="readonly" type="text" id="formt" name="formt" value="'.$formt.'" />';
echo '<input style="display: none;" readonly="readonly" type="text" id="class" name="class" value="'.$class.'" />';
echo '<input style="display: none;" readonly="readonly" type="text" id="arms" name="arms" value="'.$arms.'" />';
echo '<input style="display: none;" readonly="readonly" type="text" id="year" name="year" value="'.$year.'" />'; 
echo '<input style="display: none;" readonly="readonly" type="text" id="term" name="term" value="'.$term.'" />';
echo '<input type="submit" style="background-color: green; color: white;" class="button" name="bt-upload2" value="Return to list of students in class." />';
echo '</form>';
echo '</div></center>';
			}
}
?>
