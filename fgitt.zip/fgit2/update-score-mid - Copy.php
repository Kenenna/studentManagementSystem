<?php
	include("auth.php");
	include('db.php');	
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Update Scores</title>
<link rel="stylesheet" href="style.css" type="text/css" />
<link rel="stylesheet" href="css/style.css" />
		<link href="table/css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
        <link rel="stylesheet" type="text/css" href="table/css/DT_bootstrap.css">

	<script src="table/js/jquery.js" type="text/javascript"></script>
<script src="table/js/bootstrap.js" type="text/javascript"></script>
	
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/jquery.dataTables.js"></script>
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/DT_bootstrap.js"></script>

<style>
ul.topnav {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}
ul.topnav li {float: left;}
ul.topnav li a {
    display: inline-block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    transition: 0.3s;
    font-size: 17px;
}
ul.topnav li a:hover {background-color: #555;}
ul.topnav li.icon {display: none;}

@media screen and (max-width:680px) {
  ul.topnav li:not(:first-child) {display: none;}
  ul.topnav li.icon {
    float: right;
    display: inline-block;
  }
}
@media screen and (max-width:680px) {
  ul.topnav.responsive {position: relative;}
  ul.topnav.responsive li.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  ul.topnav.responsive li {
    float: none;
    display: inline;
  }
  ul.topnav.responsive li a {
    display: block;
    text-align: left;
  }
}
</style>

<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += "responsive";
    } else {
        x.className = "topnav";
    }
}
</script>

<script type="text/javascript" src="jq.js"></script>
<script>
$(document).ready(function(){
	//$(".newhwmax").css("display","none");
	//$(".newcwmax").css("display","none");
	//$(".newtestmax").css("display","none");
	var inihw = $(".newhwmax").val();
	var inicw = $(".newcwmax").val();
	var initest = $(".newtestmax").val();
	$("#txtFirstName").val(inihw);
	$("#txtFirstName1").val(inicw);
	$("#txtFirstName2").val(initest); 
	$("#txtFirstName").css("width","30px");
	$("#txtFirstName1").css("width","30px");
	$("#txtFirstName2").css("width","30px");
	$("#txtFirstName").before("<span>HW MAX:</span> ");
	$("#txtFirstName1").before("<span>CW MAX:</span> ");
	$("#txtFirstName2").before("<span>TEST MAX:</span> ");
	$("#dosomething").click(function(){
	//$("#txtFirstName").fadeIn(3000);
	//$("#txtFirstName1").fadeIn(3000);		
	var inihw2 = $(".newhwmax").val();
	var inicw2 = $(".newcwmax").val();
	var initest2 = $(".newtestmax").val();
	
	var valueit=$('#txtFirstName').val();
	var valueit1=$('#txtFirstName1').val();	
	var valueit2=$('#txtFirstName2').val();	
 if(valueit == 0){
	 $(".newhwmax").val(inihw);
				}
 else{
	 $(".newhwmax").val(valueit);
	}				
	if(valueit1 == 0){
	 $(".newcwmax").val(inicw);
				}
 else{
	 $(".newcwmax").val(valueit1);
	}
	if(valueit2 == 0){
	 $(".newtestmax").val(initest);
				}
 else{
	 $(".newtestmax").val(valueit2);
	}
});

$(".remark").css("cursor","pointer");
$(".remark").click(function(){
	var chatt = this.id;
	var ss = $('[id='+chatt+']').val();
	var comm = prompt("Enter comment",ss);
	if(comm==null){
	 $('[id='+chatt+']').val(ss);
	}else{
	 $('[id='+chatt+']').val(comm);	
	}
});



});
</script>
</head>

<body>
<?php
if($_SESSION['role'] == 'teacher'){
echo '<ul class="topnav" id="myTopnav">';
echo '<li><a href="index.php">Home</a></li>';
echo '<li><a href="teacher-student-mid.php">Add Midscores</a></li>';
echo '<li><a href="teacher-student.php">Add Scores</a></li>';
echo '<li><a href="update-score.php">Update Scores</a></li>';
echo '<li><a href="formclasses.php">Form Tutor</a></li>';
echo '<li><a href="affective.php">Input Ranks</a></li>';
echo '<li><a href="teagetresultmid.php">Midterm Result</a></li>';
echo '<li><a href="teagetresult.php">Term Result</a></li>';
echo '<li><a href="attend.php">Attendance</a></li>';
echo '<li><a href="logout.php">Logout</a></li>';
echo '<li class="icon">';
echo '<a href="javascript:void(0);" onclick="myFunction()">&#9776;</a>';
echo '</li>';
echo '</ul>';
}
elseif($_SESSION['role'] == 'admin'){
echo '<ul class="topnav" id="myTopnav">';
echo '<li><a href="adstuadmin.php">Add Student</a></li>';
echo '<li><a href="adminaddformt.php">Add Form Tutor</a></li>';
echo '<li><a href="admgetresult.php">Student\'s Result</a></li>';
echo '<li><a href="admviewtea.php">View Teachers</a></li>';
echo '<li><a href="admviewtutor.php">View Tutors</a></li>';
echo '<li><a href="viewmaxatt.php">View Max Attendance</a></li>';
echo '<li><a href="logout.php">Logout</a></li>';
echo '<li class="icon">';
echo '<a href="javascript:void(0);" onclick="myFunction()">&#9776;</a>';
echo '</li>';
echo '</ul>';
}
else{echo "";}
?>
<?php
$user = $_SESSION['username'];
?>
<BR><BR>
<form action="" method="post" enctype="multipart/form-data">
<center>
 <div>
 <?php 
include "connection.php";
?> 
	<label><select style="width:15%;" name="class_name" id="class_name" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM classes");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['class_name'].'">';
								echo $row['class_name'];
								echo '</option>';
							}
						?>
      </select>
	  
	  <br>
	  <select style="width:15%;" name="year" id="year" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM years");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['year'].'">';
								echo $row['year'];
								echo '</option>';
							}
						?>
      </select>
	  
	  
	   <br>
	  <select style="width:15%;" name="term" id="term" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM terms");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['term'].'">';
								echo $row['term'];
								echo '</option>';
							}
						?>
      </select>
	   <br>
	  <select style="width:15%;" name="subject" id="subject" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM subjects");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['subject'].'">';
								echo $row['subject'];
								echo '</option>';
							}
						?>
      </select>
	  
	   <br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM users2 where username='$user'");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<input style="display:none" type="hidden" name="teacher_id" value="'.$row['teacher_id'].'">';
							}
						?>  
	  
	  </label>
	  
  <label>
      <input type="submit" class="button" name="btn-upload" value="Submit Form" />
    </label>

  </div>
  </center>
</form><br>

<?php
if(isset($_POST['btn-upload'])){
	
$user=$_SESSION['username'];
$result3 = mysqli_query($db, "SELECT * FROM users2 where username='$user'");
while($rowtid = mysqli_fetch_assoc($result3))
{
	$a = $rowtid['teacher_id'];
}
$tid =  $a;	
		
$class_name = $_POST['class_name'];
$year = $_POST['year'];
$term = $_POST['term'];
$subject = $_POST['subject'];
$teacher_id = $tid;  


$resultcheck2 = mysqli_query($db, "SELECT * FROM scoresmid where class_name='$class_name' AND year='$year' AND term='$term' AND subject='$subject' AND teacher_id='$teacher_id'");
$resultcount2 = mysqli_num_rows($resultcheck2);   
if($resultcount2 == 0){
	echo ''; 
}else{
echo '<center>';
echo '<input type="text" placeholder="Max Hw Score" class="txtFirstName" id="txtFirstName"><br>';
echo '<input type="text" placeholder="Max Cw Score" class="txtFirstName1" id="txtFirstName1"><br>';
echo '<input type="text" placeholder="Max Test Score" class="txtFirstName2" id="txtFirstName2"><br>';
echo '<button id="dosomething" style="background-color: green; color: white;">Update Max Scores</button>';
echo '<div style="color: red;">NOTE THAT MAX HW, CW AND TEST SCORES ARE FOR ONLY THE 1ST HALF OF THE TERM.<br>TO UPDATE MAX SCORES FOR 2ND HALF, <a href="update-score.php">CLICK HERE.</a></div>';
echo '</center><br>';
}

$resultcheck = mysqli_query($db, "SELECT * FROM scoresmid where class_name='$class_name' AND year='$year' AND term='$term' AND subject='$subject' AND teacher_id='$teacher_id'");
$resultcount = mysqli_num_rows($resultcheck);   
if($resultcount == 0){
	echo '<center><span style="color: red; font-size: 16px;">No scores to be updated for students in your '.$term. ', '.$year.', '.$class_name.' '.$subject.' class.<br /></span></center>'; 
}else{
echo '<center><span style="color: green; font-size: 16px;">Update the scores of students in your '.$term. ', '.$year.', '.$class_name.' '.$subject.' class.<br /></span></center>';            
	include "connection.php";
	
	echo '<div class="row-fluid" style="width:100%;">';
echo '<div class="span12">';
echo '<div class="container" style="width:100%;">';
echo '<form method="POST" name="form" action="update_score_mid_exec.php">';
echo '<table style="width:100%;" cellpadding="1" cellspacing="1" border="1" class="table table-striped table-bordered" id="example">';
echo '<thead><tr style="text-align:left;">';
echo '<th style="display: none;">Score ID</th><th style="text-align: center; width: 3%">Student\'s Name</th><th style="text-align: center; width: 3%">Total</th><th style="text-align: center; width: 3%">Total (Raw)</th><th style="text-align: center; width: 3%">HW (RAW)</th><th style="text-align: center; width: 3%">CW (RAW)</th><th style="text-align: center; width: 3%">TEST (RAW)</th><th style="text-align: center; width: 3%">HW (30)</th><th style="text-align: center; width: 3%">CW (30)</th><th style="text-align: center; width: 3%">TEST (40)</th><th style="text-align: center; width: 3%">Remark</th><th style="display: none;">Class</th><th style="display: none;">Year</th><th style="display: none;">Term</th><th style="display: none;">Subject</th><th style="display: none;">Teacher ID</th><th>HW Max</th><th>CW Max</th><th>Test Max</th>';
echo '</thead></tr>';
	$countmid = 0;
$result = mysqli_query($db, "SELECT * FROM scoresmid where class_name='$class_name' AND year='$year' AND term='$term' AND subject='$subject' AND teacher_id='$teacher_id'");
						while($row = mysqli_fetch_assoc($result))
							{  
							 echo '<tr>';
							  echo '<td style="display: none;"><input type="text" style="width:220px;" name="score_id[]" id="score_id" value="'.$row['score_id'].'" readonly="readonly" /></td>';
							 echo '<td style="text-align: center; width: 3%"><input style="text-align: center; width: 80%" type="text" name="student_name[]" id="student_name" value="'.$row['student_name'].'" readonly /></td>';
							 echo '<td style="text-align: center; width: 3%"><input style="text-align: center; width: 40%" type="text" value="'.$row['score'].'" name="score[]" id="score" readonly/></td>';
							 echo '<td style="text-align: center; width: 3%"><input style="text-align: center; width: 60%" type="text" value="'.$row['scoreraw'].'" name="scoreraw[]" id="scoreraw" readonly/></td>'; 
							 
							 echo '<td style="text-align: center; width: 3%"><input style="text-align: center; width: 60%" type="text" value="'.$row['hwraw'].'" name="hwraw[]" id="hwraw" /></td>';
							 echo '<td style="text-align: center; width: 3%"><input style="text-align: center; width: 60%"type="text" value="'.$row['cwraw'].'" name="cwraw[]" id="cwraw" /></td>';
							 echo '<td style="text-align: center; width: 3%"><input style="text-align: center; width: 60%"type="text" value="'.$row['testraw'].'" name="testraw[]" id="testraw" /></td>';
							  
							 echo '<td style="text-align: center; width: 3%"><input style="text-align: center; width: 60%" type="text" value="'.$row['hw'].'" name="hw[]" id="hw" readonly/></td>';
							 echo '<td style="text-align: center; width: 3%"><input style="text-align: center; width: 60%"type="text" value="'.$row['cw'].'" name="cw[]" id="cw" readonly/></td>';
							 echo '<td style="text-align: center; width: 3%"><input style="text-align: center; width: 60%"type="text" value="'.$row['test'].'" name="test[]" id="test" readonly/></td>';
							 echo '<td style="text-align: center; width: 3%"><input style="text-align: center; width: 60%" type="text" value="'.$row['remark'].'" name="remark[]" class="remark" id="remark_'.$countmid.'" /></td>';
							 echo '<td style="display: none;"><input type="text" name="class_name[]" id="class_name" value="'.$row['class_name'].'"></td>';
							 echo '<td style="display: none;"><input type="text" name="year[]" id="year" value="'.$row['year'].'"></td>';
							 echo '<td style="display: none;"><input type="text" name="term[]" id="term" value="'.$row['term'].'"></td>';
							 echo '<td style="display: none;"><input type="text" name="subject[]" id="subject" value="'.$row['subject'].'"></td>';
							 echo '<td style="display: none;"><input type="text" name="teacher_id[]" id="teacher_id" value="'.$row['teacher_id'].'"></td>';
							 echo '<td style="text-align: center; width: 3%;"><input style="text-align: center; width: 60%;" class="newhwmax" type="text" name="hwmaxname[]" id="hwmaxname" value="'.$row['hwmaxname'].'" readonly /></td>';
							 echo '<td style="text-align: center; width: 3%;"><input style="text-align: center; width: 60%;" class="newcwmax" type="text" name="cwmaxname[]" id="cwmaxname" value="'.$row['cwmaxname'].'" readonly /></td>';
							echo '<td style="text-align: center; width: 3%;"><input style="text-align: center; width: 60%;" class="newtestmax" type="text" name="testmaxname[]" id="testmaxname" value="'.$row['testmaxname'].'" readonly /></td>';
							echo  '</tr>';
							$countmid++;
							}
echo '<tr style="border: 0;">';
echo '<td colspan="19"><input type="submit" class="submit_button" name="submit" value="Update Scores" /></td>';
//echo '<td style="display: none;"></td><td><input type="submit" class="submit_button" name="submit" value="Update Scores" /></td><td style="display: none;"></td><td style="display: none;"></td><td></td><td></td><td></td><td style="display: none;"></td><td></td><td></td><td></td><td style="display: none;"></td><td style="display: none;"></td><td style="display: none;"></td><td style="display: none;"></td>';
echo '</tr>';	
echo '</table>';
echo '</form>';	
echo '</div></div></div>';
}}

?>

<br>
</html>