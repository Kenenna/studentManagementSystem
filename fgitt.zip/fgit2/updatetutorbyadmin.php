<?php 
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Update Teacher</title>
<link rel="stylesheet" href="css/style.css" />
        <link rel="stylesheet" type="text/css" href="table/css/DT_bootstrap.css">

	<script src="table/js/jquery.js" type="text/javascript"></script>
<script src="table/js/bootstrap.js" type="text/javascript"></script>
	
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/jquery.dataTables.js"></script>
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/DT_bootstrap.js"></script>
   
   <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
   
 /*  $("#menu-btn").on('click', function() {
      var navht = $("#respMenu").height();
       if($('.checkvis').is(':visible')){
       alert("y");
   }else{
      alert("n"); 
   }
   }); */
   
   
  });
 </script>	
<style>
select{
	height: auto;
}
</style>
<style>
form {
  background: -webkit-linear-gradient(bottom, #CCCCCC, #EEEEEE 175px);
  background: -moz-linear-gradient(bottom, #CCCCCC, #EEEEEE 175px);
  background: linear-gradient(bottom, #CCCCCC, #EEEEEE 175px);
  width: 380px;
  height: 370px;
  font-family: Tahoma, Geneva, sans-serif;
  font-size: 16px;
  font-style: italic;
  line-height: 24px;
  font-weight: bold;
  color: #09C;
  text-decoration: none;
  border-radius: 10px;
  padding: 10px;
  border: 1px solid #999;
  border: inset 1px solid #333;
  -webkit-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  -moz-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  margin-top: 40px;
}
@media only screen and (max-width: 600px) {
    form {
         margin-top: 60px;
         height: 700px;
    }
}

input {
  width: 30%;
  display: block;
  border: 1px solid #999;
  height: 15px;
  -webkit-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  -moz-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  text-align: center; 
}

select#upload {
  width: 140px;
  height: 30px;
  display: block;
}

.button {
  width: 200px;
  bottom: 10px;
  top: 180px;
  background: #09C;
  float: center;
  color: #fff;
  font-family: Tahoma, Geneva, sans-serif;
  height: 40px;
  border-radius: 15px;
  border: 1p solid #999;
}

input.button:hover {
  background: #fff;
  color: #09C;
}

select:focus, input:focus {
  border: 1px solid #09C;
}
ul.ace-responsive-menu> li > ul > li {
    background: #fff;   
}
</style> 
 <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
</head>
<body>
<?php
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
elseif($_SESSION['role'] == 'principal'){
include("headerprinci.php");
}
else{ header("location: logout.php");}
?>
<?php
$id = $_GET['id'];
$query1 = mysqli_query($db, "select * from formt where id=$id");
while ($row1 = mysqli_fetch_array($query1)) {
echo '<center>';
echo '<br><br><form action="updatetutorbyadmin_exec.php" method="post" enctype="multipart/form-data">';
echo '<div>';
echo '<h5>Edit Form Tutor\'s Info :</h5>';
echo '<label>';
echo  '<input id="id" type="hidden" name="id" value="'.$row1['id'].'" />';
echo  '</label>';
echo '<label>';
echo  '<input id="teacher_id" type="hidden" name="teacher_id" value="'.$row1['teacher_id'].'" />';
echo  '</label>';
 echo '<label>';
echo  '<input id="teacher_name" readonly="readonly" type="text" name="teacher_name" value="'.$row1['teacher_name'].'" />';
echo '</label>';
  echo '<label>';
  if($ctype=="Js"){
if($row1['class_name'] == "Year 7"){ $caa2 = "JS1";}
else if($row1['class_name'] == "Year 8"){ $caa2 = "JS2";}
else if($row1['class_name'] == "Year 9"){ $caa2 = "JS3";}
else if($row1['class_name'] == "Year 10"){ $caa2 = "SS1";}
else if($row1['class_name'] == "Year 11"){ $caa2 = "SS2";}
else if($row1['class_name'] == "Year 12"){ $caa2 = "SS3";}
else{}
}elseif($ctype=="Primary"){
if($row1['class_name'] == "Year 1"){ $caa2 = "Primary 1";}
else if($row1['class_name'] == "Year 2"){ $caa2 = "Primary 2";}
else if($row1['class_name'] == "Year 3"){ $caa2 = "Primary 3";}
else if($row1['class_name'] == "Year 4"){ $caa2 = "Primary 4";}
else if($row1['class_name'] == "Year 5"){ $caa2 = "Primary 5";}
else if($row1['class_name'] == "Year 6"){ $caa2 = "Primary 6";}
else{}
}else{
if($row1['class_name'] == "Year 7"){ $caa2 = "Year 7";}	
else if($row1['class_name'] == "Year 8"){ $caa2 = "Year 8";}
else if($row1['class_name'] == "Year 9"){ $caa2 = "Year 9";}
else if($row1['class_name'] == "Year 10"){ $caa2 = "Year 10";}
else if($row1['class_name'] == "Year 11"){ $caa2 = "Year 11";}
else if($row1['class_name'] == "Year 12"){ $caa2 = "Year 12";}
else{}
}
echo  '<input id="class_name2" type="text" name="class_name2" value="'.$caa2.'" />';  
echo  '<input style="display: none;" id="class_name" type="text" name="class_name" value="'.$row1['class_name'].'" />';
echo '</label>';
 echo '<label>';
echo  '<input id="arms" type="text" name="arms" value="'.$row1['arms'].'" />';
echo '</label>';
 echo '<label>';
echo  '<input id="year" type="text" name="year" value="'.$row1['year'].'" />';
echo '</label>';
 echo '<label>';
echo  '<input id="term" type="text" name="term" value="'.$row1['term'].'" />';
echo '</label><br>';
echo '<label>';
 echo   '<input type="submit" class="button" name="btn-upload" id="thesubbutton" value="Submit Form" />';
  echo  '</label>';
echo '</div>';
echo '</form><br>';
}
echo '</center>';
include("footer.php");
?>

</body>
</html>