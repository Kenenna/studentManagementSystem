<?php
 session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Result</title>
<link rel="stylesheet" href="css/style.css" />
		
        <link rel="stylesheet" type="text/css" href="table/css/DT_bootstrap.css">

	<script src="table/js/jquery.js" type="text/javascript"></script>
<script src="table/js/bootstrap.js" type="text/javascript"></script>
	
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/jquery.dataTables.js"></script>
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/DT_bootstrap.js"></script>

<style>
select{
	height: auto;
}
</style>

<script>
$(document).ready(function() {	
$("#byarm").on("change", function(){
	if(this.checked){
        this.checked=true;
		$("#byarm2").val("yes");
		$("#byarm").val("yes");
		$("#subbyarm3").show();
		$("#subbyclass3").hide();
		$("#armsbyarms").show();
	}else{
		$("#byarm2").val("no");
		$("#byarm2").val("no");
		$("#subbyclass3").show();
		$("#subbyarm3").hide();
		$("#armsbyarms")[0].selectedIndex = 0;
		$("#armsbyarms").hide();
	}           
});
$("#halftermsub").hide();
$("#halfterm").on("change", function(){
	if(this.checked){
        this.checked=true;
		$("#fulltermdiv").hide(1000);
		$("#halftermsub").show(1000);
	}else{
		$("#fulltermdiv").show(1000);
		$("#halftermsub").hide(1000);
	}           
});
var sstr = $("#class_name option").eq(2).text();
var res = sstr.substring(1,2);
if(res=="S"){
	
}else{
$("#class_name option").eq(6).after("<option>Hy</option>");	
}
$("#halftermsub").on("click",function(){
var bb = $("#class_name").find(":selected").text();
var b = null;
if(bb=="Primary 1"){
	b = "Year 1";
}
else if(bb=="Primary 2"){
	b = "Year 2";
}
else if(bb=="Primary 3"){
	b = "Year 3";
}
else if(bb=="Primary 4"){
	b = "Year 4";
}
else if(bb=="Primary 5"){
	b = "Year 5";
}
else if(bb=="Primary 6"){
	b = "Year 6";
}
else if(bb=="JS1"){
	b = "Year 7";
}
else if(bb=="JS2"){
	b = "Year 8";
}
else if(bb=="JS3"){
	b = "Year 9";
}
else if(bb=="SS1"){
	b = "Year 10";
}
else if(bb=="SS2"){
	b = "Year 11";
}
else if(bb=="SS3"){
	b = "Year 12";
}
else{
	b = bb;
}
$("#class_name").find(":selected").val(b);
var c = $("#class_name").find(":selected").val();
$("#byarmform").prop("action","getresultmid.php");
});
$("[data-j=cn] option").eq(7).css("display","none");
var sstr = $("[data-j=cn] option").eq(2).text();
var res = sstr.substring(1,2);
if(res=="S"){
	
}else{
$("[data-j=cn] option").eq(6).after("<option>Year 8</option>");	
}


$("#subbyarmm3").on("click",function(){
var bb = $("[data-j=cn]").find(":selected").text();
var b = null;
if(bb=="Primary 1"){
	b = "Year 1";
}
else if(bb=="Primary 2"){
	b = "Year 2";
}
else if(bb=="Primary 3"){
	b = "Year 3";
}
else if(bb=="Primary 4"){
	b = "Year 4";
}
else if(bb=="Primary 5"){
	b = "Year 5";
}
else if(bb=="Primary 6"){
	b = "Year 6";
}
else if(bb=="JS1"){
	b = "Year 7";
}
else if(bb=="JS2"){
	b = "Year 8";
}
else if(bb=="JS3"){
	b = "Year 9";
}
else if(bb=="SS1"){
	b = "Year 10";
}
else if(bb=="SS2"){
	b = "Year 11";
}
else if(bb=="SS3"){
	b = "Year 12";
}
else{
	b = bb;
}
$("[data-j=cn]").find(":selected").val(b);
var c = $("[data-j=cn]").find(":selected").val();
});

$("#subbyclasss3").on("click",function(){
var bb = $("[data-j=cn]").find(":selected").text();
var b = null;
if(bb=="Primary 1"){
	b = "Year 1";
}
else if(bb=="Primary 2"){
	b = "Year 2";
}
else if(bb=="Primary 3"){
	b = "Year 3";
}
else if(bb=="Primary 4"){
	b = "Year 4";
}
else if(bb=="Primary 5"){
	b = "Year 5";
}
else if(bb=="Primary 6"){
	b = "Year 6";
}
else if(bb=="JS1"){
	b = "Year 7";
}
else if(bb=="JS2"){
	b = "Year 8";
}
else if(bb=="JS3"){
	b = "Year 9";
}
else if(bb=="SS1"){
	b = "Year 10";
}
else if(bb=="SS2"){
	b = "Year 11";
}
else if(bb=="SS3"){
	b = "Year 12";
}
else{
	b = bb;
}
$("[data-j=cn]").find(":selected").val(b);
var c = $("[data-j=cn]").find(":selected").val();
});
 
 
$("#class_name option").eq(7).css("display","none");
$("#subbyarm3").on("click",function(){
var bb = $("#class_name").find(":selected").text();
var b = null;
if(bb=="Primary 1"){
	b = "Year 1";
}
else if(bb=="Primary 2"){
	b = "Year 2";
}
else if(bb=="Primary 3"){
	b = "Year 3";
}
else if(bb=="Primary 4"){
	b = "Year 4";
}
else if(bb=="Primary 5"){
	b = "Year 5";
}
else if(bb=="Primary 6"){
	b = "Year 6";
}
else if(bb=="JS1"){
	b = "Year 7";
}
else if(bb=="JS2"){
	b = "Year 8";
}
else if(bb=="JS3"){
	b = "Year 9";
}
else if(bb=="SS1"){
	b = "Year 10";
}
else if(bb=="SS2"){
	b = "Year 11";
}
else if(bb=="SS3"){
	b = "Year 12";
}
else{
	b = bb;
}
$("#class_name").find(":selected").val(b);
var c = $("#class_name").find(":selected").val();
});


$("#subbyclass3").on("click",function(){
var bb = $("#class_name").find(":selected").text();
var b = null;
if(bb=="Primary 1"){
	b = "Year 1";
}
else if(bb=="Primary 2"){
	b = "Year 2";
}
else if(bb=="Primary 3"){
	b = "Year 3";
}
else if(bb=="Primary 4"){
	b = "Year 4";
}
else if(bb=="Primary 5"){
	b = "Year 5";
}
else if(bb=="Primary 6"){
	b = "Year 6";
}
else if(bb=="JS1"){
	b = "Year 7";
}
else if(bb=="JS2"){
	b = "Year 8";
}
else if(bb=="JS3"){
	b = "Year 9";
}
else if(bb=="SS1"){
	b = "Year 10";
}
else if(bb=="SS2"){
	b = "Year 11";
}
else if(bb=="SS3"){
	b = "Year 12";
}
else{
	b = bb;
}
$("#class_name").find(":selected").val(b);
var c = $("#class_name").find(":selected").val();
});
 
 $("#subbyarm3").on("click",function(){
var bb = $("#class_name").find(":selected").text();
var b = null;
if(bb=="Primary 1"){
	b = "Year 1";
}
else if(bb=="Primary 2"){
	b = "Year 2";
}
else if(bb=="Primary 3"){
	b = "Year 3";
}
else if(bb=="Primary 4"){
	b = "Year 4";
}
else if(bb=="Primary 5"){
	b = "Year 5";
}
else if(bb=="Primary 6"){
	b = "Year 6";
}
else if(bb=="JS1"){
	b = "Year 7";
}
else if(bb=="JS2"){
	b = "Year 8";
}
else if(bb=="JS3"){
	b = "Year 9";
}
else if(bb=="SS1"){
	b = "Year 10";
}
else if(bb=="SS2"){
	b = "Year 11";
}
else if(bb=="SS3"){
	b = "Year 12";
}
else{
	b = bb;
}
$("#class_name").find(":selected").val(b);
var c = $("#class_name").find(":selected").val();
 });
 
 $("[data-j=cnn] option").eq(7).css("display","none");
 var sstr = $("[data-j=cnn] option").eq(2).text();
var res = sstr.substring(1,2);
if(res=="S"){
	
}else{
$("[data-j=cnn] option").eq(6).after("<option>Year 8</option>");	
}
 
 
 
$("#submit4").on("click",function(){
var bb = $("[data-j=cnn]").find(":selected").text();
var b = null;
if(bb=="Primary 1"){
	b = "Year 1";
}
else if(bb=="Primary 2"){
	b = "Year 2";
}
else if(bb=="Primary 3"){
	b = "Year 3";
}
else if(bb=="Primary 4"){
	b = "Year 4";
}
else if(bb=="Primary 5"){
	b = "Year 5";
}
else if(bb=="Primary 6"){
	b = "Year 6";
}
else if(bb=="JS1"){
	b = "Year 7";
}
else if(bb=="JS2"){
	b = "Year 8";
}
else if(bb=="JS3"){
	b = "Year 9";
}
else if(bb=="SS1"){
	b = "Year 10";
}
else if(bb=="SS2"){
	b = "Year 11";
}
else if(bb=="SS3"){
	b = "Year 12";
}
else{
	b = bb;
}
$("[data-j=cnn]").find(":selected").val(b);
var c = $("[data-j=cnn]").find(":selected").val();
if(c=="Year 1" || c=="Year 2" || c=="Year 3" || c=="Year 4" || c=="Year 5" || c=="Year 6"){
	$("#transcriptform").prop("action","transtea2.php");
}
});
});
</script>
<script>
$(document).ready(function() {	
$("#byarmm").on("change", function(){
	if(this.checked){
        this.checked=true;
		$("#byarmm2").val("yes");
		$("#subbyarmm3").show(1000);
		$("#subbyclasss3").hide(1000);
		$("#armsbyarmss").show(1000);
	}else{
		$("#byarmm2").val("no");
		$("#subbyclasss3").show(1000);
		$("#subbyarmm3").hide(1000);
		$("#armsbyarmss")[0].selectedIndex = 0;
		$("#armsbyarmss").hide(1000);
	}           
});
});
</script>
	<link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>
 
 <style>
.containers:after { /*clear float*/
    content: "";
    display: table;
    clear: both;
}
.containers > div {
    float: left;
    width: 33.33%;
    box-sizing: border-box;
    text-align: center;
}
@media (max-width: 480px) { /*breakpoint*/
    .containers > div {
        float: none;
        width: 100%;
    }
}
 </style>
  <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
 
</head>
<body>
<?php
if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'admin'){
include("headeradmin.php");
}
elseif($_SESSION['role'] == 'student'){
include("headerstudent.php");
}
elseif($_SESSION['role'] == 'principal'){ 
include("headerprinci.php"); 
}
else{ header("location: logout.php"); }
?>
<br><br><br>
<?php
echo '<div class="containers">';
echo '<div id="div1">';
echo '<div class="form">';
echo '<br><br>';
echo '<h5>GET STUDENT\'S SCORES</h5>';
echo '<form name="registration" action="getresult.php" id="byarmform" method="post">';
//include "connection.php";
	$resultst = mysqli_query($db, "SELECT DISTINCT(student_name) FROM scores where school='".$_SESSION["school"]."' ORDER BY student_name ASC");
echo '<select style="width: 210px; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="student_name" id="student_name" required >';
	while($rowst = mysqli_fetch_assoc($resultst))
							{  
								echo '<option value="'.$rowst['student_name'].'">';
								echo $rowst['student_name'];
								echo '</option>';
							}
    echo '</select>';
//	include "connection.php";
echo '<br><span style="color: red;">For Secondary School, Class Begins in Year 7.</span>';
	echo '<select style="width: 210px; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="class_name" id="class_name" required >';
	include "connection.php";
	$cccc = 0;
	$cccc2 = 0;
	$cccc3 = 0;
	$result = mysqli_query($db, "SELECT * FROM classes");
						while($row = mysqli_fetch_assoc($result))
							{ 
								echo '<option>';
								if($ctype=="Js"){
								if($cccc == 0){	
									$cccc++;
									echo 'SELECT A CLASS';
									continue;
									}		
								if($cccc <= 3){
								echo 'JS'.$cccc;	
								}
								elseif($cccc >= 4 && $cccc <= 6){
									if($cccc == 4){	
									$cccc++;
									echo 'SS'.($cccc2 - 2);	
									continue;
									}
									if($cccc == 5){	
									$cccc++;
									echo 'SS'.($cccc2 - 1);	
									continue;
									}
									if($cccc == 6){	
									$cccc++;
									echo 'SS'.($cccc2 - 0);	
									continue;
									}
								}else{
									break;
								}
								$cccc++;	
								$cccc2++;
									}
								else{	
								if($ctype=="Primary"){
									if($cccc == 0){	
									$cccc++;
									echo 'SELECT A CLASS';
									continue;
									}
								echo 'Primary '.$cccc;
								if($cccc > 5){
									break;
								}
								$cccc++;	
								}
								else{
								echo 'Year '.($cccc+1);
								if($cccc > 11){
									break;
								}
								$cccc++;	
								}
								}//end of else
								echo '</option>';
							}
    echo '</select>';
	
	echo '<select style="width: 210px; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="year" id="year" required >';
//	include "connection.php";
echo '<option value="none" disabled="disabled" selected>SESSION COMMENCING</option>';
	$result = mysqli_query($db, "SELECT * FROM years");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['year'].'">';
								echo $row['year'];
								echo '</option>';
							}
    echo '</select>';
	echo '<select style="width: 210px; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="term" id="term" required >';
//	include "connection.php";
	$resulttm = mysqli_query($db, "SELECT * FROM terms");
						while($row = mysqli_fetch_assoc($resulttm))
							{  
								echo '<option value="'.$row['term'].'">';
								echo $row['term'];
								echo '</option>';
							}
  echo '</select>';
echo '<br><input type="checkbox" name="halfterm" id="halfterm" value="yes"><span style="color: red;" >&nbsp;&nbsp;Fetch Half Term Result</span><br>';
	echo '<input type="checkbox" name="byarm" id="byarm"><span style="color: red;" >&nbsp;&nbsp;Fetch Result By Class Arm</span><br>';
echo '<select style="display: none; width: 210px; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="arms" id="armsbyarms" >';
	 $result = mysqli_query($db,"SELECT * FROM school where school='".$_SESSION["school"]."'");
				while($row = mysqli_fetch_assoc($result)){
					$arrr2[] = $row["arms"];
				}
				$a = implode(',',$arrr2);
				$b = explode(',',$a);
				$f = (array_filter($b));
				echo '<option disabled="disabled" selected="selected" value="">Pick An Arm</option>';
						for($i=0; $i<=(count($f)-1); $i++)
							{  
								echo '<option value="'.$f[$i].'">';
								echo $f[$i];
								echo '</option>';
							}
    echo '</select>';
	echo '<div id="fulltermdiv">';
echo '<input type="text" style="display:none;" name="byarm2" id="byarm2" />';
	echo '<select style="width: 210px; height: auto; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="sig" id="sig" required >';
								echo '<option value="3" selected="selected">DIGITAL SIGNATURE?</option>';
								echo '<option value="0">NO</option>';
								echo '<option value="1">YES</option>';
    echo '</select>';
echo '<input type="submit" name="submit3" id="subbyclass3" value="Get Result by Year Group" />';
echo '<input style="display: none;" id="subbyarm3" type="submit" name="subbyarm3" style="" value="Get Result by Arm" />';
echo '</div>';
echo '<input type="submit" name="halftermsub" id="halftermsub" value="Get Half Term Result" />';
echo '</form>';
echo '<br>';
echo '</div>';
echo '</div>'; //end of div1

echo '<div id="div2">';
echo '<div class="form">';
echo '<br><br>';
echo '<h5>GET PERFORMANCE RANKING</h5>';
echo '<form name="registration" id="armsbyarms2form" action="getresultmaxes.php" method="post">';
echo '<span style="color: red;">For Secondary School, Class Begins in Year 7.</span>';
	echo '<select data-j="cn" style="width: 210px; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="class_name" id="class_name" required >';
	//include "connection.php";
$cccc = 0;
$cccc2 = 0;
	$resultb = mysqli_query($db, "SELECT * FROM classes");
						while($rowb = mysqli_fetch_assoc($resultb))
							{ 
							echo '<option>';
								if($ctype=="Js"){
								if($cccc == 0){	
									$cccc++;
									echo 'SELECT A CLASS';
									continue;
									}		
								if($cccc <= 3){
								echo 'JS'.$cccc;	
								}
								elseif($cccc >= 4 && $cccc <= 6){
									if($cccc == 4){	
									$cccc++;
									echo 'SS'.($cccc2 - 2);	
									continue;
									}
									if($cccc == 5){	
									$cccc++;
									echo 'SS'.($cccc2 - 1);	
									continue;
									}
									if($cccc == 6){	
									$cccc++;
									echo 'SS'.($cccc2 - 0);	
									continue;
									}
								}else{
									break;
								}
								$cccc++;	
								$cccc2++;
									}
								else{	
								if($ctype=="Primary"){
									if($cccc == 0){	
									$cccc++;
									echo 'SELECT A CLASS';
									continue;
									}
								echo 'Primary '.$cccc;
								if($cccc > 5){
									break;
								}
								$cccc++;	
								}
								else{
								echo 'Year '.($cccc+1);
								if($cccc > 11){
									break;
								}
								$cccc++;	
								}
								}//end of else
								echo '</option>';
							}
    echo '</select>';
	
	echo '<select style="width: 210px; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="year" id="year" required >';
	$result = mysqli_query($db, "SELECT * FROM years");
	echo '<option value="none" disabled="disabled" selected>SESSION COMMENCING</option>';
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['year'].'">';
								echo $row['year'];
								echo '</option>';
							}
    echo '</select>';
	echo '<select style="width: 210px; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="term" id="term" required >';
								echo '<option value="Third Term">';
								echo 'Third Term';
								echo '</option>';
    echo '</select>';
	echo '<select style="width: 210px; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="subject" id="subject" required >';
	$result = mysqli_query($db, "SELECT * FROM subjects ORDER BY subject ASC");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['subject'].'">';
								echo $row['subject'];
								echo '</option>';
							}
    echo '</select>';
	echo '<br><label>Will be downloading with comments</label>';
	echo '<br><input type="radio" name="withit" value="yes" checked> Yes<br>';
	echo '<input type="radio" name="withit" value="no"> No<br>';
echo '<input type="checkbox" name="byarm" id="byarmm" value="yes"><span style="color: red;" >&nbsp;&nbsp;Fetch Ranking By Class Arm</span><br>';
echo '<input type="text" style="display:none;" name="byarm2" id="byarmm2" />';
echo '<select style="display: none; width: 210px; height: auto; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="arms" id="armsbyarmss" >';
	 $result = mysqli_query($db,"SELECT * FROM school where school='".$_SESSION["school"]."'");
				while($row = mysqli_fetch_assoc($result)){
					$arrrr2[] = $row["arms"];
				}
				$aa = implode(',',$arrrr2);
				$bb = explode(',',$aa);
				$ff = (array_filter($bb));
				echo '<option disabled="disabled" selected="selected" value="">Pick An Arm</option>';
						for($i=0; $i<=(count($ff)-1); $i++)
							{  
								echo '<option value="'.$ff[$i].'">';
								echo $ff[$i];
								echo '</option>';
							}
    echo '</select>'; 
    echo '<input style="display: none;" type="text" name="admgetresult" id="admgetresult" value="admgetresult" />';
echo '<input type="submit" name="submit3" id="subbyclasss3" value="Get Ranking by Year Group" />';
echo '<input style="display: none;" id="subbyarmm3" type="submit" name="subbyarmm3" style="" value="Get Ranking by Arm" />';
echo '</form>';
echo '</div>';
echo '</div>'; //end of div2

echo '<div id="div3">';
echo '<br><div class="form">';
echo '<br>';
echo '<h5>GET STUDENT\'S TRANSCRIPT</h5>';
echo '<form name="registration" id="transcriptform" action="transtea.php" method="post">';
//include "connection.php";
	$resultst = mysqli_query($db, "SELECT DISTINCT(student_name) FROM scores where school='".$_SESSION["school"]."' ORDER BY student_name ASC");
echo '<select style="width: 210px; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="student_name" id="student_name" required >';
	while($rowst = mysqli_fetch_assoc($resultst))
							{  
								echo '<option value="'.$rowst['student_name'].'">';
								echo $rowst['student_name'];
								echo '</option>';
							}
    echo '</select>';
	echo '<br><span style="color: red;">For Secondary School, Class Begins in Year 7.</span>';
	echo '<select data-j="cnn" style="width: 210px; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="class_name" id="class_name" required >';
//	include "connection.php";
$cccc = 0;
$cccc2 = 0;
	$result = mysqli_query($db, "SELECT * FROM classes");					
						while($row = mysqli_fetch_assoc($result))
							{  
							echo '<option>';
								if($ctype=="Js"){
								if($cccc == 0){	
									$cccc++;
									echo 'SELECT A CLASS';
									continue;
									}		
								if($cccc <= 3){
								echo 'JS'.$cccc;	
								}
								elseif($cccc >= 4 && $cccc <= 6){
									if($cccc == 4){	
									$cccc++;
									echo 'SS'.($cccc2 - 2);	
									continue;
									}
									if($cccc == 5){	
									$cccc++;
									echo 'SS'.($cccc2 - 1);	
									continue;
									}
									if($cccc == 6){	
									$cccc++;
									echo 'SS'.($cccc2 - 0);	
									continue;
									}
								}else{
									break;
								}
								$cccc++;	
								$cccc2++;
									}
								else{	
								if($ctype=="Primary"){
									if($cccc == 0){	
									$cccc++;
									echo 'SELECT A CLASS';
									continue;
									}
								echo 'Primary '.$cccc;
								if($cccc > 5){
									break;
								}
								$cccc++;	
								}
								else{
								echo 'Year '.($cccc+1);
								if($cccc > 11){
									break;
								}
								$cccc++;	
								}
								}//end of else
								echo '</option>';
							}
    echo '</select>';
	echo '<select style="width: 210px; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;" name="year" id="year" required >';
	//include "connection.php";
	echo '<option value="none" disabled="disabled" selected>SESSION COMMENCING</option>';
	$result = mysqli_query($db, "SELECT * FROM years");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['year'].'">';
								echo $row['year'];
								echo '</option>';
							}
    echo '</select>';
echo '<input style="display: none;" type="text" name="admgetresult" id="admgetresult" value="admgetresult" />';    
echo '<input type="submit" name="submit4" id="submit4" value="Get Transcript" />';
echo '</form>';
echo '<br>';
echo '</div>';
echo '</div>'; //end of div3
echo '</div>'; //end of container
?>
<?php
include("footer.php");
?>
</body>