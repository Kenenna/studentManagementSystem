<?php
$pdfatt = $_POST['pdfatt'];
echo $pdfatt;
?>