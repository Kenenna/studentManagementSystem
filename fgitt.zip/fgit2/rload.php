<?php
$result = mysqli_query($db, "SELECT * FROM studentsbyclass where class='$class' AND year='$year' AND term='$term' AND formt='$tna' AND arms='$arms'");
$result2 = mysqli_query($db, "SELECT * FROM attend where class='$class' AND year='$year' AND term='$term' AND formt='$tna' AND datename='$datename' AND arms='$arms'");
$resultdistinctstudent = mysqli_query($db, "SELECT DISTINCT(student_name) FROM studentsbyclass where class='$class' AND year='$year' AND term='$term' AND formt='$tna' AND arms='$arms'");
$resultdistinctstudentattend = mysqli_query($db, "SELECT DISTINCT(student_name) FROM attend where class='$class' AND year='$year' AND term='$term' AND formt='$tna' AND arms='$arms' AND datename='$datename'");
while($rowds = mysqli_fetch_assoc($resultdistinctstudent))
{ 
 $valuesds2[] = $rowds['student_name'];	
}
$valuesds3 = array_merge($valuesds2, $valuesds2);

while($rowdsa = mysqli_fetch_assoc($resultdistinctstudentattend))
{ 
 $valuesdsa2[] = $rowdsa['student_name'];	
}
$valuesdsa3 = array_merge($valuesdsa2, $valuesdsa2);

$sd = array_diff($valuesds3,$valuesdsa3);
//print_r($sd);
$sd2 = count($sd);

$countresult2 = mysqli_num_rows($result2);
while($row2 = mysqli_fetch_assoc($result2))
{  						
$values2[] = $row2['student_name'];
$values2attend[] = $row2['attend']; //for the attendance table
}
$values2 = array_merge($values2, $values2);
$values22 =($values2);
$valattend = ($values2attend);
$vtu = count($values22);

while($row = mysqli_fetch_assoc($result))
{  						
$values[] = $row['student_name']; 
$valuesclass[] = $row['class']; 
$valuesyear[] = $row['year']; 
$valuesterm[] = $row['term'];
$valuesarms[] = $row['arms']; 
}
$values = array_merge($values, $values);
$vallue = $values;

$vtuu = count($values);

current($valuesclass);
current($valuesyear);
current($valuesterm);
current($valuesarms);

$r = array_diff($vallue, $values22); 
echo '<br>';
//print_r($values2)."<br>";
//print_r($vallue);
//print_r($values22);
//print_r($r);
//echo $r;
$vtuuu = $vtuu - $vtu;
//echo $vtuuu;

include "connection.php";
$result3 = mysqli_query($db, "SELECT * FROM maxattname WHERE year='$year' AND term='$term'");
while ($row3 = mysqli_fetch_assoc($result3)) {
$termbegin1[] = $row3['termbegin'];	
}
$termbegin = current($termbegin1);


if($vtuuu < 1){
	if($countresult2 <= 0){
		echo "<span style='color:red; font-size:16px; text-decoration: underline;'>You have not inputed the attendance for students enrolled in your class under the selected criteria for: ".strtoupper(date("l, jS \of F Y", strtotime($datename)))."</span><br>";
	}else{
	   if($sd2 > 0){
//echo '<div id="showsome">';		   
echo '<span style="color: green; font-size: 16px;">Take attendance of Students in '.current($valuesclass).' for '.current($valuesterm).', '.current($valuesyear).'</span><br />';	
echo '<br>';
echo '<span style="color: green; font-size: 16px;">Attendance is for '.strtoupper(date("D jS \of F Y", strtotime($_POST["datename"]))).'</span><br />';	
echo '<br>';
echo '<input type="text" class="txtFirstName1" id="txtFirstName1">';
echo '<button id="dosomething1" style="background-color: green; color: white;">Set All TO PRESENT</button>';
echo '<input type="text" class="txtFirstName2" id="txtFirstName2">';
echo '<button id="dosomething2" style="background-color: green; color: white;">Set All TO ABSENT</button>';
echo '<input type="text" class="txtFirstName3" id="txtFirstName3"><br>';
echo '<button id="dosomething3" style="background-color: green; color: white;">Set All TO MIDTERM</button>';
echo '<br>';
echo '<br>';
//echo '<form action="attend_exec.php" method="post">';
echo '<form id="formid" class="formidd">';
echo '<table id="fhalf"><thead><tr><th colspan="6"></th><tr></thead>';
echo '<tr><td style="text-align:center; font-weight: bold;">Student Name</td><td style="text-align:center; font-weight: bold;">Present</td><td style="display: none;">Class</td><td style="display: none;">Arm</td><td style="display: none;">Year</td><td style="display: none;">Term</td><td style="display: none;">Date</td><td style="font-weight: bold;">Day Period</td></tr>';		
$counter = 0;
foreach ($sd as $key => $sd['student_name']) {
echo '<tr class="checkSingles">';
echo '<td style="text-align:center;"><input type="hidden" name="student_name[]" value="'.$sd['student_name'].'" /><span>'.$sd['student_name'].'</span></td>';
echo '<td style="text-align:center;"><input style="width: 50%;" id="in_'.$counter.'" class="checkSingle" readonly="readonly" type="text" name="attend[]" /></td>';
echo '<td style="display: none;"><input type="text"  name="class[]" id="class_name" value="'.current($valuesclass).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="arms[]" id="arms" value="'.current($valuesarms).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="year[]" id="year" value="'.current($valuesyear).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="term[]" id="term" value="'.current($valuesterm).'" /></td>';
echo '<td style="display: none;"><input type="text" name="datename[]" id="datename" value="'.$datename.'"/></td>';
echo '<td style="display: none;"><input type="text" name="formt[]" id="formt" value="'.$tna.'"/></td>';
echo '<td><input readonly="readonly" style="width: 50%;" class="checkSingleaft" type="text" name="dtime[]" id="dtime" /></td>';
echo '</tr>';
$counter++;	
}
echo '<tr style="border: 0;">';
echo '<td colspan="1" style="border: 0;" class="getprogress"><input style="float: left;" type="submit" class="submit_button" name="submit" value="Submit Attendance" /></td><td colspan="3" style="border: 0;"><span class="error" style="display:none; color: red;"><img src="table/del.jpg" width="60" height="60"/>ERROR! You may be attempting to take the class attendance twice for the same day.</span><span class="success" style="display:none; color: green;"><img src="table/492.png" width="60" height="60"/> Attendance taken successfully.</span></td>';
echo '<td colspan="1" style="border: 0; display: none;" class="getfulllist"><a href="#" id="getfulllistbutton">Get Full Class</a></td>';
echo '</tr>';
echo '</table>';
echo '</form>';		
echo '</center><br>';	   	   
	   } 
	   else{
	$resultforupdate = mysqli_query($db, "SELECT * FROM attend WHERE class='$class' AND year='$year' AND arms='$arms' AND term='$term' AND datename='$datename' ORDER BY student_name ASC");
	echo "<span style='color:red; font-size:16px; text-decoration: underline;'>You may have already inputed the attendance for the students enrolled in your class under the selected criteria for: ".strtoupper(date("l, jS \of F Y", strtotime($datename)))."</span><br>";
	echo "<span style='color:red; font-size:16px; text-decoration: underline;'>You can update student's attendance status!</span><br>";
	echo '<center>';
	echo '<br>';
	echo '<span style="color: green; font-size: 16px;">Attendance is for '.strtoupper(date("D jS \of F Y", strtotime($_POST["datename"]))).'</span><br />';	
	echo '<br>';
echo '<input type="text" class="txtFirstName1" id="txtFirstName1">';
echo '<button id="dosomething1" style="background-color: green; color: white;">Set All TO PRESENT</button>';
echo '<input type="text" class="txtFirstName2" id="txtFirstName2">';
echo '<button id="dosomething2" style="background-color: green; color: white;">Set All TO ABSENT</button>';
echo '<input type="text" class="txtFirstName3" id="txtFirstName3"><br>';
echo '<button id="dosomething3" style="background-color: green; color: white;">Set All TO MIDTERM</button>';
echo '<br>';
echo '<form id="formidupdate">';
echo '<table><thead><tr><th colspan="6"></th><tr></thead>';
echo '<tr><td style="text-align:center; font-weight: bold; display: none;">ID</td><td style="text-align:center; font-weight: bold;">Student Name</td><td style="text-align:center; font-weight: bold;">Status</td><td style="text-align:center; font-weight: bold;">Day Period</td></tr>';		
$counter = 0;
while ($resultforupdateit = mysqli_fetch_assoc($resultforupdate)) {
echo '<tr class="checkSingles">';
echo '<td style="display: none;"><input type="text" style="width:80%; display: none;" name="id[]" id="id" value="'.$resultforupdateit["id"].'" readonly="readonly" /></td>';	
echo '<td style="text-align:center;"><input style="text-align:center;" type="text" name="student_name[]" value="'.$resultforupdateit["student_name"].'" id="sn_'.$counter.'" readonly/></td>';
echo '<td style="text-align:center;"><input style="width: 80%; text-align:center;" type="text" name="attend[]" class="checkSingle" readonly="readonly" value="'.$resultforupdateit["attend"].'" id="in_'.$counter.'" /></td>';
echo '<td><input readonly="readonly" style="width: 80%; text-align:center;" class="checkSingleaft" type="text" name="dtime[]" id="dt_'.$counter.'" /></td>';
echo '</tr>';
$counter++;
}
echo '<tr style="border: 0;">';
echo '<td colspan="2" style="border: 0;" class="getprogress"><input style="left: right;" type="submit" class="submit_button" name="submit" value="Submit Attendance" /></td><td colspan="2" style="border: 0;"><span class="error" style="display:none; color: red;"><img src="table/del.jpg" width="60" height="60"/>Updates could not be made.</span><span class="success" style="display:none; color: green;"><img src="table/492.png" width="60" height="60"/> Attendance updated successfully.</span></td>';
echo '</tr>';
echo '</table>';
echo '</form>';	
echo '</center>';
}
}
}
else if($vtu == 0){
	$values22[] = "nothingham";
	$r = array_diff($vallue, $values22);
echo '<span style="color: green; font-size: 16px;">Take attendance of Students in '.current($valuesclass).''.current($valuesarms).' for '.current($valuesterm).', '.current($valuesyear).'</span><br />';		
echo '<br>';
echo '<center>';
echo '<input type="text" class="txtFirstName1" id="txtFirstName1">';
echo '<button id="dosomething1" style="background-color: green; color: white;">Set All TO PRESENT</button>';
echo '<input type="text" class="txtFirstName2" id="txtFirstName2">';
echo '<button id="dosomething2" style="background-color: green; color: white;">Set All TO ABSENT</button>';
echo '<input type="text" class="txtFirstName3" id="txtFirstName3"><br>';
echo '<button id="dosomething3" style="background-color: green; color: white;">Set All TO MIDTERM</button>';
echo '</center><br>';
echo '<br>';
echo '<form id="formid" class="formid">';
echo '<table id="fhalf"><thead><tr><th colspan="6"></th><tr></thead>';
echo '<tr><td style="text-align:center; font-weight: bold;">Student Name</td><td style="text-align:center; font-weight: bold;">Present</td><td style="display: none;">Class</td><td style="display: none;">Arm</td><td style="display: none;">Year</td><td style="display: none;">Term</td><td style="display: none;">Date</td><td style="font-weight: bold;">Day Period</td></tr>';		
$counter = 0;
foreach ($r as $key => $r['student_name']) {
echo '<tr class="checkSingles">';	
echo '<td style="text-align:center;"><input type="hidden" name="student_name[]" value="'.$r['student_name'].'" />'.$r['student_name'].'</td>';
echo '<td style="text-align:center;"><input style="width: 50%;" id="in_'.$counter.'" class="checkSingle" readonly="readonly" type="text" name="attend[]" value="absent" /></td>';
echo '<td style="display: none;"><input type="text"  name="class[]" id="class_name" value="'.current($valuesclass).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="arms[]" id="arms" value="'.current($valuesarms).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="year[]" id="year" value="'.current($valuesyear).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="term[]" id="term" value="'.current($valuesterm).'" /></td>';
echo '<td style="display: none;"><input type="text" name="datename[]" id="datename" value="'.$datename.'"/></td>';
echo '<td style="display: none;"><input type="text" name="formt[]" id="formt" value="'.$tna.'"/></td>';
echo '<td><input readonly="readonly" style="width: 50%;" class="checkSingleaft" type="text" name="dtime[]" id="dtime" /></td>';
echo '</tr>';
$counter++;	
}
echo '<tr style="border: 0;">';
echo '<td colspan="2" style="border: 0;" class="getprogress"><input style="float: left;" type="submit" class="submit_button" name="submit" value="Submit Attendance" /></td><td colspan="3" style="border: 0;"><span class="error" style="display:none; color: red;"><img src="table/del.jpg" width="60" height="60"/>ERROR! You may be attempting to take the class attendance twice for the same day.</span><span class="success" style="display:none; color: green;"><img src="table/492.png" width="60" height="60"/> Attendance taken successfully.</span></td>';
echo '</tr>';
echo '</table>';
echo '</form>';		
}
else{
echo '<center>';
echo '<span style="color: green; font-size: 16px;">Take attendance of Students in '.current($valuesclass).''.current($valuesclass).' for '.current($valuesterm).', '.current($valuesyear).'</span><br />';	
echo '<br>';
echo 'Check All<br />';		
echo '<form>';
echo '<input type="checkbox" name="checkedAll" id="checkedAll"></input>';
echo '</form><br>';
echo '<form action="teacher-student_exec.php" method="post">';
echo '<table id="fhalf" ><thead><tr><th style="text-align:center;">Student Name</th><th style="text-align:center;">Present</th><th style="display: none;">Class</th><th style="display: none;">Arm</th><th style="display: none;">Year</th><th style="display: none;">Term</th><th style="display: none;">Date</th></tr></thead>';
foreach ($r as $key => $r['student_name']) {
echo '<tr class="checkSingles">';
echo '<td style="text-align:center;"><input type="hidden" name="student_name[]" value="'.$r['student_name'].'" />'.$r['student_name'].'</td>';
echo '<td class="checkSingles" style="text-align:center;"><input class="checkSingle" type="checkbox" name="attend[]" value="present" id="attend" /></td>';
echo '<td style="display: none;"><input type="text"  name="class[]" id="class_name" value="'.current($valuesclass).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="arms[]" id="class_name" value="'.current($valuesarms).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="year[]" id="year" value="'.current($valuesyear).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="term[]" id="term" value="'.current($valuesterm).'" /></td>';
echo '<td style="display: none;"><input type="text" name="datename[]" id="datename" value="'.$datename.'"/></td>';
echo '<td style="display: none;"><input type="text" name="formt[]" id="formt" value="'.$tna.'"/></td>';
echo '</tr>';
}
echo '<tr>';
echo '<td colspan="5"><input style="float: right;" type="submit" class="submit_button" name="submit" value="Submit Scores" /></td>';
echo '</tr>';
echo '</table>';
echo '</form>';	
echo '</center>';
}
}
?>
<br>