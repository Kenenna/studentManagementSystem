<?php
session_start();
include("auth.php");
include('database.php');
include('function.php');
include "connection.php";

$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);

$query = '';
$output = array();
$query .= "SELECT * FROM studentsbyclass WHERE school='".$_SESSION["school"]."' AND (";
if(isset($_POST["search"]["value"]))
{ 
 //$query .= '';
 $query .= 'student_name LIKE "%'.$_POST["search"]["value"].'%" ';
 $query .= 'OR class LIKE "%'.$_POST["search"]["value"].'%" ';
 $query .= 'OR year LIKE "%'.$_POST["search"]["value"].'%" ';
 $query .= 'OR term LIKE "%'.$_POST["search"]["value"].'%" ';
 $query .= 'OR formt LIKE "%'.$_POST["search"]["value"].'%" ';
 $query .= 'OR arms LIKE "%'.$_POST["search"]["value"].'%" ';
 $query .= 'OR house LIKE "%'.$_POST["search"]["value"].'%" ';
 $query .= ") ";
}
if(isset($_POST["order"]))
{
 $query .= 'ORDER BY '.$_POST['order']['0']['column'].' '.$_POST['order']['0']['dir'].' ';
}
else
{
 $query .= 'ORDER BY id DESC ';
}
if($_POST["length"] != -1)
{
 $query .= 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
}
$statement = $connection->prepare($query);
$statement->execute();
$result = $statement->fetchAll();
$data = array();
$filtered_rows = $statement->rowCount();
foreach($result as $row)
{
 $image = '';
 if($row["image"] != '')
 {
  $image = '<img src="upload/'.$row["image"].'" class="img-thumbnail" width="50" height="35" />';
 }
 else
 {
  $image = '';
 }
 
 $class = $row["class"];
if($class=="Year 1"){
	if($ctype=="Js"){
	$cl = "JS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 1";
}
else{
	$cl = "Year 7";
}
}
elseif($class=="Year 2"){
	if($ctype=="Js"){
	$cl = "JS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 2";
}
else{
	$cl = "Year 2";
}
}
elseif($class=="Year 3"){
	if($ctype=="Js"){
	$cl = "JS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 3";
}
else{
	$cl = "Year 3";
}
}
elseif($class=="Year 4"){
	if($ctype=="Js"){
	$cl = "JS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 4";
}
else{
	$cl = "Year 4";
}
}
elseif($class=="Year 5"){
	if($ctype=="Js"){
	$cl = "JS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 5";
}
else{
	$cl = "Year 5";
}
}
elseif($class=="Year 6"){
	if($ctype=="Js"){
	$cl = "JS1";
}elseif($ctype=="Primary"){
	$cl = "Primary 6";
}
else{
	$cl = "Year 6";
}
}
elseif($class=="Year 7"){
	if($ctype=="Js"){
	$cl = "JS1";
}else{
	$cl = "Year 7";
}
}else if($class=="Year 8"){
	if($ctype=="Js"){
	$cl = "JS2";
}else{
	$cl = "Year 8";
}
}else if($class=="Year 9"){
	if($ctype=="Js"){
	$cl = "JS3";
}else{
	$cl = "Year 9";
}
}else if($class=="Year 10"){
	if($ctype=="Js"){
	$cl = "SS1";
}else{
	$cl = "Year 10";
}
}else if($class=="Year 11"){
	if($ctype=="Js"){
	$cl = "SS2";
}else{
	$cl = "Year 11";
}
}else if($class=="Year 12"){
	if($ctype=="Js"){
	$cl = "SS3";
}else{
	$cl = "Year 12";
}
}else{
	$cl = "NOT APPLICABLE";
} 
 
 
 
 $sub_array = array();
 $sub_array[] = $image;
 $sub_array[] = $row["student_name"];
 $sub_array[] = $cl;
 $sub_array[] = $row["year"];
 $sub_array[] = $row["term"];
 $sub_array[] = $row["formt"];
 $sub_array[] = $row["arms"];
 $sub_array[] = $row["house"];
 $sub_array[] = '<button type="button" name="update" id="'.$row["id"].'" class="btn btn-warning btn-xs update">Update</button>';
 $sub_array[] = '<button type="button" name="delete" id="'.$row["id"].'" class="btn btn-danger btn-xs delete">Delete</button>';
 $data[] = $sub_array;
}
$output = array(
 "draw"    => intval($_POST["draw"]),
 "recordsTotal"  =>  $filtered_rows,
 "recordsFiltered" => get_total_all_records(),
 "data"    => $data
);
//if(isset($_POST['btn-upload'])){
echo json_encode($output);
//echo $yrr;
//}
//echo json_encode($_POST["yearfromform"]);
?>
