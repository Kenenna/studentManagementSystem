<?php
require_once("connection.php");
for($i=0; $i<=20; $i++){
		$fs = 100 - $i;
		$idd = 1+$i;
		echo $fs."-".$idd."<br>";
//$bq11 = mysqli_query($db,"UPDATE gradeband SET score='$fs' WHERE id='$idd'");
}		

echo "<br><br>";
$thelastiddd = mysqli_query($db,"SELECT * FROM gradeband where id='21' ORDER BY id DESC");
	while($row = mysqli_fetch_assoc($thelastiddd)){
					$idr2 = $row["id"];
					$scr2 = $row["score"];
				}
				$idr = $idr2+1;
				$scr = $scr2-1;			
//echo $idr."-".$scr;
	

for($i=0; $i<=9; $i++){
		$fs2 = $scr-$i;
		$idd2 = $idr+$i;
		echo $fs2."-".$idd2."<br>";
	// $bq2 = mysqli_query($db,"UPDATE gradeband SET score='$fs', grade='B2' WHERE id='$idd2'");
	}

	
echo "<br><br>";
$thelastiddd3 = mysqli_query($db,"SELECT * FROM gradeband where id='31' ORDER BY id DESC");
	while($row = mysqli_fetch_assoc($thelastiddd3)){
					$idr3 = $row["id"];
					$scr3 = $row["score"];
				}
				$idr33 = $idr3+1;
				$scr33 = $scr3-1;
for($i=0; $i<=9; $i++){
		$fs3 = $scr33-$i;
		$idd3 = $idr33+$i;
		echo $fs3."-".$idd3."<br>";
	// $bq2 = mysqli_query($db,"UPDATE gradeband SET score='$fs', grade='B2' WHERE id='$idd2'");
	}				
?>