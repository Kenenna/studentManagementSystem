<?php
/*
Author: Javed Ur Rehman
Website: https://htmlcssphptutorial.wordpress.com
*/
?>

<?php
$connection = mysql_connect('localhost', 'thetutor_user', 'Uandme_12');
if (!$connection){
    die("Database Connection Failed" . mysql_error());
}
$select_db = mysql_select_db('thetutor_db');
if (!$select_db){
    die("Database Selection Failed" . mysql_error());
}
?>