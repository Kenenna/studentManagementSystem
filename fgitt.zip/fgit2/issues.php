<?php
session_start();
include("auth.php"); //include auth.php file on all secure pages
require_once("connection.php");
$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Issue</title>
<link rel="stylesheet" href="css/style.css" />
<style>
.pbutton {
	background-color:#44c767;
	-moz-border-radius:2px;
	-webkit-border-radius:2px;
	border-radius:2px;
	border:1px solid #18ab29;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:12px;
	padding:6px 20px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
	float: left;
	margin: 0;
	height: 15px;
}
.pbutton:hover {
	background-color:#5cbf2a;
}
.pbutton:active {
	position:relative;
	top:1px;
}
.pbutton2 {
	background-color:#44c767;
	-moz-border-radius:2px;
	-webkit-border-radius:28px;
	border-radius:28px;
	border:1px solid #18ab29;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:15px;
	padding:6px 24px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
}
.pbutton2:hover {
	background-color:#5cbf2a;
}
.pbutton2:active {
	position:relative;
	top:1px;
}
nav{
z-index: 1000;
}
nav ul li a{
z-index: 1000;
}
nav ul{
z-index: 1000;
}
  nav ul li ul li{
           float: left;   
        }
</style>
<link rel="stylesheet" href="css/styles.css">
<script src="table/js/jquery.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js" type="text/javascript"></script>
	
    <script type="text/javascript">
   $(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
        {
            extend: 'colvis',
            columns: ':gt(1)'
        }
    ]
    } );
} );
</script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.4.2/css/buttons.dataTables.min.css">
  
   <link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
   var docHeight = $(window).height();
   var footerHeight = $('#footer').height();
   var footerTop = $('#footer').position().top + footerHeight;
   if (footerTop < docHeight) {
    $('#footer').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>
    <link href="acemenu/css/ace-responsive-menu.css" rel="stylesheet" type="text/css" />
  <!--<script src="acemenu/js/jquery-1.10.1.min.js" type="text/javascript"></script>-->
    <script src="acemenu/js/ace-responsive-menu.js" type="text/javascript"> </script>
    <script>
$(document).ready(function() {
     $("#respMenu").aceResponsiveMenu({
                 resizeWidth: '768', // Set the same in Media query       
                 animationSpeed: 'fast', //slow, medium, fast
                 accoridonExpAll: false //Expands all the accordion menu on click
             }); });
 </script>
</head>
<body>
<?php
$resultrole2 = mysqli_query($db, "SELECT * FROM users2 where username='".$_SESSION['username']."'");
while($rowrole2 = mysqli_fetch_assoc($resultrole2))
{
	$arole[] = $rowrole2['role'];
	$adminlevel2[] = $rowrole2['adminlevel'];
}
$_SESSION['role'] =  current($arole);
$_SESSION['adminlevel'] =  current($adminlevel2);

if($_SESSION['role'] == 'teacher'){
include("header.php");
}
elseif($_SESSION['role'] == 'admin'){
echo '<ul class="topnav" id="myTopnav">';
echo '<li><a href="adstuadmin.php">Add Student</a></li>';
echo '<li><a href="adminaddformt.php">Add Form Tutor</a></li>';
echo '<li><a href="admgetresult.php">Student\'s Result</a></li>';
echo '<li><a href="admviewtea.php">View Teachers</a></li>';
echo '<li><a href="admviewtutor.php">View Tutors</a></li>';
echo '<li><a href="admviewhp.php">View House Parent</a></li>';
echo '<li><a href="viewmaxatt.php">View Max Attendance</a></li>';
echo '<li><a href="newpass.php">Change Pass</a></li>';
if($_SESSION['adminlevel']==4){
echo '<li><a href="manageadmins.php">Admins</a></li>';
}
echo '<li><a href="chooseschool.php">School</a></li>';
echo '<li><a href="logout.php">Logout</a></li>';
echo '<li class="icon">';
echo '<a href="javascript:void(0);" onclick="myFunction()">&#9776;</a>';
echo '</li>';
echo '</ul>';
}
elseif($_SESSION['role'] == 'principal'){
echo '<ul class="topnav" id="myTopnav">';
echo '<li><a href="admgetresult.php">Student\'s Result</a></li>';
echo '<li><a href="admviewtea.php">View Teachers</a></li>';
echo '<li><a href="admviewtutor.php">View Tutors</a></li>';
echo '<li><a href="admviewhp.php">View House Parent</a></li>';
echo '<li><a href="viewmaxatt.php">View Max Attendance</a></li>';
echo '<li><a href="newpass.php">Change Pass</a></li>';
if($_SESSION['adminlevel']==4){
echo '<li><a href="manageadmins.php">Admins</a></li>';
}
echo '<li><a href="chooseschool.php">School</a></li>';
echo '<li><a href="princicomments.php">Principal\'s Comments</a></li>';
echo '<li><a href="logout.php">Logout</a></li>';
echo '<li class="icon">';
echo '<a href="javascript:void(0);" onclick="myFunction()">&#9776;</a>';
echo '</li>';
echo '</ul>';
}
elseif($_SESSION['role'] == 'student'){
echo '<ul class="topnav" id="myTopnav">';
echo '<li><a href="teagetresultmid.php">Midterm Result</a></li>';
echo '<li><a href="teagetresult.php">Term Result</a></li>';
echo '<li><a href="newpass.php">Change Pass</a></li>';
echo '<li><a href="logout.php">Logout</a></li>';
echo '<li class="icon">';
echo '<a href="javascript:void(0);" onclick="myFunction()">&#9776;</a>';
echo '</li>';
echo '</ul>';
}
else{echo "";}
?>
<br><br>
<?php
echo '<center><div style="z-index: -1;" class="row-fluid">';
echo '<div class="span12">';
echo '<br><br><br>';
echo '<div class="container" style="width:80%;">';
echo '<table style="width:100%; z-index: -1;" cellpadding="1" cellspacing="1" border="1" class="table table-striped table-bordered" id="example">';
echo '<thead><tr style="text-align:left;">';
$user = $_SESSION['username'];
$result1 = mysqli_query($db, "SELECT * FROM users2 where username='$user' AND school='".$_SESSION['school']."'");
while ($row1 = mysqli_fetch_assoc($result1)) {
	$valteacher[] = $row1['teacher'];
	$teacherid[] = $row1['teacher_id'];
}
$valteach = current($valteacher);
$teachid = current($teacherid);

$resultar = mysqli_query($db,"SELECT * FROM school where school='".$_SESSION["school"]."'");
				while($rowar = mysqli_fetch_assoc($resultar)){
					$arrr2[] = $rowar["arms"];
				}
				$a = implode(',',$arrr2);
				$b = explode(',',$a);
				$f = (array_filter($b));

echo '<th style="display: none;" >&nbsp;</th><th style="display: none;">ID</th><th style="display: none;" >Teacher</th><th>Class</th><th>Arm</th><th>Session Commencing</th><th>Term</th><th style="display: none;">Subject</th><th>Action</th><th style="display: none;" >&nbsp;</th></tr></thead><tbody>';
$result = mysqli_query($db, "SELECT * FROM teachers where teacher_name='$valteach' AND school='".$_SESSION['school']."'");
while($row = mysqli_fetch_assoc($result)){
if($row['class_id']==1)
{ 
$class_name= 'Year 7';
}
elseif($row['class_id']==2)
{ 
$class_name= 'Year 8';
}
elseif($row['class_id']==3)
{ 
$class_name= 'Year 9';
}
elseif($row['class_id']==4)
{ 
$class_name= 'Year 10';
}
elseif($row['class_id']==5)
{ 
$class_name= 'Year 11';
}
elseif($row['class_id']==6)
{ 
$class_name= 'Year 12';
}
elseif($row['class_id']==7)
{ 
$class_name= 'Year 1';
}
elseif($row['class_id']==8)
{ 
$class_name= 'Year 2';
}
elseif($row['class_id']==9)
{ 
$class_name= 'Year 3';
}
elseif($row['class_id']==10)
{ 
$class_name= 'Year 4';
}
elseif($row['class_id']==11)
{ 
$class_name= 'Year 5';
}
elseif($row['class_id']==12)
{ 
$class_name= 'Year 6';
}
else{
	
}
if($row['term_id']==1)
{ 
$term= 'First Term';
}
elseif($row['term_id']==2)
{ 
$term= 'Second Term';
}
elseif($row['term_id']==3)
{ 
$term= 'Third Term';
}
else{
}
if($row['year_id']==1){
	$year = '2012';
}
elseif($row['year_id']==2){
	$year = '2013';
}
if($row['year_id']==3){
	$year = '2014';
}
if($row['year_id']==4){
	$year = '2015';
}
if($row['year_id']==5){
	$year = '2016';
}
if($row['year_id']==6){
	$year = '2017';
}
if($row['year_id']==7){
	$year = '2018';
}
if($row['year_id']==8){
	$year = '2019';
}
if($row['year_id']==9){
	$year = '2020';
}
if($row['year_id']==10){
	$year = '2021';
}
if($row['year_id']==11){
	$year = '2022';
}
if($row['year_id']==12){
	$year = '2023';
}
if($row['year_id']==13){
	$year = '2024';
}
if($row['year_id']==14){
	$year = '2025';
}
if($row['year_id']==15){
	$year = '2026';
}
if($row['year_id']==16){
	$year = '2027';
}
if($row['year_id']==17){
	$year = '2028';
}
if($row['year_id']==18){
	$year = '2029';
}
if($row['year_id']==19){
	$year = '2030';
}
if($row['year_id']==20){
	$year = '2031';
}
if($row['year_id']==21){
	$year = '2032';
}
if($row['year_id']==22){
	$year = '2033';
}
else{	
}
if(($ctype=="Js")OR($ctype=="Primary")){
	if($class_name=="Year 1"){
		$cl = "Primary 1";
	}
	else if($class_name=="Year 2"){
		$cl = "Primary 2";
	}
	else if($class_name=="Year 3"){
		$cl = "Primary 3";
	}
	else if($class_name=="Year 4"){
		$cl = "Primary 4";
	}
	else if($class_name=="Year 5"){
		$cl = "Primary 5";
	}
	else if($class_name=="Year 6"){
		$cl = "Primary 6";
	}
	else if($class_name=="Year 7"){
		$cl = "JS1";
	}
	else if($class_name=="Year 8"){
		$cl = "JS2";
	}
	else if($class_name=="Year 9"){
		$cl = "JS3";
	}
	else if($class_name=="Year 10"){
		$cl = "SS1";
	}
	else if($class_name=="Year 11"){
		$cl = "SS2";
	}
	else if($class_name=="Year 12"){
		$cl = "SS3";
	}
	else{ $cl = "NA"; }
}else{ $cl = $row['class_name']; }

echo '<tr><td style="display:none;"><form action="issues2.php" method="POST"></td>';
echo '<td style="display: none;" ><input style="display: none;" name="teacher_id" value="'.$teachid.'" />'.$teachid.'</td>';
echo '<td style="display: none;" ><input style="display: none;" name="teacher" value="'.$valteach.'" />'.$valteach.'</td>';
echo '<td><input type="hidden" name="class" value="'.$row['class_name'].'" />'.$cl.'</td>';
echo '<td><select style="width: 140px; border-radius: 2px; border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 2px; height: auto;" name="arms" id="arms" required >';
						for($i=0; $i<=(count($f)-1); $i++)
							{  
								echo '<option value="'.$f[$i].'">';
								echo $f[$i];
								echo '</option>';
							}
 echo '</select></td>'; 
echo '<td><input style="display:none;" name="year" value="'.$year.'" />'.$year.'</td>';
echo '<td><input style="display:none;" name="term" value="'.$term.'" />'.$term.'</td>';
echo '<td style="display: none;"><input style="display:none;" name="subject" value="'.$row['subject'].'" />'.$row['subject'].'</td>';
echo '<td width="80"><input type="submit" name="btn-upload" value="Comment" /></td>';
echo '<td style="display:none;"></form></td></tr>';
}
echo "</tbody></table></center>";
?>
<br><br><br>
</div></div></div>
<?php
include("footer.php");
?>
</body>
</html>