<?php 
include("auth.php");
include "connection.php";
?>
<!DOCTYPE html>
<html>
<head>
<link href="table/css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
<link rel="stylesheet" type="text/css" href="table/css/DT_bootstrap.css">
<script src="table/js/jquery.js" type="text/javascript"></script>
<script src="table/js/bootstrap.js" type="text/javascript"></script>
<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/jquery.dataTables.js"></script>
<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/DT_bootstrap.js"></script>

<!--<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">-->
<!--<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>-->

 <script>
function confirmationDelete(anchor)
{
   var conf = confirm('Are you sure want to delete this record?');
   if(conf)
      window.location=anchor.attr("href");
}
</script> 


<script>
$(function() {
    $( "#skills" ).autocomplete({
        source: 'readstudentname.php'
    });
});
</script>

<script>
$(document).ready(function() {	
$("#formid").submit(function( event ) {
var stu = $("#skills").val();
var cla = $("#class").val();
var arm = $("#arms").val();
var yea = $("#year").val();
var ter = $("#term").val();
var formt = $("#formt").val();



var dataString = 'student_name=' + stu + '&class=' + cla + '&year=' + yea + '&term=' + ter + '&formt=' + formt + '&arms=' + arm;

$.ajax({
type: "POST",
url: "addstudent_exec.php",
data: dataString,
success: function(response){
 if(response==1) {   // DO SOMETHING     
		$(".success").show();
		setTimeout(function() { $(".success").hide(); }, 3000);
		//$("#skills").val("");
    } else {
		 $(".error").show();
		setTimeout(function() { $(".error").hide(); }, 3000);
		}
}
});
event.preventDefault();
});
});


$("#refreshButton").click(function(e){
  e.preventDefault();
  window.location.reload();

});
</script>
<style>
ul.topnav {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}
ul.topnav li {float: left;}
ul.topnav li a {
    display: inline-block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    transition: 0.3s;
    font-size: 17px;
}
ul.topnav li a:hover {background-color: #555;}
ul.topnav li.icon {display: none;}

@media screen and (max-width:680px) {
  ul.topnav li:not(:first-child) {display: none;}
  ul.topnav li.icon {
    float: right;
    display: inline-block;
  }
}
@media screen and (max-width:680px) {
  ul.topnav.responsive {position: relative;}
  ul.topnav.responsive li.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  ul.topnav.responsive li {
    float: none;
    display: inline;
  }
  ul.topnav.responsive li a {
    display: block;
    text-align: left;
  }
}
</style>

<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>

 <style>
form {
  background: -webkit-linear-gradient(bottom, #CCCCCC, #EEEEEE 175px);
  background: -moz-linear-gradient(bottom, #CCCCCC, #EEEEEE 175px);
  background: linear-gradient(bottom, #CCCCCC, #EEEEEE 175px);
  margin: auto;
  position: relative;
  width: 60%;
  height: auto;
  font-family: Tahoma, Geneva, sans-serif;
  font-size: 12px;
  font-style: italic;
  line-height: 24px;
  font-weight: bold;
  color: #09C;
  text-decoration: none;
  border-radius: 10px;
  padding: 10px;
  border: 1px solid #999;
  border: inset 1px solid #333;
  -webkit-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  -moz-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
}


input {
  width: 95%;
  display: block;
  border: 1px solid #999;
  height: 20px;
  -webkit-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  -moz-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
}

select {
  width: 95%;
  display: block;
  border: 1px solid #999;
  height: 30px;
  -webkit-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  -moz-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
}

select#upload {
  width: 140px;
  height: 30px;
  display: block;
}

.button {
  width: 100px;
  position: absolute;
  right: 20px;
  bottom: 8px;
  background: #09C;
  color: #fff;
  font-family: Tahoma, Geneva, sans-serif;
  height: 30px;
  border-radius: 15px;
  border: 1p solid #999;
}

input.button:hover {
  background: #fff;
  color: #09C;
}

select:focus, input:focus {
  border: 1px solid #09C;
}
</style>     
       
</head>
<body>
<?php
if($_SESSION['role'] == 'teacher'){
echo '<ul class="topnav" id="myTopnav">';
echo '<li><a href="index.php">Home</a></li>';
echo '<li><a href="teacher-student-mid.php">Add Midscores</a></li>';
echo '<li><a href="teacher-student.php">Add Scores</a></li>';
echo '<li><a href="update-score-mid.php">Update Midscores</a></li>';
echo '<li><a href="update-score.php">Update Scores</a></li>';
echo '<li><a href="formclasses.php">Form Tutor</a></li>';
echo '<li><a href="affective.php">Input Ranks</a></li>';
echo '<li><a href="teagetresultmid.php">Midterm Result</a></li>';
echo '<li><a href="teagetresult.php">Term Result</a></li>';
echo '<li><a href="attend.php">Attendance</a></li>';
echo '<li><a href="logout.php">Logout</a></li>';
echo '<li class="icon">';
echo '<a href="javascript:void(0);" onclick="myFunction()">&#9776;</a>';
echo '</li>';
echo '</ul>';
}
elseif($_SESSION['role'] == 'admin'){
echo '<ul class="topnav" id="myTopnav">';
echo '<li><a href="adstuadmin.php">Add Student</a></li>';
echo '<li><a href="adminaddformt.php">Add Form Tutor</a></li>';
echo '<li><a href="admgetresult.php">Student\'s Result</a></li>';
echo '<li><a href="admviewtea.php">View Teachers</a></li>';
echo '<li><a href="admviewtutor.php">View Tutors</a></li>';
echo '<li><a href="viewmaxatt.php">View Max Attendance</a></li>';
echo '<li><a href="logout.php">Logout</a></li>';
echo '<li class="icon">';
echo '<a href="javascript:void(0);" onclick="myFunction()">&#9776;</a>';
echo '</li>';
echo '</ul>';
}
else{echo "";}
?>

<div class="row-fluid" style="width:100%;">
	        <div class="span12">
	            <div class="container" style="width:100%;">
				
<center>
<span class="error" style="display:none; color: red;">Insertion Failed: A student with the provided information may already exist.</span>
<span class="success" style="display:none; color: green;"> Insertion was Successful.</span>
</center>				
<br><br>				
<form id="formid">
 <div>
    <h1>Add a Student :</h1>
    <label>
     <input hidden id="id" type="hidden" name="id" />
    </label>
	<div class="ui-widget">
    <label for="skills">Student: </label>
    <input id="skills">
	</div>
     <label>
      <!--<input id="student_name" placeholder="student name" type="text" name="student_name" required/>-->
    </label>
	
	
    <label>
     <select  name="class" class="class" id="class" required >
<?php 
	$resultcl = mysqli_query($db, "SELECT * FROM classes");
						while($rowcl = mysqli_fetch_assoc($resultcl))
							{  
								echo '<option value="'.$rowcl['class_name'].'">';
								echo $rowcl['class_name'];
								echo '</option>';
							}
?>
</select>
</label>

 <label>
     <select  name="arms" class="arms" id="arms" required >
<?php 
	$resultcl = mysqli_query($db, "SELECT * FROM arms");
						while($rowcl = mysqli_fetch_assoc($resultcl))
							{  
								echo '<option value="'.$rowcl['arms'].'">';
								echo $rowcl['arms'];
								echo '</option>';
							}
?>
</select>
</label>


 <label>
 <select name="year" class="year" id="year" required >
<?php 
	$resultyr = mysqli_query($db, "SELECT * FROM years");
						while($rowyr = mysqli_fetch_assoc($resultyr))
							{  
								echo '<option value="'.$rowyr['year'].'">';
								echo $rowyr['year'];
								echo '</option>';
							}
?>
</select>
</label>


<label>
<select name="term" class="term" id="term" required >
<?php
	$resulttm = mysqli_query($db, "SELECT * FROM terms");
						while($rowtm = mysqli_fetch_assoc($resulttm))
							{  
								echo '<option value="'.$rowtm['term'].'">';
								echo $rowtm['term'];
								echo '</option>';
							}
?>							
</select>
</label>
	<?php 
	$user = $_SESSION['username'];
$result1 = mysqli_query($db, "SELECT * FROM users2 where username='$user'");
while ($row1 = mysqli_fetch_assoc($result1)) {
	$valteacher[] = $row1['teacher'];
}
$valteach = current($valteacher);
?>
 <label>
      <input id="formt" value="<?php echo $valteach; ?>" type="hidden" name="formt" />
    </label>
	
   <br>
      <input type="submit" class="button" name="btn-upload" value="Submit Form" />
    </label>

  </div>
</form><br>

				
				
			<a id="refreshButton" href="#">Refresh</a>	
				
				
		<table style="width:100%; float:left;"cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
				
			<thead><tr>
			<th>Student</th><th>Class</th><th>Arm</th><th>Year</th><th>Term</th><th style="display: none;"></th><th>Edit</th><th>Delete</th>
			</thead></tr>
<?php
$user = $_SESSION['username'];
$result1 = mysqli_query($db, "SELECT * FROM users2 where username='$user'");
while ($row1 = mysqli_fetch_assoc($result1)) {
	$valteacher[] = $row1['teacher'];
}
$valteach = current($valteacher);




if(isset($_POST['btn-upload'])){
        $teacher_id = $_POST['teacher_id'];
		$teacher = $_POST['teacher'];
        $class = $_POST['class'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		$arms = $_POST['arms'];
$result = mysqli_query($db, "SELECT * FROM studentsbyclass where class='$class' AND year='$year' AND term='$term' AND formt='$valteach' AND arms='$arms'");
while ($row = mysqli_fetch_assoc($result)) {
	echo '<tr>';
echo '<td><input readonly="readonly" type="text" id="student_name" name="student_name[]" value="'.$row['student_name'].'" /></td>';	
echo '<td><input readonly="readonly" type="text" id="class" name="class[]" value="'.$row['class'].'" /></td>';
echo '<td><input readonly="readonly" type="text" id="arms" name="arms[]" value="'.$row['arms'].'" /></td>';
echo '<td><input readonly="readonly" type="text" id="year" name="year[]" value="'.$row['year'].'" /></td>';
echo '<td><input readonly="readonly" type="text" id="term" name="term[]" value="'.$row['term'].'" /></td>';
echo '<td style="display: none;"><input readonly="readonly" type="text" id="tutor" name="tutor[]" value="'.$valteach.'" /></td>';
echo '<td><a href="updatestudentsbyclass.php?id='.$row['id'].'"><img src="table/edit-icon.png" alt="no image" height="30" width="30" /></a></td>';
echo '<td><a onClick="javascript:confirmationDelete($(this));return false;" href="delclass.php?id='.$row['id'].'"><img src="table/deletee.png" alt="no image" height="30" width="30" /></a></td>';
'</tr>';
}
}
?>
</table>
</div></div></div>
<br>
 </body>
</html>
