<?php
	include("auth.php"); 
	include('db.php');
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Insert Attendance</title>
<link rel="stylesheet" href="css/style.css" />
		<link href="table/css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
        <link rel="stylesheet" type="text/css" href="table/css/DT_bootstrap.css">

	<script src="table/js/jquery.js" type="text/javascript"></script>
<script src="table/js/bootstrap.js" type="text/javascript"></script>
	
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/jquery.dataTables.js"></script>
	<script type="text/javascript" charset="utf-8" language="javascript" src="table/js/DT_bootstrap.js"></script>
	
<!--<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>-->
<script>
$(document).ready(function() {
	var rowCount = $('.checkSingles').length;
	/*$(".checkSingles").slice( 0, (rowCount/2) ).css( "background-color", "green" );
	$(".checkSingles").slice(0, (rowCount/2)).css( "color", "white" );
	$(".checkSingles").slice((rowCount/2), rowCount).css( "color", "white" );
	$(".checkSingles").slice((rowCount/2), rowCount).css( "background-color", "blue" );
	*/
	$("input.checkSingleaft").slice( 0, (rowCount/2) ).val( "Morning" ).css("background-color", "green").css("color", "white");
	$("input.checkSingleaft").slice((rowCount/2), rowCount).val( "Afternnon" ).css("background-color", "blue").css("color", "white");
	$(".checkSingles").slice( 0, (rowCount/2) ).css("background-color", "green").css("color", "white");
	$(".checkSingles").slice((rowCount/2), rowCount).css("background-color", "blue").css("color", "white");
	
	var arrp = [];
	var arrp2 = [];
   $( ".checkSingle" ).each(function( index ){
	   var chattt = this.id;
	   arrp.push(chattt);
	   arrp2.push(index+1);
	});
	 $( ".checkSingle" ).each(function( index ){
		var chatttt = (this.id).substring(3);
		var iNum = parseInt(chatttt);
		if((iNum+1)%2 == 0){
		$(this).css( "background-color", "green" );
		$(this).css( "color", "white" );
		$('[id=sn_'+chatttt+']').css("color", "white").css("background-color", "green");
		$('[id=dt_'+chatttt+']').val('morning').css("color", "white").css("background-color", "green");
		}
		else{
		$(this).css( "background-color", "blue" );	
		$(this).css( "color", "white" );
		$('[id=sn_'+chatttt+']').css("color", "white").css("background-color", "blue");
		$('[id=dt_'+chatttt+']').val('afternnon').css("color", "white").css("background-color", "blue");
		}
	});
  
  $(".checkSingle").click(function() {
    var chatt = this.id;
	//alert(chatt);
	var $ss = $('[id='+chatt+']').val();
	if($ss == 'absent'){
	 $('[id='+chatt+']').val("present");
	}
	else if($ss == 'present'){
	$('[id='+chatt+']').val("midterm");
	}
	else if($ss == 'midterm'){
	$('[id='+chatt+']').val("absent");
	}
	else{
	$('[id='+chatt+']').val("present");	
	}
	return false;
});
	$(".txtFirstName1").hide();
	$(".txtFirstName2").hide();
	$(".txtFirstName3").hide();
	var pr = $(".txtFirstName1").val("present");
    $("#dosomething1").click(function(){
	$(".checkSingle").val("present");
	});
   var abs = $(".txtFirstName2").val("absent");
    $("#dosomething2").click(function(){
	$(".checkSingle").val("absent");
	});
	var mterm = $(".txtFirstName3").val("midterm");
	$("#dosomething3").click(function(){
	$(".checkSingle").val("midterm");
	});
	var prsec = $(".txtFirstName1").val("present");
    $("#dosomething1").click(function(){
	$(".checkSingle").val("present");
	return false;
	});
   var abssec = $(".txtFirstName2").val("absent");
    $("#dosomething2").click(function(){
	$(".checkSingle").val("absent");
	return false;
	});
	var mtermsec = $(".txtFirstName3").val("midterm");
	$("#dosomething3").click(function(){
	$(".checkSingle").val("midterm");
	return false;
	});
});
</script>

<script>
		$(document).ready(function() {	
		$("#formid").submit(function( event ) {
			event.preventDefault();	
$.ajax({
type: "POST",
url: "attend_exec.php",
data: $("#formid").serializeArray(),	
success: function(response){
 if(response==1) { 
		event.preventDefault();
		$(".success").fadeIn();
		setTimeout(function() { $(".success").fadeOut(); }, 2000); 
		//$('#rload').load("rload.php");
		var cj = $("#classj").val();
		var yj = $("#yearj").val();
		var tj = $("#termj").val();
		var armj = $("#armsj").val();
		var dnj = $("#datenamej").val();
		var tnj = $("#tnaj").val();
		//alert(cj);
		//alert(yj);
		//alert(tj);
		//alert(dnj);
		<?php $ddnn = $_POST['datename']; ?>
		var dnjj = <?php echo json_encode($ddnn, JSON_HEX_TAG); ?>;
		<?php $clnn = $_POST['class']; ?>
		var cljj = <?php echo json_encode($clnn, JSON_HEX_TAG); ?>;
		<?php $yrnn = $_POST['year']; ?>
		var yrjj = <?php echo json_encode($yrnn, JSON_HEX_TAG); ?>;
		<?php $ternn = $_POST['term']; ?>
		var terjj = <?php echo json_encode($ternn, JSON_HEX_TAG); ?>;
		<?php $arnn = $_POST['arms']; ?>
		var arjj = <?php echo json_encode($arnn, JSON_HEX_TAG); ?>;
		window.location = "attend.php?class="+cljj+"&year="+yrjj+"&term="+terjj+"&arms="+arjj+"&datename="+dnjj+"&tna="+tnj;
    } else {
		 $(".error").show();
		setTimeout(function() { $(".error").fadeOut(); }, 2000);
		}
		}
});	
});

$("#viewst").html("View Attendance");
$("#viewstu").hide();
 $("#viewst").click(function( event ) {
		event.preventDefault();
		var hi = $("#viewst").html();
		if(hi == "View Attendance"){	
		$("#viewst").html("Hide Attendance");
		$("#viewstu").show();
		}
		else if(hi == "Hide Attendance"){	
		$("#viewst").html("View Attendance");
		$("#viewstu").hide();
		}
	 });
 
 
 $("#takest").html("Show Take-Attendance Form");
$("#takestu").hide();
 $("#takest").click(function( event ) {
		event.preventDefault();
		var hi = $("#takest").html();
		if(hi == "Show Take-Attendance Form"){	
		$("#takest").html("Hide Take-Attendance Form");
		$("#takestu").show();
		}
		else if(hi == "Hide Take-Attendance Form"){	
		$("#takest").html("Show Take-Attendance Form");
		$("#takestu").hide();
		}
	 });
 
 
 $("#formidupdate").submit(function( event ) {
			event.preventDefault();	
$.ajax({
type: "POST",
url: "update_attend_exec.php",
data: $("#formidupdate").serializeArray(),	
success: function(response){
 if(response==1) { 
		event.preventDefault();
		$(".success").fadeIn();
		setTimeout(function() { $(".success").fadeOut(); }, 2000); 
    } else {
		 $(".error").show();
		setTimeout(function() { $(".error").fadeOut(); }, 2000);
		}
		}
});	
});
 
});
</script>

<style>
ul.topnav {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}
ul.topnav li {float: left;}
ul.topnav li a {
    display: inline-block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    transition: 0.3s;
    font-size: 17px;
}
ul.topnav li a:hover {background-color: #555;}
ul.topnav li.icon {display: none;}

@media screen and (max-width:680px) {
  ul.topnav li:not(:first-child) {display: none;}
  ul.topnav li.icon {
    float: right;
    display: inline-block;
  }
}
@media screen and (max-width:680px) {
  ul.topnav.responsive {position: relative;}
  ul.topnav.responsive li.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  ul.topnav.responsive li {
    float: none;
    display: inline;
  }
  ul.topnav.responsive li a {
    display: block;
    text-align: left;
  }
}
input.checkSingle{
	cursor: pointer;
}
</style>

<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>
<style>
.myButton {
	background-color:#44c767;
	-moz-border-radius:28px;
	-webkit-border-radius:28px;
	border-radius:28px;
	border:1px solid #18ab29;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:15px;
	padding:6px 24px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
	float: left;
}
.myButton:hover {
	background-color:#5cbf2a;
}
.myButton:active {
	position:relative;
	top:1px;
}
</style>
</head>

<body>
<?php
if($_SESSION['role'] == 'teacher'){
echo '<ul class="topnav" id="myTopnav">';
echo '<li><a href="index.php">Home</a></li>';
echo '<li><a href="teacher-student-mid.php">Add Midscores</a></li>';
echo '<li><a href="teacher-student.php">Add Scores</a></li>';
echo '<li><a href="update-score-mid.php">Update Midscores</a></li>';
echo '<li><a href="update-score.php">Update Scores</a></li>';
echo '<li><a href="formclasses.php">Form Tutor</a></li>';
echo '<li><a href="affective.php">Input Ranks</a></li>';
echo '<li><a href="teagetresultmid.php">Midterm Result</a></li>';
echo '<li><a href="teagetresult.php">Term Result</a></li>';
echo '<li><a href="logout.php">Logout</a></li>';
echo '<li class="icon">';
echo '<a href="javascript:void(0);" onclick="myFunction()">&#9776;</a>';
echo '</li>';
echo '</ul>';
}
elseif($_SESSION['role'] == 'admin'){
echo '<ul class="topnav" id="myTopnav">';
echo '<li><a href="adstuadmin.php">Add Student</a></li>';
echo '<li><a href="adminaddformt.php">Add Form Tutor</a></li>';
echo '<li><a href="admgetresult.php">Student\'s Result</a></li>';
echo '<li><a href="admviewtea.php">View Teachers</a></li>';
echo '<li><a href="admviewtutor.php">View Tutors</a></li>';
echo '<li><a href="viewmaxatt.php">View Max Attendance</a></li>';
echo '<li><a href="logout.php">Logout</a></li>';
echo '<li class="icon">';
echo '<a href="javascript:void(0);" onclick="myFunction()">&#9776;</a>';
echo '</li>';
echo '</ul>';
}
else{echo "";}
?>
<?php
$user = $_SESSION['username'];
?>
<h1 class="hello">Hello, <em><?php echo $user;?>!</em></h1>
<center>
  <a style="color: red; font-weight: bold; font-size: 20px; text-decoration: none;" href="#" id="takest"></a><br><br>
  
<form action="" method="post" id="takestu" enctype="multipart/form-data">
 <div>
  <?php include "connection.php"; ?>
	<label>
	<select style="width:15%;" name="class" id="class" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM classes");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['class_name'].'">';
								echo $row['class_name'];
								echo '</option>';
							}
						?>
      </select><br>
	  <select style="width:15%;" name="arms" id="arms" required >
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM arms");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['arms'].'">';
								echo $row['arms'];
								echo '</option>';
							}
						?>
      </select>
	  
	  <br>
	  <select style="width:15%;" name="year" id="year" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM years");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['year'].'">';
								echo $row['year'];
								echo '</option>';
							}
						?>
      </select>
	  
	  
	   <br>
	  <select style="width:15%;" name="term" id="term" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM terms");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['term'].'">';
								echo $row['term'];
								echo '</option>';
							}
						?>
      </select>

	
<br>
      <input type="date"  style="width:15%;" name="datename" />
    </label>
	
  <br>
      <input type="submit" style="background-color: green; color: white;" class="button" name="btn-upload" value="Get Students" />
   

  </div>
</form>
<br>
<hr />
<br>
</center>


<center>
<a style="color: red; font-weight: bold; font-size: 20px; text-decoration: none;" href="#" id="viewst"></a><br><br>
<form action="upatt.php" method="post" id="viewstu" enctype="multipart/form-data">
 <div>
	<label><select style="width:15%;" name="class" id="class" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM classes");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['class_name'].'">';
								echo $row['class_name'];
								echo '</option>';
							}
						?>
      </select>
	  
	  <br>
	  <select style="width:15%;" name="arms" id="arms" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM arms");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['arms'].'">';
								echo $row['arms'];
								echo '</option>';
							}
						?>
      </select>
	  
	  <br>
	  <select style="width:15%;" name="year" id="year" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM years");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['year'].'">';
								echo $row['year'];
								echo '</option>';
							}
						?>
      </select>
	  
	  
	   <br>
	  <select style="width:15%;" name="term" id="term" required ><br>
                   
                    <?php
	$result = mysqli_query($db, "SELECT * FROM terms");
						while($row = mysqli_fetch_assoc($result))
							{  
								echo '<option value="'.$row['term'].'">';
								echo $row['term'];
								echo '</option>';
							}
						?>
      </select>
	  </label>
  <br>
      <input type="submit" style="background-color: green; color: white;" class="button" name="btn-upload2" value="View Students" />

  </div>
  </center>
</form>
<center>
<br>
<!--<form action="upit.php" method="POST">
  <input type="submit" style="background-color: green; color: white;" class="button" name="btn-uploadup" value="View Students" />
  </form>-->
<div id="rload">
<?php
//if(isset($_POST['btn-upload'])){	
if($_GET['class']==$_POST['class']){
	$class = $_GET['class'];
}else{
	$class = $_POST['class'];
}

if($_GET['year']==$_POST['year']){
	$year = $_GET['year'];
}else{
	$year = $_POST['year'];
}

if($_GET['term']==$_POST['term']){
	$term = $_GET['term'];
}else{
	$term = $_POST['term'];
}

if($_GET['arms']==$_POST['arms']){
	$arms = $_GET['arms'];
}else{
	$arms = $_POST['arms'];
}

if($_GET['datename']==$_POST['datename']){
	$datename = $_GET['datename'];
}else{
	$datename = $_POST['datename'];
}

//$class = $_POST['class'];
//$year = $_POST['year'];
//$term = $_POST['term'];
//$arms = $_POST['arms'];
//$datename = $_POST['datename'];



$user=$_SESSION['username'];
$result3 = mysqli_query($db, "SELECT * FROM users2 where username='$user'");
while($rowtid = mysqli_fetch_assoc($result3))
{
	$tname = $rowtid['teacher'];
}
$tna = $tname;


if($_GET['tna']==""){
	$tna = $tname;
}else{
	$tna = $_GET['tna'];
}


echo '<form>';
echo '<input id="classj" value="'.$class.'" />';
echo '<input id="yearj" value="'.$year.'" />';
echo '<input id="termj" value="'.$term.'" />';
echo '<input id="armsj" value="'.$arms.'" />';
echo '<input id="datenamej" value="'.$datename.'" />';
echo '<input id="tnaj" value="'.$tna.'" />';
echo '</form>';

echo '<form>';
echo '<input id="classj2" value="'.$_GET['class'].'" />';
echo '<input id="yearj2" value="'.$_GET['year'].'" />';
echo '<input id="termj2" value="'.$_GET['term'].'" />';
echo '<input id="armsj2" value="'.$_GET['arms'].'" />';
echo '<input id="datenamej2" value="'.$_GET['datename'].'" />';
echo '<input id="tnaj2" value="'.$_GET['tna'].'" />';
echo '</form>';




$result = mysqli_query($db, "SELECT * FROM studentsbyclass where class='".$_GET["class"]."' AND year='".$_GET["year"]."' AND term='".$_GET["term"]."' AND formt='".$_GET["tna"]."' AND arms='".$_GET["arms"]."'");
$result2 = mysqli_query($db, "SELECT * FROM attend where class='".$_GET["class"]."' AND year='".$_GET["year"]."' AND term='".$_GET["term"]."' AND formt='".$_GET["tna"]."' AND datename='".$_GET["datename"]."' AND arms='".$_GET["arms"]."'");
$resultdistinctstudent = mysqli_query($db, "SELECT DISTINCT(student_name) FROM studentsbyclass where class='".$_GET["class"]."' AND year='".$_GET["year"]."' AND term='".$_GET["term"]."' AND formt='".$_GET["tna"]."' AND arms='".$_GET["arms"]."'");
$resultdistinctstudentattend = mysqli_query($db, "SELECT DISTINCT(student_name) FROM attend where class='".$_GET["class"]."' AND year='".$_GET["year"]."' AND term='".$_GET["term"]."' AND formt='".$_GET["tna"]."' AND arms='".$_GET["arms"]."' AND datename='".$_GET["datename"]."'");
while($rowds = mysqli_fetch_assoc($resultdistinctstudent))
{ 
 $valuesds2[] = $rowds['student_name'];	
}
$valuesds3 = array_merge($valuesds2, $valuesds2);

while($rowdsa = mysqli_fetch_assoc($resultdistinctstudentattend))
{ 
 $valuesdsa2[] = $rowdsa['student_name'];	
}
$valuesdsa3 = array_merge($valuesdsa2, $valuesdsa2);

$sd = array_diff($valuesds3,$valuesdsa3);
//print_r($sd);
$sd2 = count($sd);

$countresult2 = mysqli_num_rows($result2);
while($row2 = mysqli_fetch_assoc($result2))
{  						
$values2[] = $row2['student_name'];
$values2attend[] = $row2['attend']; //for the attendance table
}
$values2 = array_merge($values2, $values2);
$values22 =($values2);
$valattend = ($values2attend);
$vtu = count($values22);

while($row = mysqli_fetch_assoc($result))
{  						
$values[] = $row['student_name']; 
$valuesclass[] = $row['class']; 
$valuesyear[] = $row['year']; 
$valuesterm[] = $row['term'];
$valuesarms[] = $row['arms']; 
}
$values = array_merge($values, $values);
$vallue = $values;

$vtuu = count($values);

current($valuesclass);
current($valuesyear);
current($valuesterm);
current($valuesarms);

$r = array_diff($vallue, $values22); 
echo '<br>';
//print_r($values2)."<br>";
//print_r($vallue);
//print_r($values22);
//print_r($r);
//echo $r;
$vtuuu = $vtuu - $vtu;
//echo $vtuuu;

include "connection.php";
$result3 = mysqli_query($db, "SELECT * FROM maxattname WHERE year='".$_GET["year"]."' AND term='".$_GET["term"]."'");
while ($row3 = mysqli_fetch_assoc($result3)) {
$termbegin1[] = $row3['termbegin'];	
}
$termbegin = current($termbegin1);


if($vtuuu < 1){
	if($countresult2 <= 0){
		echo "<span style='color:red; font-size:16px; text-decoration: underline;'>You have not inputed the attendance for students enrolled in your class under the selected criteria for: ".strtoupper(date("l, jS \of F Y", strtotime($_GET['datename'])))."</span><br>";
	}else{
	   if($sd2 > 0){
//echo '<div id="showsome">';		   
echo '<span style="color: green; font-size: 16px;">Take attendance of Students in '.current($valuesclass).' for '.current($valuesterm).', '.current($valuesyear).'</span><br />';	
echo '<br>';
echo '<span style="color: green; font-size: 16px;">Attendance is for '.strtoupper(date("l, jS \of F Y", strtotime($datename))).'</span><br />';	
echo '<br>';
echo '<input type="text" class="txtFirstName1" id="txtFirstName1">';
echo '<button id="dosomething1" style="background-color: green; color: white;">Set All TO PRESENT</button>';
echo '<input type="text" class="txtFirstName2" id="txtFirstName2">';
echo '<button id="dosomething2" style="background-color: green; color: white;">Set All TO ABSENT</button>';
echo '<input type="text" class="txtFirstName3" id="txtFirstName3"><br>';
echo '<button id="dosomething3" style="background-color: green; color: white;">Set All TO MIDTERM</button>';
echo '<br>';
echo '<br>';
//echo '<form action="attend_exec.php" method="post">';
echo '<form id="formid" class="formidd">';
echo '<table id="fhalf"><thead><tr><th colspan="6"></th><tr></thead>';
echo '<tr><td style="text-align:center; font-weight: bold;">Student Name</td><td style="text-align:center; font-weight: bold;">Present</td><td style="display: none;">Class</td><td style="display: none;">Arm</td><td style="display: none;">Year</td><td style="display: none;">Term</td><td style="display: none;">Date</td><td style="font-weight: bold;">Day Period</td></tr>';		
$counter = 0;
foreach ($sd as $key => $sd['student_name']) {
echo '<tr class="checkSingles">';
echo '<td style="text-align:center;"><input type="hidden" name="student_name[]" value="'.$sd['student_name'].'" /><span>'.$sd['student_name'].'</span></td>';
echo '<td style="text-align:center;"><input style="width: 50%;" id="in_'.$counter.'" class="checkSingle" readonly="readonly" type="text" name="attend[]" /></td>';
echo '<td style="display: none;"><input type="text"  name="class[]" id="class_name" value="'.current($valuesclass).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="arms[]" id="arms" value="'.current($valuesarms).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="year[]" id="year" value="'.current($valuesyear).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="term[]" id="term" value="'.current($valuesterm).'" /></td>';
echo '<td style="display: none;"><input type="text" name="datename[]" id="datename" value="'.$datename.'"/></td>';
echo '<td style="display: none;"><input type="text" name="formt[]" id="formt" value="'.$tna.'"/></td>';
echo '<td><input readonly="readonly" style="width: 50%;" class="checkSingleaft" type="text" name="dtime[]" id="dtime" /></td>';
echo '</tr>';
$counter++;	
}
echo '<tr style="border: 0;">';
echo '<td colspan="1" style="border: 0;" class="getprogress"><input style="float: left;" type="submit" class="submit_button" name="submit" value="Submit Attendance" /></td><td colspan="3" style="border: 0;"><span class="error" style="display:none; color: red;"><img src="table/del.jpg" width="60" height="60"/>ERROR! You may be attempting to take the class attendance twice for the same day.</span><span class="success" style="display:none; color: green;"><img src="table/492.png" width="60" height="60"/> Attendance taken successfully.</span></td>';
echo '<td colspan="1" style="border: 0; display: none;" class="getfulllist"><a href="#" id="getfulllistbutton">Get Full Class</a></td>';
echo '</tr>';
echo '</table>';
echo '</form>';		
echo '</center><br>';	   	   
	   } 
	   else{
	$resultforupdate = mysqli_query($db, "SELECT * FROM attend WHERE class='$class' AND year='$year' AND arms='$arms' AND term='$term' AND datename='$datename' ORDER BY student_name ASC");
	echo "<span style='color:red; font-size:16px; text-decoration: underline;'>You may have already inputed the attendance for the students enrolled in your class under the selected criteria for: ".strtoupper(date("l, jS \of F Y", strtotime($datename)))."</span><br>";
	echo "<span style='color:red; font-size:16px; text-decoration: underline;'>You can update student's attendance status!</span><br>";
	echo '<center>';
	echo '<br>';
	echo '<span style="color: green; font-size: 16px;">Attendance is for '.strtoupper(date("D jS \of F Y", strtotime($_POST["datename"]))).'</span><br />';	
	echo '<br>';
echo '<input type="text" class="txtFirstName1" id="txtFirstName1">';
echo '<button id="dosomething1" style="background-color: green; color: white;">Set All TO PRESENT</button>';
echo '<input type="text" class="txtFirstName2" id="txtFirstName2">';
echo '<button id="dosomething2" style="background-color: green; color: white;">Set All TO ABSENT</button>';
echo '<input type="text" class="txtFirstName3" id="txtFirstName3"><br>';
echo '<button id="dosomething3" style="background-color: green; color: white;">Set All TO MIDTERM</button>';
echo '<br>';
echo '<form id="formidupdate">';
echo '<table><thead><tr><th colspan="6"></th><tr></thead>';
echo '<tr><td style="text-align:center; font-weight: bold; display: none;">ID</td><td style="text-align:center; font-weight: bold;">Student Name</td><td style="text-align:center; font-weight: bold;">Status</td><td style="text-align:center; font-weight: bold;">Day Period</td></tr>';		
$counter = 0;
while ($resultforupdateit = mysqli_fetch_assoc($resultforupdate)) {
echo '<tr class="checkSingles">';
echo '<td style="display: none;"><input type="text" style="width:80%; display: none;" name="id[]" id="id" value="'.$resultforupdateit["id"].'" readonly="readonly" /></td>';	
echo '<td style="text-align:center;"><input style="text-align:center;" type="text" name="student_name[]" value="'.$resultforupdateit["student_name"].'" id="sn_'.$counter.'" readonly/></td>';
echo '<td style="text-align:center;"><input style="width: 80%; text-align:center;" type="text" name="attend[]" class="checkSingle" readonly="readonly" value="'.$resultforupdateit["attend"].'" id="in_'.$counter.'" /></td>';
echo '<td><input readonly="readonly" style="width: 80%; text-align:center;" class="checkSingleaft" type="text" name="dtime[]" id="dt_'.$counter.'" /></td>';
echo '</tr>';
$counter++;
}
echo '<tr style="border: 0;">';
echo '<td colspan="2" style="border: 0;" class="getprogress"><input style="left: right;" type="submit" class="submit_button" name="submit" value="Submit Attendance" /></td><td colspan="2" style="border: 0;"><span class="error" style="display:none; color: red;"><img src="table/del.jpg" width="60" height="60"/>Updates could not be made.</span><span class="success" style="display:none; color: green;"><img src="table/492.png" width="60" height="60"/> Attendance updated successfully.</span></td>';
echo '</tr>';
echo '</table>';
echo '</form>';	
echo '</center>';
}
}
}
else if($vtu == 0){
	$values22[] = "nothingham";
	$r = array_diff($vallue, $values22);
echo '<span style="color: green; font-size: 16px;">Take attendance of Students in '.current($valuesclass).''.current($valuesarms).' for '.current($valuesterm).', '.current($valuesyear).'</span><br />';		
echo '<br>';
echo '<center>';
echo '<input type="text" class="txtFirstName1" id="txtFirstName1">';
echo '<button id="dosomething1" style="background-color: green; color: white;">Set All TO PRESENT</button>';
echo '<input type="text" class="txtFirstName2" id="txtFirstName2">';
echo '<button id="dosomething2" style="background-color: green; color: white;">Set All TO ABSENT</button>';
echo '<input type="text" class="txtFirstName3" id="txtFirstName3"><br>';
echo '<button id="dosomething3" style="background-color: green; color: white;">Set All TO MIDTERM</button>';
echo '</center><br>';
echo '<br>';
echo '<form id="formid" class="formid">';
echo '<table id="fhalf"><thead><tr><th colspan="6"></th><tr></thead>';
echo '<tr><td style="text-align:center; font-weight: bold;">Student Name</td><td style="text-align:center; font-weight: bold;">Present</td><td style="display: none;">Class</td><td style="display: none;">Arm</td><td style="display: none;">Year</td><td style="display: none;">Term</td><td style="display: none;">Date</td><td style="font-weight: bold;">Day Period</td></tr>';		
$counter = 0;
foreach ($r as $key => $r['student_name']) {
echo '<tr class="checkSingles">';	
echo '<td style="text-align:center;"><input type="hidden" name="student_name[]" value="'.$r['student_name'].'" />'.$r['student_name'].'</td>';
echo '<td style="text-align:center;"><input style="width: 50%;" id="in_'.$counter.'" class="checkSingle" readonly="readonly" type="text" name="attend[]" value="absent" /></td>';
echo '<td style="display: none;"><input type="text"  name="class[]" id="class_name" value="'.current($valuesclass).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="arms[]" id="arms" value="'.current($valuesarms).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="year[]" id="year" value="'.current($valuesyear).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="term[]" id="term" value="'.current($valuesterm).'" /></td>';
echo '<td style="display: none;"><input type="text" name="datename[]" id="datename" value="'.$datename.'"/></td>';
echo '<td style="display: none;"><input type="text" name="formt[]" id="formt" value="'.$tna.'"/></td>';
echo '<td><input readonly="readonly" style="width: 50%;" class="checkSingleaft" type="text" name="dtime[]" id="dtime" /></td>';
echo '</tr>';
$counter++;	
}
echo '<tr style="border: 0;">';
echo '<td colspan="2" style="border: 0;" class="getprogress"><input style="float: left;" type="submit" class="submit_button" name="submit" value="Submit Attendance" /></td><td colspan="3" style="border: 0;"><span class="error" style="display:none; color: red;"><img src="table/del.jpg" width="60" height="60"/>ERROR! You may be attempting to take the class attendance twice for the same day.</span><span class="success" style="display:none; color: green;"><img src="table/492.png" width="60" height="60"/> Attendance taken successfully.</span></td>';
echo '</tr>';
echo '</table>';
echo '</form>';		
}
else{
echo '<center>';
echo '<span style="color: green; font-size: 16px;">Take attendance of Students in '.current($valuesclass).''.current($valuesclass).' for '.current($valuesterm).', '.current($valuesyear).'</span><br />';	
echo '<br>';
echo 'Check All<br />';		
echo '<form>';
echo '<input type="checkbox" name="checkedAll" id="checkedAll"></input>';
echo '</form><br>';
echo '<form action="teacher-student_exec.php" method="post">';
echo '<table id="fhalf" ><thead><tr><th style="text-align:center;">Student Name</th><th style="text-align:center;">Present</th><th style="display: none;">Class</th><th style="display: none;">Arm</th><th style="display: none;">Year</th><th style="display: none;">Term</th><th style="display: none;">Date</th></tr></thead>';
foreach ($r as $key => $r['student_name']) {
echo '<tr class="checkSingles">';
echo '<td style="text-align:center;"><input type="hidden" name="student_name[]" value="'.$r['student_name'].'" />'.$r['student_name'].'</td>';
echo '<td class="checkSingles" style="text-align:center;"><input class="checkSingle" type="checkbox" name="attend[]" value="present" id="attend" /></td>';
echo '<td style="display: none;"><input type="text"  name="class[]" id="class_name" value="'.current($valuesclass).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="arms[]" id="class_name" value="'.current($valuesarms).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="year[]" id="year" value="'.current($valuesyear).'" /></td>';
echo '<td style="display: none;"><input type="text"  name="term[]" id="term" value="'.current($valuesterm).'" /></td>';
echo '<td style="display: none;"><input type="text" name="datename[]" id="datename" value="'.$datename.'"/></td>';
echo '<td style="display: none;"><input type="text" name="formt[]" id="formt" value="'.$tna.'"/></td>';
echo '</tr>';
}
echo '<tr>';
echo '<td colspan="5"><input style="float: right;" type="submit" class="submit_button" name="submit" value="Submit Scores" /></td>';
echo '</tr>';
echo '</table>';
echo '</form>';	
echo '</center>';
}
//}
?>
<br>
</div>
</body>
</html>