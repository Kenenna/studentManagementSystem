<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Index</title>
<style>
.div1{
	background-color: green;
	height: 400px;
	width: 400px;
	margin: auto 0;
	padding: 0;
	text-align: center;
	color: white;
	text-transform: capitalize;
	font-size: 20px;
	border: dotted white 10px;
	text-decoration: underline;
}
</style>
</head>
<body>
<center><div class="div1">
<img src="images/1.jpg" height="70" width="70"/>my name is arif.
</div></center>

</body>
</html>