<?php
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsch = mysqli_fetch_assoc($resultsch))
							{  
								$ctype2[] = $rowsch['classtype'];
							}
							$ctype = current($ctype2);
							//echo $ctype;
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Get Result</title>
<script type="text/javascript" src="js/jquery-2.1.4.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script>
$(document).ready(function(){
$('#ttable td').each(function () {
  if ($(this).text() == 0 || $(this).text() == '0') {
    $(this).text('-');
  }
});
});
</script>
<script>
$(document).ready(function() {	
$("#resultpdf").submit(function( evt ) {
			evt.preventDefault();
var countlist = $("#resultlist li").length;	
if(countlist > 0){
$(".liresultlist").fadeOut(500); 	
}		
$.ajax({
type: "POST",
url: "pdf4/examples/resultpdfmid.php",
cache: false,
beforeSend: function(){
	$("#loadit").addClass("loader");
	$("#loadit").after("<label id='forremoval' style='color: red;' >We are preparing your download. Please wait...</label>");
	$('#attpdfsubmit').attr( 'onClick', 'return false' );
	},
data: $("#resultpdf").serializeArray(),
success: function(response){
$("#forresultit").remove();		
$("#resultlist").append("<li class='liresultlist'><a class='pbutton' style='margin: auto; text-align: center;' id='forresult' href='pdf4/examples/"+response+"' download>download your result</a></li>");	
},
complete: function(){
$("#loadit").removeClass("loader");	
$("#forremoval").remove();
$('#attpdfsubmit').attr( 'onClick', 'return true' );
}
});			
});
});
</script>
<script>
function printDiv(eleId){
    var PW = window.open('', '_blank', 'Print content');
 
    //IF YOU HAVE DIV STYLE IN CSS, REMOVE BELOW COMMENT AND ADD CSS ADDRESS
    //PW.document.write('<link rel="stylesheet" type="text/css" href="CSS-FILE-ADDRESS"/>');
 
    PW.document.write(document.getElementById(eleId).innerHTML);
    PW.document.close();
    PW.focus();
    PW.print();
    PW.close();
}
</script>
<style>
.pbutton {
	background-color:#44c767;
	-moz-border-radius:28px;
	-webkit-border-radius:28px;
	border-radius:5px;
	border:1px solid #18ab29;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:15px;
	padding:6px 24px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
	float: left;
}
.pbutton:hover {
	background-color:#5cbf2a;
}
.pbutton:active {
	position:relative;
	top:1px;
}
</style>
<style>
section {
    width: 80%;  
    margin: auto;
    padding: 8px;
}
div#one {
    width: 80%; 
    float: left;
}
div#two {
    margin-left: 1%;  
}

#section3 {
    width: 80%;  
    margin: auto;
    padding: 10px;
}
div#one3 {
    width: 50%; 
    float: left;
}
#heading{
	color: red;
}
</style>
<style>
.loader {
  border: 8px solid #f3f3f3;
  border-radius: 50%;
  border-top: 8px solid blue;
  border-right: 8px solid green;
  border-bottom: 8px solid red;
  width: 20px;
  height: 20px;
  -webkit-animation: spin 2s linear infinite;
  animation: spin 2s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.dnone{
	display: none;
}
</style>
</head>
<body>
<div id="printMe">
<table style="width:90%; border-top:0; border-bottom: 1px solid red; margin:auto; padding:auto;">
<?php
$resultsch = mysqli_query($db, "SELECT * FROM school where school='".$_SESSION["school"]."'");
						while($rowsc = mysqli_fetch_assoc($resultsch))
							{  
								$school2[] = $rowsc['school'];
								$address2[] = $rowsc['address'];
								$tel2[] = $rowsc['tel'];
								$fax2[] = $rowsc['fax'];
								$email2[] = $rowsc['email'];
								$img2[] = $rowsc['img'];
							}
							$schooll = current($school2);
							$address = current($address2);
							$tel = current($tel2);
							$fax = current($fax2);
							$email = current($email2);
							$img = current($img2);
?>
<tr><td style="font-size:12px;"><?php echo '<img src="'.$img.'" align="left" height="60" width="100" />' ?><?php echo strtoupper($schooll); ?><br><?php echo strtoupper($address); ?><br>
Tel: <?php echo $tel; ?>; &nbsp;Fax: <?php echo $fax; ?>; &nbsp;Email: <?php echo $email; ?><span style="float:right;"><?php echo date("jS F, Y"); ?></span></td>
</tr></table>
<?php
if(isset($_POST['submit3']) OR isset($_POST['submittoresult']) OR isset($_POST['halftermsub'])){
$term = $_POST['term'];
$year = $_POST['year'];
$arms = $_POST['arms'];
$class = $_POST['class_name'];

if($class=="Year 1"){
		if($ctype=="Primary"){
		$cl = "Primary 1";
		}
		elseif($ctype=="Js"){
		$cl = "JS1";
		}else{
		$cl = "Year 1";
}}	
if($class=="Year 2"){
		if($ctype=="Primary"){
		$cl = "Primary 2";
		}
		elseif($ctype=="Js"){
		$cl = "JS2";
		}else{
		$cl = "Year 2";
}}	
if($class=="Year 3"){
		if($ctype=="Primary"){
		$cl = "Primary 3";
		}
		elseif($ctype=="Js"){
		$cl = "JS3";
		}else{
		$cl = "Year 3";
}}
if($class=="Year 4"){
		if($ctype=="Primary"){
		$cl = "Primary 4";
		}
		elseif($ctype=="Js"){
		$cl = "SS1";
		}else{
		$cl = "Year 4";
}}
if($class=="Year 5"){
		if($ctype=="Primary"){
		$cl = "Primary 5";
		}
		elseif($ctype=="Js"){
		$cl = "SS2";
		}else{
		$cl = "Year 5";
}}	
if($class=="Year 6"){
		if($ctype=="Primary"){
		$cl = "Primary 6";
		}
		elseif($ctype=="Js"){
		$cl = "SS3";
		}else{
		$cl = "Year 6";
}}	
	if($class=='Year 7'){
	if($ctype == 'Js'){
		$cl = 'JS1';
	}else{
		$cl='Year 7';
	}
	}
	if($class=='Year 8'){
	if($ctype == 'Js'){
		$cl = 'JS2';
	}else{
		$cl='Year 8';
	}
	}
	if($class=='Year 9'){
	if($ctype == 'Js'){
		$cl = 'JS3';
	}else{
		$cl='Year 9';
	}
	}
	if($class=='Year 10'){
	if($ctype == 'Js'){
		$cl = 'SS1';
	}else{
		$cl='Year 10';
	}
	}
	if($class=='Year 11'){
	if($ctype == 'Js'){
		$cl = 'SS2';
	}else{
		$cl='Year 11';
	}
	}
	if($class=='Year 12'){
	if($ctype == 'Js'){
		$cl = 'SS3';
	}else{
		$cl='Year 12';
	}
	}

if($term == 'First Term'){
echo '<table style="width:100%; text-align:center; font-weight:bold; font-size:14px;"><tr><td>MIDTERM RESULT SHEET FOR FIRST TERM, '.$year.'/'.($year+1).' SESSION</td></tr>';
echo '</table>';
}
else if($term == 'Second Term'){
echo '<table style="width:100%; text-align:center; font-weight:bold; font-size:14px;"><tr><td>MIDTERM RESULT SHEET FOR SECOND TERM, '.$year.'/'.($year+1).' SESSION</td></tr>';	
echo '</table>';
}
else{
echo '<table style="width:100%; text-align:center; font-weight:bold; font-size:14px;"><tr><td>MIDTERM RESULT SHEET FOR THIRD TERM, '.$year.'/'.($year+1).' SESSION</td></tr>';
echo '</table>';
}}
?>

<?php 
if(isset($_POST['submit3']) OR isset($_POST['submittoresult']) OR isset($_POST['halftermsub'])){
$student_name = $_POST['student_name'];	
$term = $_POST['term'];
$year = $_POST['year'];
$class = $_POST['class_name'];
$arms = $_POST['arms'];

echo '<table style="width:90%; margin:auto; padding:auto; text-align:center; font-size: 10px;">';
if($class=="Year 1"){
		if($ctype=="Primary"){
		$cl = "Primary 1";
		}
		elseif($ctype=="Js"){
		$cl = "JS1";
		}else{
		$cl = "Year 1";
}}	
if($class=="Year 2"){
		if($ctype=="Primary"){
		$cl = "Primary 2";
		}
		elseif($ctype=="Js"){
		$cl = "JS2";
		}else{
		$cl = "Year 2";
}}	
if($class=="Year 3"){
		if($ctype=="Primary"){
		$cl = "Primary 3";
		}
		elseif($ctype=="Js"){
		$cl = "JS3";
		}else{
		$cl = "Year 3";
}}
if($class=="Year 4"){
		if($ctype=="Primary"){
		$cl = "Primary 4";
		}
		elseif($ctype=="Js"){
		$cl = "SS1";
		}else{
		$cl = "Year 4";
}}
if($class=="Year 5"){
		if($ctype=="Primary"){
		$cl = "Primary 5";
		}
		elseif($ctype=="Js"){
		$cl = "SS2";
		}else{
		$cl = "Year 5";
}}	
if($class=="Year 6"){
		if($ctype=="Primary"){
		$cl = "Primary 6";
		}
		elseif($ctype=="Js"){
		$cl = "SS3";
		}else{
		$cl = "Year 6";
}}	
	if($class=='Year 7'){
	if($ctype == 'Js'){
		$cl = 'JS1';
	}else{
		$cl='Year 7';
	}
	}
	if($class=='Year 8'){
	if($ctype == 'Js'){
		$cl = 'JS2';
	}else{
		$cl='Year 8';
	}
	}
	if($class=='Year 9'){
	if($ctype == 'Js'){
		$cl = 'JS3';
	}else{
		$cl='Year 9';
	}
	}
	if($class=='Year 10'){
	if($ctype == 'Js'){
		$cl = 'SS1';
	}else{
		$cl='Year 10';
	}
	}
	if($class=='Year 11'){
	if($ctype == 'Js'){
		$cl = 'SS2';
	}else{
		$cl='Year 11';
	}
	}
	if($class=='Year 12'){
	if($ctype == 'Js'){
		$cl = 'SS3';
	}else{
		$cl='Year 12';
	}
	}

//include "connection.php";	
$student_name = $_POST['student_name'];
$resultpic = mysqli_query($db, "SELECT * FROM img WHERE student_name='$student_name' AND school='".$_SESSION["school"]."'");
						while($rowpic = mysqli_fetch_assoc($resultpic))
							{
$rpic[] = $rowpic['img'];							
}
$rpic2 = current($rpic);
$result3 = mysqli_query($db, "SELECT * FROM maxattname WHERE year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while ($row3 = mysqli_fetch_assoc($result3)) {
$termbegin1[] = $row3['termbegin'];	
}
$termbegin = current($termbegin1);

$student_name = $_POST['student_name'];
$resultattmidd = mysqli_query($db, "SELECT MIN(datename) AS dtn FROM attend WHERE student_name='$student_name' AND attend='midterm' AND class='".$_POST['class_name']."' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while($rowmidd = mysqli_fetch_assoc($resultattmidd)){
$dtn = $rowmidd['dtn'];
}

$resultattmiddd = mysqli_query($db, "SELECT MAX(datename) AS dtn FROM attend WHERE student_name='$student_name' AND attend!='midterm' AND class='".$_POST['class_name']."' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
while($rowmiddd = mysqli_fetch_assoc($resultattmiddd)){
$dtnn = $rowmiddd['dtn'];
}

if($dtn==""){
$resultall = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$termbegin') AND ((attend='present') OR (attend='absent')) AND (datename <= '$dtnn') AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
}else{
$resultall = mysqli_query($db, "SELECT DISTINCT(datename) FROM attend where (datename >= '$termbegin') AND ((attend='present') OR (attend='absent')) AND (datename < '$dtn') AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");	
}

$attall = mysqli_num_rows($resultall);
$atall2 = $attall * 2;


$resultsex = mysqli_query($db, "SELECT * FROM regstu WHERE student_name='$student_name' AND school='".$_SESSION["school"]."'");
						while($rowsex = mysqli_fetch_assoc($resultsex))
							{
$rsex[] = $rowsex['sex'];
$rdob[] = $rowsex['dob'];	
$admno[] = $rowsex['admno'];					
}
$rsex2 = current($rsex);
$rdob2 = current($rdob);
$admno2 = current($admno);

if($dtn==""){
$resultatt = mysqli_query($db, "SELECT datename FROM attend WHERE student_name='$student_name' AND (datename <= '$dtnn') AND attend='present' AND class='".$_POST['class_name']."' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");	
}else{
$resultatt = mysqli_query($db, "SELECT datename FROM attend WHERE student_name='$student_name' AND (datename < '$dtn') AND attend='present' AND class='".$_POST['class_name']."' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."'");
}
$att2 = mysqli_num_rows($resultatt);
$att = $att2 ;		
?>
<tbody style="height: 13px;">
<tr>
<td>Student Name: <?php echo $student_name; ?></td>
<td>Admission No: <?php echo $admno2; ?></td>
<td>Sex: <?php echo $rsex2; ?></td>
<td rowspan="3"><?php echo '<img style="float:right;" src="'.$rpic2.'" height="60" width="80"/>' ?></td>  
</tr>
<tr>
<td>Class: <?php echo $cl; if($arms=="no"){echo "";}else{echo " ".$arms;} ?></td>
<td>Term: <?php echo $term; ?></td>
<td>Year: <?php echo $year."/".($year+1)." Session"; ?></td>  
</tr>
<tr>
<td>No of Times Present: <?php echo $att; ?></td>
<td>No of Times School Open: <?php echo $atall2; ?></td>
<td>Date of Birth: <?php echo date("jS F, Y", strtotime($rdob2)); ?></td>
</tr>
</tbody>
</table>
<?php } ?>


<table id="ttable" style="width:90%; border: 1px solid black; margin:auto; padding:auto; text-align:center; font-size: 10px;" border="1">
<tr><td colspan="12" ><div style="color:red; font-size:12px; text-align:center;">CONGNITIVE ASSESSMENT</div></td></tr>
<?php
	if(isset($_POST['submittoresult'])){
		$su = $_POST['su2'];
		$cc = $_POST['cc2'];
		$dd = $_POST['dd2'];
		$ca = $_POST['ca2'];
		$exam = $_POST['exam2'];
		$tt = $_POST['tt2'];
		$av = $_POST['av2'];
		$ccav = $_POST['ccav2'];
		$grade = $_POST['grade2'];
		$tn = $_POST['tn2'];
		$re = $_POST['re2'];
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		for ($x = 0; $x <= (count($su)-1); $x++){
echo '<tr><td>'.$su[$x].'</td><td>'.$ca[$x].'</td><td>'.$exam[$x].'</td><td>'.$tt[$x].'</td><td>'.$dd[$x].'</td><td>'.$cc[$x].'</td><td>'.$av[$x].'</td><td id="mytd">'.round($ccav[$x]).'</td><td>'.$grade[$x].'</td><td>'.$tn[$x].'</td><td>'.$re[$x].'</td></tr>';			
		}
echo '</table>';
	}
	else{
//include "connection.php";
		$student_name = $_POST['student_name'];
        $class_name = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
		$arms = $_POST['arms'];
		$byarm = $_POST['byarm'];	
		echo '<tr id="heading"><td>SUBJECT</td><td>HW (30)</td><td>CW (30)</td><td>TEST (40)</td><td>TOTAL (100)</td><td>CLASS AV. (100)</td><td>GRADE</td><td>TEACHER\'S NAME</td><td>REMARK</td></tr>';		
		if($byarm=="" OR $byarm=="no"){
		$result = mysqli_query($db, "SELECT * FROM scoresmid WHERE student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."' ORDER BY subject ASC");		
					while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}	

	$recav = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
	$recavmax = mysqli_query($db, "SELECT MAX(score) AS agrmax FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
	while($rowcav = mysqli_fetch_assoc($recav))
							{
							$agrcavin[]	= $rowcav['score'];
							}
							$agrcav = array_filter($agrcavin);
							$agrcav2 = array_sum($agrcav);
	$numbagr = count(array_filter($agrcav));
	$agrcav3 = $agrcav2/$numbagr;
	
	$recav1 = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Basic Science' AND school='".$_SESSION["school"]."'");
	while($rowcav1 = mysqli_fetch_assoc($recav1))
							{
							$bascavin[]	= $rowcav1['score'];
							}
							$bascav = array_filter($bascavin);
							$bascav2 = array_sum($bascav);
	$numbbas = count(array_filter($bascav));
	$bascav3 = $bascav2/$numbbas;
	
	$recav2 = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='English' AND school='".$_SESSION["school"]."'");
	$recav2max = mysqli_query($db, "SELECT MAX(score) AS engmax FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='English' AND school='".$_SESSION["school"]."'");
	while($rowcav2 = mysqli_fetch_assoc($recav2))
							{
							$engcavin[]	= $rowcav2['score'];
							}
							$engcav = array_filter($engcavin);
							$engcav2 = array_sum($engcav);
	$numbeng = count(array_filter($engcav));
	$engcav3 = round($engcav2/$numbeng);
	while($rowcav2max = mysqli_fetch_assoc($recav2max))
							{
							$engcavinmax[]	= $rowcav2max['engmax'];
							}
							$engcavmax = array_filter($engcavinmax);
							$engcav2max = array_sum($engcavmax);
	$numbengmax = count(array_filter($engcavmax));
	$engcav3max = $engcav2max/$numbengmax;
	//echo $engcav3max;
	
	$recav3 = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Business Studies' AND school='".$_SESSION["school"]."'");
	while($rowcav3 = mysqli_fetch_assoc($recav3))
							{
							$buscavin[]	= $rowcav3['score'];
							}
							$buscav = array_filter($buscavin);
							$buscav2 = array_sum($buscav);
	$numbbus = count(array_filter($buscav));
	$buscav3 = round($buscav2/$numbbus);
	
	$recav4 = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Catering' AND school='".$_SESSION["school"]."'");
	while($rowcav4 = mysqli_fetch_assoc($recav4))
							{
							$catcavin[]	= $rowcav4['score'];
							}
							$catcav = array_filter($catcavin);
							$catcav2 = array_sum($catcav);
	$numbcat = count(array_filter($catcav));
	$catcav3 = $catcav2/$numbcat;
	
	$recav5 = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Civic Education' AND school='".$_SESSION["school"]."'");
	while($rowcav5 = mysqli_fetch_assoc($recav5))
							{
							$civcavin[]	= $rowcav5['score'];
							}
							$civcav = array_filter($civcavin);
							$civcav2 = array_sum($civcav);
	$numbciv = count(array_filter($civcav));
	$civcav3 = $civcav2/$numbciv;
	
	$recav6 = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Crk' AND school='".$_SESSION["school"]."'");
	while($rowcav6 = mysqli_fetch_assoc($recav6))
							{
							$crkcavin[]	= $rowcav6['score'];
							}
							$crkcav = array_filter($crkcavin);
							$crkcav2 = array_sum($crkcav);
	$numbcrk = count(array_filter($crkcav));
	$crkcav3 = $crkcav2/$numbcrk;
	
	$recav7 = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Food and Nutrition' AND school='".$_SESSION["school"]."'");
	while($rowcav7 = mysqli_fetch_assoc($recav7))
							{
							$foocavin[]	= $rowcav7['score'];
							}
							$foocav = array_filter($foocavin);
							$foocav2 = array_sum($foocav);
	$numbfoo = count(array_filter($foocav));
	$foocav3 = $foocav2/$numbfoo;
	
	$recav8 = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='French' AND school='".$_SESSION["school"]."'");
	while($rowcav8 = mysqli_fetch_assoc($recav8))
							{
							$frecavin[]	= $rowcav8['score'];
							}
							$frecav = array_filter($frecavin);
							$frecav2 = array_sum($frecav);
	$numbfre = count(array_filter($frecav));
	$frecav3 = $frecav2/$numbfre;
	
	$recav9 = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='ICT' AND school='".$_SESSION["school"]."'");
	while($rowcav9 = mysqli_fetch_assoc($recav9))
							{
							$ictcavin[]	= $rowcav9['score'];
							}
							$ictcav = array_filter($ictcavin);
							$ictcav2 = array_sum($ictcav);
	$numbict = count(array_filter($ictcav));
	$ictcav3 = $ictcav2/$numbict;
	
	$recav10 = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Igbo' AND school='".$_SESSION["school"]."'");
	while($rowcav10 = mysqli_fetch_assoc($recav10))
							{
							$igbcavin[]	= $rowcav10['score'];
							}
							$igbcav = array_filter($igbcavin);
							$igbcav2 = array_sum($igbcav);
	$numbigb = count(array_filter($igbcav));
	$igbcav3 = $igbcav2/$numbigb;
	
	$recav11 = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Mathematics' AND school='".$_SESSION["school"]."'");
	while($rowcav11 = mysqli_fetch_assoc($recav11))
							{
							$matcavin[]	= $rowcav11['score'];
							}
							$matcav = array_filter($matcavin);
							$matcav2 = array_sum($matcav);
	$numbmat = count(array_filter($matcav));
	$matcav3 = $matcav2/$numbmat;
	
	$recav12 = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Music' AND school='".$_SESSION["school"]."'");
	while($rowcav12 = mysqli_fetch_assoc($recav12))
							{
							$muscavin[]	= $rowcav12['score'];
							}
							$muscav = array_filter($muscavin);
							$muscav2 = array_sum($muscav);
	$numbmus = count(array_filter($muscav));
	$muscav3 = $muscav2/$numbmus;
	
	$recav13 = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='PHE' AND school='".$_SESSION["school"]."'");
	while($rowcav13 = mysqli_fetch_assoc($recav13))
							{
							$phecavin[]	= $rowcav13['score'];
							}
							$phecav = array_filter($phecavin);
							$phecav2 = array_sum($phecav);
	$numbphe = count(array_filter($phecav));
	$phecav3 = $phecav2/$numbphe;

	$recav14 = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Social Studies' AND school='".$_SESSION["school"]."'");
	while($rowcav14 = mysqli_fetch_assoc($recav14))
							{
							$soccavin[]	= $rowcav14['score'];
							}
							$soccav = array_filter($soccavin);
							$soccav2 = array_sum($soccav);
	$numbsoc = count(array_filter($soccav));
	$soccav3 = $soccav2/$numbsoc;
	
	$recav15 = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Biology' AND school='".$_SESSION["school"]."'");
	while($rowcav15 = mysqli_fetch_assoc($recav15))
							{
							$biocavin[]	= $rowcav15['score'];
							}
							$biocav = array_filter($biocavin);
							$biocav2 = array_sum($biocav);
	$numbbio = count(array_filter($biocav));
	$biocav3 = $biocav2/$numbbio;
	
	$recav16 = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Chemistry' AND school='".$_SESSION["school"]."'");
	while($rowcav16 = mysqli_fetch_assoc($recav16))
							{
							$checavin[]	= $rowcav16['score'];
							}
							$checav = array_filter($checavin);
							$checav2 = array_sum($checav);
	$numbche = count(array_filter($checav));
	$checav3 = $checav2/$numbche;
	
	$recav17 = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Economics' AND school='".$_SESSION["school"]."'");
	while($rowcav17 = mysqli_fetch_assoc($recav17))
							{
							$ecocavin[]	= $rowcav17['score'];
							}
							$ecocav = array_filter($ecocavin);
							$ecocav2 = array_sum($ecocav);
	$numbeco = count(array_filter($ecocav));
	$ecocav3 = $ecocav2/$numbeco;
	
	$recav18 = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Government' AND school='".$_SESSION["school"]."'");
	while($rowcav18 = mysqli_fetch_assoc($recav18))
							{
							$govcavin[]	= $rowcav18['score'];
							}
							$govcav = array_filter($govcavin);
							$govcav2 = array_sum($govcav);
	$numbgov = count(array_filter($govcav));
	$govcav3 = $govcav2/$numbgov;
	
	$recav19 = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='VA' AND school='".$_SESSION["school"]."'");
	while($rowcav19 = mysqli_fetch_assoc($recav19))
							{
							$vacavin[]	= $rowcav19['score'];
							}
							$vacav = array_filter($vacavin);
							$vacav2 = array_sum($vacav);
	$numbva = count(array_filter($vacav));
	$vacav3 = $vacav2/$numbva;
	
	$recav20 = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='TD' AND school='".$_SESSION["school"]."'");
	while($rowcav20 = mysqli_fetch_assoc($recav20))
							{
							$tdcavin[]	= $rowcav20['score'];
							}
							$vacav = array_filter($tdcavin);
							$tdcav2 = array_sum($tdcav);
	$numbtd = count(array_filter($tdcav));
	$tdcav3 = $tdcav2/$numbtd;
	
	$recav21 = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Sociology' AND school='".$_SESSION["school"]."'");
	while($rowcav21 = mysqli_fetch_assoc($recav21))
							{
							$socicavin[]	= $rowcav21['score'];
							}
							$socicav = array_filter($socicavin);
							$socicav2 = array_sum($socicav);
	$numbsoci = count(array_filter($socicav));
	$socicav3 = $socicav2/$numbsoci;
							
	$recav22 = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Physics' AND school='".$_SESSION["school"]."'");
	while($rowcav22 = mysqli_fetch_assoc($recav22))
							{
							$phycavin[]	= $rowcav22['score'];
							}
							$phycav = array_filter($phycavin);
							$phycav2 = array_sum($phycav);
	$numbphy = count(array_filter($phycav));
	$phycav3 = $phycav2/$numbphy;
	
	$recav23 = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Marketing' AND school='".$_SESSION["school"]."'");
	while($rowcav23 = mysqli_fetch_assoc($recav23))
							{
							$marcavin[]	= $rowcav23['score'];
							}
							$marcav = array_filter($marcavin);
							$marcav2 = array_sum($marcav);
	$numbmar = count(array_filter($marcav));
	$marcav3 = $marcav2/$numbmar;
	
	$recav24 = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Lit in English' AND school='".$_SESSION["school"]."'");
	while($rowcav24 = mysqli_fetch_assoc($recav24))
							{
							$litcavin[]	= $rowcav24['score'];
							}
							$litcav = array_filter($litcavin);
							$litcav2 = array_sum($litcav);
	$numblit = count(array_filter($litcav));
	$litcav3 = $litcav2/$numblit;
	
	$recav25 = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Yoruba' AND school='".$_SESSION["school"]."'");
	while($rowcav25 = mysqli_fetch_assoc($recav25))
							{
							$yorcavin[]	= $rowcav25['score'];
							}
							$yorcav = array_filter($yorcavin);
							$yorcav2 = array_sum($yorcav);
	$numbyor = count(array_filter($yorcav));
	$yorcav3 = $yorcav2/$numbyor;
	
	$recav26 = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Quantitative Reasoning' AND school='".$_SESSION["school"]."'");
	while($rowcav26 = mysqli_fetch_assoc($recav26))
							{
							$qrcavin[]	= $rowcav26['score'];
							}
							$qrcav = array_filter($qrcavin);
							$qrcav2 = array_sum($qrcav);
	$numbqr = count(array_filter($qrcav));
	$qrcav3 = $qrcav2/$numbqr;
	
	$recav27 = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Verbal Reasoning' AND school='".$_SESSION["school"]."'");
	while($rowcav27 = mysqli_fetch_assoc($recav27))
							{
							$vrcavin[]	= $rowcav27['score'];
							}
							$vrcav = array_filter($vrcavin);
							$vrcav2 = array_sum($vrcav);
	$numbvr = count(array_filter($vrcav));
	$vrcav3 = $vrcav2/$numbvr;
	
	$recav28 = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Geography' AND school='".$_SESSION["school"]."'");
	$recavmax28 = mysqli_query($db, "SELECT MAX(score) AS agrmax FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Geography' AND school='".$_SESSION["school"]."'");
	while($rowcav28 = mysqli_fetch_assoc($recav28))
							{
							$geocavin[]	= $rowcav28['score'];
							}
							$geocav = array_filter($geocavin);
							$geocav2 = array_sum($geocav);
	$numbgeo = count(array_filter($geocav));
	$geocav3 = $geocav2/$numbgeo;
	
	$recav29 = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Handwriting' AND school='".$_SESSION["school"]."'");
	while($rowcav29 = mysqli_fetch_assoc($recav29))
							{
							$hwcavin[]	= $rowcav29['score'];
							}
							$hwcav = array_filter($hwcavin);
							$hwcav2 = array_sum($hwcav);
	$numbhw = count(array_filter($hwcav));
	$hwcav3 = $hwcav2/$numbhw;
	
	$recav30 = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Vocational Aptitude' AND school='".$_SESSION["school"]."'");
	while($rowcav30 = mysqli_fetch_assoc($recav30))
							{
							$vapcavin[]	= $rowcav30['score'];
							}
							$vapcav = array_filter($vapcavin);
							$vapcav2 = array_sum($vapcav);
	$numbvap = count(array_filter($vapcav));
	$vapcav3 = $vapcav2/$numbvap;
	
	$recav31 = mysqli_query($db, "SELECT score FROM scoresmid WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Phonics' AND school='".$_SESSION["school"]."'");
	while($rowcav31 = mysqli_fetch_assoc($recav31))
							{
							$phocavin[]	= $rowcav31['score'];
							}
							$phocav = array_filter($phocavin);
							$phocav2 = array_sum($phocav);
	$numbpho = count(array_filter($phocav));
	$phocav3 = $phocav2/$numbpho;
	
	$recav32 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Islamic Religious Studies' AND school='".$_SESSION["school"]."'");
	while($rowcav32 = mysqli_fetch_assoc($recav32))
							{
							$irscavin[]	= $rowcav32['score'];
							}
							$irscav = array_filter($irscavin);
							$irscav2 = array_sum($irscav);
	$numbirs = count(array_filter($irscav));
	$irscav3 = $irscav2/$numbirs;
	
	$recav33 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Creative and Cultural Arts' AND school='".$_SESSION["school"]."'");
	while($rowcav33 = mysqli_fetch_assoc($recav33))
							{
							$ccacavin[]	= $rowcav33['score'];
							}
							$ccacav = array_filter($ccacavin);
							$ccacav2 = array_sum($ccacav);
	$numbcca = count(array_filter($ccacav));
	$ccacav3 = $ccacav2/$numbcca;
	
	$recav34 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='History' AND school='".$_SESSION["school"]."'");
	while($rowcav34 = mysqli_fetch_assoc($recav34))
							{
							$hiscavin[]	= $rowcav34['score'];
							}
							$hiscav = array_filter($hiscavin);
							$hiscav2 = array_sum($hiscav);
	$numbhis = count(array_filter($hiscav));
	$hiscav3 = $hiscav2/$numbhis;
	
	$recav35 = mysqli_query($db, "SELECT score FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Hausa' AND school='".$_SESSION["school"]."'");
	while($rowcav35 = mysqli_fetch_assoc($recav35))
							{
							$haucavin[]	= $rowcav35['score'];
							}
							$haucav = array_filter($haucavin);
							$haucav2 = array_sum($haucav);
	$numbhau = count(array_filter($haucav));
	$haucav3 = $haucav2/$numbhau;
							if($row["subject"] == "Agricultural Science"){$ccav = $agrcav3;}
								elseif($row["subject"] == "Basic Science"){$ccav = $bascav3;}
								elseif($row["subject"] == "English"){$ccav = $engcav3;}
								elseif($row["subject"] == "Business Studies"){$ccav = $buscav3;}
								elseif($row["subject"] == "Catering"){$ccav = $catcav3;}
								elseif($row["subject"] == "Civic Education"){$ccav = $civcav3;}
								elseif($row["subject"] == "Crk"){$ccav = $crkcav3;}
								elseif($row["subject"] == "Food and Nutrition"){$ccav = $foocav3;}
								elseif($row["subject"] == "ICT"){$ccav = $ictcav3;}
								elseif($row["subject"] == "French"){$ccav = $frecav3;}
								elseif($row["subject"] == "Igbo"){$ccav = $igbcav3;}
								elseif($row["subject"] == "Mathematics"){$ccav = $matcav3;}
								elseif($row["subject"] == "Music"){$ccav = $muscav3;}
								elseif($row["subject"] == "PHE"){$ccav = $phecav3;}
								elseif($row["subject"] == "Social Studies"){$ccav = $soccav3;}
								elseif($row["subject"] == "Biology"){$ccav = $biocav3;}
								elseif($row["subject"] == "Chemistry"){$ccav = $checav3;}
								elseif($row["subject"] == "Economics"){$ccav = $ecocav3;}
								elseif($row["subject"] == "Government"){$ccav = $govcav3;}
								elseif($row["subject"] == "VA"){$ccav = $vacav3;}
								elseif($row["subject"] == "TD"){$ccav = $tdcav3;}
								elseif($row["subject"] == "Sociology"){$ccav = $socicav3;}
								elseif($row["subject"] == "Marketing"){$ccav = $marcav3;}
								elseif($row["subject"] == "Physics"){$ccav = $phycav3;}
								elseif($row["subject"] == "Lit in English"){$ccav = $litcav3;}
								elseif($row["subject"] == "Yoruba"){$ccav = $yorcav3;}
								elseif($row["subject"] == "Quantitative Reasoning"){$ccav = $qrcav3;}
								elseif($row["subject"] == "Verbal Reasoning"){$ccav = $vrcav3;}
								elseif($row["subject"] == "Geography"){$ccav = $geocav3;}
								elseif($row["subject"] == "Handwriting"){$ccav = $hwcav3;}
								elseif($row["subject"] == "Vocational Aptitude"){$ccav = $vapcav3;}
								elseif($row["subject"] == "Phonics"){$ccav = $phocav3;}
								elseif($row["subject"] == "Islamic Religious Studies"){$ccav = $irscav3;}
								elseif($row["subject"] == "Creative and Cultural Arts"){$ccav = $ccacav3;}
								elseif($row["subject"] == "History"){$ccav = $hiscav3;}
								elseif($row["subject"] == "Hausa"){$ccav = $haucav3;}
								elseif($ccav == ""){$ccav = "-";}
								else{$ccav = "-";}
								
								echo '<tr><td>'.$row["subject"].'</td><td>'.$row["hw"].'</td><td>'.$row["cw"].'</td><td>'.$row["test"].'</td><td>'.$row["score"].'</td><td>'.round($ccav).'</td><td>'.$grade.'</td><td>'.$row["teacher_name"].'</td><td>'.$row["remark"].'</td></tr>';				
		$arrsubj[] = $row["subject"];					
		$hwork[] = $row["hw"];
		$cwork[] = $row["cw"];
		$test[] = $row["test"];
		$score[] = $row["score"];
		$grades[] = $grade;
		$teacher_name[] = $row["teacher_name"];	
		$remark[] = $row["remark"];
		$ccav2[] = round($ccav);
		}		
		}
else{
		$result = mysqli_query($db, "SELECT * FROM scoresmid WHERE arms='$arms' AND student_name='$student_name' AND class_name='$class_name' AND year='$year' AND term='$term' AND school='".$_SESSION["school"]."' ORDER BY subject ASC");		
					while($row = mysqli_fetch_assoc($result))
							{  
								if($row["score"] >= 80){$grade = "A1"; }
								else if(($row["score"] >= 70) AND ($row["score"] <= 79)){$grade = "B2";}
								else if(($row["score"] >= 65) AND ($row["score"] <= 69)){$grade = "B3";}
								else if(($row["score"] >= 60) AND ($row["score"] <= 64)){$grade = "C4";}
								else if(($row["score"] >= 55) AND ($row["score"] <= 59)){$grade = "C5";}
								else if(($row["score"] >= 50) AND ($row["score"] <= 54)){$grade = "C6";}
								else if(($row["score"] >= 45) AND ($row["score"] <= 49)){$grade = "D7";}
								else if(($row["score"] >= 40) AND ($row["score"] <= 44)){$grade = "E8";}
								else if(($row["score"] <= 39)){$grade = "F9";}
								else {$grade = "NA";}	

	$recav = mysqli_query($db, "SELECT score FROM scoresmid WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
	$recavmax = mysqli_query($db, "SELECT MAX(score) AS agrmax FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Agricultural Science' AND school='".$_SESSION["school"]."'");
	while($rowcav = mysqli_fetch_assoc($recav))
							{
							$agrcavin[]	= $rowcav['score'];
							}
							$agrcav = array_filter($agrcavin);
							$agrcav2 = array_sum($agrcav);
	$numbagr = count(array_filter($agrcav));
	$agrcav3 = $agrcav2/$numbagr;
	
	$recav1 = mysqli_query($db, "SELECT score FROM scoresmid WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Basic Science' AND school='".$_SESSION["school"]."'");
	while($rowcav1 = mysqli_fetch_assoc($recav1))
							{
							$bascavin[]	= $rowcav1['score'];
							}
							$bascav = array_filter($bascavin);
							$bascav2 = array_sum($bascav);
	$numbbas = count(array_filter($bascav));
	$bascav3 = $bascav2/$numbbas;
	
	$recav2 = mysqli_query($db, "SELECT score FROM scoresmid WHERE  arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='English' AND school='".$_SESSION["school"]."'");
	$recav2max = mysqli_query($db, "SELECT MAX(score) AS engmax FROM scores WHERE class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='English' AND school='".$_SESSION["school"]."'");
	while($rowcav2 = mysqli_fetch_assoc($recav2))
							{
							$engcavin[]	= $rowcav2['score'];
							}
							$engcav = array_filter($engcavin);
							$engcav2 = array_sum($engcav);
	$numbeng = count(array_filter($engcav));
	$engcav3 = round($engcav2/$numbeng);
	while($rowcav2max = mysqli_fetch_assoc($recav2max))
							{
							$engcavinmax[]	= $rowcav2max['engmax'];
							}
							$engcavmax = array_filter($engcavinmax);
							$engcav2max = array_sum($engcavmax);
	$numbengmax = count(array_filter($engcavmax));
	$engcav3max = $engcav2max/$numbengmax;
	//echo $engcav3max;
	
	$recav3 = mysqli_query($db, "SELECT score FROM scoresmid WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Business Studies' AND school='".$_SESSION["school"]."'");
	while($rowcav3 = mysqli_fetch_assoc($recav3))
							{
							$buscavin[]	= $rowcav3['score'];
							}
							$buscav = array_filter($buscavin);
							$buscav2 = array_sum($buscav);
	$numbbus = count(array_filter($buscav));
	$buscav3 = round($buscav2/$numbbus);
	
	$recav4 = mysqli_query($db, "SELECT score FROM scoresmid WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Catering' AND school='".$_SESSION["school"]."'");
	while($rowcav4 = mysqli_fetch_assoc($recav4))
							{
							$catcavin[]	= $rowcav4['score'];
							}
							$catcav = array_filter($catcavin);
							$catcav2 = array_sum($catcav);
	$numbcat = count(array_filter($catcav));
	$catcav3 = $catcav2/$numbcat;
	
	$recav5 = mysqli_query($db, "SELECT score FROM scoresmid WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Civic Education' AND school='".$_SESSION["school"]."'");
	while($rowcav5 = mysqli_fetch_assoc($recav5))
							{
							$civcavin[]	= $rowcav5['score'];
							}
							$civcav = array_filter($civcavin);
							$civcav2 = array_sum($civcav);
	$numbciv = count(array_filter($civcav));
	$civcav3 = $civcav2/$numbciv;
	
	$recav6 = mysqli_query($db, "SELECT score FROM scoresmid WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Crk' AND school='".$_SESSION["school"]."'");
	while($rowcav6 = mysqli_fetch_assoc($recav6))
							{
							$crkcavin[]	= $rowcav6['score'];
							}
							$crkcav = array_filter($crkcavin);
							$crkcav2 = array_sum($crkcav);
	$numbcrk = count(array_filter($crkcav));
	$crkcav3 = $crkcav2/$numbcrk;
	
	$recav7 = mysqli_query($db, "SELECT score FROM scoresmid WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Food and Nutrition' AND school='".$_SESSION["school"]."'");
	while($rowcav7 = mysqli_fetch_assoc($recav7))
							{
							$foocavin[]	= $rowcav7['score'];
							}
							$foocav = array_filter($foocavin);
							$foocav2 = array_sum($foocav);
	$numbfoo = count(array_filter($foocav));
	$foocav3 = $foocav2/$numbfoo;
	
	$recav8 = mysqli_query($db, "SELECT score FROM scoresmid WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='French' AND school='".$_SESSION["school"]."'");
	while($rowcav8 = mysqli_fetch_assoc($recav8))
							{
							$frecavin[]	= $rowcav8['score'];
							}
							$frecav = array_filter($frecavin);
							$frecav2 = array_sum($frecav);
	$numbfre = count(array_filter($frecav));
	$frecav3 = $frecav2/$numbfre;
	
	$recav9 = mysqli_query($db, "SELECT score FROM scoresmid WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='ICT' AND school='".$_SESSION["school"]."'");
	while($rowcav9 = mysqli_fetch_assoc($recav9))
							{
							$ictcavin[]	= $rowcav9['score'];
							}
							$ictcav = array_filter($ictcavin);
							$ictcav2 = array_sum($ictcav);
	$numbict = count(array_filter($ictcav));
	$ictcav3 = $ictcav2/$numbict;
	
	$recav10 = mysqli_query($db, "SELECT score FROM scoresmid WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Igbo' AND school='".$_SESSION["school"]."'");
	while($rowcav10 = mysqli_fetch_assoc($recav10))
							{
							$igbcavin[]	= $rowcav10['score'];
							}
							$igbcav = array_filter($igbcavin);
							$igbcav2 = array_sum($igbcav);
	$numbigb = count(array_filter($igbcav));
	$igbcav3 = $igbcav2/$numbigb;
	
	$recav11 = mysqli_query($db, "SELECT score FROM scoresmid WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Mathematics' AND school='".$_SESSION["school"]."'");
	while($rowcav11 = mysqli_fetch_assoc($recav11))
							{
							$matcavin[]	= $rowcav11['score'];
							}
							$matcav = array_filter($matcavin);
							$matcav2 = array_sum($matcav);
	$numbmat = count(array_filter($matcav));
	$matcav3 = $matcav2/$numbmat;
	
	$recav12 = mysqli_query($db, "SELECT score FROM scoresmid WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Music' AND school='".$_SESSION["school"]."'");
	while($rowcav12 = mysqli_fetch_assoc($recav12))
							{
							$muscavin[]	= $rowcav12['score'];
							}
							$muscav = array_filter($muscavin);
							$muscav2 = array_sum($muscav);
	$numbmus = count(array_filter($muscav));
	$muscav3 = $muscav2/$numbmus;
	
	$recav13 = mysqli_query($db, "SELECT score FROM scoresmid WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='PHE' AND school='".$_SESSION["school"]."'");
	while($rowcav13 = mysqli_fetch_assoc($recav13))
							{
							$phecavin[]	= $rowcav13['score'];
							}
							$phecav = array_filter($phecavin);
							$phecav2 = array_sum($phecav);
	$numbphe = count(array_filter($phecav));
	$phecav3 = $phecav2/$numbphe;

	$recav14 = mysqli_query($db, "SELECT score FROM scoresmid WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Social Studies' AND school='".$_SESSION["school"]."'");
	while($rowcav14 = mysqli_fetch_assoc($recav14))
							{
							$soccavin[]	= $rowcav14['score'];
							}
							$soccav = array_filter($soccavin);
							$soccav2 = array_sum($soccav);
	$numbsoc = count(array_filter($soccav));
	$soccav3 = $soccav2/$numbsoc;
	
	$recav15 = mysqli_query($db, "SELECT score FROM scoresmid WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Biology' AND school='".$_SESSION["school"]."'");
	while($rowcav15 = mysqli_fetch_assoc($recav15))
							{
							$biocavin[]	= $rowcav15['score'];
							}
							$biocav = array_filter($biocavin);
							$biocav2 = array_sum($biocav);
	$numbbio = count(array_filter($biocav));
	$biocav3 = $biocav2/$numbbio;
	
	$recav16 = mysqli_query($db, "SELECT score FROM scoresmid WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Chemistry' AND school='".$_SESSION["school"]."'");
	while($rowcav16 = mysqli_fetch_assoc($recav16))
							{
							$checavin[]	= $rowcav16['score'];
							}
							$checav = array_filter($checavin);
							$checav2 = array_sum($checav);
	$numbche = count(array_filter($checav));
	$checav3 = $checav2/$numbche;
	
	$recav17 = mysqli_query($db, "SELECT score FROM scoresmid WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Economics' AND school='".$_SESSION["school"]."'");
	while($rowcav17 = mysqli_fetch_assoc($recav17))
							{
							$ecocavin[]	= $rowcav17['score'];
							}
							$ecocav = array_filter($ecocavin);
							$ecocav2 = array_sum($ecocav);
	$numbeco = count(array_filter($ecocav));
	$ecocav3 = $ecocav2/$numbeco;
	
	$recav18 = mysqli_query($db, "SELECT score FROM scoresmid WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Government' AND school='".$_SESSION["school"]."'");
	while($rowcav18 = mysqli_fetch_assoc($recav18))
							{
							$govcavin[]	= $rowcav18['score'];
							}
							$govcav = array_filter($govcavin);
							$govcav2 = array_sum($govcav);
	$numbgov = count(array_filter($govcav));
	$govcav3 = $govcav2/$numbgov;
	
	$recav19 = mysqli_query($db, "SELECT score FROM scoresmid WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='VA' AND school='".$_SESSION["school"]."'");
	while($rowcav19 = mysqli_fetch_assoc($recav19))
							{
							$vacavin[]	= $rowcav19['score'];
							}
							$vacav = array_filter($vacavin);
							$vacav2 = array_sum($vacav);
	$numbva = count(array_filter($vacav));
	$vacav3 = $vacav2/$numbva;
	
	$recav20 = mysqli_query($db, "SELECT score FROM scoresmid WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='TD' AND school='".$_SESSION["school"]."'");
	while($rowcav20 = mysqli_fetch_assoc($recav20))
							{
							$tdcavin[]	= $rowcav20['score'];
							}
							$vacav = array_filter($tdcavin);
							$tdcav2 = array_sum($tdcav);
	$numbtd = count(array_filter($tdcav));
	$tdcav3 = $tdcav2/$numbtd;
	
	$recav21 = mysqli_query($db, "SELECT score FROM scoresmid WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Sociology' AND school='".$_SESSION["school"]."'");
	while($rowcav21 = mysqli_fetch_assoc($recav21))
							{
							$socicavin[]	= $rowcav21['score'];
							}
							$socicav = array_filter($socicavin);
							$socicav2 = array_sum($socicav);
	$numbsoci = count(array_filter($socicav));
	$socicav3 = $socicav2/$numbsoci;
							
	$recav22 = mysqli_query($db, "SELECT score FROM scoresmid WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Physics' AND school='".$_SESSION["school"]."'");
	while($rowcav22 = mysqli_fetch_assoc($recav22))
							{
							$phycavin[]	= $rowcav22['score'];
							}
							$phycav = array_filter($phycavin);
							$phycav2 = array_sum($phycav);
	$numbphy = count(array_filter($phycav));
	$phycav3 = $phycav2/$numbphy;
	
	$recav23 = mysqli_query($db, "SELECT score FROM scoresmid WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Marketing' AND school='".$_SESSION["school"]."'");
	while($rowcav23 = mysqli_fetch_assoc($recav23))
							{
							$marcavin[]	= $rowcav23['score'];
							}
							$marcav = array_filter($marcavin);
							$marcav2 = array_sum($marcav);
	$numbmar = count(array_filter($marcav));
	$marcav3 = $marcav2/$numbmar;
	
	$recav24 = mysqli_query($db, "SELECT score FROM scoresmid WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Lit in English' AND school='".$_SESSION["school"]."'");
	while($rowcav24 = mysqli_fetch_assoc($recav24))
							{
							$litcavin[]	= $rowcav24['score'];
							}
							$litcav = array_filter($litcavin);
							$litcav2 = array_sum($litcav);
	$numblit = count(array_filter($litcav));
	$litcav3 = $litcav2/$numblit;
	
	$recav25 = mysqli_query($db, "SELECT score FROM scoresmid WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Yoruba' AND school='".$_SESSION["school"]."'");
	while($rowcav25 = mysqli_fetch_assoc($recav25))
							{
							$yorcavin[]	= $rowcav25['score'];
							}
							$yorcav = array_filter($yorcavin);
							$yorcav2 = array_sum($yorcav);
	$numbyor = count(array_filter($yorcav));
	$yorcav3 = $yorcav2/$numbyor;
	
	$recav26 = mysqli_query($db, "SELECT score FROM scoresmid WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Quantitative Reasoning' AND school='".$_SESSION["school"]."'");
	while($rowcav26 = mysqli_fetch_assoc($recav26))
							{
							$qrcavin[]	= $rowcav26['score'];
							}
							$qrcav = array_filter($qrcavin);
							$qrcav2 = array_sum($qrcav);
	$numbqr = count(array_filter($qrcav));
	$qrcav3 = $qrcav2/$numbqr;
	
	$recav27 = mysqli_query($db, "SELECT score FROM scoresmid WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Verbal Reasoning' AND school='".$_SESSION["school"]."'");
	while($rowcav27 = mysqli_fetch_assoc($recav27))
							{
							$vrcavin[]	= $rowcav27['score'];
							}
							$vrcav = array_filter($vrcavin);
							$vrcav2 = array_sum($vrcav);
	$numbvr = count(array_filter($vrcav));
	$vrcav3 = $vrcav2/$numbvr;
	
	$recav28 = mysqli_query($db, "SELECT score FROM scoresmid WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Geography' AND school='".$_SESSION["school"]."'");
	while($rowcav28 = mysqli_fetch_assoc($recav28))
							{
							$geocavin[]	= $rowcav28['score'];
							}
							$geocav = array_filter($geocavin);
							$geocav2 = array_sum($geocav);
	$numbgeo = count(array_filter($geocav));
	$geocav3 = $geocav2/$numbgeo;
	
	$recav29 = mysqli_query($db, "SELECT score FROM scoresmid WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Handwriting' AND school='".$_SESSION["school"]."'");
	while($rowcav29 = mysqli_fetch_assoc($recav29))
							{
							$hwcavin[]	= $rowcav29['score'];
							}
							$hwcav = array_filter($hwcavin);
							$hwcav2 = array_sum($hwcav);
	$numbhw = count(array_filter($hwcav));
	$hwcav3 = $hwcav2/$numbhw;
	
	$recav30 = mysqli_query($db, "SELECT score FROM scoresmid WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Vocational Aptitude' AND school='".$_SESSION["school"]."'");
	while($rowcav30 = mysqli_fetch_assoc($recav30))
							{
							$vapcavin[]	= $rowcav30['score'];
							}
							$vapcav = array_filter($vapcavin);
							$vapcav2 = array_sum($vapcav);
	$numbvap = count(array_filter($vapcav));
	$vapcav3 = $vapcav2/$numbvap;
	
	$recav31 = mysqli_query($db, "SELECT score FROM scoresmid WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Phonics' AND school='".$_SESSION["school"]."'");
	while($rowcav31 = mysqli_fetch_assoc($recav31))
							{
							$phocavin[]	= $rowcav31['score'];
							}
							$phocav = array_filter($phocavin);
							$phocav2 = array_sum($phocav);
	$numbpho = count(array_filter($phocav));
	$phocav3 = $phocav2/$numbpho;
	
	$recav32 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Islamic Religious Studies' AND school='".$_SESSION["school"]."'");
	while($rowcav32 = mysqli_fetch_assoc($recav32))
							{
							$irscavin[]	= $rowcav32['score'];
							}
							$irscav = array_filter($irscavin);
							$irscav2 = array_sum($irscav);
	$numbirs = count(array_filter($irscav));
	$irscav3 = $irscav2/$numbirs;
	
		$recav33 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Creative and Cultural Arts' AND school='".$_SESSION["school"]."'");
	while($rowcav33 = mysqli_fetch_assoc($recav33))
							{
							$ccacavin[]	= $rowcav33['score'];
							}
							$ccacav = array_filter($ccacavin);
							$ccacav2 = array_sum($ccacav);
	$numbcca = count(array_filter($ccacav));
	$ccacav3 = $ccacav2/$numbcca;
	
		$recav34 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='History' AND school='".$_SESSION["school"]."'");
	while($rowcav34 = mysqli_fetch_assoc($recav34))
							{
							$hiscavin[]	= $rowcav34['score'];
							}
							$hiscav = array_filter($hiscavin);
							$hiscav2 = array_sum($hiscav);
	$numbhis = count(array_filter($hiscav));
	$hiscav3 = $hiscav2/$numbhis;
	
	$recav35 = mysqli_query($db, "SELECT score FROM scores WHERE arms='$arms' AND class_name='$class_name' AND year='$year' AND (term='First Term' OR term='Second Term' OR term='Third Term') AND subject='Hausa' AND school='".$_SESSION["school"]."'");
	while($rowcav35 = mysqli_fetch_assoc($recav35))
							{
							$haucavin[]	= $rowcav35['score'];
							}
							$haucav = array_filter($haucavin);
							$haucav2 = array_sum($haucav);
	$numbhau = count(array_filter($haucav));
	$haucav3 = $haucav2/$numbhau;
		
		if($row["subject"] == "Agricultural Science"){$ccav = $agrcav3;}
								elseif($row["subject"] == "Basic Science"){$ccav = $bascav3;}
								elseif($row["subject"] == "English"){$ccav = $engcav3;}
								elseif($row["subject"] == "Business Studies"){$ccav = $buscav3;}
								elseif($row["subject"] == "Catering"){$ccav = $catcav3;}
								elseif($row["subject"] == "Civic Education"){$ccav = $civcav3;}
								elseif($row["subject"] == "Crk"){$ccav = $crkcav3;}
								elseif($row["subject"] == "Food and Nutrition"){$ccav = $foocav3;}
								elseif($row["subject"] == "ICT"){$ccav = $ictcav3;}
								elseif($row["subject"] == "French"){$ccav = $frecav3;}
								elseif($row["subject"] == "Igbo"){$ccav = $igbcav3;}
								elseif($row["subject"] == "Mathematics"){$ccav = $matcav3;}
								elseif($row["subject"] == "Music"){$ccav = $muscav3;}
								elseif($row["subject"] == "PHE"){$ccav = $phecav3;}
								elseif($row["subject"] == "Social Studies"){$ccav = $soccav3;}
								elseif($row["subject"] == "Biology"){$ccav = $biocav3;}
								elseif($row["subject"] == "Chemistry"){$ccav = $checav3;}
								elseif($row["subject"] == "Economics"){$ccav = $ecocav3;}
								elseif($row["subject"] == "Government"){$ccav = $govcav3;}
								elseif($row["subject"] == "VA"){$ccav = $vacav3;}
								elseif($row["subject"] == "TD"){$ccav = $tdcav3;}
								elseif($row["subject"] == "Sociology"){$ccav = $socicav3;}
								elseif($row["subject"] == "Marketing"){$ccav = $marcav3;}
								elseif($row["subject"] == "Physics"){$ccav = $phycav3;}
								elseif($row["subject"] == "Lit in English"){$ccav = $litcav3;}
								elseif($row["subject"] == "Yoruba"){$ccav = $yorcav3;}
								elseif($row["subject"] == "Quantitative Reasoning"){$ccav = $qrcav3;}
								elseif($row["subject"] == "Verbal Reasoning"){$ccav = $vrcav3;}
								elseif($row["subject"] == "Geography"){$ccav = $geocav3;}
								elseif($row["subject"] == "Handwriting"){$ccav = $hwcav3;}
								elseif($row["subject"] == "Vocational Aptitude"){$ccav = $vapcav3;}
								elseif($row["subject"] == "Phonics"){$ccav = $phocav3;}
								elseif($row["subject"] == "Islamic Religious Studies"){$ccav = $irscav3;}
								elseif($row["subject"] == "Creative and Cultural Arts"){$ccav = $ccacav3;}
								elseif($row["subject"] == "History"){$ccav = $hiscav3;}
								elseif($row["subject"] == "Hausa"){$ccav = $haucav3;}
								elseif($ccav == ""){$ccav = "-";}
								else{$ccav = "-";}
								
								echo '<tr><td>'.$row["subject"].'</td><td>'.$row["hw"].'</td><td>'.$row["cw"].'</td><td>'.$row["test"].'</td><td>'.$row["score"].'</td><td>'.round($ccav).'</td><td>'.$grade.'</td><td>'.$row["teacher_name"].'</td><td>'.$row["remark"].'</td></tr>';				
		$arrsubj[] = $row["subject"];					
		$hwork[] = $row["hw"];
		$cwork[] = $row["cw"];
		$test[] = $row["test"];
		$score[] = $row["score"];
		$grades[] = $grade;
		$teacher_name[] = $row["teacher_name"];	
		$remark[] = $row["remark"];
		$ccav2[] = round($ccav);
	}
} //for yes arms	
		}	// for halftermsub										
?>
</table>
<hr style="width:80%;"/>
<table style="width:80%; margin:auto; padding:auto; font-size: 10px;">
<tr>
<?php
	$student_name = $_POST['student_name'];
        $class = $_POST['class_name'];
		$year = $_POST['year'];
		$term = $_POST['term'];
$tnames = mysqli_query($db, "SELECT studentsbyclass.hpcomment, studentsbyclass.prcomment, ftcomments.firstname FROM studentsbyclass INNER JOIN ftcomments ON studentsbyclass.student_name=ftcomments.student_name WHERE studentsbyclass.class='$class' AND studentsbyclass.student_name='$student_name' AND studentsbyclass.year='$year' AND studentsbyclass.term='$term' AND studentsbyclass.school='".$_SESSION["school"]."'");
while($rowtnames = mysqli_fetch_assoc($tnames))
{
$rowhpcomment62[] = $rowtnames['hpcomment'];
$rowftcomment62[] = $rowtnames['firstname'];
$rowprcomment62[] = $rowtnames['prcomment'];
}
$rowhpcomment = current($rowhpcomment62);
$rowftcomment = current($rowftcomment62);
$rowprcomment = current($rowprcomment62);

echo '<td style="text-align: left; font-size: 14px; width: 50%;"><span style="color: red;">Form Tutor\'s Comment:</span><br> <span style="text-decoration: none;">'.$rowftcomment.'</span></td>';
echo '<td style="text-align:right; font-size: 14px; width: 50%;"><span style="color: red;" >House Parent\'s Comment:</span><br> <span style="text-decoration: none;">'.$rowhpcomment.'</span></td>';
?>
</tr>
<tr>
<?php
$term = $_POST['term'];
$year = $_POST['year'];
$class = $_POST['class_name'];

$resultsig = mysqli_query($db, "SELECT * FROM principal where year='$year' AND school='".$_SESSION["school"]."'");
while($rowsig = mysqli_fetch_assoc($resultsig))
{
$sign2[] = $rowsig['sig'];
$imgpr2[] = $rowsig['img'];
}
$sign = current($sign2);
$imgpr = current($imgpr2);
if(($class=="Year 1")OR($class=="Year 2")OR($class=="Year 3")OR($class=="Year 4")OR($class=="Year 5")OR($class=="Year 6")){
echo '<td colspan="2" style="text-align:left; font-size: 14px; width: 50%;"><br><span style="color: red;" >Head Teacher\'s Comment:</span> <span style="text-decoration: none;">'.$rowhpcomment.'</span><br>';
}else{
echo '<td colspan="2" style="text-align:left; font-size: 14px; width: 50%;"><br><span style="color: red;" >Principal\'s Comment:</span> <span style="text-decoration: none;">'.$rowhpcomment.'</span><br>';	
}
if($sign == 1){
echo '<span style="color: red;">Signature:</span> <img src="'.$imgpr.'" alt="" width="80" height="50" />'.date("d-m-Y").'</td>';	
}else{
echo '<br><span style="color: red;">Signature:</span> _______________________</td>';	
}
?>
</tr>
</table>
<center>
<div id="loadit"></div>	
<div id="afterthis"><ul id="resultlist" style="list-style-type: none;" ></ul></div>
</center>
<br><br>
<?php
//include "connection.php";
$user=$_SESSION['username'];
$result3 = mysqli_query($db, "SELECT * FROM users2 where username='$user' AND school='".$_SESSION["school"]."'");
while($rowtid = mysqli_fetch_assoc($result3))
{
$trole[] = $rowtid['role'];
}
$trol = current($trole);
if(($trol == 'teacher')||($trol == 'student')){?>
<button class="pbutton" onclick="location.href='teagetresultmid.php';" style="float: left;">New Request</button>
<?php } ?>
<?php
if(($trol == 'principal')||($trol == 'admin')){?>
<br><br>
<button class="pbutton" onclick="location.href='admgetresult.php';" style="float: left;">New Request</button>
<?php } ?>
<button class="pbutton" onclick="printDiv('printMe');" style="float: left;">Print</button>
<a class="pbutton" style="float: left;" href="index.php">Index</a>
<?php
if(isset($_POST['halftermsub'])){	
$arms = $_POST['arms'];
$byarm = $_POST['byarm'];	
echo '<form id="resultpdf">';
foreach($arrsubj as $subjloop)
{
  echo '<input style="display: none;"  type="text" name="subjloop[]" value="'. $subjloop. '">';
}
foreach($hwork as $hwloop)
{
  echo '<input style="display: none;" type="text" name="hwloop[]" value="'. $hwloop. '">';
}
foreach($cwork as $cwloop)
{
  echo '<input style="display: none;" type="text" name="cwloop[]" value="'. $cwloop. '">';
}
foreach($test as $testloop)
{
  echo '<input style="display: none;" type="text" name="testloop[]" value="'. $testloop. '">';
}
foreach($score as $scoreloop)
{
  echo '<input style="display: none;" type="text" name="scoreloop[]" value="'. $scoreloop. '">';
}
foreach($ccav2 as $ccavloop)
{
  echo '<input style="display: none;" type="text" name="ccavloop[]" value="'. $ccavloop. '">';
}
foreach($grades as $gradeloop)
{
  echo '<input style="display: none;" type="text" name="gradeloop[]" value="'. $gradeloop. '">';
}
foreach($teacher_name as $tn)
{
  echo '<input style="display: none;" type="text" name="tn[]" value="'. $tn. '">';
}
foreach($remark as $remarkloop)
{
  echo '<input style="display: none;" type="text" name="remarkloop[]" value="'. $remarkloop. '">';
}
echo '<input   style="display: none;" name="schooll[]" type="text" value="'.$schooll. '">';
echo '<input   style="display: none;" name="address[]" type="text" value="'.$address. '">';
echo '<input   style="display: none;" name="tel[]" type="text" value="'.$tel. '">';
echo '<input   style="display: none;" name="fax[]" type="text" value="'.$fax. '">';
echo '<input   style="display: none;" name="email[]" type="text" value="'.$email. '">';
echo '<input   style="display: none;" name="img[]" type="text" value="'.$img. '">';	
echo '<input style="display: none;" name="class_name[]" type="text" value="'.$class. '">';
echo '<input style="display: none;" name="cl[]" type="text" value="'.$cl. '">';
echo '<input   style="display: none;" name="year[]" type="text" value="'.$year. '">';
echo '<input   style="display: none;" name="term[]" type="text" value="'.$term. '">';						
echo '<input   style="display: none;" name="rpic[]" type="text" value="'.$rpic2. '">';
echo '<input   style="display: none;" name="termbegin[]" type="text" value="'.$termbegin. '">';
echo '<input   style="display: none;" name="student_name[]" type="text" value="'.$student_name. '">';						
echo '<input   style="display: none;" name="admno[]" type="text" value="'.$admno2. '">';							
echo '<input   style="display: none;" name="rsex[]" type="text" value="'.$rsex2. '">';						
echo '<input   style="display: none;" name="rpic[]" type="text" value="'.$rpic2. '">';							
echo '<input   style="display: none;" name="att[]" type="text" value="'.$att. '">';
echo '<input   style="display: none;" name="rdob[]" type="text" value="'.$rdob2. '">';
echo '<input   style="display: none;" name="atall[]" type="text" value="'.$atall2. '">';
echo '<input   style="display: none;" name="rowhpcomment[]" type="text" value="'.$rowhpcomment. '">';
echo '<input   style="display: none;" name="rowftcomment[]" type="text" value="'.$rowftcomment. '">';
echo '<input   style="display: none;" name="rowprcomment[]" type="text" value="'.$rowprcomment. '">';			
echo '<input   style="display: none;" name="sign[]" type="text" value="'.$sign. '">';
echo '<input   style="display: none;" name="imgpr[]" type="text" value="'.$imgpr. '">';
echo '<input  style="display: none;" name="byarm[]" type="text" value="'.$byarm. '">';
echo '<input  style="display: none;" name="arms[]" type="text" value="'.$arms. '">';
echo '<input class="pbutton" style="float: left;" type="submit" name="submit" id="resultpdfsubmit" value="Make Downloadable" />';
echo '</form>';	

echo '<form action="chart.js2mid.php" method="POST">';
echo '<input  style="display: none;" name="arrsubj" value="'.base64_encode(serialize($arrsubj)). '">';
echo '<input  style="display: none;" name="cwork" type="text" value="'.base64_encode(serialize($cwork)). '">';
echo '<input  style="display: none;" name="hwork" type="text" value="'.base64_encode(serialize($hwork)). '">';
echo '<input  style="display: none;" name="test" type="text" value="'.base64_encode(serialize($test)). '">';
echo '<input  style="display: none;" name="score" type="text" value="'.base64_encode(serialize($score)). '">';
echo '<input  style="display: none;" name="ccav" type="text" value="'.base64_encode(serialize($ccav2)). '">';
echo '<input  style="display: none;" name="grade" type="text" value="'.base64_encode(serialize($grades)). '">';
echo '<input  style="display: none;" name="tn" type="text" value="'.base64_encode(serialize($teacher_name)). '">';
echo '<input  style="display: none;" name="remark" type="text" value="'.base64_encode(serialize($remark)). '">';
echo '<input  style="display: none;" name="student_name" type="text" value="'.$student_name. '">';
echo '<input  style="display: none;" name="class_name" type="text" value="'.$class. '">';
echo '<input  style="display: none;" name="year" type="text" value="'.$year. '">';
echo '<input  style="display: none;" name="term" type="text" value="'.$term. '">';
echo '<input  style="display: none;" name="byarm" type="text" value="'.$byarm. '">';
echo '<input  style="display: none;" name="arms" type="text" value="'.$arms. '">';
echo '<input class="pbutton" style="float: left;" type="submit" name="submit" value="View Chart of '.$student_name.'\'s Performance across Subjects" />';
echo '</form>';	

echo '<form action="tochartmid.php" method="POST">';
echo '<input  style="display: none;" name="arrsubj" value="'.base64_encode(serialize($arrsubj)). '">';
echo '<input  style="display: none;" name="cwork" type="text" value="'.base64_encode(serialize($cwork)). '">';
echo '<input  style="display: none;" name="hwork" type="text" value="'.base64_encode(serialize($hwork)). '">';
echo '<input  style="display: none;" name="test" type="text" value="'.base64_encode(serialize($test)). '">';
echo '<input  style="display: none;" name="score" type="text" value="'.base64_encode(serialize($score)). '">';
echo '<input  style="display: none;" name="ccav" type="text" value="'.base64_encode(serialize($ccav2)). '">';
echo '<input  style="display: none;" name="grade" type="text" value="'.base64_encode(serialize($grades)). '">';
echo '<input  style="display: none;" name="tn" type="text" value="'.base64_encode(serialize($teacher_name)). '">';
echo '<input  style="display: none;" name="remark" type="text" value="'.base64_encode(serialize($remark)). '">';
echo '<input  style="display: none;" style="display: none;" name="student_name" type="text" value="'.$student_name. '">';
echo '<input  style="display: none;" name="class_name" type="text" value="'.$class. '">';
echo '<input  style="display: none;" name="year" type="text" value="'.$year. '">';
echo '<input  style="display: none;" style="display: none;" name="term" type="text" value="'.$term. '">';
echo '<input  style="display: none;" name="byarm" type="text" value="'.$byarm. '">';
echo '<input  style="display: none;" name="arms" type="text" value="'.$arms. '">';
echo '<input class="pbutton" style="float: left;" type="submit" name="submit" value="View Chart of '.$student_name.'\'s Performance in a Subject across Years" />';
echo '</form>';








}
?>
<a class="pbutton" style="float: left;" href="logout.php">Logout</a>
</body>