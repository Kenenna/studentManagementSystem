<?php
	session_start();
	include("auth.php");	
	include 'connection.php';
//$score = $_POST['score'];
$teacher_id = $_POST['teacher_id'];
$student_name = $_POST['student_name'];
$subject = $_POST['subject'];
$remark = $_POST['remark'];
$arms = $_POST['arms'];
$teacher_name = $_POST['teacher'];
$class_name = $_POST['class_name'];
$year = $_POST['year'];
$term = $_POST['term'];
$hwmax = $_POST['hwmax'];
$cwmax = $_POST['cwmax'];
$testmax = $_POST['testmax'];
$camax = $_POST['camax'];
$exammax = $_POST['exammax'];
$testmaxname = $_POST['testmaxname'];
$cwmaxname = $_POST['cwmaxname'];
$hwmaxname = $_POST['hwmaxname'];

$hw2 = $_POST['hw'];
$cw2 = $_POST['cw'];
$test2 = $_POST['test'];
$ca2 = $_POST['ca'];	
$exam2 = $_POST['exam'];
$scoremid2raw = $_POST['scoremidraw'];
$scoremid2 = $_POST['scoremid'];

for ($i = 0; $i <= (count($student_name)-1); $i++){
	$hw[$i] = round(($hw2[$i]/$hwmax[$i])*30);
	$cw[$i] = round(($cw2[$i]/$cwmax[$i])*30);
	$test[$i] = round((($test2[$i]/$testmax[$i])*40));
	
	$caraw[$i] = round($hw2[$i]+$cw2[$i]+$test2[$i]+$scoremid2raw[$i]);
	$ca[$i] = round((($hw2[$i]+$cw2[$i]+$test2[$i]+$scoremid2raw[$i]) / ($hwmax[$i]+$cwmax[$i]+$testmax[$i]+$hwmaxname[$i]+$cwmaxname[$i]+$testmaxname[$i]))*40);
	//$ca[$i] = round((($hw[$i]+$cw[$i]+$test[$i]+$scoremid2[$i])/200)*40);
	$exam[$i] = round(($exam2[$i]/$exammax[$i])*60);
	$score[$i] = round(($ca[$i])+($exam[$i]));
	
	//echo $ca[$i]."--".$exam[$i]."--".$score[$i];
    //echo "<br>";
	//echo $score[$i]."--".$scoremid2[$i]."--".$scoremid2raw[$i]."--".$hw2[$i]."--".$cw2[$i]."--".$test2[$i]."--".$exam2[$i]."--".$hw[$i]."--".$cw[$i]."--".$test[$i]."--".$hwmax[$i]."--".$cwmax[$i]."--".$testmax[$i];
	//echo "<br>";
    $t = mysqli_query($db,"INSERT INTO scores(score,scoremid,scoremidraw,hwraw,cwraw,testraw,caraw,examraw,hw,cw,test,ca,exam,teacher_id,student_name,subject,remark,teacher_name,class_name,arms,year,term,hwmaxname,cwmaxname,testmaxname,exammaxname,school) VALUES('$score[$i]','$scoremid2[$i]','$scoremid2raw[$i]','$hw2[$i]','$cw2[$i]','$test2[$i]','$caraw[$i]','$exam2[$i]','$hw[$i]','$cw[$i]','$test[$i]','$ca[$i]','$exam[$i]','$teacher_id[$i]','$student_name[$i]','".ucfirst($subject[$i])."','$remark[$i]','$teacher_name[$i]','$class_name[$i]','$arms[$i]','$year[$i]','$term[$i]','$hwmax[$i]','$cwmax[$i]','$testmax[$i]','$exammax[$i]','".$_SESSION["school"]."')");
    $tt = mysqli_query($db,"INSERT INTO issues(score,student_name,class,year,term,firstname,ppfirstname,ssfirstname,ttfirstname,school) VALUES('$score[$i]','$student_name[$i]','$class_name','$year[$i]','$term[$i]','','','','','".$_SESSION["school"]."')");
	//$t = mysqli_query($db,"INSERT INTO scores(score,ca,exam,teacher_id,student_name,subject,remark,teacher_name,class_name,year,term,camaxname, exammaxname) VALUES('$score[$i]','$ca[$i]','$exam[$i]','$teacher_id[$i]','$student_name[$i]','".ucfirst($subject[$i])."','$remark[$i]','$teacher_name[$i]','$class_name[$i]','$year[$i]','$term[$i]','$camax[$i]','$exammax[$i]')");
}	
if($t){
//echo "<p align='center'>scores saved successfully</p>";
//echo '<meta content="2;index.php" http-equiv="refresh" />';
echo 1;
}	
else{
//echo "<p align='center'>NOT SAVED! PLEASE CHECK TO ENSURE YOU HAVE INPUTTED MAX SCORES!</p>";
//echo '<meta content="2;index.php" http-equiv="refresh" />';
echo 0;
}
?>

