<?php
//if(isset($_POST['btn-upload']))
//{  
  include "connection.php";
		$student_name = $_POST['student_name'];
		$class = $_POST['class'];
        $year = $_POST['year'];
		$term = $_POST['term'];
		$formt = $_POST['formt'];
		$arms = $_POST['arms'];
		//echo $student_name;
		//echo $class;
		//echo $formt;
		
 $result = mysqli_query($db, "SELECT * FROM studentsbyclass where student_name='$student_name' AND class='$class' AND year='$year' AND arms='$arms' AND term='$term' AND formt='$formt'");
  $check = mysqli_num_rows($result);
  if($check > 0){
	  echo '<span style="color: red; font-size: 18px; text-align: center;">You have a student already enrolled with the given data.</span>';
	  echo '<meta content="2;formclasses.php" http-equiv="refresh" />';
  }else{
 $sql="INSERT INTO studentsbyclass(student_name, class, year, term, formt, arms) VALUES('$student_name', '$class', '$year', '$term', '$formt', '$arms')";
 $sql2="INSERT INTO affective(student_name, class, year, term, formt, arms) VALUES('$student_name', '$class', '$year', '$term', '$formt', '$arms')";
 $ms = mysqli_query($db, $sql); 
mysqli_query($db, $sql2);
if($ms){
	echo 1;
}else{
	//echo '<img src="table/492.png" /> &nbsp;! data uploaded successfully';
		//echo '<meta content="2;formclasses.php" http-equiv="refresh" />';
		echo 0;
}
 
  }
//}
?>