<?php
session_start();
include("auth.php"); //include auth.php file on all secure pages
include "connection.php";
	
$classtype = $_POST['classtype'];

$sql1=mysqli_query($db,"UPDATE school SET classtype='$classtype' WHERE school='".$_SESSION["school"]."'");

if($sql1){
	echo 1;
}	
else{
	echo 0;
}
?>